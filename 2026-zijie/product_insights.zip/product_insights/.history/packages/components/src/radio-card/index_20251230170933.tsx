import React, { FC, useContext } from 'react';
import classNames from 'classnames';

import { Radio, Tooltip } from '@ecom/auxo';
import RadioGroupContext from '@ecom/auxo/es/components/radio/component/context';

export interface RadioCardProps {
  className?: string;
  value: string | number;
  disabled?: boolean;
  children?: React.ReactNode;
  checked?: boolean;
  onChange?: () => void;
}

export const RadioCard: FC<RadioCardProps> = ({
  disabled,
  className,
  value,
  children,
  checked: propsChecked,
  onChange: propsOnChange,
}) => {
  const ctx = useContext(RadioGroupContext);

  const checked = propsChecked || Boolean(ctx?.value === value);
  const onChange = propsOnChange || ctx?.onChange;

  const handleClick = (e: React.MouseEvent) => {
    onChange?.({
      target: {
        checked: true,
        value,
      },
      stopPropagation: e.stopPropagation,
      preventDefault: e.preventDefault,
      nativeEvent: e.nativeEvent,
    });
  };

  return (
    <Tooltip title={disabled ? '敬请期待' : ''}>
      <div
        className={classNames(
          'container flex cursor-pointer border-[1px] rounded-lg p-4 transition-colors border-[#e5e7eb]',
          {
            '!border-[#3b82f6]': checked,
            'bg-[#eff6ff]': checked,
            'cursor-not-allowed opacity-50': disabled,
            'bg-[#cfd0d3]': disabled,
          },
          className,
        )}
        onClick={handleClick}
      >
        {children || <Radio value={value} />}
      </div>
    </Tooltip>
  );
};
