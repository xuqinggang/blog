import Tea from 'byted-tea-sdk';

/** 页面title枚举值 */
export enum PageTitle {
  PROD_ANALYSIS = '货品分析',
  BIG_ACTIVITY_PROD_DETAIL = '大促商品可优化商品详情',
  PROD_DETAIL = '商品画像',
  PRICE_SKU = 'SKU价格力',
  PRICE_ORDER = '订单价格力',
  PRICE_SHOW = '曝光价格力',
  PROD_ALERT = '货盘监控首页',
  PROD_ALERT_DETAIL = '货盘监控商品明细',
  ATTRIBUTION = '大盘异动归因',
  GUESS_ATTRIBUTION = '猜喜异动归因',
  TREND_ANALYSIS = '趋势分析',
  FUNNEL_ANALYSIS = '漏斗分析',
  PROD_LIST = '商品榜单',
  DATA_SET = '数据集市',
  KS_INSIGHT = '拐点洞察',
  LOOK_LIKE = '寻找相似品',
  ACTIVITY_REVIEW = '活动复盘',

  /** 专项洞察--start  */
  PRICE_COMPARISON = '改价分析',
  VOLUME_PRICE = '量价模型',
  PRICE_TREND = '价格趋势洞察',
  /** 专项洞察--end  */

  GUESS_INSIGHT = '猜喜专项洞察',
  SKU_CLUSTER = 'SKU簇洞察',
  GREAT_VALUE_BUY = '超值购诊断',
  BIG_ACTIVITY = '大促诊断',

  PROD_REVIEW = '货盘复盘',
  PROD_REVIEW_STRATEGY = '货盘复盘-单策略报告页',
  PROD_REVIEW_AGGREGATE = '货盘复盘-业务专项报告页',
}

/** 嵌出模块的枚举值 */
export enum ModuleTitle {
  MULTI_DIM_ANALYSIS = '多维分析',
}

/** 通知内容点击类型 link-链接，img-图片 */
export enum NoticeClickType {
  LINK = 'link',
  IMG = 'img',
}

/**
 * 嵌出模块的PV上报
 * @param module 模块名称
 * @param source 宿主名称
 */
export const reportEmbedPageView = (module: ModuleTitle, source: string) => {
  console.log('reportEmbedPageView', module, source);
  Tea.event('embed_pageview', {
    module,
    source,
  });
};

/** PV上报 */
export const reportPageView = (title: PageTitle, from?: string | null, options?: any) => {
  (window as any).__PRODUCT_INSIGHTS_TITLE__ = title;
  console.log('~~~tea, reportPageView', title);
  Tea.event('predefine_pageview', {
    title,
    from,
    ...options,
  });
};

/** 核心结论复制图片点击 */
export const reportConclusionCopy = (title: PageTitle) => {
  Tea.event('conclusion_copy', {
    title,
  });
};

/** 核心结论有用点击 */
export const reportConclusionLike = (title: PageTitle) => {
  Tea.event('conclusion_like', {
    title,
  });
};

/** 核心结论没用点击 */
export const reportConclusionDislike = (title: PageTitle) => {
  Tea.event('conclusion_dislike', {
    title,
  });
};

/** 平台通知显示埋点 */
export const reportNoticeShow = (id: string, title: string) => {
  Tea.event('notice_show', {
    notice_id: id,
    notice_title: title,
  });
};

/** 平台通知关闭埋点 */
export const reportNoticeClose = (id: string, title: string) => {
  Tea.event('notice_close', {
    notice_id: id,
    notice_title: title,
  });
};

/** 平台通知内容点击埋点 */
export const reportNoticeClick = (id: string, title: string, type: NoticeClickType, content: string) => {
  Tea.event('notice_click', {
    notice_id: id,
    notice_title: title,
    click_type: type,
    click_content: content,
  });
};

/** 平台通知显示埋点 */
export const reportSearchActionClick = (title: string) => {
  Tea.event('diagnosis_action_click', {
    title,
  });
};
