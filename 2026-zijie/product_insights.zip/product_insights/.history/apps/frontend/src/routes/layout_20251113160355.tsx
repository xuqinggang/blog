import { useEffect } from 'react';
import dayjs from 'dayjs';
import advancedFormat from 'dayjs/plugin/advancedFormat';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import localeData from 'dayjs/plugin/localeData';
import weekday from 'dayjs/plugin/weekday';
import weekOfYear from 'dayjs/plugin/weekOfYear';
import weekYear from 'dayjs/plugin/weekYear';
import EventEmitter from 'eventemitter3';
import { observer } from 'mobx-react-lite';
import ReactDOM from 'react-dom';

import { ConfigProvider, Empty, message } from '@ecom/auxo';
import zhCN from '@ecom/auxo/es/components/locale/zh_CN';
import { ErrorBoundary } from '@ecom/mera';
import { Outlet, useLocation } from '@edenx/runtime/router';
import VChart from '@visactor/vchart';
import { chartHubLightTheme } from '@visactor/vchart-theme';

import { initFeelgood } from '@/components/feel-good';
import { mera } from '@/slardar';
import { noticeStore } from '@/store/notice';
import { initTea } from '@/tea';

import './index.less';
import '@ecom/auxo-pro-form/es/preset/import/package/v2Default';
import 'dayjs/locale/zh-cn';
import './lander-dependency';

// vchart配置charthub主题
VChart.ThemeManager.registerTheme('chart-hub-light', chartHubLightTheme);
VChart.ThemeManager.setCurrentTheme('chart-hub-light');

dayjs.extend(customParseFormat);
dayjs.extend(advancedFormat);
dayjs.extend(localeData);
dayjs.extend(weekOfYear);
dayjs.extend(weekYear);
dayjs.extend(weekday);
dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);
dayjs.locale('zh-cn');

console.log('xxxx000', ReactDOM);
message.config({ maxCount: 2 });

const GloablEventEmitter = new EventEmitter();
window.GloablEventEmitter = GloablEventEmitter;

initTea();

const Layout = observer(() => {
  const { setPathname } = noticeStore;
  const { pathname } = useLocation();

  useEffect(() => {
    setPathname(pathname);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  // 初始化FeelGood
  useEffect(() => {
    initFeelgood();
  }, []);

  return (
    <ErrorBoundary
      mera={mera}
      fallbackRender={e => {
        console.error('页面加载失败，请刷新重试', e.message);

        return (
          <div className="flex items-center justify-center h-full w-full">
            <Empty
              className="empty-img-emotion"
              style={{ margin: 0, width: '100%' }}
              backgroundImg="https://lf3-static.bytednsdoc.com/obj/eden-cn/vebh_tvjl/ljhwZthlaukjlkulzlp/Frame9.svg"
              description="页面加载失败，请刷新重试"
            />
          </div>
        );
      }}
    >
      <ConfigProvider locale={zhCN}>
        <Outlet />
      </ConfigProvider>
    </ErrorBoundary>
  );
});

export default Layout;
