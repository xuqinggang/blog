

const fs = require('fs');
const path = require('path');

const themeData = require('./theme.json');

const formatData = data => {
  if (data.type) {
    if (data.type === 'color') {
      return data.value;
    } else {
      return undefined;
    }
  } else {
    let obj = {};
    Object.entries(data).forEach(([key, value]) => {
      const formattedValue = formatData(value);
      if (formattedValue) {
        // 如果key以大写字母开头
        if (key[0] === key[0].toUpperCase()) {
          obj = {
            ...obj,
            ...formattedValue
          }
        } else {
          obj[key] = formattedValue;
        }
      }
    });
    return obj;
  }
};

console.log(`🦁 [vars] `, formatData(themeData));

const distFile = path.resolve(__dirname, '../config/tailwind-color.json');

fs.writeFileSync(distFile, JSON.stringify(formatData(themeData), null, 2));
