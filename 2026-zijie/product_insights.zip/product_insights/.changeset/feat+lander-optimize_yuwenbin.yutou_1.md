---
"@ecom/product-insights-components": major
---

范围输入框输出强制为字符串数组
