---
"@ecom/product-insights-components": patch
---

修改全部禁用问题
