import ReactDOM from 'react-dom';
import './index.css';
import { App } from './App';
const rootDOM = document.getElementById('root');

if (rootDOM) {
  ReactDOM.render(<App />, rootDOM);
}
