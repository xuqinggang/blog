// import Xxx from 'marketing-analyser/marketing-analyser';

export const App = () => (
  <div className="container-box">
    {/* <div className="landing-page">
      <Xxx
        schedules={[
          {
            scheduleName: '测试1',
            crowdPackageId: ['cond_un_22876940'],
            prodPackageId: ['7594833815919526150'],
            threshold: 1000,
            shopId: ['654321'],
            prodSetId: [],
          },
          {
            scheduleName: '测试2',
            crowdPackageId: ['cond_un_22876940'],
            prodSetId: ['7594833815919444230'],
            threshold: 2000,
            shopId: [],
            prodPackageId: [],
          },
          {
            scheduleName: '测试3',
            crowdPackageId: ['cond_un_22876940'],
            prodPackageId: [],
            threshold: 3000,
            shopId: ['123456'],
            prodSetId: [],
          },
          {
            scheduleName: '测试4',
            crowdPackageId: ['cond_un_22876940'],
            prodPackageId: ['10068122544'],
            threshold: 4000,
            shopId: [],
            prodSetId: [],
          },
        ]}
      />
    </div> */}
  </div>
);
