import { createVmokConfig } from '@edenx/plugin-vmok';

export default createVmokConfig({
  name: '@ecom-insight/vmok-test',
  remotes: {
    provider: {
      name: '@byted/basic-rslib-provider',
      // if the project is local , you can set local url like: http://localhost:3001/vmok-manifest.json
      devVersionOrUrl: '*',
      prodVersionOrUrl: '*',
    },
    'marketing-analyser': {
      name: '@ecom-insight/product',
      // if the project is local , you can set local url like: http://localhost:3001/vmok-manifest.json
      devVersionOrUrl: 'http://localhost:8081/vmok-manifest.json',
      prodVersionOrUrl: '*',
    },
  },
  shared: {
    react: {
      singleton: true,
    },
    'react-dom': {
      singleton: true,
    },
  },
  dts: {
    /**
     * disableGenerateLegacyTypes 和 disableConsumeLegacyTypes 必须显式配置
     *
     * 说明：Vmok 有两套类型生成方案，为了兼容之前的项目，会在未来一段时间处于共存状态。
     * 对于新创建的用户，推荐使用新的类型生成方案。
     *
     * @see {@link https://vmok.bytedance.net/guide/basic/type-prompt.html#%E8%83%8C%E6%99%AF} 详细说明
     */
    // disableConsumeLegacyTypes: true,
    // disableGenerateLegacyTypes: true,
  },
});
