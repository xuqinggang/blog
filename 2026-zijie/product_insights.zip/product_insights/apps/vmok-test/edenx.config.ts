import { appTools, defineConfig } from '@edenx/app-tools';
import pluginVmok from '@edenx/plugin-vmok';

// https://edenx.bytedance.net/configure/app/usage
export default defineConfig({
  //Currently not supoort use devtools and vmok at the same time
  devtools: false,
  plugins: [
    appTools({
      bundler: 'rspack', // Set to 'webpack' to enable webpack
    }),
    pluginVmok(),
  ],
});
