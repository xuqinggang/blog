/* eslint-disable @typescript-eslint/naming-convention */
import AntdDayjsWebpackPlugin from 'antd-dayjs-webpack-plugin';
import MonacoWebpackPlugin from 'monaco-editor-webpack-plugin';
import path from 'path';

import CoverageUploadPlugin from '@ecom/coverage-upload-plugin';
import { ecopPlugin } from '@ecop/edenx-plugin';
import { appTools, defineConfig } from '@edenx/app-tools';
import { garfishPlugin } from '@edenx/plugin-garfish';
import { tailwindcssPlugin } from '@edenx/plugin-tailwind';
import VmokPlugin from '@edenx/plugin-vmok';
import { Region, SlardarRdWebpackPlugin } from '@slardar/rd-webpack-plugin';

const {
  BUILD_TYPE,
  BUILD_REPO_BRANCH,
  BUILD_VERSION,
  CDN_OUTER_CN,
  CDN_PATH_PREFIX,
  NODE_ENV,
  BUILD_BASE_COMMIT_HASH,
} = process.env;

const isOffline = BUILD_TYPE === 'offline' || BUILD_TYPE === 'test'; // scm构建线下和测试版本
const isOnline = BUILD_TYPE === 'online'; // scm构建线上版本

// const coverageVariable = '__product_insight_coverage__';
// https://edenx.bytedance.net/configure/app/usage
export default defineConfig({
  runtime: {
    router: {
      basename: 'product_insight',
    },
  },
  source: {
    define: {
      'process.env.ENV': JSON.stringify(NODE_ENV),
      'process.env.NODE_ENV': JSON.stringify(NODE_ENV),
      'process.env.commitHash': JSON.stringify(BUILD_BASE_COMMIT_HASH),
      'process.env.BUILD_TYPE': JSON.stringify(BUILD_TYPE),
      'process.env.BUILD_REPO_BRANCH': JSON.stringify(BUILD_REPO_BRANCH),
      'process.env.CDN_OUTER_CN': JSON.stringify(CDN_OUTER_CN),
      'process.env.CDN_PATH_PREFIX': JSON.stringify(CDN_PATH_PREFIX),
      'process.env.BUILD_VERSION': JSON.stringify(BUILD_VERSION),
    },
  },
  output: {
    disableTsChecker: true,
    enableCssModuleTSDeclaration: true,
  },
  deploy: {
    microFrontend: true, // 需要配置
  },
  dev: {
    port: 8081,
    // PS: cloudide需要加上以下配置。
    client: {
      path: '/webpack-hmr',
      port: '8081',
      host: 'localhost',
      protocol: 'ws',
    },
  },
  tools: {
    babel: (_, { addPlugins }) => {
      if (isOffline) {
        addPlugins(['module:@ecom/babel-coverage-plugin']);
      }
    },
    rspack: config => {
      const alias = config.resolve.alias;
      if (alias) {
        alias['@ecom/product-insights-components'] = path.resolve(__dirname, '../../packages/components/src');
        alias['@ecom/product-insights-components/*'] = path.resolve(__dirname, '../../packages/components/src/*');
        alias['~'] = path.resolve(__dirname, '../../packages/components/src');
        alias['~/*'] = path.resolve(__dirname, '../../packages/components/src/*');
      }
      // console.log(`🦁 [>>>>] `, config.resolve.alias);
      config.plugins?.push(new AntdDayjsWebpackPlugin());
      config.plugins?.push(
        new MonacoWebpackPlugin({
          filename: 'worker/[name].work.js',
          languages: ['json', 'shell', 'java', 'go', 'python', 'javascript', 'php', 'cpp', 'sql', 'markdown'],
        }),
      );
      config.ignoreWarnings = [
        (warning: any) => {
          if (warning.message.includes('react-dom/client')) {
            return true;
          }
          return false;
        },
      ];
      if (isOffline) {
        config.plugins?.push(
          new CoverageUploadPlugin({
            gitRepo: 'ecom/product_insights', // 必填，代码库的gitRepo，例如ecom/huatuo-fe
            isDiffSend: true, // 可选，开启增量上报
            // coverageVariable,
            interval: 2000, // 可选，上报间隔，默认2s
            diffSendFileNum: 50, //  每次上报的文件数量，默认50
            retryLimit: 5, // 上报失败重试次数，默认5次,
          }),
        );
      }

      if (isOnline) {
        // 上传sourceMap到slardar
        config.plugins?.push(
          new SlardarRdWebpackPlugin({
            bid: 'product_insight',
            paths: [path.resolve(__dirname, 'dist')],
            release: process.env.BUILD_VERSION,
            batch: true,
            clear_after_upload: true,
            region: Region.cn, // Region.i18n, Region.ttp
          }),
        );
      }
    },
  },
  plugins: [
    appTools({
      bundler: 'rspack',
    }),
    tailwindcssPlugin(),
    garfishPlugin(),
    VmokPlugin(),
    ecopPlugin({
      //  橙蕉资源共享插件（无特殊情况需要接入）
      styled: { disabled: true },
    }),
  ],
});
