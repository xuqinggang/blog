import { sendEvent } from '@/slardar';
import { message } from '@ecom/auxo';
import { AxiosRequest as EcopAxiosRequest } from '@ecom/ecop-op-subsystem-sdk';
import { Iinterceptor } from '@ecom/ecop-op-subsystem-sdk/dist/tools/fetchApi';
import type { AxiosInstance } from 'axios';
import { emitInterfaceNoPermissionEvent } from './event';

const { requestBridge } = window.GarfishBridge ?? {};

const AxiosService = requestBridge?.AxiosRequest || EcopAxiosRequest;

// 自定义事件名称
const EventName = 'requestApiEvent';

interface RespExtra {
  current_env?: 'ppe' | 'boe' | 'prod';
}

export interface RequestResp {
  data?: any;
  st?: number;
  code?: number;
  msg: string;
  BaseResp?: {
    StatusCode?: number;
    StatusMessage?: string;
    Extra?: RespExtra;
  };
}

const defaultInterceptor: Iinterceptor = {
  success: resp => {
    const { data, config, headers, status } = resp;
    const { msg, code, BaseResp } = (data ?? {}) as RequestResp;

    // 构造slardar的自定义事件参数
    const customData = {
      name: EventName,
      categories: {
        status: status.toString(), // 状态码
        method: config?.method || '', // 请求方法
        requestUrl: config?.url || '', // 请求路径
        logId: headers?.['x-tt-logid'] || '', // logId
        code: (code || 0).toString(), // 错误码
        content: 'success', // 内容
        logLevel: 'info', // 日志级别
        env: BaseResp?.Extra?.current_env || 'prod', // 当前环境，默认是prod
      },
      metrics: { errorKeyCount: 0 },
    };

    if ((BaseResp && BaseResp?.StatusCode !== 0) || code) {
      // 上报自定义事件
      customData.categories.code = (BaseResp?.StatusCode || code || 0).toString();
      customData.categories.content = BaseResp?.StatusMessage || msg || '网络错误';
      customData.categories.logLevel = 'error';
      customData.metrics.errorKeyCount++;
      sendEvent(customData);

      if (BaseResp?.StatusMessage === '无该业务线数据权限') {
        emitInterfaceNoPermissionEvent();
      }
      // 错误透出、打印错误日志
      message.error(msg || BaseResp?.StatusMessage || '网络错误');
      return Promise.reject(
        new Error(JSON.stringify({ msg: msg || BaseResp?.StatusMessage || '网络错误', code: BaseResp?.StatusCode })),
      );
    }

    // 上报自定义事件
    sendEvent(customData);
    return Promise.resolve(data);
  },
  error: (err: any) => {
    const { response, config, message: msg } = err ?? {};
    const { BaseResp } = (response?.data ?? {}) as RequestResp;

    // 上报自定义事件
    const customData = {
      name: EventName,
      categories: {
        status: response?.status?.toString(), // 状态码
        method: config?.method || '', // 请求方法
        requestUrl: config?.url || '', // 请求路径
        logId: response?.headers?.['x-tt-logid'] || '', // logId,
        code: '0', // 错误码
        content: msg || '网络错误',
        logLevel: 'error',
        env: BaseResp?.Extra?.current_env || 'prod', // 当前环境，默认是prod
      },
      metrics: { errorKeyCount: 1 },
    };
    sendEvent(customData);

    // 错误透出、打印错误日志
    message.error(msg || '网络错误');
    return Promise.reject(err);
  },
};

const { axios } = new AxiosService({
  baseURL: '',
  interceptors: [defaultInterceptor],
  timeout: 0,
});

// axios.interceptors.request.use(
//   config => {
//     // const { headers } = config;
//     console.log('bbbbbb', config);
//     return config;
//   },
//   error => {
//     return Promise.reject(error);
//   },
// );

export default axios as AxiosInstance;
