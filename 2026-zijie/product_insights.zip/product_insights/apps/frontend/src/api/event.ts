import EventEmitter from 'eventemitter3';

// 接口报无权限事件
export const EVENT_INTERFACE_NO_PERMISSION = 'event_interface_no_permission';
export const interfaceEventEmitter = new EventEmitter();

export function emitInterfaceNoPermissionEvent() {
  interfaceEventEmitter.emit(EVENT_INTERFACE_NO_PERMISSION);
}
export function onInterfaceNoPermissionEvent(cb: () => void) {
  interfaceEventEmitter.on(EVENT_INTERFACE_NO_PERMISSION, cb);
}

// 归因树加载完成事件
export const DIAGNOSIS_TREE_LOADED = 'diagnosis_tree_loaded';
export const diagnosisTreeEventEmitter = new EventEmitter();

export function emitDiagnosisTreeLoadedEvent() {
  diagnosisTreeEventEmitter.emit(DIAGNOSIS_TREE_LOADED);
}
export function onDiagnosisTreeLoadedEvent(cb: () => void) {
  diagnosisTreeEventEmitter.on(DIAGNOSIS_TREE_LOADED, cb);
}
