import Mera, { TMera } from '@ecom/mera';
import { heatmap } from '@slardar/integrations/dist/heatmap';
import browserClient from '@slardar/web';
const MeraPlugin = Mera({
  release: process.env.BUILD_VERSION,
});

const userInfo = window.GarfishBridge?.infoBridge?.getUserInfo();

/** 全局上下文配置，需要在init之前配置：https://bytedance.larkoffice.com/wiki/wikcnO1yz6ccHFHFp7Eg8aBfn2d */
browserClient('context.set', 'userInfo', userInfo);

browserClient('init', {
  // ...
  bid: 'product_insight',
  env: process.env.NODE_ENV === 'production' ? 'prod' : 'dev',
  pid: window.location.pathname,
  userId: userInfo?.email, // 使用用户邮箱作为用户唯一标识
  release: process.env.BUILD_VERSION,
  integrations: [MeraPlugin, heatmap({ trackRootScroll: false })],
  plugins: {
    action: {
      pure: true,
    },
  },
});

browserClient('start');

// 获取mera实例
// @ts-ignore global
export const mera = (browserClient.___MERA__ || browserClient.getMera()) as TMera;

// 获取slardar实例
export const { slardar } = mera;

export interface CustomEventPayload {
  /** 自定义事件名称 */
  name: string;
  /** metrics 上报的是可以被度量的值，也就是数值 */
  metrics?: { [key: string]: number };
  /** categories 上报的是分类，维度，用来做筛选，分组 */
  categories?: { [key: string]: string };
}

export interface CustomLogPayload {
  /** 额外的附加信息， 在上报的时候 number会被分流到metric string会被分流到categories */
  extra?: { [key: string]: string | number }; //
  /** 自定义事件内容，任意字符串，可以是日志或者对象的 JSON 字符串等等 */
  content: string;
  /** 自定义事件级别，默认是 info, 可枚举项 debug | info | warn | error */
  level?: 'debug' | 'info' | 'warn' | 'error';
}

/**
 * 上报一个自定义事件
 * @param customData 自定义事件数据
 */
export function sendEvent(customData: CustomEventPayload) {
  slardar.sendEvent?.(customData);
}

/**
 * 上报一个自定义日志
 * @param customLog 自定义日志数据
 */
export function sendLog(customLog: CustomLogPayload) {
  slardar.sendLog?.(customLog);
}

/**
 * 上报一个异常
 * @param err 异常
 * @param extra 额外信息
 */
export function sendError(err: Error | unknown, extra?: Record<string, string>) {
  slardar.captureException?.(err, extra);
}
