import { TargetBasicInfo, TargetCardEntity } from '@/api/product/namespaces/analysis';
import { accurateRatio, accurateRatioUsePP, errorRatio } from '@/utils/formatter/number';

export const formatTargetData = (
  target: TargetCardEntity | TargetBasicInfo,
  options: { ifPositiveSymbol?: boolean } = { ifPositiveSymbol: true },
) => {
  const { cycle_change_ratio } = target;
  const { ifPositiveSymbol = true } = options || {};

  const ratioData = Number(cycle_change_ratio ?? 0);

  const isIncrease = 'extra' in target && !target.extra?.is_larger_advantage ? ratioData < 0 : ratioData > 0; // 是否正向

  const ratioWithUnit = errorRatio(ratioData)
    ? '-'
    : `${ratioData >= 0 && ifPositiveSymbol ? '+' : ''}${
        'is_use_pp' in target && target.is_use_pp ? accurateRatioUsePP(ratioData, 1) : accurateRatio(ratioData, 1)
      }`;

  const noChange = ratioData === 0;

  return {
    ...target,
    isIncrease,
    ratioWithUnit,
    noChange,
    isError: errorRatio(cycle_change_ratio),
  };
};
