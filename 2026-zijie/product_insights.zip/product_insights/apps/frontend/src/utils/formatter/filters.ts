import { groupBy, omit } from 'lodash-es';

import {
  DimensionAttributeType,
  EnumElement,
  ProductAnalysisBaseStruct,
  SelectedDimensionInfo,
  ThresholdAttr,
} from '@/api/product/namespaces/dimensions';
import {
  AnalysisFilter,
  AnalysisServerFilter,
  CommonFilter,
  CommonServerFilter,
  DimensionMap,
  PriceFilter,
  PriceServerFilter,
} from '@/components/dimension-filter/types';
import { DIM_GROUPS } from '@/components/dimension-filter/utils/constant';
import {
  transformGroupAttrs2Filter,
  transformGroupAttrs2Server,
  transformRule2SelectDim,
} from '@/components/dimension-filter/utils/transform';
import { SelectType } from '@/components/RuleSelect';
import { BaseStruct } from '@/types';

export const formatDimValue = (value: EnumElement[], type?: SelectType) => {
  const [firstV = {}] = value;
  const { type_value } = firstV;
  const isTypeValue = Boolean(type_value?.length);
  return {
    op_type: isTypeValue ? type : undefined,
    selected_values: isTypeValue ? value[0].type_value : value.map(({ code }) => code || ''),
    selected_option: value,
  };
};

export function batchFormatDimensions(data: CommonFilter) {
  return DIM_GROUPS.reduce<SelectedDimensionInfo[]>((prev, curr) => {
    const { key, attrType } = curr;
    return prev.concat(data[key]?.map(i => transformRule2SelectDim(i, attrType)) ?? []);
  }, []);
}

export function formatDimensionsFromServer(dimensions?: Array<SelectedDimensionInfo & { op_type?: SelectType }>) {
  const dimMap = groupBy(
    dimensions?.map(i => ({
      ...i,
      ...formatDimValue(i.selected_values ?? [], i.op_type),
    })),
    'attr_type',
  );

  return {
    user_dimensions: dimMap[DimensionAttributeType.User] ?? [],
    product_dimensions: dimMap[DimensionAttributeType.Product] ?? [],
    place_dimensions: dimMap[DimensionAttributeType.Place] ?? [],
    order_dimensions: dimMap[DimensionAttributeType.Order] ?? [],
  } as DimensionMap;
}

export function formatFilterToServer(data: CommonFilter, isProdAnalysis: boolean): CommonServerFilter {
  const { user_dimensions, product_dimensions, place_dimensions, order_dimensions, group_attrs, ...otherFilter } = data;
  const groupAttrs = transformGroupAttrs2Server(group_attrs);
  const dimensions = batchFormatDimensions(data);

  if (isProdAnalysis) {
    // 商品分析
    const result = {
      ...omit(otherFilter, ['threshold_type', 'analysis_date_type', 'compare_date_type']),
      start_date: data.start_date ?? '',
      end_date: data.end_date ?? '',
      compare_start_date: (data as AnalysisFilter).compare_start_date ?? '',
      compare_end_date: (data as AnalysisFilter).compare_end_date ?? '',
      dimensions,
    } as AnalysisServerFilter;

    if (groupAttrs) {
      result.group_attrs = groupAttrs;
    }

    return result;
  }

  const result = {
    ...otherFilter,
    dimensions,
  } as PriceServerFilter;

  if (groupAttrs) {
    result.group_attrs = groupAttrs;
  }

  return result;
}

export function formatFilterFromServer(data: Partial<BaseStruct>, isProdAnalysis: boolean): CommonFilter {
  const { dimensions, group_attrs, ...otherFilter } = data;
  const groupAttrs = transformGroupAttrs2Filter(group_attrs, dimensions);
  const dimensionsData = formatDimensionsFromServer(dimensions);

  if (isProdAnalysis) {
    // 商品分析
    const { threshold_attrs, ...other } = otherFilter as Partial<
      Omit<ProductAnalysisBaseStruct, 'dimensions' | 'group_attrs'>
    >;
    const threshold = threshold_attrs?.length
      ? { threshold_type: threshold_attrs?.[0]?.type ?? 0, threshold_attrs }
      : { threshold_type: 2, threshold_attrs: [{ key: 'pay_ord_cnt' }] as ThresholdAttr[] };

    return {
      ...dimensionsData,
      ...threshold,
      ...omit(other, ['biz_type']),
      group_attrs: groupAttrs,
    } as AnalysisFilter;
  }

  // 价格力
  return {
    ...dimensionsData,
    ...omit(otherFilter, ['biz_type']),
    group_attrs: groupAttrs,
  } as PriceFilter;
}
