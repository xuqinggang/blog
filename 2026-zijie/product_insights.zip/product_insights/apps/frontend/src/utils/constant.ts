/** 单维度最小枚举值数目 */
export const MIN_SINGLE_DIMENSION_ENUM_COUNT = 1;

/** 单维度最大的枚举值数目 */
export const MAX_SINGLE_DIMENSION_ENUM_COUNT = 200;

/** 筛选区每页搜索的枚举值数目 */
export const ENUM_LIST_PAGE_SIZE = 10;

export const ServerRange = ['NEGATIVE_INFINITY', 'POSITIVE_INFINITY'];

// 模块缓存key（趋势分析、漏斗分析、商品榜单）
export const INSIGHT_CACHE_MODULE_KEY = 'INSIGHT_CACHE_MODULE';

/** 关闭掉的通知列表缓存key */
export const INSIGHT_CACHE_CLOSE_NOTICE = 'INSIGHT_CACHE_CLOSE_NOTICE';
