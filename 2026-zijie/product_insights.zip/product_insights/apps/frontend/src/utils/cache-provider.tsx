import { createContext, FC, useCallback, useContext, useMemo } from 'react';
import { noop } from 'lodash-es';

interface CacheCtx {
  getCache: <T>(key: string, initializer?: () => Promise<T>) => Promise<T | null>;
  clearCache: (key?: string) => void;
}
export const cacheCtx = createContext<CacheCtx>({
  getCache: async () => {
    return null;
  },
  clearCache: noop,
});

export const CacheProvider: FC = ({ children }) => {
  const cacheMap = useMemo(() => new Map<string, Promise<unknown>>(), []);

  const getCache = useCallback(
    async (key: string, initializer?: () => Promise<unknown>) => {
      try {
        if (cacheMap.has(key)) {
          console.log(`[CACHE] ✅✅✅ target cache for ${key} `);
          return await cacheMap.get(key);
        }
        if (initializer) {
          console.log(`[CACHE] 🌀🌀🌀 get cache ${key} running initializer`);
          const requestPmz = initializer();
          requestPmz.catch(err => {
            console.log(`[CACHE] 🛑🛑🛑 initializer error ${key}`, err);
            cacheMap.delete(key);
          });
          cacheMap.set(key, requestPmz);
          return await requestPmz;
        }
      } catch (err) {
        return null;
      }
    },
    [cacheMap],
  );

  const clearCache = useCallback(
    (key?: string) => {
      if (key) {
        cacheMap.delete(key);
        console.log(`[CACHE] 🧹🧹🧹 clear cache key ${key}`);
      } else {
        console.log(`[CACHE] 🗑️🗑️🗑️ clear all cache`);
        cacheMap.clear();
      }
    },
    [cacheMap],
  );

  const ctxVal = useMemo(
    () => ({
      getCache,
      clearCache,
    }),
    [clearCache, getCache],
  );
  return <cacheCtx.Provider value={ctxVal}>{children}</cacheCtx.Provider>;
};

export const useCacheCtx = () => useContext(cacheCtx);
