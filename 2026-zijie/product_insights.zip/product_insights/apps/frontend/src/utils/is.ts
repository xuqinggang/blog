import dayjs from 'dayjs';
import { isEmpty, isEqual, sortBy } from 'lodash-es';

import { DateType } from '@/api/product/namespaces/base';
import { BizType, DataReadyTime } from '@/api/product/namespaces/dimensions';

export function isPriceTrend(bizType: BizType) {
  return bizType === BizType.PriceTrendOrder || bizType === BizType.PriceTrendShow || bizType === BizType.PriceTrendSku;
}

export function isPriceCompare(bizType: BizType) {
  return bizType === BizType.PriceAACompare;
}

export function isNullOrUndefined(value: unknown): value is null | undefined {
  return value === undefined || value === null;
}

export function isArrayEqual(a: string[], b: string[]) {
  return isEqual(sortBy(a), sortBy(b));
}

export function isValidTime(readyTime: DataReadyTime, startDate?: string, endDate?: string) {
  if (!startDate || !endDate) {
    return true;
  }

  const { oldest_partition, newest_partition, date_range_info, max_date_range } = readyTime;
  const maxDateRange = max_date_range ?? date_range_info?.find(i => i.date_type === DateType.DAY)?.max_date_range;
  const start = dayjs(startDate).startOf('day');
  const end = dayjs(endDate).endOf('day');
  const oldest = dayjs(oldest_partition).startOf('day');
  const newest = dayjs(newest_partition).endOf('day');

  return (
    start.isBefore(end) &&
    (maxDateRange ? end.isSameOrBefore(start.add(Number(maxDateRange), 'day')) : true) &&
    start.isSameOrAfter(oldest) &&
    end.isSameOrBefore(newest)
  );
}

export function isRecursiveEmpty(obj: Record<string, any>): boolean {
  if (isEmpty(obj)) {
    return true;
  }

  return Object.values(obj).every(i => {
    if (typeof i === 'object') {
      return isRecursiveEmpty(i);
    } else {
      return isEmpty(i);
    }
  });
}
