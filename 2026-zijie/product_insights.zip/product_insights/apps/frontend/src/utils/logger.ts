import { prettyDebug, prettyError, prettyLog, prettyWarn } from '@ecom/product-insights-components';

import { sendLog } from '@/slardar';

const debug = (...content: any[]) => {
  prettyDebug('DEBUG', ...content);
};

const info = (...content: any[]) => {
  prettyLog('INFO', ...content);

  sendLog({
    content: content.join(' '),
    level: 'info',
  });
};
const warn = (...content: any[]) => {
  prettyWarn('WARN', ...content);

  sendLog({
    content: content.join(' '),
    level: 'warn',
  });
};
const error = (...content: any[]) => {
  prettyError('ERROR', ...content);

  sendLog({
    content: content.join(' '),
    level: 'error',
  });
};
export const Logger = {
  debug,
  info,
  warn,
  error,
};
