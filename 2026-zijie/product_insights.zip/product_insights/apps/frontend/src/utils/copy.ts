import { message } from '@ecom/auxo';

export const copyToClipboard = (text: string | number) => {
  navigator.clipboard.writeText(String(text)).then(() => {
    message.success('复制成功');
  });
};
