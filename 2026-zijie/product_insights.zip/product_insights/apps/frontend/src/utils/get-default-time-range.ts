import { Dayjs } from 'dayjs';

export const getDefaultTimeRange = (timeRange: false | Dayjs[] = false, step = 1) => {
  if (!timeRange || timeRange.length !== 2) {
    return undefined;
  }

  const [sT, eT] = timeRange;
  const maxRange = Math.floor(eT.diff(sT, 'day') / 2);
  const range = step > maxRange ? maxRange : step;

  const endDate = eT;
  const startDate = eT.subtract(range, 'day');

  const compareEndDate = startDate.subtract(1, 'day');
  const compareStartDate = compareEndDate.subtract(range, 'day');

  return {
    start_date: startDate.format('YYYY-MM-DD'),
    end_date: endDate.format('YYYY-MM-DD'),
    compare_start_date: compareStartDate.format('YYYY-MM-DD'),
    compare_end_date: compareEndDate.format('YYYY-MM-DD'),
  };
};
