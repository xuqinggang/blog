import { DataInfo } from '@/api/product/namespaces/ai_analysis';
import {
  GetProductAnalysisMultiDimFullListData,
  MultiDimFullListRow,
  TargetCardEntity,
} from '@/api/product/namespaces/analysis';
import { LogicalExprType } from '@/api/product/namespaces/base';
import {
  BizType,
  DimensionInfo,
  GetProductAnalysisBizInfo,
  ProductAnalysisBaseStruct,
  SelectedDimensionInfo,
  SelectedMultiDimensionInfo,
  TargetMetaInfo,
  ThresholdAttr,
  ThresholdType,
} from '@/api/product/namespaces/dimensions';
import { OperatorList } from '@/components/RuleSelect';

import { uniqDimensions } from './formatter/dimension';
import { accurateRatio } from './formatter/number';
import { isNullOrUndefined } from './is';

/** 通用筛选项类型定义 */
interface CommonBaseStruct {
  /** 业务线类型 */
  biz_type: BizType;
  /** 分析周期起始时间，格式为 YYYY-MM-DD */
  start_date: string;
  /** 分析周期结束时间，格式为 YYYY-MM-DD */
  end_date: string;
  /** 对比周期起始时间，格式为 YYYY-MM-DD */
  compare_start_date: string;
  /** 对比周期结束时间，格式为 YYYY-MM-DD */
  compare_end_date: string;
  /** 筛选的维度列表 */
  dimensions?: Array<SelectedDimensionInfo>;
  /** 指标阈值筛选逻辑关系 */
  threshold_expr?: LogicalExprType;
  /** 指标阈值筛选 */
  threshold_attrs?: Array<ThresholdAttr>;
  /** 下钻的维度列表 */
  group_attrs?: Array<SelectedMultiDimensionInfo>;
}

/**
 * 将筛选条件转换为Markdown格式字符串
 * @param data 筛选条件数据
 * @param selectedBiz 选中的业务线
 * @returns Markdown格式字符串
 */
export function getBaseStructMarkdown(
  data: CommonBaseStruct,
  selectedBiz?: GetProductAnalysisBizInfo | null,
  targetList?: TargetMetaInfo[] | null,
  dimensionInfos?: DimensionInfo[] | null,
): string {
  const lines: string[] = [];

  // 业务线类型
  let bizName = selectedBiz?.biz_name || String(data.biz_type);
  if (String(data.biz_type).startsWith('40')) {
    // 大盘异动归因，将异动归因替换为大盘
    bizName = bizName.replace('异动归因', '大盘');
  }

  if (data.biz_type === BizType.AttributionCoreGuess) {
    bizName = '猜喜';
  }

  lines.push(`**业务线类型**：${bizName}`);

  // 分析周期
  lines.push(`**分析周期**：${data.start_date}至${data.end_date}`);

  // 对比周期
  lines.push(`**对比周期**：${data.compare_start_date}至${data.compare_end_date}`);

  // 筛选维度（如果有数据）
  const validDimensions = uniqDimensions(
    data.dimensions?.filter(dim => dim.selected_values && dim.selected_values.length > 0) ?? [],
  );
  if (validDimensions && validDimensions.length > 0) {
    lines.push('**筛选维度**：');
    validDimensions.forEach(dim => {
      const selectedValues = dim
        .selected_values!.map(i => {
          if (i.type_value) {
            // 针对xxID类型的维度进行特化处理
            return i.type_value.join('、');
          }

          return i.name || '';
        })
        .filter(Boolean) as string[];
      let dimName = dim.name;
      if (!dimName) {
        dimName = dimensionInfos?.find(j => j.id === dim.id)?.show_name;
      }
      if (selectedValues.length > 10) {
        // 处理超过10个值的情况
        lines.push(`- 【${dimName}】：${selectedValues.slice(0, 10).join('、')}等`);
      } else {
        lines.push(`- 【${dimName}】：${selectedValues.join('、')}`);
      }
    });
    // 添加两个换行符
    lines.push('');
  }

  // 下钻维度（如果有数据）
  if (data.group_attrs && data.group_attrs.length > 0) {
    lines.push('**下钻维度**：');
    data.group_attrs.forEach(attr => {
      const valueText = attr.value?.name || '';
      let dimName = attr.dim_info.name;
      if (!dimName) {
        dimName = dimensionInfos?.find(j => j.id === attr.dim_info.id)?.show_name;
      }
      if (valueText) {
        lines.push(`- 【${dimName}】：${valueText}`);
      } else {
        lines.push(`- 【${dimName}】`);
      }
    });
    // 添加两个换行符
    lines.push('');
  }

  // 指标阈值筛选（如果有数据）
  if (data.threshold_attrs && data.threshold_attrs.length > 0) {
    lines.push('**指标阈值筛选**：');
    data.threshold_attrs.forEach(attr => {
      const targetName = targetList?.find(i => i.name === attr.key)?.display_name;
      let thresholdText = '';
      switch (attr.type) {
        case ThresholdType.TOP_THRESHOLD:
          thresholdText = `Top${attr.top_n}`;
          break;
        case ThresholdType.CONTRIBUTION_THRESHOLD:
          thresholdText = `贡献度 top ${attr.top_n}%`;
          break;
        case ThresholdType.ACC_THRESHOLD:
          if (attr.acc_threshold?.operator && attr.acc_threshold?.threshold) {
            thresholdText = `精准阈值 ${
              OperatorList.find(i => i.value === attr.acc_threshold?.operator)?.label || ''
            } ${attr.acc_threshold?.threshold}`;
          }
          break;
        default:
          break;
      }

      if (targetName && thresholdText) {
        lines.push(`- 【${targetName}】：${thresholdText}`);
      }
    });
    // 添加两个换行符
    lines.push('');
  }

  // 指标阈值筛选逻辑关系
  if (data.threshold_expr) {
    lines.push(`**指标阈值筛选逻辑关系**：${data.threshold_expr === LogicalExprType.OR ? '或' : '且'}`);
  }

  return lines.join('\n');
}

// 处理多维度下钻行数据，将其转换为二维数组
function processMultiDimRows(
  rows: MultiDimFullListRow[],
  maxDepth: number,
  parentDims: string[] = [],
): { analysisRows: string[][]; compareRows: string[][] } {
  const analysisRows: string[][] = [];
  const compareRows: string[][] = [];

  for (let i = 0; i < rows.length; i++) {
    if (i > 20) {
      // 最多只处理20行数据
      break;
    }

    const row = rows[i];

    // 添加维度名称
    let dimDisplayName = '整体';
    if (row.enum_value && row.enum_value !== '不被匹配的整体') {
      dimDisplayName = row.enum_value;
    }
    const currentDims = [...parentDims, dimDisplayName];

    // 创建填充后的维度数组
    const paddedDims: string[] = new Array(maxDepth).fill('整体');
    currentDims.forEach((dim, index) => {
      if (index < maxDepth) {
        paddedDims[index] = dim;
      }
    });

    const analysisRow: string[] = [];
    const compareRow: string[] = [];

    // 添加填充后的维度
    analysisRow.push(...paddedDims);
    compareRow.push(...paddedDims);

    // 添加指标值
    if (row.target_list && row.target_list.length > 0) {
      for (const target of row.target_list) {
        // 分析周期
        analysisRow.push(isNullOrUndefined(target.value) ? '-' : String(target.value));
        // 对比周期
        compareRow.push(isNullOrUndefined(target.cycle_value) ? '-' : String(target.cycle_value));
      }
    }

    analysisRows.push(analysisRow);
    compareRows.push(compareRow);

    // 递归处理子行
    if (row.children && row.children.length > 0) {
      const { analysisRows: childAnalysisRows, compareRows: childCompareRows } = processMultiDimRows(
        row.children,
        maxDepth,
        currentDims,
      );
      analysisRows.push(...childAnalysisRows);
      compareRows.push(...childCompareRows);
    }
  }

  return { analysisRows, compareRows };
}

/**
 * 多维分析数据转换为DataInfo数组
 * @param inData 多维分析数据
 * @returns DataInfo数组
 */
export function convertMultiDimToDataInfo(
  inData: GetProductAnalysisMultiDimFullListData,
  baseStruct: ProductAnalysisBaseStruct,
  needDiff = false,
): DataInfo[] {
  const analysisRows: string[][] = [];
  const compareRows: string[][] = [];

  // 标题行
  const titleRow: string[] = [];
  const dimNames: string[] = [];

  let maxDepth = 0;

  if (baseStruct.group_attrs && baseStruct.group_attrs.length > 0) {
    maxDepth = baseStruct.group_attrs.length;
    for (let i = 0; i < baseStruct.group_attrs.length; i++) {
      const dim = baseStruct.group_attrs[i];
      dimNames.push(dim.dim_info.name || `维度${i + 1}`);
      titleRow.push(dim.dim_info.name || `维度${i + 1}`);
    }
  }

  // 处理整体数据
  if (inData.total) {
    // 补充标题行指标部分
    if (inData.total.target_list && inData.total.target_list.length > 0) {
      for (const target of inData.total.target_list) {
        titleRow.push(`${target.display_name}（${target.name}）`);
      }
    }

    analysisRows.push(titleRow);
    compareRows.push(titleRow);

    const { analysisRows: analysisTotalRows, compareRows: compareTotalRows } = processMultiDimRows(
      [inData.total],
      maxDepth,
      [],
    );

    analysisRows.push(...analysisTotalRows);
    compareRows.push(...compareTotalRows);
  }

  // 处理维度数据
  if (inData.full_list && inData.full_list.length > 0) {
    const { analysisRows: analysisDimRows, compareRows: compareDimRows } = processMultiDimRows(
      inData.full_list,
      maxDepth,
      [],
    );

    analysisRows.push(...analysisDimRows);
    compareRows.push(...compareDimRows);
  }

  if (needDiff) {
    return [
      {
        description: `按照${dimNames.join('、')}多维度下钻分析周期数据（${baseStruct.start_date}至${
          baseStruct.end_date
        }）`,
        data: analysisRows,
      },
      {
        description: `按照${dimNames.join('、')}多维度下钻对比周期数据（${baseStruct.compare_start_date}至${
          baseStruct.compare_end_date
        }）`,
        data: compareRows,
      },
    ];
  }

  return [
    {
      description: `按照${dimNames.join('、')}多维度下钻分析周期数据（${baseStruct.start_date}至${
        baseStruct.end_date
      }）`,
      data: analysisRows,
    },
  ];
}

/**
 * 将TargetCardEntity列表转换为二维数组
 * @param targetList 指标列表
 * @returns string[][] 二维数组，包含表头和数据行
 */
export function convertTargetListToArray(targetList: TargetCardEntity[]): string[][] {
  // 表头行
  const headerRow = ['指标名称', '分析周期值', '对比周期值', '变化率'];

  // 数据行生成
  const dataRows = targetList.map(target => {
    // 指标名称
    const name = `${target.display_name}（${target.name}）`;
    // 分析周期原始值（取value字段）
    const currentValue = target.value !== undefined ? target.value.toString() : '-';
    // 对比周期原始值（取cycle_value字段）
    const compareValue = target.cycle_value !== undefined ? target.cycle_value.toString() : '-';
    // 变化率（使用accurateRatio格式化）
    const ratio = accurateRatio(target.cycle_change_ratio, 2, { useSymbol: true });

    return [name, currentValue, compareValue, ratio];
  });

  // 返回二维数组，第一行是表头
  return [headerRow, ...dataRows];
}
