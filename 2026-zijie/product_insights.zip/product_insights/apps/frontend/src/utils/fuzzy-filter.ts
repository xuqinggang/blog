import { FilterOptions, MatchOptions } from 'fuzzy';

export interface MatchObj {
  text: string;
  matched?: boolean;
}

export const fuzzyMatch = (pattern: string, str: string, opts: Omit<MatchOptions, 'pre' | 'post'> = {}) => {
  let patternIdx = 0;
  const result: MatchObj[] = [];
  const len = str.length;
  let totalScore = 0;
  let currScore = 0;
  // raw string
  const compareString = (opts.caseSensitive && str) || str.toLowerCase();

  pattern = (opts.caseSensitive && pattern) || pattern.toLowerCase();

  // For each character in the string, either add it to the result
  // or wrap in template if it's the next string in the pattern
  for (let idx = 0; idx < len; idx++) {
    const ch: MatchObj = {
      text: str[idx],
      matched: false,
    };
    if (compareString[idx] === pattern[patternIdx]) {
      ch.matched = true;
      patternIdx += 1;

      // consecutive characters should increase the score more than linearly
      currScore += 1 + currScore;
    } else {
      currScore = 0;
    }
    totalScore += currScore;
    result[result.length] = ch;
  }

  // return rendered string if we have a match for every char
  if (patternIdx === pattern.length) {
    // if the string is an exact match with pattern, totalScore should be maxed
    totalScore = compareString === pattern ? Infinity : totalScore;
    return { rendered: result, score: totalScore };
  }

  return null;
};

interface FilterObj<T> {
  texts: MatchObj[];
  score: number;
  index: number;
  original: T;
}

export const fuzzyFilter = <T>(pattern: string, arr: T[], opts: Omit<FilterOptions<T>, 'pre' | 'post'> = {}) => {
  if (!arr || arr.length === 0) {
    return [];
  }
  // if (typeof pattern !== 'string') {
  //   return arr;
  // }
  opts = opts || {};
  return (
    arr
      .reduce<FilterObj<T>[]>(function (prev, element, idx) {
        const str = String(opts?.extract ? opts.extract(element) : element);

        const rendered = fuzzyMatch(pattern, str);
        if (rendered != null) {
          prev[prev.length] = {
            texts: rendered.rendered,
            score: rendered.score,
            index: idx,
            original: element,
          };
        }
        return prev;
      }, [])

      // Sort by score. Browsers are inconsistent wrt stable/unstable
      // sorting, so force stable by using the index in the case of tie.
      // See http://ofb.net/~sethml/is-sort-stable.html
      .sort(function (a, b) {
        const compare = b.score - a.score;
        if (compare) return compare;
        return a.index - b.index;
      })
  );
};
