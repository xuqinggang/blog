import CryptoJS from 'crypto-js';

const desKey = CryptoJS.enc.Utf8.parse('12345678'); // DES 使用 8 字节的密钥
const desIv = CryptoJS.enc.Utf8.parse('87654321'); // DES-CBC 模式需要 8 字节的 IV

/**
 * DES CBC加密方法
 * @param data 原始信息
 * @returns 加密后的信息
 */
export function encryptDES(data: string) {
  const encrypted = CryptoJS.DES.encrypt(data, desKey, {
    iv: desIv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  return encrypted.toString();
}

/**
 * DES CBC解密方法
 * @param data 加密后的信息
 * @returns 解密后的信息
 */
export function decryptDES(encrypted: string) {
  const decrypted = CryptoJS.DES.decrypt(encrypted, desKey, {
    iv: desIv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  return decrypted.toString(CryptoJS.enc.Utf8);
}

// 密钥
const aesKey = CryptoJS.enc.Utf8.parse('1234567812345678'); // AES-128 需要 16 字节的密钥
// 初始化向量 (IV)
const aesIv = CryptoJS.enc.Utf8.parse('8765432187654321'); // IV 也是 16 字节

/**
 * AES CBC加密方法
 * @param data 原始信息
 * @returns 加密后的信息
 */
export function encryptAES(data: string) {
  const message = CryptoJS.enc.Utf8.parse(data);
  const encrypted = CryptoJS.AES.encrypt(message, aesKey, {
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
    iv: aesIv,
  }).toString();

  return encodeURIComponent(encrypted);
}

/**
 * AES CBC解密方法
 * @param data 加密后的信息
 * @returns 解密后的信息
 */
export function decryptAES(encrypted: string) {
  const decrypted = CryptoJS.AES.decrypt(decodeURIComponent(encrypted), aesKey, {
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
    iv: aesIv,
  }).toString(CryptoJS.enc.Utf8);

  return decrypted;
}
