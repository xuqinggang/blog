import queryString from 'query-string';

import { ProdDetailBaseRequest } from '@/api/product/namespaces/price_analysis';
import { Scope } from '@/routes/product_detail/types';

export const openProductPage = (id?: string) => {
  if (!id) return;
  window.GarfishBridge?.actionBridge?.openInsideTag(
    `//ecop.bytedance.net/operation-crm-product/product-info/detail?cjSiteCode=St12306080000001&productId=${id}`,
  );
};

export const openShopPage = (id?: string) => {
  if (!id) return;
  window.GarfishBridge?.actionBridge?.openInsideTag(
    `//ecop.bytedance.net/businessManage/panorama?activeKey=shopIndex&cjSiteCode=St12306080000001&id=${id}`,
  );
};

export const openProductDetailPage = (params: {
  base_req?: Partial<Pick<ProdDetailBaseRequest, 'req_marshal' | 'router' | 'code'>> & { res_id?: string };
  scope?: Scope;
}) => {
  const { base_req, scope = {} } = params;

  if (!base_req) return;

  const baseReqJson = encodeURIComponent(JSON.stringify(base_req));
  const scopeJSON = encodeURIComponent(JSON.stringify(scope));

  let path = '/product_insight/product_detail';
  if (scope?.biz_from === 'product_incubation') {
    path = '/product_insight/product_detail_for_product_incubation';
  }

  window.top?.GarfishBridge?.actionBridge?.openInsideTag(`${path}?base_req=${baseReqJson}&scope=${scopeJSON}`);
};

export const openInsidePage = (params: { res_id?: string; pathname: string }) => {
  const { res_id, pathname } = params;

  window.GarfishBridge?.actionBridge?.openInsideTag(`${pathname}?cjSiteCode=St12403140000002&res_id=${res_id}`);
};

export const openAnalysisPalletRule = (params: { pool_id: string }, isRefresh?: boolean, useBrowser?: boolean) => {
  const path = '/dikar-platform/analysis-pallet/rule';
  const { origin } = window.location;
  const baseUrl = `${path}?${queryString.stringify({
    ...(params || {}),
  })}`;
  if (useBrowser) {
    window.open(`${origin}${baseUrl}`, '_blank');
    return;
  }
  window.GarfishBridge?.actionBridge?.openInsideTag(baseUrl, '监控规则', isRefresh);
};

export const openAnalysisPalletDetail = (params: { pool_id: string }, isRefresh?: boolean, useBrowser?: boolean) => {
  const path = '/dikar-platform/analysis-pallet/prods';
  const { origin } = window.location;
  const baseUrl = `${path}?${queryString.stringify({
    ...(params || {}),
  })}`;
  if (useBrowser) {
    window.open(`${origin}${baseUrl}`, '_blank');
    return;
  }
  window.GarfishBridge?.actionBridge?.openInsideTag(baseUrl, '商品明细', isRefresh);
};

export const openAnalysisPallet = (params: Record<string, string>, isRefresh?: boolean, useBrowser?: boolean) => {
  const path = '/dikar-platform/analysis-pallet/list';
  const { origin } = window.location;
  const baseUrl = `${path}?${queryString.stringify({
    ...(params || {}),
  })}`;
  if (useBrowser) {
    window.open(`${origin}${baseUrl}`, '_blank');
    return;
  }
  window.GarfishBridge?.actionBridge?.openInsideTag(baseUrl, '货盘管理', isRefresh);
};

export const openPoolList = (isRefresh?: boolean, useBrowser?: boolean) => {
  const path = '/dikar-platform/analysis-pallet/list';
  const { origin } = window.location;
  if (useBrowser) {
    window.open(`${origin}${path}`, '_blank');
    return;
  }
  window.GarfishBridge?.actionBridge?.openInsideTag(path, '货盘管理', isRefresh);
};
