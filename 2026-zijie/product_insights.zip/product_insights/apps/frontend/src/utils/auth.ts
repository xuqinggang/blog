import { GetProductAnalysisBizData } from '@/api/product/namespaces/dimensions';

interface DimensionValue {
  dimension_type: string;
  dimension_values?: Array<DimensionValue>;
}

export interface ShowApplyDimensionPopupProps {
  dimension_type: string; // 数据权限k
  dimension_values?: Array<DimensionValue>; // 数据权限k对应的v，可能1级可能2级
  afterApplyCallback?: () => void; // 申请接口调用之后执行的回调
}

// 唤起数据权限申请弹窗（https://bytedance.larkoffice.com/wiki/Fd3LwTeBPiBgj0k543ac932jnoh?docs_entrance=from_lark_index_search&wiki_version=2）
export function handleApplyAuth(bizData?: GetProductAnalysisBizData, code?: string) {
  if (!bizData?.parent_user_dimension_code) {
    return;
  }

  const params: ShowApplyDimensionPopupProps = {
    dimension_type: bizData.parent_user_dimension_code,
  };

  if (code) {
    params.dimension_values = [
      {
        dimension_type: code,
      },
    ];
  }

  window?.GarfishBridge?.actionBridge?.showApplyDimensionPopup?.(params);
}

export function batchApplyAuth(bizData?: GetProductAnalysisBizData) {
  if (!bizData?.parent_user_dimension_code) {
    return;
  }

  const params: ShowApplyDimensionPopupProps = {
    dimension_type: bizData.parent_user_dimension_code,
  };

  params.dimension_values = bizData.biz_list?.map(biz => ({
    dimension_type: biz.user_dimension_code || '',
  }));

  window?.GarfishBridge?.actionBridge?.showApplyDimensionPopup?.(params);
}
