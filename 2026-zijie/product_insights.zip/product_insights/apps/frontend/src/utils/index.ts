import { RecursivePartial } from '@ecom/product-insights-components/dist/types/types';

/** 随机生成指定长度的字符串ID */
export const generateRandomId = (length = 12) => {
  let str = Math.random().toString(36).substr(2, 9);
  while (str.length < length) {
    str += Math.random().toString(36).substr(2, 9);
  }
  return str.substring(0, length).toUpperCase();
};

export const readFile = async (file: File) => {
  const pmz = new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = event => {
      const text = event.target?.result?.toString() || '';
      resolve(text);
    };
    reader.onerror = error => {
      reject(error);
    };
    reader.readAsText(file);
  });

  return pmz;
};

interface UserInfo {
  id: number;
  shop_name: string;
  user_name: string;
  mobile: null;
  status: number;
  agent: null;
  user_type: number;
  address: null;
  collect_tel: null;
  collect_tel_sure: null;
  operate_status: null;
  stop_reason: null;
  wechat: null;
  modify_status: null;
  shop_charge_name: null;
  mobile_charge: null;
  is_proxy: null;
  proxy_id: null;
  pay_type: null;
  ad_biz_status: null;
  media_biz_status: null;
  shop_biz_status: null;
  biz_type: number;
  shop_logo: null;
  qq: null;
  email: string;
  toutiaohao_id: null;
  is_pledge_cash: null;
  pledge_cash: null;
  total_reduce: null;
  roster_name: null;
  pledge_cash_refund_status: null;
  pledge_cash_refund_check_msg: null;
  refund_account_info: null;
  company_partner: null;
  email_charge: null;
  contract_status: null;
  contract_archive_date: null;
  register_agreement: null;
  v_type: null;
  certify_status: null;
  certify_status_note: null;
  login_resource: null;
  shop_type: null;
  token: string;
  notice_count: null;
  ad_daily_cost: null;
  toutiao_type: null;
  sutui_white: null;
  is_luban: null;
  active: string;
  avatar_url: string;
  lark_avatar_url: string;
  city_en_name: string;
  city_name: string;
  company: string;
  country_en_name: string;
  country_name: string;
  department_en_name: string;
  department_name: string;
  employee_en_name: string;
  employee_code: string;
  employee_legal_name: null;
  nationality: string;
  organizations: string;
  sequence: string;
  employee_id: string;
  super_admin: boolean;
  department_id: string;
  employee_number: string;
}
export const getCurrentUserInfo = (): UserInfo | undefined => {
  return (window as any)?.GarfishBridge?.infoBridge?.getUserInfo();
};

export function formatNumber(num?: number): string | undefined {
  if (num === undefined) {
    return undefined;
  }

  const sign = num < 0 ? '-' : '';
  const absNum = Math.abs(num);

  // 保留两位小数（四舍五入）
  const fixed = absNum.toFixed(2);
  const [integerPart, decimalPart] = fixed.split('.');

  // 手动每三位插入逗号
  let formattedInt = '';
  let count = 0;
  for (let i = integerPart.length - 1; i >= 0; i--) {
    formattedInt = integerPart[i] + formattedInt;
    count++;
    if (count % 3 === 0 && i !== 0) {
      formattedInt = `,${formattedInt}`;
    }
  }

  return `${sign}${formattedInt}.${decimalPart}`;
}

type PlainObject = Record<string, any>;

function isPlainObject(val: any): val is PlainObject {
  return Object.prototype.toString.call(val) === '[object Object]';
}

export const deepMerge = <T>(target: T, source: RecursivePartial<T>): T => {
  // 如果不是对象，直接返回 source 覆盖 target
  if (!isPlainObject(target) || !isPlainObject(source)) {
    return target as T;
  }

  const result: PlainObject = { ...target };

  for (const key of Object.keys(source)) {
    const targetValue = (target as PlainObject)[key];
    const sourceValue = (source as PlainObject)[key];

    if (Array.isArray(targetValue) && Array.isArray(sourceValue)) {
      // 数组合并，按需改成 concat / 覆盖
      result[key] = [...targetValue, ...sourceValue];
    } else if (isPlainObject(targetValue) && isPlainObject(sourceValue)) {
      result[key] = deepMerge(targetValue, sourceValue);
    } else {
      result[key] = sourceValue;
    }
  }

  return result as T;
};

export const getChangeRatio = (current: number, compare: number) => {
  if (compare === 0) {
    return current === 0 ? 0 : '-';
  }
  return (current - compare) / compare;
};

export enum APP_ROUTE {
  ProductReview = '/product_insight/review',
  BusinessAnalysis = '/product_insight/review/business_analysis',
}

export const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
