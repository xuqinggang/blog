/* eslint-disable @typescript-eslint/member-ordering */
import { flow, makeAutoObservable, observable } from 'mobx';

import { arcticClient } from '@/api';
import { LoadShareableStateResponse } from '@/api/arctic';
import { BizType } from '@/api/product/namespaces/dimensions';

export type IShareData<T = unknown> = T & {
  biz_type?: BizType;
};

export class ShareStore<T = unknown> {
  shareData: IShareData<T> | null = null; // 分享的数据

  shareInit = false; // 分享的数据是否初始化

  constructor() {
    makeAutoObservable(this, { shareData: observable.ref }, { autoBind: true });
  }

  // 获取分享的数据
  getShareData = flow(function* (this: ShareStore, resId?: string | null) {
    if (!resId) {
      this.shareInit = true;
      return;
    }

    try {
      const { modules }: LoadShareableStateResponse = yield arcticClient.LoadShareableState({
        res_id: resId,
      });
      if (!modules?.filter?.state) {
        this.shareInit = true;
        return;
      }

      const shareData = JSON.parse(modules.filter.state) as T;
      if (shareData) {
        this.shareData = shareData;
      }
      return shareData;
    } catch (e) {
      console.error(`Get shared filter error, res_id = ${resId}, error = `, e);
    } finally {
      this.shareInit = true;
    }
  });
}
