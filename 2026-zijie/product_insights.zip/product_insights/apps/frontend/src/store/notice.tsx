import dayjs from 'dayjs';
import { makeAutoObservable, reaction } from 'mobx';

import { Icon, notification } from '@ecom/auxo';
import { RichTextView } from '@ecom/product-insights-components';

import { bffClient } from '@/api';
import { NoticeStatus } from '@/api/bff/namespaces/notice';
import { NoticeClickType, reportNoticeClick, reportNoticeClose, reportNoticeShow } from '@/tea';
import { INSIGHT_CACHE_CLOSE_NOTICE } from '@/utils/constant';

export function previewNotice(title: string, deltas?: any, onClose?: () => void, hooks?: PreviewNoticeHooks) {
  notification.open({
    message: (
      <div className="font-semibold flex items-center gap-2">
        <Icon.NoticeIcon style={{ color: '#108ee9' }} />
        <span>{title}</span>
      </div>
    ),
    description: (
      <RichTextView
        defaultDeltas={deltas}
        showDirectory={false}
        className="!text-[14px] !leading-5 !max-h-[500px]"
        image={{
          upload: () => Promise.resolve(''),
          onClick: hooks?.onImgClick,
        }}
        hyperlink={{
          onClick: hooks?.onLinkClick,
        }}
      />
    ),
    duration: null,
    onClose,
  });
}

interface NoticeInfo {
  timestamp: number; // 通知不可见时间戳，默认是T+1天
  id: string;
}

export interface PreviewNoticeHooks {
  onImgClick?: (src: string) => void;
  onLinkClick?: (url: string) => void;
}

class NoticeStore {
  pathname = '';

  alreadyShow = false;

  constructor() {
    makeAutoObservable(this, {}, { autoBind: true });

    reaction(
      () => this.pathname,
      () => {
        this.showNotice();
      },
    );
  }

  setPathname(pathname: string) {
    this.pathname = pathname;
  }

  showNotice = async () => {
    if (!this.pathname || this.alreadyShow || this.pathname.startsWith('/admin')) {
      return;
    }

    try {
      const data = await bffClient.GetNoticeList({
        status: NoticeStatus.ONLINE,
        path: `/product_insight${this.pathname}`,
      });
      const noticeList = data?.data?.list;
      if (!noticeList.length) {
        return;
      }

      const closeNotice = JSON.parse(localStorage.getItem(INSIGHT_CACHE_CLOSE_NOTICE) || '[]') as NoticeInfo[];
      const notice = noticeList.find(item => {
        let visible = true;
        for (const { id, timestamp } of closeNotice) {
          if (item.id === id && dayjs().valueOf() < timestamp) {
            visible = false;
            break;
          }
        }

        return visible;
      }); // 默认展示用户没有关闭的通知
      if (!notice) {
        return;
      }

      const deltas = JSON.parse(notice.content || '{}');
      // 展示通知
      reportNoticeShow(String(notice.id), notice.title);
      previewNotice(
        notice.title,
        deltas,
        () => {
          // 关闭通知，该通知在T+1天内不可见
          reportNoticeClose(String(notice.id), notice.title);
          const newCloseNotice: NoticeInfo[] = [
            ...closeNotice,
            {
              id: String(notice.id),
              timestamp: dayjs().add(1, 'day').startOf('day').valueOf(),
            },
          ];
          localStorage.setItem(INSIGHT_CACHE_CLOSE_NOTICE, JSON.stringify(newCloseNotice));
        },
        {
          onImgClick: src => {
            reportNoticeClick(String(notice.id), notice.title, NoticeClickType.IMG, src);
          },
          onLinkClick: url => {
            reportNoticeClick(String(notice.id), notice.title, NoticeClickType.LINK, url);
          },
        },
      );

      this.alreadyShow = true;
    } catch (e) {
      console.error('Get notice error');
    }
  };
}

export const noticeStore = new NoticeStore();
