/* eslint-disable @typescript-eslint/member-ordering */
import dayjs from 'dayjs';
import { flow, makeAutoObservable, observable } from 'mobx';

import { productClient } from '@/api';
import {
  BizType,
  DataReadyTime,
  GetDataReadyTimeResponse,
  GetDimensionListData,
  GetDimensionListResponse,
  GetProductAnalysisTargetMetaListResponse,
  TargetMetaInfo,
} from '@/api/product/namespaces/dimensions';
import { FilterStatus } from '@/components/dimension-filter/types';
import { DIMENSION_CACHE_KEY_PREFIX } from '@/components/dimension-filter/utils/constant';
import { getMultiDims } from '@/components/dimension-filter/utils/get-multi-dims';

export class BizStore {
  bizType: BizType;

  loading = true; // 维度是否在加载中

  status = FilterStatus.INIT; // 筛选区的状态

  readyTime: DataReadyTime | null = null; // 可用时间范围

  dimensionData: GetDimensionListData | null = null; // 维度信息

  targetList: TargetMetaInfo[] | null = null; // 分析指标列表

  constructor(bizType: BizType) {
    this.bizType = bizType;
    makeAutoObservable(
      this,
      {
        readyTime: observable.ref,
        dimensionData: observable.ref,
        targetList: observable.ref,
      },
      { autoBind: true },
    );
  }

  // 用于多维分析的维度
  get multiDimDimensions() {
    return getMultiDims(this.dimensionData);
  }

  get targetOptions() {
    return (
      this.targetList?.map(item => ({
        label: item.display_name as string,
        value: item.name as string,
      })) || []
    );
  }

  // 设置筛选的状态
  setStatus(status: FilterStatus) {
    this.status = status;
  }

  // 获取业务指标列表
  getAnalysisTargetList = flow(function* (this: BizStore) {
    try {
      const { data }: GetProductAnalysisTargetMetaListResponse = yield productClient.GetProductAnalysisTargetMetaList({
        biz_type: this.bizType,
      });

      const query = new URLSearchParams(location.search);
      const isFromProductIncubation = query.get('biz_from') === 'product_incubation';

      if (data) {
        this.targetList = data;
        // 孵化中心不展示计划字段
        if (isFromProductIncubation) {
          this.targetList = this.targetList.filter(item => item.name !== 'plan_cnt');
        }
      }
    } catch (e) {
      console.error('Get analysis target list error', e);
    }
  });

  // 获取维度信息
  getDimensionList = flow(function* (this: BizStore, ifCache = true) {
    try {
      console.log('xxxxxxxgetDimensionList, this.bizType', this.bizType);
      // 默认从localStorage里面获取dimension
      const cacheKey = `${DIMENSION_CACHE_KEY_PREFIX}_${this.bizType}`;
      const { timeStamp = 0, data } = JSON.parse(localStorage.getItem(cacheKey) ?? '{}');
      const isOutDate = dayjs(timeStamp).add(1, 'hour').isBefore(dayjs()); // 缓存过期时间为1h

      let dimData: GetDimensionListData | undefined;
      if (!isOutDate && data && ifCache) {
        // 缓存未过期
        dimData = data;
      } else {
        const { data: resData }: GetDimensionListResponse = yield productClient.GetDimensionList({
          biz_type: this.bizType,
        });

        if (resData) {
          dimData = resData;

          // 更新缓存
          localStorage.setItem(cacheKey, JSON.stringify({ timeStamp: dayjs().toString(), data: resData }));
        }
      }

      if (dimData) {
        this.dimensionData = dimData;
      }
      console.log('xxxxxxxgetDimensionList, this.dimensionData', this.dimensionData);
    } catch (e) {
      console.error('Get dimension error', e);
    } finally {
      this.loading = false;
    }
  });

  // 获取可用时间范围
  getReadyTime = flow(function* (this: BizStore) {
    try {
      const { data }: GetDataReadyTimeResponse = yield productClient.GetReadyTime({ biz_type: this.bizType });
      if (data) {
        this.readyTime = data;
      }
    } catch (e) {
      console.error('Get ready time error', e);
    }
  });
}
