/* eslint-disable @typescript-eslint/member-ordering */
import { autorun, flow, makeAutoObservable, observable } from 'mobx';

import { TemplateEntity } from '@ecom/arctic-components';
import { message } from '@ecom/auxo';

import { productClient } from '@/api';
import { BizType } from '@/api/product/namespaces/dimensions';
import { TemplateElement, TemplateModule } from '@/api/product/namespaces/template';
import { IShareData } from '@/store/share';
import { INSIGHT_CACHE_MODULE_KEY } from '@/utils/constant';

export type ModuleShareData<T> = IShareData<
  T & {
    module?: TemplateModule;
  }
>;

export interface TemplateList {
  selfList: Array<TemplateEntity>;
  commonList: Array<TemplateEntity>;
}

export class ModuleStore<T = unknown> {
  initialData: T | null = null; // 初始化数据

  templateList: TemplateList | null = null; // 模板列表

  loading = false;

  templateId = ''; // 选择的模版

  globalData: T | null = null; // 当前所有子模块的数据

  isInit = false; // 是否初始化完成

  private module: TemplateModule;

  private bizType: BizType;

  constructor(module: TemplateModule, bizType: BizType) {
    this.module = module;
    this.bizType = bizType;

    makeAutoObservable(
      this,
      { initialData: observable.ref, templateList: observable.ref, globalData: false },
      { autoBind: true },
    );

    // initialData改变时，更新globalData
    autorun(() => {
      this.initialData && this.setGlobalData({ ...this.initialData });
    });
  }

  get selectedTemplate() {
    return (
      this.templateList?.commonList?.find(i => i.template_id === this.templateId) ??
      this.templateList?.selfList?.find(i => i.template_id === this.templateId)
    );
  }

  // 获取缓存数据
  getCacheData() {
    const cachedString = localStorage.getItem(`${INSIGHT_CACHE_MODULE_KEY}_${this.module}_${this.bizType}`);
    if (!cachedString) {
      return;
    }

    try {
      const cachedData = JSON.parse(cachedString) as T;
      return cachedData;
    } catch (e) {
      console.error('Get module cache error', e);
    }
  }

  // 获取模版列表
  async getTemplateList(keyword?: string) {
    function transformTemplate(i: TemplateElement): TemplateEntity {
      return {
        name: i.name,
        template_id: i.id,
        disabled: !i.edit,
      };
    }

    try {
      const { data } = await productClient.GetTemplateList({
        biz_type: this.bizType,
        keyword,
        module_enum: this.module,
      });

      const templateList = {
        commonList: data.common_list?.map(transformTemplate) ?? [],
        selfList: data.self_list?.map(transformTemplate) ?? [],
      };

      this.templateList = templateList;
    } catch (e) {
      console.error('Get template list error', e);
      this.templateList = {
        commonList: [],
        selfList: [],
      };
    }
  }

  // 获取模版详情
  async getTemplateDetail(templateId: string) {
    try {
      const { data } = await productClient.GetTemplateDetail({
        template_id: templateId,
      });
      if (!data?.base_req_marshal) {
        return;
      }

      const templateData = (data.base_info ?? JSON.parse(data.base_req_marshal)) as T;
      return templateData;
    } catch (e) {
      console.error('Get template detail error', e);
    }
  }

  // 数据初始化
  initData(shareData?: ModuleShareData<T> | null) {
    if (this.initialData) {
      return;
    }

    // 分享
    if (shareData) {
      const { biz_type, module, ...rest } = shareData;
      if (biz_type === this.bizType && module === this.module) {
        // bizType和module匹配成功才会赋值给initialData
        this.isInit = true;
        this.initialData = rest as T;
        return;
      }
    }

    // 缓存
    const cachedData = this.getCacheData();
    if (cachedData) {
      this.isInit = true;
      this.initialData = cachedData;
      return;
    }

    this.isInit = true;
  }

  setBizType(bizType: BizType) {
    this.bizType = bizType;
  }

  setGlobalData(data: T | null) {
    this.globalData = data;
  }

  // 数据更新
  handleChangeData(data: T) {
    this.setGlobalData(data);
    localStorage.setItem(`${INSIGHT_CACHE_MODULE_KEY}_${this.module}_${this.bizType}`, JSON.stringify(this.globalData)); // 缓存
  }

  // 选中模版
  handleSelectTemplate = flow(function* (this: ModuleStore, templateId: string) {
    this.templateId = templateId;
    if (!templateId) {
      return;
    }

    this.loading = true;

    const templateData: T | undefined = yield this.getTemplateDetail(templateId);
    if (templateData) {
      this.initialData = templateData;
      localStorage.setItem(`${INSIGHT_CACHE_MODULE_KEY}_${this.module}_${this.bizType}`, JSON.stringify(templateData)); // 缓存
    }

    this.loading = false;
  });

  // 删除模版
  handleDeleteTemplate = flow(function* (this: ModuleStore, templateId: string) {
    try {
      yield productClient.DeleteTemplate({
        template_id: templateId,
      });
      message.success('模版删除成功');

      // 重置templateId
      this.templateId = '';

      // 刷新模版列表
      yield this.getTemplateList();
    } catch (e) {
      console.error('Delete template error', e);
      message.error('模版删除失败');
    }
  });

  // 清空模版，重置为缓存的数据
  handleClearTemplate() {
    const cachedData = this.getCacheData();
    if (cachedData) {
      this.initialData = cachedData;
    } else {
      this.initialData = null;
    }
  }

  // 保存、更新模版
  async createOrUpdateTemplate(templateId?: string, name?: string, isCommon?: boolean) {
    try {
      if (templateId) {
        // 更新
        const isCommon = this.templateList?.commonList.some(i => i.template_id === templateId);
        const name = [...(this.templateList?.commonList ?? []), ...(this.templateList?.selfList ?? [])].find(
          i => i.template_id === templateId,
        )?.name;

        await productClient.UpdateTemplate({
          biz_type: this.bizType,
          template_id: templateId,
          name,
          module_enum: this.module,
          base_req_marshal: JSON.stringify(this.globalData),
          is_common: isCommon,
        });

        message.success('模版保存成功');
      } else {
        // 创建
        await productClient.CreateTemplate({
          biz_type: this.bizType,
          name,
          module_enum: this.module,
          base_req_marshal: JSON.stringify(this.globalData),
          is_common: isCommon,
        });

        message.success('模版创建成功');
      }

      // 刷新模版列表
      await this.getTemplateList();
    } catch (e) {
      console.error('Create or update template error', e);
      message.error(templateId ? '模版更新失败' : '模版创建失败');
    }
  }
}
