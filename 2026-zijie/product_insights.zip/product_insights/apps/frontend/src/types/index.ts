import { BizType, ProductAnalysisBaseStruct } from '@/api/product/namespaces/dimensions';
import { PriceAnalysisBaseStruct } from '@/api/product/namespaces/price_dimensions';

export type BaseStruct = ProductAnalysisBaseStruct | PriceAnalysisBaseStruct;

/** 打开下钻页面传递的上下文 */
export interface DrillContext {
  baseStruct: BaseStruct;
  bizType: BizType;
}

/** 下钻页面的参数 */
export interface PageParams {
  template_id?: string;
}
