import Tea from 'byted-tea-sdk';

/** 开始分析按钮点击 */
export const reportStartAnalysisClick = (title?: string) => {
  console.log('~~~tea, reportStartAnalysisClick', title || (window as any).__PRODUCT_INSIGHTS_TITLE__);
  Tea.event('start_analysis_click', { title: title || (window as any).__PRODUCT_INSIGHTS_TITLE__ });
};

/** 商品明细抽屉展现（废弃） */
export const reportProdDetailShow = () => {
  Tea.event('prod_detail_show');
};

/** 多维分析配置抽屉展现 */
export const reportMultiDimensionShow = () => {
  Tea.event('multi_dimension_show');
};

/** 多维分析确认按钮点击 */
export const reportMultiDimensionClick = () => {
  Tea.event('multi_dimension_click');
};
