import Tea from 'byted-tea-sdk';

export function initTea() {
  try {
    // 开发环境不上报埋点
    Tea.init({
      app_id: 613357, //  number类型的appId。
      channel: 'cn',
      autotrack: {
        custom: 'tea',
      },
      enable_debug: process.env.NODE_ENV === 'development',

      /** 禁止默认上报pv */
      disable_auto_pv: true,
    });

    const userInfo = window.GarfishBridge?.infoBridge?.getUserInfo();

    /** 配置埋点上报通用参数 */
    Tea.config({
      // eslint-disable-next-line @typescript-eslint/naming-convention
      _staging_flag: process.env.NODE_ENV === 'development' ? 1 : 0, // 开发环境下埋点不落库
      user_unique_id: userInfo?.email, // 使用用户邮箱作为用户唯一标识
      evtParams: {
        url: location.href,
        url_path: location.pathname,
        user_id: userInfo?.id,
        user_name: userInfo?.user_name,
        department: userInfo?.department_name,
        email: userInfo?.email,
        employee_id: userInfo?.employee_id,
      },
    });

    Tea.start();
    console.log('init tea success');
  } catch (e) {
    // eslint-disable-next-line no-console
    console.warn('init tea failed:', e);
  }
}

export * from './dashboard';
export * from './common';
