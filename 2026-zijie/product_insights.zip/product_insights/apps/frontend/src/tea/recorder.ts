/** Tea会话回放：https://bytedance.larkoffice.com/wiki/PXuDwRgKWiD4mpkn1LycnfoonZb */
import { useEffect } from 'react';
import Tea from 'byted-tea-sdk';

import { RecordingContext, RecordingEvent, RecordingMode, TeaMultithreadedRecorder } from '@teareplay/recorder';

import { PageTitle } from './common';

export const teaRecorder = new TeaMultithreadedRecorder({
  tea: Tea, // 需要传入 tea web sdk 实例；如果使用了 CDN 版本 tea web sdk,
  // 则该参数可省略，只要确保 Tea SDK 已加载完毕后再开始播放即可；
  // 如果使用 edenx 的 Tea 插件，则需要将 window.Tea 传入。
  trackers: ['HTML', 'Mouse', 'Network', 'Keyboard', 'Console', 'Error', 'Performance', 'Insight'],
});

export function useTeaRecorder(page: PageTitle) {
  useEffect(() => {
    let recorder: RecordingContext<RecordingEvent>;
    const startRecording = async () => {
      try {
        recorder = await teaRecorder.startRecording({
          mode: RecordingMode.Streaming,
          tags: [
            page, // 页面名称
            location.pathname || '/product_insight', // 页面路径
            process.env.NODE_ENV === 'production'
              ? process.env.BUILD_TYPE === 'online' && process.env.BUILD_REPO_BRANCH === 'master' // 区分线上和ppe，只有构建类型为线上且构建分支为master才上报到prod环境
                ? 'prod'
                : 'ppe'
              : 'dev', // 环境
          ],
        });
      } catch (error) {
        console.error(error, 'tea会话录制失败');
      }
    };

    startRecording();

    return () => {
      if (recorder) {
        // 在调用 recorder 之前先检查是否存在
        recorder.stopRecording();
      }
    };
  }, [page]);
}
