import Tea from 'byted-tea-sdk';

import { PageTitle } from './common';

/** AI Bot对话框展现 */
export const reportBotShowPv = (title: PageTitle) => {
  Tea.event('bot_show_pv', {
    title,
  });
};

/** 用户发起提问 */
export const reportBotQuery = (title: PageTitle, ai_bot_query?: string) => {
  Tea.event('bot_query', {
    title,
    ai_bot_query,
  });
};

/** AI Bot开始回复 */
export const reportBotReplay = (title: PageTitle, ai_bot_query?: string) => {
  Tea.event('bot_reply', {
    title,
    ai_bot_query,
  });
};

/** AI Bot回复完成 */
export const reportBotReplayFinish = (title: PageTitle, ai_bot_query: string) => {
  Tea.event('bot_reply_finish', {
    title,
    ai_bot_query,
  });
};

/** AI Bot回复失败 */
export const reportBotReplayFail = (title: PageTitle, error_message: string, ai_bot_query?: string) => {
  Tea.event('bot_reply_fail', {
    title,
    ai_bot_query,
    error_message,
  });
};

/** 反馈 */
export const reportBotFeedback = (
  title: PageTitle,
  feedback_type: 'good' | 'bad',
  session_id: string,
  message_id: string,
  feedback_reason?: string,
  feedback_content?: string,
) => {
  Tea.event('bot_feedback', {
    title,
    feedback_type,
    session_id,
    message_id,
    feedback_reason,
    feedback_content,
  });
};
