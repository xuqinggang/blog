import axios from '@/api/axios';

export async function uploadImage(file: File, name?: string) {
  try {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('name', name || '');

    const { data } = await axios.post('/product_analysis_node/image/upload', formData);
    const imgUrl = data?.imgUrl || '';
    return imgUrl;
  } catch (e) {
    console.error('Upload image error', e);
  }
}
