// https://lander.arcosite.bytedance.com/3vflb831/khpb476x?_lang=zh#5a10cfd5

import React from 'react';
import * as MobxReactLite from 'mobx-react-lite';
import jsxRuntime from 'react/jsx-runtime';
import ReactDOM from 'react-dom';

import * as Auxo from '@ecom/auxo';

// Lander注入依赖：https://bytedance.larkoffice.com/docx/Y1hzdm1QkoD03xxgxJKcZC4enRf

window.React = React;
window.ReactDOM = ReactDOM;
(window as any).jsxRuntime = jsxRuntime;
window.Auxo = Auxo as any;
(window as any).MobxReactLite = MobxReactLite;
