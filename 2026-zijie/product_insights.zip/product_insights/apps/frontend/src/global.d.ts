type CtxKey = `APP_CTX_${string}`;

interface Window {
  GarfishBridge: Record<string, any>;
  LanderDatajs: any;
  AnalysisTable: any;
  AuthToCompass: any;
  Moment: any;
  Auxo: any;
  ChartHub: any;
  Lodash: any;
  GloablEventEmitter: any;

  __insight_lander_dev__?: boolean;
  [key: CtxKey]: any;
}

// antd-dayjs-webpack-plugin ts声明
declare module 'antd-dayjs-webpack-plugin';

declare module 'markdown-it-br' {
  const exportData: any = {};
  export = exportData;
}

declare module 'jsoneditor-react';
// declare module 'moment' {
//   import { Dayjs } from 'dayjs';
//   namespace moment {
//     type Moment = Dayjs;
//   }
//   export = moment;
// }
