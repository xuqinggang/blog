import React from 'react';

import {
  Body,
  Head,
  Html,
  Root,
  // DocumentContext,
} from '@edenx/runtime/document';

export default function Document(): React.ReactElement {
  // DocumentContext 提供一些构建时的参数
  // const {
  //   config: { output: htmlConfig },
  //   entryName,
  //   templateParams,
  // } = useContext(DocumentContext);
  return (
    <Html>
      <Head />
      <Body>
        <Root rootId="root" />
      </Body>
    </Html>
  );
}
