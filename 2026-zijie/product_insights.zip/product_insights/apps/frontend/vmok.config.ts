import { createVmokConfig } from '@edenx/plugin-vmok';

export default createVmokConfig({
  // 同一个 scm 目前只能绑定一个 Vmok 模块
  name: '@ecom-insight/product',
  dev: {
    disableLiveReload: true,
  },
  exposes: {
    '.': './node_modules/.edenx/main/index.jsx',
    './multi-dim-conclusion': './src/components/multi-dim-conclusion/index.tsx',
    './multi-dim-table': './src/components/multi-dim-table/index.tsx',
    './cross-dim-picker': './src/components/CrossDimPicker/index.tsx',
    './embed-provider': './src/components/embed-provider/index.tsx',
    './marketing-analyser': './src/modules/marketing-analyser/index.tsx',
  },
  // 设置共享依赖
  shared: {
    react: {
      singleton: true,
    },
    'react-dom': {
      singleton: true,
    },
  },
  dts: {
    displayErrorInTerminal: true,
  },
});
