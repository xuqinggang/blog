#!/bin/bash
. /etc/profile

set -e

npm run deploy
