# ProductValueClassifyTree

## changelog

### 1.0.0-alpha.3

1. 百分比显示问题
2. 增加贡献比例展示
3. 增加未来上线功能展示
