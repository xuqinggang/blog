import { createLanderForm, type ISettings } from '@ecom/lander-ui-setters';

// Field中的name不可使用lander的保留字段，保留字段有：style、visible、name、cellId、componentName；也不可使用__开头的字符
const Setting: ISettings = {
  props: [
    {
      type: 'Void',
      title: '基础',
      decorator: 'Block',
      children: [
        {
          type: 'Union',
          title: '渲染数据',
          name: 'renderData',
          defaultValue: [],
        },

        {
          type: 'Union',
          title: '文案',
          name: 'definition',
          defaultValue: {},
        },
        {
          type: 'Union',
          title: '通用请求体',
          name: 'baseParams',
          defaultValue: {},
        },
        {
          type: 'Union',
          title: '商品查询参数',
          name: 'queryParams',
          defaultValue: {},
        },
        {
          type: 'Union',
          title: '目标信息',
          name: 'targets',
          defaultValue: {},
        },
        {
          type: 'Union',
          title: '策略信息',
          name: 'strategy',
          defaultValue: null,
        },
      ],
    },
  ],
  events: [],
  style: true,
};

export default createLanderForm(Setting);
