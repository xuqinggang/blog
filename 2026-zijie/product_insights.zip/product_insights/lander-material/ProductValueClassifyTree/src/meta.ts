import { defineMeta } from '@ecom/lander-ui-setters';

export default defineMeta({
  name: 'productValueClassifyTree',
  displayName: '商品分化洞察归因树',
  icon: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/nulmlbebo/product_insight/ProductValueClassifyTree.png',
  group: '货盘复盘/数据展示',
  width: '100px',
  height: '100px',
  heightType: 'fit',
  stateProperties: {
    targetPoolType: {
      desc: '选中状态',
    },
  },
});
