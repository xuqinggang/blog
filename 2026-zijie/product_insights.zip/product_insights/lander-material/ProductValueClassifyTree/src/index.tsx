/* eslint-disable @typescript-eslint/naming-convention */
import { FC } from 'react';

import { createLanderComponent, type UIContext, useGlobalState } from '@ecom/lander-ui-runtime-usage';
import { CommonAnalysisRequest, ProductValueClassifyTree } from '@ecom/product-insights-components';
import { TargetCardEntity } from '@ecom/product-insights-components/dist/types/api/product/namespaces/analysis';
import { ProdReviewStrategy } from '@ecom/product-insights-components/dist/types/api/product/namespaces/prod_review';

// !请注意不要直接引用setting文件

export interface ProductValueClassifyTreeProps extends UIContext {
  renderData: Array<TargetCardEntity>;

  definition: {
    strategy_full: string;
    strategy_advantage: string;
    strategy_disadvantage: string;
    short: string;
    long: string;
    invalid: string;
  };
  baseParams: CommonAnalysisRequest;
  queryParams: string;
  targets: {
    short: number;
    long: number;
  };
  strategy?: ProdReviewStrategy;
}

export const ProductValueClassifyTreeComp: FC<ProductValueClassifyTreeProps> = props => {
  const {
    renderData,
    baseParams,
    queryParams,
    definition,
    targets,
    strategy,
    style = { width: '100px', height: '100px' },
  } = props;

  const [targetPoolType, setActiveNode] = useGlobalState({
    key: 'targetPoolType',
    defaultValue: 0,
  });

  const handleActiveNode = (idx = 0) => {
    if (idx === -1) {
      return;
    }
    const newIdx = Math.max(0, Math.min(idx, 2));
    setActiveNode(newIdx);
  };

  return (
    // 必须在组件根节点下应用props中的style属性，LanderCommon中配置的组件宽高等属性将会通过该属性传递
    <div style={style}>
      <ProductValueClassifyTree
        renderData={renderData}
        targetPoolType={Number(targetPoolType)}
        definition={definition}
        handleActiveNode={handleActiveNode}
        baseParams={baseParams}
        queryParams={queryParams}
        targets={targets}
        strategy={strategy}
      />
    </div>
  );
};

export default createLanderComponent<ProductValueClassifyTreeProps>(ProductValueClassifyTreeComp);
