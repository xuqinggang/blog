import moduleTools, { defineConfig } from '@edenx/module-tools';
import tailwindPlugin from '@edenx/plugin-tailwind';
import { modulePluginRollupUmd } from '@edenx/plugin-module-rollup-umd';
import autoprefixer from 'autoprefixer';
import tailwindConfig from './tailwind.config';
import umdGlobals from './umdGlobals.json';
import path from 'path';
import fs from 'fs';
const { theme: designSystem, ...tailwindcss } = tailwindConfig;

const isDev = process?.env?.NODE_ENV === 'development';

const alias = {
  '@ecom/product-insights-components': path.resolve(__dirname, '../packages/components/src'),
  '@ecom/product-insights-components/*': path.resolve(__dirname, '../packages/components/src/*'),
  '~': path.resolve(__dirname, '../packages/components/src'),
  '~/*': path.resolve(__dirname, '../packages/components/src/*'),
};
export default (name: string) =>
  defineConfig({
    plugins: [
      moduleTools(),
      tailwindPlugin(),
      modulePluginRollupUmd(),
      {
        name: 'build-check-plugin',
        setup() {
          return {
            afterBuild(options: any): void {
              const umdConfig = options?.config?.find((el: any) => el.format === 'umd');
              const indexPath = path.resolve(umdConfig?.sourceDir, '../dist/index.umd.js');
              const content = fs.readFileSync(indexPath);
              if (content?.includes('LanderUISetters') || content?.includes('LanderUISetting')) {
                throw Error(
                  `index文件直接或间接引用了index.setting文件，请检查 ${indexPath} 文件的内容，确保其中不包含“LanderUISetters”或者“LanderUISetting”`,
                );
              }
            },
          };
        },
      },
    ],
    buildConfig: [
      // 构建组件的es包
      {
        format: 'esm',
        target: 'es5',
        buildType: 'bundleless',
        input: ['./src'],
        autoExternal: true,
        outDir: './dist/es',
        platform: 'browser',
        dts: false,
        style: {
          less: {
            lessOptions: {
              javascriptEnabled: true,
              math: 'always',
            },
          },
          postcss: {
            plugins: [
              autoprefixer({
                flexbox: 'no-2009',
                overrideBrowserslist: ['> 0.01%', 'not dead', 'not op_mini all'],
              }),
            ],
          },
          tailwindcss,
        },
      },
      {
        buildType: 'bundle',
        outDir: './dist/types',
        platform: 'browser',
        dts: {
          only: true,
        },
        alias,
      },
      {
        format: 'umd',
        target: 'es5',
        buildType: 'bundle',
        autoExternal: false,
        outDir: './dist',
        dts: false,
        input: {
          'index.umd': './src/index.tsx',
          'setting.umd': './src/index.setting.tsx',
          'meta.umd': './src/meta.ts',
        },
        umdModuleName: path => {
          if (path.includes('index.umd')) {
            return name;
          } else if (path.includes('setting.umd')) {
            return `${name}/setting`;
          } else if (path.includes('meta.umd')) {
            return `${name}/meta`;
          }
          return path;
        },
        platform: 'browser',
        style: {
          inject: true,
          less: {
            lessOptions: {
              javascriptEnabled: true,
              math: 'always',
            },
          },
          postcss: {
            plugins: [
              autoprefixer({
                flexbox: 'no-2009',
                overrideBrowserslist: ['> 0.01%', 'not dead', 'not op_mini all'],
              }),
            ],
          },
        },
        minify: isDev ? false : true,
        umdGlobals,
        alias,
      },
    ],
    designSystem,
  });
