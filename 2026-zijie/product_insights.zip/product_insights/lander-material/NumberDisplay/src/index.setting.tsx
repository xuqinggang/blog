import { type ISettings, castMarker, createLanderForm } from '@ecom/lander-ui-setters';

export enum PropertyKey {
  text = 'text',
  size = 'size',
}

// Field中的name不可使用lander的保留字段，保留字段有：style、visible、name、cellId、componentName；也不可使用__开头的字符
const Setting: ISettings = {
  props: [
    {
      type: 'Void',
      title: '基础',
      decorator: 'Block',
      children: [
        {
          type: 'Union',
          title: '数字',
          name: 'value',
          defaultValue: 0,
        },
      ],
    },
    {
      type: 'Void',
      title: '格式化',
      decorator: 'Block',
      children: [
        {
          type: 'String',
          name: 'format/ratio',
          title: '百分比展示',
          defaultValue: '',
          setter: 'ChoiceSetter',
          setterProps: {
            options: [
              { value: '', label: '无' },
              { value: '%', label: '%' },
              { value: 'pp', label: 'pp' },
            ],
          },
        },
        {
          title: '自动添加单位',
          type: 'Boolean',
          name: 'format/useUnit',
          defaultValue: false,
          setter: 'SwitchSetter',
        },
        {
          type: 'Number',
          name: 'format/fixed',
          title: '小数位数',
          defaultValue: 2,
          setter: 'NumberSetter',
        },
      ],
    },
    {
      type: 'Void',
      title: '样式',
      decorator: 'Block',
      children: [
        {
          type: 'String',
          name: 'styles/color',
          title: '颜色',
          defaultValue: '',
          setter: 'ChoiceSetter',
          setterProps: {
            options: [
              { value: '', label: '无' },
              { value: 'negative', label: '负数' },
              { value: 'positive', label: '正数' },
            ],
          },
        },
        {
          type: 'String',
          name: 'styles/prefix',
          title: '前缀',
          defaultValue: '',
          setter: 'ChoiceSetter',
          setterProps: {
            options: [
              { value: '', label: '无' },
              { value: 'arrow', label: '箭头' },
            ],
          },
        },
      ],
    },
  ],
  events: [
    {
      label: '点击',
      value: 'Click',
    },
  ],
  style: [
    {
      type: 'StructStyle',
      name: 'style',
      enablePosition: true,
      enableSize: true,
      enableOverflow: true,
      enableTextResizing: true,
      enableVisible: true,
      enableZIndex: true,
      enableBackgroundColor: true,
      enableBorderRadius: true,
    },
    {
      type: 'Void',
      title: '字体',
      decorator: 'Collapse',
      children: [
        {
          type: 'Object',
          name: 'fontStyle',
          title: '',
          properties: [
            // {
            //   type: 'String',
            //   name: 'fontFamily',
            //   title: '字体',
            //   setter: 'ChoiceSetter',
            //   setterProps: {
            //     options: [
            //       { label: 'PingFang SC', value: 'PingFang SC' },
            //       { label: 'Barlow', value: 'Barlow' },
            //     ],
            //   },
            //   supportFx: true,
            // },
            {
              type: 'Union',
              name: 'style/size',
              title: '字体大小',
              defaultValue: 14,
              setter: 'CodeInputSetter',
              markers: castMarker(['number']),
            },

            {
              type: 'Union',
              name: 'style/color',
              title: '字体颜色',
              setter: 'CodeInputSetter',
              markers: castMarker(['string']),
            },
            // {
            //   type: 'Union',
            //   name: 'fontHoverColor',
            //   title: '字体悬停颜色',
            //   setter: 'CodeInputSetter',
            //   markers: castMarker(['string']),
            // },
            {
              type: 'Number',
              name: 'style/textWeight',
              title: '字体粗细',
              setter: 'SelectSetter',
              setterProps: {
                options: [
                  { label: '常规', value: 400 },
                  { label: '粗体', value: 500 },
                ],
              },
              supportFx: true,
            },
            {
              type: 'String',
              name: 'style/cursor',
              title: '指针样式',
              setter: 'SelectSetter',
              setterProps: {
                options: [
                  { label: '默认', value: 'default' },
                  { label: '可点击', value: 'pointer' },
                ],
              },
              supportFx: true,
            },
            {
              type: 'Union',
              name: 'style/customStyle',
              title: '自定义样式',
              setter: 'CodeInputSetter',
              defaultValue: '{}',
              markers: castMarker(['object']),
            },
            // {
            //   type: 'Boolean',
            //   name: 'noRem',
            //   title: '去除自动em',
            //   supportFx: true,
            //   tooltip: '开启markdown时，会自动添加margin-bottom为1em，开启后会去掉这个自动添加的样式',
            // },
          ],
        },
      ],
    },
  ],
};

export default createLanderForm(Setting);
