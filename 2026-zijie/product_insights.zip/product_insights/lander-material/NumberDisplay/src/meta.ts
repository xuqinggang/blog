import { defineMeta } from '@ecom/lander-ui-setters';

export default defineMeta({
  name: 'numberDisplay',
  displayName: '数字展示',
  icon: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/nulmlbebo/product_insight/numberinput.png',
  group: '通用展示组件',
  width: '100px',
  height: '100px',
  heightType: 'fit',
});
