/* eslint-disable react/destructuring-assignment */
/* eslint-disable @typescript-eslint/naming-convention */
import { CSSProperties, FC, useMemo } from 'react';
import { createLanderComponent, type UIContext } from '@ecom/lander-ui-runtime-usage';
import { NumberDisplay } from '@ecom/product-insights-components';
// !请注意不要直接引用setting文件

export interface NumberDisplayProps {
  'format/ratio': '%' | 'pp' | undefined;
  'format/useUnit': boolean;
  'format/fixed': number;
  'styles/color': 'negative' | 'positive' | undefined;
  'styles/prefix': 'arrow';
}

export interface FontStyle {
  'style/size': number;
  'style/color': string;
  'style/textWeight': number;
  'style/cursor': string;
  'style/customStyle': CSSProperties;
}

export interface NumberDisplayCompProps extends UIContext, NumberDisplayProps {
  value: number;
  fontStyle: FontStyle;
}

export const NumberDisplayComp: FC<NumberDisplayCompProps> = props => {
  const { style = { width: '100px', height: '100px' }, fontStyle = {} as FontStyle } = props;

  const customizeStyle = useMemo(() => {
    const baseStyle: CSSProperties = { ...fontStyle['style/customStyle'] };
    if (fontStyle['style/size']) {
      baseStyle.fontSize = fontStyle['style/size'];
    }
    if (fontStyle['style/color']) {
      baseStyle.color = fontStyle['style/color'];
    }
    if (fontStyle['style/textWeight']) {
      baseStyle.fontWeight = fontStyle['style/textWeight'];
    }
    if (fontStyle['style/cursor']) {
      baseStyle.cursor = fontStyle['style/cursor'];
    }
    return baseStyle;
  }, [fontStyle]);

  return (
    // 必须在组件根节点下应用props中的style属性，LanderCommon中配置的组件宽高等属性将会通过该属性传递
    <div style={style}>
      <NumberDisplay
        value={props.value}
        format={{
          ratio: props['format/ratio'],
          useUnit: props['format/useUnit'],
          fixed: props['format/fixed'],
        }}
        styles={{ color: props['styles/color'], prefix: props['styles/prefix'] }}
        style={customizeStyle}
      />
    </div>
  );
};

export default createLanderComponent<NumberDisplayCompProps>(NumberDisplayComp);
