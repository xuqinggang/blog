import edenxConfig from '../edenx.config';
import { name } from './package.json';

const config = edenxConfig(name);
console.log(`🦁 [config] `, JSON.stringify(config, null, 2));

export default config;
