import { StorySetting } from '@ecom/lander-ui-setters';
import SettingConfig from '@/index.setting';
import '@ecom/auxo/es/styles/index.less';

export const Normal = () => <StorySetting config={SettingConfig} />;

export default {
  title: 'AiConclusion Setting',
};
