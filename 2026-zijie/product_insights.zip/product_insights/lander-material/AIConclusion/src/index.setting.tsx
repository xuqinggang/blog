import { createLanderForm, type ISettings } from '@ecom/lander-ui-setters';

// Field中的name不可使用lander的保留字段，保留字段有：style、visible、name、cellId、componentName；也不可使用__开头的字符
const Setting: ISettings = {
  props: [
    {
      type: 'Void',
      title: '基础',
      decorator: 'Block',
      children: [
        {
          type: 'Union',
          title: '标题',
          name: 'title',
          defaultValue: 'AI 结论',
        },
        {
          type: 'Union',
          title: '模块ID',
          name: 'moduleId',
          defaultValue: '',
        },
        {
          type: 'Union',
          title: '高度限制',
          name: 'heightLimit',
          defaultValue: 0,
        },
        {
          type: 'Union',
          title: '请求参数',
          name: 'requestParams',
          defaultValue: {},
        },
        {
          type: 'Union',
          title: '域名前缀',
          name: 'domainPrefix',
          defaultValue: '',
        },
      ],
    },
  ],
  events: [
    {
      label: '点击',
      value: 'Click',
    },
  ],
  style: true,
};

export default createLanderForm(Setting);
