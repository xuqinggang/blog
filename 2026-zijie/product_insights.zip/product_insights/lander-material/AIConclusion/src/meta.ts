import { defineMeta } from '@ecom/lander-ui-setters';

export default defineMeta({
  name: 'aiConclusion',
  displayName: 'AI结论',
  icon: 'https://p3-play.byteimg.com/tos-cn-i-6swn9abqfj/5e530c3f53a7ba27b08a54883415b4b7.svg~tplv-6swn9abqfj-image.image',
  group: '通用展示组件',
  width: '100px',
  height: '100px',
  heightType: 'fit',
});
