import { FC } from 'react';

import { ButtonProps as AuxoButtonProps } from '@ecom/auxo';
import { createLanderComponent, type UIContext } from '@ecom/lander-ui-runtime-usage';
import { AIConclusionWrapper } from '@ecom/product-insights-components';
// !请注意不要直接引用setting文件

export interface AiConclusionProps extends UIContext {
  text: string;
  size: AuxoButtonProps['size'];
  title: string;
  moduleId: string;
  heightLimit: number;
  requestParams: Record<string, string>;
  domainPrefix?: string;
}

export const AiConclusion: FC<AiConclusionProps> = props => {
  const {
    style = { width: '100px', height: '100px' },
    title,
    moduleId,
    heightLimit,
    requestParams,
    domainPrefix,
  } = props;

  return (
    // 必须在组件根节点下应用props中的style属性，LanderCommon中配置的组件宽高等属性将会通过该属性传递
    <div style={style}>
      <AIConclusionWrapper
        id={moduleId as any}
        title={title}
        heightLimit={heightLimit}
        req={requestParams}
        domainPrefix={domainPrefix}
      />
    </div>
  );
};

export default createLanderComponent<AiConclusionProps>(AiConclusion);
