import { FC } from 'react';
import { createLanderComponent, type UIContext } from '@ecom/lander-ui-runtime-usage';
import { ButtonProps as AuxoButtonProps } from '@ecom/auxo';
import { FlightFilter, FlightFilterProps } from '@ecom/product-insights-components';
// !请注意不要直接引用setting文件

export interface FlightSelectorProps extends UIContext, FlightFilterProps {
  text: string;
  size: AuxoButtonProps['size'];
  fieldName?: string;
}

export const FlightSelector: FC<FlightSelectorProps> = props => {
  const { fieldName = 'flight', flightId, metaInfo = {}, style = { width: '100px', height: '100px' } } = props;

  if (!flightId) {
    return null;
  }

  return (
    // 必须在组件根节点下应用props中的style属性，LanderCommon中配置的组件宽高等属性将会通过该属性传递
    <div style={style}>
      <FlightFilter name={fieldName} flightId={flightId} metaInfo={metaInfo} />
    </div>
  );
};

export default createLanderComponent<FlightSelectorProps>(FlightSelector);
