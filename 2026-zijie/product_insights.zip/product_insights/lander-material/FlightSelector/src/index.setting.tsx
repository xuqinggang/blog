import { type ISettings, createLanderForm } from '@ecom/lander-ui-setters';

// Field中的name不可使用lander的保留字段，保留字段有：style、visible、name、cellId、componentName；也不可使用__开头的字符
const Setting: ISettings = {
  props: [
    {
      type: 'Void',
      title: '基础',
      decorator: 'Block',
      children: [
        {
          type: 'Union',
          title: '字段名',
          name: 'fieldName',
          defaultValue: '',
        },

        {
          type: 'Union',
          title: '实验ID',
          name: 'flightId',
          defaultValue: '',
        },

        {
          type: 'Union',
          title: '实验信息',
          name: 'metaInfo',
          defaultValue: {},
        },
      ],
    },
  ],
  events: [
    {
      label: '点击',
      value: 'Click',
    },
  ],
  style: true,
};

export default createLanderForm(Setting);
