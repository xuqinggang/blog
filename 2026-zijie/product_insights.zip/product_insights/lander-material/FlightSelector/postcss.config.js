module.exports = {
  plugins: {
    tailwindcss: require('../tailwind.config'),
    autoprefixer: {},
  },
};
