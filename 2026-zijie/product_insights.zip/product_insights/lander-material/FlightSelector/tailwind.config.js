module.exports = require('../tailwind.config');
