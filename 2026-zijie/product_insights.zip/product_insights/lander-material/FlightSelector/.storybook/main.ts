import type { StorybookConfig } from '@edenx/storybook';
import NodePolyfillPlugin from 'node-polyfill-webpack-plugin';

const config: StorybookConfig = {
  stories: ['../stories/**/*.stories.@(js|jsx|ts|tsx)'],
  addons: ['@storybook/addon-essentials'],
  framework: {
    name: '@edenx/storybook',
    options: {
      bundler: 'rspack',
      builderConfig: {
        source: {
          alias: {
            react: require.resolve('react'),
            'react-dom': require.resolve('react-dom'),
          },
        },
        tools: {
          postcss: {
            postcssOptions: {
              plugins: [require('tailwindcss')],
            },
          },
          less: {
            lessOptions: {
              javascriptEnabled: true,
              math: 'always',
            },
          },
          rspack: {
            plugins: [new NodePolyfillPlugin()],
          },
        },
      },
    },
  },
  typescript: {
    reactDocgen: 'react-docgen',
  },
};

export default config;
