import edenxConfig from '../edenx.config';

import { name } from './package.json';

export default edenxConfig(name);
