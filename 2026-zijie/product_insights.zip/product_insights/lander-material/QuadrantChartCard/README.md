# 货盘复盘-四象限图

## changelog

### v1.0.0-alpha.9

限定卡片宽度

### v1.0.0-alpha.8

增加操作按钮占位，满足产品诉求

### v1.0.0-alpha.7

增加 `targetLimit` 参数，用于限制主指标数量
