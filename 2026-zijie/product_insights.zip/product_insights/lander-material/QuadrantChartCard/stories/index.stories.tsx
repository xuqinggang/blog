import { StoryIndex } from '@ecom/lander-ui-runtime-usage';

import IndexConfig from '@/index';

export const Normal = () => <StoryIndex config={IndexConfig} props={{ text: '按钮', size: 'middle' } as any} />;

export default {
  title: 'QuadrantChartCard',
};
