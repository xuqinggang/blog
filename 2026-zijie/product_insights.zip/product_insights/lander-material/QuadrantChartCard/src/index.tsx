import { FC, useMemo } from 'react';

import { Button, Tooltip } from '@ecom/auxo';
import { createLanderComponent, type UIContext } from '@ecom/lander-ui-runtime-usage';
import {
  CommonAnalysisRequest,
  LanderComponentWrapper,
  LanderComponentWrapperProps,
  QuadrantChartCard as QuadrantChartCardComp,
  QuadrantChartGroup,
  ResizedPlaceholder,
} from '@ecom/product-insights-components';
import { ItemDataList } from '@ecom/product-insights-components/dist/types/api/product/namespaces/common_response';

// !请注意不要直接引用setting文件

export interface QuadrantChartCardProps extends LanderComponentWrapperProps, UIContext {
  data?: ItemDataList;
  xLabel?: string;
  yLabel?: string;
  baseParams: CommonAnalysisRequest;
  mainMetricsCount?: number;
}

export const QuadrantChartCard: FC<QuadrantChartCardProps> = props => {
  const {
    style = { width: '100px', height: '100px' },
    data,
    xLabel,
    yLabel,
    loading,
    hasError,
    baseParams,
    mainMetricsCount,
  } = props;

  const renderList = useMemo(() => {
    return [
      data?.item_data_list?.find(item => item.item_name === 'first_quadrant'),
      data?.item_data_list?.find(item => item.item_name === 'second_quadrant'),
      data?.item_data_list?.find(item => item.item_name === 'third_quadrant'),
      data?.item_data_list?.find(item => item.item_name === 'fourth_quadrant'),
    ];
  }, [data?.item_data_list]);

  const hasData = renderList.filter(Boolean).length > 0;

  if (!hasData) {
    return <ResizedPlaceholder />;
  }

  return (
    // 必须在组件根节点下应用props中的style属性，LanderCommon中配置的组件宽高等属性将会通过该属性传递
    <div style={style} className="w-full felx justify-center items-center">
      <LanderComponentWrapper loading={loading} hasError={hasError}>
        <QuadrantChartGroup xLabels={[`低${xLabel}`, `高${xLabel}`]} yLabels={[`低${yLabel}`, `高${yLabel}`]}>
          {renderList?.map((item, idx) =>
            item ? (
              <QuadrantChartCardComp
                key={item?.item_name}
                type={item?.item_name === 'fourth_quadrant' ? 'warn' : idx === 2 ? 'alert' : undefined}
                data={item}
                baseParams={baseParams}
                targetLimit={mainMetricsCount}
                operation={
                  <div className="flex gap-2 flex-row items-center">
                    <Tooltip title="即将上线，敬请期待">
                      <Button type="link" disabled>
                        商品画像
                      </Button>
                    </Tooltip>

                    <Tooltip title="即将上线，敬请期待">
                      <Button type="link" disabled>
                        标记商品
                      </Button>
                    </Tooltip>

                    <Tooltip title="即将上线，敬请期待">
                      <Button type="link" disabled>
                        存为货盘
                      </Button>
                    </Tooltip>

                    {['first_quadrant', 'second_quadrant'].includes(item?.item_name || '') ? (
                      <Tooltip title="即将上线，敬请期待">
                        <Button type="link" disabled>
                          流量扶持
                        </Button>
                      </Tooltip>
                    ) : null}
                    {['third_quadrant'].includes(item?.item_name || '') ? (
                      <>
                        <Tooltip title="即将上线，敬请期待">
                          <Button type="link" disabled>
                            诊断归因
                          </Button>
                        </Tooltip>
                        <Tooltip title="即将上线，敬请期待">
                          <Button type="link" disabled>
                            汰换商品
                          </Button>
                        </Tooltip>
                      </>
                    ) : null}
                  </div>
                }
              />
            ) : (
              <div key={idx}>
                <ResizedPlaceholder />
              </div>
            ),
          )}
        </QuadrantChartGroup>
      </LanderComponentWrapper>
    </div>
  );
};

export default createLanderComponent<QuadrantChartCardProps>(QuadrantChartCard);
