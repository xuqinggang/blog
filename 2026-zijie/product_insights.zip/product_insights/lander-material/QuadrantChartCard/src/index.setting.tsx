import { createLanderForm, type ISettings } from '@ecom/lander-ui-setters';
import { LanderComponentWrapperMeta } from '@ecom/product-insights-components';

// Field中的name不可使用lander的保留字段，保留字段有：style、visible、name、cellId、componentName；也不可使用__开头的字符
const Setting: ISettings = {
  props: [
    {
      type: 'Union',
      title: '数据',
      name: 'data',
      defaultValue: {},
    },
    {
      type: 'Union',
      title: 'x轴名称',
      name: 'xLabel',
      defaultValue: '',
    },
    {
      type: 'Union',
      title: 'y轴名称',
      name: 'yLabel',
      defaultValue: '',
    },

    {
      type: 'Union',
      title: '筛选参数',
      name: 'baseParams',
      defaultValue: {},
    },
    {
      type: 'Union',
      title: '主指标数量',
      name: 'mainMetricsCount',
      defaultValue: 2,
    },

    ...LanderComponentWrapperMeta.props,
  ],
  events: [
    {
      label: '点击',
      value: 'Click',
    },
  ],
  style: true,
};

export default createLanderForm(Setting);
