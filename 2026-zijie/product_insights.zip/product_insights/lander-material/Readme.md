| [参考文档](https://lander.bytedance.net/doc-pro/3vflb831/hnxds1z0?_lang=zh#0212ee02)

# 1. 安装 lander-cli

使用以下命令安装 lander-cli， 命令为`lander`

```bash
npm install -g @ecom/lander-cli
```

# 2. 创建新的 lander 项目

**在项目根目录下**， 使用以下命令创建新的 lander 项目， 文件夹中包含`eden.monorepo.json`文件， 如果检测不到该文件， 会出现报错。

```bash
lander add -s
```

按照脚手架完成项目创建后，项目信息会被自动添加到[eden.monorepo.json](../eden.monorepo.json)中，如果要删除项目，需要同时清理文件中的子项目配置

# 3. 开发 lander 物料

## 1. 开启调试信息 server

在本地开启 lander 物料的调试信息 server，在当前目录下执行

```bash
pnpm run serve
```

这个命令会开启一个静态文件服务， 可以通过 localhost:8686 访问文件夹中的文件， 8686 端口以及文件名是可以改变的，如果遇到冲突可以更换成其他端口， 与调试时使用的地址保持一致即可。

物料的映射信息存储在[serve.mock.json](../serve.mock.json)中，增加物料后，在这个文件中增加对应的映射。

## 2. 代码编译

在项目的根目录下执行，进行代码编译

```bash
pnpm run build:watch
```

## 3. 调试 lander 物料

在 lander 的编辑器中，在 Url 中拼接

```
&__lander_debug=true&serve=http://localhost:8686/serve.mock.json
```

也可以直接使用
[测试页面](https://lander.bytedance.net/app/editor-pro?pageId=0xRdCy_bm3ee&__lander_editor_version=new&__lander_debug=true&serve=http://localhost:8686/serve.mock.json)

---

完成以上流程，应该可以在 lander 编辑器中看到调试的物料
![img](https://lf3-static.bytednsdoc.com/obj/eden-cn/nulmlbebo/product_insight/Snipaste_2025-09-25_17-50-02.png)

4. 物料发布

- 发布 npm 包
- 使用`lander register`将发布后的包注册到 lander 上
