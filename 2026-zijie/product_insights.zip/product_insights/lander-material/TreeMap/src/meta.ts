import { defineMeta } from '@ecom/lander-ui-setters';

export default defineMeta({
  name: 'treeMap',
  displayName: '树图',
  icon: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/nulmlbebo/product_insight/treemap.png',
  group: '货盘复盘/数据展示',
  width: '100px',
  height: '100px',
  heightType: 'fit',
  stateProperties: {
    activeNode: {
      desc: '当前点击选中的节点',
    },
  },
});
