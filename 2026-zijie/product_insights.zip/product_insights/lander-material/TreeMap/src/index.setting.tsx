import { createLanderForm, type ISettings } from '@ecom/lander-ui-setters';

// Field中的name不可使用lander的保留字段，保留字段有：style、visible、name、cellId、componentName；也不可使用__开头的字符
const Setting: ISettings = {
  props: [
    {
      type: 'Void',
      title: '基础',
      decorator: 'Block',
      children: [
        {
          type: 'Union',
          title: '数据',
          name: 'data',
          defaultValue: [],
        },
        {
          type: 'String',
          title: '图表类型',
          name: 'chartType',
          defaultValue: 'tree',
          setter: 'ChoiceSetter',
          setterProps: {
            options: [
              { value: 'tree', label: '树图' },
              { value: 'line', label: '条状比例' },
            ],
          },
        },
      ],
    },
  ],
  events: [
    {
      label: '点击树图',
      value: 'click_map_node',
    },
  ],
  style: true,
};

export default createLanderForm(Setting);
