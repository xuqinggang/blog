import { FC } from 'react';

import { createLanderComponent, type UIContext, useGlobalEvent, useGlobalState } from '@ecom/lander-ui-runtime-usage';
import { TreeMapBar, TreeMapChart } from '@ecom/product-insights-components';

// !请注意不要直接引用setting文件
export interface TreeMapProps extends UIContext {
  data: {
    name: string;
    value: number;
  }[];
  chartType: 'tree' | 'line';
}

export const TreeMap: FC<TreeMapProps> = props => {
  const { data, chartType, style = { width: '100px', height: '100px' } } = props;
  const triggerEvent = useGlobalEvent();
  const [_, setActiveNode] = useGlobalState({
    key: 'activeNode',
    defaultValue: null as unknown,
  });
  const handleClick = (item: unknown) => {
    setActiveNode && setActiveNode(item);
    setTimeout(() => {
      triggerEvent('events', 'click_map_node');
    }, 100);
  };
  return (
    // 必须在组件根节点下应用props中的style属性，LanderCommon中配置的组件宽高等属性将会通过该属性传递
    <div style={style}>
      {chartType === 'line' ? <TreeMapBar data={data} /> : <TreeMapChart data={data} onClick={handleClick} />}
    </div>
  );
};

export default createLanderComponent<TreeMapProps>(TreeMap);
