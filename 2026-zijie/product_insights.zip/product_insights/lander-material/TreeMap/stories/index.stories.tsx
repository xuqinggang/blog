import IndexConfig from '@/index';
import { StoryIndex } from '@ecom/lander-ui-runtime-usage';

export const Normal = () => <StoryIndex config={IndexConfig} props={{ text: '按钮', size: 'middle' } as any} />;

export default {
  title: 'TreeMap',
};
