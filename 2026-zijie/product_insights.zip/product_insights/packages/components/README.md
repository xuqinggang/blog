# @ecom/product-insights-components

## Get Started

按开发环境的要求，运行和调试项目

运行和调试组件

```
pnpm run dev
```

按照社区规范和最佳实践，生成构建产物

```
pnpm run build
```

继续创建更多项目要素

```
pnpm run new
```

