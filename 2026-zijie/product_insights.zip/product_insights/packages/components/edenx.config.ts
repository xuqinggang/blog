import { defineConfig, moduleTools } from '@edenx/module-tools';
import { modulePluginDoc } from '@edenx/plugin-module-doc';
import { tailwindcssPlugin } from '@edenx/plugin-tailwind';

export default defineConfig({
  plugins: [
    moduleTools(),
    modulePluginDoc({
      doc: {
        base: '/insight_components',
      },
    }),
    tailwindcssPlugin(),
  ],
  buildPreset: 'npm-component',
  buildConfig: {
    externals: ['@ecom/auxo', 'React', 'ReactDOM', '@ecop/user', 'axios'],
  },
  /** 推荐使用 tailwind.config.{ts,js} 文件进行配置，两者都配置的情况下style.tailwindcss 定义的配置会优先生效，并覆盖 tailwind.config.{ts,js} 中定义的内容 */
  // buildConfig: {
  //   style: {
  //     tailwindcss: {},
  //   },
  // },
});
