/* eslint-disable @ecom/security-not-http */
const domains = ['ecop.bytedance.net'];

const fs = require('fs');
const path = require('path');


// const scanFolder = (folder) => {
//   const files = fs.readdirSync(folder);
//   const folders = files.filter(file => fs.statSync(path.join(folder, file)).isDirectory());

//   const paths = files.map()

//   return mdxFiles;
// }

const docRoot = path.resolve(__dirname, './docs');

const files = fs.readdirSync(docRoot);
const folders = files.map(file => file.replace('.mdx', ''));

let rewrites = {};

domains.forEach(host => {
  const paths = Object.fromEntries(
    folders.map(folder => [`https://${host}/${folder}`, `http://localhost:3000/${folder}`]),
  );

  rewrites = {
    ...rewrites,
    ...paths,

    [`https://${host}/static`]: 'http://localhost:3000/static',
    'wss://ecop.bytedance.net/rsbuild-hmr': 'ws://localhost:3000/rsbuild-hmr',
  };
});

module.exports = {
  domains,
  proxy: {
    urlRewrite: {
      ...rewrites,
    },
    headerActions: [],
  },
};

console.log('RELOAD===>');
console.log(rewrites);
