module.exports = {
  extends: [require.resolve('@ecom/product-insights-config/eslintrc.browser')],
  parserOptions: { tsconfigRootDir: __dirname },
};
