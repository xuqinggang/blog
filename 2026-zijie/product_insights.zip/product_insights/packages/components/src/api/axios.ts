import { AxiosInstance } from 'axios';

import { message } from '@ecom/auxo';
import { AxiosRequest, AxiosRequest as EcopAxiosRequest } from '@ecom/ecop-op-subsystem-sdk';

const { requestBridge } = window.GarfishBridge ?? {};

const AxiosService = (requestBridge?.AxiosRequest || EcopAxiosRequest) as typeof AxiosRequest;

interface RequestResp {
  data?: any;
  st?: number;
  code?: number;
  msg: string;
  BaseResp?: {
    StatusCode?: number;
    StatusMessage?: string;
  };
}

const interceptors = [
  {
    success: (resp: { data: RequestResp }) => {
      const { msg, code, BaseResp } = resp.data ?? {};

      if ((BaseResp && BaseResp?.StatusCode !== 0) || code) {
        message.error(msg || BaseResp?.StatusMessage || '网络错误');
        return Promise.reject(
          new Error(JSON.stringify({ msg: msg || BaseResp?.StatusMessage || '网络错误', code: BaseResp?.StatusCode })),
        );
      }

      return Promise.resolve(resp.data);
    },
    error: (err: any) => {
      message.error(err.msg || '网络错误');
      return Promise.reject(err);
    },
  },
];

const service = new AxiosService({
  baseURL: '',
  interceptors: interceptors as any,
});

const axios = service.axios as AxiosInstance;

export default axios;
