import ArcticService from './arctic';
import axios from './axios';
import ProductService from './product';
import SubscribeService from './subscribe';
import EcopService from './ecop';

const BASE_URL = '';

export const productClient = new ProductService<{ headers: any }>({
  baseURL: BASE_URL,
  request(params, options = { headers: {} }) {
    return axios.request({ ...params, ...options });
  },
});

export const arcticClient = new ArcticService<{ headers: any }>({
  baseURL: BASE_URL,
  request(params, options = { headers: {} }) {
    return axios.request({ ...params, ...options });
  },
});

export const subscribeClient = new SubscribeService<{ headers: any }>({
  baseURL: BASE_URL,
  request(params, options = { headers: {} }) {
    return axios.request({ ...params, ...options });
  },
});

export const ecopClient = new EcopService<{ headers: any }>({
  baseURL: BASE_URL,
  request(params, options = { headers: {} }) {
    return axios.request({ ...params, ...options });
  },
});
