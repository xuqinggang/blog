import { message } from '@ecom/auxo';

const { requestBridge } = window.GarfishBridge ?? {};

const AxiosService = requestBridge?.AxiosRequest || (window as any).Axios?.Axios;

interface RequestResp {
  data?: any;
  st?: number;
  code?: number;
  msg: string;
  BaseResp?: {
    StatusCode?: number;
    StatusMessage?: string;
  };
}

const interceptors = [
  {
    success: (resp: { data: RequestResp }) => {
      const { msg, code, BaseResp } = resp.data ?? {};

      if ((BaseResp && BaseResp?.StatusCode !== 0) || code) {
        message.error(msg || BaseResp?.StatusMessage || '网络错误');
        return Promise.reject(
          new Error(JSON.stringify({ msg: msg || BaseResp?.StatusMessage || '网络错误', code: BaseResp?.StatusCode })),
        );
      }

      return Promise.resolve(resp.data);
    },
    error: (err: any) => {
      message.error(err.msg || '网络错误');
      return Promise.reject(err);
    },
  },
];

const { axios } = AxiosService
  ? new AxiosService({
      baseURL: '',
      interceptors,
      timeout: 0,
    })
  : {
      axios: { request: () => Promise.reject(new Error('AxiosService is not available')) },
    };

const bridgeRequest = axios;
export { bridgeRequest };
export default bridgeRequest;
