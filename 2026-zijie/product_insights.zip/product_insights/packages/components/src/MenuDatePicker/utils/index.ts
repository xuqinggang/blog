import { ManipulateType } from 'dayjs';

import { DateType } from '~/api/product/namespaces/base';

export enum DatePickerType {
  WEEK = 'week',
  MONTH = 'month',
  DATE = 'date',
}

export function transformDateType(type: DatePickerType, isUnit = false): DateType | ManipulateType {
  switch (type) {
    case DatePickerType.MONTH: {
      return isUnit ? 'month' : DateType.MONTH;
    }
    case DatePickerType.WEEK: {
      return isUnit ? 'week' : DateType.WEEK;
    }
    case DatePickerType.DATE:
    default: {
      return isUnit ? 'day' : DateType.DAY;
    }
  }
}
