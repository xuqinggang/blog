/* eslint-disable @ecom/no-chinese */
import React, { forwardRef, memo, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { useMemoizedFn } from 'ahooks';
import classNames from 'classnames';
import dayjs, { Dayjs, ManipulateType } from 'dayjs';
import dayjsLocal from 'dayjs/locale/zh-cn';
import updateLocale from 'dayjs/plugin/updateLocale';
import { cloneDeep } from 'lodash-es';

import { DatePicker, Divider, Icon, Menu, message, TimeRangePickerProps } from '@ecom/auxo';

import { DatePickerType, transformDateType } from './utils';

import './index.scss';

import { DataReadyTime } from '~/api/product/namespaces/dimensions';
import { getRecentDate } from '~/utils';

dayjs.extend(updateLocale);
dayjs.locale(dayjsLocal);
dayjs.updateLocale('zh-cn', {
  weekStart: 1,
});

export type RangeTime = [Dayjs | null, Dayjs | null] | null | undefined;

export interface MenuDatePickerProps extends Omit<TimeRangePickerProps, 'disabledDate' | 'onChange'> {
  isProdAnalysis?: boolean; // 是否是货品分析
  defaultKey?: DatePickerType;
  activeKey?: DatePickerType;
  showRecentSelect?: boolean; // 是否展示「近x天」的选择，默认不展示
  defaultRecentDate?: RecentDateType;
  recentDate?: RecentDateType;
  recentDateList?: RecentDate[]; // 「近x天」的快捷选项
  disabledMonth?: boolean; // 禁用月份选择
  disabledWeek?: boolean; // 禁用周选择
  readyTime?: DataReadyTime | null; // 数据就绪时间
  onChange?: (value: RangeTime, type: DatePickerType, recentDate?: RecentDateType) => void;
  disabledDate?: (date: Dayjs, type?: DatePickerType, value?: RangeTime) => boolean;
  validateDate?: (date: RangeTime, activeKey: DatePickerType) => RangeTime; // 校验函数
}

export enum RecentDateType {
  ONE = '1', // 近1天
  THREE = '3', // 近3天
  SEVEN = '7', // 近7天
  FOURTEEN = '14', // 近14天
  THIRTY = '30', // 近30天
}

export interface RecentDate {
  title: string;
  value: RecentDateType;
}

export interface MenuDatePickerRef {
  activeKey: DatePickerType;
}

const allPickerType = [
  { key: DatePickerType.WEEK, title: '自然周' },
  { key: DatePickerType.MONTH, title: '自然月' },
  { key: DatePickerType.DATE, title: '自定义周期' },
];

const defaultRecentDateList: RecentDate[] = [
  { title: '近1天', value: RecentDateType.ONE },
  { title: '近3天', value: RecentDateType.THREE },
  { title: '近7天', value: RecentDateType.SEVEN },
  { title: '近14天', value: RecentDateType.FOURTEEN },
  { title: '近30天', value: RecentDateType.THIRTY },
];

export const MenuDatePicker = memo(
  forwardRef<MenuDatePickerRef, MenuDatePickerProps>(
    (
      {
        isProdAnalysis = false,
        showRecentSelect = false,
        onChange,
        format,
        disabledDate,
        defaultKey,
        activeKey: outerActiveKey,
        defaultRecentDate,
        recentDate: outerRecentDate,
        recentDateList = defaultRecentDateList,
        readyTime,
        validateDate,
        disabledMonth = false,
        disabledWeek = false,
        ...otherProps
      },
      ref,
    ) => {
      const { value } = otherProps;
      const [activeKey, setActiveKey] = useState<DatePickerType>(defaultKey || DatePickerType.WEEK);
      const [recentDate, setRecentDate] = useState<RecentDateType | undefined>(defaultRecentDate);
      const [choseDate, setChoseDate] = useState<RangeTime>([null, null]);
      const [open, setOpen] = useState(false);
      const unit = transformDateType(activeKey, true) as ManipulateType;
      const valueInit = useRef(false);

      // 设置ChoseDate初始值
      useEffect(() => {
        if (valueInit.current) {
          return;
        }

        if (value) {
          setChoseDate(value);
          valueInit.current = true;
        }
      }, [value]);

      // 将activeKey暴露给父组件
      useImperativeHandle(
        ref,
        () => ({
          activeKey,
        }),
        [activeKey],
      );

      // 选择了近x天，则切换到自定义周期
      useEffect(() => {
        if (recentDate) {
          setActiveKey(DatePickerType.DATE);
        }
      }, [recentDate]);

      // recentDate受控
      useEffect(() => {
        setRecentDate(outerRecentDate);
      }, [outerRecentDate]);

      const panelRender = useMemoizedFn((origin: React.ReactNode) => {
        return (
          <div style={{ display: 'flex', minWidth: 391 }}>
            <div className="w-[152px]">
              <Menu
                mode="vertical"
                selectedKeys={[activeKey]}
                onClick={e => {
                  setActiveKey(e.key as DatePickerType);
                  onChange?.([null, null], e.key as DatePickerType);
                  setChoseDate([null, null]);
                }}
              >
                {allPickerType.map(type => {
                  if (disabledMonth && type.key === 'month') {
                    return <></>;
                  }
                  if (disabledWeek && type.key === 'week') {
                    return <></>;
                  }

                  return (
                    <Menu.Item key={type.key} className="hover:bg-[#ebf3ff]" style={{ padding: '6px 8px 6px 12px' }}>
                      <div
                        className={classNames('flex items-center h-7 text-[#252931] hover:font-medium', {
                          'font-medium': type.key === activeKey,
                        })}
                      >
                        <span className="flex-1 leading-7">{type.title}</span>
                        <Icon.RightIcon />
                      </div>
                    </Menu.Item>
                  );
                })}
              </Menu>
              {showRecentSelect && (
                <>
                  <Divider className="mt-3 mb-3" />
                  <div className="menu-date-picker-recent">
                    {recentDateList.map(({ title, value }) => {
                      return (
                        <div
                          key={value}
                          className={classNames('menu-date-picker-recent__item', {
                            'menu-date-picker-recent__item--active': value === recentDate,
                          })}
                          onClick={() => {
                            if (!readyTime) {
                              message.error('数据未就绪，请稍后再试');
                              return;
                            }

                            // 计算最近x天的时间
                            const { startDate, endDate } = getRecentDate(readyTime, Number(value));

                            if (validateDate) {
                              // 校验所选的日期
                              const date = validateDate([startDate, endDate], DatePickerType.DATE);
                              if (!date) {
                                setOpen(false);
                                return;
                              }

                              setChoseDate(date);
                              onChange?.(date, DatePickerType.DATE, value);
                            } else {
                              setChoseDate([startDate, endDate]);
                              onChange?.([startDate, endDate], DatePickerType.DATE, value);
                            }

                            setRecentDate(value);
                            setOpen(false);
                          }}
                        >
                          {title}
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
            <div className="flex-1">{origin}</div>
          </div>
        );
      });
      const handleClick = useMemoizedFn(() => {
        setOpen(true);
        outerActiveKey && setActiveKey(outerActiveKey);
      });
      const handleBlur = useMemoizedFn(() => {
        setOpen(false);
      });
      const handleChange = useMemoizedFn((v: RangeTime) => {
        if (isProdAnalysis && (activeKey === DatePickerType.WEEK || activeKey === DatePickerType.MONTH)) {
          return;
        }

        const start = v?.[0] ? dayjs(v[0]).startOf(unit) : null;
        const end = v?.[1] ? dayjs(v[1]).endOf(unit) : null;

        if (validateDate) {
          // 校验所选的日期
          const date = validateDate?.([start, end], activeKey);
          if (!date) {
            setOpen(false);
            return;
          }

          onChange?.(date, activeKey);
        } else {
          onChange?.([start, end], activeKey);
        }

        setOpen(false);
      });
      const handleCalendarChange = useMemoizedFn((v, _, rangeInfo) => {
        setChoseDate(v);

        if (isProdAnalysis && (activeKey === DatePickerType.WEEK || activeKey === DatePickerType.MONTH)) {
          // 商品分析 & 周/月选择
          const validTime = rangeInfo.range === 'start' ? v?.[0] : v?.[1];
          if (!validTime) {
            return;
          }

          const start = cloneDeep(validTime).startOf(activeKey);
          const end = cloneDeep(validTime).endOf(activeKey);

          if (validateDate) {
            // 校验所选的日期
            const date = validateDate([start, end], activeKey);
            if (!date) {
              setOpen(false);
              return;
            }

            onChange?.(date, activeKey);
          } else {
            onChange?.([start, end], activeKey);
          }

          setOpen(false);
        }
      });
      const handleDisableDate = useMemoizedFn(date => {
        return disabledDate?.(date, activeKey, choseDate) ?? true;
      });
      return (
        <DatePicker.RangePicker
          {...otherProps}
          allowClear={false}
          open={open}
          format={['YYYY/MM/DD']}
          onClick={handleClick}
          onBlur={handleBlur}
          onChange={handleChange}
          onCalendarChange={handleCalendarChange}
          disabledDate={handleDisableDate}
          picker={activeKey as 'week' | 'month'}
          panelRender={panelRender}
        />
      );
    },
  ),
);

MenuDatePicker.displayName = 'MenuDatePicker';
