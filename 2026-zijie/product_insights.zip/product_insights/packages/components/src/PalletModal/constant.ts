import { DrawerOperationEnum } from './type';

export const DrawerOperationMap = {
  [DrawerOperationEnum.create]: {
    label: '新建',
  },
  [DrawerOperationEnum.edit]: {
    label: '编辑',
  },
  [DrawerOperationEnum.copy]: {
    label: '复制',
  },
  [DrawerOperationEnum.detail]: {
    label: '查看',
  },
};
