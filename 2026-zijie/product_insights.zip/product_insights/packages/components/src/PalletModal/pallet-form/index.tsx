import React from 'react';

import { Form, Input, Radio, Space } from '@ecom/auxo';

import { ProductInsightFilterPreviewFormDisplay } from '../../ProductInsightFilterPreview';
import { DrawerOperationEnum, PalletFormStore } from '../type';

import styles from './index.module.scss';

import { productClient } from '~/api';
import { GetDimensionListData } from '~/api/product/namespaces/dimensions';
import { DefaultEnumMap } from '~/filter-form/types';
import { PeopleFormDisplay, ValueDisplay } from '~/FormDisplay';

const PALLET_NAME_MAX_LEN = 50;

type PalletProps = {
  operationType: DrawerOperationEnum;
  // 初始表单信息 暂时不用
  initData?: Omit<PalletFormStore, 'prod_cnt_1d' | 'create_user_id'>;
  dimensionData?: GetDimensionListData | null;
  defaultEnumMap?: DefaultEnumMap;
};

type PalletFormRef = {
  validateFields: () => Promise<PalletFormStore | null>;
};

/**
 * 新建、编辑货盘表单
 */

const PalletForm = React.forwardRef((props: PalletProps, ref: React.Ref<PalletFormRef>) => {
  const [_form] = Form.useForm<PalletFormStore>();

  const { initData, operationType, defaultEnumMap, dimensionData } = props;
  const validateFields = React.useCallback(async () => {
    try {
      const data = await _form.validateFields();
      return {
        pool_name: data.pool_name || '',
        pool_type: data.pool_type,
        pool_rule: data.pool_rule,
      };
    } catch (err) {
      return null;
    }
  }, [_form]);

  React.useImperativeHandle(
    ref,
    () =>
      ({
        validateFields,
      } as PalletFormRef),
  );

  React.useEffect(() => {
    async function fetchData() {
      if (!initData?.pool_rule) {
        return;
      }
      const poolDetailRes = await productClient.QueryAnalysisPoolDetail({
        base_struct: initData?.pool_rule,
      } as any);
      const userInfo = window.GarfishBridge?.infoBridge?.getUserInfo();

      if (operationType === DrawerOperationEnum.create) {
        _form.setFieldsValue({
          pool_type: 1,
          pool_rule: initData?.pool_rule,
          create_user_id: userInfo?.employee_id,
          prod_cnt_1d: poolDetailRes.data?.prod_cnt_1d,
        });
      } else {
        _form.setFieldsValue({
          ...(initData || {}),
          create_user_id: userInfo?.employee_id,
          prod_cnt_1d: poolDetailRes.data?.prod_cnt_1d,
        });
      }
    }
    fetchData();
    return () => {
      _form.resetFields();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [operationType]);

  return (
    <div>
      <Form form={_form} className={styles.form}>
        <Space direction="vertical" size={16} className={styles.space}>
          <Form.Item
            labelCol={{ span: 4 }}
            wrapperCol={{ span: 20 }}
            label="货盘名称"
            rules={[
              { required: true, message: '此项是必填项' },
              {
                max: PALLET_NAME_MAX_LEN,
                message: `货盘名称最长为 ${PALLET_NAME_MAX_LEN} 字符`,
              },
            ]}
            name="pool_name"
          >
            <Input placeholder="请输入货盘名称" limit={PALLET_NAME_MAX_LEN} />
          </Form.Item>
          <Form.Item required label="货盘类型" name="pool_type" labelCol={{ span: 4 }} wrapperCol={{ span: 20 }}>
            <Radio.Group>
              <Radio value={1}>规则圈选</Radio>
            </Radio.Group>
          </Form.Item>
          <Form.Item label="圈选规则" name="pool_rule" labelCol={{ span: 4 }} wrapperCol={{ span: 20 }}>
            <ProductInsightFilterPreviewFormDisplay dimensionData={dimensionData} defaultEnumMap={defaultEnumMap} />
          </Form.Item>
          <Form.Item label="圈选商品预估数量" name="prod_cnt_1d" labelCol={{ span: 4 }} wrapperCol={{ span: 20 }}>
            <ValueDisplay />
          </Form.Item>
          <Form.Item label="创建人" name="create_user_id" labelCol={{ span: 4 }} wrapperCol={{ span: 20 }}>
            <PeopleFormDisplay />
          </Form.Item>
        </Space>
      </Form>
    </div>
  );
});

export function usePalletForm() {
  return React.useRef<PalletFormRef>(null);
}

export default PalletForm;
