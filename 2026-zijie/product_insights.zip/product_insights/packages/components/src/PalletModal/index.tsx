/* eslint-disable max-nested-callbacks */
/* eslint-disable @typescript-eslint/no-non-null-asserted-optional-chain */
/* eslint-disable @typescript-eslint/no-non-null-assertion */
import React from 'react';
import { useRequest } from 'ahooks';

import { Button, Drawer, message, Space, Spin } from '@ecom/auxo';

import { DrawerOperationMap } from './constant';
import PalletForm, { usePalletForm } from './pallet-form';
import { DrawerOperationEnum, PalletFormStore } from './type';

import styles from './index.module.scss';

import { productClient } from '~/api';
import { GetDimensionListData } from '~/api/product/namespaces/dimensions';
import { DefaultEnumMap } from '~/filter-form/types';
import withVisibility, { type PropsWithVisible } from '~/hocs/withVisibility';

export * from './type';

export type PalletDrawerProps = {
  operationType: DrawerOperationEnum;
  initData?: Partial<Omit<PalletFormStore, 'pool_prod_count' | 'create_user_id'>>;
  is_total_dim?: boolean;
  dimensionData?: GetDimensionListData | null;
  defaultEnumMap?: DefaultEnumMap;
  onSuccess?: (pool_id: string) => void;
};

/**
 * 新建、编辑货盘抽屉
 */
export function PalletDrawer(this: never, props: PropsWithVisible<PalletDrawerProps>) {
  const { visible, onCancel, onSuccess, is_total_dim, operationType, initData, dimensionData, defaultEnumMap } = props;
  const _formRef = usePalletForm();

  const { runAsync: create, loading: createLoading } = useRequest(
    productClient.CreateAnalysisPool.bind(productClient),
    {
      manual: true,
    },
  );

  const loading = createLoading;

  const getAlertPreMsg = React.useCallback(() => {
    return DrawerOperationMap[operationType] ? `${DrawerOperationMap[operationType].label}货盘` : '';
  }, [operationType]);

  const emitSuccess = React.useCallback(
    (pool_id: string, preMsg: string) => {
      if (onSuccess) {
        onSuccess?.(pool_id);
      } else {
        message.success(`${preMsg}成功`);
      }
      onCancel();
    },
    [onSuccess, onCancel],
  );

  const onSubmit = React.useCallback(async () => {
    if (loading) return;
    const data = await _formRef.current?.validateFields().catch(() => null);
    if (!data) return;

    const requestFn = create;
    try {
      const res = await requestFn({
        pool_name: data.pool_name!,
        pool_type: data.pool_type || 1, // 货盘类型 当前只有可能是规则货盘
        base_struct: data.pool_rule,
        is_total: is_total_dim,
        pool_source: 0, // 暂时默认0
      });
      if (res?.data) {
        emitSuccess(res?.data, getAlertPreMsg());
      }
    } catch (error) {
      message.error((error as Error)?.message || '网络错误，请重试');
    }
  }, [_formRef, create, emitSuccess, getAlertPreMsg, is_total_dim, loading]);

  const renderDrawerFooter = React.useMemo(() => {
    return (
      <Space className={styles.footer}>
        <Button onClick={onSubmit} loading={loading} type="primary">
          提交
        </Button>

        <Button onClick={onCancel} loading={loading}>
          取消
        </Button>
      </Space>
    );
  }, [loading, onCancel, onSubmit]);

  const renderTitle = React.useMemo(() => {
    return DrawerOperationMap[operationType] ? `${DrawerOperationMap[operationType].label}货盘` : '';
  }, [operationType]);

  return (
    <Drawer
      keyboard
      visible={visible}
      onCancel={onCancel}
      width={850}
      title={renderTitle}
      footer={renderDrawerFooter}
      destroyOnClose
    >
      <Spin spinning={loading}>
        <PalletForm
          ref={_formRef}
          initData={initData}
          operationType={operationType}
          defaultEnumMap={defaultEnumMap}
          dimensionData={dimensionData}
        />
      </Spin>
    </Drawer>
  );
}

export const OpenPalletDrawerButton = withVisibility(PalletDrawer)(Button);
