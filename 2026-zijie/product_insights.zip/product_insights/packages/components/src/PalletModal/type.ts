import { Int64 } from '~/api/product/namespaces/base';
import { ProductAnalysisBaseStruct } from '~/api/product/namespaces/dimensions';

export enum DrawerOperationEnum {
  create,
  edit,
  copy,
  detail,
}

export interface PalletFormStore {
  pool_name?: string;
  pool_type?: number;
  pool_rule?: ProductAnalysisBaseStruct;
  prod_cnt_1d?: Int64;
  create_user_id?: string;
}
