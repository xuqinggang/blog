import React, { FC } from 'react';
import classNames from 'classnames';

import styles from './index.module.scss';

export interface FilterBlockProps {
  className?: string;
  style?: React.CSSProperties;
  noMargin?: boolean;
}

export const FilterBlock: FC<FilterBlockProps> = ({ className, style, children, noMargin }) => {
  return (
    <div
      className={classNames('p-2 rounded-[4px] bg-[#F8F9FA] w-fit', { [styles.noMargin]: noMargin }, className)}
      style={style}
    >
      {children}
    </div>
  );
};
