import React, { useCallback, useLayoutEffect, useMemo, useState } from 'react';
import classNames from 'classnames';
import { debounce } from 'lodash-es';
import { createPortal } from 'react-dom';

import { Editor, EditorComponent, EditorEventType } from '@editor-kit/core';
import { DeltaSet } from '@editor-kit/delta';

import { IDirectoryItem, IRichTextEditor } from '../types';

import { Directory } from './components/directory';
import { modules } from './config/modules';
import { genRegister } from './config/plugins';
import { schema } from './config/schema';
import { getContentDirectory } from './services/get-content-directory';

import './index.less';

export const BaseEditor = (props: IRichTextEditor) => {
  const {
    editable = true,
    showToolbar = true,
    showDirectory = false,
    getEditor,
    defaultDeltas,
    placeholder,
    className,
    image,
    hyperlink,
    getDirectoryContainer,
  } = props;

  const [directory, setDirectory] = useState<IDirectoryItem[]>([]);
  const [directoryContainer, setDirectoryContainer] = useState<Element | null>(null);

  useLayoutEffect(() => {
    setTimeout(() => {
      const targetDirectoryContainer = getDirectoryContainer?.();
      if (targetDirectoryContainer) {
        setDirectoryContainer(targetDirectoryContainer);
      }
    }, 0);
  }, [getDirectoryContainer]);

  const register = useMemo(
    () => genRegister(showToolbar, editable, image, hyperlink),
    [editable, hyperlink, image, showToolbar],
  );

  const handleEditorInit = useCallback(
    (editor: Editor) => {
      if (getEditor) {
        getEditor(editor);
      }

      if (showDirectory) {
        editor.on(
          EditorEventType.PAINT,
          debounce(() => {
            const directory = getContentDirectory(editor);
            setDirectory(directory);
          }, 500),
        );
      }
    },
    [showDirectory, getEditor],
  );

  return (
    <div className="rich-text-editor" style={editable ? { border: '1px solid #dee0e3' } : undefined}>
      <div id="editor-kit-toolbar" />
      <EditorComponent
        className={classNames('rich-text-editor__content', className)}
        style={editable ? { padding: '16px 24px' } : undefined}
        editable={editable}
        copyable
        businessKey="product-insights"
        modules={modules}
        register={register}
        schema={schema}
        onInit={handleEditorInit}
        placeholder={placeholder}
        initData={defaultDeltas ? new DeltaSet(defaultDeltas) : undefined}
      />
      {showDirectory && directoryContainer && createPortal(<Directory items={directory} />, directoryContainer)}
    </div>
  );
};
