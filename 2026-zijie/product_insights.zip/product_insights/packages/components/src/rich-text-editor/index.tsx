import React from 'react';

import { DeltaSet, DeltaSetOptions } from '@editor-kit/delta';

import { BaseEditor } from './base-editor';
import { IRichTextEditor, IRichTextView } from './types';

// -----编辑器样式------
import '@editor-kit/core/dist/style/index.css';
// -----各插件默认样式------
// Align 插件默认样式
import '@editor-kit/plugins/dist/align/style/index.css';
// Table 插件默认样式
import '@editor-kit/plugins/dist/table/style/index.css';
import '@editor-kit/plugins/dist/table-ui/style/index.css';
// Checkbox 插件默认样式
import '@editor-kit/plugins/dist/checkbox/style/index.css';
// Heading 标题插件默认样式
import '@editor-kit/plugins/dist/heading/style/index.css';
// Hyperlinks 超链接插件默认样式
import '@editor-kit/plugins/dist/hyperlinks/style/index.css';
// Image 图片插件默认样式
import '@editor-kit/plugins/dist/image/style/index.css';
// Inline-code 内联代码插件默认样式
import '@editor-kit/plugins/dist/inline-code/style/index.css';
// 工具栏插件默认样式
import '@editor-kit/plugins/dist/toolbar-v2/style/index.css';
// codeblock 插件默认样式
import '@editor-kit/plugins/dist/codeblock/style/index.css';
// mention 缩进插件默认样式
import '@editor-kit/plugins/dist/mention/style/index.css';
// list 插件默认样式
import '@editor-kit/plugins/dist/list/style/pc.css';
// -----各插件默认样式------

export const RichTextEditor = (props: IRichTextEditor) => <BaseEditor {...props} />;

export const RichTextView = (props: IRichTextView) => (
  <BaseEditor
    showDirectory={true}
    editable={false}
    showToolbar={false}
    image={{ upload: () => Promise.resolve('') }}
    {...props}
  />
);

export const toDeltaSet = (value: DeltaSetOptions) => new DeltaSet(value);

export { Editor } from '@editor-kit/core';
