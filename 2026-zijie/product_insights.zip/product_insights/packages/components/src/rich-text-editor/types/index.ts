import { Editor } from '@editor-kit/core';
import { Deltas } from '@editor-kit/delta';

export interface IDirectoryItem {
  key: string; // delta的key
  text: string; // 标题
  depth: number; // 深度，用于缩进渲染，h1 -> 0、h2 -> 1
  node: HTMLElement; // 真实的dom节点，用于点击后scroll
}

export interface IImagePluginProps {
  upload: (file: File) => Promise<string>;
  onInsertSuccess?: (file: File) => void;
  onInsertError?: (e: Error, file: File) => void;
  onPasteSuccess?: (file: File, option: { srcUrl: string }) => void;
  onPasteError?: (e: Error, option: { srcUrl: string }) => void;
  onClick?: (src: string) => void;
}

export interface IHyperLinkPluginProps {
  onClick?: (url: string) => void;
}

export interface IRichTextEditor {
  /** 图片上传插件配置 */
  image?: IImagePluginProps;
  /** 超链接插件配置 */
  hyperlink?: IHyperLinkPluginProps;
  /** editor-kit className透传 */
  className?: string;
  /** 拿到editor实例，可以用上面的方法操作编辑器，如 获取数据，重新刷新等 */
  getEditor?: (editor: Editor) => void;
  /** 编辑初次渲染的内容 */
  defaultDeltas?: Deltas;
  /** 是否展示目录，默认是false */
  showDirectory?: boolean;
  /** 是否展示工具栏，默认是true */
  showToolbar?: boolean;
  /** 是否可编辑，默认是true */
  editable?: boolean;
  placeholder?: string;
  /** 目录渲染的container */
  getDirectoryContainer?: () => Element | null;
}

export type IRichTextView = Pick<
  IRichTextEditor,
  'defaultDeltas' | 'showDirectory' | 'getDirectoryContainer' | 'className' | 'getEditor' | 'image' | 'hyperlink'
>;
