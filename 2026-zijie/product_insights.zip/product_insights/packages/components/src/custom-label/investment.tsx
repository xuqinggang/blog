import { useState } from 'react';

import { Button, Spin, Tooltip } from '@ecom/auxo';

import { productClient } from '~/api';
import { EnumElement, RegisterDimensionType } from '~/api/product/namespaces/dimensions';

export enum InvestmentStatus {
  UN_SYNC = 0, // 未同步
  FINISH = 1, // 已同步
  SYNCING = 2, // 同步中
}

export interface InvestmentExtraInfo {
  investment_status: InvestmentStatus;
}

export interface CustomInvestmentLabelProps {
  label: React.ReactNode;
  enumValue: EnumElement;
}

export function CustomInvestmentLabel(props: CustomInvestmentLabelProps) {
  const { enumValue } = props;
  const { extra_info } = enumValue;
  const [status, setStatus] = useState<InvestmentStatus>(() => {
    try {
      const { investment_status } = JSON.parse(extra_info || '{}') as InvestmentExtraInfo;
      return investment_status;
    } catch (e) {
      return InvestmentStatus.UN_SYNC;
    }
  });
  const [loading, setLoading] = useState(false);
  const disabled = status !== InvestmentStatus.FINISH;

  async function handleSync() {
    if (status !== InvestmentStatus.UN_SYNC || !enumValue.code) {
      return;
    }

    try {
      setLoading(true);
      await productClient.RegisterNeedDumpDimension({
        entity_ids: [enumValue.code],
        register_dimension_type: RegisterDimensionType.InvestmentSelectProd,
      });

      // 切换为同步中状态
      setStatus(InvestmentStatus.SYNCING);
    } catch (e) {
      console.error('Sync investment error', e);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex items-center justify-between gap-[2px]">
      <Tooltip title={enumValue.name}>
        <span className="text-ellipsis overflow-hidden whitespace-nowrap">{enumValue.name}</span>
      </Tooltip>
      {disabled && (
        <Spin spinning={loading}>
          <Tooltip
            title={
              status === InvestmentStatus.SYNCING
                ? '同步中，预计次日完成'
                : '商品包来自招商选品，请点击同步，同步完成后即可分析'
            }
          >
            <Button
              className="flex-shrink-0"
              type="link"
              size="small"
              disabled={status === InvestmentStatus.SYNCING}
              onClick={() => {
                handleSync();
              }}
            >
              {status === InvestmentStatus.SYNCING ? '同步中' : '同步'}
            </Button>
          </Tooltip>
        </Spin>
      )}
    </div>
  );
}
