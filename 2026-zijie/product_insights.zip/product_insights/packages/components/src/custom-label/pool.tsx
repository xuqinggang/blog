import { useMemo } from 'react';

import { Button, Divider, Space, Tooltip } from '@ecom/auxo';
import { PeopleCard } from '@ecop/user';

import { EnumElement } from '~/api/product/namespaces/dimensions';
// import { openAnalysisPalletDetail } from '~/utils/openPage';

export enum CustomPoolLabelType {
  /** 自定义货盘 */
  CustomProdPool = 1,
  /** 选品大脑货盘 */
  ProdBrainPool = 2,
}

export interface CustomPoolLabelProps {
  label: React.ReactNode;
  enumValue: EnumElement;
  type: CustomPoolLabelType;
}

export function CustomPoolLabel(props: CustomPoolLabelProps) {
  const { label, enumValue, type } = props;
  const link = useMemo(() => {
    switch (type) {
      case CustomPoolLabelType.CustomProdPool: {
        return (
          <Button
            type="link"
            // onClick={() => openAnalysisPalletDetail({ pool_id: enumValue.code! }, false, true)}
          >{`查看货盘商品明细>`}</Button>
        );
      }
      case CustomPoolLabelType.ProdBrainPool: {
        return (
          <Button
            type="link"
            onClick={() => {
              enumValue.link_url &&
                (window.GarfishBridge?.actionBridge?.openInsideTag(enumValue.link_url) ??
                  window.open(enumValue.link_url));
            }}
          >{`查看选品大脑货盘>`}</Button>
        );
      }
      default: {
        return null;
      }
    }
  }, [enumValue, type]);

  return (
    <Tooltip
      color="#ffffff"
      title={
        <div style={{ color: '#333', padding: 10 }}>
          <div style={{ marginBottom: 16, fontWeight: 'bold', fontSize: 16 }}>{enumValue.name}</div>
          <Space direction="vertical" className="w-full">
            <Space>
              <span>ID: </span>
              <span>{enumValue.code}</span>
            </Space>
            <Space>
              <span>创建人:</span>
              <PeopleCard
                list={[
                  // @ts-ignore global
                  {
                    employee_id: enumValue.create_user_id,
                  },
                ]}
              />
            </Space>
            <Divider style={{ margin: '5px 0' }} />
            {link}
          </Space>
        </div>
      }
      placement="right"
    >
      {/* <div className="flex items-center justify-between">
        {label}
        <div
          className="cursor-pointer"
          onClick={() => {
            console.log('aaaaaaaa');
          }}
        >
          测试
        </div>
      </div> */}
      {label}
    </Tooltip>
  );
}
