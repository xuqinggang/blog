import { CSSProperties, FC, useMemo } from 'react';
import classNames from 'classnames';
import { isFunction, isNumber } from 'lodash-es';

import { formatNumber, NumberFormatOption } from '~/utils';
import { isNullOrUndefined } from '~/utils/is';

export interface NumberDisplayProps {
  className?: string;
  style?: CSSProperties;
  value: number;
  format?: NumberFormatOption;
  styles?: {
    color?: 'negative' | 'positive' | (() => string);
    prefix?: 'arrow';
  };
}

export const NumberDisplay: FC<NumberDisplayProps> = ({ className, style, value, format, styles }) => {
  const formattedNumber = formatNumber(value, format);

  const notZero = Boolean(value);
  const isNegative = value < 0;
  // #region 处理预置颜色
  const color = useMemo(() => {
    if (isFunction(styles?.color)) {
      return styles?.color();
    }
    if (styles?.color && notZero) {
      switch (styles.color) {
        case 'negative':
          return value > 0 ? '#FF3B52' : '#00C87F';
        case 'positive':
        default:
          return value < 0 ? '#FF3B52' : '#00C87F';
      }
    }
    return undefined;
  }, [notZero, styles, value]);
  // #endregion

  if (isNullOrUndefined(value) || !isNumber(value)) {
    return <span>-</span>;
  }
  return (
    <span
      className={classNames('inline-flex items-center overflow-y-hidden', className)}
      style={{
        color,
        ...style,
      }}
    >
      {notZero && styles?.prefix === 'arrow' ? (
        <svg
          width="0.675em"
          height="0.675em"
          viewBox="0 0 8 8"
          fill={color}
          style={{
            transform: isNegative ? 'rotate(180deg) translateY(-0.025em)' : 'translateY(0.025em)',
            width: '0.675em',
            height: '0.675em',
          }}
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M4 8.00195C4.27614 8.00195 4.5 7.7781 4.5 7.50195L4.5 0.531267C4.5 0.255124 4.27614 0.0312667 4 0.0312667C3.72386 0.0312668 3.5 0.255124 3.5 0.531267L3.5 7.50195C3.5 7.7781 3.72386 8.00195 4 8.00195Z"
          />
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M7.85355 4.35551C8.04882 4.16024 8.04882 3.84366 7.85355 3.6484L4.35355 0.1484C4.15829 -0.0468618 3.84171 -0.0468618 3.64645 0.1484L0.146449 3.6484C-0.0488139 3.84366 -0.0488138 4.16025 0.146449 4.35551C0.34171 4.55077 0.658293 4.55077 0.853555 4.35551L4 1.20906L7.14645 4.35551C7.34171 4.55077 7.65829 4.55077 7.85355 4.35551Z"
          />
        </svg>
      ) : null}
      {formattedNumber}
    </span>
  );
};
