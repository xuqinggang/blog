import React, { CSSProperties } from 'react';
import { isArray } from 'lodash-es';

import { PeopleCard } from '@ecop/user';

export enum ValueDisplayType {
  image = 'image',
  string = 'string',
  people = 'people',
}
interface ValueDisplayUse {
  options?: any[];
  displayStyle?: CSSProperties;
  displayType?: ValueDisplayType;
  originChildren?: React.ReactNode;
}

interface ValueDisplayProps extends ValueDisplayUse {
  value?: any;
  unit?: any;
  onChange?(e: any): void;
}

export const ValueDisplay = (props: ValueDisplayProps) => {
  const { value, options, displayStyle, unit } = props;
  if (options) {
    const selectOption = options.find(option => String(option.value) === String(value)) || {};
    return <div style={displayStyle}>{selectOption?.label}</div>;
  }
  return (
    <div style={displayStyle}>
      <span>{value}</span>
      {unit ? <span>{unit}</span> : null}
    </div>
  );
};

export const PeopleFormDisplay = (props: { value?: string[] | string }) => {
  const { value } = props;
  const v: string[] = React.useMemo(() => {
    if (value && isArray(value) && value.length) {
      return value;
    }
    return [value as string];
  }, [value]);
  if (!value) {
    return null;
  }
  return <PeopleCard max={3} list={(v || []).map(employee_id => ({ employee_id }))} />;
};
