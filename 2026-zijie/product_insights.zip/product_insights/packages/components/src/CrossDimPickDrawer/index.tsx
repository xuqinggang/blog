import React, { ReactNode, useEffect, useMemo, useState } from 'react';
import { groupBy, map } from 'lodash-es';

import { Button, Divider, Drawer, DrawerProps, Form, Icon, Modal, Space, Spin, Tooltip } from '@ecom/auxo';
import { FormInstance } from '@ecom/auxo-pro-form';

import { RuleValueType } from '../RuleSelect';

import { DimensionInfo, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import {
  MAX_MULTI_DIM,
  MAX_SINGLE_DIMENSION_ENUM_COUNT,
  MIN_MULTI_DIM,
  MIN_SINGLE_DIMENSION_ENUM_COUNT,
} from '~/constant';
import DimCheckGroup, { DimItem } from '~/DimCheckGroup';
import { DimEnumFilter } from '~/DimEnumFilter';
import { DimensionType } from '~/filter-form/types';
import { errorDepend } from '~/filter-form/utils/compute';
import { getMultiDimList } from '~/filter-form/utils/get-multi-dim-list';
import { useFromProductIncubation } from '~/utils';

export interface CrossDimPickDrawerProps extends Omit<DrawerProps, 'visible' | 'onOk'> {
  loading?: boolean;
  triggerText?: string;
  triggerClassName?: string;
  min?: number;
  max?: number;
  minEnum?: number; // 最小可选的枚举值数量
  maxEnum?: number; // 最大可选的枚举值数量
  mode?: 'single' | 'multiple'; // 单选|多选，默认是多选
  value?: DimItem[];
  form?: FormInstance;
  field?: string;
  disabled?: boolean;
  disabledDimList?: string[]; // 不可选中的维度
  multiDimDimensions?: Partial<Record<DimensionType, DimensionInfo[]>> | null;
  selectedDimensions?: (SelectedDimensionInfo | RuleValueType)[];
  renderTrigger?: ({ onClick }: { onClick: () => void }) => ReactNode;
  onVisibleChange?: (visible: boolean) => void;
  onOk?: (value: Omit<DimItem, 'disabled'>[]) => void;
}

export const CrossDimPickDrawer: React.FC<CrossDimPickDrawerProps> = ({
  renderTrigger,
  onVisibleChange,
  loading = false,
  triggerText = '设置维度',
  triggerClassName,
  title = '多维分析',
  multiDimDimensions,
  selectedDimensions,
  value,
  onOk,
  form,
  field,
  min = MIN_MULTI_DIM,
  max = MAX_MULTI_DIM,
  minEnum = MIN_SINGLE_DIMENSION_ENUM_COUNT,
  maxEnum = MAX_SINGLE_DIMENSION_ENUM_COUNT,
  mode = 'multiple',
  disabledDimList,
  disabled = false,
  ...otherProps
}) => {
  const [visible, setVisible] = useState(false);
  const [errorInfo, setErrorInfo] = useState('');
  const [selectDimList, setSelectDimList] = useState<DimItem[]>([]);
  const isFromProductIncubation = useFromProductIncubation();

  const dimGroup = useMemo(
    () => getMultiDimList(multiDimDimensions, selectedDimensions, selectDimList, maxEnum),
    [maxEnum, multiDimDimensions, selectDimList, selectedDimensions],
  );

  const dimGroupHideByProductIncubation = useMemo(() => {
    return dimGroup.map(item => {
      return {
        ...item,
        list: item.list?.filter(v => {
          if (!isFromProductIncubation) {
            return true;
          }
          return v.value !== '10291' && v.value !== '10292';
        }),
      };
    });
  }, [dimGroup, isFromProductIncubation]);

  const list = useMemo(
    () => dimGroupHideByProductIncubation.reduce<DimItem[]>((prev, curr) => prev.concat(curr.list ?? []), []),
    [dimGroupHideByProductIncubation],
  );

  const openDrawer = () => {
    setVisible(true);
  };

  const validateError = () => {
    const allError: string[] = [];
    const selectedValue = selectDimList.map<RuleValueType>(dim => ({
      id: String(dim.value),
      selected_values: map(dim.selected_enums, 'value'),
    }));

    selectDimList.forEach(({ selected_enums }) => {
      selected_enums?.forEach(op => {
        if (!op.depend_code) return;
        const error = errorDepend(op.depend_code, selectedValue as RuleValueType[]);
        const errorGroup = groupBy(error, 'id');
        const dependGroup = groupBy(op.depend_code, 'id');

        const hasError = Object.keys(errorGroup).some(
          k => errorGroup[k].length && errorGroup[k].length === dependGroup[k].length,
        );
        hasError && allError.push(String(op.label));
      }) ?? [];
    });

    const error = allError.length ? `选项 ${allError.join('、')} 存在冲突` : '';
    setErrorInfo(error);
    return error;
  };

  const onConfirm = () => {
    // TODO@ZOTILLE:
    // reportMultiDimensionClick();

    try {
      if (validateError()) {
        return;
      }

      const overLimitDims: string[] = [];
      const selected = selectDimList.map<DimItem>(dim => {
        const { selected_enums } = dim;
        const length = selected_enums?.length ?? 0;
        if (length < minEnum || length > maxEnum) {
          overLimitDims.push(`【${dim.label}】`);
        }

        return {
          ...dim,
          enums: selected_enums,
        };
      });

      if (overLimitDims.length) {
        throw new Error(
          `您设置的维度${overLimitDims.join(
            '、',
          )}包含的枚举值过多/过少,请添加筛选条件后查看结果（单个维度最多筛选${maxEnum}个枚举值，最少筛选${minEnum}个枚举值)~`,
        );
      }

      onOk?.(selected);
      setVisible(false);
    } catch (error) {
      Modal.warning({
        width: 480,
        content: (error as { message: string })?.message,
        title: '枚举值过多',
        showCancel: false,
      });
    }
  };

  useEffect(() => {
    if (!visible) {
      return;
    }

    setSelectDimList(value ?? form?.pGetFieldValue(field || '') ?? []);
    // TODO@ZOTILLE:
    // reportMultiDimensionShow();
  }, [field, form, value, visible]);

  useEffect(() => {
    onVisibleChange?.(visible);
  }, [onVisibleChange, visible]);

  return (
    <>
      {renderTrigger ? (
        renderTrigger({ onClick: openDrawer })
      ) : (
        <Tooltip title="建议下钻的维度枚举值不超过30个">
          <div className={triggerClassName}>
            <Button disabled={disabled} type="dashed" icon={<Icon.SetUpIcon />} onClick={openDrawer}>
              {triggerText}
            </Button>
          </div>
        </Tooltip>
      )}
      <Drawer
        visible={visible}
        title={title}
        width={800}
        onCancel={() => setVisible(false)}
        onOk={onConfirm}
        destroyOnClose
        {...otherProps}
      >
        <Spin spinning={loading}>
          <Space size={8} style={{ marginBottom: 16 }}>
            <span className="font-medium">添加分析维度</span>
            {min > 0 && <span className="text-desc">最少选择{min}个维度</span>}
            {max < Infinity && <span className="text-desc">最多选择{max}个维度</span>}
          </Space>
          <DimCheckGroup
            style={{ width: '80%' }}
            dimGroup={dimGroupHideByProductIncubation}
            disabledDimList={disabledDimList}
            underLimit={selectDimList.length <= min}
            overLimit={selectDimList.length >= max}
            mode={mode}
            value={selectDimList}
            groupInValue
            onChange={setSelectDimList}
          />
          {selectDimList.length ? (
            <>
              <Divider style={{ width: '100%' }} />
              <Space size={8} style={{ marginBottom: 16 }}>
                <span className="font-medium">添加过滤条件</span>
                <span className="text-desc">可以拖动调整维度的顺序。单个维度最多可选择{maxEnum}个枚举值</span>
              </Space>
              <Form>
                <Form.Item validateStatus={errorInfo ? 'error' : 'success'} help={errorInfo}>
                  <DimEnumFilter
                    value={selectDimList}
                    list={list}
                    showLogic
                    onChange={setSelectDimList}
                    min={min}
                    maxSelected={maxEnum}
                  />
                </Form.Item>
              </Form>
            </>
          ) : null}
        </Spin>
      </Drawer>
    </>
  );
};
