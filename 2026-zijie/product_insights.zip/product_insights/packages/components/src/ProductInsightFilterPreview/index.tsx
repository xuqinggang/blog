/* eslint-disable max-nested-callbacks */
import React from 'react';
import { get } from 'lodash-es';

import { ThresholdAttrs } from './threshold-attrs';

import {
  DimensionInfo,
  GetDimensionListData,
  ProductAnalysisBaseStruct,
  SelectedDimensionInfo,
} from '~/api/product/namespaces/dimensions';
import { DefaultEnumMap } from '~/filter-form/types';
import { transformAttrType } from '~/filter-form/utils/transform';
import { OperatorList } from '~/RuleSelect';

const MAX_PREVIEW_ENUM_COUNT = 9; // 最多显示9个维度枚举值

interface SimpleSelectedDim extends Omit<SelectedDimensionInfo, 'selected_values'> {
  name: string;
  selected_values?: string[];
}

interface ProductInsightFilterPreviewProps {
  baseStruct?: ProductAnalysisBaseStruct; // 货盘结构，内部依赖该字段获取筛选条件
  dimensionData?: GetDimensionListData | null;
  defaultEnumMap?: DefaultEnumMap;
  showAttrs?: boolean;
}

export const ProductInsightFilterPreview = (props: ProductInsightFilterPreviewProps) => {
  const { baseStruct: productAnalysisBaseStruct, dimensionData, defaultEnumMap, showAttrs } = props;

  const baseStruct = React.useMemo(() => {
    const result = productAnalysisBaseStruct || { dimensions: [], group_attrs: [] };

    result.dimensions?.forEach(i => {
      const dimType = transformAttrType(i?.attr_type);
      if (!dimType) {
        return;
      }

      const dim = get(dimensionData, dimType, []).find((j: DimensionInfo) => j?.id === i?.id);
      if (!dim) {
        return;
      }

      const searchEnums = defaultEnumMap?.[i?.id || ''] || [];
      i?.selected_values?.forEach(j => {
        if (j?.name) {
          return;
        }

        let enumName: string;
        if (dim?.need_page_search) {
          enumName = (searchEnums?.find((k: any) => k?.value === j?.code)?.label as string) || '';
        } else {
          enumName = dim.values?.find((k: any) => k?.code === j?.code)?.name || '';
        }

        if (enumName) {
          j.name = enumName;
        }
      });
    });

    return result;
  }, [defaultEnumMap, dimensionData, productAnalysisBaseStruct]);

  const simpleSelectedDim = React.useMemo(() => {
    return (baseStruct?.dimensions as SelectedDimensionInfo[])?.reduce((prev: any, curr: any) => {
      const { attr_type, id, selected_values } = curr;
      if (!selected_values?.length) {
        return prev;
      }

      const selectedValues = selected_values?.map((i: any) =>
        Boolean(i?.type_value?.length) ? (i?.type_value || []).join(',') : i?.name || '',
      );
      const dimType = transformAttrType(attr_type);
      if (!dimType) {
        return [
          ...prev,
          {
            ...curr,
            selected_values: selectedValues,
            name: '',
          },
        ];
      }

      const dimName = get(dimensionData, dimType, []).find((i: DimensionInfo) => i?.id === id)?.show_name || '';
      return [
        ...prev,
        {
          ...curr,
          selected_values: selectedValues,
          name: dimName,
        },
      ];
    }, [] as SelectedDimensionInfo[]);
  }, [baseStruct.dimensions, dimensionData]);

  return (
    <div className="flex gap-1">
      <div className="flex flex-1">
        {simpleSelectedDim?.length || baseStruct?.group_attrs?.length ? (
          <span>
            {simpleSelectedDim?.length ? (
              <span>
                <span>筛选维度：</span>
                {simpleSelectedDim?.map((i: SimpleSelectedDim, index: number) => {
                  const { name, selected_values, selected_operator } = i;
                  const isMore = (selected_values?.length ?? 0) > MAX_PREVIEW_ENUM_COUNT;
                  const selectedValues = isMore ? selected_values?.slice(0, MAX_PREVIEW_ENUM_COUNT) : selected_values;

                  const operatorText = ` ${OperatorList?.find(j => j?.value === selected_operator)?.label || '包含'} `;
                  const valuesText = selectedValues?.join('，');
                  const moreText = isMore ? ` 等${selected_values?.length ?? 0}个选项` : '';

                  return (
                    <>
                      {index !== 0 && '；'}
                      {name}
                      <span className="text-[#252931] font-medium">{`${operatorText}`}</span>
                      {valuesText}
                      {moreText}
                    </>
                  );
                })}
              </span>
            ) : null}

            {showAttrs && (
              <ThresholdAttrs attrs={(baseStruct as any)?.threshold_attrs || []} dimensionData={dimensionData} />
            )}
            {baseStruct?.group_attrs?.length &&
            baseStruct?.group_attrs?.some(i => i?.dim_info?.name && i?.value?.code) ? (
              <span style={{ marginLeft: 8 }}>
                下钻维度：
                {baseStruct?.group_attrs
                  ?.map(i => (i?.dim_info?.name && i?.value?.code ? `${i?.dim_info?.name} 选中 ${i?.value?.code}` : ''))
                  ?.join('；')}
              </span>
            ) : null}
          </span>
        ) : (
          <span>无</span>
        )}
      </div>
    </div>
  );
};

interface ProductInsightFilterPreviewDisplayProps {
  value?: ProductAnalysisBaseStruct;
  dimensionData?: GetDimensionListData | null;
  defaultEnumMap?: DefaultEnumMap;
  showAttrs?: boolean;
}

export const ProductInsightFilterPreviewFormDisplay = ({
  value,
  defaultEnumMap,
  dimensionData,
  showAttrs,
}: ProductInsightFilterPreviewDisplayProps) => {
  return (
    <ProductInsightFilterPreview
      defaultEnumMap={defaultEnumMap}
      dimensionData={dimensionData}
      baseStruct={value}
      showAttrs={showAttrs}
    />
  );
};
