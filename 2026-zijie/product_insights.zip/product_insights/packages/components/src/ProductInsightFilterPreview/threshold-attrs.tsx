import { FC, useMemo } from 'react';
import { get } from 'lodash-es';

import { OperatorType } from '~/api/product/namespaces/base';
import { GetDimensionListData, ThresholdAttr, ThresholdType } from '~/api/product/namespaces/dimensions';

interface CommonProps {
  dimensionData?: GetDimensionListData | null;
}

const OperatorMap: Record<OperatorType, string> = {
  [OperatorType.IN]: '包含',
  [OperatorType.NOT_IN]: '不包含',
  [OperatorType.EQUAL]: '=',
  [OperatorType.GREATER_EQUAL_THAN]: '>=',
  [OperatorType.GREATER_THAN]: '>',
  [OperatorType.LESS_EQUAL_THAN]: '<=',
  [OperatorType.LESS_THAN]: '<',
};

export const ThresholdAttrItem: FC<
  CommonProps & {
    data: ThresholdAttr;
  }
> = ({ data, dimensionData }) => {
  const { key, type, top_n, acc_threshold } = data;

  const attrMeta = useMemo(() => {
    const metas = dimensionData?.threshold_attr_meta?.find(i => i.type === type);
    return metas?.value_list?.find(i => i.id === key);
  }, [dimensionData?.threshold_attr_meta, key, type]);

  if (!attrMeta) return null;

  const { name } = attrMeta || {};

  switch (type) {
    case ThresholdType.TOP_THRESHOLD:
      return (
        <div className="mt-1">
          <b className="mr-1">{name}</b>
          <span className="mr-1">
            TOP
            <b>{top_n}</b>
          </span>
          <span>个商品</span>
        </div>
      );

    case ThresholdType.CONTRIBUTION_THRESHOLD:
      return (
        <div className="mt-1">
          <b className="mr-1">{name}</b>
          <span className="mr-1">贡献度大于</span>
          <b className="mr-1">{acc_threshold?.threshold}</b>
          <span>的商品</span>
        </div>
      );

    case ThresholdType.ACC_THRESHOLD:
      return (
        <div className="mt-1">
          <b className="mr-1">{name}</b>
          <b className="mr-1">
            {get(OperatorMap, acc_threshold?.operator || '', '')} {acc_threshold?.threshold}
          </b>
          <span>的商品</span>
        </div>
      );

    case ThresholdType.BIGSALE_HOT_SCORE_THRESHOLD:
      return (
        <div className="mt-1">
          <b className="mr-1">{name}</b>
          <span>大促爆发系数</span>
          <b className="mr-1">大于{acc_threshold?.threshold}</b>
          <span>的商品</span>
        </div>
      );
    default: {
      return null;
    }
  }
};

/** 指标阈值展示 */
export const ThresholdAttrs: FC<
  CommonProps & {
    attrs: ThresholdAttr[];
  }
> = ({ attrs = [], dimensionData }) => {
  if (!dimensionData || !attrs.length) return null;
  return (
    <div className="flex flex-col pt-2">
      <span>指标阈值：</span>
      <div className="flex flex-col pl-4">
        {attrs?.map(i => (
          <ThresholdAttrItem key={i.key} data={i} dimensionData={dimensionData} />
        ))}
      </div>
    </div>
  );
};
