import React, { FC, useMemo } from 'react';
import classNames from 'classnames';

import { Checkbox } from '@ecom/auxo';

import styles from './index.module.scss';

import { TargetMetaInfo } from '~/api/product/namespaces/dimensions';

export interface TargetPickerProps {
  targetMetaList: TargetMetaInfo[];
  value?: string[];
  onChange?: (targets: string[]) => void;
}
export const TargetPicker: FC<TargetPickerProps> = ({ targetMetaList, value, onChange }) => {
  const groupedData = useMemo(() => {
    const data: Record<string, { order: number; list: TargetMetaInfo[] }> = {};
    targetMetaList.forEach(item => {
      const { attribute_type = '未归类' } = item;
      if (!data[attribute_type]) {
        data[attribute_type] = {
          order: Number(item.attribute_type_order) || 999,
          list: [item],
        };
      } else {
        data[attribute_type].list.push(item);
      }
    });

    const arrData = Object.entries(data)
      .map(([k, v]) => ({ ...v, name: k }))
      .sort((a, b) => a.order - b.order);
    arrData.forEach(item => {
      item.list.sort((a, b) => Number(a.attribute_type_order) - Number(b.attribute_type_order));
    });
    return arrData;
  }, [targetMetaList]);

  return (
    <Checkbox.Group
      value={value}
      onChange={e => {
        onChange?.(e as string[]);
      }}
    >
      <div className={classNames(styles.container, '')}>
        {groupedData.map(item => (
          <React.Fragment key={item.list[0]?.attribute_type || ''}>
            <div className={styles.label}>{item.name}</div>
            <div className="grid grid-cols-3 gap-4">
              {item.list.map(listItem => (
                <Checkbox
                  value={listItem.name}
                  key={listItem.name}
                  // checked={Boolean(listItem.name && value?.includes(listItem.name))}
                >
                  {listItem.display_name}
                </Checkbox>
              ))}
            </div>
          </React.Fragment>
        ))}
      </div>
    </Checkbox.Group>
  );
};

export { TargetPickerDrawer } from './drawer';
