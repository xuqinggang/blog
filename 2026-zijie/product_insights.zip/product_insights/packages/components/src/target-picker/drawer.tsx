import { FC, useCallback, useLayoutEffect, useState } from 'react';

import { Drawer, DrawerProps } from '@ecom/auxo';

import { TargetPicker, TargetPickerProps } from '.';

export interface TargetPickerDrawerProps extends TargetPickerProps, Pick<DrawerProps, 'title'> {
  visible?: boolean;
  onCancel?: () => void;
  onOk?: (targets: string[]) => void;
}

export const TargetPickerDrawer: FC<TargetPickerDrawerProps> = ({
  visible,
  value,
  onCancel,
  onOk,
  title,
  onChange,
  ...rest
}) => {
  const [innerValue, setInnerValue] = useState<string[]>([]);

  useLayoutEffect(() => {
    if (visible) {
      setInnerValue(value || []);
    }
  }, [value, visible]);

  const handleChange = useCallback(v => {
    setInnerValue(v);
  }, []);

  const handleOk = useCallback(() => {
    onChange?.(innerValue);
    onOk?.(innerValue);
  }, [innerValue, onChange, onOk]);

  return (
    <Drawer visible={Boolean(visible)} onOk={handleOk} onCancel={onCancel} width={960} title={title || '指标选择'}>
      <TargetPicker {...rest} value={innerValue} onChange={handleChange} />
    </Drawer>
  );
};
