import React, { useEffect } from 'react';
import { isEmpty } from 'lodash-es';

import { Select, Space, Typography } from '@ecom/auxo';
import type { IStepsProps } from '@ecom/auxo/es/components/select/SPSearch';
import { EnumOption } from '@ecom/auxo-pro-form/es/components';

import { productClient } from '~/api';
import { AnalysisPool } from '~/api/product/namespaces/analysis_pool';
import { GetDimensionListData } from '~/api/product/namespaces/dimensions';
import { DIMENSION_TYPE_LIST } from '~/constant';
import { CommonFilter, DefaultEnumMap, DimensionType } from '~/filter-form/types';
import { formatFilterFromServer } from '~/filter-form/utils/filters';
import useAuxoSearchSelect, { type Service } from '~/hooks/useAuxoSearchSelect';
import { ProductInsightFilterPreview } from '~/ProductInsightFilterPreview';
import { RuleValueType } from '~/RuleSelect';

export interface DefaultEnumInfo {
  id?: string;
  enumList?: EnumOption[];
}

const getEnumsByCode = async (dim: RuleValueType): Promise<DefaultEnumInfo> => {
  const { id, selected_values } = dim;
  if (!id || !selected_values?.length) {
    return {};
  }

  const { data } = await productClient.GetDimensionPageEnumList({
    dimension_id: id || '',
    enum_code_list: selected_values?.map(item => String(item)) ?? [],
  });

  return {
    id: id || '',
    enumList: data?.enum_list?.map<EnumOption>(({ code, name }) => ({ value: code || '', label: name || '' })) ?? [],
  };
};

const getDefaultEnums = async (
  filter?: CommonFilter | RuleValueType[] | null,
  dimensionData?: GetDimensionListData | null,
) => {
  if (isEmpty(dimensionData) || isEmpty(filter)) {
    return;
  }

  // #region 找出筛选项中需要搜索枚举值的维度列表
  const filterDims = (
    Array.isArray(filter)
      ? filter.map<RuleValueType>(i => ({ ...i, dim_type: 'product_dimensions' }))
      : Object.keys(filter).reduce<RuleValueType[]>((prev, curr) => {
          if (!DIMENSION_TYPE_LIST.includes(curr) || !filter?.[curr as keyof CommonFilter]) {
            return prev;
          }

          return prev.concat(
            filter[curr as DimensionType]?.map((i: RuleValueType) => ({ ...i, dim_type: curr as DimensionType })) ?? [],
          );
        }, [])
  ).filter(({ id, dim_type }) => {
    if (!id || !dim_type) {
      return false;
    }

    const dims = dimensionData?.[dim_type];
    return dims?.find(i => i.id === id)?.need_page_search;
  });
  // #endregion

  // #region 搜索枚举值
  try {
    const promises = filterDims
      .filter(({ id, selected_values }) => Boolean(id && selected_values?.length))
      .map(getEnumsByCode);
    const arr: DefaultEnumInfo[] = await Promise.all(promises);
    const defaultEnumMap = arr.reduce<DefaultEnumMap>((prev, curr) => {
      const { id, enumList } = curr;
      if (id && enumList?.length) {
        prev[id] = enumList;
      }

      return prev;
    }, {});

    return defaultEnumMap;
  } catch (e) {
    console.error('Get enums by code error', e);
  }
  // #endregion
};

export default function PoolSelect(
  props: IStepsProps<any> & {
    insightDimData?: GetDimensionListData;
  },
) {
  const [poolInfo, setPoolInfo] = React.useState<AnalysisPool>();
  const [baseStruct, setBaseStruct] = React.useState<AnalysisPool['base_struct']>();
  const [defaultEnumMap, setDefaultEnumMap] = React.useState<DefaultEnumMap>();
  const { value, insightDimData, ...restProps } = props;
  const handleFetch = React.useCallback<Service<AnalysisPool>>(async ({ page, pageSize, searchVal }) => {
    return productClient
      .QueryAnalysisPool({
        page_req: {
          page_num: page,
          page_size: pageSize,
        },
        pool_name: searchVal,
      })
      .then(res => res.data.list);
  }, []);

  const { spSearchProps, reset, fetchData } = useAuxoSearchSelect(handleFetch, {
    manual: true,
    dataKey: record => record?.pool_id as string,
    label: record => (
      <Typography.Text ellipsis={{ tooltip: `${record?.pool_name} ID：${record?.pool_id}` }}>
        {record?.pool_name}
      </Typography.Text>
    ),
    value: record => record?.pool_id,
    searchDebounce: 500,
  });

  useEffect(() => {
    const fetchRelatedData = async () => {
      const poolDetailRes = await productClient
        .QueryAnalysisPoolDetail({
          pool_id: value,
        })
        .catch(() => null);
      setPoolInfo(poolDetailRes?.data?.info);
      if (poolDetailRes?.data?.info?.base_struct) {
        setBaseStruct(poolDetailRes?.data?.info?.base_struct);
        const defaultEnumMap = await getDefaultEnums(
          formatFilterFromServer(poolDetailRes?.data?.info?.base_struct, true),
          insightDimData,
        );
        setDefaultEnumMap(defaultEnumMap);
      }
    };
    fetchRelatedData();
  }, [insightDimData, value]);

  useEffect(() => {
    reset();
    fetchData();
  }, [reset, fetchData]);

  const renderPreview = React.useMemo(() => {
    if (poolInfo?.pool_type === 0) {
      return <div>人工录入</div>;
    }
    if (poolInfo?.pool_type === 1) {
      return (
        <ProductInsightFilterPreview
          baseStruct={baseStruct}
          defaultEnumMap={defaultEnumMap}
          dimensionData={insightDimData}
        />
      );
    }
    return null;
  }, [baseStruct, defaultEnumMap, insightDimData, poolInfo?.pool_type]);

  return (
    <Space direction="vertical" style={{ width: '100%' }}>
      <Select
        showSearch
        placeholder="请选择货盘"
        style={{ width: '100%' }}
        value={value}
        {...spSearchProps}
        {...restProps}
      />
      {value ? (
        <Space align="start">
          <div style={{ width: '70px' }}>圈选规则：</div>
          {renderPreview}
        </Space>
      ) : null}
    </Space>
  );
}
