import { cloneDeep, compact, flatten, isNil, omit, pick } from 'lodash-es';

import { EnumOption } from '@ecom/auxo-pro-form';

import { OperatorType } from '~/api/product/namespaces/base';
import {
  BizType,
  DimensionAttributeType,
  DimensionInfo,
  DimSimpleElement,
  EnumElement,
  PriceComparisonType,
  ProductAnalysisBaseStruct,
  SelectedDimensionInfo,
  SelectedMultiDimensionInfo,
} from '~/api/product/namespaces/dimensions';
import { PriceAnalysisBaseStruct } from '~/api/product/namespaces/price_dimensions';
import { DIM_GROUPS, DIM_KEY_MAP, DIMENSION_TYPE_LIST, ServerRange } from '~/constant';
import { DimItem } from '~/DimCheckGroup';
import { formatFilterToServer } from '~/filter-form/utils/filters';
import { ProductPalletFilterFields } from '~/form_filters/product_pallet_filter/comp';
import { RuleSelectedOption, RuleValueType } from '~/RuleSelect';
import { isPriceTrend } from '~/utils/is';

import { AnalysisFilter, AnalysisServerFilter, CommonFilter, DimensionType, PriceServerFilter } from '../types';

import { isHybrid } from './is-hybrid';

export function transformAttrType(attrType?: DimensionAttributeType): DimensionType | undefined {
  switch (attrType) {
    case DimensionAttributeType.User: {
      return 'user_dimensions';
    }
    case DimensionAttributeType.Place: {
      return 'place_dimensions';
    }
    case DimensionAttributeType.Product: {
      return 'product_dimensions';
    }
    case DimensionAttributeType.Order: {
      return 'order_dimensions';
    }
    default: {
      return;
    }
  }
}

export function transformDimensionType(dimType?: DimensionType): DimensionAttributeType | undefined {
  switch (dimType) {
    case 'user_dimensions': {
      return DimensionAttributeType.User;
    }
    case 'place_dimensions': {
      return DimensionAttributeType.Place;
    }
    case 'product_dimensions': {
      return DimensionAttributeType.Product;
    }
    case 'order_dimensions': {
      return DimensionAttributeType.Order;
    }
    default: {
      return;
    }
  }
}

/**
 * 根据筛选的维度更新多维分析筛选项（多维分析筛选项枚举值必须是维度筛选项枚举值的子集）
 * @param groupAttrs 多维分析筛选项
 * @param dims 选择的维度
 * @returns 更新后的多维分析筛选项
 */
export function updateGroupAttrs(
  groupAttrs: DimItem[],
  dims?: SelectedDimensionInfo[],
): {
  needUpdate: boolean;
  groupAttrs: DimItem[];
} {
  if (!dims?.length) {
    return {
      groupAttrs,
      needUpdate: false,
    };
  }

  let needUpdate = false;
  const newGroupAttrs = cloneDeep(groupAttrs);

  dims.forEach(dim => {
    const { selected_values: selectedEnums, id, selected_operator } = dim;
    if (!selectedEnums?.length) {
      return;
    }

    const groupDim = newGroupAttrs.find(({ value }) => value === id);
    if (!groupDim) {
      return;
    }

    needUpdate = true;
    // 找出多维分析中选择的枚举值和筛选区选择的枚举值中的交集
    const { selected_enums: groupSelectedEnums } = groupDim;
    // eslint-disable-next-line max-nested-callbacks
    const filterEnums = groupSelectedEnums?.filter(i =>
      selectedEnums.some(j => (!selected_operator ? i.value === j.code : i.value !== j.code)),
    );

    if (!filterEnums?.length) {
      /** 没有交集，
       * 1. 如果筛选区维度是包含逻辑，默认选择筛选区的枚举值作为多维分析的枚举值
       * 2. 如果筛选区维度是非包含逻辑，则清空筛选项
       */
      groupDim.selected_enums = !selected_operator
        ? selectedEnums?.map(({ code, name }) => ({
            value: code || '',
            label: name || '',
          }))
        : [];
    } else {
      groupDim.selected_enums = filterEnums;
    }
  });

  return {
    groupAttrs: newGroupAttrs,
    needUpdate,
  };
}

export function transformGroupAttrs2Filter(
  groupAttrs?: SelectedMultiDimensionInfo[],
  dims?: SelectedDimensionInfo[],
  fillSelect = true,
) {
  return updateGroupAttrs(
    groupAttrs?.map<DimItem>(attr => {
      const enums =
        attr.dim_info?.selected_values?.map<EnumOption>(v => ({ value: v.code ?? 0, label: v.name || '' })) ?? [];

      const dim: DimItem = {
        value: attr.dim_info?.id ?? 0,
        label: attr.dim_info.name || '',
        group: DIM_GROUPS.find(g => attr.dim_info.attr_type === g.attrType)?.key ?? '',
        enums: enums,
      };

      if (fillSelect) {
        dim.selected_enums = enums;
      }

      return dim;
    }) ?? [],
    dims,
  ).groupAttrs;
}

export function transformGroupAttrs2Server(groupAttrs?: DimItem[]) {
  return groupAttrs?.map<SelectedMultiDimensionInfo>(dim => ({
    dim_info: {
      id: String(dim.value),
      name: dim.label,
      attr_type: dim.group ? DIM_KEY_MAP[dim.group as DimensionType] : DimensionAttributeType.User,
      selected_values: dim.selected_enums?.map(e => ({ code: String(e.value), name: String(e.label) })) ?? [],
    },
  }));
}

export function transformDim2Select(
  dim?: DimensionInfo,
  values?: EnumElement[],
  showDefault = false,
): SelectedDimensionInfo | undefined {
  if (!dim) {
    return;
  }

  const { id, show_name, dimension_category, values: dimValues } = dim;
  return {
    id,
    name: show_name,
    attr_type: dimension_category,
    selected_operator: OperatorType.IN,
    selected_values: values ?? (showDefault ? dimValues?.filter(({ is_default_show }) => is_default_show) : undefined),
  };
}

export const fromDimensionInfo2SelectedDimensionInfo = transformDim2Select;

export function transformDim2Rule(dim: DimensionInfo, idList?: string[]): RuleValueType {
  const { id, values } = dim;
  const selected_option = (
    idList?.length
      ? values?.filter(item => item.code && idList.includes(item.code))
      : values?.filter(j => j.is_default_show)
  ) as RuleSelectedOption[] | undefined;

  return {
    id,
    selected_option,
    selected_values: selected_option?.map(({ code }) => code || ''), // 填充默认的枚举值
  };
}

export const fromDimensionInfo2RuleValueType = transformDim2Rule;

export function transformSelectDim2Rule(dim?: SelectedDimensionInfo): RuleValueType {
  return {
    id: dim?.id,
    name: dim?.name,
    selected_operator: dim?.selected_operator,
    selected_values: dim?.selected_values?.map(({ code, type_value }) => code || type_value)?.flat(),
    selected_option: dim?.selected_values as RuleSelectedOption[],
    dim_type: transformAttrType(dim?.attr_type),
  } as RuleValueType;
}

export const fromSelectedDimensionInfo2RuleValueType = transformSelectDim2Rule;

export function getRuleSelectedValues(rule: RuleValueType) {
  const { selected_option } = rule;
  const selected_values: EnumElement[] = [];

  if (rule.op_type?.includes('range_input')) {
    // 因为暂时没被货品分析引用，暂时先把defaultV逻辑处理掉
    const typeValue = ServerRange.map((defaultV, idx) =>
      rule.selected_values?.[idx] ? String(rule.selected_values?.[idx]) : rule.selected_values?.[idx],
    );
    selected_values.push({ type_value: typeValue as string[] });
  } else if (rule.op_type?.includes('array_input')) {
    selected_values.push({ type_value: rule.selected_values as string[] });
  } else {
    const selectedValues = (rule.selected_values as string[])?.map(v => ({ code: v })) ?? [];
    selected_values.push(...selectedValues);
  }

  selected_option?.forEach(item => {
    const value = selected_values.find(({ code }) => code === item?.code);
    if (!value) {
      return;
    }

    value.depend_code = item?.depend_code;
    value.name = item?.name;
  });

  return selected_values;
}

export function transformRule2SelectDim(rule: RuleValueType, attr_type: DimensionAttributeType): SelectedDimensionInfo {
  return {
    ...omit(rule, ['selected_option']),
    attr_type,
    selected_values: getRuleSelectedValues(rule),
  };
}

export function getSelectedDimFromFilter(rootValue: CommonFilter) {
  return flatten(Object.values(pick(rootValue, DIMENSION_TYPE_LIST))) as RuleValueType[];
}

export function transformDimItem2Rule(dim: DimItem): RuleValueType {
  const { value, label, selected_enums } = dim;
  return {
    id: String(value),
    name: label,
    selected_operator: 0,
    selected_values: selected_enums?.map(({ value }) => value) ?? [],
  } as RuleValueType;
}

// 转换货品分析filter
export function transformProductFilter(bizType: BizType, filter?: CommonFilter | null) {
  if (!filter) {
    return {} as ProductAnalysisBaseStruct;
  }

  const filterData = formatFilterToServer(filter, true);
  return {
    ...(filterData as AnalysisServerFilter),
    threshold_attrs: (filter as AnalysisFilter).threshold_attrs?.filter(
      i => !isNil(i.top_n) || !isNil(i.acc_threshold?.threshold),
    ),
    biz_type: bizType,
  } as ProductAnalysisBaseStruct;
}

// 转换价格力filter
export function transformPriceFilter(
  bizType: BizType,
  filter?: CommonFilter | null,
  priceHybridList?: DimSimpleElement[],
) {
  if (!filter) {
    return {} as PriceAnalysisBaseStruct;
  }

  const filterData = formatFilterToServer(filter, false);
  if (isPriceTrend(bizType)) {
    // 价格力趋势需要区分比价口径
    const { dimensions } = filterData;
    if (isHybrid(dimensions ?? [], priceHybridList)) {
      // 命中了B店混比口径
      (filterData as PriceAnalysisBaseStruct).price_comparison_type = PriceComparisonType.Hybrid;
    } else {
      // 新阶梯比价
      (filterData as PriceAnalysisBaseStruct).price_comparison_type = PriceComparisonType.NewStage;
    }
  }

  // 价格力趋势/比较
  return {
    ...(filterData as PriceServerFilter),
    biz_type: bizType,
  } as PriceAnalysisBaseStruct;
}

export const fromSelectedDimensionInfo2ProductPalletFilterFields = (
  source: SelectedDimensionInfo[],
): ProductPalletFilterFields => {
  return {
    order_dimensions: (source || [])
      .filter(item => item.attr_type === DimensionAttributeType.Order)
      .map(fromSelectedDimensionInfo2RuleValueType),
    place_dimensions: (source || [])
      .filter(item => item.attr_type === DimensionAttributeType.Place)
      .map(fromSelectedDimensionInfo2RuleValueType),
    product_dimensions: (source || [])
      .filter(item => item.attr_type === DimensionAttributeType.Product)
      .map(fromSelectedDimensionInfo2RuleValueType),
    user_dimensions: (source || [])
      .filter(item => item.attr_type === DimensionAttributeType.User)
      .map(fromSelectedDimensionInfo2RuleValueType),
  };
};

export const fromProductPalletFilterFields2SelectedDimensionInfo = (
  source: ProductPalletFilterFields,
): SelectedDimensionInfo[] => {
  return [
    ...(source.order_dimensions?.map(item => transformRule2SelectDim(item, DimensionAttributeType.Order)) || []),
    ...(source.place_dimensions?.map(item => transformRule2SelectDim(item, DimensionAttributeType.Place)) || []),
    ...(source.product_dimensions?.map(item => transformRule2SelectDim(item, DimensionAttributeType.Product)) || []),
    ...(source.user_dimensions?.map(item => transformRule2SelectDim(item, DimensionAttributeType.User)) || []),
  ];
};

export const fromID2SelectedDimensionInfo = (
  dim: DimensionInfo,
  selectedIds: string[],
): SelectedDimensionInfo | undefined => {
  const dimId = dim.id;
  const attr = dim.dimension_category;
  if (attr) {
    if (selectedIds?.length) {
      const selectedValues = selectedIds?.map(id => (dim?.values || []).find(item => item.code === id)).filter(Boolean);
      if (selectedValues) {
        return {
          attr_type: Number(attr),
          editable: 0,
          id: dimId,
          is_group: false,
          name: dim.show_name,
          selected_operator: 0,
          selected_values: compact(selectedValues),
        };
      }
    }
  }
};

export const fromDimensionInfo2SelectedMultiDimensionInfo = (
  dim: DimensionInfo,
  idList?: string[] | true,
): SelectedMultiDimensionInfo => {
  const values =
    idList === true
      ? dim.values
      : idList?.length
      ? compact(idList?.map(id => dim.values?.find(item => item.code === id)).filter(Boolean))
      : undefined;
  return {
    dim_info: fromDimensionInfo2SelectedDimensionInfo(dim, values, true)!,
  };
};
