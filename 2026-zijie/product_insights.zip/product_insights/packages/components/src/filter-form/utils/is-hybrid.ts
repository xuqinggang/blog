import { DimSimpleElement, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';

/** 判断是否命中B店混比比价口径 */
export function isHybrid(dimensions: (SelectedDimensionInfo | undefined)[], priceHybridList?: DimSimpleElement[]) {
  const selectedValues: DimSimpleElement[] = [];
  dimensions.forEach(dim => {
    const { id, selected_values } = dim ?? {};
    if (!selected_values?.length) {
      return;
    }

    // eslint-disable-next-line prefer-spread
    selectedValues.push.apply(
      selectedValues,
      selected_values.map(({ code, name }) => ({ id, code, name })),
    );
  });

  const result = selectedValues.some(({ code, id }) => priceHybridList?.some(i => i.code === code && i.id === id));
  return result;
}
