import { Dayjs } from 'dayjs';

import { RangeTime } from '~/MenuDatePicker';
import { DatePickerType } from '~/MenuDatePicker/utils';

export function getCompareDate(
  v: RangeTime,
  type: DatePickerType,
  validateDate: (date: RangeTime, activeKey?: DatePickerType) => RangeTime,
) {
  if (!v?.[0] || !v?.[1]) {
    return;
  }

  const compareDate: [Dayjs | null, Dayjs | null] = [v[0], v[1]];
  if (type === DatePickerType.DATE) {
    const diff = v[1].diff(v[0], 'd');
    compareDate[0] = v[0].subtract(diff + 1, 'd') || null;
    compareDate[1] = v[1].subtract(diff + 1, 'd') || null;
  } else {
    const lastPeriodStart = v?.[0]?.subtract(1, type as 'week' | 'month');
    compareDate[0] = lastPeriodStart || null;
    compareDate[1] = lastPeriodStart?.endOf(type as 'week' | 'month') || null;
  }

  const date = validateDate(compareDate);
  if (!date) {
    return;
  }

  const formattedCompareDate = date.map(d => (d ? d?.format('YYYY-MM-DD') : d));
  return formattedCompareDate;
}
