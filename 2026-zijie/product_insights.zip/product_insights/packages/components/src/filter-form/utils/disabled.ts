import { SelectedOption } from './format-enums';

import { OperatorType } from '~/api/product/namespaces/base';
import { EnumElement } from '~/api/product/namespaces/dimensions';
import { RuleValueType } from '~/RuleSelect';

export function getDisabledTip(selectedEnums?: string[], disabledEnums?: string[]) {
  let disabledTip: string | undefined;
  if (selectedEnums?.length) {
    disabledTip = '与筛选区选项冲突，无法选择';
  } else if (disabledEnums?.length) {
    disabledTip = '与其他已选项冲突，无法选择';
  }

  return disabledTip;
}

export function getDisabled(code: string, selected?: SelectedOption, disabledEnums?: string[]) {
  let disabled = false;
  if (selected?.selectedEnums?.length) {
    const { selectedEnums, selectedOperator } = selected;
    disabled = !selectedOperator ? !selectedEnums.includes(code) : selectedEnums.includes(code);
  } else if (disabledEnums?.length) {
    disabled = disabledEnums.includes(code);
  }

  return disabled;
}

// 获取存在依赖问题（不允许选中）的枚举值code列表
export function getDisabledEnums(selectedDimensions: RuleValueType[], dimId?: string, enums?: EnumElement[]) {
  const disabledEnums: string[] = [];
  const selectedDim = selectedDimensions.find(i => i?.id === dimId);

  if (selectedDim) {
    enums?.forEach(({ depend_code, code }) => {
      if (!depend_code?.length || !code) {
        return;
      }

      // 判断是否是依赖枚举值
      const isDepend = depend_code.some(d => {
        const dependDim = selectedDimensions.find(i => d?.id === i.id);
        if (!dependDim?.selected_values?.length) {
          return false;
        }

        const isInclude = Boolean(d.code && dependDim.selected_values.includes(d.code));

        // selected_operator 0 包含，1 不包含
        return dependDim.selected_operator === OperatorType.IN ? !isInclude : isInclude;
      });

      isDepend && disabledEnums.push(code);
    });
  }

  return disabledEnums;
}
