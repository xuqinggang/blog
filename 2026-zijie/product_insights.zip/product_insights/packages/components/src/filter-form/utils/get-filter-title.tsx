import { FieldDesc } from '@ecom/auxo-pro-form';

export function getFilterTitle(title: string, hidden?: boolean): FieldDesc {
  const filterTitle: FieldDesc = {
    type: 'custom',
    children: <div className="text-[#252931] font-medium">{title}</div>,
    itemProps: {
      className: 'filter-form__title',
    },
    hidden,
  };

  return filterTitle;
}
