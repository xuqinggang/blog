import { groupBy, intersectionBy } from 'lodash-es';

import { Rule, RuleObject, RuleRender } from '@ecom/auxo/es/components/form';

import { FieldCountItem } from '../types';

import { errorDepend } from './compute';
import { getSelectedDimFromFilter, transformDimItem2Rule } from './transform';

import { SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import {
  MAX_ERROR_DIM_COUNT,
  MAX_MULTI_DIM,
  MAX_SINGLE_DIMENSION_ENUM_COUNT,
  MIN_ANALYSIS_TARGET,
  MIN_MULTI_DIM,
  MIN_SINGLE_DIMENSION_ENUM_COUNT,
  PRICE_COMPARE_REQUIRED_DIMS,
} from '~/constant';
import { DimItem } from '~/DimCheckGroup';
import { RuleValueType } from '~/RuleSelect';

export const dimSelectorValidator = (form => ({
  validator: (_, value) => {
    const rootValue = form.getFieldsValue();
    const selectedDimensions = getSelectedDimFromFilter(rootValue);
    const allError: string[] = [];

    try {
      value?.forEach((dim: RuleValueType) => {
        if (dim.op_type?.includes('range_input')) {
          const [v1 = -Infinity, v2 = Infinity] = dim.selected_values ?? [];
          if (v2 < v1) throw new Error('范围选择输入错误，前值 < 后值');
        } else {
          dim.selected_option?.forEach(op => {
            const error = errorDepend(op.depend_code ?? [], selectedDimensions, Boolean(dim.selected_operator));
            const errorGroup = groupBy(error, 'id');
            const dependGroup = groupBy(op.depend_code, 'id');

            const hasError = Object.keys(errorGroup).some(
              k => errorGroup[k].length && errorGroup[k].length === dependGroup[k].length,
            );
            hasError && allError.push(op.name || '');
          }) ?? [];
        }
      });
    } catch (error) {
      return Promise.reject(error);
    }

    if (allError.length) {
      if (allError.length > MAX_ERROR_DIM_COUNT) {
        return Promise.reject(
          new Error(`选项 ${allError.slice(0, MAX_ERROR_DIM_COUNT).join('、')} 等${allError.length}个选项存在冲突`),
        );
      }

      return Promise.reject(new Error(`选项 ${allError.join('、')} 存在冲突`));
    }
    return Promise.resolve();
  },
})) as RuleRender;

export const priceCompareValidator: Rule = {
  type: 'array',
  validateTrigger: 'onSubmit',
  validator: (_, value: SelectedDimensionInfo[]) => {
    const intersection = intersectionBy(value, PRICE_COMPARE_REQUIRED_DIMS, 'id');

    let legalSelectedDim = 0;

    for (const i of intersection) {
      if (i.selected_values?.length) {
        legalSelectedDim++;
      }
    }

    if (legalSelectedDim === 2) {
      return Promise.reject(
        new Error(
          `维度 ${PRICE_COMPARE_REQUIRED_DIMS[0].name} 和 ${PRICE_COMPARE_REQUIRED_DIMS[1].name} 只能选择其中之一`,
        ),
      );
    } else if (legalSelectedDim === 0) {
      return Promise.reject(
        new Error(
          `维度 ${PRICE_COMPARE_REQUIRED_DIMS[0].name} 和 ${PRICE_COMPARE_REQUIRED_DIMS[1].name} 必须要选择其中之一`,
        ),
      );
    } else {
      return Promise.resolve();
    }
  },
};

export const dateValidator = (msg?: string) =>
  [
    {
      type: 'array',
      validateTrigger: 'onSubmit',
      validator: (_, value) => {
        if (!value || !value[0] || !value[1]) return Promise.reject(new Error(msg));
        return Promise.resolve();
      },
    },
  ] as Rule[];

/** 多维分析校验
 * 1. 维度个数校验（1-3）
 * 2. 选项不能为空
 * 3. 多维分析选项之间不能存在冲突
 */
export const multiDimValidator = (drillCount?: FieldCountItem, enumCount?: FieldCountItem): RuleObject => {
  const { min: drillMin = MIN_MULTI_DIM, max: drillMax = MAX_MULTI_DIM } = drillCount ?? {}; // 默认值
  const { min: enumMin = MIN_SINGLE_DIMENSION_ENUM_COUNT, max: enumMax = MAX_SINGLE_DIMENSION_ENUM_COUNT } =
    enumCount ?? {}; // 默认值

  return {
    validator: (_, value?: DimItem[]) => {
      const length = value?.length ?? 0;

      // 1. 维度个数校验
      if (length < drillMin) {
        return Promise.reject(new Error(`多维分析维度个数不能小于${drillMin}`));
      }

      if (length > drillMax) {
        return Promise.reject(new Error(`多维分析维度个数不能大于${drillMax}`));
      }

      // 2. 维度枚举值个数校验
      const enumsError: string[] = [];
      value?.forEach(({ selected_enums, label }) => {
        const length = selected_enums?.length ?? 0;
        if (length < enumMin || length > enumMax) {
          enumsError.push(label);
        }
      });

      if (enumsError.length) {
        return Promise.reject(
          new Error(`多维分析维度 ${enumsError.join('、')} 选项个数不能小于${enumMin}或大于${enumMax}`),
        );
      }

      // 3. 多维分析选项之间不能存在冲突
      const selectedRules = value?.map(transformDimItem2Rule) ?? [];
      const conflictError: string[] = [];

      value?.forEach(({ selected_enums }) => {
        selected_enums?.forEach(op => {
          const error = errorDepend(op.depend_code ?? [], selectedRules);
          const errorGroup = groupBy(error, 'id');
          const dependGroup = groupBy(op.depend_code, 'id');

          const hasError = Object.keys(errorGroup).some(
            k => errorGroup[k].length && errorGroup[k].length === dependGroup[k].length,
          );
          hasError && conflictError.push(op.name || '');
        }) ?? [];
      });

      if (conflictError.length) {
        if (conflictError.length > MAX_ERROR_DIM_COUNT) {
          return Promise.reject(
            new Error(
              `多维分析选项 ${conflictError.slice(0, MAX_ERROR_DIM_COUNT).join('、')} 等${
                conflictError.length
              }个选项存在冲突`,
            ),
          );
        }

        return Promise.reject(new Error(`多维分析选项 ${conflictError.join('、')} 存在冲突`));
      }

      return Promise.resolve();
    },
    validateTrigger: 'onChange',
  };
};

/**
 * 分析指标校验：指标个数 1-12
 */
export const targetListValidator = (count?: FieldCountItem): RuleObject => {
  const { min = MIN_ANALYSIS_TARGET, max = Infinity } = count ?? {}; // 默认值
  return {
    validator: (_, value?: string[]) => {
      const length = value?.length ?? 0;

      if (length < min) {
        return Promise.reject(new Error(`分析指标个数不能小于${min}`));
      }

      if (length > max) {
        return Promise.reject(new Error(`分析指标个数不能大于${max}`));
      }

      return Promise.resolve();
    },
    validateTrigger: 'onChange',
  };
};
