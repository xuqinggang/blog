import dayjs, { Dayjs } from 'dayjs';

import { dimensions } from '~/api/product';
import { RuleValueType } from '~/RuleSelect';

// 返回枚举存在依赖问题的依赖项
export const errorDepend = (depends: dimensions.DimSimpleElement[], selected: RuleValueType[], opposite = false) => {
  const errorDepends: dimensions.DimSimpleElement[] = [];
  depends?.forEach(depend => {
    // 判断是否 选择了依赖项对应维度，且是否 已选依赖项对应枚举
    const idx = selected.findIndex(item => {
      if (!(item.selected_values?.length && item.id === depend.id)) return false;
      const isIncludeDepend = item.selected_values?.includes(depend.code as string);
      // 包含说明已选改枚举(默认包含)，依赖没问题，不包含则相反
      return !item.selected_operator && !opposite ? !isIncludeDepend : isIncludeDepend;
    });
    idx !== -1 && errorDepends.push(depend);
  });
  return errorDepends;
};

export const filterEnums = (originEnums: dimensions.EnumElement[], selected: RuleValueType[]) => {
  return originEnums.filter(enumItem => {
    if (!enumItem.depend_code?.length) return true;
    return errorDepend(enumItem.depend_code ?? [], selected).length < (enumItem.depend_code?.length ?? 0);
  });
};

// 格式化时间选择器
// TODO 是否有更简单方式
export const dateFormatter = (valueFormat?: (v?: [Dayjs | null, Dayjs | null]) => [Dayjs | null, Dayjs | null]) => ({
  valueFromWidget(value?: [Dayjs | null, Dayjs | null]) {
    return (valueFormat?.(value) ?? value)?.map(d => d?.format('YYYY-MM-DD'));
  },
  valueToWidget(value: [string, string]) {
    return value?.map(d => (d ? dayjs(d) : null));
  },
});
