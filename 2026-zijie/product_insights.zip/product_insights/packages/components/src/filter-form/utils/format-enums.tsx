import { Tag, Tooltip } from '@ecom/auxo';
import { EnumOption } from '@ecom/auxo-pro-form/es/components';

import { getDisabled } from './disabled';

import { OperatorType } from '~/api/product/namespaces/base';
import { EnumElement } from '~/api/product/namespaces/dimensions';

export interface SelectedOption {
  selectedEnums?: string[];
  selectedOperator?: OperatorType;
}

export type IFormatEnumOption = EnumElement & EnumOption;

/**
 * 根据维度信息生成筛选项和多维分析枚举值
 * @param enums - 维度枚举值列表
 * @param selected - 筛选项中已选择的维度信息（适用于多维分析）
 * @param disabledEnums - 不允许选中的枚举值
 * @param withCode - 是否需要添加code标签前缀（适用于店铺搜索），默认false
 * @param disabledTip - 不允许选中的tip信息
 * @param renderLabelTip - 自定义渲染label tip信息
 * @param customDisabled - 自定义disabled逻辑
 * @param sortByDisabled - 是否根据disabled排序，默认true
 * @returns 格式化后的枚举值列表
 */
export function formatEnums(
  enums?: EnumElement[],
  selected?: SelectedOption,
  disabledEnums?: string[],
  withCode = false,
  disabledTip?: string,
  renderLabelTip?: (label: React.ReactNode, enumValue: EnumElement) => React.ReactNode,
  customDisabled?: (enumValue: EnumElement) => boolean,
  sortByDisabled = true,
) {
  const result = enums?.map<IFormatEnumOption>(v => {
    const disabled = customDisabled?.(v) ?? getDisabled(v.code ?? '', selected, disabledEnums);
    const label = withCode ? (
      <div className="flex items-center gap-[8px]">
        <div>{v.name}</div>
        <Tag color="gray">ID: {v.code}</Tag>
      </div>
    ) : (
      v.name || ''
    );

    return {
      value: v.code ?? '',
      label:
        disabledTip && disabled ? <Tooltip title={disabledTip}>{label}</Tooltip> : renderLabelTip?.(label, v) ?? label,
      disabled,
      ...v,
    };
  });

  return sortByDisabled
    ? result?.sort((a, b) => {
        // 如果 a.disabled 是 false 而 b.disabled 是 true，则 a 排在前面
        if (!a.disabled && b.disabled) {
          return -1;
        }
        // 如果 a.disabled 是 true 而 b.disabled 是 false，则 a 排在后面
        if (a.disabled && !b.disabled) {
          return 1;
        }
        // 如果 a.disabled 和 b.disabled 都是 true 或 false，则保持原顺序
        return 0;
      }) ?? []
    : result ?? [];
}
