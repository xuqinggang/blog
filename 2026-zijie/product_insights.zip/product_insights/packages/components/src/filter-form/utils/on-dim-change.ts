import { FormInstance } from '@ecom/auxo-pro-form';

import { CacheFilter } from '../types';

import { transformRule2SelectDim, updateGroupAttrs } from './transform';

import { BizType, DimensionAttributeType } from '~/api/product/namespaces/dimensions';
import { LATEST_CACHE_KEY_PREFIX } from '~/constant';
import { DimItem } from '~/DimCheckGroup';
import { RuleValueType } from '~/RuleSelect';

export function onDimChange(
  form: FormInstance,
  v: RuleValueType[],
  type: DimensionAttributeType,
  bizType: BizType,
  groupAttrs?: DimItem[],
) {
  if (!groupAttrs) {
    return;
  }

  const dims = v.map(i => transformRule2SelectDim(i, type));
  // 多维分析参数受维度参数约束，在这里做校验
  const { needUpdate, groupAttrs: newGroupAttrs } = updateGroupAttrs(groupAttrs, dims);
  if (needUpdate) {
    // 更新group_attrs
    form.pSetFieldsValue({ group_attrs: newGroupAttrs });
    // 缓存
    const cachedFilterString = localStorage.getItem(`${LATEST_CACHE_KEY_PREFIX}_${bizType}`);
    if (cachedFilterString) {
      try {
        const filter = JSON.parse(cachedFilterString) as CacheFilter;
        localStorage.setItem(
          `${LATEST_CACHE_KEY_PREFIX}_${bizType}`,
          JSON.stringify({
            ...filter,
            group_attrs: newGroupAttrs,
          }),
        );
      } catch (e) {
        console.error('Get cache filter error', e);
      }
    } else {
      localStorage.setItem(
        `${LATEST_CACHE_KEY_PREFIX}_${bizType}`,
        JSON.stringify({
          group_attrs: newGroupAttrs,
        }),
      );
    }
  }
}
