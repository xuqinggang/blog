import { DimensionType, DimGroupItem } from '../types';

import { formatDimListToCheckOption } from './format-multi-dim-list';

import { DimensionInfo, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import { DIM_GROUPS, MAX_SINGLE_DIMENSION_ENUM_COUNT } from '~/constant';
import { DimItem } from '~/DimCheckGroup';
import { RuleValueType } from '~/RuleSelect';

export function getMultiDimList(
  multiDimDimensions?: Partial<Record<DimensionType, DimensionInfo[]>> | null,
  selectedDimensions?: (SelectedDimensionInfo | RuleValueType)[],
  selectedGroupAttrs?: DimItem[],
  pageSize = MAX_SINGLE_DIMENSION_ENUM_COUNT,
  keyword?: string,
): Array<DimGroupItem> {
  return DIM_GROUPS.map(group => ({
    ...group,
    list:
      multiDimDimensions?.[group.key]
        ?.map<DimItem>(i =>
          formatDimListToCheckOption(i, group.key, selectedDimensions, selectedGroupAttrs, undefined, pageSize),
        )
        ?.filter(({ label }) => (keyword ? label.toLowerCase().indexOf(keyword.toLowerCase()) >= 0 : true)) ?? [],
  }));
}
