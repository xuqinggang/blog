import { groupBy, omit } from 'lodash-es';

import {
  AnalysisFilter,
  AnalysisServerFilter,
  BaseStruct,
  CommonFilter,
  CommonServerFilter,
  PriceFilter,
  PriceServerFilter,
} from '../types';

import { transformGroupAttrs2Filter, transformGroupAttrs2Server, transformRule2SelectDim } from './transform';

import {
  DimensionAttributeType,
  EnumElement,
  ProductAnalysisBaseStruct,
  SelectedDimensionInfo,
  ThresholdAttr,
} from '~/api/product/namespaces/dimensions';
import { DIM_GROUPS, ServerRange } from '~/constant';
import { RuleValueType } from '~/RuleSelect';

export const formatSelectedValues = (dimension: RuleValueType) => {
  if (dimension.op_type?.includes('range_input')) {
    const typeValue = ServerRange.map((defaultV, idx) => String(dimension.selected_values?.[idx] ?? defaultV));
    return [{ type_value: typeValue }];
  } else if (dimension.op_type?.includes('array_input')) {
    return [{ type_value: dimension.selected_values as string[] }];
  } else {
    const selectedValues = (dimension.selected_values as string[])?.map(v => ({ code: v })) ?? [];
    return [...selectedValues];
  }
};

export const formatDimValue = (value: EnumElement[], type?: string) => {
  const [firstV = {}] = value;
  const { type_value } = firstV;
  const isTypeValue = Boolean(type_value?.length);
  return {
    op_type: isTypeValue ? type || 'range_input' : undefined,
    selected_values: isTypeValue ? value[0].type_value : value.map(({ code }) => code || ''),
    selected_option: value,
  };
};

export function batchFormatDimensions(data: CommonFilter) {
  return DIM_GROUPS.reduce<SelectedDimensionInfo[]>((prev, curr) => {
    const { key, attrType } = curr;
    return prev.concat(data[key]?.map(i => transformRule2SelectDim(i, attrType)) ?? []);
  }, []);
}

export function formatFilterToServer(data: CommonFilter, isProdAnalysis: boolean): CommonServerFilter {
  const { user_dimensions, product_dimensions, place_dimensions, order_dimensions, group_attrs, ...otherFilter } = data;
  const groupAttrs = transformGroupAttrs2Server(group_attrs);
  const dimensions = batchFormatDimensions(data);

  if (isProdAnalysis) {
    // 商品分析
    const result = {
      dimensions,
      ...omit(otherFilter, ['threshold_type', 'analysis_date_type', 'compare_date_type']),
    } as AnalysisServerFilter;

    if (groupAttrs) {
      result.group_attrs = groupAttrs;
    }

    return result;
  }

  const result = {
    dimensions,
    ...otherFilter,
  } as PriceServerFilter;

  if (groupAttrs) {
    result.group_attrs = groupAttrs;
  }

  return result;
}

export function formatFilterFromServer(data: Partial<BaseStruct>, isProdAnalysis: boolean): CommonFilter {
  const { dimensions, group_attrs, ...otherFilter } = data;
  const groupAttrs = transformGroupAttrs2Filter(group_attrs, dimensions);
  const dimMap = groupBy(
    (dimensions as Array<SelectedDimensionInfo & { op_type: string }>)?.map(i => ({
      ...i,
      ...formatDimValue(i.selected_values ?? [], i.op_type),
    })),
    'attr_type',
  );
  const dimensionsData = {
    user_dimensions: dimMap[DimensionAttributeType.User] ?? [],
    product_dimensions: dimMap[DimensionAttributeType.Product] ?? [],
    place_dimensions: dimMap[DimensionAttributeType.Place] ?? [],
    order_dimensions: dimMap[DimensionAttributeType.Order] ?? [],
  };

  if (isProdAnalysis) {
    // 商品分析
    const { threshold_attrs, ...other } = otherFilter as Partial<
      Omit<ProductAnalysisBaseStruct, 'dimensions' | 'group_attrs'>
    >;
    const threshold = threshold_attrs?.length
      ? { threshold_type: threshold_attrs?.[0]?.type ?? 0, threshold_attrs }
      : { threshold_type: 2, threshold_attrs: [{ key: 'pay_ord_cnt' }] as ThresholdAttr[] };

    return {
      ...dimensionsData,
      ...threshold,
      ...omit(other, ['biz_type']),
      group_attrs: groupAttrs,
    } as AnalysisFilter;
  }

  // 价格力
  return {
    ...dimensionsData,
    ...omit(otherFilter, ['biz_type']),
    group_attrs: groupAttrs,
  } as PriceFilter;
}
