import { get } from 'lodash-es';

import { RemoteSelectProps } from '@ecom/auxo-pro-form';

import { CommonFilter, DefaultEnumMap } from '../types';

import { getDisabledEnums, getDisabledTip } from './disabled';
import { formatEnums } from './format-enums';
import { getSelectedDimFromFilter } from './transform';

import { productClient } from '~/api';
import { BizType, DimensionInfo, EnumElement } from '~/api/product/namespaces/dimensions';
import { ENUM_LIST_PAGE_SIZE } from '~/constant';
import { OperatorTypeEnum, RuleOption, SelectType } from '~/RuleSelect';

export function formatDimList(
  dim: DimensionInfo,
  bizType: BizType,
  rootValue: CommonFilter = {},
  defaultEnumMap: DefaultEnumMap = {},
  customizeItem?: Record<
    string,
    {
      render?: (label: React.ReactNode, enumValue: EnumElement) => React.ReactNode;
      disabled?: (enumValue: EnumElement) => boolean;
    }
  >,
): RuleOption {
  const { id, show_name, show_type, values = [], reject_dim_ids } = dim;
  const defaultEnums = defaultEnumMap[id || ''];
  const selectedDimensions = getSelectedDimFromFilter(rootValue);
  const dependSelect = selectedDimensions?.filter(i => reject_dim_ids?.includes(String(i?.id) || '')); // 依赖的维度
  const withCode = show_type === SelectType.BasicInfoSearchInput || show_type === SelectType.BasicInfoSearchSingleInput;
  const disabledEnums = getDisabledEnums(selectedDimensions, id, values); // 筛选维度中冲突的枚举值
  const disabledTip = getDisabledTip(undefined, disabledEnums);

  return {
    value: id || '',
    label: show_name,
    type:
      !withCode && dim.need_page_search
        ? show_type === SelectType.SingleSelect
          ? SelectType.RemoteSingleSelect
          : SelectType.RemoteMultiSelect
        : show_type,
    operatorType: OperatorTypeEnum.INCLUDE,
    enums: formatEnums(values, undefined, disabledEnums, withCode, disabledTip),
    valueProps:
      dim.need_page_search && id
        ? ({
            defaultEnums, // 增加defaultEnums，用于数据回显
            service: async ({ search = '', page = 1 }) => {
              // if (withCode && !search) {
              //   // BasicInfoSearchInput和BasicInfoSearchSingleInput类型组件如果没有搜索条件，则直接返回
              //   return;
              // }

              // 依赖维度
              const dependDims = dependSelect.map(selectItem => ({
                ...selectItem,
                id: String(selectItem.id),
                selected_values: selectItem.selected_values?.map(v => ({ code: String(v) })),
              }));

              const { data } = await productClient.GetDimensionPageEnumList({
                dimension_id: id,
                search_enum_name: search,
                page_info: { page_num: page, page_size: ENUM_LIST_PAGE_SIZE },
                depend_dims: dependDims,
                biz_type: bizType,
              });

              const remoteDisabledEnums = getDisabledEnums(selectedDimensions, id, data.enum_list);
              const remoteDisabledTip = getDisabledTip(undefined, remoteDisabledEnums);
              const res =
                formatEnums(
                  data.enum_list,
                  undefined,
                  remoteDisabledEnums,
                  withCode,
                  remoteDisabledTip,
                  get(customizeItem, id)?.render,
                  get(customizeItem, id)?.disabled,
                ) || [];
              console.log('xxxxxenums.service valueprops', res, data, defaultEnums);
              return res;
            },
            refreshDeps: dependSelect.map(i => i.selected_values?.length),
            loadMore: true,
            showAllCheckbox: false,
          } as RemoteSelectProps)
        : undefined,
  };
}
