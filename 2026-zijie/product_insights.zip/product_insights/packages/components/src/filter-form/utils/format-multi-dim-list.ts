import { EnumOption } from '@ecom/auxo-pro-form';

import { getDisabledEnums, getDisabledTip } from './disabled';
import { formatEnums } from './format-enums';
import { transformDimItem2Rule } from './transform';

import { productClient } from '~/api';
import { DimensionInfo, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import { MAX_SINGLE_DIMENSION_ENUM_COUNT } from '~/constant';
import { DimItem } from '~/DimCheckGroup';
import { RuleValueType, SelectType } from '~/RuleSelect';
import { getEnumCodeList } from '~/utils';
/** 多维分析 */
export const formatDimListToCheckOption = (
  dim: DimensionInfo,
  group: string,
  selectedDimensions?: (SelectedDimensionInfo | RuleValueType)[],
  selectedGroupAttrs?: DimItem[],
  selectedOptions?: EnumOption[],
  pageSize = MAX_SINGLE_DIMENSION_ENUM_COUNT,
): DimItem => {
  const {
    show_name,
    id,
    values,
    need_page_search,
    dimension_group,
    dimension_group_order,
    show_type,
    dimension_group_dim_order,
  } = dim;
  const withCode = show_type === SelectType.BasicInfoSearchInput || show_type === SelectType.BasicInfoSearchSingleInput;

  const selectedDim = selectedDimensions?.find(i => i?.id === id);
  const selectedEnums = (
    (selectedDim as RuleValueType)?.selected_option ?? (selectedDim as SelectedDimensionInfo)?.selected_values
  )?.map(({ code }) => code || ''); // 筛选项中已经选中的维度枚举值（子集）

  const selectedRules = selectedGroupAttrs?.map(transformDimItem2Rule) ?? [];
  const disabledEnums = getDisabledEnums(selectedRules, id, values); // 多维分析中冲突的枚举值
  const disabledTip = getDisabledTip(selectedEnums, disabledEnums);

  return {
    label: show_name ?? '',
    value: id ?? '',
    selected_enums: selectedOptions,
    group,
    enums: formatEnums(
      values,
      {
        selectedEnums,
        selectedOperator: selectedDim?.selected_operator,
      },
      disabledEnums,
      withCode,
      disabledTip,
    ),
    remote: need_page_search
      ? selected => {
          const dependSelect = selected?.filter(i => dim.reject_dim_ids?.includes(String(i.id)));

          const dependDims = dependSelect?.map(selectItem => ({
            ...selectItem,
            id: String(selectItem.id),
            selected_values: selectItem.selected_values?.map(v => ({ code: String(v) })),
          }));

          return {
            service: async ({ search = '', page = 1 }) => {
              if (!dim.id) return [];
              const { data } = await productClient.GetDimensionPageEnumList({
                dimension_id: dim.id,
                search_enum_name: search,
                page_info: { page_num: page, page_size: pageSize },
                depend_dims: dependDims,
                enum_code_list: getEnumCodeList(selectedDimensions, dim),
              });

              const remoteDisabledEnums = getDisabledEnums(selectedRules, id, data.enum_list);
              const remoteDisabledTip = getDisabledTip(selectedEnums, remoteDisabledEnums);
              return formatEnums(
                data.enum_list,
                {
                  selectedEnums,
                  selectedOperator: selectedDim?.selected_operator,
                },
                remoteDisabledEnums,
                withCode,
                remoteDisabledTip,
              );
            },
            refreshDeps: dependSelect?.map(i => i.selected_values?.length ?? 0) ?? [],
          };
        }
      : undefined,
    show_type,
    dimension_group,
    dimension_group_order,
    dimension_group_dim_order,
  };
};
