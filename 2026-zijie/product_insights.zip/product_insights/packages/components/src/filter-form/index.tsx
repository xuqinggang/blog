import { forwardRef, memo, useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { useUpdateEffect } from 'ahooks';
import { mapValues, omit } from 'lodash-es';

import { Form, FormInstance } from '@ecom/auxo-pro-form';

import { DimCheckedValue, DimModal } from '../dim-model';

import { CustomizeOption, useFormJson } from './hooks/use-form-json';
import { formatFilterFromServer, formatFilterToServer } from './utils/filters';
import { DimensionType, FilterFormProps } from './types';

import './index.scss';

import { DimensionInfo, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import { DIMENSION_TYPE_LIST } from '~/constant';

export const FilterForm = memo(
  forwardRef<FormInstance, FilterFormProps & CustomizeOption>((props, ref) => {
    const {
      bizType,
      baseStruct,
      operator,
      isProdAnalysis = true,
      visible: propsVisible,
      requiredDimInfo,
      dimensionData,
      onFinish,
      onChange,
      onReset,
      customPJson,
      labelCol,
      pLayout,
      ...rest
    } = props;
    const { ruleFilter: ruleFilterVisible = true } = propsVisible ?? {};

    const [filterForm] = Form.useForm();
    const isFormInit = useRef(false);
    const [visible, setVisible] = useState(false); // 筛选维度弹窗可见性
    const [dimKey, setDimKey] = useState<DimensionType>(DIMENSION_TYPE_LIST[0] as DimensionType); // 当前modal对应的dimension，用于过滤显示的属性维度
    const [dimModalInitial, setDimModalInitial] = useState({} as DimCheckedValue);

    // 打开维度筛选弹窗
    const openDimModal = useCallback(
      (dim?: string) => {
        const curFormDimValue = filterForm.pGetFieldsValue(DIMENSION_TYPE_LIST);
        const curDimListMap = mapValues(curFormDimValue, v => v?.map((i: DimensionInfo) => i.id));
        setDimModalInitial(curDimListMap as DimCheckedValue);
        setVisible(true);
        dim && setDimKey(dim as DimensionType);
      },
      [filterForm],
    );

    // 选中维度指标的回调
    const handleCheckedDim = (checkedValue: DimCheckedValue) => {
      const curFormDimValue = filterForm.pGetFieldsValue(DIMENSION_TYPE_LIST);
      const newData = {} as Record<string, SelectedDimensionInfo[]>;
      DIMENSION_TYPE_LIST.forEach(key => {
        const selected: SelectedDimensionInfo[] = curFormDimValue[key] ?? [];
        const checkedItems =
          checkedValue[key as DimensionType]?.map<SelectedDimensionInfo>(
            i =>
              selected.find(s => s.id === i) || {
                id: i,
                // 假设 DimensionType 是一个合法的索引类型，使用类型断言确保 key 可以作为索引
                name: (dimensionData?.[key as keyof typeof dimensionData] as DimensionInfo[])?.find(j => j.id === i)
                  ?.show_name,
              },
          ) ?? [];
        newData[key] = checkedItems;
      });
      filterForm.pSetFieldsValue(newData);
      const filter = filterForm.pGetFieldsValue();
      const baseStruct = formatFilterToServer(filter, isProdAnalysis);
      onChange?.(filter, baseStruct);
      setVisible(false);
    };

    console.log('pJson run');

    const pJson = useFormJson(openDimModal, omit(props, ['operator', 'onFinish', 'onReset']));

    // 切换业务线重置isFormInit
    useUpdateEffect(() => {
      isFormInit.current = false;
    }, [bizType]);

    useImperativeHandle(ref, () => filterForm, [filterForm]);

    // baseStruct受控
    useEffect(() => {
      if (baseStruct) {
        const filter = formatFilterFromServer(baseStruct, isProdAnalysis);
        filterForm.pSetFieldsValue(filter);
        onChange?.(filter, baseStruct);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [baseStruct, isProdAnalysis, onChange]);

    return (
      <>
        <Form
          form={filterForm}
          labelCol={labelCol ?? { span: 3 }}
          onFinish={onFinish}
          onReset={onReset}
          onValuesChange={(changedValues, values) => {
            if (isProdAnalysis && ruleFilterVisible && !isFormInit.current) {
              // PS: 由于CustomLogic组件会在传入初始化value时调用一次onChange，所以这里会额外调用一次，需要过滤掉
              isFormInit.current = true;
              return;
            }

            const baseStruct = formatFilterToServer(values, isProdAnalysis);
            onChange?.(values, baseStruct, changedValues);
          }}
          pJson={customPJson?.(pJson) ?? pJson}
          pLayout={
            pLayout ?? {
              gutter: [0, 16],
              disableItemMargin: true,
              style: { padding: 0 },
            }
          }
          {...omit(rest, [
            'readyTime',
            'multiDimDimensions',
            'targetList',
            'showSubTitle',
            'defaultEnumMap',
            'disabled',
            'validate',
            'count',
            'dimensionLayout',
          ])}
        >
          {operator}
        </Form>
        <DimModal
          dimensionKey={dimKey}
          visible={visible}
          initialValue={dimModalInitial}
          disabledDimList={requiredDimInfo?.map(({ id }) => id ?? '')}
          dimensionData={dimensionData}
          onOK={handleCheckedDim}
          onCancel={() => setVisible(false)}
        />
      </>
    );
  }),
);

FilterForm.displayName = 'FilterForm';

export { DEFAULT_CUSTOMIZE_ITEMS } from './customize';

export type { BaseStruct, CommonServerFilter, DefaultEnumMap } from './types';
