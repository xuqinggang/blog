import { useCallback, useMemo } from 'react';
import dayjs, { Dayjs, ManipulateType } from 'dayjs';

import { message } from '@ecom/auxo';

import { DataReadyTime } from '~/api/product/namespaces/dimensions';
import { RangeTime } from '~/MenuDatePicker';
import { DatePickerType, transformDateType } from '~/MenuDatePicker/utils';

const unitMap = {
  [DatePickerType.MONTH]: '月',
  [DatePickerType.WEEK]: '周',
  [DatePickerType.DATE]: '日',
};

export function useValidateDate(readyTime?: DataReadyTime | null, isProdAnalysis = true) {
  // 最早和最新可用的日期
  const { oldestDate, latestDate } = useMemo(() => {
    const { oldest_partition, newest_partition } = readyTime ?? {};
    return {
      oldestDate: dayjs(oldest_partition ?? 0).startOf('day'),
      latestDate: dayjs(newest_partition ?? 0).endOf('day'),
    };
  }, [readyTime]);

  // 返回一个日期是否禁用
  const disabledDate = useCallback(
    (date: Dayjs, type?: DatePickerType, value?: RangeTime) => {
      if (!readyTime) {
        return false;
      }

      // 不能选择只能日期范围之外的日期
      if (date < oldestDate || date > latestDate) {
        return true;
      }

      if (!type || !value) {
        return false;
      }

      // #region 使用date_range_info判断不能选中的日期范围（只限制最大可选范围，最小可选范围通过toast提示）
      const { date_range_info } = readyTime;
      const dateType = transformDateType(type);
      const maxRange = date_range_info?.find(({ date_type }) => date_type === dateType)?.max_date_range;
      if (!maxRange) {
        return false;
      }

      const [start, end] = value;
      const unit = transformDateType(type, true) as ManipulateType;
      const tooLate =
        type === DatePickerType.DATE
          ? Boolean(start && date > start.add(Number(maxRange), unit))
          : Boolean(start && date >= start.add(Number(maxRange), unit).startOf(unit));
      const tooEarly =
        type === DatePickerType.DATE
          ? Boolean(end && date < end.subtract(Number(maxRange), unit))
          : Boolean(end && date <= end.subtract(Number(maxRange), unit).endOf(unit));

      return tooLate || tooEarly;
    },
    [latestDate, oldestDate, readyTime],
  );

  // 校验所选的日期是否符合要求
  const validateDate = useCallback(
    (date: RangeTime, activeKey?: DatePickerType): RangeTime => {
      const [start, end] = date ?? [];

      if (isProdAnalysis) {
        // 商品分析
        let indeedStart: Dayjs | null | undefined;
        let indeedEnd: Dayjs | null | undefined;

        if (!start || !disabledDate(start)) {
          indeedStart = start;
        } else {
          indeedStart = oldestDate;
        }

        if (!end || !disabledDate(end, DatePickerType.DATE, date ?? [null, null])) {
          indeedEnd = end;
        } else {
          indeedEnd = indeedStart?.add(
            Number(
              readyTime?.date_range_info?.find(({ date_type }) => date_type === transformDateType(DatePickerType.DATE))
                ?.max_date_range ?? 0,
            ),
            'd',
          );
        }

        if (indeedEnd && indeedEnd > latestDate) {
          indeedEnd = latestDate;
        }

        return [indeedStart ?? null, indeedEnd ?? null];
      } else {
        // 价格力分析
        if (!start || !end || !activeKey) {
          return;
        }

        const unit = transformDateType(activeKey, true) as ManipulateType;
        const unitName = unitMap[activeKey];
        if (disabledDate(start) || disabledDate(end)) {
          // 时间范围不符合
          message.warn(`超出日期范围 ${oldestDate.format('YYYY-MM-DD')} - ${latestDate.format('YYYY-MM-DD')}`);
          return;
        }

        const range = readyTime?.date_range_info?.find(({ date_type }) => date_type === transformDateType(activeKey));
        if (range) {
          // 选择的粒度范围不符合
          const diff = end.diff(start, unit);
          const { max_date_range, min_date_range } = range;

          if (max_date_range && diff > Number(max_date_range) - 1) {
            // 大于最大范围
            message.warn(`分析周期范围不能大于 ${max_date_range} ${unitName}`);
            return;
          }

          if (min_date_range && diff < Number(min_date_range) - 1) {
            // 小于最小范围
            message.warn(`分析周期范围不能小于 ${min_date_range} ${unitName}`);
            return;
          }
        }

        return date;
      }
    },
    [disabledDate, isProdAnalysis, latestDate, oldestDate, readyTime],
  );

  return {
    oldestDate,
    latestDate,
    validateDate,
    disabledDate,
  };
}
