import { useMemo } from 'react';

import { Icon, Tooltip } from '@ecom/auxo';
import { FieldDesc, FormDesc, FormInstance } from '@ecom/auxo-pro-form';

import { FilterFormProps } from '../types';
import { dateFormatter } from '../utils/compute';
import { getCompareDate } from '../utils/get-compare-date';
import { dateValidator } from '../utils/validators';

import { useValidateDate } from './use-validate-date';

import { DateType } from '~/api/product/namespaces/base';
import { formatFilterToServer } from '~/filter-form/utils/filters';
import { MenuDatePicker, MenuDatePickerProps, RangeTime, RecentDateType } from '~/MenuDatePicker';
import { DatePickerType, transformDateType } from '~/MenuDatePicker/utils';
import { isPriceCompare, isPriceTrend } from '~/utils/is';

export function useDateField(
  isInline = false,
  options: Pick<
    FilterFormProps,
    'onChange' | 'visible' | 'disabled' | 'validate' | 'isProdAnalysis' | 'bizType' | 'readyTime' | 'dateFieldLayout'
  >,
) {
  const { onChange, visible, disabled, validate, isProdAnalysis = true, readyTime, bizType, dateFieldLayout } = options;
  const { disabledDate, validateDate } = useValidateDate(readyTime, isProdAnalysis);
  const extraText = isProdAnalysis
    ? '由于集群性能有限，自定义周期的分析最多支持31天范围。'
    : '选择日期的单位为自然周时，趋势分析粒度为周（最多12周）；选择自然月时，分析粒度为月（最多3个月）；选择自定义周期时，分析粒度为日（最多30天）';

  const fields = useMemo<FormDesc>(() => {
    const { analysisDate: analysisDateVisible = true, compareDate: compareDateVisible = true } = visible ?? {};
    const { analysisDate: analysisDateDisabled = false, compareDate: compareDateDisabled = false } = disabled ?? {};
    const { analysisDate: analysisDateValidate = true, compareDate: compareDateValidate = true } = validate ?? {};
    const isTrend = isPriceTrend(bizType); // 价格力趋势（SKU/订单/曝光）
    const isPriceAA = isPriceCompare(bizType); // 价格AA对比

    function handleChange(form: FormInstance) {
      const filter = form.pGetFieldsValue();
      const baseStruct = formatFilterToServer(filter, isProdAnalysis);
      onChange?.(filter, baseStruct);
    }

    /** 分析周期类型（日、周、月） */
    const analysisTypeField: FieldDesc = {
      name: 'analysis_date_type',
      type: 'text',
      itemProps: {
        hidden: true,
        noStyle: true,
      },
      hidden: !isProdAnalysis || !analysisDateVisible,
    };

    /** 对比周期类型（日、周、月） */
    const compareTypeField: FieldDesc = {
      name: 'compare_date_type',
      type: 'text',
      itemProps: {
        hidden: true,
        noStyle: true,
      },
      hidden: !isProdAnalysis || !compareDateVisible,
    };

    /** 分析周期 */
    const analysisDateField: FieldDesc = {
      label: (
        <span className="flex items-center gap-[2px]">
          分析周期
          <Tooltip title={extraText}>
            <Icon.DoubtIcon className="cursor-pointer" />
          </Tooltip>
        </span>
      ),
      type: 'custom',
      name: '[start_date, end_date]',
      children: (
        <MenuDatePicker
          className="w-full"
          isProdAnalysis={isProdAnalysis}
          disabledMonth={isProdAnalysis} // 商品分析需要隐藏月份
          showRecentSelect={isProdAnalysis} // 商品分析需要展示「近x天」的选择
          disabledDate={disabledDate}
          validateDate={validateDate}
          disabled={analysisDateDisabled}
          readyTime={readyTime}
        />
      ),
      hidden: !analysisDateVisible,
      itemProps: {
        pLayout: isInline ? undefined : { span: 12 },
        labelCol: isInline ? undefined : { span: 6 },
        labelAlign: dateFieldLayout?.analysisDateFieldLabelAlign ?? 'left',
        required: true,
        pTransformer: dateFormatter(),
        extra: isInline ? undefined : extraText,
      },
      dynamicProps: opts => {
        const { form, rootValue } = opts;

        return {
          // activeKey: isProdAnalysis ? rootValue?.compare_date_type : undefined, // 「商品分析」传入比较周期的粒度
          recentDate: isProdAnalysis ? rootValue?.recent_date : undefined, // 「商品分析」传入最近x天
          onChange: (v: RangeTime, type: DatePickerType, recentDate?: RecentDateType) => {
            if (isPriceAA) {
              return;
            }

            isProdAnalysis && form.pSetFieldsValue({ analysis_date_type: type });
            isTrend && form.pSetFieldsValue({ date_type: transformDateType(type) as DateType });

            if (!isProdAnalysis) {
              handleChange(form);
              return;
            }

            // 商品分析 - 根据分析周期设置对比周期
            const compareDate = getCompareDate(v, type, validateDate);
            if (!compareDate) {
              handleChange(form);
              return;
            }

            form.pSetFieldsValue({
              // eslint-disable-next-line @typescript-eslint/naming-convention
              '[compare_start_date, compare_end_date]': compareDate,
            });
            form.pValidateFields(['[compare_start_date, compare_end_date]']);

            // 商品分析 - 设置recent_date
            form.pSetFieldsValue({
              recent_date: recentDate,
            });

            handleChange(form);
          },
        } as Partial<MenuDatePickerProps>;
      },
      dependencies: ['recent_date'],
      // shouldUpdate: (pre, cur) =>
      //   isProdAnalysis && (cur.compare_date_type !== pre.compare_date_type || cur.recent_date !== pre.recent_date),
      rules: analysisDateValidate ? dateValidator('请选择分析周期') : undefined,
    };

    /** 近x天 */
    const recentDateField: FieldDesc = {
      type: 'custom',
      name: 'recent_date',
      itemProps: {
        hidden: true,
        noStyle: true,
      },
    };

    /** 对比周期 */
    const compareDateField: FieldDesc = {
      label: '对比周期',
      type: 'custom',
      name: '[compare_start_date, compare_end_date]',
      children: (
        <MenuDatePicker
          className="w-full"
          isProdAnalysis={isProdAnalysis}
          disabledMonth={isProdAnalysis} // 商品分析需要隐藏月份
          disabledDate={disabledDate}
          validateDate={validateDate}
          disabled={compareDateDisabled}
        />
      ),
      itemProps: {
        pLayout: isInline ? undefined : { span: 12 },
        labelCol: isInline ? undefined : { span: 6 },
        labelAlign: 'left',
        required: true,
        pTransformer: dateFormatter(),
      },
      hidden: !isProdAnalysis || !compareDateVisible,
      dynamicProps: ({ form, rootValue }) =>
        ({
          activeKey: rootValue.analysis_date_type,
          onChange: (_, type) => {
            form.pSetFieldsValue({ compare_date_type: type });
            handleChange(form);
          },
        } as Partial<MenuDatePickerProps>),
      dependencies: ['analysis_date_type'],
      // shouldUpdate: (pre, cur) => cur.analysis_date_type !== pre.analysis_date_type,
      rules: compareDateValidate ? dateValidator('请选择对比周期') : undefined,
    };

    return [analysisTypeField, compareTypeField, analysisDateField, compareDateField, recentDateField];
  }, [
    bizType,
    disabled,
    disabledDate,
    extraText,
    isInline,
    isProdAnalysis,
    onChange,
    readyTime,
    validate,
    validateDate,
    visible,
  ]);

  return fields;
}
