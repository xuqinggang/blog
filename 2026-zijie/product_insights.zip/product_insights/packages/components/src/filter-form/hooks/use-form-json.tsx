/* eslint-disable max-lines-per-function */
import { useMemo } from 'react';
import { isEmpty } from 'lodash-es';

import { CustomLogic, IsLogic } from '@ecom/arctic-components';
import { Icon, Tooltip } from '@ecom/auxo';
import { FieldDesc, FormDesc, FormInstance } from '@ecom/auxo-pro-form';

import { DateType, LogicalExprType } from '~/api/product/namespaces/base';
import {
  AnalysisGranularity,
  BizType,
  DateRule,
  DateRuleType,
  DimensionAttributeType,
  EnumElement,
  TargetElementValue,
  ThresholdType,
} from '~/api/product/namespaces/dimensions';
import {
  DIMENSION_TYPE_LIST,
  MAX_MULTI_DIM,
  MAX_SINGLE_DIMENSION_ENUM_COUNT,
  MIN_ANALYSIS_TARGET,
  MIN_MULTI_DIM,
  MIN_SINGLE_DIMENSION_ENUM_COUNT,
} from '~/constant';
import { CrossDimPickDrawer } from '~/CrossDimPickDrawer';
import { DimEnumFilter, DimEnumFilterProps } from '~/DimEnumFilter';
import RuleSelect, { OperatorTypeEnum, RuleSelectProps, SelectType } from '~/RuleSelect';
import RuleSelectList, { RuleSelectListProps } from '~/RuleSelectList';
import { TargetListDrawer } from '~/target-list-drawer';
import { TargetListEditor, TargetListEditorProps } from '~/target-list-editor';
import { isPriceCompare, isPriceTrend } from '~/utils/is';

import { DimensionType, FilterFormProps } from '../types';
import { formatFilterToServer } from '../utils/filters';
import { formatDimList } from '../utils/format-dim-list';
import { getFilterTitle } from '../utils/get-filter-title';
import { onDimChange } from '../utils/on-dim-change';
import { getSelectedDimFromFilter } from '../utils/transform';
import {
  dimSelectorValidator,
  multiDimValidator,
  priceCompareValidator,
  targetListValidator,
} from '../utils/validators';

import { useDateField } from './use-date-field';

import '../index.scss';

export interface CustomizeOption {
  customizeItem?: Record<
    string,
    {
      render?: (label: React.ReactNode, enumValue: EnumElement) => React.ReactNode;
      disabled?: (enumValue: EnumElement) => boolean;
    }
  >;
}
// TODO: 根据field拆分成多个hook
export function useFormJson(
  openDimModal: (dimKey?: DimensionType) => void,
  options: Omit<FilterFormProps, 'operator' | 'onFinish' | 'onReset'> & CustomizeOption,
): FormDesc {
  const {
    readyTime,
    dimensionData,
    bizType,
    multiDimDimensions,
    requiredDimInfo,
    targetList,
    isProdAnalysis = true,
    defaultEnumMap,
    visible,
    disabled,
    validate,
    showSubTitle = true,
    count = {},
    dimensionLayout = 'flex',
    dateFieldLayout,
    onChange,
    customizeItem,
    prodDimensionLabel,
  } = options;

  const dateFields = useDateField(false, {
    onChange,
    visible,
    disabled,
    validate,
    isProdAnalysis,
    bizType,
    readyTime,
    dateFieldLayout,
  });

  const fields = useMemo<FormDesc>(() => {
    console.log('xxxxx111defaultEnumMap', defaultEnumMap);
    const {
      targetFilter: targetFilterCount = {},
      drillFilter: drillFilterCount = {},
      drillEnum: drillEnumCount = {},
    } = count;
    const { min: targetMin = MIN_ANALYSIS_TARGET, max: targetMax = Infinity } = targetFilterCount;
    const { min: drillMin = MIN_MULTI_DIM, max: drillMax = MAX_MULTI_DIM } = drillFilterCount;
    const { min: drillEnumMin = MIN_SINGLE_DIMENSION_ENUM_COUNT, max: drillEnumMax = MAX_SINGLE_DIMENSION_ENUM_COUNT } =
      drillEnumCount;

    const attrMetaMap = dimensionData?.threshold_attr_meta?.reduce((buf, { type, value_list = [] }) => {
      type !== undefined && (buf[type] = value_list ?? []);
      return buf;
    }, {} as Record<number, TargetElementValue[]>);

    const isTrend = isPriceTrend(bizType); // 价格力趋势（SKU/订单/曝光）
    const isPriceAA = isPriceCompare(bizType); // 价格AA对比

    const {
      drillFilter: drillFilterVisible = true,
      targetFilter: targetFilterVisible = true,
      dimFilter: dimFilterVisible = true,
      ruleFilter: ruleFilterVisible = true,
    } = visible ?? {};
    const {
      // drillFilter: drillFilterDisabled = false,
      // targetFilter: targetFilterDisabled = false,
      dimFilter: dimFilterDisabled = false,
    } = disabled ?? {};
    const {
      drillFilter: drillFilterValidate = true,
      targetFilter: targetFilterValidate = true,
      dimFilter: dimFilterValidate = true,
    } = validate ?? {};

    const hiddenFilterTitle = !showSubTitle || (!dimFilterVisible && !ruleFilterVisible); // 是否隐藏筛选项标题
    const hiddenTargetTitle = !showSubTitle || !isProdAnalysis || !targetFilterVisible; // 是否隐藏指标筛选项标题
    const hiddenDrillTitle = !showSubTitle || !isProdAnalysis || !drillFilterVisible; // 是否隐藏下钻筛选项标题

    function handleChange(form: FormInstance) {
      const filter = form.pGetFieldsValue();
      const baseStruct = formatFilterToServer(filter, isProdAnalysis);
      onChange?.(filter, baseStruct);
    }

    /** 趋势分析粒度（价格力趋势洞察） */
    const dateTypeField: FieldDesc = {
      label: '趋势分析粒度',
      name: 'date_type',
      type: 'enum',
      props: {
        isRadio: true,
        radioProps: {
          optionType: 'button',
        },
      },
      itemProps: {
        extra: '此处的粒度会控制分析结果中所有趋势图横轴的粒度，您可以在【分析周期】修改粒度。',
      },
      dynamicProps(opts) {
        const { rootValue } = opts;
        return {
          enums: [
            {
              label: '日',
              value: DateType.DAY,
              disabled: rootValue.date_type !== DateType.DAY,
            },
            {
              label: '周',
              value: DateType.WEEK,
              disabled: rootValue.date_type !== DateType.WEEK,
            },
            {
              label: '月',
              value: DateType.MONTH,
              disabled: rootValue.date_type !== DateType.MONTH,
            },
          ],
        };
      },
      dependencies: ['date_type'],
      hidden: !isTrend,
    };

    /** 商品分析粒度 */
    const granularityField: FieldDesc = {
      label: '商品分析粒度',
      name: 'granularity',
      type: 'enum',
      enums: [
        { label: 'SKU ID', value: AnalysisGranularity.SKU },
        { label: '商品 ID', value: AnalysisGranularity.PROD }, // SKU价格力只允许选SKU ID粒度
      ],
      hidden: !isPriceAA, // 只价格力AA对比才需要展示「商品分析粒度」
      props: {
        isRadio: true,
        radioProps: {
          optionType: 'button',
        },
      },
    };

    /** 商品属性 */
    const prodDimensionField: FieldDesc = {
      label: prodDimensionLabel ? (
        prodDimensionLabel
      ) : (
        <span className="flex items-center gap-[2px]">
          商品属性
          <Tooltip title="按照商品属性筛选商品">
            <Icon.DoubtIcon className="cursor-pointer" />
          </Tooltip>
        </span>
      ),
      type: 'custom',
      name: 'product_dimensions',
      children: (
        <RuleSelectList
          disabled={dimFilterDisabled}
          list={[]}
          onItemAdd={() => openDimModal('product_dimensions')}
          layout={dimensionLayout}
        />
      ),
      hidden: !Boolean(dimensionData?.product_dimensions?.length) || !dimFilterVisible,
      dynamicProps: ({ rootValue, form }) =>
        ({
          list: isEmpty(rootValue)
            ? []
            : dimensionData?.product_dimensions?.map(dim =>
                formatDimList(dim, bizType, rootValue, defaultEnumMap, customizeItem),
              ) ?? [],
          onItemAdd: () => openDimModal('product_dimensions'),
          requiredDimInfo,
          onChange(v) {
            onDimChange(form, v ?? [], DimensionAttributeType.Product, bizType, rootValue?.group_attrs);
          },
        } as Partial<RuleSelectListProps>),
      dependencies: [],
      rules: dimFilterValidate
        ? isPriceAA
          ? [priceCompareValidator, dimSelectorValidator]
          : [dimSelectorValidator]
        : undefined, // 价格力AA对比特化校验逻辑
    };

    /** 用户属性 */
    const userDimensionField: FieldDesc = {
      label: (
        <span className="flex items-center gap-[2px]">
          用户属性
          <Tooltip title="此处筛选的是对特定用户曝光过的商品">
            <Icon.DoubtIcon className="cursor-pointer" />
          </Tooltip>
        </span>
      ),
      type: 'custom',
      name: 'user_dimensions',
      children: <RuleSelectList list={[]} onItemAdd={() => openDimModal('user_dimensions')} layout={dimensionLayout} />,
      hidden: !Boolean(dimensionData?.user_dimensions?.length) || !dimFilterVisible,
      dynamicProps: ({ rootValue, form }) =>
        ({
          list: isEmpty(rootValue)
            ? []
            : dimensionData?.user_dimensions?.map(dim =>
                formatDimList(dim, bizType, rootValue, defaultEnumMap, customizeItem),
              ) ?? [],
          requiredDimInfo,
          onChange(v) {
            onDimChange(form, v ?? [], DimensionAttributeType.User, bizType, rootValue?.group_attrs);
          },
        } as Partial<RuleSelectListProps>),
      dependencies: [],
      rules: dimFilterValidate ? [dimSelectorValidator] : undefined,
    };

    /** 场域属性 */
    const placeDimensionField: FieldDesc = {
      label:
        bizType === BizType.PriceTrendOrder ? (
          '场域属性'
        ) : (
          <span className="flex items-center gap-[2px]">
            场域属性
            <Tooltip title="此处筛选的是特定场域下曝光过的商品">
              <Icon.DoubtIcon className="cursor-pointer" />
            </Tooltip>
          </span>
        ),
      type: 'custom',
      name: 'place_dimensions',
      children: (
        <RuleSelectList list={[]} onItemAdd={() => openDimModal('place_dimensions')} layout={dimensionLayout} />
      ),
      hidden: !Boolean(dimensionData?.place_dimensions?.length) || !dimFilterVisible,
      dynamicProps: ({ rootValue, form }) => {
        return {
          list: isEmpty(rootValue)
            ? []
            : dimensionData?.place_dimensions?.map(dim =>
                formatDimList(dim, bizType, rootValue, defaultEnumMap, customizeItem),
              ) ?? [],
          requiredDimInfo,
          onChange(v) {
            onDimChange(form, v ?? [], DimensionAttributeType.Place, bizType, rootValue?.group_attrs);
          },
        } as Partial<RuleSelectListProps>;
      },
      dependencies: [],
      rules: dimFilterValidate ? [dimSelectorValidator] : undefined,
    };

    /** 订单属性 */
    const orderDimensionField: FieldDesc = {
      label: '订单属性',
      type: 'custom',
      name: 'order_dimensions',
      children: (
        <RuleSelectList list={[]} onItemAdd={() => openDimModal('order_dimensions')} layout={dimensionLayout} />
      ),
      hidden: !Boolean(dimensionData?.order_dimensions?.length) || !dimFilterVisible,
      dynamicProps: ({ rootValue, form }) =>
        ({
          list: isEmpty(rootValue)
            ? []
            : dimensionData?.order_dimensions?.map(dim =>
                formatDimList(dim, bizType, rootValue, defaultEnumMap, customizeItem),
              ) ?? [],
          requiredDimInfo,
          onChange(v) {
            onDimChange(form, v ?? [], DimensionAttributeType.Order, bizType, rootValue?.group_attrs);
          },
        } as Partial<RuleSelectListProps>),
      dependencies: [],
      rules: dimFilterValidate ? [dimSelectorValidator] : undefined,
    };

    /** 指标阈值 */
    const thresholdTypeField: FieldDesc = {
      label: '指标阈值',
      type: 'enum',
      name: 'threshold_type',
      enums: [
        { label: 'TOPN', value: ThresholdType.TOP_THRESHOLD },
        { label: '累计贡献', value: ThresholdType.CONTRIBUTION_THRESHOLD },
        { label: '具体阈值', value: ThresholdType.ACC_THRESHOLD },
        { label: '大促爆发分', value: ThresholdType.BIGSALE_HOT_SCORE_THRESHOLD },
        { label: '绝对日期TOPN', value: ThresholdType.TOP_THRESHOLD_ABSOLUTE_DATE },
        { label: '相对日期TOPN', value: ThresholdType.TOP_THRESHOLD_RELATIVE_DATE },
        { label: '绝对日期阈值', value: ThresholdType.ACC_THRESHOLD_ABSOLUTE_DATE },
        { label: '相对日期阈值', value: ThresholdType.ACC_THRESHOLD_RELATIVE_DATE },
      ].filter(i => dimensionData?.threshold_attr_meta?.findIndex(meta => meta.type === i.value) !== -1),
      hidden: !isProdAnalysis || !ruleFilterVisible,
      itemProps: {
        pIgnoreOnFinish: true, // 实现在Form的onFinish方法参数中忽略收集该字段，但仍会触发校验
      },
      dynamicProps: ({ form }) => ({
        isRadio: true,
        radioProps: {
          optionType: 'button',
        },
        onChange: (v: number) => {
          form.setFieldsValue({ threshold_attrs: [{ key: attrMetaMap?.[v]?.[0]?.id, type: v }] });
          handleChange(form);
        },
      }),
      dependencies: [],
    };

    /** 过滤规则 */
    const ruleField: FieldDesc = {
      label: ' ',
      type: 'json',
      props: {
        container: <div className="flex logic-selector" />,
      },
      hidden: !isProdAnalysis || !ruleFilterVisible,
      subJson: [
        /** 计算逻辑：且、或 */
        {
          name: 'threshold_expr',
          type: 'custom',
          hidden: ({ rootValue }) =>
            ![
              ThresholdType.ACC_THRESHOLD,
              ThresholdType.ACC_THRESHOLD_ABSOLUTE_DATE,
              ThresholdType.ACC_THRESHOLD_RELATIVE_DATE,
            ].includes(rootValue.threshold_type), // 只有「具体阈值」相关的需要展示逻辑计算
          children: <CustomLogic />,
          itemProps: {
            pLayout: false,
            pTransformer: {
              valueFromWidget: v => (v === IsLogic.Or ? LogicalExprType.OR : LogicalExprType.AND),
              valueToWidget: v => (v === LogicalExprType.OR ? IsLogic.Or : IsLogic.And),
            },
          },
          dependencies: ['threshold_type'],
        },
        /** 指标阈值筛选（具体阈值） */
        {
          name: 'threshold_attrs',
          type: 'custom',
          itemProps: {
            pLayout: { span: 22 },
          },
          dependencies: ['threshold_type'],
          dynamicItemProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              pTransformer: {
                valueToWidget: (v = []) => {
                  return v.map(
                    (attrsData: { key: string; acc_threshold?: { operator?: number; threshold?: number } }) => ({
                      id: attrsData.key,
                      selected_operator: attrsData.acc_threshold?.operator,
                      selected_values: attrsData.acc_threshold?.threshold,
                    }),
                  );
                },
                valueFromWidget: v => {
                  return v?.map((item: { id: string; selected_operator: number; selected_values: number }) => ({
                    type: threshold_type,
                    key: item.id,
                    acc_threshold: { operator: item.selected_operator, threshold: item.selected_values },
                  }));
                },
              },
            };
          },
          dynamicProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              list: attrMetaMap?.[threshold_type]?.map(valueItem => ({
                label: valueItem.name,
                value: valueItem.id,
                operatorType: OperatorTypeEnum.COMPARE,
                type: SelectType.InputNumber,
                valueProps: {
                  min: 0,
                  placeholder: '请输入阈值',
                },
              })),
            } as Partial<RuleSelectListProps>;
          },
          children: <RuleSelectList className="ml-[-6px]" addButton="条件" maxLength={5} list={[]} enableRepeat />,
          hidden: ({ rootValue }) => rootValue.threshold_type !== ThresholdType.ACC_THRESHOLD,
        },
        /** 指标阈值筛选（绝对日期具体阈值） */
        {
          name: 'threshold_attrs',
          type: 'custom',
          itemProps: {
            pLayout: { span: 22 },
          },
          dependencies: ['threshold_type'],
          dynamicItemProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              pTransformer: {
                valueToWidget: (v = []) => {
                  return v.map(
                    (attrsData: {
                      key: string;
                      date_rule?: DateRule;
                      acc_threshold?: { operator?: number; threshold?: number };
                    }) => ({
                      id: attrsData.key,
                      selected_operator: attrsData.acc_threshold?.operator,
                      selected_values: attrsData.acc_threshold?.threshold,
                      date_rule: attrsData?.date_rule,
                    }),
                  );
                },
                valueFromWidget: v => {
                  return v?.map(
                    (item: {
                      id: string;
                      selected_operator: number;
                      selected_values: number;
                      date_rule?: DateRule;
                    }) => ({
                      type: threshold_type,
                      key: item.id,
                      date_rule: item.date_rule,
                      acc_threshold: {
                        operator: item.selected_operator,
                        threshold: item.selected_values,
                      },
                    }),
                  );
                },
              },
            };
          },
          dynamicProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              dateRuleType: DateRuleType.AbsoluteDateRange,
              list: attrMetaMap?.[threshold_type]?.map(valueItem => ({
                label: valueItem.name,
                value: valueItem.id,
                operatorType: OperatorTypeEnum.COMPARE,
                type: SelectType.InputNumber,
                valueProps: {
                  min: 0,
                  placeholder: '请输入阈值',
                },
              })),
            } as Partial<RuleSelectListProps>;
          },
          children: (
            <RuleSelectList
              className="ml-[-6px]"
              addButton="条件"
              maxLength={5}
              list={[]}
              enableRepeat
              dateRuleType={DateRuleType.AbsoluteDateRange}
            />
          ),
          hidden: ({ rootValue }) => rootValue.threshold_type !== ThresholdType.ACC_THRESHOLD_ABSOLUTE_DATE,
        },
        /** 指标阈值筛选（相对日期具体阈值） */
        {
          name: 'threshold_attrs',
          type: 'custom',
          itemProps: {
            pLayout: { span: 22 },
          },
          dependencies: ['threshold_type'],
          dynamicItemProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              pTransformer: {
                valueToWidget: (v = []) => {
                  return v.map(
                    (attrsData: {
                      key: string;
                      date_rule?: DateRule;
                      acc_threshold?: { operator?: number; threshold?: number };
                    }) => ({
                      id: attrsData.key,
                      selected_operator: attrsData.acc_threshold?.operator,
                      selected_values: attrsData.acc_threshold?.threshold,
                      date_rule: attrsData?.date_rule,
                    }),
                  );
                },
                valueFromWidget: v => {
                  return v?.map(
                    (item: {
                      id: string;
                      selected_operator: number;
                      selected_values: number;
                      date_rule?: DateRule;
                    }) => ({
                      type: threshold_type,
                      key: item.id,
                      date_rule: item.date_rule,
                      acc_threshold: {
                        operator: item.selected_operator,
                        threshold: item.selected_values,
                      },
                    }),
                  );
                },
              },
            };
          },
          dynamicProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              dateRuleType: DateRuleType.RelativeDateRange,
              list: attrMetaMap?.[threshold_type]?.map(valueItem => ({
                label: valueItem.name,
                value: valueItem.id,
                operatorType: OperatorTypeEnum.COMPARE,
                type: SelectType.InputNumber,
                valueProps: {
                  min: 0,
                  placeholder: '请输入阈值',
                },
              })),
            } as Partial<RuleSelectListProps>;
          },
          children: (
            <RuleSelectList
              className="ml-[-6px]"
              addButton="条件"
              maxLength={5}
              list={[]}
              enableRepeat
              dateRuleType={DateRuleType.RelativeDateRange}
            />
          ),
          hidden: ({ rootValue }) => rootValue.threshold_type !== ThresholdType.ACC_THRESHOLD_RELATIVE_DATE,
        },
        /** 大促爆发分 */
        {
          name: 'threshold_attrs',
          type: 'custom',
          itemProps: {
            pLayout: { span: 22 },
          },
          dependencies: ['threshold_type'],
          dynamicItemProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              pTransformer: {
                valueToWidget: (v = []) => {
                  const [attrsData = {}] = v;
                  return {
                    id: attrsData.key,
                    selected_operator: attrsData.acc_threshold?.operator,
                    selected_values: attrsData.acc_threshold?.threshold,
                  };
                },
                valueFromWidget: v => {
                  return [
                    {
                      type: threshold_type,
                      key: v?.id,
                      acc_threshold: { operator: v?.selected_operator, threshold: v?.selected_values },
                    },
                  ];
                },
              },
            };
          },
          dynamicProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              options: attrMetaMap?.[threshold_type]?.map(valueItem => ({
                label: valueItem.name,
                value: valueItem.id,
                operatorType: OperatorTypeEnum.COMPARE,
                type: SelectType.InputNumber,
                valueProps: {
                  min: 0,
                  placeholder: '请输入阈值',
                },
              })),
            } as Partial<RuleSelectProps>;
          },
          children: (
            <RuleSelect
              options={[]}
              extra={{
                desc: (
                  <div className="text-[12px] leading-4 mt-1 text-[#898b8f]">
                    大促爆发分，是预测商品在某次大促中，GMV爆发的可能性的指标，范围是0～100；大促爆发分越高，商品越有可能收获较大的GMV增长；如果希望圈出较少的头部品，可以设置更高的阈值。
                  </div>
                ),
              }}
            />
          ),
          hidden: ({ rootValue }) => rootValue.threshold_type !== ThresholdType.BIGSALE_HOT_SCORE_THRESHOLD,
        },
        /** 指标阈值筛选（绝对日期具体TOPN） */
        {
          name: 'threshold_attrs',
          type: 'custom',
          itemProps: {
            pLayout: { span: 22 },
          },
          hidden: ({ rootValue }) => rootValue.threshold_type !== ThresholdType.TOP_THRESHOLD_ABSOLUTE_DATE,
          dependencies: ['threshold_type'],
          children: <RuleSelect options={[]} extra={{ dateRuleType: DateRuleType.AbsoluteDateRange }} />,
          dynamicProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              type: threshold_type,
              options:
                attrMetaMap?.[threshold_type]?.map(valueItem => ({
                  label: valueItem.name,
                  value: valueItem.id,
                  type: SelectType.InputNumber,
                  valueProps: {
                    min: 0,
                    unit: '',
                  },
                })) ?? [],
              extra: {
                prefix: '筛选',
                suffix: '个商品',
                operator: threshold_type === ThresholdType.TOP_THRESHOLD_ABSOLUTE_DATE ? '最高的前' : '具体贡献度',
                dateRuleType: DateRuleType.AbsoluteDateRange,
              },
            };
          },
          dynamicItemProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              pTransformer: {
                valueToWidget: (v = []) => {
                  const [attrsData = {}] = v;
                  return {
                    id: attrsData.key,
                    selected_values: attrsData.top_n,
                    date_rule: attrsData.date_rule,
                  };
                },
                valueFromWidget: v => {
                  return [
                    {
                      type: threshold_type,
                      key: v?.id,
                      top_n: v?.selected_values,
                      date_rule: v?.date_rule,
                    },
                  ];
                },
              },
            };
          },
        },
        /** 指标阈值筛选（相对日期具体TOPN） */
        {
          name: 'threshold_attrs',
          type: 'custom',
          itemProps: {
            pLayout: { span: 22 },
          },
          hidden: ({ rootValue }) => rootValue.threshold_type !== ThresholdType.TOP_THRESHOLD_RELATIVE_DATE,
          dependencies: ['threshold_type'],
          children: <RuleSelect options={[]} extra={{ dateRuleType: DateRuleType.RelativeDateRange }} />,
          dynamicProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              type: threshold_type,
              options:
                attrMetaMap?.[threshold_type]?.map(valueItem => ({
                  label: valueItem.name,
                  value: valueItem.id,
                  type: SelectType.InputNumber,
                  valueProps: {
                    min: 0,
                    unit: '',
                  },
                })) ?? [],
              extra: {
                prefix: '筛选',
                suffix: '个商品',
                operator: threshold_type === ThresholdType.TOP_THRESHOLD_RELATIVE_DATE ? '最高的前' : '具体贡献度',
                dateRuleType: DateRuleType.RelativeDateRange,
              },
            };
          },
          dynamicItemProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              pTransformer: {
                valueToWidget: (v = []) => {
                  const [attrsData = {}] = v;
                  return {
                    id: attrsData.key,
                    selected_values: attrsData.top_n,
                    date_rule: attrsData.date_rule,
                  };
                },
                valueFromWidget: v => {
                  return [
                    {
                      type: threshold_type,
                      key: v?.id,
                      top_n: v?.selected_values,
                      date_rule: v?.date_rule,
                    },
                  ];
                },
              },
            };
          },
        },
        /** 指标阈值筛选（TOPN） */
        {
          name: 'threshold_attrs',
          type: 'custom',
          itemProps: {
            pLayout: { span: 22 },
          },
          hidden: ({ rootValue }) => rootValue.threshold_type !== ThresholdType.TOP_THRESHOLD,
          dependencies: ['threshold_type'],
          children: <RuleSelect options={[]} />,
          dynamicProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              type: threshold_type,
              options:
                attrMetaMap?.[threshold_type]?.map(valueItem => ({
                  label: valueItem.name,
                  value: valueItem.id,
                  type: SelectType.InputNumber,
                  valueProps: {
                    min: 0,
                    unit: threshold_type === ThresholdType.CONTRIBUTION_THRESHOLD ? '%' : '',
                  },
                })) ?? [],
              extra: {
                prefix: '筛选',
                suffix: '个商品',
                operator: threshold_type === ThresholdType.TOP_THRESHOLD ? '最高的前' : '具体贡献度',
              },
            };
          },
          dynamicItemProps: ({ rootValue }) => {
            const { threshold_type } = rootValue;
            return {
              pTransformer: {
                valueToWidget: (v = []) => {
                  const [attrsData = {}] = v;
                  return {
                    id: attrsData.key,
                    selected_values: attrsData.top_n,
                  };
                },
                valueFromWidget: v => {
                  return [
                    {
                      type: threshold_type,
                      key: v?.id,
                      top_n: v?.selected_values,
                    },
                  ];
                },
              },
            };
          },
        },
      ],
    };

    /** 分析指标 */
    const targetField: FieldDesc = {
      label: '分析指标',
      type: 'custom',
      name: 'target_meta_list',
      children: <TargetListEditor list={targetList ?? []} min={targetMin} />,
      hidden: !isProdAnalysis || !targetFilterVisible,
      dynamicProps: ({ form }) =>
        ({
          addBtn: (
            <TargetListDrawer
              triggerClassName="pt-1 pb-1"
              list={targetList ?? []}
              form={form}
              field="target_meta_list"
              min={targetMin}
              max={targetMax}
              onOk={v => {
                form.pSetFieldsValue({ target_meta_list: v });
                handleChange(form);
              }}
            />
          ),
        } as Partial<TargetListEditorProps>),
      dependencies: [],
      rules: targetFilterValidate ? [targetListValidator({ min: targetMin, max: targetMax })] : undefined,
    };

    /** 多维分析 */
    const multiDimField: FieldDesc = {
      label: '多维分析',
      type: 'custom',
      name: 'group_attrs',
      children: <DimEnumFilter multiDimDimensions={multiDimDimensions} min={drillMin} maxSelected={drillEnumMax} />,
      hidden: !isProdAnalysis || !drillFilterVisible,
      dynamicProps: ({ rootValue, form }) => {
        const selectedDimensions = getSelectedDimFromFilter(rootValue);

        return {
          selectedDimensions,
          addBtn: (
            <CrossDimPickDrawer
              triggerClassName="pt-1 pb-1"
              form={form}
              field="group_attrs"
              multiDimDimensions={multiDimDimensions}
              selectedDimensions={selectedDimensions}
              mode={drillMin === 0 && drillMax === 1 ? 'single' : 'multiple'}
              min={drillMin}
              max={drillMax}
              minEnum={drillEnumMin}
              maxEnum={drillEnumMax}
              onOk={v => {
                form.pSetFieldsValue({ group_attrs: v });
                handleChange(form);
              }}
            />
          ),
        } as DimEnumFilterProps;
      },
      dependencies: DIMENSION_TYPE_LIST,
      rules: drillFilterValidate
        ? [multiDimValidator({ min: drillMin, max: drillMax }, { min: drillEnumMin, max: drillEnumMax })]
        : undefined,
    };

    return [
      getFilterTitle('添加筛选条件', hiddenFilterTitle),
      ...dateFields,
      dateTypeField,
      granularityField,
      prodDimensionField,
      userDimensionField,
      placeDimensionField,
      orderDimensionField,
      thresholdTypeField,
      ruleField,
      getFilterTitle('选择分析指标', hiddenTargetTitle),
      targetField,
      getFilterTitle('选择下钻维度', hiddenDrillTitle),
      multiDimField,
    ];
  }, [
    bizType,
    count,
    dateFields,
    defaultEnumMap,
    dimensionData,
    dimensionLayout,
    disabled,
    isProdAnalysis,
    multiDimDimensions,
    onChange,
    openDimModal,
    prodDimensionLabel,
    requiredDimInfo,
    showSubTitle,
    targetList,
    validate,
    visible,
  ]);

  return fields;
}
