import { CustomizeOption } from './hooks/use-form-json';

import { EnumElement } from '~/api/product/namespaces/dimensions';
import { CUSTOM_POOL_DIM_ID, PROD_BRAIN_DIM_ID, PROD_COLLECTION_DIM_ID } from '~/constant';
import { CustomInvestmentLabel, InvestmentExtraInfo, InvestmentStatus } from '~/custom-label/investment';
import { CustomPoolLabel, CustomPoolLabelType } from '~/custom-label/pool';

function getRenderProdPoolLabelTip(id: string) {
  return (label: React.ReactNode, enumValue: EnumElement) => {
    return (
      <CustomPoolLabel
        label={label}
        enumValue={enumValue}
        type={id === CUSTOM_POOL_DIM_ID ? CustomPoolLabelType.CustomProdPool : CustomPoolLabelType.ProdBrainPool}
      />
    );
  };
}

function renderInvestmentLabel(label: React.ReactNode, enumValue: EnumElement) {
  return <CustomInvestmentLabel label={label} enumValue={enumValue} />;
}

export const DEFAULT_CUSTOMIZE_ITEMS: CustomizeOption['customizeItem'] = {
  /** 自定义货盘 */
  [CUSTOM_POOL_DIM_ID]: {
    render: getRenderProdPoolLabelTip(CUSTOM_POOL_DIM_ID),
  },

  /** 选品大脑货品 */
  [PROD_BRAIN_DIM_ID]: {
    render: getRenderProdPoolLabelTip(PROD_BRAIN_DIM_ID),
  },

  /** 招商选品集 */
  [PROD_COLLECTION_DIM_ID]: {
    render: renderInvestmentLabel,
    disabled: (enumValue: EnumElement) => {
      try {
        const { extra_info } = enumValue;
        const { investment_status } = JSON.parse(extra_info || '{}') as InvestmentExtraInfo;
        return investment_status !== InvestmentStatus.FINISH;
      } catch (e) {
        console.log('Parse extra_info error: ', e);
        return true;
      }
    },
  },
};
