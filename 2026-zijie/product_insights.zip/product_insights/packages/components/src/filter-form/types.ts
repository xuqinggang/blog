import { ReactNode } from 'react';
import { Dayjs } from 'dayjs';

import { NamePath } from '@ecom/auxo/es/components/form';
import { FormDesc, FormProps } from '@ecom/auxo-pro-form';
import { EnumOption } from '@ecom/auxo-pro-form/es/components';

import {
  BizType,
  DataReadyTime,
  DimensionAttributeType,
  DimensionInfo,
  GetDimensionListData,
  ProductAnalysisBaseStruct,
  SelectedDimensionInfo,
  TargetMetaInfo,
  ThresholdType,
} from '~/api/product/namespaces/dimensions';
import { PriceAnalysisBaseStruct } from '~/api/product/namespaces/price_dimensions';
import { DimItem } from '~/DimCheckGroup';
import { RuleValueType } from '~/RuleSelect';

export type DefaultEnumMap = Record<string, EnumOption[]>;

export type BaseStruct = ProductAnalysisBaseStruct | PriceAnalysisBaseStruct;

/** 维度类型 */
export type DimensionType = Exclude<keyof GetDimensionListData, 'threshold_attr_meta' | 'default_group_attrs'>;

/** 维度map */
export type DimensionMap = Partial<{
  [key in DimensionType]: RuleValueType[];
}>;

/** 商品分析筛选项结构 */
export type AnalysisFilter = DimensionMap &
  Partial<Omit<ProductAnalysisBaseStruct, 'biz_type' | 'dimensions' | 'group_attrs'>> & {
    /** 分析周期类型（日/周/月） */
    analysis_date_type?: string;
    /** 对比周期类型（日/周/月） */
    compare_date_type?: string;
    /** 指标阈值（商品分析） */
    threshold_type?: ThresholdType;
    group_attrs?: DimItem[];
  };

/** 价格力筛选项结构 */
export type PriceFilter = DimensionMap &
  Partial<
    Omit<PriceAnalysisBaseStruct, 'biz_type' | 'dimensions' | 'group_attrs'> & {
      group_attrs?: DimItem[];
    }
  >;

/** 筛选项结构 */
export type CommonFilter = AnalysisFilter | PriceFilter;

/** 商品分析筛选服务端结构 */
export type AnalysisServerFilter = Partial<Omit<ProductAnalysisBaseStruct, 'biz_type'>>;

/**  价格力筛选服务端结构 */
export type PriceServerFilter = Partial<Omit<PriceAnalysisBaseStruct, 'biz_type'>>;

/** 服务端筛选项结构 */
export type CommonServerFilter = AnalysisServerFilter | PriceServerFilter;

/** 筛选的状态 */
export const enum FilterStatus {
  DONE = -1,
  INIT,
  LOADING,
  SYNC_DONE,
}

/** 筛选区的时间范围 */
export interface FilterDateRange {
  start_date: Dayjs;
  end_date: Dayjs;
  compare_start_date: Dayjs;
  compare_end_date: Dayjs;
}

export interface DimGroupItem {
  name: string;
  key: DimensionType;
  attrType: DimensionAttributeType;
  list?: DimItem[];
}

/** 分享的筛选数据 */
export type ShareFilter = CommonFilter & {
  biz_type?: BizType;
};

/** 缓存的筛选数据 */
export type CacheFilter = CommonFilter & {
  template_id?: string;
};

export type FormValidate = (nameList?: NamePath[]) => Promise<CommonFilter>;

export interface DateOperation {
  analysisDate?: boolean; // 分析周期
  compareDate?: boolean; // 对比周期
}

export interface FieldOperation extends DateOperation {
  drillFilter?: boolean; // 下钻筛选项
  targetFilter?: boolean; // 指标筛选项
  dimFilter?: boolean; // 维度筛选项
  ruleFilter?: boolean; // 规则筛选项（TOPN/具体阈值）
}

export interface FieldCountItem {
  max?: number;
  min?: number;
}

export interface FieldCount {
  targetFilter?: FieldCountItem; // 指标筛选项个数限制（默认min=1, max=Infinity）
  drillFilter?: FieldCountItem; // 下钻筛选项个数限制（默认min=1, max=3）
  drillEnum?: FieldCountItem; // 下钻枚举值个数限制（默认min=1, max=200）
}

export interface FilterFormProps
  extends Omit<FormProps<CommonFilter>, 'form' | 'onValuesChange' | 'pJson' | 'onChange' | 'disabled'> {
  bizType: BizType;
  baseStruct?: BaseStruct;
  readyTime?: DataReadyTime | null;
  dimensionData?: GetDimensionListData | null;
  multiDimDimensions?: Partial<Record<DimensionType, DimensionInfo[]>> | null;
  requiredDimInfo?: SelectedDimensionInfo[];
  targetList?: TargetMetaInfo[] | null;
  isProdAnalysis?: boolean;
  operator?: ReactNode;
  showSubTitle?: boolean;
  defaultEnumMap?: DefaultEnumMap;
  visible?: FieldOperation;
  disabled?: FieldOperation;
  validate?: FieldOperation;
  count?: FieldCount;
  dimensionLayout?: 'flex' | 'grid';
  onChange?: (filter: CommonFilter, baseStruct: CommonServerFilter, changedValues?: any) => void;
  customPJson?: (pJson: FormDesc) => FormDesc;
  dateFieldLayout?: {
    analysisDateFieldLabelAlign?: 'left' | 'right';
  };
  prodDimensionLabel?: ReactNode;
}
