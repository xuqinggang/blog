import dayjs, { Dayjs } from 'dayjs';

import { DataReadyTime } from '~/api/product/namespaces/dimensions';
import { getCompareDate } from '~/filter-form/utils/get-compare-date';
import { RangeTime } from '~/MenuDatePicker';
import { DatePickerType } from '~/MenuDatePicker/utils';
import { AttributionFilter } from '~/types';
import { isNullOrUndefined } from '~/utils/is';

/**
 * 获取最近有数的日期
 * @param readyTime 数据就绪时间
 * @param recent 最近天数
 * @returns 最近有数的日期
 */
export function getRecentDate(readyTime: DataReadyTime, recent: number) {
  const { newest_partition, oldest_partition, max_date_range } = readyTime;
  const prevDate = dayjs().subtract(1, 'day').endOf('day');

  const newestDate = dayjs(newest_partition).endOf('day');
  const oldestRangeDate = !isNullOrUndefined(max_date_range)
    ? newestDate.subtract(Number(max_date_range) - 1, 'day').startOf('day')
    : undefined;
  let oldestDate = oldest_partition ? dayjs(oldest_partition).startOf('day') : undefined;
  if (oldestRangeDate && oldestRangeDate.isAfter(oldestDate)) {
    oldestDate = oldestRangeDate;
  }

  let startDate: Dayjs;
  let endDate: Dayjs;

  if (prevDate.isAfter(newestDate)) {
    // 如果前一天的数据还未产出，则返回最近有数的一天
    const tmpStartDate = newestDate.subtract(recent - 1, 'day').startOf('day');
    if (oldestDate && tmpStartDate.isBefore(oldestDate)) {
      startDate = oldestDate;
    } else {
      startDate = tmpStartDate;
    }

    endDate = newestDate;
  } else {
    // 如果前一天的数据已产出，则前一天的数据
    const tmpStartDate = prevDate.subtract(recent - 1, 'day').startOf('day');
    if (oldestDate && tmpStartDate.isBefore(oldestDate)) {
      startDate = oldestDate;
    } else {
      startDate = tmpStartDate;
    }

    endDate = prevDate;
  }

  return {
    startDate,
    endDate,
  };
}

/**
 * 获取最近有数的日期以及对比日期，返回格式为 YYYY-MM-DD
 * @param readyTime 数据就绪时间
 * @param recent 最近天数
 * @returns 最近有数的日期
 */
export function getRecentDateWithCompare(
  readyTime: DataReadyTime,
  recent: number,
  validateDate: (date: RangeTime, activeKey?: DatePickerType) => RangeTime,
): Pick<AttributionFilter, 'start_date' | 'end_date' | 'compare_end_date' | 'compare_start_date'> {
  const { startDate, endDate } = getRecentDate(readyTime, recent);
  const [compareStartDate, compareEndDate] =
    getCompareDate([startDate, endDate], DatePickerType.DATE, validateDate) ?? [];

  return {
    start_date: startDate.format('YYYY-MM-DD'),
    end_date: endDate.format('YYYY-MM-DD'),
    compare_start_date: compareStartDate ?? undefined,
    compare_end_date: compareEndDate ?? undefined,
  };
}
