export function safetyParse(str: string, fallback: any) {
  try {
    return JSON.parse(str);
  } catch (err) {
    return fallback;
  }
}
