export type HSBA = {
  h: number; // 0-360
  s: number; // 0-1 或 0-100
  b: number; // 0-1 或 0-100
  a?: number; // 0-1、0-100 或 0-255
};

export type RGBA = {
  r: number; // 0-255
  g: number; // 0-255
  b: number; // 0-255
  a: number; // 0-1
};

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function normalizeFraction(x: number) {
  // 支持 0-1 或 0-100 百分比
  return clamp(x > 1 ? x / 100 : x, 0, 1);
}

function normalizeAlpha(a: number | undefined): number {
  const v = a ?? 1;
  // 支持 0-1、0-100（百分比）或 0-255
  if (v <= 1) return clamp(v, 0, 1);
  if (v <= 100) return clamp(v / 100, 0, 1);
  return clamp(v / 255, 0, 1);
}

/**
 * HSBA -> RGBA（对象）
 */
export function hsbaToRgba(h: number, s: number, b: number, a: number = 1): RGBA {
  const hn = ((h % 360) + 360) % 360; // 归一化到 0-360
  const sn = normalizeFraction(s);
  const vn = normalizeFraction(b); // Brightness/V
  const an = normalizeAlpha(a);

  const c = vn * sn;
  const x = c * (1 - Math.abs(((hn / 60) % 2) - 1));
  const m = vn - c;

  let rp = 0;
  let gp = 0;
  let bp = 0;

  if (hn < 60) {
    rp = c;
    gp = x;
    bp = 0;
  } else if (hn < 120) {
    rp = x;
    gp = c;
    bp = 0;
  } else if (hn < 180) {
    rp = 0;
    gp = c;
    bp = x;
  } else if (hn < 240) {
    rp = 0;
    gp = x;
    bp = c;
  } else if (hn < 300) {
    rp = x;
    gp = 0;
    bp = c;
  } else {
    rp = c;
    gp = 0;
    bp = x;
  }

  const r = Math.round((rp + m) * 255);
  const g = Math.round((gp + m) * 255);
  const bb = Math.round((bp + m) * 255);

  return { r, g, b: bb, a: Number(an.toFixed(3)) };
}

/**
 * HSBA -> RGBA（CSS 字符串）
 */
export function hsbaToRgbaString(h: number, s: number, b: number, a: number = 1): string {
  const { r, g, b: bb, a: an } = hsbaToRgba(h, s, b, a);
  return `rgba(${r}, ${g}, ${bb}, ${an})`;
}
