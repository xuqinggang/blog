import { isEqual, sortBy } from 'lodash-es';

import { BizType } from '~/api/product/namespaces/dimensions';

export function isPriceTrend(bizType: BizType) {
  return bizType === BizType.PriceTrendOrder || bizType === BizType.PriceTrendShow || bizType === BizType.PriceTrendSku;
}

export function isPriceCompare(bizType: BizType) {
  return bizType === BizType.PriceAACompare;
}

export function isNullOrUndefined(value: unknown): value is null | undefined {
  return value === undefined || value === null;
}

export function isArrayEqual(a: string[], b: string[]) {
  return isEqual(sortBy(a), sortBy(b));
}
