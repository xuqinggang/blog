interface FixedOption {
  mode: 'fixed' | 'auto';
  len?: number;
}
export interface NumberFormatOption {
  ratio?: '%' | 'pp';
  /**
   * 是否自动转换为单位
   * @default false
   */
  useUnit?: boolean;
  /**
   * 保留小数点位数
   * @default 2
   */
  fixed?: number | FixedOption;
}

const splitNum = (num: number, fixedCnt: number | false) => {
  const sign = num < 0 ? '-' : '';
  const absNum = Math.abs(num);

  // 保留两位小数（四舍五入）
  const fixedValue = fixedCnt === false ? absNum.toString() : absNum.toFixed(fixedCnt);
  const [integerPart, decimalPart] = fixedValue.split('.');

  // 手动每三位插入逗号
  let formattedInt = '';
  let count = 0;
  for (let i = integerPart.length - 1; i >= 0; i--) {
    formattedInt = integerPart[i] + formattedInt;
    count++;
    if (count % 3 === 0 && i !== 0) {
      formattedInt = `,${formattedInt}`;
    }
  }
  if (fixedCnt === false) {
    return `${sign}${formattedInt}${decimalPart?.length > 0 ? `.${decimalPart}` : ''}`;
  }
  if (fixedCnt) {
    return `${sign}${formattedInt}${decimalPart?.length > 0 ? `.${decimalPart}` : ''}`;
  }
  return `${sign}${formattedInt}`;
};

export function formatNumberToUnits(num: number, { isShowSymbol = true } = {}) {
  const units = ['', '万', '千万', '亿'];
  const thresholds = [1e4, 1e7, 1e8]; // 万(1e4), 千万(1e7), 亿(1e8)
  let unitIndex = 0;

  // 动态判断单位层级
  if (Math.abs(num) >= 1e8) {
    // 亿及以上
    unitIndex = 3;
  } else if (Math.abs(num) >= 1e7) {
    // 千万及以上
    unitIndex = 2;
  } else if (Math.abs(num) >= 1e4) {
    // 万及以上
    unitIndex = 1;
  }

  const divisor = Math.pow(10, thresholds[unitIndex - 1]?.toString().length - 1 || 0);
  const formatted = (num / divisor).toFixed(1) + units[unitIndex];
  return num > 0 ? `${isShowSymbol ? '+' : ''}${formatted}` : formatted;
}

export function formatNumber(num = 0, option?: NumberFormatOption): string | undefined {
  const { ratio, useUnit, fixed } = option || {};
  const actualFix: number | false = (() => {
    if (typeof fixed === 'object') {
      const { mode, len = 2 } = fixed;
      // 自动模式下，判断是否有小数点
      if (mode === 'auto') {
        if (String(num).includes('.')) {
          return len;
        }
        return false;
      }
      return fixed.len ?? 2;
    }
    return fixed ?? 2;
  })();

  if (useUnit) {
    return formatNumberToUnits(num);
  }
  if (ratio === 'pp' || ratio === '%') {
    const newValue = num * 100;
    return `${splitNum(newValue, actualFix)}${ratio}`;
  }

  return splitNum(num, actualFix);
}
