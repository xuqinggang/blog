const createTag = (color: string) => {
  return [
    `font-size: 10px; color: white; background-color: ${color}; border-radius: 3px 0 0 3px; padding: 3px 0;`,
    `font-size: 10px; color: white; background-color: #999999; border-radius: 0 3px 3px 0; padding: 3px 0`,
  ];
};

export const prettyDebug = (stage: string, ...content: any) => {
  console.debug(
    `%c 🦁 DEBUG %c ${stage} | ${new Date().toLocaleTimeString('zh-CN', { hour12: false })} `,
    ...createTag('#636363'),
    ...content,
  );
};

export const prettyLog = (stage: string, ...content: any) => {
  console.info(
    `%c 🦁 LOG %c ${stage} | ${new Date().toLocaleTimeString('zh-CN', { hour12: false })} `,
    ...createTag('#309e01'),
    ...content,
  );
};

export const prettyWarn = (stage: string, ...content: any) => {
  console.warn(
    `%c 🦁 WARN %c ${stage} | ${new Date().toLocaleTimeString('zh-CN', { hour12: false })} `,
    ...createTag('#b9a418'),
    ...content,
  );
};
export const prettyError = (stage: string, ...content: any) => {
  console.error(
    `%c 🦁 ERROR %c ${stage} | ${new Date().toLocaleTimeString('zh-CN', { hour12: false })} `,
    ...createTag('#bb2727'),
    ...content,
  );
};
