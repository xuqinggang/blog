// eslint-disable-next-line @ecom/security-internal-host
const oauthCallbackUrl = 'https://ecop.bytedance.net/product_analysis_node/lark/oauth_callback';
const appId = 'cli_a6b2866f9dedd00b';

export function redirectToLarkOAuth(state?: string) {
  window.open(
    `https://accounts.feishu.cn/open-apis/authen/v1/authorize?client_id=${appId}&redirect_uri=${encodeURIComponent(
      oauthCallbackUrl,
    )}${state ? `&state=${state}` : ''}`,
  );
}
