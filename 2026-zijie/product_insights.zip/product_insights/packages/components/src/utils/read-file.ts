export const readFile = async (file: File) => {
  const pmz = new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = event => {
      const text = event.target?.result?.toString() || '';
      resolve(text);
    };
    reader.onerror = error => {
      reject(error);
    };
    reader.readAsText(file);
  });

  return pmz;
};
