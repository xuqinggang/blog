import numeral from 'numeral';

import { isNullOrUndefined } from '../is';

// 判断是数字
function checkNum(input?: number | string) {
  if (typeof input === 'number') {
    return !isNaN(input);
  }
  if (typeof input === 'string') {
    return !isNaN(Number(input)) && input && Boolean(input.trim().length);
  }
  return false;
}
/**
 * 精确展示数字，最多保留两位小数
 * @param num 数字
 * @returns 1234.5->["","1,234.5",""],超过999999999999.99时返回["","999,999,999,999.99","+"]
 */
export function accurateAmount(num?: number | string): string[] {
  try {
    if (!checkNum(num) || (typeof num === 'number' && isNaN(num))) {
      return ['', '-', ''];
    }

    const cur = Number(num);
    if (cur && cur > 999999999999.99) {
      return ['', '999,999,999,999.99', '+'];
    }

    return ['', numeral(cur).format('0,0.[00]'), ''];
  } catch (error) {
    return ['', '-', ''];
  }
}

/**
 * 精简展示数字，增加单位万，最多保留两位小数，四舍五入
 * @param num 数字
 * @returns 12345678->["","1,234.68","万"] 123000000->["","1.2","亿"]
 */
export function compactAmount(num?: number | string): string[] {
  try {
    if (!num || !checkNum(num)) {
      return ['', '-', ''];
    }

    let data = Math.abs(Number(num));
    let unit = '';
    if (data > 99999950) {
      data = data / 100000000;
      unit = '亿';
    } else if (data > 9999.995) {
      data = data / 10000;
      unit = '万';
    }

    return [Number(num) < 0 ? '-' : '', numeral(data).format('0,0.[00]'), unit];
  } catch (error) {
    return ['', '-', ''];
  }
}

/** 精确展示数字，返回字符串 */
export function compactAmountUseString(num?: number | string): string {
  try {
    if (num === 0) {
      return '0';
    }
    if (!num || !checkNum(num)) {
      return '-';
    }

    let data = Math.abs(Number(num));
    let unit = '';
    if (data > 99999950) {
      data = data / 100000000;
      unit = '亿';
    } else if (data > 9999.995) {
      data = data / 10000;
      unit = '万';
    }

    const result = String(numeral(data).format('0,0.[00]')) + unit;
    return Number(num) < 0 ? `-${result}` : result;
  } catch (error) {
    return '-';
  }
}

export function transformNum(num: unknown) {
  if (typeof num !== 'number') return num;
  if (isNaN(num)) return num;
  // eslint-disable-next-line prefer-const
  let [before, after] = num.toString().split('.');
  // eslint-disable-next-line @ecom/security-unsafe-regex
  before = before.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
  return after === undefined ? before : `${before}.${after}`;
}

// 格式化小数，最多x位
export const formatDecimal = (number?: number | string, decimal = 2) => {
  const formattedNum = Number(number ?? 0).toFixed(decimal); // 将数字格式化为最多6位小数
  return parseFloat(formattedNum).toString(); // 将格式化后的数字转换为字符串并去除末尾的0
};

export const errorRatio = (num?: number) => 0.123456789 === num || isNullOrUndefined(num);

export const accurateRatio = (
  num?: number,
  fix = 2,
  extra?: { useSymbol?: boolean; usePP?: boolean; hiddenError?: boolean },
): string => {
  const { useSymbol = false, usePP = false, hiddenError = false } = extra || {};

  const unit = usePP ? 'pp' : '%';

  if (errorRatio(num)) return hiddenError ? '' : '-';
  if (Number(num) > 0 && useSymbol) {
    return `+${((num ?? 0) * 100).toFixed(fix)}${unit}`;
  }
  return `${((num ?? 0) * 100).toFixed(fix)}${unit}`;
};

export const accurateRatioUsePP = (num?: number, fix = 2): string => {
  if (errorRatio(num)) return '-';

  return `${((num ?? 0) * 100).toFixed(fix)}pp`;
};

export const removeSymbol = (num: number | string) => {
  if (typeof num === 'number') {
    return num > 0 ? num.toString() : (-num).toString();
  }
  return num.startsWith('-') || num.startsWith('+') ? num.slice(1) : num;
};

/** 将阿拉伯数字转化为中文数字 */
export function transformNumber(num: number): string {
  const chnNumChar = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
  const chnUnitSection = ['', '万', '亿', '万亿'];
  const chnUnitChar = ['', '十', '百', '千'];

  function sectionToChinese(section: number): string {
    let strIns = '';
    let chnStr = '';
    let unitPos = 0;
    let zero = true;

    while (section > 0) {
      const v = section % 10;
      if (v === 0) {
        if (!zero) {
          zero = true;
          chnStr = chnNumChar[v] + chnStr;
        }
      } else {
        zero = false;
        strIns = chnNumChar[v];
        strIns += chnUnitChar[unitPos];
        chnStr = strIns + chnStr;
      }
      unitPos++;
      section = Math.floor(section / 10);
    }
    return chnStr;
  }

  let unitPos = 0;
  let strIns = '';
  let chnStr = '';
  let needZero = false;

  if (num === 0) {
    return chnNumChar[0];
  }

  while (num > 0) {
    const section = num % 10000;
    if (needZero) {
      chnStr = chnNumChar[0] + chnStr;
    }
    strIns = sectionToChinese(section);
    strIns += section !== 0 ? chnUnitSection[unitPos] : chnUnitSection[0];
    chnStr = strIns + chnStr;
    needZero = section < 1000 && section > 0;
    num = Math.floor(num / 10000);
    unitPos++;
  }

  return chnStr;
}

/**
 * 格式化时间，比如将0转化为00，1转化为01
 */
export function formatTime(unit?: number) {
  if (!unit) {
    return '00';
  }

  return unit < 10 ? `0${unit}` : String(unit);
}
