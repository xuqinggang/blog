import { Dayjs } from 'dayjs';
import { cloneDeep, uniqBy } from 'lodash-es';

import { SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import { ProdDetailBaseRequest } from '~/api/product/namespaces/price_analysis';

export * from './hooks';
export * from './get-recent-date';
export * from './format-number';
export * from './get-enum-code-list';
export * from './logger';
export * from './read-file';
export * from './lark-oauth';
export * from './user-info';
export * from './upload-image';

export const getEarlierTime = (...times: Dayjs[]) =>
  times.reduce((earlier, time) => (earlier.isBefore(time) ? earlier : time));
export const getLatestTime = (...times: Dayjs[]) =>
  times.reduce((latest, time) => (latest.isAfter(time) ? latest : time));

export type Scope = {
  page?: string;
  module?: string;
  biz_from?: string; // 来源，用于做一些特殊处理
};

export const openProductDetailPage = (params: {
  base_req?: Partial<Pick<ProdDetailBaseRequest, 'req_marshal' | 'router' | 'code'>> & { res_id?: string };
  scope?: Scope;
}) => {
  const { base_req, scope = {} } = params;

  if (!base_req) return;

  const baseReqJson = encodeURIComponent(JSON.stringify(base_req));
  const scopeJSON = encodeURIComponent(JSON.stringify(scope));

  let path = '/product_insight/product_detail';
  if (scope?.biz_from === 'product_incubation') {
    path = '/product_insight/product_detail_for_product_incubation';
  }

  if (window.top?.GarfishBridge?.actionBridge?.openInsideTag) {
    window.top?.GarfishBridge?.actionBridge?.openInsideTag(`${path}?base_req=${baseReqJson}&scope=${scopeJSON}`);
  } else {
    open(`${path}?base_req=${baseReqJson}&scope=${scopeJSON}`);
  }
};

// 根据id将dimensions合并，selected_values根据code去重
export function uniqDimensions(dimensions: SelectedDimensionInfo[]) {
  const mergeDimension: SelectedDimensionInfo[] = [];

  cloneDeep(dimensions).forEach(dim => {
    const existDim = mergeDimension.find(item => item.id === dim.id);
    if (existDim) {
      // 合并selected_values，并根据code去重
      existDim.selected_values = uniqBy([...(existDim.selected_values ?? []), ...(dim.selected_values ?? [])], 'code');
    } else {
      mergeDimension.push(dim);
    }
  });

  return mergeDimension;
}
