import { DimensionInfo, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import { RuleValueType } from '~/RuleSelect';

// 对[多维分析维度设置], 其类目维度值依赖上面分析筛选选中的对应类目ID输入做限制
// 便于筛序中批量输入相应的类目ID, 多维设置可以进行过滤选择
export function getEnumCodeList(
  selectedDimensions: (SelectedDimensionInfo | RuleValueType)[] | undefined,
  dim: DimensionInfo | undefined,
) {
  // 输入的类目ID对其相应的类目多选做限制
  const DEPEND_CODE_MAP: any = {
    // 叶子类目: 可使用叶子类目ID做限制(如上面分析筛选, 选中叶子类目ID)
    '10028': '10195',
    // 一级类目: 一级类目ID
    '10026': '10287',
    // 二级类目: 二级类目ID
    '10027': '10288',
  };
  const { id } = dim || {};
  if (DEPEND_CODE_MAP[id as string]) {
    // 相应的类目ID维度
    const idDim = selectedDimensions?.find(i => i.id === DEPEND_CODE_MAP[id as string]) as SelectedDimensionInfo;
    const codeValues = idDim?.selected_values?.[0]?.type_value;
    return codeValues;
  }
}
