import { useRef } from 'react';

export const useValueChanges = (value: Record<string, unknown>) => {
  const valueRef = useRef(value);

  const obj: any = {};

  Object.keys(value).forEach(k => {
    obj[k] = {
      changed: valueRef.current[k] !== value[k],
      from: valueRef.current[k],
      to: value[k],
    };
  });
  console.group('数据变化检查');
  console.table(obj);
  console.groupEnd();
  valueRef.current = value;
};
