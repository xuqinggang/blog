import { useState } from 'react';

export { useLatestRequest } from './use-latest-request';

// TODO@ZOTILLE: 这里是不合理的 要想办法抽离出去
export function useFromProductIncubation() {
  const [query] = useState(new URLSearchParams(location.search));
  return query.get('biz_from') === 'product_incubation';
}
