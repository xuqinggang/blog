import { useCallback, useEffect, useRef, useState } from 'react';

export type LastRequestResult<T = unknown> = ReturnType<typeof useLatestRequest<T>>;

interface Options<P> {
  exec?: (params?: P) => boolean;
  debounce?: number;
  params?: P;
}

/**
 * 用于请求的Hook 使用最后一次成功请求的数据结果 \
 * 增加了一些`loading`和`retry`的业务属性 \
 * @param caller 请求的函数
 * @param exec 执行请求的条件，默认为`true`，即每次渲染都会执行请求
 * @returns
 */
export const useLatestRequest = <P = unknown, T = unknown>(
  caller: (params?: P) => Promise<{ data?: T }>,
  options?: Options<P> | ((params?: P) => boolean),
) => {
  const reqSeq = useRef(0);
  const [data, setData] = useState<T | null>(null);
  const [hasError, setHasError] = useState(false);
  const [loading, setLoading] = useState(false);

  const exec = typeof options === 'function' ? options : options?.exec;

  const debounce = typeof options === 'function' ? undefined : options?.debounce;
  const defaultParams = typeof options === 'function' ? undefined : options?.params;

  const fetchData = useCallback(
    async (params?: P) => {
      setLoading(true);
      setHasError(false);
      reqSeq.current += 1;
      const seq = reqSeq.current;

      if (debounce) {
        await new Promise<void>(resolve => {
          setTimeout(() => {
            resolve();
          }, debounce);
        });

        if (reqSeq.current !== seq) {
          return;
        }
      }
      try {
        const res = await caller(params);

        if (reqSeq.current === seq) {
          // 请求成功，且是最新的请求
          setData(res.data || null);
          setLoading(false);
          setHasError(false);
        }
      } catch (e) {
        if (reqSeq.current === seq) {
          console.error('ERROR 🦁 [request error] ', e);
          // 请求成功，且是最新的请求
          setData(null);
          setLoading(false);
          setHasError(true);
        }
      }
    },
    [caller, debounce],
  );

  useEffect(() => {
    const run = exec ? exec() : true;

    console.log('xxxxxx0000111run', run, exec, exec?.());
    if (run) {
      fetchData(defaultParams);
    }
  }, [fetchData, caller, exec, defaultParams]);

  return {
    loading,
    data,
    hasError,
    fetchData,
    retry: fetchData,
  };
};
