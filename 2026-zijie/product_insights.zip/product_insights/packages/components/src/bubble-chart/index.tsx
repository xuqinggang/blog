import { useMemo, useRef } from 'react';

import { ISpec, VChart as VChartComp } from '@visactor/react-vchart';
import VChart, { BaseEventParams, IMarkLineSpec, IScatterChartSpec, ITooltipPattern } from '@visactor/vchart';
import { IVisualSpecBase } from '@visactor/vchart/esm/typings';

import { AxisSegmentation } from '~/api/product/namespaces/prod_review';
import { isNullOrUndefined } from '~/utils/is';

import { AXISSEGMENTATION_MAP } from './const';
import { IBubbleChartData, IBubbleChartMarkInfo } from './type';
import { compactAmount } from './utils';

interface IProps {
  width?: number; // 图宽度
  height?: number; // 图高度

  values?: IBubbleChartData[]; // 气泡图数据
  seriesField?: keyof IBubbleChartData; // 分组字段
  xField?: keyof IBubbleChartData; // x轴字段
  yField?: keyof IBubbleChartData; // y轴字段
  sizeField?: keyof IBubbleChartData; // 气泡大小字段
  bubbleSizeRange?: number[]; // 气泡大小范围

  xMark?: IBubbleChartMarkInfo; // x轴标注数据
  yMark?: IBubbleChartMarkInfo; // y轴标注数据
  markType?: AxisSegmentation; // 标注类型，中位数/均值/Top10/Top20，默认是均值
  showLabel?: boolean; // 是否展示label，默认不展示

  onClick?: (params: BaseEventParams) => void; // 点击气泡的回调
}
export const BubbleChart = (props: IProps) => {
  const {
    values,
    xField = 'x',
    yField = 'y',
    sizeField = 'z',
    seriesField = 'legend_name',
    bubbleSizeRange = [20, 60],
    width,
    height,
    showLabel = false,
    onClick,
    xMark,
    yMark,
    markType = AxisSegmentation.Mean,
  } = props;
  const ref = useRef<VChart>(null); // VChart实例

  const markLine = useMemo<IMarkLineSpec | IMarkLineSpec[] | undefined>(() => {
    const markText = (AXISSEGMENTATION_MAP as any)[markType] ?? '';
    const xMarkLine: IMarkLineSpec = {
      x: xMark?.value ?? 0, // 标注目标：笛卡尔坐标系x坐标空间。 x轴上的标注线
      // 配置文本
      label: {
        position: 'end',
        text: xMark?.display_value ? `${markText}：${xMark.display_value}` : markText,
        autoRotate: false,
        refY: -10,
        style: {
          textAlign: 'left',
          textBaseline: 'top',
          fill: '#898B8F',
          dy: 5,
        },
        labelBackground: {
          visible: false,
        },
      },
      line: {
        // 配置线样式
        style: {
          lineWidth: 1,
          opacity: 1,
          stroke: '#898B8F',
          lineDash: [4],
        },
      },
      // 隐藏末尾箭头
      endSymbol: {
        visible: false,
      },
    };
    const yMarkLine: IMarkLineSpec = {
      y: yMark?.value ?? 0, // 标注目标：笛卡尔坐标系y坐标空间。 y轴上的标注线
      // 配置文本
      label: {
        position: 'end',
        text: yMark?.display_value ? `${markText}：${yMark.display_value}` : markText,
        style: {
          textAlign: 'right',
          textBaseline: 'bottom',
          fill: '#898B8F',
          dy: -5,
        },
        labelBackground: {
          visible: false,
        },
      },
      line: {
        // 配置线样式
        style: {
          lineWidth: 1,
          opacity: 1,
          stroke: '#898B8F',
          lineDash: [4],
        },
      },
      // 隐藏末尾箭头
      endSymbol: {
        visible: false,
      },
    };

    if (isNullOrUndefined(xMark) && isNullOrUndefined(yMark)) {
      return;
    } else if (isNullOrUndefined(xMark)) {
      return yMarkLine;
    } else if (isNullOrUndefined(yMark)) {
      return xMarkLine;
    } else {
      return [xMarkLine, yMarkLine];
    }
  }, [markType, yMark, xMark]);

  const commonTooltipMark: ITooltipPattern = {
    title: {
      value: datum => `${(datum as IBubbleChartData)?.bubble_name}`,
    },
    content: [
      {
        key: datum => (datum as IBubbleChartData)?.x_display_name,
        value: datum => (datum as IBubbleChartData)?.x_display_value,
      },
      {
        key: datum => (datum as IBubbleChartData)?.y_display_name,
        value: datum => (datum as IBubbleChartData)?.y_display_value,
      },
      {
        key: datum => (datum as IBubbleChartData)?.z_display_name,
        value: datum => (datum as IBubbleChartData)?.z_display_value,
      },
    ],
  };

  const spec: IScatterChartSpec = {
    type: 'scatter',
    padding: 16,
    width,
    height,
    data: {
      values: values ?? [],
    },
    xField,
    yField,
    seriesField,
    sizeField,
    size: {
      type: 'linear',
      range: bubbleSizeRange,
    } as IVisualSpecBase<unknown, number>,
    /** label配置 */
    label: {
      position: 'top',
      visible: showLabel,
      overlap: {
        hideOnHit: false,
      },
      formatMethod: (_, datum) => (datum as IBubbleChartData)?.bubble_name || '',
    },
    /** 坐标轴配置 */
    axes: [
      {
        type: 'linear',
        orient: 'left',
        label: {
          formatMethod: text => compactAmount(String(text)).join(''),
        },
      },
      {
        type: 'linear',
        orient: 'bottom',
        domainLine: { visible: true },
        maxHeight: '20%', // Limit maximum height to 20% of chart height
        sampling: false,
        label: {
          visible: true,
          autoRotate: true,
          autoLimit: true,
          autoRotateAngle: [0, -45],
          formatMethod: text => compactAmount(String(text)).join(''),
        },
      },
    ],
    /** 图例配置 */
    legends: {
      visible: true,
      orient: 'top',
      position: 'middle',
    },
    /** 数据标注（中位数/均值） */
    markLine,
    /** tooltip配置 */
    tooltip: {
      trigger: ['click', 'hover'],
      lockAfterClick: true, // 点击后锁定 tooltip
      enterable: true,
      mark: commonTooltipMark,
      dimension: {
        visible: false,
      },
    },
  };

  // const renderTooltip: TooltipRender = (tooltipElement, actualTooltip) => {
  //   tooltipElement.style.width = 'initial'; // tooltip宽度自适应
  //   return <div>test</div>;
  // };

  return (
    <VChartComp
      ref={ref}
      spec={spec as ISpec}
      // reserveDefaultTooltip
      // tooltipRender={renderTooltip}
      onClick={onClick as any}
    />
  );
};
