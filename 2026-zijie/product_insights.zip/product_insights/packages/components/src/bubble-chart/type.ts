export enum EBubbleChartAxisEnum {
  X = 'x',
  Y = 'y',
  Z = 'z',
}

export interface IBubbleChartMarkInfo {
  display_value?: string;
  value?: number;
}

export interface IBubbleChartData {
  x_name?: string; // x轴指标名
  x?: number; // x轴指标值
  x_display_value?: string; // x轴指标展示值
  x_display_name?: string; // x轴指标显示名
  y_name?: string; // y轴指标名
  y?: number; // y轴指标值
  y_display_value?: string; // y轴指标展示值
  y_display_name?: string; // y轴指标显示名
  z_name?: string; // z轴指标名
  z?: number; // z轴指标值
  z_display_value?: string; // z轴指标展示值
  z_display_name?: string; // z轴指标显示名
  legend_code?: string; // 图例code，用作分组
  legend_name?: string; // 图例name，用作图例展示
  bubble_name?: string; // 气泡名称
  // group?: Partial<Record<BubbleChartAxisEnum, BubbleChartGroup[]>>; // 多维分析数据
  prod_tag_code?: string; // 商品画像下钻的标识
}
