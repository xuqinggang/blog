import { AxisSegmentation } from '~/api/product/namespaces/prod_review';

export const AXISSEGMENTATION_MAP = {
  [AxisSegmentation.Mean]: '均值',
  [AxisSegmentation.Median]: '中位数',
  [AxisSegmentation.Top10Percent]: 'Top10分位',
  [AxisSegmentation.Top20Percent]: 'Top20分位',
};
