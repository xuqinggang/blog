import numeral from 'numeral';

// 判断是数字
function checkNum(input?: number | string) {
  if (typeof input === 'number') {
    return !isNaN(input);
  }
  if (typeof input === 'string') {
    return !isNaN(Number(input)) && input && Boolean(input.trim().length);
  }
  return false;
}

/**
 * 精简展示数字，增加单位万，最多保留两位小数，四舍五入
 * @param num 数字
 * @returns 12345678->["","1,234.68","万"] 123000000->["","1.2","亿"]
 */
export function compactAmount(num?: number | string): string[] {
  try {
    if (!num || !checkNum(num)) {
      return ['', '-', ''];
    }

    let data = Math.abs(Number(num));
    let unit = '';
    if (data > 99999950) {
      data = data / 100000000;
      unit = '亿';
    } else if (data > 9999.995) {
      data = data / 10000;
      unit = '万';
    }

    return [Number(num) < 0 ? '-' : '', numeral(data).format('0,0.[00]'), unit];
  } catch (error) {
    return ['', '-', ''];
  }
}
