import { ReactNode, useCallback, useMemo } from 'react';
import { omit } from 'lodash-es';

import { DragMoveEvent } from '@dnd-kit/core';
import { CustomLogic } from '@ecom/arctic-components';

import { DimItem } from '../DimCheckGroup';
import { DropContainer } from '../dnd/drop-container';
import { RuleValueType } from '../RuleSelect';

import { DimEnumFilterItem, DimItemWithId } from './item';

import { DimensionInfo, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import { MAX_SINGLE_DIMENSION_ENUM_COUNT, MIN_MULTI_DIM } from '~/constant';
import { DimensionType } from '~/filter-form/types';
import { getMultiDimList } from '~/filter-form/utils/get-multi-dim-list';

export interface DimEnumFilterProps {
  value?: DimItem[];
  multiDimDimensions?: Partial<Record<DimensionType, DimensionInfo[]>> | null;
  selectedDimensions?: (SelectedDimensionInfo | RuleValueType)[];
  list?: DimItem[];
  /** 在static模式下，需要使用这个函数获取每一层可用的维度 */
  getList?: (idx: number) => DimItem[] | undefined;
  min?: number; // 最少选择的维度数量
  maxSelected?: number; // 单个维度最多选择的枚举数量
  ruleDisabled?: boolean | Array<'rule' | 'op' | 'value'>;
  showLogic?: boolean;
  addBtn?: ReactNode;
  onChange?: (v: DimItem[]) => void;
  isStatic?: boolean;
}

export const DimEnumFilter: React.FC<DimEnumFilterProps> = props => {
  const {
    value = [],
    multiDimDimensions,
    selectedDimensions,
    list: outerList,
    min = MIN_MULTI_DIM,
    maxSelected = MAX_SINGLE_DIMENSION_ENUM_COUNT,
    ruleDisabled,
    showLogic = true,
    onChange,
    addBtn,
    isStatic,
    getList,
  } = props;
  const disabledDelete = value.length <= min;

  const list = useMemo<DimItem[]>(() => {
    if (outerList) {
      return outerList;
    }

    const dims = getMultiDimList(multiDimDimensions, selectedDimensions, value, maxSelected);
    return dims.reduce<DimItem[]>((prev, curr) => prev.concat(curr.list ?? []), []);
  }, [maxSelected, multiDimDimensions, outerList, selectedDimensions, value]);

  const valueWithId = useMemo<DimItemWithId[]>(
    () =>
      value.map<DimItemWithId>(i => ({
        ...i,
        id: i.value,
      })),
    [value],
  );

  const handleChange = useCallback(
    (idx: number, v?: RuleValueType) => {
      if (!v) {
        return;
      }

      const newValue = [...value];
      const dimItem = (getList?.(idx) || list)?.find(({ value }) => value === v.id);
      if (!dimItem) {
        return;
      }

      newValue[idx] = omit(
        {
          ...dimItem,
          selected_enums: v.selected_option,
        },
        ['remote'],
      );

      onChange?.(newValue);
    },
    [getList, list, onChange, value],
  );

  const handleDelete = useCallback(
    (idx: number) => {
      const newValue = [...value.slice(0, idx), ...value.slice(idx + 1)];
      onChange?.(newValue);
    },
    [onChange, value],
  );

  const getMoveIndex = useCallback((array: DimItem[], event: DragMoveEvent) => {
    const { active, over } = event;
    const activeIndex = array.findIndex(item => item.value === active.id);
    const overIndex = array.findIndex(item => item.value === over?.id);

    // 处理未找到索引的情况
    return {
      activeIndex: activeIndex !== -1 ? activeIndex : 0,
      overIndex: overIndex !== -1 ? overIndex : activeIndex,
    };
  }, []);

  return (
    <div className="flex gap-3 items-center w-full max-w-[1320px]">
      {showLogic && <CustomLogic renderIcon={() => '交叉'} disabled />}
      <div className="flex-1 flex gap-2">
        {!value.length && addBtn ? (
          addBtn
        ) : (
          <>
            <DropContainer value={value} items={valueWithId} getMoveIndex={getMoveIndex} onChange={onChange}>
              <div className="flex-1 flex flex-col gap-2">
                {valueWithId.map((item, index) => (
                  <DimEnumFilterItem
                    key={item.id}
                    item={item}
                    index={index}
                    value={value}
                    ruleDisabled={ruleDisabled}
                    disabledDelete={disabledDelete}
                    list={getList?.(index) || list}
                    max={maxSelected}
                    handleChange={handleChange}
                    handleDelete={handleDelete}
                    isStatic={isStatic}
                  />
                ))}
              </div>
            </DropContainer>
            <div className="self-end">{addBtn}</div>
          </>
        )}
      </div>
    </div>
  );
};
