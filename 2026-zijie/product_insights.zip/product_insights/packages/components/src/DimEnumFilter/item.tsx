import { memo, useMemo } from 'react';

import { UniqueIdentifier } from '@dnd-kit/core';
import { Divider, Icon } from '@ecom/auxo';
import { EnumOption, EnumSelectProps, RemoteSelectProps } from '@ecom/auxo-pro-form';

import { DimItem, RemoteSelect } from '../DimCheckGroup';
import { DragItem } from '../dnd/drag-item';
import { useDropContext } from '../dnd/drop-container';
import RuleSelect, { RuleOption, RuleValueType, SelectType } from '../RuleSelect';

import DragIcon from '~/assets/svg/drag.svg';
import { MAX_SINGLE_DIMENSION_ENUM_COUNT } from '~/constant';
import { transformDimItem2Rule } from '~/filter-form/utils/transform';

export interface DimItemWithId extends DimItem {
  id: UniqueIdentifier;
}

interface DimEnumFilterItemProps {
  item: DimItemWithId;
  value: DimItem[];
  index: number;
  ruleDisabled?: boolean | Array<'rule' | 'op' | 'value'>;
  disabledDelete?: boolean;
  list?: DimItem[];
  max?: number; // 单个维度最多可选择的枚举值数量
  handleChange: (idx: number, v?: RuleValueType) => void;
  handleDelete: (idx: number) => void;
  isStatic?: boolean;
}

export const DimEnumFilterItem = memo((props: DimEnumFilterItemProps) => {
  const {
    item,
    value,
    index,
    ruleDisabled,
    disabledDelete,
    list,
    max = MAX_SINGLE_DIMENSION_ENUM_COUNT,
    handleChange,
    handleDelete,
    isStatic,
  } = props;
  const { grabbing } = useDropContext();
  const { value: dimValue, selected_enums } = item;
  const selectedValue = useMemo<RuleValueType[]>(() => value.map<RuleValueType>(transformDimItem2Rule), [value]);

  return (
    <DragItem item={item} className="flex items-center gap-2 pt-1 pb-1 pl-2 pr-2 rounded-[4px] bg-[#F8F9FA] flex-1">
      {({ attributes, listeners }) => (
        <>
          {isStatic ? null : (
            <div {...attributes} {...listeners} className={grabbing ? 'cursor-grabbing' : 'cursor-grab'}>
              <img src={DragIcon} />
            </div>
          )}
          <RuleSelect
            disabled={ruleDisabled}
            // className="draggable-select"
            value={selectedValue[index]}
            onChange={v => {
              handleChange(index, v);
            }}
            options={(
              list?.map<RuleOption>(i => {
                let defaultEnums: EnumOption[] | undefined;
                if (i.value === dimValue) {
                  defaultEnums = selected_enums;
                }

                return {
                  ...i,
                  type:
                    i.show_type === SelectType.StaticNoInput
                      ? SelectType.StaticNoInput
                      : i.remote
                      ? SelectType.RemoteMultiSelect
                      : SelectType.MultiSelect,
                  operatorType: false,
                  // 用于多维分析的组件是「枚举多选」或者「远程枚举选择」
                  valueProps: {
                    defaultEnums, // 增加一个defaultEnums参数，解决RemoteSeleect service返回前数据回显问题
                    maxSelected: max,
                    multiple: true,
                    loadMore: true,
                    ...(i.remote?.(selectedValue as RemoteSelect[]) ?? {}),
                  } as RemoteSelectProps | EnumSelectProps,
                };
              }) ?? []
            ).filter(j => j.value === dimValue || !value.some(k => k.value === j.value))}
          />
          {isStatic ? null : (
            <>
              <Divider type="vertical" style={{ height: 12, margin: 'unset' }} />
              <Icon.DeleteIcon
                disabled={disabledDelete}
                onClick={() => {
                  !disabledDelete && handleDelete(index);
                }}
                className={disabledDelete ? 'cursor-not-allowed' : 'cursor-pointer'}
              />
            </>
          )}
        </>
      )}
    </DragItem>
  );
});

DimEnumFilterItem.displayName = 'DimEnumFilterItem';
