interface Options {
  startColor?: [number, number, number];
  endColor?: [number, number, number];
  steps: number;
}
export const getColorSeries = (options?: number | Options) => {
  const cnt = typeof options === 'number' ? options : options?.steps || 10;

  const startColor = typeof options === 'number' ? [92, 135, 255] : options?.startColor || [92, 135, 255];
  const endColor = typeof options === 'number' ? [235, 240, 255] : options?.endColor || [235, 240, 255];
  if (cnt <= 1) {
    return [
      {
        color: `rgb(${startColor[0]}, ${startColor[1]}, ${startColor[2]})`,
        bg: `rgb(${startColor[0]}, ${startColor[1]}, ${startColor[2]}, 0.2)`,
        light: false,
      },
    ];
  }
  const rStep = (endColor[0] - startColor[0]) / (cnt - 1);
  const gStep = (endColor[1] - startColor[1]) / (cnt - 1);
  const bStep = (endColor[2] - startColor[2]) / (cnt - 1);

  return new Array(cnt).fill(0).map((_, idx) => {
    const r = startColor[0] + rStep * idx;
    const g = startColor[1] + gStep * idx;
    const b = startColor[2] + bStep * idx;
    return {
      color: `rgb(${r}, ${g}, ${b})`,
      bg: `rgb(${r}, ${g}, ${b}, 0.2)`,
      light: r > 170,
    };
  });
};
