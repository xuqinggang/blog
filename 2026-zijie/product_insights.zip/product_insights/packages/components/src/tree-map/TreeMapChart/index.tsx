import { FC, useEffect, useMemo, useRef, useState } from 'react';

import { getColorSeries } from '../utils';

import { SquareMap } from './SquareMap';
import { RenderInfo, squarify } from './squarify';
import { Tooltip, TooltipRef } from './Tooltip';

import { ResizedPlaceholder } from '~/placeholder';
export interface TreeMapChartProps {
  data: Array<{
    name: string;
    value: number;
  }>;
  onClick?: (data: RenderInfo) => void;
}

export const TreeMapChart: FC<TreeMapChartProps> = ({ data: originData, onClick }) => {
  const boxRef = useRef<HTMLDivElement | null>(null);
  const [boxSize, setBoxSize] = useState({ width: 0, height: 0 });
  const tooltipRef = useRef<TooltipRef>(null);

  const renderData = useMemo(() => {
    const total = originData.reduce((acc, cur) => acc + cur.value, 0);
    return originData
      .filter(item => item.value > 0)
      .map(item => ({
        ...item,
        percent: item.value / total,
      }));
  }, [originData]);

  const sizeObserver = useMemo(() => {
    const observer = new ResizeObserver(() => {
      setBoxSize({
        width: boxRef.current?.clientWidth || 0,
        height: boxRef.current?.clientHeight || 0,
      });
    });
    return observer;
  }, []);

  useEffect(() => {
    return () => {
      sizeObserver.disconnect();
    };
  }, [sizeObserver]);

  const handleRef = (el: HTMLDivElement) => {
    if (el && boxRef.current !== el) {
      const rect = el.getBoundingClientRect();
      setBoxSize({ width: rect.width, height: rect.height });
      sizeObserver.observe(el);
      boxRef.current = el;
    }
  };

  const blocks = squarify(renderData, {
    x: 0,
    y: 0,
    width: 100,
    height: 100,
  });

  const colors = useMemo(() => getColorSeries(blocks.length), [blocks.length]);

  if (!renderData.length) {
    return (
      <div className="w-full h-full flex justify-center items-center">
        <ResizedPlaceholder />
      </div>
    );
  }

  return (
    <div
      className="relative w-full h-full "
      ref={handleRef}
      onMouseMove={e => {
        const index = (e.target as HTMLDivElement)?.dataset?.index;
        tooltipRef.current?.setLocation({ dataIdx: Number(index), x: e.pageX, y: e.pageY });
        tooltipRef.current?.setVisible(true);
      }}
      onMouseLeave={() => tooltipRef.current?.setVisible(false)}
    >
      <SquareMap blocks={blocks} boxSize={boxSize} colors={colors} onClick={onClick} />
      <Tooltip ref={tooltipRef} data={renderData} colors={colors} />
    </div>
  );
};
