interface TreeMapDataItem {
  name: string;
  value: number;
}

interface Location {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface RenderInfo {
  item: TreeMapDataItem;
  x: number;
  y: number;
  width: number;
  height: number;
  percentage: number;
}

export const squarify = (items: TreeMapDataItem[], location: Location, total = 0): RenderInfo[] => {
  const filteredTotal = total || items.reduce((sum, item) => sum + item.value, 0);
  const { x, y, width, height } = location;
  if (items.length === 0) return [];

  if (items.length === 1) {
    const item = items[0];
    const percentage = item.value / filteredTotal;
    return [
      {
        item,
        x,
        y,
        width: Math.max(1, width),
        height: Math.max(1, height),
        percentage,
      },
    ];
  }

  // 计算最佳分割点
  const totalValue = items.reduce((sum, item) => sum + item.value, 0);
  const isWide = width > height * 2;

  // 找到最佳分割点，使得矩形比例接近1:1
  let bestRatio = Infinity;
  let bestSplit = 1;

  for (let i = 1; i < items.length; i++) {
    const group1Value = items.slice(0, i).reduce((sum, item) => sum + item.value, 0);

    let ratio1;
    let ratio2;
    if (isWide) {
      const width1 = (group1Value / totalValue) * width;
      ratio1 = Math.max(width1 / height, height / width1);
      const width2 = width - width1;
      ratio2 = Math.max(width2 / height, height / width2);
    } else {
      const height1 = (group1Value / totalValue) * height;
      ratio1 = Math.max(width / height1, height1 / width);
      const height2 = height - height1;
      ratio2 = Math.max(width / height2, height2 / width);
    }

    const maxRatio = Math.max(ratio1, ratio2);
    if (maxRatio < bestRatio) {
      bestRatio = maxRatio;
      bestSplit = i;
    }
  }

  // 按最佳分割点分组
  const group1 = items.slice(0, bestSplit);
  const group2 = items.slice(bestSplit);
  const group1Value = group1.reduce((sum, item) => sum + item.value, 0);

  if (isWide) {
    const width1 = (group1Value / totalValue) * width;
    return [
      ...squarify(
        group1,
        {
          x,
          y,
          width: width1,
          height,
        },
        filteredTotal,
      ),
      ...squarify(
        group2,
        {
          x: x + width1,
          y,
          width: width - width1,
          height,
        },
        filteredTotal,
      ),
    ];
  } else {
    const height1 = (group1Value / totalValue) * height;
    return [
      ...squarify(
        group1,
        {
          x,
          y,
          width,
          height: height1,
        },
        filteredTotal,
      ),
      ...squarify(
        group2,
        {
          x,
          y: y + height1,
          width,
          height: height - height1,
        },
        filteredTotal,
      ),
    ];
  }
};
