import { FC, useEffect, useRef } from 'react';

import VChart from '@visactor/vchart';
// register the theme
import { allThemeMap } from '@visactor/vchart-theme';

import { TreeMapChartProps } from '.';

// register themes
allThemeMap.forEach((theme, name) => {
  VChart.ThemeManager.registerTheme(name, theme);
});

export const VisTreeMapChart: FC<TreeMapChartProps> = ({ data }) => {
  const domRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!domRef.current) {
      return;
    }
    const vchart = new VChart(
      {
        type: 'treemap',
        data: {
          values: data,
        },
        categoryField: 'name',
        valueField: 'value',
        label: {
          visible: true,
          style: {
            fontSize: 12,
          },
        },
        theme: 'veODesignLightMedical',
      },
      { dom: domRef.current },
    );
    vchart.renderSync();
    return () => {
      vchart.release();
    };
  }, [data]);
  return <div ref={domRef} className="w-full h-full" />;
};
