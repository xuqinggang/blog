import { FC, memo } from 'react';
import classNames from 'classnames';

import { Divider } from '@ecom/auxo';

import { RenderInfo } from './squarify';

import { NumberDisplay } from '~/number_display';

interface SquareMapProps {
  blocks: RenderInfo[];
  boxSize: {
    width: number;
    height: number;
  };
  colors: {
    color: string;
    light: boolean;
  }[];
  onClick?: (data: RenderInfo) => void;
}

export const SquareMap: FC<SquareMapProps> = memo(({ blocks, boxSize, colors, onClick }) => {
  return (
    <>
      {blocks.map((b, idx) => {
        const { item } = b;
        const color = colors[idx % colors.length];
        const w = (boxSize.width * b.width) / 100 - 4;
        const h = (boxSize.height * b.height) / 100 - 4;
        const showTitle = w > 24 && h > 18;
        const smallerText = h < 32;
        const showInfo = h > 64;

        return (
          <div
            key={idx}
            style={{
              border: '1px solid white',
              position: 'absolute',
              left: `${b.x}%`,
              top: `${b.y}%`,
              width: `${b.width}%`,
              height: `${b.height}%`,
              backgroundColor: color.color,
            }}
            onClick={() => onClick?.(b)}
            data-index={idx}
            className="flex flex-col justify-center items-center  text-white hover:transform hover:scale-105 hover:z-10 transition-all !cursor-default"
          >
            <div
              className={classNames(
                'flex flex-col justify-center items-center user-select-none select-none pointer-events-none',
                color.light ? 'text-text-icon-1' : 'text-white',
                'font-medium',
                {
                  'text-xs': smallerText,
                  'leading-4': smallerText,
                },
              )}
            >
              {showTitle ? <span className={`text-sm leading-5 `}>{item.name}</span> : null}
              {showInfo ? (
                <div className="flex items-center">
                  <span>
                    <NumberDisplay value={b.percentage} format={{ ratio: '%' }} />
                  </span>
                  <Divider type="vertical" />
                  <span>
                    <NumberDisplay value={item.value} format={{ fixed: { mode: 'auto', len: 3 } }} />
                  </span>
                </div>
              ) : null}
            </div>
          </div>
        );
      })}
    </>
  );
});
