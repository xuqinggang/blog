import { forwardRef, useImperativeHandle, useMemo, useState } from 'react';
import classNames from 'classnames';
import { createPortal } from 'react-dom';

import { Divider } from '@ecom/auxo';

import { formatNumber } from '~/utils';

interface Location {
  dataIdx?: number;
  x: number;
  y: number;
}
export interface TooltipRef {
  setLocation: (location: Location) => void;
  setVisible: (visible: boolean) => void;
}

interface TooltipProps {
  data: Array<{
    name: string;
    value: number;
    percent: number;
  }>;
  colors: {
    color: string;
    light: boolean;
  }[];
}

export const Tooltip = forwardRef<TooltipRef, TooltipProps>(({ data = [], colors = [] }, ref) => {
  const [location, setLocation] = useState<Location>({ dataIdx: undefined, x: 0, y: 0 });
  const [visible, setVisible] = useState(false);
  const { body } = document;

  useImperativeHandle(ref, () => ({
    setLocation,
    setVisible,
  }));

  const showTooltip = useMemo(() => visible && location.dataIdx !== undefined, [visible, location.dataIdx]);

  return createPortal(
    <div className={`fixed top-0 left-0 w-[100vw] h-0 z-[999] ${showTooltip ? 'block' : 'hidden'}`}>
      {location.dataIdx === undefined ? null : (
        <div
          className={classNames(
            'bg-white w-fit rounded-[4px] flex items-center shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)]',
            'p-3',
          )}
          style={{ transform: `translate(${location.x + 10}px, ${location.y + 7}px)` }}
        >
          <div className="w-2 h-2 rounded-full " style={{ backgroundColor: colors[location.dataIdx]?.color }} />
          <span className="ml-1 text-[#1d1d2e] text-xs leading-[18px] ">{data[location.dataIdx]?.name}</span>
          <span className="ml-1 text-[#1d1d2e] text-xs leading-[18px] ">
            {(data[location.dataIdx]?.percent * 100).toFixed(2)}%
          </span>
          <Divider type="vertical" />
          <span className="ml-1 text-[#1d1d2e] text-xs leading-[18px] ">
            {formatNumber(data[location.dataIdx]?.value, { fixed: { mode: 'auto', len: 3 } })}
          </span>
        </div>
      )}
    </div>,
    body,
  );
});
