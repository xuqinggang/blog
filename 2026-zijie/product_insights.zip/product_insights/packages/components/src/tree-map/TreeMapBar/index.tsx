import { FC, useMemo } from 'react';

import { Tooltip } from '@ecom/auxo';

import { getColorSeries } from '../utils';

import { formatNumber } from '~/utils';

export interface TreeMapBarProps {
  data: Array<{
    name: string;
    value: number;
  }>;
  targetName?: string;
}

export const TreeMapBar: FC<TreeMapBarProps> = ({ data, targetName }) => {
  const total = data.reduce((prev, cur) => prev + cur.value, 0);

  const colors = useMemo(
    () =>
      getColorSeries({
        startColor: [25, 102, 255],
        endColor: [188, 189, 192],
        steps: data.length,
      }),
    [data.length],
  );
  const renderData = data.map(item => ({
    ...item,
    percent: item.value / total,
  }));

  const isSpecial = renderData.length === 2;

  if (isSpecial) {
    return (
      <div className="container flex w-full h-full gap-4 overflow-hidden min-h-[104px]">
        <Tooltip
          title={`${renderData[0].name} ${formatNumber(renderData[0].value)} ${formatNumber(renderData[0].percent, {
            ratio: '%',
            fixed: 2,
          })}`}
        >
          <div
            className="h-full flex items-center justify-between p-3 bg-highlight border-[1px] border-hover rounded min-w-[320px]"
            style={{
              width: `${renderData[0].percent * 100}%`,
            }}
          >
            <div className="content text-white flex flex-col items-start">
              <span className="overflow-hidden text-ellipsis whitespace-nowrap text-base font-medium leading-8 mb-2 text-brand">
                {renderData[0].name}
              </span>
              <span className="text-text-icon-1 text-xs leading-4">{targetName}</span>
              <span className="text-text-icon-0 font-semibold text-lg leading-6">
                {formatNumber(renderData[0].value)}
              </span>
            </div>
            <div className="ratio">
              <span className="font-bold text-[28px] leading-[42px] text-hover">
                {formatNumber(renderData[0].percent, { ratio: '%', fixed: 2 })}
              </span>
            </div>
          </div>
        </Tooltip>
        <Tooltip
          title={`${renderData[1].name} ${formatNumber(renderData[1].value)} ${formatNumber(renderData[1].percent, {
            ratio: '%',
            fixed: 2,
          })}`}
        >
          <div
            className="h-full flex items-center justify-between p-3 bg-white border-[1px] border-line-1 rounded min-w-[320px]"
            style={{
              width: `${renderData[1].percent * 100}%`,
            }}
          >
            <div className="content text-white flex flex-col items-start">
              <span className="overflow-hidden text-ellipsis whitespace-nowrap text-base font-medium leading-8 mb-2 text-text-icon-1">
                {renderData[1].name}
              </span>
              <span className="text-text-icon-1 text-xs leading-4">{targetName}</span>
              <span className="text-text-icon-0 font-semibold text-lg leading-6">
                {formatNumber(renderData[1].value)}
              </span>
            </div>
            <div className="ratio">
              <span className="font-bold text-[28px] leading-[42px] text-text-icon-3">
                {formatNumber(renderData[1].percent, { ratio: '%', fixed: 2 })}
              </span>
            </div>
          </div>
        </Tooltip>
      </div>
    );
  }

  return (
    <div className="container flex w-full h-full gap-4 overflow-hidden min-h-[104px]">
      {renderData.map((item, idx) => {
        const { color, bg } = colors[idx];
        return (
          <Tooltip
            key={item.name}
            title={`${item.name} ${formatNumber(item.value)} ${formatNumber(item.percent, { ratio: '%', fixed: 2 })}`}
          >
            <div
              key={item.name}
              className="h-full flex items-center justify-between p-3"
              style={{
                width: `${item.percent * 100}%`,
                backgroundColor: bg,
                border: `1px solid ${color}`,
                borderRadius: 4,
                overflow: 'hidden',
              }}
            >
              <div className="content text-white flex flex-col items-start">
                <span
                  className="overflow-hidden text-ellipsis whitespace-nowrap text-base font-medium leading-8 mb-2"
                  style={{ color }}
                >
                  {item.name}
                </span>
                <span className="text-text-icon-1 text-xs leading-4">指标名称</span>
                <span className="text-text-icon-0 font-semibold text-lg leading-6">{formatNumber(item.value)}</span>
              </div>
              <div className="ratio">
                <span className="font-bold text-[28px] leading-[42px]" style={{ color }}>
                  {formatNumber(item.percent, { ratio: '%', fixed: 2 })}
                </span>
              </div>
            </div>
          </Tooltip>
        );
      })}
    </div>
  );
};
