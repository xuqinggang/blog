import { FC } from 'react';
import classNames from 'classnames';

interface ReviewConclusionTargetItem {
  label: string;
  value: string;
  change?: string;
  changePercent?: string;
  isPositive?: boolean;
  hasTag?: boolean;
  tagText?: string;
}

interface ReviewConclusionTargetSection {
  title: string;
  mainValue: string;
  unit: string;
  items: ReviewConclusionTargetItem[];
}

interface ReviewConclusionTargetCardProps {
  title: string;
  sections: ReviewConclusionTargetSection[];
}

export const ReviewConclusionTargetCard: FC<ReviewConclusionTargetCardProps> = ({ title, sections }) => {
  return (
    <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
      <div className="text-lg font-semibold text-gray-800 mb-4">{title}</div>

      <div className="grid grid-cols-2 gap-4">
        {sections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="bg-white rounded-lg p-4 space-y-3">
            {/* 标题和主要数值 */}
            <div className="space-y-1">
              <div className="text-sm text-gray-600">{section.title}</div>
              <div className="text-2xl font-bold text-gray-900">
                {section.mainValue}
                <span className="text-sm font-normal text-gray-600 ml-1">{section.unit}</span>
              </div>
            </div>

            {/* 详细项目 */}
            <div className="space-y-2">
              {section.items.map((item, itemIndex) => (
                <div key={itemIndex} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-600">{item.label}</span>
                    {item.hasTag && item.tagText && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                        {item.tagText}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center space-x-2">
                    {item.change && (
                      <span
                        className={classNames(
                          'text-sm font-medium',
                          item.isPositive ? 'text-green-600' : 'text-red-600',
                        )}
                      >
                        {item.change}
                      </span>
                    )}

                    {item.changePercent && (
                      <span
                        className={classNames(
                          'text-sm font-medium flex items-center',
                          item.isPositive ? 'text-green-600' : 'text-red-600',
                        )}
                      >
                        {item.isPositive && (
                          <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path
                              fillRule="evenodd"
                              d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        )}
                        {!item.isPositive && (
                          <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path
                              fillRule="evenodd"
                              d="M14.707 12.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l2.293-2.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        )}
                        {item.changePercent}
                      </span>
                    )}

                    {item.hasTag && item.tagText && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                        {item.tagText}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
