/* eslint-disable @typescript-eslint/ban-types */
import React from 'react';
import { omit } from 'lodash-es';
/**
 * 利用逆变，判断 A 是不是存在于 B=(A | X) 中
 *
 * ```ts
 * type A = 'hello' | 'world';
 *
 * // true
 * // 'hello' 是 'hello' | 'world' 的子集
 * type B = In<'hello', A>;
 * ```
 */
type In<A, B> = (() => A) extends () => B ? true : false;

/**
 * 判断两个类型是否强相等
 *
 */
type IsEqual<A, B> = (<T>() => T extends A ? 1 : 2) extends <T>() => T extends B ? 1 : 2 ? true : false;

/**
 * 移除一个 object 顶层所有 partial 属性
 *
 * ```ts
 * type A = { name: string; age?: number; hobby: string };
 *
 * // { name: string }
 * // age 和 hobby 都是 partial 的，所以被移除了
 * type B = OmitPartialAttr<A>;
 * ```
 */
type OmitPartialAttr<T> = {
  [K in keyof T as In<undefined, T[K]> extends true ? never : K]: T[K];
};

/**
 * 受控（Modal/Drawer 等）组件，必须有这些 props
 */
export type PropsWithVisible<T extends Record<string, any> = {}> = {
  visible: boolean;
  onCancel: () => void;
  // 弹窗、抽屉展现前的逻辑或数据处理
  onShowWithPipe?: (...args: any[]) => Promise<any>;
} & T;

/**
 * 触发器（Button/Text 等）组件，必须有这些 props
 * todo:: 目前只支持 onClick
 */
type PropsWithTrigger = {
  onClick?: (...args: any[]) => void;
};

type PropsInject<C extends PropsWithVisible, R = Omit<C, keyof PropsWithVisible>> = IsEqual<
  OmitPartialAttr<R>,
  {}
> extends true
  ? {
      inject?: R;
    }
  : {
      inject: R;
    };

/**
 * 搞一个 HOC，传入 A 和 B，当 B 触发 onClick 时，给 A 传入 `visible: true` 的 props
 *
 * 因为 Modal 和 Drawer 太多了，不想给每个 Modal/Drawer 都写对应的 visible 控制
 *
 * \`\`\`tsx
 * ```tsx
 * const CustomButton = withVisibility(MyModal)(Button);
 *
 * <CustomButton>点我则 MyModal visible</CustomButton>
 * ```
 * \`\`\`
 *
 * - CustomButton 的 `inject` props，会透传给 MyModal
 * - CustomButton 支持所有的 Button props
 * - CustomButton 具有 `visible` 和 `onCancel` 的 props
 *
 * 如果 MyModal 的 props 除了 PropsWithVisible 外都是 Partial 的，那么 `inject` 为选填
 *
 * 反之 `inject` 将会成为必填 props
 */
export default function withVisibility<C extends PropsWithVisible>(Component: React.ComponentType<C>) {
  return function <T extends PropsWithTrigger>(Trigger: React.ComponentType<T>) {
    return function (props: T & Partial<PropsWithVisible> & PropsInject<C>) {
      const [visible, setVisible] = React.useState(false);
      const [pipeProps, setPipeProps] = React.useState<any>();
      const { inject: injectedProps, visible: visibleFromProps, onCancel, onShowWithPipe, onClick } = props;

      const handleOnCancel = () => {
        setVisible(false);
        typeof onCancel === 'function' && onCancel();
      };

      const handleOnClick = (...args: any[]) => {
        if (onShowWithPipe && typeof onShowWithPipe === 'function') {
          onShowWithPipe(...args)
            .then(pipeParams => {
              setPipeProps(pipeParams);
              return Promise.resolve();
            })
            .then(() => {
              setVisible(true);
            });
        } else {
          setVisible(true);
          typeof onClick === 'function' && onClick(...args);
        }
      };

      React.useEffect(() => {
        if (typeof visibleFromProps === 'boolean') {
          setVisible(visibleFromProps);
        }
      }, [visibleFromProps]);

      const triggerProps: any = Object.assign({}, omit(props, ['inject', 'visible']), {
        onClick: handleOnClick,
      });
      const componentProps: any = Object.assign({}, injectedProps as any, pipeProps as any, {
        visible,
        onCancel: handleOnCancel,
      });

      return (
        <React.Fragment>
          {React.createElement(Trigger, triggerProps)}
          {React.createElement(Component, componentProps)}
        </React.Fragment>
      );
    };
  };
}
