import { useCallback, useState } from 'react';

export const useExecTask = () => {
  const [taskCnt, setTaskCnt] = useState(0);

  const execTask = useCallback((pmz: Promise<any>) => {
    setTaskCnt(cnt => cnt + 1);
    pmz.finally(() => {
      setTaskCnt(cnt => cnt - 1);
    });
  }, []);

  return { taskCnt, execTask };
};
