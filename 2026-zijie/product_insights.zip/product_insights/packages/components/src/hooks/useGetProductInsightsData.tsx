import React from 'react';
import dayjs from 'dayjs';
import { isEmpty, noop } from 'lodash-es';

import { EnumOption } from '@ecom/auxo-pro-form/es/components';

import { productClient } from '~/api';
import {
  BizType,
  GetDataReadyTimeResponse,
  GetDimensionListData,
  GetDimensionListResponse,
  GetProductAnalysisBizListResponse,
} from '~/api/product/namespaces/dimensions';
import { DIMENSION_TYPE_LIST } from '~/constant';
import { CommonFilter, DefaultEnumMap, DimensionType } from '~/filter-form/types';
import { DefaultEnumInfo } from '~/PoolSelect';
import { RuleValueType } from '~/RuleSelect';

const DIMENSION_CACHE_KEY_PREFIX = 'INSIGHT_CACHE_DIMENSION_V2';

export interface ProductInsightsDataContextVal {
  bizData: GetProductAnalysisBizListResponse['data'];
  getCustomContext(): Record<string, any>;
  setCustomContext(context?: Record<string, any>): void;
}

// 获取货品分析表readyTime
const getProductInsightsReadyTime = async function (bizType: BizType) {
  try {
    const { data }: GetDataReadyTimeResponse = await productClient.GetReadyTime({ biz_type: bizType });
    if (data) {
      return data;
    }
    return undefined;
  } catch (e) {
    console.error('Get ready time error', e);
    return undefined;
  }
};

// 获取货品分析维度列表
const getProductInsightsDimensionData = async function (bizType: BizType) {
  try {
    // 默认从localStorage里面获取dimension
    const cacheKey = `${DIMENSION_CACHE_KEY_PREFIX}_${bizType}`;
    const { timeStamp = 0, data } = JSON.parse(localStorage.getItem(cacheKey) ?? '{}');
    const isOutDate = dayjs(timeStamp).add(1, 'd').isBefore(dayjs()); // 缓存过期时间为1d

    let dimData: GetDimensionListData | undefined;
    if (!isOutDate && data) {
      // 缓存未过期
      dimData = data;
    } else {
      const { data: resData }: GetDimensionListResponse = await productClient.GetDimensionList({
        biz_type: bizType,
      });

      if (resData) {
        dimData = resData;

        // 更新缓存
        localStorage.setItem(cacheKey, JSON.stringify({ timeStamp: dayjs().toString(), data: resData }));
      }
    }
    return dimData;
  } catch (e) {
    console.error('Get dimension error', e);
    return undefined;
  }
};

const getProductAnalysisBizList = async function () {
  try {
    const { data } = await productClient.GetProductAnalysisBizList({});
    return data;
  } catch (e) {
    console.error('Get dimension error', e);
    return undefined;
  }
};

const getEnumsByCode = async (dim: RuleValueType): Promise<DefaultEnumInfo> => {
  const { id, selected_values } = dim;
  if (!id || !selected_values?.length) {
    return {};
  }

  const { data } = await productClient.GetDimensionPageEnumList({
    dimension_id: id || '',
    enum_code_list: selected_values?.map(item => String(item)) ?? [],
  });

  return {
    id: id || '',
    enumList: data?.enum_list?.map<EnumOption>(({ code, name }) => ({ value: code || '', label: name || '' })) ?? [],
  };
};

// 获取默认的枚举值
const getDefaultEnums = async (
  filter?: CommonFilter | RuleValueType[] | null,
  dimensionData?: GetDimensionListData | null,
) => {
  if (isEmpty(dimensionData) || isEmpty(filter)) {
    return;
  }

  // 找出筛选项中需要搜索枚举值的维度列表
  const filterDims = (
    Array.isArray(filter)
      ? filter.map<RuleValueType>(i => ({ ...i, dim_type: 'product_dimensions' }))
      : Object.keys(filter).reduce<RuleValueType[]>((prev, curr) => {
          if (!DIMENSION_TYPE_LIST.includes(curr) || !filter?.[curr as keyof CommonFilter]) {
            return prev;
          }

          return prev.concat(
            filter[curr as DimensionType]?.map(i => ({ ...i, dim_type: curr as DimensionType })) ?? [],
          );
        }, [])
  ).filter(({ id, dim_type }) => {
    if (!id || !dim_type) {
      return false;
    }

    const dims = dimensionData?.[dim_type];
    return dims?.find(i => i.id === id)?.need_page_search;
  });

  // #region 搜索枚举值
  try {
    const promises = filterDims
      .filter(({ id, selected_values }) => Boolean(id && selected_values?.length))
      .map(getEnumsByCode);
    const arr: DefaultEnumInfo[] = await Promise.all(promises);
    const defaultEnumMap = arr.reduce<DefaultEnumMap>((prev, curr) => {
      const { id, enumList } = curr;
      if (id && enumList?.length) {
        prev[id] = enumList;
      }

      return prev;
    }, {});

    return defaultEnumMap;
  } catch (e) {
    console.error('Get enums by code error', e);
  }
};

export const productInsightsRequest = {
  getProductInsightsReadyTime,
  getProductInsightsDimensionData,
  getProductAnalysisBizList,
  getDefaultEnums,
  getEnumsByCode,
};

export const ProductInsightsDataContext = React.createContext<ProductInsightsDataContextVal>({
  bizData: {} as GetProductAnalysisBizListResponse['data'],
  getCustomContext: () => ({}),
  setCustomContext: noop,
});

export const useGetProductInsightsDataContext = () => {
  const productInsightsDataContext = React.useContext(ProductInsightsDataContext);
  return productInsightsDataContext;
};

export const useGetProductInsightsData = (pageProps?: any) => {
  const [data, setData] = React.useState<Omit<ProductInsightsDataContextVal, 'getCustomContext' | 'setCustomContext'>>(
    {} as ProductInsightsDataContextVal,
  );
  const customContextRef = React.useRef<Record<string, any>>({});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const getCustomContext = () => {
    return customContextRef?.current || {};
  };
  const setCustomContext = (context: Record<string, any>) => {
    customContextRef.current = {
      ...(customContextRef?.current || {}),
      ...context,
    };
  };
  const withProductInsightsDataContext = React.useCallback(
    PageComponent => {
      return (
        <ProductInsightsDataContext.Provider value={{ ...data, getCustomContext, setCustomContext }}>
          <PageComponent {...(pageProps || {})} />
        </ProductInsightsDataContext.Provider>
      );
    },
    [data, pageProps],
  );
  React.useEffect(() => {
    // 默认先获取用增维度数据
    Promise.all([getProductAnalysisBizList()]).then(([bizDataRes]) => {
      setData({
        bizData: bizDataRes || {},
      });
    });
  }, []);

  return {
    withProductInsightsDataContext,
  };
};
