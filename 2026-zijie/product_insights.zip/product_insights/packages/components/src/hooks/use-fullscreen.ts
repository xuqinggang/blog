import { useEffect, useRef, useState } from 'react';

export const useFullscreen = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFullScreen, setIsFullScreen] = useState(false);

  useEffect(() => {
    function onFullScreenChange() {
      setIsFullScreen(document.fullscreenElement === containerRef.current);
    }

    document.addEventListener('fullscreenchange', onFullScreenChange);
    document.addEventListener('webkitfullscreenchange', onFullScreenChange); // Safari
    document.addEventListener('mozfullscreenchange', onFullScreenChange); // Firefox
    document.addEventListener('MSFullscreenChange', onFullScreenChange); // IE/Edge（旧）
    return () => {
      document.removeEventListener('fullscreenchange', onFullScreenChange);
      document.removeEventListener('webkitfullscreenchange', onFullScreenChange); // Safari
      document.removeEventListener('mozfullscreenchange', onFullScreenChange); // Firefox
      document.removeEventListener('MSFullscreenChange', onFullScreenChange); // IE/Edge（旧）
    };
  }, []);

  const handleFullScreen = (active?: boolean) => {
    if (active !== undefined) {
      if (active && !isFullScreen) {
        containerRef.current?.requestFullscreen();
      } else if (!active && isFullScreen) {
        document.exitFullscreen();
      }
      return;
    }
    if (containerRef.current) {
      if (isFullScreen) {
        document.exitFullscreen();
      } else {
        containerRef.current?.requestFullscreen();
      }
    }
  };

  return {
    containerRef,
    isFullScreen,
    handleFullScreen,
  };
};
