/* eslint-disable @typescript-eslint/no-non-null-assertion */
import React from 'react';
import { debounce } from 'lodash-es';

import { Divider, Select } from '@ecom/auxo';
import type { IStepsProps } from '@ecom/auxo/es/components/select/SPSearch';

import cx from './index.module.scss';

export type ServiceParam = {
  [k: string]: any;

  page: number;
  searchVal: string;
  pageSize: number;
};
export type Service<T> = (param: ServiceParam) => Promise<T[]>;
export type Options<T> = {
  /** 字段的 Label 值，如果是 string 则会当作 key 从 record 中取对应的 value */
  label?: keyof T | ((record: T, ind: number) => React.ReactNode);
  /** 字段的 Value 值，如果是 string 则会当作 key 从 record 中取对应的 value */
  value?: keyof T | ((record: T, ind: number) => any);
  /** 字段的 Key 值，如果是 string 则会当作 key 从 record 中取对应的 value */
  dataKey: keyof T | ((record: T, ind: number) => string);
  /** 如果为 true，则不会自动触发请求，需要手动调用 submit() */
  manual?: boolean;
  /** 搜索框 onchange debounce，默认 0 */
  searchDebounce?: number;
  /** 「加载更多」触发阈值（像素），默认 128px（4 个 select option 的高度） */
  loadMoreThreshold?: number;
  /** 默认 20 */
  pageSize?: number;
  /** 接管 footer 渲染 */
  footer?: React.ReactNode;
  /** 当搜索时，如果返回 false 则不会主动触发 fetch */
  onSearch?: (val: string) => void | boolean;
  /** 当翻页（加载更多）时，如果返回 false 则不会主动触发 fetch */
  onPaginate?: (page: number, size: number) => void | boolean;
};
export type Results<T> = {
  dataSource: any;
  /** 透传给 Select.SPSearch */
  spSearchProps: IStepsProps<any>;
  /** 接口 loading 中 */
  loading: boolean;
  /** 没有更多了 */
  noMore: boolean;
  /** 可触发 fetch，val 可以是 Record 任意值 */
  submit: (val?: Record<string, any>, force?: boolean) => void;
  /** 可触发 fetch，清空所有缓存 */
  reset: () => void;
  /** 请求一次，传入的 params 不会存到缓存内 */
  fetchData: (extraParams?: Record<string, any>) => Promise<Array<T> | undefined>;
};

const LOAD_MORE_ITEM = Symbol('load more');

export default function useAuxoSearchSelect<T>(service: Service<T>, options: Options<T>): Results<T> {
  const [dataSource, setDataSource] = React.useState<T[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [noMore, setNoMore] = React.useState(false);
  const {
    footer = null,
    manual = false,
    label,
    value,
    dataKey,
    searchDebounce = 0,
    loadMoreThreshold = 128,
    pageSize = 20,
    onSearch,
    onPaginate = () => true,
  } = options;

  const DEFAULT_FETCH_PARAM = React.useRef<ServiceParam>({
    page: 1,
    searchVal: '',
    pageSize,
  });

  const _fetchParamRef = React.useRef<ServiceParam>(Object.assign({}, DEFAULT_FETCH_PARAM.current));
  const _loadingRef = React.useRef(false);
  const _fetchingVersion = React.useRef(Date.now());

  const fetchData = React.useCallback(
    async (extraParams: Record<string, any> = {}): Promise<Array<T> | undefined> => {
      const version = Date.now();
      _fetchingVersion.current = version;

      try {
        _loadingRef.current = true;
        setLoading(true);

        const data = await service(Object.assign({}, _fetchParamRef.current, extraParams));

        if (_fetchingVersion.current !== version) return;

        // 加载来的数据 = pageSize，说明可能下面还有
        if (data.length === _fetchParamRef.current.pageSize) {
          // 将 load more 提示作为一个 item
          data.push(LOAD_MORE_ITEM as any);
          setNoMore(false);
        } else {
          setNoMore(true);
        }

        if (_fetchParamRef.current.page !== 1) {
          // 注意移除上一次的 load more
          setDataSource(prev => prev.slice(0, -1).concat(data));
        } else {
          setDataSource(data);
        }

        return data;
      } catch (err) {
      } finally {
        _loadingRef.current = false;
        setLoading(false);
      }

      return;
    },
    [service],
  );

  const dispatchSearch = React.useCallback(
    (val: Partial<ServiceParam>, force = false) => {
      Object.assign(_fetchParamRef.current, val);
      (force || !manual) && fetchData();
    },
    [fetchData, manual],
  );

  const dropdownRender = React.useCallback(
    (menu: React.ReactElement) => {
      return (
        <div>
          {menu}
          {footer && (
            <React.Fragment>
              <Divider className={cx.divider} />
              <footer className={cx.footer}>{footer}</footer>
            </React.Fragment>
          )}
        </div>
      );
    },
    [footer],
  );

  const handleOnSearch = React.useCallback(
    debounce((searchStr: string) => {
      if (typeof onSearch !== 'function' || onSearch(searchStr) !== false) {
        // 搜索的时候，page 需要重置
        dispatchSearch({ searchVal: searchStr, page: 1 }, true);
      }
    }, searchDebounce),
    [onSearch, dispatchSearch],
  );

  const spSearchChildren = React.useMemo(
    () => (
      <React.Fragment>
        {dataSource.map((it, index) => {
          if (it === LOAD_MORE_ITEM) {
            return (
              <Select.Option className={cx['disabled-item']} key="LOAD_MORE_ITEM" value="LOAD_MORE_ITEM" disabled>
                加载中...
              </Select.Option>
            );
          }

          const itLabel = typeof label === 'function' ? label(it, index) : it[label!] || 'label';
          const itValue = typeof value === 'function' ? value(it, index) : it[value!] || 'value';
          const itKey: any = typeof dataKey === 'function' ? dataKey(it, index) : it[dataKey];

          return (
            <Select.Option key={itKey} value={itValue} record={it}>
              {itLabel}
            </Select.Option>
          );
        })}
      </React.Fragment>
    ),
    [dataSource, label, value, dataKey],
  );

  const onPopupScroll = React.useCallback(
    (ev: React.UIEvent<HTMLDivElement, UIEvent>) => {
      if (_loadingRef.current || noMore) return;

      const { scrollTop, scrollHeight, clientHeight } = ev.target as HTMLDivElement;

      if (scrollHeight - scrollTop - clientHeight < loadMoreThreshold) {
        const nextPage = _fetchParamRef.current.page + 1;

        if (onPaginate(nextPage, _fetchParamRef.current.pageSize) !== false) {
          dispatchSearch({ page: _fetchParamRef.current.page + 1 }, true);
        }
      }
    },
    [noMore, loadMoreThreshold, onPaginate, dispatchSearch],
  );

  const spSearchProps = React.useMemo<IStepsProps<any>>(
    () => ({
      loading,
      children: spSearchChildren,
      filterOption: false,
      onSearch: handleOnSearch,
      onPopupScroll: onPopupScroll,
      dropdownRender,
    }),
    [loading, spSearchChildren, onPopupScroll, dropdownRender, handleOnSearch],
  );

  const submit = React.useCallback(
    (val: Record<string, any> = {}, force = false) => {
      dispatchSearch(val, force);
    },
    [dispatchSearch],
  );

  const reset = React.useCallback(() => {
    _fetchParamRef.current = Object.assign({}, DEFAULT_FETCH_PARAM.current);
    setDataSource([]);
    !manual && fetchData();
  }, [fetchData, manual]);

  React.useEffect(() => {
    !manual && fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    dataSource,
    spSearchProps,
    loading,
    noMore,
    submit,
    reset,
    fetchData,
  };
}
