import React, { useMemo } from 'react';
import cls from 'classnames';
import { compact } from 'lodash-es';

import { GetDimensionListData } from '~/api/product/namespaces/dimensions';
import DimTags, { DimTag } from '~/dim-tags';
import { AnalysisFilter } from '~/filter-form/types';
import { AnalysisFilterGroupName } from '~/form_filters';

type FieldsData = Pick<AnalysisFilter, AnalysisFilterGroupName>;

export interface DimTagsRenderProps {
  className?: string;
  style?: React.CSSProperties;
  values?: FieldsData;
  suffix?: React.ReactElement;
  title: string;
  dimensionData: GetDimensionListData;
  pure?: boolean;
}

export const DimTagsRender: React.FC<DimTagsRenderProps> = ({
  className,
  values,
  suffix,
  title,
  dimensionData,
  pure,
}) => {
  /** 所有可用的维度 */
  const allDims = useMemo(() => {
    const { product_dimensions, user_dimensions, order_dimensions, place_dimensions } = dimensionData || {};
    return [product_dimensions, user_dimensions, order_dimensions, place_dimensions].flat();
  }, [dimensionData]);

  const {
    product_dimensions: dims = [],
    user_dimensions: userDims,
    order_dimensions: orderDims,
    place_dimensions: placeDims,
  } = values || {};

  const selectedDims = [...(dims || []), ...(userDims || []), ...(orderDims || []), ...(placeDims || [])];
  const showDims: DimTag[] = compact(
    selectedDims.map(dim => {
      const { id, selected_operator, selected_option, selected_values } = dim;
      const targetDim = allDims?.find(d => d?.id === id);
      const bakSelectedOption = targetDim?.values?.filter(
        item =>
          selected_values?.includes(item.code as any) ||
          (selected_values as any)?.find((tItem: any) => tItem.code === item.code || tItem === item.code),
      );

      if (targetDim) {
        const data: DimTag = {
          selectedOperator: selected_operator,
          selectedValues: selected_option?.length
            ? selected_option
            : bakSelectedOption?.length
            ? bakSelectedOption
            : selected_values?.map?.(code => ({ code: code as string, name: code as string })) || [],
          showName: targetDim.show_name,
        };

        return data;
      }
      return null;
    }),
  );

  return (
    <DimTags
      data={showDims}
      className={cls('bg-[#F8F9FA] border-none', className)}
      title={title ?? '筛选条件'}
      suffix={suffix || undefined}
      split=" | "
      type={'ghost'}
      pure={pure}
    />
  );
};

export default DimTagsRender;
