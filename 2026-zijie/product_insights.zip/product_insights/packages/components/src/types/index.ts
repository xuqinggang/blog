import { AttributionCommonBaseStruct } from '~/api/product/namespaces/attribution';
import { RuleValueType } from '~/RuleSelect';

export type AttributionFilter = Partial<
  Omit<
    AttributionCommonBaseStruct,
    'biz_type' | 'group_attrs' | 'threshold_attrs' | 'threshold_expr' | 'need_trend' | 'dimensions'
  >
> & {
  recent_date?: number;
  dimensions?: RuleValueType[];
};

export type RecursivePartial<T> =
  // 函数保持原样
  T extends (...args: any[]) => any
    ? T
    : // 普通数组 -> 递归处理元素
    T extends Array<infer U>
    ? Array<RecursivePartial<U>>
    : // 只读数组 / 元组 -> 递归处理元素并保持 readonly
    T extends ReadonlyArray<infer U>
    ? ReadonlyArray<RecursivePartial<U>>
    : // 普通对象 -> 对每个属性递归变为可选
    T extends object
    ? { [K in keyof T]?: RecursivePartial<T[K]> }
    : // 基本类型（string/number/...）直接保留
      T;
