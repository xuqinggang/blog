import React, { memo, useCallback, useEffect, useMemo, useState } from 'react';
import { debounce, intersection, isEqual, sortBy } from 'lodash-es';

import { Button, Input, LabelWrapper, Modal, Space } from '@ecom/auxo';

import { getMultiDimList } from '../filter-form/utils/get-multi-dim-list';

import { GetDimensionListData } from '~/api/product/namespaces/dimensions';
import { DIM_GROUPS } from '~/constant';
import DimCheckGroup from '~/DimCheckGroup';
import { DimensionType } from '~/filter-form/types';

export type DimCheckedValue = Record<DimensionType, string[]>;

interface DimModalProps {
  dimensionKey: DimensionType;
  visible: boolean;
  initialValue?: DimCheckedValue;
  disabledDimList?: string[];
  dimensionData?: GetDimensionListData | null;
  onCancel?: () => void;
  onOK?: (value: DimCheckedValue) => void;
}

export const DimModal = memo(
  ({ visible, initialValue, disabledDimList, onOK, onCancel, dimensionKey, dimensionData }: DimModalProps) => {
    const [selectDim, setSelectDim] = useState({} as DimCheckedValue);
    const [keyword, setKeyword] = useState('');
    const dimGroupList = useMemo(
      () => getMultiDimList(dimensionData, undefined, undefined, undefined, keyword),
      [dimensionData, keyword],
    );

    const title = dimensionKey
      ? `添加筛选维度（${DIM_GROUPS.filter(({ key }) => key === dimensionKey)[0]?.name}）`
      : `添加筛选维度`;

    const { selectNum, total } = useMemo(() => {
      let _selectNum = 0;
      let _total = 0;
      DIM_GROUPS.filter(item => item?.key === dimensionKey).forEach(({ key }) => {
        _selectNum += selectDim[key]?.length ?? 0;
        _total += dimensionData?.[key]?.length ?? 0;
      });
      return { selectNum: _selectNum, total: _total };
    }, [dimensionData, dimensionKey, selectDim]);

    const handleReset = useCallback(() => {
      setSelectDim(prev => {
        const dimList = prev[dimensionKey];
        if (!dimList) {
          return prev;
        }

        const curr = { ...prev };
        const mix = intersection(dimList, disabledDimList ?? []);
        if (!mix?.length) {
          delete curr[dimensionKey];
        } else {
          curr[dimensionKey] = mix;
        }

        return curr;
      });
    }, [dimensionKey, disabledDimList]);

    const debounceSearch = debounce((e: React.ChangeEvent<HTMLInputElement>) => {
      setKeyword(e.target.value);
    }, 500);

    // 关闭弹窗，重置搜索关键词
    useEffect(() => {
      !visible && setKeyword('');
    }, [visible]);

    useEffect(() => {
      visible && initialValue && setSelectDim(initialValue);
    }, [visible, initialValue]);

    return (
      <Modal
        width={750}
        visible={visible}
        title={title}
        onCancel={onCancel}
        destroyOnClose
        footer={
          <Space>
            <div className="flex gap-4 mr-2">
              <span>
                已选：{selectNum}/{total}
              </span>
              <Button
                type="link"
                disabled={isEqual(sortBy(selectDim[dimensionKey] ?? []), sortBy(disabledDimList ?? []))}
                onClick={handleReset}
              >
                重置选择
              </Button>
            </div>
            <Button type="primary" onClick={() => onOK?.(selectDim)}>
              确认
            </Button>
            <Button onClick={() => onCancel?.()}>取消</Button>
          </Space>
        }
      >
        {/* 商品维度支持搜索 */}
        {dimensionKey === 'product_dimensions' && (
          <LabelWrapper label="搜索维度" className="mb-4">
            <Input placeholder="输入维度关键字进行搜索" onChange={debounceSearch} allowClear />
          </LabelWrapper>
        )}
        <DimCheckGroup
          dimension={dimensionKey}
          disabledDimList={disabledDimList}
          displayDimensionGroup={false}
          dimGroup={dimGroupList}
          value={selectDim}
          onChange={(checkedValue, key) =>
            setSelectDim(pre => (key ? { ...pre, [key]: checkedValue as string[] } : pre))
          }
        />
      </Modal>
    );
  },
);
