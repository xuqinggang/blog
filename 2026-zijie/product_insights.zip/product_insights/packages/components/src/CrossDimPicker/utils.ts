import { DimensionInfo, GetDimensionListData } from '~/api/product/namespaces/dimensions';
import { DimensionType } from '~/filter-form/types';

export function getMultiDims(
  dimensionData?: GetDimensionListData | null,
): Partial<Record<DimensionType, DimensionInfo[]>> | null {
  if (!dimensionData) {
    return null;
  }

  const { user_dimensions, product_dimensions, place_dimensions, order_dimensions } = dimensionData;
  return {
    user_dimensions: user_dimensions?.filter(i => i.is_multi_dim),
    product_dimensions: product_dimensions?.filter(i => i.is_multi_dim),
    place_dimensions: place_dimensions?.filter(i => i.is_multi_dim),
    order_dimensions: order_dimensions?.filter(i => i.is_multi_dim),
  };
}
