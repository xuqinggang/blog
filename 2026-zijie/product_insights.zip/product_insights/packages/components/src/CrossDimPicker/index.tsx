import { CSSProperties, ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { map } from 'lodash-es';

import { Input, LabelWrapper, Space, Tag, Tooltip } from '@ecom/auxo';

import { productClient } from '~/api';
import {
  BizType,
  DimensionInfo,
  SelectedDimensionInfo,
  SelectedMultiDimensionInfo,
} from '~/api/product/namespaces/dimensions';
import { CrossDimPickDrawer, CrossDimPickDrawerProps } from '~/CrossDimPickDrawer';
import { CrossDimStaticPickDrawer } from '~/CrossDimStaticPickDrawer';
import { DimItem } from '~/DimCheckGroup';
import { DimensionType } from '~/filter-form/types';
import {
  transformGroupAttrs2Filter,
  transformGroupAttrs2Server,
  updateGroupAttrs,
} from '~/filter-form/utils/transform';

import { getMultiDims } from './utils';

export interface SimpleDimInfo {
  label: string;
  value: string | Array<string | number>;
}

export interface CrossDimPickerItemProps {
  dim: SimpleDimInfo;
  disabled?: boolean;
  style?: CSSProperties;
}

export const formatTooltipTitle = (value: Array<string | number>): ReactNode => {
  const titleArr: Array<string> = [];
  let prev: Array<string | number> = [];
  value.forEach((item, index) => {
    prev.push(`${item};`);
    if (!((index + 1) % 3)) {
      titleArr.push(prev.join(''));

      prev = [];
    }
  });

  titleArr.push(prev.join(''));

  return (
    <div>
      {titleArr.map(item => {
        return <div key={item}>{item}</div>;
      })}
    </div>
  );
};

const getSimpleDims = (groupAttrs?: DimItem[]) =>
  groupAttrs?.map<SimpleDimInfo>(i => ({
    label: i.label,
    value: map(i.selected_enums, 'label') as string[],
  })) ?? [];

export function CrossDimPickerItem(props: CrossDimPickerItemProps) {
  const { dim, disabled, style } = props;

  const children = (
    <LabelWrapper className="flex-1" style={{ maxWidth: 240, ...style }} label={dim.label} key={dim.label}>
      <Input
        disabled={disabled}
        style={{ textOverflow: 'ellipsis' }}
        value={(Array.isArray(dim.value) ? dim.value.join(';') : dim.value) || '全部'}
      />
    </LabelWrapper>
  );

  if ((Array.isArray(dim.value) && !dim.value.length) || !dim.value) {
    return children;
  }

  return (
    <Tooltip overlayClassName="max-w-md" title={Array.isArray(dim.value) ? formatTooltipTitle(dim.value) : dim.value}>
      {children}
    </Tooltip>
  );
}

export interface CrossDimPickerProps
  extends Pick<CrossDimPickDrawerProps, 'triggerClassName' | 'disabled' | 'min' | 'max' | 'minEnum' | 'maxEnum'> {
  mode?: 'static' | 'single' | 'multi';
  className?: string; // 类名
  style?: React.CSSProperties; // 样式
  overlayClassName?: string; // 容器类名
  crossNode?: ReactNode; // 交叉节点
  groupAttrs?: SelectedMultiDimensionInfo[]; // 多维分析维度（受控）
  defaultGroupAttrs?: SelectedMultiDimensionInfo[]; // 默认的多维分析维度
  showDimPicker?: boolean; // 是否展示维度选择器
  multiDims?: Partial<Record<DimensionType, DimensionInfo[]>> | null; // 多维分析可选维度
  bizType?: BizType; // 业务类型
  selectedDimensions?: SelectedDimensionInfo[]; // 已选维度
  onChange?: (value?: SelectedMultiDimensionInfo[], groupAttrs?: DimItem[]) => void; // 多维分析维度变化回调
  /** 未选择占位 */ placeholder?: React.ReactNode;
  extraNode?: React.ReactNode; // 额外节点
  /** 在static模式下，需要使用这个函数获取每一层可用的维度 */
  getList?: (idx: number) => DimItem[] | undefined;
}

const defaultCross = (
  <Tag category="medium" style={{ whiteSpace: 'nowrap', marginRight: 'unset' }}>
    交叉
  </Tag>
);

export const CrossDimPicker: React.FC<CrossDimPickerProps> = ({
  crossNode = defaultCross,
  className,
  overlayClassName,
  style,
  disabled = false,
  groupAttrs: propsGroupAttrs,
  defaultGroupAttrs,
  showDimPicker = false,
  multiDims: propsMultiDims,
  bizType = BizType.GrowthProductStrategy,
  onChange,
  placeholder,
  extraNode,
  mode = 'multi',
  getList,
  ...rest
}) => {
  const { selectedDimensions } = rest;
  const [dims, setDims] = useState<DimItem[]>(transformGroupAttrs2Filter(defaultGroupAttrs));
  const [multiDims, setMultiDims] = useState<Partial<Record<DimensionType, DimensionInfo[]>> | null>();
  const [loading, setLoading] = useState(false);
  const simpleDims = useMemo<SimpleDimInfo[]>(() => getSimpleDims(dims), [dims]);

  const handleVisibleChange = useCallback(
    async (visible: boolean) => {
      if (!visible || multiDims) {
        return;
      }

      try {
        setLoading(true);

        const { data } = await productClient.GetDimensionList({
          biz_type: bizType,
        });

        setMultiDims(getMultiDims(data));
      } catch (e) {
        console.error('');
      } finally {
        setLoading(false);
      }
    },
    [bizType, multiDims],
  );

  useEffect(() => {
    // 如果存在已经筛选的维度，下钻维度需要受约束
    const dims = transformGroupAttrs2Filter(propsGroupAttrs);
    const { groupAttrs: _dims } = updateGroupAttrs(dims, selectedDimensions);
    setDims(_dims);
  }, [propsGroupAttrs, selectedDimensions]);

  useEffect(() => {
    setMultiDims(propsMultiDims);
  }, [propsMultiDims]);

  return (
    <Space className={overlayClassName} size={8}>
      <div className={`hack-cls-1 flex gap-2 items-center w-max ${className}`} style={style}>
        {simpleDims.length
          ? simpleDims.map((dim, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <CrossDimPickerItem disabled={disabled} dim={dim} />
                {idx !== dims.length - 1 ? crossNode : null}
              </div>
            ))
          : placeholder || null}
        {showDimPicker &&
          (mode === 'static' ? (
            <CrossDimStaticPickDrawer
              loading={loading}
              disabled={disabled}
              value={dims}
              multiDimDimensions={multiDims}
              onVisibleChange={handleVisibleChange}
              onOk={v => {
                setDims(v);
                onChange?.(transformGroupAttrs2Server(v), v);
              }}
              getList={getList}
              {...rest}
            />
          ) : (
            <CrossDimPickDrawer
              loading={loading}
              disabled={disabled}
              value={dims}
              multiDimDimensions={multiDims}
              onVisibleChange={handleVisibleChange}
              onOk={v => {
                setDims(v);
                onChange?.(transformGroupAttrs2Server(v), v);
              }}
              {...rest}
            />
          ))}
        {extraNode}
      </div>
    </Space>
  );
};

export default CrossDimPicker;
