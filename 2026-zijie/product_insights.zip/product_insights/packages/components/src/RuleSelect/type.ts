import { ReactNode } from 'react';

import { EnumOption, EnumValue } from '@ecom/auxo-pro-form';

import { OperatorType } from '~/api/product/namespaces/base';
import { EnumElement, DateRule, DateRuleType } from '~/api/product/namespaces/dimensions';
import { DimensionType } from '~/filter-form/types';

import { OperatorTypeEnum, SelectType, SelectTypeMap } from './constants';

export type RuleSelectedOption = EnumOption & EnumElement;

export interface RuleValueType {
  id?: string; // 维度id
  name?: string; // 维度名称
  selected_operator?: OperatorType;
  selected_values?: EnumValue[];
  op_type?: SelectType;
  selected_option?: Array<RuleSelectedOption>;
  dim_type?: DimensionType;
  date_rule?: DateRule;
}

export type RuleEnum = { label?: string; value: string | number };

export interface RuleOption<T extends keyof SelectTypeMap = any> {
  label?: string;
  value: string | number;
  type: T;
  operatorType?: OperatorTypeEnum | false;
  operators?: Array<{ label?: string; value: number }>;
  enums?: EnumOption[];
  valueProps?: SelectTypeMap[T];
  dimension_group?: string;
  dimension_group_order?: number | string;
}

export interface RuleSelectProps<T extends SelectType = SelectType> {
  className?: string;
  prefixSelectClassName?: string;
  style?: React.CSSProperties;
  disabled?: boolean | Array<'rule' | 'op' | 'value'>;
  value?: RuleValueType;
  onChange?: (v: RuleSelectProps<T>['value']) => void;
  options: RuleOption<T>[];
  allowClear?: boolean;
  extra?: {
    prefix?: ReactNode;
    suffix?: ReactNode;
    operator?: ReactNode;
    hiddenPrefixSelect?: boolean;
    desc?: ReactNode;
    dateRuleType?: DateRuleType;
  };
}
