import React, { CSSProperties, memo, useEffect, useMemo, useState } from 'react';
import cls from 'classnames';
import { differenceBy } from 'lodash-es';

import { DatePicker, Select } from '@ecom/auxo';
import { RemoteSelectProps } from '@ecom/auxo-pro-form';

import { DateRuleType } from '~/api/product/namespaces/dimensions';
import { OP_ONLY_IN_DIMS } from '~/constant';

import {
  NoOpTypes,
  OnlyInOperatorOptions,
  OperatorMap,
  OperatorTypeEnum,
  SelectComponentMap,
  SelectType,
} from './constants';
import { RuleOption, RuleSelectProps, RuleValueType } from './type';

import './index.scss';
import dayjs from 'dayjs';

const getDefaultOperator = <T extends SelectType>(rule?: RuleOption<T>) => {
  if (!rule) return undefined;
  const { operatorType, operators } = rule;
  if (operators) return operators?.[0]?.value;
  else return OperatorMap[operatorType || OperatorTypeEnum.INCLUDE]?.[0]?.value;
};

export const RuleSelect = memo(
  <T extends SelectType>({
    value,
    options = [],
    onChange,
    extra = {},
    disabled = false,
    className,
    prefixSelectClassName,
    allowClear,
    style = {},
  }: RuleSelectProps<T>) => {
    const { prefix = null, suffix = null, operator = null, hiddenPrefixSelect = false, dateRuleType } = extra;
    const [innerValue, setInnerValue] = useState<RuleSelectProps<T>['value']>(value ?? {});
    const { id, selected_operator, selected_values, date_rule } = innerValue ?? {};

    const selectRule = useMemo(() => {
      return options.find(o => o.value === innerValue?.id);
    }, [innerValue?.id, options]);

    const { type, operatorType, enums, valueProps } = selectRule ?? {};

    const {
      ValueComp,
      valueFrom,
      valueTo,
      compProps = {},
    } = useMemo(
      () => (type && SelectComponentMap[type] ? SelectComponentMap[type] : SelectComponentMap[SelectType.MultiSelect]),
      [type],
    );

    const showOperator = !NoOpTypes.includes(type ?? SelectType.MultiSelect) && operatorType !== false && !operator;
    const operatoOnlyIn = Boolean(OP_ONLY_IN_DIMS.find(v => v.id === id));

    const valueCompProps = useMemo(() => {
      const allProps: Record<string, any> = { ...compProps, ...valueProps, enums };

      // 针对需要服务端搜索类型组件进行enums的重写
      if (
        type === SelectType.RemoteMultiSelect ||
        type === SelectType.RemoteSingleSelect ||
        type === SelectType.BasicInfoSearchInput ||
        type === SelectType.BasicInfoSearchSingleInput
      ) {
        delete allProps.enums;
        const { defaultEnums } = allProps as RemoteSelectProps;

        // PS: defaultEnums只在组件初始化时候有用，后续更新无用，由于筛选器获取defaultEnums是异步的，所以这里只能通过改变enums实现
        if (defaultEnums && Array.isArray(defaultEnums)) {
          allProps.service = (async (params, ...props) => {
            const res = await (valueProps as RuleOption<SelectType.RemoteMultiSelect>['valueProps'])?.service(
              params,
              ...props,
            );

            const filteredRep = differenceBy(res, defaultEnums, 'value') || []; // 数组去重
            const tempRes = params.page === 1 ? [...defaultEnums, ...(filteredRep ?? [])] : filteredRep ?? [];
            console.log('xxxxxenums.service', tempRes, defaultEnums);
            return res;
          }) as RemoteSelectProps['service'];
        }
      }

      return allProps;
    }, [compProps, enums, type, valueProps]);

    const itemDisabled = useMemo(() => {
      const isStatic = type === SelectType.StaticNoInput;

      const isArrayDisabled = Array.isArray(disabled);
      if (isArrayDisabled)
        return {
          rule: disabled.includes('rule'),
          op: disabled.includes('op'),
          value: isStatic ? true : disabled.includes('value'),
        };
      else return { rule: disabled, op: disabled, value: isStatic ? true : disabled };
    }, [disabled, type]);

    const handleChange = (v: RuleValueType) => {
      onChange ? onChange(v) : setInnerValue(v);
    };

    const handleRuleChange = (rule: RuleOption<T>) => {
      if (allowClear) {
        handleChange({ id: null } as any);
      }

      if (!rule.value) return;
      handleChange({
        id: String(rule.value),
        name: rule.label,
        selected_operator: getDefaultOperator(rule),
      });
    };

    const handleDateRuleChange = (v?: any) => {
      if (dateRuleType === DateRuleType.AbsoluteDateRange && v?.length === 2) {
        handleChange({
          ...innerValue,
          date_rule: {
            /** 日期规则类型 */
            type: dateRuleType,
            /** 指标开始时间 */
            start_date: dayjs(v[0]).format('YYYY-MM-DD'),
            /** 指标结束时间 */
            end_date: dayjs(v[1]).format('YYYY-MM-DD'),
          },
        });
      }
      if (dateRuleType === DateRuleType.RelativeDateRange && v !== undefined) {
        handleChange({
          ...innerValue,
          date_rule: {
            /** 日期规则类型 */
            type: dateRuleType,
            /** 指标开始时间 */
            day: v,
          },
        });
      }
    };

    const handleOperatorChange = (v?: string | number) => {
      v !== undefined && handleChange({ ...innerValue, selected_operator: Number(v) });
    };

    const handleValueChange = (
      v?: Array<string | number> | string | number,
      op?: Array<{ title: string; value: number | string }> | { title: string; value: number | string },
    ) => {
      const finalV = valueFrom?.(v) ?? v;
      const finalOp = (op ? valueFrom?.(op) ?? op : undefined)?.map((i: { title: string }) => ({
        ...i,
        label: i.title,
      }));
      const changedV = {
        ...innerValue,
        op_type: selectRule?.type,
        selected_operator: innerValue?.selected_operator || getDefaultOperator(selectRule),
        selected_values: finalV as string[],
        selected_option: finalOp,
      };

      handleChange(changedV);
    };

    useEffect(() => {
      setInnerValue(value);
    }, [value]);

    // TODO: 先暂时注释掉，感觉不需要这段逻辑
    // useUpdateEffect(() => {
    //   if (!enums?.length) {
    //     return;
    //   }

    //   const timer = setTimeout(() => {
    //     const allEnumValue = enums.map(e => e.value);
    //     const validValue = selected_values?.filter(item => allEnumValue?.includes(item));
    //     const validOp = selected_option?.filter(item => allEnumValue?.includes(item.value));
    //     validValue && handleValueChange(validValue as any, validOp);
    //   });

    //   return () => {
    //     clearTimeout(timer);
    //   };
    // }, [enums?.length]);

    console.log('dateRuleType === DateRuleType.AbsoluteDateRange', dateRuleType === DateRuleType.AbsoluteDateRange);
    const renderDateRule = () => {
      if (dateRuleType === DateRuleType.AbsoluteDateRange) {
        return (
          <DatePicker.RangePicker
            style={{ width: 220, flexShrink: 0 } as CSSProperties}
            format="YYYY-MM-DD"
            disabled={itemDisabled.rule}
            value={
              date_rule?.start_date && date_rule?.end_date
                ? [dayjs(date_rule.start_date), dayjs(date_rule.end_date)]
                : undefined
            }
            onChange={(v: any) => handleDateRuleChange(v)}
          />
        );
      }
      if (dateRuleType === DateRuleType.RelativeDateRange) {
        return (
          <Select
            style={{ width: 90, flexShrink: 0 } as CSSProperties}
            disabled={itemDisabled.rule}
            value={date_rule?.day}
            placeholder="请选择近多少天"
            onChange={(v: any) => handleDateRuleChange(v)}
            options={[
              { value: 1, label: '近1天' },
              { value: 3, label: '近3天' },
              { value: 7, label: '近7天' },
              { value: 14, label: '近14天' },
            ]}
          />
        );
      }
      return null;
    };

    return (
      <>
        <div
          className={cls('flex flex-1 max-w-[1176px] gap-[10px] items-center whitespace-nowrap', className)}
          style={style}
        >
          {prefix}
          {renderDateRule()}
          {hiddenPrefixSelect ? null : (
            <Select
              showSearch
              className={cls('rule-select__prefix-a', prefixSelectClassName)}
              disabled={itemDisabled.rule}
              value={id}
              placeholder="请选择"
              onChange={(_, option) => handleRuleChange?.(option as RuleOption<T>)}
              allowClear={allowClear}
              options={options}
              filterOption={(input, option) => String(option?.label).toLowerCase().indexOf(input.toLowerCase()) >= 0}
            />
          )}
          {showOperator ? (
            <Select
              disabled={itemDisabled.op}
              style={{ width: 120 } as CSSProperties}
              placeholder="请选择"
              value={selected_operator}
              defaultValue={selectRule && getDefaultOperator(selectRule)}
              onChange={v => handleOperatorChange(v as string | number)}
              options={
                operatoOnlyIn
                  ? OnlyInOperatorOptions
                  : OperatorMap[(operatorType as OperatorTypeEnum) ?? OperatorTypeEnum.INCLUDE] ?? []
              }
            />
          ) : (
            operator
          )}
          <ValueComp
            {...valueCompProps}
            key={id} // PS: 加上key，强制组件重新渲染，否则会出现RemoteSelect组件无法重新执行service的问题
            style={
              { flex: 1, minWidth: 180, maxWidth: showOperator ? 800 : 930, width: 'fit-content' } as CSSProperties
            }
            wrapperStyle={{ flex: 1 }}
            allowClear={allowClear}
            disabled={itemDisabled.value}
            value={(valueTo ? valueTo(selected_values) : selected_values) ?? []}
            onChange={handleValueChange}
          />
          {suffix}
        </div>
        {extra.desc}
      </>
    );
  },
);
