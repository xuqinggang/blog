import { FC, ForwardRefExoticComponent } from 'react';
import { flatten } from 'lodash-es';

import { Icon, InputNumber as AuxoInputNumber, InputNumberProps } from '@ecom/auxo';
import { EnumSelect, EnumSelectProps, RemoteSelect, RemoteSelectProps } from '@ecom/auxo-pro-form';

import { OperatorType } from '~/api/product/namespaces/base';
import Manually, { ManuallyProps } from '~/Manually';

export const enum SelectType {
  MultiSelect = 'multi_select',
  SingleSelect = 'single_select',
  AmountRangeInput = 'amount_range_input',
  NumberRangeInput = 'number_range_input',
  RatioRangeInput = 'ratio_range_input',
  InputNumber = 'input_number',
  RemoteMultiSelect = 'remote_multi_select',
  RemoteSingleSelect = 'remote_single_select',
  BoolSelect = 'bool_single_select',
  TextArrayInput = 'text_array_input',
  BasicInfoSearchInput = 'basic_info_search_input',
  BasicInfoSearchSingleInput = 'basic_info_search_single_input',
  StaticNoInput = '__static_no_input',
}

export interface SelectTypeMap {
  [SelectType.MultiSelect]: EnumSelectProps;
  [SelectType.SingleSelect]: EnumSelectProps;
  [SelectType.AmountRangeInput]: InputNumberProps;
  [SelectType.NumberRangeInput]: InputNumberProps;
  [SelectType.RatioRangeInput]: InputNumberProps;
  [SelectType.InputNumber]: InputNumberProps;
  [SelectType.RemoteMultiSelect]: RemoteSelectProps;
  [SelectType.RemoteSingleSelect]: RemoteSelectProps;
  [SelectType.BoolSelect]: EnumSelectProps;
  [SelectType.TextArrayInput]: ManuallyProps;
  [SelectType.BasicInfoSearchInput]: RemoteSelectProps;
  [SelectType.BasicInfoSearchSingleInput]: RemoteSelectProps;
  [SelectType.StaticNoInput]: EnumSelectProps;
}

export const SelectComponentMap: Record<
  SelectType,
  {
    ValueComp: FC<any> | ForwardRefExoticComponent<any>;
    compProps?: SelectTypeMap[SelectType];
    valueFrom?: (v?: any) => any;
    valueTo?: (v?: any) => any;
  }
> = {
  [SelectType.InputNumber]: { ValueComp: AuxoInputNumber },
  [SelectType.NumberRangeInput]: {
    ValueComp: AuxoInputNumber.Group,
    valueFrom: (v?: number[]) => v?.map(i => (i !== undefined ? String(i) : '')),
  },
  [SelectType.RatioRangeInput]: {
    ValueComp: AuxoInputNumber.Group,
    compProps: { unit: '%' },
    valueFrom: (v?: number[]) => v?.map(i => (i !== undefined ? String(i) : '')),
  },
  [SelectType.AmountRangeInput]: {
    ValueComp: AuxoInputNumber.Group,
    compProps: { prefix: '￥' },
    valueFrom: (v?: number[]) => v?.map(i => (i !== undefined ? String(i) : '')),
  },
  [SelectType.TextArrayInput]: {
    ValueComp: Manually,
    compProps: { maxLength: 10000, showPreview: false, buttonProps: { style: { flexShrink: 0 } }, name: 'ID' },
  },

  [SelectType.MultiSelect]: {
    ValueComp: EnumSelect,
    compProps: {
      multiple: true,
      maxTagCount: 'responsive',
    },
  },
  [SelectType.StaticNoInput]: {
    ValueComp: EnumSelect,
    compProps: {
      multiple: true,
      maxTagCount: 'responsive',
    },
  },
  [SelectType.RemoteMultiSelect]: {
    ValueComp: RemoteSelect,
    compProps: {
      multiple: true,
      maxTagCount: 'responsive',
      // maxTagCount: 6,
    },
  },
  [SelectType.RemoteSingleSelect]: {
    ValueComp: RemoteSelect,
    valueFrom: (v?: string | number) => (v === undefined ? v : [v]),
    valueTo: (v?: (string | number)[]) => v?.[0],
    compProps: { multiple: false, maxTagCount: 'responsive' },
  },
  [SelectType.BasicInfoSearchInput]: {
    ValueComp: RemoteSelect,
    compProps: {
      multiple: true,
      maxTagCount: 'responsive',
      placeholder: '请输入关键字进行搜索',
      suffixIcon: <Icon.SearchIcon />,
    },
  },
  [SelectType.BasicInfoSearchSingleInput]: {
    ValueComp: RemoteSelect,
    valueFrom: (v?: string | number) => (v === undefined ? v : [v]),
    valueTo: (v?: (string | number)[]) => v?.[0],
    compProps: {
      multiple: false,
      maxTagCount: 'responsive',
      placeholder: '请输入关键字进行搜索',
      suffixIcon: <Icon.SearchIcon />,
    },
  },

  [SelectType.SingleSelect]: {
    ValueComp: EnumSelect,
    valueFrom: (v?: string | number) => (v === undefined ? v : [v]),
    valueTo: (v?: (string | number)[]) => v?.[0],
  },
  [SelectType.BoolSelect]: {
    ValueComp: EnumSelect,
    valueFrom: (v?: string | number) => (v === undefined ? v : [v]),
    valueTo: (v?: (string | number)[]) => v?.[0],
  },
};

export const NoOpTypes = [
  SelectType.AmountRangeInput,
  SelectType.NumberRangeInput,
  SelectType.RatioRangeInput,
  SelectType.TextArrayInput,
  SelectType.BoolSelect,
];

export const enum OperatorTypeEnum {
  INCLUDE = 'include',
  COMPARE = 'compare',
}

export const OnlyInOperatorOptions = [{ label: '包含', value: OperatorType.IN }];

export const OperatorMap = {
  [OperatorTypeEnum.INCLUDE]: [
    { label: '包含', value: OperatorType.IN },
    { label: '不包含', value: OperatorType.NOT_IN },
  ],
  [OperatorTypeEnum.COMPARE]: [
    { label: '>=', value: OperatorType.GREATER_EQUAL_THAN },
    { label: '>', value: OperatorType.GREATER_THAN },
    { label: '<=', value: OperatorType.LESS_EQUAL_THAN },
    { label: '<', value: OperatorType.LESS_THAN },
  ],
};

export const OperatorList = flatten(Object.values(OperatorMap));
