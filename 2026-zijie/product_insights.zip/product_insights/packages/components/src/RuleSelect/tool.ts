import { SelectType } from './constants';

/** 判断是否是有效的 select 类型 */
export function isSelectType(value: string): value is keyof typeof SelectType {
  // @ts-ignore 忽略检查
  return Object.values(SelectType).includes(value as keyof typeof SelectType);
}
