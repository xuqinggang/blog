/* eslint-disable @typescript-eslint/no-unused-vars */
interface EditorKitOp {
  insert: string | { id: string };
  attributes?: {
    [key: string]: any;
  };
}

interface EditorKitZone {
  ops: EditorKitOp[];
  zoneId: string;
  zoneType: string;
}

export interface EditorKitData {
  [key: string]: EditorKitZone;
}

interface Handler {
  (op: EditorKitOp, context: ConversionContext): string;
}

interface ConversionContext {
  zoneMap: Map<string, EditorKitZone>;
  currentLineAttributes: { [key: string]: any };
}

const handlers: { [key: string]: Handler } = {
  lineMarker: (_op, _context) => '',
  codeBlock: (op, context) => {
    if (op.attributes?.type === 'codeblock') {
      const language = op.attributes.language || '';
      let markdown = `\`\`\`${language}\n`;
      if (op.attributes.zoneId) {
        const codeZone = context.zoneMap.get(op.attributes.zoneId);
        if (codeZone && codeZone.ops) {
          for (const codeOp of codeZone.ops) {
            if (typeof codeOp.insert === 'string') {
              markdown += codeOp.insert;
            }
          }
        }
      }
      return `${markdown}\n\`\`\`\n`;
    }
    return '';
  },
  heading: (op, _context) => {
    if (op.attributes?.heading) {
      const level = parseInt(op.attributes?.heading.slice(1));
      return `${'#'.repeat(level)} `;
    }
    return '';
  },
  list: (op, _context) => {
    if (op.attributes?.list) {
      const listType = op.attributes?.list;
      if (listType.startsWith('bullet')) {
        return `- ${op.insert}`;
      }
      if (listType.startsWith('number')) {
        return `1. ${op.insert}`;
      }
      if (listType === 'check1') {
        return `- [ ] ${op.insert}`;
      }
    }
    return '';
  },
  blockquote: (op, _context) => {
    if (op.attributes?.blockquote) {
      return `> ${op.insert}`;
    }
    return '';
  },

  horizontalLine: (op, _context) => {
    if (op.attributes?.['horizontal-line']) {
      return '---\n\n';
    }
    return '';
  },
  image: (op, _context) => {
    if (op.attributes?.image === 'true') {
      const src = op.attributes.src || '';
      return `![image](${src})\n\n`;
    }
    return '';
  },
  table: (op, context) => {
    if (op.attributes?.aceTable) {
      const tableIds = op.attributes.aceTable.split(' ');
      const rowZoneId = tableIds[0];
      const colZoneId = tableIds[1];

      const rowZone = context.zoneMap.get(rowZoneId);
      const colZone = context.zoneMap.get(colZoneId);

      if (rowZone && colZone) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return `${buildMarkdownTable(rowZone, colZone, context.zoneMap)}\n\n`;
      }
    }
    return '';
  },
  inlineStyles: (op, _context) => {
    let text = typeof op.insert === 'string' ? op.insert : '';
    if (op.attributes?.bold) {
      text = `**${text}**`;
    }
    if (op.attributes?.italic) {
      text = `*${text}*`;
    }
    if (op.attributes?.strikethrough) {
      text = `~~${text}~~`;
    }
    if (op.attributes?.underline) {
      text = `__${text}__`;
    }
    if (op.attributes?.hyperlink) {
      const link = JSON.parse(op.attributes.hyperlink);
      text = `[${text}](${link.href})`;
    }
    return text === '\n' ? '\n\n' : text || '';
  },
};

export function convertToMarkdown(editorKitData: EditorKitData): string {
  const mainZone = editorKitData['0'];
  const zoneMap = new Map(Object.entries(editorKitData));

  if (!mainZone || !mainZone.ops) {
    return '';
  }

  let markdown = '';
  const context: ConversionContext = {
    zoneMap,
    currentLineAttributes: {},
  };

  for (const op of mainZone.ops) {
    // 检查是否是新行标记
    const isNewLine = op.attributes?.lmkr === '1' && op.insert === '*';
    if (isNewLine) {
      context.currentLineAttributes = { ...op.attributes };
      markdown += '\n';
      // 不要 continue，继续处理其他属性
    }

    let handled = false;
    for (const handler of Object.values(handlers)) {
      const result = handler({ ...op, insert: isNewLine ? '' : op.insert }, context);
      if (result) {
        markdown += result;
        handled = true;
        break;
      }
    }

    // 如果没有处理器处理该操作，且不是新行标记，则直接插入
    if (!handled && typeof op.insert === 'string') {
      // 仅在 op.insert 不是 '*' 时插入
      if (!isNewLine) {
        markdown += op.insert;
      }
    }
  }

  return markdown.trim();
}

function buildMarkdownTable(
  rowZone: EditorKitZone,
  colZone: EditorKitZone,
  zoneMap: Map<string, EditorKitZone>,
): string {
  let table = '';
  const rows = rowZone.ops.map(op => (typeof op.insert === 'string' ? op.insert : op.insert.id));
  const cols = colZone.ops.map(op => (typeof op.insert === 'string' ? op.insert : op.insert.id));

  // 第一行作为表头
  const headerRowId = rows.shift();
  if (headerRowId) {
    let headerRow = '|';
    for (const colId of cols) {
      const cellZoneId = `x${headerRowId}x${colId}`;
      const cellZone = zoneMap.get(cellZoneId);
      if (cellZone && cellZone.ops.length > 0) {
        const cellContent = convertToMarkdown({ '0': cellZone }).replace(/\n+/g, '<br>');
        headerRow += ` ${cellContent} |`;
      } else {
        headerRow += '  |';
      }
    }
    table += `${headerRow}\n`;
    table += `|${cols.map(() => '---').join(' | ')} |\n`;
  }

  for (const rowId of rows) {
    let row = '|';
    for (const colId of cols) {
      const cellZoneId = `x${rowId}x${colId}`;
      const cellZone = zoneMap.get(cellZoneId);
      if (cellZone && cellZone.ops.length > 0) {
        const cellContent = convertToMarkdown({ '0': cellZone }).replace(/\n+/g, '<br>');
        row += ` ${cellContent} |`;
      } else {
        row += '  |';
      }
    }
    table += `${row}\n`;
  }

  return table;
}
