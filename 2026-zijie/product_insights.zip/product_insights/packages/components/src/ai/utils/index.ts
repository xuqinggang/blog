import MarkdownIt from 'markdown-it';
import MarkdownItBr from 'markdown-it-br';

import { message } from '@ecom/auxo';

import { CommonMessage, Message } from '../common/message';

export enum AIChatType {
  Supervisor,
  Normal,
}

export function parseMarkdownTable(mdTable: string): string[][] {
  // 按行拆分，过滤空行
  const lines = mdTable
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);

  if (lines.length < 2) {
    throw new Error('表格至少需要两行（表头和分隔符行）');
  }

  // 验证第二行是否为分隔符行（形如 | --- | --- | 或类似）
  const separatorLine = lines[1];
  // eslint-disable-next-line @ecom/security-unsafe-regex
  if (!/^(\|? *:?-+:? *\|)+ *:?-+:? *\|?$/.test(separatorLine)) {
    throw new Error('第二行不是有效的表格分隔符行');
  }

  // 处理每一行，拆分单元格
  const rows = lines.map(line => {
    // 去除行首尾的竖线，避免空单元格
    let trimmedLine = line;
    if (trimmedLine.startsWith('|')) trimmedLine = trimmedLine.slice(1);
    if (trimmedLine.endsWith('|')) trimmedLine = trimmedLine.slice(0, -1);

    // 按 | 拆分单元格，去除每个单元格前后空白
    const cells = trimmedLine.split('|').map(cell => cell.trim());
    return cells;
  });

  // 返回除去分隔符行的二维数组
  return [rows[0], ...rows.slice(2)];
}

export function getCopyContent(msg: Message) {
  const { content, tasks, cot } = msg;
  let copyContent = '';
  // tasks优先于content
  if (tasks.length > 0) {
    tasks.forEach(({ content: taskContent, cot: taskCot, name: taskName }) => {
      const _content = taskCot ? `<thinking>${taskCot}</thinking>\n\n${taskContent}` : taskContent;
      copyContent += `## ${taskName}\n\n${_content}\n\n`;
    });
  } else {
    copyContent += cot ? `<thinking>${cot}</thinking>\n\n${content}` : content;
  }
  return copyContent;
}

// 聚焦到输入框
export function focusInput() {
  const timer = setTimeout(() => {
    const input = document.getElementById('ai-chat-input');
    input?.focus();
    clearTimeout(timer);
  }, 100);
}

// CSV转Markdown表格
export function convertCsvToMarkdown(csvData: string[][]): string {
  if (!csvData.length) return '';

  // 1. 分离表头和数据行（第一行为表头，剩余为数据）
  const headers = csvData[0]; // 表头行（CSV 第一行）
  const dataRows = csvData.slice(1); // 数据行（CSV 剩余行）

  // 2. 处理表头行（转义特殊字符）
  const processedHeaders = headers.map(header => {
    let h = (header || '').toString();
    h = h.replace(/\|/g, '\\|').replace(/\n/g, ''); // 转义 | 和换行
    return h;
  });

  // 3. 生成表头行和分隔行
  const headerRow = `| ${processedHeaders.join(' | ')} |`; // 表头行：| 列1 | 列2 | ... |
  const separatorRow = `| ${processedHeaders.map(() => '---').join(' | ')} |`; // 分隔行：| --- | --- | ... |

  // 4. 处理数据行（转义特殊字符）
  const processedDataRows = dataRows.map(row => {
    const cells = row.map(cell => {
      let c = (cell || '').toString();
      c = c.replace(/\|/g, '\\|').replace(/\n/g, ''); // 转义 | 和换行
      return c;
    });
    return `| ${cells.join(' | ')} |`; // 数据行：| 单元格1 | 单元格2 | ... |
  });

  // 5. 拼接完整 Markdown 表格
  const markdownTable = [headerRow, separatorRow, ...processedDataRows].join('\n');
  return markdownTable;
}

export async function copyToClipboard(text: string) {
  try {
    const md = new MarkdownIt({ html: true, xhtmlOut: true, breaks: true, linkify: true });
    md.use(MarkdownItBr);
    const html = md.render(text);

    // 创建一个包含 HTML 和纯文本的 ClipboardItem
    const item = new ClipboardItem({
      'text/html': new Blob([html], { type: 'text/html' }),
      'text/plain': new Blob([text], { type: 'text/plain' }),
    });

    // 复制到剪贴板
    await navigator.clipboard.write([item]);
    message.success('复制成功');
  } catch (error) {
    console.error('复制失败:', error);
    message.error('复制失败');
  }
}

export interface SSEMsg {
  content: string;
  cot?: string;
}

export function handleSSEMsg(chunk: string, msg: SSEMsg) {
  try {
    const line = chunk.trim();
    const lines = line.split('\n');
    if (lines.length !== 2) {
      throw new Error(`SSE message format mismatch: ${line}`);
    }

    const [eventStr, dataStr] = lines;
    const event = eventStr?.replace('event: ', '')?.trim() || '';
    const _data = dataStr?.replace('data: ', '')?.trim() || '';

    if (!event || !_data) {
      throw new Error(`SSE message event or data is empty: ${line}`);
    }

    if (event === 'error' || event === 'gateway-error') {
      throw new Error(`SSE message error: event=${event}; data=${_data}`);
    } else if (event === 'finish') {
      // 完成事件处理
      return 'finish';
    }

    const json = JSON.parse(_data) as CommonMessage;
    const { content, reasoning_content } = json;

    // 拼接消息内容
    if (content) {
      msg.content += content;
    } else if (reasoning_content) {
      msg.cot += reasoning_content;
    }
  } catch (e) {
    console.error('🚨 Handle SSE message error，error=', (e as any).stack);
    return 'error';
  }
}
