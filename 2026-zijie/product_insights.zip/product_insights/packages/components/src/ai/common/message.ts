import { ReactNode } from 'react';
import { makeAutoObservable, observable, reaction } from 'mobx';
import { v4 as uuidv4 } from 'uuid';

export enum MessageRole {
  User = 'user',
  Assistant = 'assistant',
}

export enum MessageStatus {
  THINKING = 'thinking', // 思考中
  OUTPUTING = 'outputing', // 输出中
  ERROR = 'error', // 错误
  FINISHED = 'finished', // 完成
}

export enum TaskType {
  SUB = 'sub', // 子任务
  OUTPUT = 'output', // 输出
  THINKING = 'thinking', // 思考中
}

export interface TaskInfo {
  id: string;
  type: TaskType;
  name?: string;
  content?: string;
  cot?: string;
}

export type CommonMessage<T = any> = T & {
  content: string;
  status: MessageStatus;
};

export interface MessageExtraInfo {
  cot?: string;
  date?: Date;
  messageId?: string;
  tasks?: TaskInfo[];
  latestTaskId?: string;
  placeholder?: ReactNode | null;
  queryMsgId?: string;
  data?: string;
}

export class Message {
  content = ''; // 消息内容

  cot = ''; // 思维链

  role: MessageRole;

  status = MessageStatus.FINISHED;

  date = new Date();

  messageId = uuidv4();

  placeholder: ReactNode = null;

  tasks: TaskInfo[] = []; // 任务列表

  latestTaskId = ''; // 最新的taskId

  isLLM = false; // 是否是LLM消息

  queryMsgId = ''; // 关联的用户消息

  data = ''; // 关联的数据

  constructor(
    role: MessageRole,
    content = '',
    status: MessageStatus = MessageStatus.FINISHED,
    isLLM = false,
    extra?: MessageExtraInfo,
  ) {
    this.role = role;
    this.content = content;
    this.status = status;
    this.isLLM = isLLM;

    if (extra) {
      this.date = extra.date || this.date;
      this.messageId = extra.messageId || this.messageId;
      this.tasks = extra.tasks || this.tasks;
      this.latestTaskId = extra.latestTaskId || this.latestTaskId;
      this.placeholder = extra.placeholder || this.placeholder;
      this.cot = extra.cot || this.cot;
      this.queryMsgId = extra.queryMsgId || this.queryMsgId;
      this.data = extra.data || this.data;
    }
    makeAutoObservable(
      this,
      {
        messageId: false,
        placeholder: observable.ref,
        tasks: observable.deep,
      },
      { autoBind: true },
    );

    reaction(
      () => this.status,
      status => {
        if (status === MessageStatus.FINISHED || status === MessageStatus.ERROR) {
          this.latestTaskId = '';
        }
      },
    );
  }

  get formattedTime() {
    return `${String(this.date.getHours()).padStart(2, '0')}:${String(this.date.getMinutes()).padStart(
      2,
      '0',
    )}:${String(this.date.getSeconds()).padStart(2, '0')}`;
  }

  setPlaceholder(placeholder: ReactNode) {
    this.placeholder = placeholder;
  }

  updateContent(content: string) {
    this.content = content;
    this.status = MessageStatus.FINISHED;
  }

  createTask(type: TaskType, name = '', content = '', cot = '') {
    this.status = MessageStatus.OUTPUTING;
    const id = uuidv4();
    this.tasks.push({ id, type, name, content, cot });
    this.latestTaskId = id;
  }

  appendTaskCot(cot: string, id?: string) {
    const task = this.tasks.find(t => t.id === (id || this.latestTaskId));
    if (!task) {
      return;
    }
    this.status = MessageStatus.OUTPUTING;
    task.cot = (task.cot || '') + cot;
  }

  appendTaskContent(content: string, id?: string) {
    const task = this.tasks.find(t => t.id === (id || this.latestTaskId));
    if (!task) {
      return;
    }
    this.status = MessageStatus.OUTPUTING;
    task.content = (task.content || '') + content;
  }

  appendContent(content: string) {
    this.status = MessageStatus.OUTPUTING;
    this.content += content;
  }

  appendCot(cot: string) {
    this.status = MessageStatus.OUTPUTING;
    this.cot += cot;
  }

  updateStatus(status: MessageStatus) {
    this.status = status;
  }
}
