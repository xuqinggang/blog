import { FC, forwardRef } from 'react';
import classNames from 'classnames';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
import remarkGfm from 'remark-gfm';

import './index.less';

interface MarkdownRenderProps {
  content: string;
  className?: string;
  style?: React.CSSProperties;
  customComponents?: Record<string, FC<any>>;
}

export const MarkdownRender = forwardRef<HTMLDivElement, MarkdownRenderProps>((props, ref) => {
  const { content, className, style, customComponents } = props;
  return (
    <div style={style} className={classNames('markdown-render', className)} ref={ref}>
      <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeRaw]} components={customComponents}>
        {content}
      </ReactMarkdown>
    </div>
  );
});
