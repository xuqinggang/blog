/** 老版组件，即将废弃 */
import { memo } from 'react';
import classNames from 'classnames';
import Markdown, { MarkdownToJSX } from 'markdown-to-jsx';

import './index.less';

interface MarkdownRenderProps {
  content: string;
  overrides?: MarkdownToJSX.Overrides;
  className?: string;
  style?: React.CSSProperties;
}

export const MarkdownRender = memo((props: MarkdownRenderProps) => {
  const { content, overrides, className, style } = props;
  return (
    <Markdown className={classNames('markdown-render', className)} style={style} options={{ overrides }}>
      {content}
    </Markdown>
  );
});
