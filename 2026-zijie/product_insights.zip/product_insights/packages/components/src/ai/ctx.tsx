import React from 'react';

interface FeedbackInfo {
  feedback_type: 'good' | 'bad';
  session_id: string;
  message_id: string;
  ai_bot_query: string;
  message_content: string;
  feedback_reason?: string;
  feedback_content?: string;
}

export interface AIConclusionConfig {
  /** 上报AI反馈 */
  reportBotFeedback?: (info: FeedbackInfo) => void;
}

export const AIConclusionCtx = React.createContext<{ config: AIConclusionConfig }>({
  config: { reportBotFeedback: undefined },
});

export const useAIConclusionCtx = () => React.useContext(AIConclusionCtx);
