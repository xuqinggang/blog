import classNames from 'classnames';

import { Button, ButtonProps } from '@ecom/auxo';

import './index.less';

type IconButtonProps = ButtonProps & React.RefAttributes<HTMLElement>;

export function IconButton(props: IconButtonProps) {
  const { className, ...restProps } = props;
  return <Button {...restProps} type="link" className={classNames('icon-button', className)} />;
}
