import { ReactNode, useRef, useState } from 'react';
import { useSize } from 'ahooks';
import classNames from 'classnames';

import { Button, Icon, Spin, Tooltip } from '@ecom/auxo';

import AIPrefixIcon from '../assets/ai-prefix.svg';
import BadIcon from '../assets/bad.svg';
import BadActiveIcon from '../assets/bad-active.svg';
import CopyIcon from '../assets/copy.svg';
import GoodIcon from '../assets/good.svg';
import GoodActiveIcon from '../assets/good-active.svg';
import { useAIConclusionCtx } from '../ctx';
import { MarkdownRender } from '../markdown-render';
import { copyToClipboard } from '../utils';

import './index.less';

import { FeedbackType } from '~/api/product/namespaces/ai_analysis';
import { prettyWarn } from '~/utils';

export interface AIConclusionProps {
  loading: boolean;
  title: string;
  conclusion: string;
  extra?: ReactNode;
  className?: string;
  reset?: () => Promise<void>;
  heightLimit?: number;
}

export function AIConclusion(props: AIConclusionProps) {
  const { loading, title, conclusion, extra, className, reset, heightLimit = 400 } = props;
  const [feedbackType, setFeedbackType] = useState<FeedbackType>(); // 反馈类型
  const contentRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const { height = 0 } = useSize(contentRef) ?? {};
  const { reportBotFeedback } = useAIConclusionCtx().config;

  function handleFeedback(type: FeedbackType) {
    setFeedbackType(type);
    if (reportBotFeedback) {
      reportBotFeedback?.({
        feedback_type: type === FeedbackType.POSITIVE ? 'good' : 'bad',
        session_id: '',
        message_id: '',
        ai_bot_query: title,
        message_content: conclusion,
      });
    } else {
      prettyWarn('reportBotFeedback 未配置');
    }
  }

  return (
    <div
      className={classNames(
        'ai-conclusion',
        { 'ai-conclusion--collapsed': !open, 'ai-conclusion--show-more': height >= heightLimit },
        className,
      )}
    >
      <Spin indicator={<Icon.LoadingIcon />} spinning={loading}>
        <div className="flex items-center justify-between mb-[10px]">
          <div className="flex items-center gap-4">
            <div className="flex gap-1">
              <img src={AIPrefixIcon} alt="" />
              <span className="font-medium">{title}</span>
            </div>
            {extra}
          </div>
          <div className="flex items-center">
            {/* 重新解读 */}
            <Tooltip title="重新解读">
              <div
                className="ai-conclusion-operation"
                onClick={() => {
                  setFeedbackType(undefined);
                  reset?.();
                }}
              >
                <Icon.RefreshIcon />
              </div>
            </Tooltip>
            {/* 复制 */}
            <Tooltip title="复制">
              <div
                className="ai-conclusion-operation"
                onClick={() => {
                  copyToClipboard(conclusion);
                }}
              >
                <img src={CopyIcon} />
              </div>
            </Tooltip>
            {/* 效果好 */}
            {feedbackType !== FeedbackType.NEGATIVE && (
              <Tooltip title="效果好">
                <div
                  className="ai-conclusion-operation"
                  onClick={() => {
                    handleFeedback(FeedbackType.POSITIVE);
                  }}
                >
                  {feedbackType === FeedbackType.POSITIVE ? <img src={GoodActiveIcon} /> : <img src={GoodIcon} />}
                </div>
              </Tooltip>
            )}
            {/* 效果不好 */}
            {feedbackType !== FeedbackType.POSITIVE && (
              <Tooltip title="效果不好">
                <div
                  className="ai-conclusion-operation"
                  onClick={() => {
                    handleFeedback(FeedbackType.NEGATIVE);
                  }}
                >
                  {feedbackType === FeedbackType.NEGATIVE ? <img src={BadActiveIcon} /> : <img src={BadIcon} />}
                </div>
              </Tooltip>
            )}
          </div>
        </div>
        <MarkdownRender
          className="ai-conclusion-content"
          ref={contentRef}
          content={conclusion}
          style={!open && heightLimit ? { maxHeight: heightLimit } : undefined}
        />
      </Spin>
      <div className="mt-3 justify-center ai-conclusion-extend-btn">
        <Button
          type="link"
          rightIcon={<Icon type={open ? 'DirectionUpIcon' : 'DirectionDownIcon'} />}
          onClick={() => setOpen(pre => !pre)}
        >
          {open ? '收起' : '展开'}
        </Button>
      </div>
    </div>
  );
}
