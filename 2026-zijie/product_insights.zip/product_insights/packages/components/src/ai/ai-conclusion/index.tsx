import { useEffect, useRef, useState } from 'react';
import { isEmpty } from 'lodash-es';
import { observer } from 'mobx-react-lite';

import { AIConclusionModule, AIConclusionRequest } from '~/api/product/namespaces/ai_analysis';

import { AIConclusionConfig, AIConclusionCtx } from '../ctx';
import { handleSSEMsg, SSEMsg } from '../utils';

import { AIConclusion, AIConclusionProps } from './conclusion';

export interface AIConclusionWrapperProps<T> extends Pick<AIConclusionProps, 'title' | 'extra' | 'className'> {
  id: AIConclusionModule;
  req?: T;
  heightLimit?: number;
  domainPrefix?: string;
  config?: AIConclusionConfig;
}

export const AIConclusionWrapper = observer(<T,>(props: AIConclusionWrapperProps<T>) => {
  const { id, req, domainPrefix = '', config, ...rest } = props;
  const [conclusion, setConclusion] = useState('');
  const [loading, setLoading] = useState(false);
  const abortController = useRef(new AbortController());

  async function getConclusion() {
    if (!req) {
      return;
    }

    try {
      setLoading(true);
      const reqJson = JSON.stringify(req);
      const userInfo = window.GarfishBridge?.infoBridge?.getUserInfo();
      const request: AIConclusionRequest = {
        id,
        employee_id: userInfo?.employee_id,
        req_json: reqJson,
      };

      // 取消上一个请求
      abortController.current.abort();
      abortController.current = new AbortController();

      // AI 流式请求
      const response = await fetch(`${domainPrefix}/product_analysis/artificial_intelligence/conclusion_stream`, {
        method: 'POST',
        body: JSON.stringify(request),
        signal: abortController.current.signal,
      });
      setLoading(false);
      if (!response.ok) {
        throw new Error('SSE 请求失败');
      }

      // 解析 SSE 事件流
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = ''; // 存储未完整的消息
      // let event = ''; // 存储当前事件
      const msg: SSEMsg = {
        content: '',
      };

      // eslint-disable-next-line no-constant-condition
      outerLoop: while (true) {
        const { value, done } = (await reader?.read()) || {};
        if (done) {
          break;
        }

        // 将二进制数据解码为字符串
        buffer += decoder.decode(value, { stream: true });

        // 处理完整的 SSE 事件
        const parts = buffer.split('\n\n');
        buffer = parts.pop() || ''; // 保留最后一部分（可能是不完整的消息）

        for (const part of parts) {
          const result = handleSSEMsg(part, msg);
          setConclusion(msg.content);
          if (result === 'finish' || result === 'error') {
            // event = result;
            break outerLoop; // 跳出外层循环
          }
        }
      }

      // if (event === 'error') {
      //   message.error('AI 解读失败');
      // }
    } catch (e) {
      console.error('get conclusion error', e);
    }
  }

  // 筛选项变化时调用接口
  useEffect(() => {
    if (!req || isEmpty(req)) {
      return;
    }

    getConclusion();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [req]);

  return (
    <AIConclusionCtx.Provider value={{ config: config || {} }}>
      <AIConclusion {...rest} conclusion={conclusion} loading={loading} reset={getConclusion} />
    </AIConclusionCtx.Provider>
  );
});
