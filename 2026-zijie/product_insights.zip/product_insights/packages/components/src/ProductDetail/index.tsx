import { ReactNode } from 'react';

import { Button, ButtonProps } from '@ecom/auxo';

import { StoreShareableStateRequest, StoreShareableStateResponse } from '~/api/arctic';
import bridgeRequest from '~/api/bridge';
import { openProductDetailPage, Scope } from '~/utils/index';

const StoreShareableState = (
  req?: StoreShareableStateRequest,
  options?: { headers: any },
): Promise<StoreShareableStateResponse> => {
  const _req = req || {};
  const url = '/api/arctic_management/common/store_shareable_state';
  const method = 'POST';
  const data = { biz: _req.biz, modules: _req.modules, ttl: _req.ttl };
  return bridgeRequest.request({ url, method, data, ...options });
};
export interface ProductDetailProps extends Omit<ButtonProps, 'onClick' | 'name'> {
  name?: ReactNode;
  awaitClick?: boolean;

  onClick?: () => void;
  // 传参
  router: string;
  req_marshal: string;
  code?: string;

  // 商品范围：e.g：价格力AA分析-流量效果达标
  scope?: Scope;
  stopPropagation?: boolean;
}

/** 商品明细按钮 */
const ProductDetail = (props: ProductDetailProps): JSX.Element => {
  const {
    name = '查看商品明细',
    router,
    req_marshal,
    code,
    onClick,
    scope,
    awaitClick,
    stopPropagation,
    ...other
  } = props;

  const handleClick = async () => {
    if (awaitClick) {
      await onClick?.();
    } else {
      onClick?.();
    }
    const base_req = { router, req_marshal, code, referer_pathname: location.pathname };
    const { res_id } = await StoreShareableState({
      biz: 'growth_analysis',
      modules: {
        filter: {
          state: JSON.stringify(base_req),
        },
      },
    });
    openProductDetailPage({ base_req: { res_id }, scope });
  };

  return (
    <Button
      type="link"
      size={other.size ?? 'small'}
      onClick={e => {
        if (stopPropagation) {
          e.stopPropagation();
          e.preventDefault();
        }
        handleClick();
      }}
      {...other}
    >
      {name}
    </Button>
  );
};

export default ProductDetail;
