import { FC } from 'react';

import { IAreaChartSpec, ILineChartSpec, VChart } from '@visactor/react-vchart';
import { Datum } from '@visactor/vchart/esm/typings';

import { UnifiedData } from '~/api/product/namespaces/common_response';

export interface MiniLineChartProps {
  data: UnifiedData['key_value_list'];
  width?: number;
  height?: number;
  padding?: number;
}

export const MiniLineChart: FC<MiniLineChartProps> = ({ data, width, height, padding }) => {
  const commonSpec: IAreaChartSpec | ILineChartSpec = {
    type: 'area',
    xField: 'X',
    yField: 'Y',
    data: {
      values: data as Datum[],
    },
    line: { style: { curveType: 'monotone' } },
    padding,
  };

  return (
    <VChart
      width={width ?? 72}
      height={height ?? 40}
      spec={{
        ...commonSpec,
        tooltip: {
          visible: false,
        },
        padding: 0,
        axes: [
          {
            visible: false,
            orient: 'bottom', // 声明显示的位置
          },
          {
            visible: false,
            orient: 'left',
          },
        ],
        crosshair: {
          xField: {
            visible: false,
          },
          yField: {
            visible: false,
          },
        },
        point: {
          visible: false,
        },
      }}
    />
  );
};
