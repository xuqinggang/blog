import { ICartesianAxisSpec, IDimensionData, IDimensionInfo } from '@visactor/vchart';

export const commonXAxes: ICartesianAxisSpec = {
  type: 'band',
  orient: 'bottom',
  // maxHeight: '20%', // Limit maximum height to 20% of chart height
  sampling: false, // 只有sampling关闭时autoRotate才会生效
  label: {
    type: 'rich',
    visible: true,
    style: {
      maxLineWidth: 120,
    },
    // @ts-ignore global
    formatMethod: text => [
      {
        text: text,
        fontWeight: 'bold',
        fontSize: 12,
      },
    ],
    autoRotate: true, // 自动旋转
    autoRotateAngle: [0, -45], // 自动旋转的范围
  },
};

export function isIDimensionInfo(item: IDimensionInfo | IDimensionData): item is IDimensionInfo {
  return Boolean((item as IDimensionInfo).data);
}
