import { FC } from 'react';

import { IAreaChartSpec, ILineChartSpec, VChart } from '@visactor/react-vchart';
import { IDimensionInfo } from '@visactor/vchart';

import { UnifiedData } from '~/api/product/namespaces/common_response';
import { compactAmount } from '~/bubble-chart/utils';

import { commonXAxes } from '../common';

export interface UnifiedLineChartProps {
  data: UnifiedData['key_value_list'];
  width?: number;
  height?: number;
  padding?: number;
}

export const UnifiedLineChart: FC<UnifiedLineChartProps> = ({ data, width, height, padding }) => {
  const commonSpec: IAreaChartSpec | ILineChartSpec = {
    type: 'area',
    xField: 'X',
    yField: 'Y',
    data: {
      values: data,
    } as any,
    line: { style: { curveType: 'monotone' } },
    padding,
  };

  return (
    <VChart
      width={width ?? 600}
      height={height ?? 300}
      spec={{
        ...commonSpec,
        /** 坐标点设置 */
        point: {
          state: {
            dimension_hover: {
              visible: true,
              size: 10,
            },
          },
        },
        /** 坐标连接线配置 */
        // crosshair: showCrosshair
        //   ? {
        //       xField: {
        //         visible: true,
        //         line: {
        //           type: 'line',
        //           style: {
        //             lineWidth: 1,
        //             opacity: 1,
        //             stroke: '#898B8F',
        //             lineDash: [2, 2],
        //           },
        //         },
        //       },
        //     }
        //   : undefined,
        /** tooltip配置 */
        tooltip: {
          mark: {
            visible: false,
          },
          dimension: {
            content: value => {
              return value?.map(item => {
                return {
                  key: (item as IDimensionInfo)?.data?.[0]?.datum?.[0]?.target_display_name,
                  value: (item as IDimensionInfo)?.data?.[0]?.datum?.[0]?.display_Y,
                };
              });
            },
          },
        },
        /** 坐标轴配置 */
        axes: [
          commonXAxes,
          {
            orient: 'left',
            visible: true,
            label: {
              formatMethod: text => compactAmount(String(text)).join(''),
            },
          },
        ],
      }}
    />
  );
};
