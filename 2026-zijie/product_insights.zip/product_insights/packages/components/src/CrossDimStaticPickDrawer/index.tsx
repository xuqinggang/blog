import React, { ReactNode, useEffect, useMemo, useState } from 'react';
import { groupBy, map } from 'lodash-es';

import { Button, Drawer, DrawerProps, Form, Icon, Modal, Space, Spin, Tooltip } from '@ecom/auxo';
import { FormInstance } from '@ecom/auxo-pro-form';

import { RuleValueType, SelectType } from '../RuleSelect';

import { DimensionInfo, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import { MAX_SINGLE_DIMENSION_ENUM_COUNT, MIN_SINGLE_DIMENSION_ENUM_COUNT } from '~/constant';
import { DimItem } from '~/DimCheckGroup';
import { DimEnumFilter } from '~/DimEnumFilter';
import { DimensionType } from '~/filter-form/types';
import { errorDepend } from '~/filter-form/utils/compute';
import { getMultiDimList } from '~/filter-form/utils/get-multi-dim-list';
import { useFromProductIncubation } from '~/utils';

export interface CrossDimStaticPickDrawerProps extends Omit<DrawerProps, 'visible' | 'onOk'> {
  loading?: boolean;
  renderTrigger?: ({ onClick }: { onClick: () => void }) => ReactNode;

  minEnum?: number; // 最小可选的枚举值数量
  maxEnum?: number; // 最大可选的枚举值数量

  value?: DimItem[];
  form?: FormInstance;
  field?: string;
  disabled?: boolean;
  disabledDimList?: string[]; // 不可选中的维度
  multiDimDimensions?: Partial<Record<DimensionType, DimensionInfo[]>> | null;
  selectedDimensions?: (SelectedDimensionInfo | RuleValueType)[];
  onVisibleChange?: (visible: boolean) => void;
  onOk?: (value: Omit<DimItem, 'disabled'>[]) => void;
  /** 在static模式下，需要使用这个函数获取每一层可用的维度 */
  getList?: (idx: number) => DimItem[] | undefined;
}

export const CrossDimStaticPickDrawer: React.FC<CrossDimStaticPickDrawerProps> = ({
  renderTrigger,
  onVisibleChange,
  loading = false,
  title = '多维分析',
  multiDimDimensions,
  selectedDimensions,
  value,
  onOk,
  form,
  field,
  minEnum = MIN_SINGLE_DIMENSION_ENUM_COUNT,
  maxEnum = MAX_SINGLE_DIMENSION_ENUM_COUNT,
  disabledDimList,
  disabled = false,
  getList,
  ...otherProps
}) => {
  const [visible, setVisible] = useState(false);
  const [errorInfo, setErrorInfo] = useState('');
  const [selectDimList, setSelectDimList] = useState<DimItem[]>([]);
  const isFromProductIncubation = useFromProductIncubation();

  const dimGroup = useMemo(
    () => getMultiDimList(multiDimDimensions, selectedDimensions, selectDimList, maxEnum),
    [maxEnum, multiDimDimensions, selectDimList, selectedDimensions],
  );

  const dimGroupHideByProductIncubation = useMemo(() => {
    return dimGroup.map(item => {
      return {
        ...item,
        list: item.list?.filter(v => {
          if (!isFromProductIncubation) {
            return true;
          }
          return v.value !== '10291' && v.value !== '10292';
        }),
      };
    });
  }, [dimGroup, isFromProductIncubation]);

  const list = useMemo(
    () => dimGroupHideByProductIncubation.reduce<DimItem[]>((prev, curr) => prev.concat(curr.list ?? []), []),
    [dimGroupHideByProductIncubation],
  );

  const openDrawer = () => {
    setVisible(true);
  };

  const validateError = () => {
    const allError: string[] = [];
    const selectedValue = selectDimList.map<RuleValueType>(dim => ({
      id: String(dim.value),
      selected_values: map(dim.selected_enums, 'value'),
    }));

    selectDimList.forEach(({ selected_enums }) => {
      selected_enums?.forEach(op => {
        if (!op.depend_code) return;
        const error = errorDepend(op.depend_code, selectedValue as RuleValueType[]);
        const errorGroup = groupBy(error, 'id');
        const dependGroup = groupBy(op.depend_code, 'id');

        const hasError = Object.keys(errorGroup).some(
          k => errorGroup[k].length && errorGroup[k].length === dependGroup[k].length,
        );
        hasError && allError.push(String(op.label));
      }) ?? [];
    });

    const error = allError.length ? `选项 ${allError.join('、')} 存在冲突` : '';
    setErrorInfo(error);
    return error;
  };

  const onConfirm = () => {
    // TODO@ZOTILLE:
    // reportMultiDimensionClick();

    try {
      if (validateError()) {
        return;
      }

      const overLimitDims: string[] = [];
      const selected = selectDimList.map<DimItem>(dim => {
        const { selected_enums } = dim;
        const length = selected_enums?.length ?? 0;
        if (length < minEnum || length > maxEnum) {
          if (dim.show_type !== SelectType.StaticNoInput) {
            overLimitDims.push(`【${dim.label}】`);
          }
        }

        return {
          ...dim,
          enums: selected_enums,
        };
      });

      if (overLimitDims.length) {
        throw new Error(
          `您设置的维度${overLimitDims.join(
            '、',
          )}包含的枚举值过多/过少,请添加筛选条件后查看结果（单个维度最多筛选${maxEnum}个枚举值，最少筛选${minEnum}个枚举值)~`,
        );
      }

      onOk?.(selected);
      setVisible(false);
    } catch (error) {
      Modal.warning({
        width: 480,
        content: (error as { message: string })?.message,
        title: '枚举值过多',
        showCancel: false,
      });
    }
  };

  useEffect(() => {
    if (!visible) {
      return;
    }

    setSelectDimList(value ?? form?.pGetFieldValue(field || '') ?? []);
    // TODO@ZOTILLE:
    // reportMultiDimensionShow();
  }, [field, form, value, visible]);

  useEffect(() => {
    onVisibleChange?.(visible);
  }, [onVisibleChange, visible]);

  return (
    <>
      <Tooltip title="建议下钻的维度枚举值不超过30个">
        {renderTrigger ? (
          renderTrigger({ onClick: openDrawer })
        ) : (
          <Button disabled={disabled} type="dashed" icon={<Icon.SetUpIcon />} onClick={openDrawer}>
            设置维度
          </Button>
        )}
      </Tooltip>
      <Drawer
        visible={visible}
        title={title}
        width={800}
        onCancel={() => setVisible(false)}
        onOk={onConfirm}
        destroyOnClose
        {...otherProps}
      >
        <Spin spinning={loading}>
          {selectDimList.length ? (
            <>
              <Space size={8} style={{ marginBottom: 16 }}>
                <span className="font-medium">修改过滤条件</span>
              </Space>
              <Form>
                <Form.Item validateStatus={errorInfo ? 'error' : 'success'} help={errorInfo}>
                  <DimEnumFilter
                    value={selectDimList}
                    list={list}
                    showLogic
                    onChange={setSelectDimList}
                    // min={min}
                    getList={getList}
                    maxSelected={maxEnum}
                    isStatic
                  />
                </Form.Item>
              </Form>
            </>
          ) : null}
        </Spin>
      </Drawer>
    </>
  );
};
