import React from 'react';
import classNames from 'classnames';

import { Divider, Icon } from '@ecom/auxo';

import { DateRuleType, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';

import { AddItemBtn } from '../add-item-btn';
import RuleSelect, { RuleOption, RuleValueType } from '../RuleSelect';

export interface RuleSelectListProps {
  className?: string;
  value?: Array<RuleValueType>;
  list: RuleOption[];
  requiredDimInfo?: SelectedDimensionInfo[]; // 不能更改/删除的维度列表
  addButton?: React.ReactNode;
  onChange?: (v: RuleSelectListProps['value']) => void;
  onItemAdd?: (idx: number) => void;
  maxLength?: number;
  layout?: 'grid' | 'flex';
  enableRepeat?: boolean; // 是否支持重复选择
  dateRuleType?: DateRuleType;
  disabled?: boolean;
}

const RuleSelectList: React.FC<RuleSelectListProps> = ({
  requiredDimInfo = [],
  list = [],
  value = [],
  onChange,
  onItemAdd,
  addButton = '添加筛选维度',
  maxLength,
  className,
  layout = 'flex',
  enableRepeat = false,
  disabled: allDisabled = false,
  dateRuleType,
}) => {
  const handleItemChange = (v: RuleValueType, idx: number) => {
    const newValue = [...value];
    newValue[idx] = v;
    onChange?.(newValue);
  };

  const handleItemDelete = (idx: number) => {
    const newValue = [...value.slice(0, idx), ...value.slice(idx + 1)];
    onChange?.(newValue);
  };

  if (!value?.length) {
    return (
      <AddItemBtn
        btnNode={addButton}
        disabled={allDisabled}
        onItemAdd={() => (onItemAdd ? onItemAdd(value.length) : handleItemChange({}, value.length))}
      />
    );
  }

  return (
    <div
      className={classNames(layout === 'grid' ? 'grid grid-cols-2 gap-y-2 gap-x-6' : 'flex flex-col gap-2', className)}
    >
      {value.map((valueItem, idx) => {
        const requiredItem = requiredDimInfo.find(({ id }) => id === valueItem.id);
        const disabled = Boolean(requiredItem);
        const editable = requiredItem?.editable;
        const showBtn =
          idx === value.length - 1 && value.length < (maxLength ?? Infinity) && value.length < list.length;

        return (
          <div key={`${valueItem.id}-${idx}`} className="flex items-center gap-2">
            <RuleSelect
              className={layout === 'grid' ? (showBtn ? '!max-w-[calc(100%-139px)]' : '!max-w-[calc(100%-31px)]') : ''}
              value={valueItem}
              disabled={(disabled && !editable) || allDisabled}
              options={
                enableRepeat ? list : list.filter(i => i.value === valueItem.id || !value.some(j => j.id === i.value))
              }
              onChange={v => v && handleItemChange(v, idx)}
              extra={{
                dateRuleType,
              }}
            />
            <Divider type="vertical" style={{ height: 12, margin: 'unset' }} />
            <Icon.DeleteIcon
              disabled={disabled || allDisabled}
              onClick={() => {
                if (disabled) {
                  return;
                }

                handleItemDelete(idx);
              }}
              className={disabled ? 'cursor-not-allowed' : 'cursor-pointer'}
            />
            <AddItemBtn
              btnNode={addButton}
              disabled={allDisabled}
              className={classNames({
                hidden: !showBtn,
              })}
              onItemAdd={() => (onItemAdd ? onItemAdd(value.length) : handleItemChange({}, value.length))}
            />
          </div>
        );
      })}
    </div>
  );
};
export default RuleSelectList;

RuleSelectList.displayName = 'RuleSelectList';
