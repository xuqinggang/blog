export const CateTag = ({ cate }: { cate: string }) => {
  return (
    <div
      className=" shadow-sm text-[12px] color-[#69718C] px-1 rounded-[2px] leading-3 py-[1px] whitespace-nowrap"
      style={{
        boxShadow: `#69718C3D 0px 0px 0px 1px`,
      }}
    >
      {cate}
    </div>
  );
};
