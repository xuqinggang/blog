/* eslint-disable @typescript-eslint/naming-convention */
import React, { useMemo } from 'react';
import classNames from 'classnames';

import { Divider, Tooltip } from '@ecom/auxo';

import { CateTag } from './CateTag';

import styles from './index.module.scss';

import { CommonAnalysisRequest } from '~/api/product/namespaces/common_request';
import { ItemData } from '~/api/product/namespaces/common_response';
import { NumberDisplay } from '~/number_display';
import ProductDetail from '~/ProductDetail';
import { IconDoubt } from '~/pure-icons/doubt';

export interface QuadrantChartCardProps {
  className?: string;
  style?: React.CSSProperties;
  type?: 'origin' | 'warn' | 'alert';
  data: ItemData;
  baseParams: CommonAnalysisRequest;
  targetLimit?: number;
  operation?: React.ReactNode;
}

export const QuadrantChartCard: React.FC<QuadrantChartCardProps> = ({
  className,
  style,
  type = 'origin',
  data,
  baseParams = {},
  targetLimit = 2,
  operation = null,
}) => {
  const { target_list = [], extra_info = {} } = data;
  const { quadrant_name, main_category_name } = extra_info.quadrant_info || {};

  const indicators = useMemo(
    () =>
      target_list.map(item => ({
        title: item.display_name,
        tooltip: item.tips,
        displayValue: item.display_value,
        subValue: item.extra?.distribution_value || 0,
      })),

    [target_list],
  );

  const shareInfo = useMemo(() => {
    return {
      base_req: baseParams.base_req,
      compare_req: baseParams.compare_req,
      biz_extra_info: {
        ...(baseParams.biz_extra_info || {}),
        prod_review_params: {
          ...baseParams.biz_extra_info?.prod_review_params,
          prod_detail_params: {
            ...baseParams.biz_extra_info?.prod_review_params?.prod_detail_params,
            quadrant_query_param: data.extra_info?.quadrant_info?.quadrant_query_param,
          },
        },
      },
    };
  }, [baseParams, data.extra_info?.quadrant_info?.quadrant_query_param]);

  const indicatorElements = useMemo(() => {
    const showIndicators = indicators.slice(0, targetLimit);
    const elements = showIndicators.map(({ title, tooltip, displayValue, subValue }) => (
      <div key={title} className="flex flex-col items-start">
        <div className="text-[#565960] text-[12px] font-medium inline-flex items-center">
          {title}
          {tooltip ? (
            <Tooltip title={tooltip}>
              <IconDoubt className="ml-1 text-sm" />
            </Tooltip>
          ) : null}
        </div>
        <div className="flex-col items-baseline flex-nowrap">
          <div className={classNames('text-[24px] text-[#252931] leading-[32px] whitespace-nowrap ', styles.mainValue)}>
            {displayValue}
          </div>
          <div className={classNames('text-[16px] leading-[24px] text-[#898B8F]  whitespace-nowrap', styles.subValue)}>
            占货盘 <NumberDisplay value={subValue} format={{ ratio: '%' }} />
          </div>
        </div>
      </div>
    ));

    for (let i = elements.length - 1; i > 0; i--) {
      elements.splice(i, 0, <Divider key={`divider-${i}`} type="vertical" className="mx-6 h-[32px]" />);
    }
    return elements;
  }, [indicators, targetLimit]);

  const renderTags = () => {
    const tags = main_category_name?.slice(0, 3) || [];
    const otherTags = main_category_name?.slice(3) || [];

    return (
      <div className="flex gap-2 items-center">
        {tags.map(cate => (
          <CateTag key={cate} cate={cate} />
        ))}
        {otherTags.length > 0 ? (
          <Tooltip title={otherTags.join('、')}>
            <div>
              <CateTag key={`other-${otherTags.length}`} cate={`+${otherTags.length}个`} />
            </div>
          </Tooltip>
        ) : null}
      </div>
    );
  };

  return (
    <div
      className={classNames(
        styles.container,
        (styles as any)[type],
        'quadrant-chart-card',
        'w-full h-full',
        'flex flex-col',
        'overflow-hidden',
        className,
      )}
      style={{
        ...style,
      }}
    >
      <div className={styles.header}>
        <span className={styles.title}>{quadrant_name}</span>
        {/* <span className={styles.desc}>{'desc'}</span> */}
      </div>

      <div className="content p-3 w-full flex flex-col">
        <div className="indicators flex items-center">{indicatorElements}</div>
        <div className="cates pt-2 flex items-center overflow-hidden">
          <div className={classNames('text-gray-500 text-[12px] leading-4 whitespace-nowrap')}>主要类目：</div>
          {renderTags()}
        </div>
        <div className="action-group flex items-center gap-2 pt-3 mt-3 border-t-[#EEEFF0] border-t-[1px] border-dashed">
          <ProductDetail
            size="middle"
            name="商品明细"
            req_marshal={JSON.stringify(shareInfo)}
            router="/product_analysis/prod_review/analysis_item_data"
          />
          {operation}
        </div>
      </div>
    </div>
  );
};

export default QuadrantChartCard;
