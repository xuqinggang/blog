export interface QuadrantChartGroupProps {
  xLabels: string[];
  yLabels: string[];
  children: React.ReactNode[];
}

export const QuadrantChartGroup: React.FC<QuadrantChartGroupProps> = ({
  xLabels = [],
  yLabels = [],
  children = [],
}) => {
  return (
    <div className="container flex flex-col items-center relative">
      <div className="y-label text-[12px] mb-[14px]">{yLabels[1] ?? ''}</div>
      <div className="wrapper flex items-center w-full">
        <div className="x-label max-w-[60px] shrink-0 text-[12px] mr-2">{xLabels[0] ?? ''}</div>
        <div className="relative inner-wrapper grid grid-cols-2 grid-rows-2 gap-4 flex-1">
          <div className="absolute w-full h-0 border-t-[1px] border-solid border-[#b4d6f7] top-[50%] left-0" />
          <div className="absolute w-0 h-full border-l-[1px] border-solid border-[#b4d6f7] left-[50%] top-0" />
          {/* <div className="rounded-[999px] bg-[#b4d6f7] w-[12px] h-[12px] absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]" /> */}
          {/* 第一象限  */}
          <div className="col-start-2 row-start-1 flex items-center justify-center">{children[0]}</div>
          {/* 第二象限  */}
          <div className="col-start-1 row-start-1 flex items-center justify-center">{children[1]}</div>
          {/* 第三象限  */}
          <div className="col-start-1 row-start-2 flex items-center justify-center">{children[2]}</div>
          {/* 第四象限  */}
          <div className="col-start-2 row-start-2 flex items-center justify-center">{children[3]}</div>
        </div>
        <div className="x-label max-w-[60px] shrink-0 text-[12px] ml-2">{xLabels[1] ?? ''}</div>
      </div>
      <div className="y-label text-[12px] mt-[14px]">{yLabels[0] ?? ''}</div>
    </div>
  );
};
