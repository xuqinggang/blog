import { FC } from 'react';

import { Select } from '@ecom/auxo';

import { TargetType } from '~/api/product/namespaces/prod_review';

const mockData = [
  {
    label: '支付订单数',
    value: '1',
  },
  {
    label: '支付订单',
    value: '2',
  },
];
const TargetTypeNameMap = {
  [TargetType.Increase]: '增量',
  [TargetType.IncreaseRate]: '增幅',
  [TargetType.AbsoluteValue]: '绝对值',
};

interface AxisInputProps {
  value?: [string, string];
  onChange?: (value: [string, string]) => void;
  defaultValue?: [string, string];
}

export const AxisInput: FC<AxisInputProps> = ({ value = [], onChange }) => {
  const handleChange = (idx: number, val: string) => {
    const newVal = [...value];
    newVal[idx] = val;
    onChange?.(newVal as [string, string]);
  };
  return (
    <div className="flex items-center gap-2">
      <div className="w-[140px]">
        <Select value={value?.[0]} onChange={value => handleChange(0, value)}>
          {mockData.map(item => (
            <Select.Option value={item.value} key={item.value}>
              {item.label}
            </Select.Option>
          ))}
        </Select>
      </div>
      <div className="w-[80px]">
        <Select value={value?.[1]} onChange={value => handleChange(1, value)}>
          {Object.entries(TargetTypeNameMap).map(([key, value]) => (
            <Select.Option key={key} value={key}>
              {value}
            </Select.Option>
          ))}
        </Select>
      </div>
    </div>
  );
};

// export const Demo = () => {};
