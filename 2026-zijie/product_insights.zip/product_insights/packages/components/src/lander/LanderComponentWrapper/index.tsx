import { FC, ReactNode } from 'react';

import { Spin } from '@ecom/auxo';

import { ResizedPlaceholder } from '~/placeholder';

export interface LanderComponentWrapperProps {
  children: ReactNode;
  loading?: boolean;
  hasError?: boolean;
}

export const LanderComponentWrapper: FC<LanderComponentWrapperProps> = ({ children, loading, hasError }) => {
  return (
    <div className="w-full h-full flex justify-center items-center">
      <Spin className="w-full h-full spin" wrapperClassName="w-full h-full spin-wrapper" spinning={Boolean(loading)}>
        {hasError ? <ResizedPlaceholder /> : children}
      </Spin>
    </div>
  );
};

const PropsConfig = [
  {
    type: 'Union',
    title: '加载中',
    name: 'loading',
    defaultValue: false,
  },
  {
    type: 'Union',
    title: '是否出错',
    name: 'hasError',
    defaultValue: false,
  },
];

export const LanderComponentWrapperMeta = {
  props: PropsConfig,
};
