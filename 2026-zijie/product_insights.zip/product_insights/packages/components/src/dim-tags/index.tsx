import React, { ReactElement } from 'react';
import classNames from 'classnames';

import { Tooltip } from '@ecom/auxo';

import { OperatorType } from '~/api/product/namespaces/base';

export interface DimTag {
  selectedOperator?: OperatorType;
  selectedValues?: {
    name?: string;
    code?: string;
    type_value?: string[];
  }[];
  showName?: string;
}

export interface DimTagsProps {
  className?: string;
  style?: React.CSSProperties;
  data: DimTag[];
  title?: string;
  suffix?: ReactElement;
  split?: string;
  pure?: boolean;
  type?: 'ghost' | 'primary';
}

export const DimTags: React.FC<DimTagsProps> = ({
  className,
  style,
  data,
  title,
  suffix,
  split = ' ',
  type = 'ghost',
  pure,
}) => {
  const pureContent = (
    <div className="flex items-center gap-2 flex-wrap">
      {data.length ? (
        data.map(({ showName, selectedValues }) => {
          if (!selectedValues?.length) {
            return null;
          }
          const label = selectedValues
            ?.map(({ name, code, type_value }) => name || code || type_value?.join(split))
            .join(split);
          return (
            <Tooltip title={label} key={showName}>
              <div
                className={classNames(
                  'tag text-[12px] leading-4 rounded-[3px] flex shrink-0 items-center p-[1px] overflow-hidden',
                  {
                    'bg-[rgba(0,0,0,0.08)]': type === 'ghost',
                    'bg-[#8cbeef]': type === 'primary',
                  },
                )}
              >
                <div
                  className={classNames('text-[12px]', 'px-1 ', {
                    'text-white': type === 'primary',
                    'text-[#212533]': type === 'ghost',
                  })}
                >
                  {showName}
                </div>
                <div
                  className={classNames(
                    'px-2  bg-white text-[12px] rounded-[2px]',
                    'flex flex-shrink-0 flex-nowrap overflow-hidden',
                    'max-w-[320px]',
                  )}
                >
                  <span
                    className={classNames('w-full whitespace-nowrap overflow-hidden text-ellipsis', {
                      'text-[#212533]': type === 'ghost',
                    })}
                  >
                    {label}
                  </span>
                </div>
              </div>
            </Tooltip>
          );
        })
      ) : (
        <span className="text-[#898B8F] text-sm leading-4 shrink-0">无</span>
      )}
      {suffix ? <div className="ml-4">{suffix}</div> : null}
    </div>
  );

  if (pure) {
    return pureContent;
  }
  return (
    <div
      className={classNames(
        'w-full flex items-center border-[1px] border-[#EEEFF00]  rounded-[3px] px-[12px] overflow-hidden',
        className,
      )}
      style={style}
    >
      {title && <div className="text-[#898B8F] text-sm leading-4 shrink-0 h-[40px] py-[12px] mr-4">{title}</div>}
      <div className="tag-wrapper flex items-start gap-2 overflow-hidden py-[12px] flex-wrap">{pureContent}</div>
    </div>
  );
};

export default DimTags;
