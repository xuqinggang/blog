import { FC } from 'react';

import { Divider } from '@ecom/auxo';

const themes = ['blue', 'red', 'green', 'yellow', 'orange', 'purple'] as const;
type Theme = typeof themes[number];

interface CoreTargetData {
  groupName?: string;
  targets: {
    title: string;
    value: string;
    type?: 'aa' | 'bb' | 'aa_ratio' | 'ab_ratio';
  }[];
}

interface CoreTargetCardProps {
  theme?: Theme;
  title: string;
  dataList: CoreTargetData[];
}

const colorConfig: Record<Theme, string> = {
  blue: '199, 219, 250',
  green: '202, 245, 211',
  purple: '230, 216, 250',
  red: '250, 216, 216',
  yellow: '250, 250, 216',
  orange: '250, 234, 216',
};

export const CoreTargetCard: FC<CoreTargetCardProps> = ({ theme = 'blue', title, dataList }) => {
  if (!themes.includes(theme)) {
    theme = 'blue';
  }
  const color = colorConfig[theme];
  return (
    <div
      className="container p-2 border border-solid rounded-md"
      style={{ background: `rgba(${color}, 0.3)`, borderColor: `rgb(${color})` }}
    >
      <div className="title flex items-center">
        <div className="indicator w-2 h-2 rounded-r bg-gray-500 mr-2" />
        <div className="text font-bold">{title}</div>
      </div>
      <div className="wrapper bg-white rounded-md">
        {dataList
          .map(item => (
            <div key={item.groupName} className="group p-2">
              <div className="group-title text-gray-500 ">{item.groupName}</div>
              <div className="group-content">
                {item.targets.map(target => (
                  <div key={target.title} className="target flex justify-between items-center">
                    <div className="target-title">{target.title}</div>
                    <div className="target-value">{target.value}</div>
                  </div>
                ))}
              </div>
            </div>
          ))
          .map((item, idx) => [item, <Divider key={idx} />])
          .flat()}
      </div>
    </div>
  );
};

export default () => {
  return (
    <div style={{ width: 400 }}>
      <CoreTargetCard
        title="title"
        dataList={[
          {
            targets: [
              {
                title: '原始',
                value: '126万元',
              },
              {
                title: 'AA增量',
                value: '+7.5万元',
              },
              {
                title: 'AA增幅',
                value: '+7.3%',
              },
            ],
          },
        ]}
      />
    </div>
  );
};
