import { memo } from 'react';

import { UniqueIdentifier } from '@dnd-kit/core';
import { Icon, Tooltip } from '@ecom/auxo';

import { DragItem } from '../dnd/drag-item';
import { useDropContext } from '../dnd/drop-container';

import { TargetMetaInfo } from '~/api/product/namespaces/dimensions';
import DragIcon from '~/assets/svg/drag.svg';

export interface DragTargetItem extends TargetMetaInfo {
  id: UniqueIdentifier;
}

interface TargetItemProps {
  item: DragTargetItem;
  index: number;
  disabledDelete?: boolean;
  handleDelete: (index: number) => void;
}

export const TargetItem = memo((props: TargetItemProps) => {
  const { item, index, disabledDelete, handleDelete } = props;
  const { grabbing } = useDropContext();

  return (
    <DragItem
      item={item}
      className="py-[6px] px-2 border border-[#DCDEE1] rounded-[4px] w-[186px] h-[32px] box-border flex items-center justify-between bg-[#fff]"
    >
      {({ attributes, listeners }) => (
        <>
          <div className="flex flex-1 gap-1 items-center">
            <div {...attributes} {...listeners} className={grabbing ? 'cursor-grabbing' : 'cursor-grab'}>
              <DragIcon />
            </div>
            <div className="text-[#898B8F] flex-shrink-0">{index + 1}</div>
            <Tooltip.Auto title={item.display_name}>{item.display_name}</Tooltip.Auto>
          </div>
          <Icon.CloseIcon
            svgProps={{
              color: '#85878A',
            }}
            disabled={disabledDelete}
            onClick={() => {
              !disabledDelete && handleDelete(index);
            }}
            className={disabledDelete ? 'cursor-not-allowed' : 'cursor-pointer'}
          />
        </>
      )}
    </DragItem>
  );
});
