import { memo, ReactNode, useCallback, useMemo } from 'react';

import { DragMoveEvent } from '@dnd-kit/core';

import { DropContainer } from '../dnd/drop-container';

import { DragTargetItem, TargetItem } from './target-item';

import './index.scss';

import { TargetMetaInfo } from '~/api/product/namespaces/dimensions';
import { MIN_ANALYSIS_TARGET } from '~/constant';

export interface TargetListEditorProps {
  value?: string[];
  list?: TargetMetaInfo[];
  min?: number;
  addBtn?: ReactNode;
  onChange?: (v: string[]) => void;
}

export const TargetListEditor = memo((props: TargetListEditorProps) => {
  const { value = [], list = [], min = MIN_ANALYSIS_TARGET, addBtn, onChange } = props;
  const selectedList = useMemo(
    () =>
      value.map<DragTargetItem>((i, index) => ({
        ...list.find(j => j.name === i),
        id: i || index,
      })),
    [list, value],
  );

  const handleDelete = useCallback(
    (idx: number) => {
      const newValue = [...value.slice(0, idx), ...value.slice(idx + 1)];
      onChange?.(newValue);
    },
    [onChange, value],
  );

  const getMoveIndex = useCallback((array: string[], event: DragMoveEvent) => {
    const { active, over } = event;
    const activeIndex = array.findIndex(item => item === active.id);
    const overIndex = array.findIndex(item => item === over?.id);

    // 处理未找到索引的情况
    return {
      activeIndex: activeIndex !== -1 ? activeIndex : 0,
      overIndex: overIndex !== -1 ? overIndex : activeIndex,
    };
  }, []);

  return (
    <div className="flex gap-2 w-full max-w-[1320px]">
      {!value.length && addBtn ? (
        addBtn
      ) : (
        <>
          <DropContainer value={value} items={selectedList} getMoveIndex={getMoveIndex} onChange={onChange}>
            <div className="target-list__container">
              {selectedList.map((item, index) => (
                <TargetItem
                  key={item.id}
                  item={item}
                  index={index}
                  disabledDelete={value.length <= min}
                  handleDelete={handleDelete}
                />
              ))}
            </div>
          </DropContainer>
          <div className="self-end">{addBtn}</div>
        </>
      )}
    </div>
  );
});
