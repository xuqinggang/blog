export const MOCK_DATA: any = {
  '大盘商品数据（不含国补）': [
    {
      is_checked: true,
      display_name: '日均GMV',
      name: 'avg_gmv',
    },
    {
      is_checked: true,
      display_name: 'GMV爆发系数',
      name: 'gmv_burst_rate',
    },
    {
      is_checked: true,
      display_name: '日均增量GMV',
      name: 'avg_gmv_increase',
    },
    {
      is_checked: true,
      display_name: '日均GPM',
      name: 'avg_gpm',
    },
    {
      is_checked: true,
      display_name: '订单单价',
      name: 'avg_pay_amt',
    },
    {
      is_checked: true,
      display_name: '累积增量GMV',
      name: 'accumulate_increase_gmv',
    },
    {
      is_checked: true,
      display_name: '累积GMV',
      name: 'accumulate_gmv',
    },
    {
      is_checked: true,
      display_name: '累积GMV爆发系数',
      name: 'accumulate_gmv_burst_rate',
    },
    {
      is_checked: true,
      display_name: '日均GMV占比大盘',
      name: 'avg_gmv_in_overall',
    },
    {
      is_checked: true,
      display_name: '日均增量GMV占比大盘',
      name: 'avg_gmv_increase_in_overall',
    },
  ],
  '大盘商品数据（含国补）': [
    {
      is_checked: true,
      display_name: '日均GMV',
      name: 'avg_gmv_gov',
    },
    {
      is_checked: true,
      display_name: 'GMV爆发系数',
      name: 'gmv_burst_rate_gov',
    },
    {
      is_checked: true,
      display_name: '日均增量GMV',
      name: 'avg_gmv_increase_gov',
    },
    {
      is_checked: true,
      display_name: '日均GPM',
      name: 'avg_gpm_gov',
    },
    {
      is_checked: true,
      display_name: '订单单价',
      name: 'avg_pay_amt_gov',
    },
    {
      is_checked: true,
      display_name: '累积增量GMV',
      name: 'accumulate_increase_gmv_gov',
    },
    {
      is_checked: true,
      display_name: '累积GMV',
      name: 'accumulate_gmv_gov',
    },
    {
      is_checked: true,
      display_name: '累积GMV爆发系数',
      name: 'accumulate_gmv_burst_rate_gov',
    },
    {
      is_checked: true,
      display_name: '日均增量GMV占比大盘',
      name: 'avg_gmv_increase_in_overall_gov',
    },
    {
      is_checked: true,
      display_name: '日均GMV占比大盘',
      name: 'avg_gmv_in_overall_gov',
    },
  ],
};
