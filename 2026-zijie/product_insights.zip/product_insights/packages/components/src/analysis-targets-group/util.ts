import { IGroupTargetColumnsMap } from './type';

import { TargetMetaInfo } from '~/api/product/namespaces/dimensions';

export function getTargetColumnsMap(targetList?: TargetMetaInfo[] | null, checkedTargets?: Array<string>) {
  const columnsMap: IGroupTargetColumnsMap = {};
  targetList?.forEach(target => {
    const { display_name = '-', name = '-', attribute_type = '', is_default_show = true } = target;
    if (attribute_type && !columnsMap[attribute_type]) {
      columnsMap[attribute_type] = [];
    }
    let isChecked = is_default_show;
    if (checkedTargets) {
      isChecked = checkedTargets?.includes(name);
    }
    attribute_type &&
      columnsMap[attribute_type].push({
        is_checked: isChecked,
        is_hidden: false,
        display_name,
        name,
      });
  });
  return columnsMap;
}
