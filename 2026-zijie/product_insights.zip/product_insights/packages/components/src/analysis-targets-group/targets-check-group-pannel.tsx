import { memo, useMemo } from 'react';

import { Checkbox, Collapse, Tooltip } from '@ecom/auxo';
import { CheckboxOptionType, CheckboxValueType } from '@ecom/auxo/es/components/checkbox';

import { TGroupTargetColumnsInfo } from './type';

import './style.scss';

const { Panel } = Collapse;
const CheckboxGroup = Checkbox.Group;

interface ITargetsCheckGroupProps {
  index: number;
  labelGroupKey: string; // 每组Label
  columnsInfo: TGroupTargetColumnsInfo; // 每组的指标列
  type?: 'prefix' | 'suffix';
  groupKeys?: string[];
  updateChecks: (labelGroupKey: string, values: CheckboxValueType[]) => void;
}

export const TargetsCheckGroupPannel = memo((props: ITargetsCheckGroupProps) => {
  const { index, labelGroupKey, type, updateChecks, columnsInfo, groupKeys, ...extraProps } = props;

  const checkboxGroupOptions: CheckboxOptionType[] = useMemo(() => {
    return columnsInfo
      ?.map(item => {
        // 每个指标都会对应三个可选的枚举：指标A、指标A变化、指标A叶子类目均值。我们只给用户展示指标A就可以，其他俩就不展示了.
        // 如果用户选了指标A，默认选中指标A(xxxx)、指标A变化(diff_xxxx)、指标A叶子类目均值(leaf_avg_xxxx)、指标A叶子子赛道均分(leaf_vbline_avg_xxxx)，这3个～
        if (
          item.is_hidden ||
          groupKeys?.some(key => (type === 'prefix' ? item.name.startsWith(key) : item.name.endsWith(key)))
        ) {
          return null as any;
        }
        return {
          label: item.display_name,
          value: item.name,
        };
      })
      ?.filter(Boolean);
  }, [columnsInfo, groupKeys, type]);

  // 选中的values
  const checkboxGroupValues: CheckboxValueType[] = useMemo(
    () => columnsInfo?.filter(item => item.is_checked)?.map(item => item.name),
    [columnsInfo],
  );

  return !checkboxGroupOptions?.length ? null : (
    <Panel
      className="target-check-pannel !border-[1px] border-[#EEEFF0] rounded-[4px] mb-[16px]"
      {...extraProps}
      header={
        <div
          className="flex items-center text-[15px] text-[#252931] font-medium select-none"
          onClick={e => {
            e.stopPropagation();
          }}
        >
          {labelGroupKey}
          <Tooltip title="该指标组是否全选">
            <Checkbox
              className="mx-[6px]"
              checked={checkboxGroupValues.length === columnsInfo.length}
              onClick={e => {
                e.stopPropagation();
              }}
              onChange={e => {
                updateChecks(labelGroupKey, e.target.checked ? checkboxGroupOptions?.map(item => item.value) : []);
              }}
            >
              {/* 全选 */}
            </Checkbox>
            <span className="text-sm text-gray-500">
              {`(${checkboxGroupValues?.length}/${checkboxGroupOptions?.length})`}
            </span>
          </Tooltip>
        </div>
      }
      key={index}
    >
      <CheckboxGroup
        className="grid grid-cols-3 gap-x-4 gap-y-4"
        options={checkboxGroupOptions}
        value={checkboxGroupValues}
        onChange={v => {
          updateChecks(labelGroupKey, v);
        }}
      />
    </Panel>
  );
});
