/**
 * 分析指标配置
 */
import { memo, useEffect, useState } from 'react';
import { useMemoizedFn } from 'ahooks';
import cls from 'classnames';
import { flatten } from 'lodash-es';

import { Collapse, Input, message } from '@ecom/auxo';
import { CheckboxValueType } from '@ecom/auxo/es/components/checkbox';

import Title from '../Title';

// import { MOCK_DATA } from './mock';
// import { targetColumnsMapAtom } from './store';
import { TargetsCheckGroupPannel } from './targets-check-group-pannel';
import { IGroupTargetColumnsMap } from './type';

import '../index.css';
import './style.scss';

interface IProps {
  title?: string;
  className?: string;
  groupKeys?: string[]; // 用于分组的key
  type?: 'prefix' | 'suffix';
  value?: IGroupTargetColumnsMap;
  onChange?: (value: IGroupTargetColumnsMap) => void;
  showTitle?: boolean;
  maxCount?: number; // 最多选择指标数量
}

export const AnalysisTargetGroup = memo((props: IProps) => {
  const {
    className,
    groupKeys = [],
    type,
    value,
    onChange,
    showTitle = true,
    title = '分析指标',
    maxCount = -1,
  } = props;
  const [targetColumnsMap, setTargetColumnsMap] = useState<IGroupTargetColumnsMap>(value as IGroupTargetColumnsMap);

  const updateIndicatorColumnsMap = useMemoizedFn((labelKey: string, values: CheckboxValueType[]) => {
    const newTargetColumnsMap = {
      ...targetColumnsMap,
      [labelKey]: targetColumnsMap?.[labelKey]?.map(item => {
        let groupName = item.name;
        for (const key of groupKeys || []) {
          if (type === 'prefix' ? item.name.startsWith(key) : item.name.endsWith(key)) {
            groupName = item.name.replace(key, '');
            break;
          }
        }

        if (values.includes(groupName)) {
          return {
            ...item,
            is_checked: true,
          };
        } else {
          return {
            ...item,
            is_checked: false,
          };
        }
      }),
    } as IGroupTargetColumnsMap;
    // 最多选择指标数量拦截
    if (maxCount > 0) {
      const checkedCount = flatten(Object.values(newTargetColumnsMap))?.filter(item => item.is_checked)?.length;
      if (checkedCount > maxCount) {
        message.warn(`最多选择${maxCount}个指标`);
        return;
      }
    }
    setTargetColumnsMap(newTargetColumnsMap);
    onChange?.(newTargetColumnsMap);
  });

  const handleSearchInput = useMemoizedFn(searchVal => {
    const newTargetColumnsMap = {} as IGroupTargetColumnsMap;
    Object.entries(targetColumnsMap)?.forEach(([labelGroupKey, values]) => {
      newTargetColumnsMap[labelGroupKey] = values?.map(item => ({
        ...item,
        is_hidden: !item.display_name.includes(searchVal),
      }));
    });
    setTargetColumnsMap(newTargetColumnsMap);
    onChange?.(newTargetColumnsMap);
  });

  useEffect(() => {
    value && setTargetColumnsMap(value);
  }, [value]);

  return (
    <div className={cls(className, 'targets-group bg-white')}>
      {showTitle && <Title type="h1" content={title} className="mb-[18px]" />}

      <Input.FillSearch placeholder="搜索指标名..." allowClear className="mb-[16px]" onSearch={handleSearchInput} />

      <Collapse defaultActiveKey={[0, 1]} ghost className="bg-white">
        {Object.entries(targetColumnsMap || {})?.map(([labelGroupKey, values], index) =>
          values?.length ? (
            <TargetsCheckGroupPannel
              index={index}
              key={index}
              labelGroupKey={labelGroupKey}
              columnsInfo={values}
              groupKeys={groupKeys}
              type={type}
              updateChecks={updateIndicatorColumnsMap}
            />
          ) : null,
        )}
      </Collapse>
      {maxCount === -1 ? null : <div className="mt-[12px] text-[12px] text-desc">*最多选择{maxCount}个指标</div>}
    </div>
  );
});
