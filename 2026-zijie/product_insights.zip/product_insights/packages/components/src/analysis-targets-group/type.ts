export type TGroupTargetColumnsInfo = Array<{
  display_name: string;
  name: string;
  is_checked: boolean; // 是否选中
  is_hidden: boolean; // 是否隐藏
}>;

export interface IGroupTargetColumnsMap {
  // key: 指标分组label
  [key: string]: TGroupTargetColumnsInfo;
}
