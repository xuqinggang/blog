// import { atom } from 'jotai';

// import { MOCK_DATA } from './mock';
// import { IGroupTargetColumnsMap } from './type';

// export const targetColumnsMapAtom = atom<IGroupTargetColumnsMap>({});
