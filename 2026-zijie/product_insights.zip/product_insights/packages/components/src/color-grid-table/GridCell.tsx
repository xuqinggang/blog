import { FC, useMemo } from 'react';
import classNames from 'classnames';

import { hsbaToRgbaString } from '~/utils/color';

const DARK_THRESHOLD = 0.3;
export const getColor = (percentage: number) => {
  const realValue = Math.max(0, Math.min(1, percentage));
  return hsbaToRgbaString(228, (0.92 - 0.12) * realValue + 0.12, 1, 1);
};

export interface GridCellProps {
  className?: string;
  value: number;
  displayValue?: string;
  width?: number;
  min: number;
  max: number;
}

// const startColor = [224, 230, 255];
// const endColor = [20, 67, 255];
export const GridCell: FC<GridCellProps> = ({ className, value, displayValue, width, min, max }) => {
  const [color, percent, isDark] = useMemo(() => {
    const percent = (value - min) / (max - min);

    return [getColor(percent), percent, percent > DARK_THRESHOLD];
  }, [value, min, max]);

  return (
    <div
      data-percent={percent}
      className={classNames(
        `title-cell flex items-center justify-center gap-[2px]`,
        ` px-2 h-6 rounded-[2px] ${className}`,
        { ['text-text-icon-2']: !isDark, ['text-white']: isDark },
      )}
      style={{ width: width || 72, backgroundColor: color }}
    >
      {displayValue || value}
    </div>
  );
};
