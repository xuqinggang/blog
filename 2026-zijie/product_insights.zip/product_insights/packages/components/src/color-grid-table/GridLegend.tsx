import { FC } from 'react';
import classNames from 'classnames';

import { getColor } from './GridCell';

interface GridLegendProps {
  min?: number;
  max?: number;
  className?: string;
}
export const GridLegend: FC<GridLegendProps> = ({ min, max, className }) => {
  const startColor = getColor(0);
  const endColor = getColor(1);
  return (
    <div
      className={classNames(
        'w-full flex items-center justify-center mb-4',
        'flex items-center gap-2 text-text-2 text-xs',
        className,
      )}
    >
      <span>最小值{min}</span>
      <div
        className="w-[200px] h-[18px]"
        style={{
          background: `linear-gradient(90deg, ${startColor} 0%, ${endColor} 100%)`,
        }}
      />
      <span>最大值{max}</span>
    </div>
  );
};
