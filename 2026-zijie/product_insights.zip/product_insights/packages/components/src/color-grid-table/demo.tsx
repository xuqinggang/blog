import { FC, useState } from 'react';

import { columns, mockData } from './mock';
import { ColorGridTable } from '.';

export const ColorGridTableDemo: FC = () => {
  const [activeRow, setActiveRow] = useState<any>(undefined);
  return (
    <div className="w-full h-[400px] flex items-center">
      <ColorGridTable
        dataSource={mockData}
        columns={columns as any}
        rowActive={rec => rec === activeRow}
        handleActiveRow={(row, idx) => {
          console.log(row, idx);
          setActiveRow(row);
        }}
      />
      {/* <ColorGridTable
        dataSource={mockData}
        columns={columns as any}
        rowActive={rec => rec === activeRow}
        handleActiveRow={(row, idx) => {
          console.log(row, idx);
          setActiveRow(row);
        }}
      /> */}
    </div>
  );
};
