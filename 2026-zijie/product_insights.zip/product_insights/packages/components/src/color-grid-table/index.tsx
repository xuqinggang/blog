import { FC, useMemo, useState } from 'react';
import classNames from 'classnames';
import { compact, get } from 'lodash-es';

import { Pagination, TableProps } from '@ecom/auxo';
import { ColumnGroupType, ColumnType } from '@ecom/auxo/es/components/table';

import { GridCell } from './GridCell';
import { GridLegend } from './GridLegend';

import styles from './index.module.scss';

import { TargetCardEntity } from '~/api/product/namespaces/analysis';
import { RowData } from '~/api/product/namespaces/common_response';

export interface RenderRowData {
  dim_name: string;
  key: string;
  targets: Record<string, TargetCardEntity>;
  originData: RowData;
  extra_info?: Record<string, string> | undefined;
  children?: RenderRowData[] | undefined;
}

function isColumnType<T>(item: ColumnGroupType<T> | ColumnType<T>): item is ColumnType<T> {
  return 'dataIndex' in item;
}

export interface ColorGridTableProps extends TableProps<RenderRowData> {
  rowActive?: (record: RenderRowData, index: number) => boolean;
  colWidth?: number;
  bgColor?: string;
  handleActiveRow?: (record: RenderRowData, index?: number) => void;
}
export const ColorGridTable: FC<ColorGridTableProps> = ({
  columns: originCols = [],
  dataSource = [],
  colWidth = 80,
  className,
  rowActive,
  handleActiveRow,
  pagination,
  bgColor,
}) => {
  const [pageIdx, setPageIdx] = useState(1);

  const { total = 0, pageSize = 10 } = pagination || {};

  const renderData = useMemo(() => {
    const start = (pageIdx - 1) * pageSize;
    const end = start + pageSize;
    return dataSource.slice(start, end);
  }, [dataSource, pageIdx, pageSize]);

  const columns = useMemo(() => {
    return compact(
      originCols.map(item => {
        if (isColumnType(item)) {
          const min = dataSource.reduce<number>(
            (prev, cur) => Math.min(prev, get(cur.targets, item.dataIndex || '')?.value),
            Number.MAX_SAFE_INTEGER,
          );
          const max = dataSource.reduce<number>(
            (prev, cur) => Math.max(prev, get(cur.targets, item.dataIndex || '')?.value),
            Number.MIN_SAFE_INTEGER,
          );

          return {
            ...item,
            min,
            max,
          };
        }
        return undefined;
      }),
    );
  }, [dataSource, originCols]);

  const renderRow = (item: RenderRowData) => {
    return [
      ...columns?.map((row, idx) => {
        if (isColumnType(row)) {
          const target = get(item, row.dataIndex as string) || item.targets[row.dataIndex as string];
          return (
            <td
              key={String(`${item.dim_name}____${row.dataIndex}__${idx}`)}
              className={classNames('', idx === 0 ? 'first-cell sticky' : '')}
            >
              {idx === 0 ? (
                <div className="first-cell sticky w-full inline-flex items-center justify-end pr-2 text-xs">
                  {target?.value || target}
                </div>
              ) : (
                <GridCell
                  width={80}
                  value={target?.value || 0}
                  displayValue={target?.display_value}
                  min={row.min}
                  max={row.max}
                  className={classNames('text-xs text-text-2')}
                />
              )}
            </td>
          );
        }
        return (
          <td key={String(idx)} className=" px-[1px]">
            <div key={idx} className="cell flex items-center gap-[2px]" style={{ width: colWidth }}>
              -
            </div>
          </td>
        );
      }),
      <td key="placeholder" className="w-2">
        <div />
      </td>,
    ];
  };
  const renderRows = () => {
    return renderData?.map((row, idx) => {
      const active = rowActive?.(row, idx);
      return (
        <tr
          className={classNames('cursor-pointer ', {
            [styles.active]: active,
          })}
          onClick={() => {
            handleActiveRow?.(row, idx);
          }}
          key={String(idx)}
        >
          {renderRow(row)}
        </tr>
      );
    });
  };

  return (
    <div className="w-full flex flex-col overflow-hidden">
      <GridLegend />
      <div className="w-full flex flex-col overflow-x-auto max-h-[230px] overflow-y-auto">
        <table className={classNames(styles.table, className)}>
          <thead style={{ backgroundColor: bgColor }}>
            <tr>
              {columns.map((item, idx) => {
                if (idx === 0) {
                  return (
                    <th key={item.key} style={{ borderColor: bgColor }}>
                      <div className="w-full h-[24px]" style={{ backgroundColor: bgColor || 'white' }} />
                    </th>
                  );
                } else
                  return (
                    <th key={item.key} className="title-cell" style={{ borderColor: bgColor }}>
                      <div
                        className={classNames(
                          'text-xs text-text-2 font-normal',
                          'overflow-hidden text-ellipsis whitespace-nowrap',
                        )}
                      >
                        {item.title}
                      </div>
                    </th>
                  );
              })}
              <th className="w-2" style={{ width: 8, borderColor: bgColor }} />
            </tr>
          </thead>
          <tbody>{renderRows()}</tbody>
        </table>
      </div>
      {pagination ? (
        <div className="w-full flex justify-end mt-2">
          <Pagination
            size="small"
            className="mt-4"
            total={total}
            pageSize={pageSize}
            current={pageIdx}
            onChange={idx => {
              setPageIdx(idx);
            }}
          />
        </div>
      ) : null}
    </div>
  );
};
