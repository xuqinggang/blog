import React from 'react';
import classNames from 'classnames';

import { Empty, EmptyProps } from '@ecom/auxo';

import styles from './index.module.scss';

type PlaceholderType = 'error' | 'empty';
export interface ResizedPlaceholderProps extends EmptyProps {
  type?: PlaceholderType;
  size?: 'small' | 'medium';
  className?: string;
  style?: React.CSSProperties;
}

const COVER_MAP: Record<PlaceholderType, string | undefined> = {
  error: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/vebh_tvjl/ljhwZthlaukjlkulzlp/Frame9.svg',
  empty: undefined,
};

export const ResizedPlaceholder: React.FC<ResizedPlaceholderProps> = ({
  type = 'empty',
  size,
  className,
  ...props
}) => {
  const cover = COVER_MAP[type] || undefined;
  return (
    <Empty
      image={cover}
      className={classNames(
        // 'empty-img-emotion',
        styles.container,
        {
          [styles.small]: size === 'small',
          [styles.medium]: size === 'medium',
        },
        className,
      )}
      {...props}
    />
  );
};
