import { EnumOption } from '@ecom/auxo-pro-form/es/components';

import { BizType } from '~/api/product/namespaces/dimensions';
import { ContentType, DateType, SubscriptionParam, UserSubscription } from '~/api/product/namespaces/subscription';

export interface SubscribeType extends EnumOption {
  recentSubscribeDate: EnumOption[];
}

export interface SubscribeModalProps {
  visible: boolean; // 弹窗是否可见
  bizType: BizType; // 业务线
  title?: string; // 弹窗标题
  configId?: number; // 订阅配置ID，默认是1
  businessId?: number; // 业务线ID，默认是1000
  customSubscribeTypes?: SubscribeType[]; // 自定义订阅类型
  contentType?: ContentType; // 订阅推动的消息类型, 是配置表的子集, 1:截图, 2:图表，默认是1
  param?: SubscriptionParam; // 订阅的参数，截图参数、时间间隔等
  onCancel: () => void; // 关闭弹窗
  beforePreview?: (task: UserSubscription) => Promise<void>; // 预览前的钩子函数
  beforeCreate?: (task: UserSubscription) => Promise<void>; // 创建订阅前的钩子函数
}

export enum SubscribeTab {
  SUBSCRIBE_CONFIG = 'subscribe_config', // 订阅设置
  SUBSCRIBE_MANAGE = 'subscribe_manage', // 订阅管理
}

export interface SubscribeDateTime {
  frequency?: number; // 当类型为周报，星期几(1~7)；当类型为月报时，几号(1~31)，每月最后一天用-1表示，若当月无31号则不推送
  time?: string; // 推送时间（mm:ss）
  recentDate?: string; // 数据周期
}

export interface SubscribeFormValues {
  name?: string; // 订阅名称
  types?: DateType[]; // 订阅类型
  dailySubscribe?: SubscribeDateTime; // 日报订阅
  weeklySubscribe?: SubscribeDateTime; // 周报订阅
  monthlySubscribe?: SubscribeDateTime; // 月报订阅
  owners?: string[]; // 负责人（employee_id）
  targetUsers?: string[]; // 目标用户（employee_id）
  targetGroups?: string[]; // 目标群（open_id）
}
