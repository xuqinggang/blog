import { forwardRef, memo, useImperativeHandle, useMemo, useRef, useState } from 'react';

import { Avatar, Button, message, Modal, Space, Switch, Tooltip } from '@ecom/auxo';
import { SortOrder } from '@ecom/auxo/es/components/table/component/interface';
import EcopTable, { ActionType, ProColumns, RequestData } from '@ecop/table';
import { PeopleCard } from '@ecop/user';

import './index.scss';

import { productClient } from '~/api';
import { Int64 } from '~/api/arctic';
import { DateType, Status, UserSubscription } from '~/api/product/namespaces/subscription';
import { formatTime, transformNumber } from '~/utils/formatter/number';

export interface SubscribeManagerProps {
  configId?: number;
  onEdit?: (subscription: UserSubscription) => void;
}

export interface SubscribeManagerRef {
  reload?: (resetPageIndex?: boolean) => Promise<void>;
}

export const SubscribeManager = memo(
  forwardRef<SubscribeManagerRef, SubscribeManagerProps>((props, ref) => {
    const { configId, onEdit } = props;
    const [loading, setLoading] = useState(false);
    const [total, setTotal] = useState(0);
    const actionRef = useRef<ActionType>();

    /**
     * 更新订阅状态
     */
    const updateSubscriptionStatus = async (status: Status, subscription: UserSubscription) => {
      try {
        setLoading(true);
        await productClient.SaveUserSubscription({
          task: {
            ...subscription,
            status,
          },
        });

        message.success('修改订阅状态成功');
      } catch (e) {
        console.error('Update subscription status error', e);
        message.error('修改订阅状态失败');
      } finally {
        setLoading(false);
      }
    };

    /**
     * 删除订阅
     */
    const deleteSubscription = async (id: Int64) => {
      try {
        await productClient.DeleteUserSubscription({
          sub_id: id,
        });
        message.success('删除订阅成功');
      } catch (e) {
        console.error('Delete subscription error', e);
        message.error('删除订阅失败');
      }
    };

    const getSubscriptionList = async (
      page: { current?: number; pageSize?: number } = {},
      sorter: Record<string, SortOrder> = {},
    ): Promise<Partial<RequestData<UserSubscription>>> => {
      try {
        const [orderBy, order] = Object.entries(sorter)?.[0] ?? [];
        const { data } = await productClient.GetUserSubscriptionList({
          config_id: configId,
          page: page.current,
          page_size: page.pageSize,
          orderBy,
          isAsc: order === 'ascend',
        });
        setTotal(Number(data?.total));

        return {
          data: data?.records ?? [],
          success: true,
        };
      } catch (e) {
        setLoading(false);
        setTotal(0);
        return {
          data: [],
          success: false,
        };
      }
    };

    const columns = useMemo<ProColumns<UserSubscription>[]>(() => {
      return [
        {
          title: '订阅名称',
          dataIndex: 'subscribe_name',
          render: value => <Tooltip.Auto title={value}>{value}</Tooltip.Auto>,
        },
        {
          title: '订阅者',
          dataIndex: 'subscribe_target',
          render: (_, record) => {
            const { target_user, target_group } = record;

            return (
              <Space direction="vertical" size={4}>
                {target_user?.length ? (
                  <Space size={4}>
                    <span>用户</span>
                    <PeopleCard
                      max={3}
                      list={target_user.map(({ id }) => ({
                        employee_id: id || '',
                      }))}
                    />
                  </Space>
                ) : null}
                {target_group?.length ? (
                  <Space size={4}>
                    <span>群组</span>
                    <Avatar.Group maxCount={3}>
                      {target_group.map(({ id, name }) => (
                        <Tooltip key={id} title={name}>
                          <Avatar>{name?.slice(0, 1)}</Avatar>
                        </Tooltip>
                      ))}
                    </Avatar.Group>
                  </Space>
                ) : null}
              </Space>
            );
          },
        },
        {
          title: '订阅时间',
          dataIndex: 'subscribe_time',
          render: (_, record) => {
            return (
              <Space direction="vertical" size={4}>
                {record.push_time?.map(({ dateType, DayOfMonth, DayOfWeek, Hour, Minute }) => {
                  let value = '';

                  switch (dateType) {
                    case DateType.Day: {
                      value = `日报：每日${formatTime(Hour)}:${formatTime(Minute)}`;
                      break;
                    }
                    case DateType.Week: {
                      value = `周报：每周${DayOfWeek ? transformNumber(DayOfWeek) : ''} ${formatTime(
                        Hour,
                      )}:${formatTime(Minute)}`;
                      break;
                    }
                    case DateType.Month: {
                      value = `月报：每月${(DayOfMonth ?? 0) <= 0 ? '最后一' : DayOfMonth}日 ${formatTime(
                        Hour,
                      )}:${formatTime(Minute)}`;
                      break;
                    }
                    default: {
                      break;
                    }
                  }

                  return (
                    <Tooltip.Auto title={value} key={value}>
                      {value}
                    </Tooltip.Auto>
                  );
                })}
              </Space>
            );
          },
        },
        {
          title: '订阅状态',
          dataIndex: 'subscribe_status',
          width: 80,
          render: (_, record) => {
            const hasAuth = record.owner_email?.some(
              ({ email }) => email === window?.GarfishBridge?.infoBridge?.getUserInfo()?.email,
            );

            return (
              <Switch
                loading={loading}
                disabled={!hasAuth}
                checked={record.status === Status.RUNING}
                onChange={async checked => {
                  // 更新订阅状态
                  await updateSubscriptionStatus(checked ? Status.RUNING : Status.PAUSE, record);
                  // 刷新列表
                  await actionRef.current?.reload(false);
                }}
              />
            );
          },
        },
        {
          title: '操作',
          dataIndex: 'operation',
          width: 80,
          render: (_, record) => {
            const hasAuth = record.owner_email?.some(
              ({ email }) => email === window?.GarfishBridge?.infoBridge?.getUserInfo()?.email,
            );

            return (
              <Space size={8}>
                <Button
                  type="link"
                  disabled={!hasAuth}
                  onClick={() => {
                    onEdit?.(record);
                  }}
                >
                  编辑
                </Button>
                <Button
                  type="link"
                  danger
                  disabled={!hasAuth}
                  onClick={() => {
                    // 二次确认弹窗
                    Modal.warn({
                      title: '删除订阅',
                      content: '确定删除该订阅吗？',
                      onOk: async () => {
                        // 删除订阅
                        record.id && (await deleteSubscription(record.id));
                        // 刷新列表
                        await actionRef.current?.reload(true);
                      },
                    });
                  }}
                >
                  删除
                </Button>
              </Space>
            );
          },
        },
      ];
    }, [loading, onEdit]);

    useImperativeHandle(
      ref,
      () => ({
        reload: actionRef.current?.reload,
      }),
      [],
    );

    return (
      <EcopTable
        className="subscribe-manager"
        search={false}
        toolBarRender={false}
        rowKey="index"
        request={getSubscriptionList}
        actionRef={actionRef}
        pagination={{ showSizeChanger: true, pageSizeOptions: ['10', '20'], total }}
        columns={columns}
        style={{ padding: 0 }}
        scroll={{ y: 300 }}
      />
    );
  }),
);
