import dayjs from 'dayjs';

import { InputNumber, Select, Space, TimePicker } from '@ecom/auxo';
import { EnumOption } from '@ecom/auxo-pro-form/es/components';

import { RECENT_SUBSCRIBE_DATE, WEEKLY_SUBSCRIBE_FREQUENCY } from './const';
import { SubscribeDateTime } from './types';

import { DateType } from '~/api/product/namespaces/subscription';

export interface SubscribeTimeConfigProps {
  type: DateType;
  recentSubscribeDate?: EnumOption[];
  value?: SubscribeDateTime;
  disabled?: Partial<Record<keyof SubscribeDateTime, boolean>>;
  onChange?: (value: SubscribeDateTime) => void;
}

export function SubscribeTimeConfig(props: SubscribeTimeConfigProps) {
  const { recentSubscribeDate = RECENT_SUBSCRIBE_DATE, type, value, disabled, onChange } = props;
  const { frequency: frequencyDisabled, time: timeDisabled, recentDate: recentDateDisabled } = disabled || {};

  return (
    <Space size={16}>
      {/* 频率选择 */}
      {type === DateType.Day ? null : type === DateType.Week ? (
        <Select
          style={{ width: 120 }}
          value={value?.frequency}
          placeholder="请选择订阅频率"
          options={WEEKLY_SUBSCRIBE_FREQUENCY as any}
          disabled={frequencyDisabled}
          onChange={v => {
            onChange?.({
              ...value,
              frequency: v,
            });
          }}
        />
      ) : (
        <InputNumber
          style={{ width: 80 }}
          className="!min-w-0"
          value={value?.frequency}
          disabled={frequencyDisabled}
          prefix="日期"
          max={31}
          min={-1}
          onChange={v => {
            onChange?.({
              ...value,
              frequency: Number(v),
            });
          }}
        />
      )}
      {/* 时间选择 */}
      <TimePicker
        value={dayjs(value?.time, 'HH:mm') as any}
        format="HH:mm"
        placeholder="请选择订阅时间"
        disabled={timeDisabled}
        onChange={v => {
          onChange?.({
            ...value,
            time: v?.format('HH:mm'),
          });
        }}
      />
      {/* 周期选择 */}
      <Select
        style={{ width: 120 }}
        value={value?.recentDate}
        placeholder="请选择数据周期"
        options={recentSubscribeDate as any}
        disabled={recentDateDisabled}
        onChange={v => {
          onChange?.({
            ...value,
            recentDate: v,
          });
        }}
      />
    </Space>
  );
}
