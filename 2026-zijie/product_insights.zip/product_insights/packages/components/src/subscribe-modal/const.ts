import { EnumOption } from '@ecom/auxo-pro-form/es/components';

import { SubscribeFormValues, SubscribeType } from './types';

import { DateType } from '~/api/product/namespaces/subscription';

export const WEEKLY_SUBSCRIBE_FREQUENCY: EnumOption[] = [
  {
    label: '周一',
    value: 1,
  },
  {
    label: '周二',
    value: 2,
  },
  {
    label: '周三',
    value: 3,
  },
  {
    label: '周四',
    value: 4,
  },
  {
    label: '周五',
    value: 5,
  },
  {
    label: '周六',
    value: 6,
  },
  {
    label: '周日',
    value: 7,
  },
];

export const RECENT_SUBSCRIBE_DATE: EnumOption[] = [
  {
    label: '近1天',
    value: '1',
  },
  {
    label: '近3天',
    value: '3',
  },
  {
    label: '近7天',
    value: '7',
  },
  {
    label: '近15天',
    value: '15',
  },
  {
    label: '近30天',
    value: '30',
  },
];

export const DEFAULT_SUBSCRIBE_TYPES: SubscribeType[] = [
  {
    label: '日报',
    value: DateType.Day,
    recentSubscribeDate: RECENT_SUBSCRIBE_DATE,
  },
  {
    label: '周报',
    value: DateType.Week,
    recentSubscribeDate: RECENT_SUBSCRIBE_DATE,
  },
  {
    label: '月报',
    value: DateType.Month,
    recentSubscribeDate: RECENT_SUBSCRIBE_DATE,
  },
];

/** 业务线ID, 1000-商品流量洞察 */
export const DEFAULT_BUSINESS_ID = 1000;

/** 默认form表单配置 */
export const DEFAULT_FORM_VALUES: SubscribeFormValues = {
  types: [DateType.Day], // 默认订阅日报
  dailySubscribe: {
    time: '10:00:00', // 默认10:00
    recentDate: '1', // 默认近1天数据
  },
  weeklySubscribe: {
    frequency: 1, // 默认周一
    time: '10:00:00', // 默认10:00
    recentDate: '7', // 默认近1天数据
  },
  monthlySubscribe: {
    frequency: 1, // 默认一号
    time: '10:00:00', // 默认10:00
    recentDate: '30', // 默认近30天数据
  },
};

/** 默认的订阅配置ID */
export const DEFAULT_CONFIG_ID = 1;
