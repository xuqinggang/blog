import { forwardRef, memo, useEffect, useImperativeHandle, useMemo, useState } from 'react';
import { differenceBy } from 'lodash-es';

import { EnumOption, Form, FormDesc, FormInstance } from '@ecom/auxo-pro-form';
import { PeopleSelect } from '@ecop/user';

import { DEFAULT_BUSINESS_ID, DEFAULT_FORM_VALUES, DEFAULT_SUBSCRIBE_TYPES } from './const';
import { SubscribeTimeConfig } from './subscribe-time-config';
import { SubscribeDateTime, SubscribeFormValues, SubscribeType } from './types';
import { transformSubscription } from './utils';

import { subscribeClient } from '~/api';
import { DateType, Target, UserSubscription } from '~/api/product/namespaces/subscription';
import { isNullOrUndefined } from '~/utils/is';

interface SubscribeConfigProps {
  subscribeTypes?: SubscribeType[]; // 订阅类型
  businessId?: number; // 业务线ID，默认是1000
  selectedSubscription?: UserSubscription; // 选中的订阅配置
}

export const SubscribeConfig = memo(
  forwardRef<FormInstance<SubscribeFormValues>, SubscribeConfigProps>((props, ref) => {
    const { subscribeTypes = DEFAULT_SUBSCRIBE_TYPES, selectedSubscription, businessId = DEFAULT_BUSINESS_ID } = props;
    const [defaultGroups, setDefaultGroups] = useState<Target[]>(); // 默认群列表
    const [form] = Form.useForm();

    useImperativeHandle(ref, () => form, [form]);

    // 初始化表单参数
    useEffect(() => {
      if (!selectedSubscription) {
        const userInfo = window.GarfishBridge?.infoBridge?.getUserInfo();
        form.pResetFields({
          value: {
            ...DEFAULT_FORM_VALUES,
            owners: [userInfo?.employee_id], // 负责人默认设置为当前用户
          },
        });
      } else {
        const formValues = transformSubscription(selectedSubscription);
        form.pSetFieldsValue(formValues);

        if (selectedSubscription?.target_group?.length) {
          setDefaultGroups(selectedSubscription.target_group);
        }
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedSubscription]);

    const pJson = useMemo<FormDesc>(() => {
      return [
        {
          type: 'text',
          label: '订阅名称',
          name: 'name',
          props: {
            placeholder: '请输入订阅名称',
          },
          itemProps: {
            required: true,
          },
          rules: [{ required: true, message: '请输入订阅名称' }],
        },
        {
          type: 'enum',
          label: '订阅类型',
          name: 'types',
          itemProps: {
            required: true,
          },
          props: {
            isRadio: true,
            multiple: true,
            enums: subscribeTypes,
          },
          rules: [
            {
              validator(_, value?: DateType[]) {
                if (!value?.length) {
                  return Promise.reject(new Error('请选择订阅类型'));
                }

                return Promise.resolve();
              },
            },
          ],
        },
        {
          type: 'custom',
          label: '日报订阅',
          name: 'dailySubscribe',
          children: (
            <SubscribeTimeConfig
              type={DateType.Day}
              recentSubscribeDate={subscribeTypes.find(i => i.value === DateType.Day)?.recentSubscribeDate}
            />
          ),
          itemProps: {
            required: true,
          },
          hidden: ({ rootValue }) => !rootValue.types?.includes(DateType.Day),
          shouldUpdate: (prev, next) => prev?.types?.includes(DateType.Day) !== next?.types?.includes(DateType.Day),
          dependencies: ['types'],
          rules: [
            {
              validator: (_, value?: SubscribeDateTime) => {
                if (!value?.time) {
                  return Promise.reject(new Error('请选择日报订阅时间'));
                }

                if (!value?.recentDate) {
                  return Promise.reject(new Error('请选择日报订阅数据周期'));
                }

                return Promise.resolve();
              },
            },
          ],
        },
        {
          type: 'custom',
          label: '周报订阅',
          name: 'weeklySubscribe',
          children: (
            <SubscribeTimeConfig
              type={DateType.Week}
              recentSubscribeDate={subscribeTypes.find(i => i.value === DateType.Week)?.recentSubscribeDate}
            />
          ),
          itemProps: {
            required: true,
          },
          hidden: ({ rootValue }) => !rootValue.types?.includes(DateType.Week),
          shouldUpdate: (prev, next) => prev?.types?.includes(DateType.Week) !== next?.types?.includes(DateType.Week),
          rules: [
            {
              validator: (_, value?: SubscribeDateTime) => {
                if (!value?.frequency) {
                  return Promise.reject(new Error('请选择周报订阅日期'));
                }

                if (!value?.time) {
                  return Promise.reject(new Error('请选择周报订阅时间'));
                }

                if (!value?.recentDate) {
                  return Promise.reject(new Error('请选择周报订阅数据周期'));
                }

                return Promise.resolve();
              },
            },
          ],
        },
        {
          type: 'custom',
          label: '月报订阅',
          name: 'monthlySubscribe',
          children: (
            <SubscribeTimeConfig
              type={DateType.Month}
              recentSubscribeDate={subscribeTypes.find(i => i.value === DateType.Month)?.recentSubscribeDate}
            />
          ),
          itemProps: {
            required: true,
            extra: '日期为1-31号，每月最后一天用-1表示，若当月无31号则不推送',
          },
          hidden: ({ rootValue }) => !rootValue.types?.includes(DateType.Month),
          dependencies: ['types'],
          rules: [
            {
              validator: (_, value?: SubscribeDateTime) => {
                if (isNullOrUndefined(value?.frequency)) {
                  return Promise.reject(new Error('请选择月报订阅日期'));
                }

                if (value?.frequency === 0) {
                  return Promise.reject(new Error('月报订阅日期不能为0'));
                }

                if (!value?.time) {
                  return Promise.reject(new Error('请选择月报订阅时间'));
                }

                if (!value?.recentDate) {
                  return Promise.reject(new Error('请选择月报订阅数据周期'));
                }

                return Promise.resolve();
              },
            },
          ],
        },
        {
          type: 'custom',
          label: '负责人',
          name: 'owners',
          itemProps: {
            required: true,
          },
          children: (
            <PeopleSelect mode="multiple" maxTagCount="responsive" showEmail placeholder="请输入用户名进行选择" />
          ),
          rules: [
            {
              validator(_, value?: string[]) {
                if (!value?.length) {
                  return Promise.reject(new Error('请选择负责人'));
                }
                return Promise.resolve();
              },
            },
          ],
        },
        {
          type: 'custom',
          label: '飞书用户',
          name: 'targetUsers',
          children: (
            <PeopleSelect mode="multiple" maxTagCount="responsive" showEmail placeholder="请输入用户名进行选择" />
          ),
          rules: [
            form => {
              const targetGroups = form.getFieldValue('targetGroups');
              return {
                validator(_, value?: string[]) {
                  if (!value?.length && !targetGroups?.length) {
                    return Promise.reject(new Error('请选择飞书用户或飞书群'));
                  }
                  return Promise.resolve();
                },
              };
            },
          ],
          shouldUpdate: (prev, next) => {
            const prevTargetGroups = prev?.targetGroups;
            const nextTargetGroups = next?.targetGroups;
            return prevTargetGroups?.length !== nextTargetGroups?.length;
          },
        },
        {
          type: 'remoteEnum',
          label: '飞书群',
          name: 'targetGroups',
          itemProps: {
            extra: '需要先将“商品流量洞察”机器人添加至群聊中，再搜索群聊名称',
          },
          props: {
            loadMore: true,
            multiple: true,
            showAllCheckbox: false,
            refreshDeps: [defaultGroups],
            placeholder: '搜索需要订阅的飞书群',
            service: async params => {
              const { search = '', page = 1 } = params;
              const defaultGroup =
                defaultGroups?.map<EnumOption>(item => ({
                  label: item.name,
                  value: item.id || '',
                })) ?? [];

              if (!search) {
                return defaultGroup;
              }

              const { data } = await subscribeClient.SearchLarkUserOrGroup({
                businessId,
                keyword: search,
                isGroup: true,
                page,
                pageSize: 10,
              });

              const res =
                data?.targets?.map<EnumOption>(({ name, openId }) => ({
                  label: name,
                  value: openId,
                })) ?? [];
              const filterRes = differenceBy(res, defaultGroup, 'value');

              return params.page === 1 ? [...defaultGroup, ...filterRes] : filterRes;
            },
          },
          rules: [
            form => {
              const targetUsers = form.getFieldValue('targetUsers');
              return {
                validator(_, value?: string[]) {
                  if (!value?.length && !targetUsers?.length) {
                    return Promise.reject(new Error('请选择飞书用户或飞书群'));
                  }
                  return Promise.resolve();
                },
              };
            },
          ],
          shouldUpdate: (prev, next) => {
            const prevTargetUsers = prev?.targetUsers;
            const nextTargetUsers = next?.targetUsers;
            return prevTargetUsers?.length !== nextTargetUsers?.length;
          },
        },
      ];
    }, [businessId, defaultGroups]);

    return (
      <Form
        form={form}
        labelCol={{ span: 4 }}
        labelAlign="left"
        pLayout={{ gutter: [0, 16], disableItemMargin: true, style: { padding: 0 } }}
        pJson={pJson}
      />
    );
  }),
);
