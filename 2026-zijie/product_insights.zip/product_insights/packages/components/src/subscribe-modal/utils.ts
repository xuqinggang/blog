import { SubscribeDateTime, SubscribeFormValues } from './types';

import { EaUser } from '~/api/ecop';
import { DateType, PushTime, Target, UserSubscription } from '~/api/product/namespaces/subscription';
import { formatTime } from '~/utils/formatter/number';

export function transformTarget(users: EaUser[]) {
  return users.map<Target>(({ employee_id_str, email, user_name }: any) => ({
    id: employee_id_str,
    name: user_name,
    email,
  }));
}

export function transformSubscription(subscription: UserSubscription): SubscribeFormValues {
  const { subscribe_name, target_group, target_user, push_time, owner_email } = subscription;

  const types: DateType[] = [];
  let dailySubscribe: SubscribeDateTime | undefined;
  let weeklySubscribe: SubscribeDateTime | undefined;
  let monthlySubscribe: SubscribeDateTime | undefined;

  push_time?.forEach(({ dateType, DayOfWeek, DayOfMonth, Hour, Minute }) => {
    types.push(dateType);
    switch (dateType) {
      case DateType.Day: {
        dailySubscribe = {
          time: `${formatTime(Hour)}:${formatTime(Minute)}`,
        };
        break;
      }
      case DateType.Week: {
        weeklySubscribe = {
          frequency: DayOfWeek,
          time: `${formatTime(Hour)}:${formatTime(Minute)}`,
        };
        break;
      }
      case DateType.Month: {
        monthlySubscribe = {
          frequency: DayOfMonth,
          time: `${formatTime(Hour)}:${formatTime(Minute)}`,
        };
        break;
      }
      default: {
        break;
      }
    }
  });

  return {
    name: subscribe_name,
    types,
    dailySubscribe,
    weeklySubscribe,
    monthlySubscribe,
    owners: owner_email?.map(({ id }) => id || ''),
    targetGroups: target_group?.map(({ id }) => id || ''),
    targetUsers: target_user?.map(({ id }) => id || ''),
  };
}

export function transformFormValues(
  formValues: SubscribeFormValues,
): Pick<UserSubscription, 'subscribe_name' | 'push_time'> {
  const { name, types, dailySubscribe, weeklySubscribe, monthlySubscribe } = formValues;
  const pushTime: PushTime[] = [];

  if (types?.includes(DateType.Day) && dailySubscribe) {
    pushTime.push({
      dateType: DateType.Day,
      Hour: Number(dailySubscribe?.time?.split(':')?.[0]),
      Minute: Number(dailySubscribe?.time?.split(':')?.[1]),
      url_params: dailySubscribe?.recentDate
        ? {
            recent_date: dailySubscribe.recentDate,
            dateType: String(DateType.Day),
          }
        : undefined,
    });
  }

  if (types?.includes(DateType.Week) && weeklySubscribe) {
    pushTime.push({
      dateType: DateType.Week,
      DayOfWeek: weeklySubscribe?.frequency,
      Hour: Number(weeklySubscribe?.time?.split(':')?.[0]),
      Minute: Number(weeklySubscribe?.time?.split(':')?.[1]),
      url_params: dailySubscribe?.recentDate
        ? {
            recent_date: dailySubscribe.recentDate,
            dateType: String(DateType.Day),
          }
        : undefined,
    });
  }

  if (types?.includes(DateType.Month) && monthlySubscribe) {
    pushTime.push({
      dateType: DateType.Month,
      DayOfMonth: monthlySubscribe?.frequency,
      Hour: Number(monthlySubscribe?.time?.split(':')?.[0]),
      Minute: Number(monthlySubscribe?.time?.split(':')?.[1]),
      url_params: dailySubscribe?.recentDate
        ? {
            recent_date: dailySubscribe.recentDate,
            dateType: String(DateType.Day),
          }
        : undefined,
    });
  }

  return {
    subscribe_name: name,
    push_time: pushTime,
  };
}
