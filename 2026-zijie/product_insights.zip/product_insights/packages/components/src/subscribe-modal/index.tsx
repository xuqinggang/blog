import { memo, useCallback, useEffect, useRef, useState } from 'react';

import { Button, message, Modal, Space, Spin, Tabs, Tooltip } from '@ecom/auxo';
import { FormInstance } from '@ecom/auxo-pro-form';

import { SubscribeConfig } from './config';
import { DEFAULT_BUSINESS_ID, DEFAULT_CONFIG_ID } from './const';
import { SubscribeManager, SubscribeManagerRef } from './manager';
import { SubscribeFormValues, SubscribeModalProps, SubscribeTab } from './types';
import { transformFormValues, transformTarget } from './utils';

import './index.scss';

import { ecopClient, productClient, subscribeClient } from '~/api';
import { ContentType, UserSubscription } from '~/api/product/namespaces/subscription';

// 批量查询用户信息
async function batchQueryUserInfo(employeeIds?: string[]) {
  if (!employeeIds?.length) {
    return [];
  }

  const { data } = await ecopClient.BatchGetEaUser({
    employeeIds: employeeIds.join(','),
  });

  return data;
}

// 查询群组信息
async function searchGroup(ids?: string[], businessId = DEFAULT_BUSINESS_ID) {
  if (!ids?.length) {
    return [];
  }

  const { data } = await subscribeClient.SearchLarkUserOrGroup({
    businessId,
    isGroup: true,
    idList: ids,
  });

  return data?.targets;
}

// 在外部有使用， 对函数做简单导出
export { batchQueryUserInfo, searchGroup };

export const SubscribeModal = memo((props: SubscribeModalProps) => {
  const {
    visible,
    bizType,
    title = '订阅',
    configId = DEFAULT_CONFIG_ID,
    businessId = DEFAULT_BUSINESS_ID,
    customSubscribeTypes,
    contentType = ContentType.ScreenShot,
    param,
    onCancel,
    beforeCreate,
    beforePreview,
  } = props;
  const [activeTab, setActiveTab] = useState(SubscribeTab.SUBSCRIBE_CONFIG); // 当前激活的tab
  const isSubscribeConfig = activeTab === SubscribeTab.SUBSCRIBE_CONFIG; // 是否是订阅配置tab
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [selectedSubscription, setSelectedSubscription] = useState<UserSubscription>(); // 选中的订阅配置
  const formRef = useRef<FormInstance>(null);
  const managerRef = useRef<SubscribeManagerRef>(null);

  /**
   * 编辑订阅
   */
  const handleEdit = useCallback((subscription: UserSubscription) => {
    setActiveTab(SubscribeTab.SUBSCRIBE_CONFIG);
    setSelectedSubscription(subscription);
  }, []);

  /**
   * 合并请求体
   */
  const genTask = async () => {
    const values = (formRef.current?.pGetFieldsValue() ?? {}) as SubscribeFormValues;

    // 批量查询用户信息
    const { owners, targetUsers, targetGroups } = values;
    const [ownerInfos, targetUserInfos, targetGroupInfo] = await Promise.all([
      batchQueryUserInfo(owners),
      batchQueryUserInfo(targetUsers),
      searchGroup(targetGroups, businessId),
    ]);

    const owner = transformTarget(ownerInfos);
    const targetUser = transformTarget(targetUserInfos);

    const task: UserSubscription = {
      ...selectedSubscription,
      config_id: configId,
      business_id: businessId,
      biz_type: bizType,
      target_user: targetUser,
      target_group: targetGroupInfo?.map(({ openId, name }) => ({ id: openId, name })),
      owner_email: owner,
      content_type: contentType,
      ...transformFormValues(values),
    };

    if (!selectedSubscription) {
      // 新建订阅需要加上外部传入的params，编辑订阅复用原有的params
      task.param = param;
    }

    return task;
  };

  /**
   * 发送订阅
   */
  async function previewSubscribe() {
    try {
      setPreviewLoading(true);
      await formRef.current?.pValidateFields();

      const task = await genTask();
      !selectedSubscription && (await beforePreview?.(task)); // 只针对新建的订阅做处理

      // 创建/更新订阅配置
      await productClient.PreviewUserSubscription({
        task,
      });

      message.success('发送测试成功，需要等待一段时间才会收到通知');
    } catch (e: any) {
      console.error('Preview subscribe error', e);
      if (e?.errorFields?.length) {
        message.error('订阅配置校验失败');
      } else {
        message.error('发送测试失败');
      }
    } finally {
      setPreviewLoading(false);
    }
  }

  /**
   * 创建/更新订阅配置
   */
  async function handleConfirm() {
    try {
      setConfirmLoading(true);
      await formRef.current?.pValidateFields();

      const task = await genTask();
      !selectedSubscription && (await beforeCreate?.(task)); // 只针对新建的订阅做处理

      // 创建/更新订阅配置
      await productClient.SaveUserSubscription({
        task,
      });

      if (selectedSubscription) {
        // 修改订阅配置
        message.success('修改订阅配置成功');
      } else {
        // 创建订阅配置
        message.success('创建订阅配置成功');
        setActiveTab(SubscribeTab.SUBSCRIBE_MANAGE);
      }

      // 刷新订阅列表
      await managerRef.current?.reload?.(true);
    } catch (e: any) {
      console.error('Save subscribe error', e);
      if (e?.errorFields?.length) {
        message.error('订阅配置校验失败');
      } else {
        message.error(selectedSubscription ? '修改订阅配置失败' : '创建订阅配置失败');
      }
    } finally {
      setConfirmLoading(false);
    }
  }

  useEffect(() => {
    if (!visible) {
      setActiveTab(SubscribeTab.SUBSCRIBE_CONFIG);
      setSelectedSubscription(undefined);
      return;
    }
  }, [visible]);

  useEffect(() => {
    if (activeTab === SubscribeTab.SUBSCRIBE_MANAGE) {
      setSelectedSubscription(undefined);
    }
  }, [activeTab]);

  return (
    <Modal
      className="subscribe-modal"
      visible={visible}
      title={title}
      onCancel={onCancel}
      width={640}
      style={{ height: 640 }}
      destroyOnClose
      footer={
        <Space size={8}>
          <Spin spinning={previewLoading}>
            <Tooltip title="发送测试默认只会推送给当前操作人">
              <div
                hidden={!isSubscribeConfig}
                className="flex items-center gap-1 cursor-pointer text-[#1966ff]"
                onClick={previewSubscribe}
              >
                <span>发送测试</span>
              </div>
            </Tooltip>
          </Spin>
          <Button loading={confirmLoading} hidden={!isSubscribeConfig} type="primary" onClick={handleConfirm}>
            确定
          </Button>
          <Button onClick={onCancel}>取消</Button>
        </Space>
      }
    >
      <Tabs activeKey={activeTab} onChange={activeKey => setActiveTab(activeKey as SubscribeTab)}>
        <Tabs.TabPane tab="订阅设置" key={SubscribeTab.SUBSCRIBE_CONFIG} forceRender>
          {/* 订阅设置 */}
          <SubscribeConfig
            ref={formRef}
            selectedSubscription={selectedSubscription}
            subscribeTypes={customSubscribeTypes}
          />
        </Tabs.TabPane>
        <Tabs.TabPane tab="订阅管理" key={SubscribeTab.SUBSCRIBE_MANAGE} forceRender>
          {/* 订阅管理 */}
          <SubscribeManager ref={managerRef} configId={configId} onEdit={handleEdit} />
        </Tabs.TabPane>
      </Tabs>
    </Modal>
  );
});
