/* eslint-disable @typescript-eslint/no-non-null-assertion */
import React, { forwardRef, ReactNode, useEffect, useImperativeHandle, useRef, useState } from 'react';

import { Drawer, Form, message } from '@ecom/auxo';

import { DRAWER_ACTION_TEXT_MAP } from './constant';
import { RuleForm } from './form';
import { addRule, editRule, getEventTypes, getRuleDetail } from './request';
import { transformFormRuleToServerValuesRule } from './transform';
import { DrawerActionType, IFormOptions, IOptions, RuleFormValue } from './type';

import {
  AlertEventTypeItem,
  GetAnalysisPoolAlertRuleDetailData,
} from '~/api/product/namespaces/analysis_pool_alert_rule';

export interface IRuleDrawerProps {
  actionAreaRender?: (
    ruleDetail: GetAnalysisPoolAlertRuleDetailData | null,
    drawerActionType: DrawerActionType,
  ) => ReactNode;
}

export interface IRuleDrawerRef {
  openDrawerByCreate: (_formOptions: IFormOptions, options: IOptions) => void;
  openDrawerByCopy: (_formOptions: IFormOptions, options: IOptions) => Promise<void>;
  openDrawerByPreview: (_formOptions: IFormOptions, options: IOptions) => Promise<void>;
  changePreviewToEdit: () => void;
  updateOptions: (options: Partial<IOptions>) => void;
}

export const RuleDrawer = forwardRef<IRuleDrawerRef, IRuleDrawerProps>((props, ref) => {
  const [eventTypes, setEventTypes] = useState<AlertEventTypeItem[]>([]);
  const [confirmLoading, setConfirmLoading] = useState(false);

  const [drawerActionType, setDrawerActionType] = useState<DrawerActionType>(DrawerActionType.CREATE);
  const [ruleDetail, setRuleDetail] = useState<GetAnalysisPoolAlertRuleDetailData | null>(null);
  const [loading, setLoading] = useState(false);
  const [visible, setVisible] = useState(false);
  // 表格所需的参数
  const [formOptions, setFormOptions] = useState<IFormOptions>();

  const [form] = Form.useForm<RuleFormValue>();

  const optionsRef = useRef<IOptions | null>(null);

  const { actionAreaRender } = props;

  const isAlertPrettyRule = React.useMemo(() => {
    const rules = ruleDetail?.ruleData?.rule?.rule?.rules;
    if (!rules?.length) {
      return Boolean(
        ruleDetail?.ruleData?.rule?.rule?.alert_pretty_rule || ruleDetail?.ruleData?.rule?.rule?.alert_indicator,
      );
    } else {
      return rules.every(item => Boolean(item?.alert_pretty_rule || item?.alert_indicator));
    }
  }, [ruleDetail]);

  const isUsePrettyRule = React.useMemo(() => {
    return !Boolean(!isAlertPrettyRule && drawerActionType !== DrawerActionType.CREATE);
  }, [isAlertPrettyRule, drawerActionType]);

  useImperativeHandle(ref, (): IRuleDrawerRef => {
    return {
      // 新建规则任务
      openDrawerByCreate: (_formOptions, options) => {
        optionsRef.current = options;
        setFormOptions(_formOptions);

        setVisible(true);
        setDrawerActionType(DrawerActionType.CREATE);
      },
      // 复制规则任务
      openDrawerByCopy: async (_formOptions, options) => {
        setLoading(true);
        optionsRef.current = {
          ...(optionsRef?.current || {}),
          ...(options || {}),
        };
        setFormOptions(_formOptions);

        setVisible(true);
        setDrawerActionType(DrawerActionType.COPY);
        const _ruleDetail = await getRuleDetail(options.ruleId || '', options.version);
        if (_ruleDetail) {
          setRuleDetail(_ruleDetail);
        }
        setLoading(false);
      },
      // 预览监控任务
      openDrawerByPreview: async (_formOptions, options) => {
        setLoading(true);
        optionsRef.current = {
          ...(optionsRef?.current || {}),
          ...(options || {}),
        };
        setFormOptions(_formOptions);

        setVisible(true);
        setDrawerActionType(DrawerActionType.PREVIEW);
        const _ruleDetail = await getRuleDetail(options.ruleId || '', options.version);
        if (_ruleDetail) {
          setRuleDetail(_ruleDetail);
        }
        setLoading(false);
      },
      // 从预览状态修改为编辑状态
      changePreviewToEdit: () => {
        if (drawerActionType === DrawerActionType.PREVIEW) {
          setDrawerActionType(DrawerActionType.EDIT);
        } else {
          console.error('drawerActionType 不为PREVIEW');
        }
      },
      // 更改内部存储的Options
      updateOptions: options => {
        if (optionsRef.current) {
          optionsRef.current = {
            ...(optionsRef?.current || {}),
            ...(options || {}),
          };
        }
      },
    };
  });

  function handleClose() {
    setVisible(false);
    optionsRef.current?.onClose?.();
    setEventTypes([]);
    form.resetFields(); // 清空form value
  }

  async function handleSubmit() {
    const errorFields = await form
      .validateFields()
      .then(() => [])
      .catch(err => Promise.resolve([...(err?.errorFields || [])]));

    if (errorFields.length > 0) {
      return;
    }

    const formValues = form.getFieldsValue();
    const { receiveGroups, receiveUsers, isAnalyzeProductStatus, alertProductStatusRule } = formValues;
    const alertProductStatusRuleObj =
      isAnalyzeProductStatus && alertProductStatusRule ? JSON.stringify(alertProductStatusRule) : undefined;
    const values = {
      ...formValues,
      alertProductStatusRule: alertProductStatusRuleObj,
      rule: transformFormRuleToServerValuesRule(formValues?.rule, isUsePrettyRule)!,
    };
    if (!receiveGroups?.length && !receiveUsers?.length) {
      // 错误提示：飞书群组和用户至少设置其中之一
      form.setFields([
        {
          name: 'receiveGroups',
          errors: ['飞书群组和飞书用户至少设置其中之一'],
        },
        {
          name: 'receiveUsers',
          errors: ['飞书群组和飞书用户至少设置其中之一'],
        },
      ]);

      return;
    }

    if (optionsRef.current?.beforeSubmit && (await optionsRef.current.beforeSubmit()) === false) {
      return;
    }

    let reqPoolId = values.poolId;
    if (!values.poolId) {
      reqPoolId = optionsRef.current?.poolId;
    }

    // 下方为表格默认行为
    setConfirmLoading(true);
    let isSuccess = false;
    if (drawerActionType === DrawerActionType.CREATE || drawerActionType === DrawerActionType.COPY) {
      // 创建规则
      isSuccess = await addRule(values, reqPoolId || '');
    } else if (drawerActionType === DrawerActionType.EDIT) {
      isSuccess = await editRule(
        values,
        ruleDetail?.ruleData?.rule?.business_id || '',
        ruleDetail?.ruleData?.rule?.rule_id || '',
      );
    }

    if (!isSuccess) {
      message.error('提交失败，请重试');
    }
    setConfirmLoading(false);

    handleClose();
    await optionsRef.current?.afterSubmit?.();
  }

  // 获取数据源列表
  useEffect(() => {
    if (!visible) {
      return;
    }

    getEventTypes().then(res => {
      if (res) {
        setEventTypes(res);
      }
    });
  }, [visible]);

  return (
    <Drawer
      width={1000}
      visible={visible}
      mask={false}
      maskClosable={false}
      loading={loading}
      confirmLoading={confirmLoading}
      title={
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            paddingRight: '40px',
          }}
        >
          <div
            style={{
              flex: 1,
            }}
          >
            {`${DRAWER_ACTION_TEXT_MAP[drawerActionType]}监控任务`}
          </div>
          {actionAreaRender?.(ruleDetail, drawerActionType)}
        </div>
      }
      destroyOnClose // 注意Form内部状态的销毁依赖于该属性
      showCancel
      footer={drawerActionType === DrawerActionType.PREVIEW ? null : undefined}
      onClose={handleClose}
      onCancel={handleClose}
      onOk={handleSubmit}
    >
      <RuleForm
        form={form}
        eventTypes={eventTypes}
        drawerActionType={drawerActionType}
        ruleDetail={ruleDetail}
        defaultValue={formOptions?.defaultValue}
        hiddenRule={formOptions?.hiddenRule}
        baseStruct={formOptions?.baseStruct}
        isTotal={formOptions?.isTotal}
        autoCreatePool={Boolean(optionsRef.current?.beforeSubmit)}
      />
    </Drawer>
  );
});
