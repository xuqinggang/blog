import { transformForm2Rule } from './transform';
import { RuleFormValue } from './type';

import { productClient } from '~/api';
import {
  CreateAnalysisPoolAlertRuleReq,
  GetAnalysisPoolAlertRuleDetailResp,
  LisAnalysisPoolEventTypeResp,
} from '~/api/product/namespaces/analysis_pool_alert_rule';

// 创建规则
export const addRule = async function (values: RuleFormValue, poolId: string) {
  try {
    const req: Omit<CreateAnalysisPoolAlertRuleReq, 'pool_id'> = await transformForm2Rule(values);
    await productClient.CreateAnalysisPoolAlertRule({ pool_id: poolId, ...req });
  } catch (e) {
    console.error('Add rule error', e);
  }
  return true;
};

// 编辑规则
export async function editRule(values: RuleFormValue, business_id: string, rule_id: string) {
  try {
    const req: Omit<CreateAnalysisPoolAlertRuleReq, 'pool_id'> = await transformForm2Rule(values);
    const userInfo = window.GarfishBridge?.infoBridge?.getUserInfo();
    // @ts-ignore 后端类型没更新
    const { code, msg } = await productClient.UpdateAnalysisPoolAlertRule({
      ...req,
      business_id,
      author_id: userInfo?.employee_id ?? '',
      author_email: userInfo?.email ?? '',
      author_name: userInfo?.user_name ?? '',
      rule_id,
    });

    if (code !== 0) {
      throw new Error(msg);
    }
    return true;
  } catch (e) {
    console.error('Add rule error', e);
    return false;
  }
}

export const getRuleDetail = async (ruleId: string, version?: number) => {
  try {
    const { data }: GetAnalysisPoolAlertRuleDetailResp = await productClient.GetAnalysisPoolAlertRuleDetail({
      rule_id: ruleId,
      version,
    });

    if (data) {
      return data;
    }
  } catch (e) {
    console.error('Get rule detail error', e);
  }
  return null;
};

// 获取数据源列表
export const getEventTypes = async function () {
  try {
    const { data }: LisAnalysisPoolEventTypeResp = await productClient.LisAnalysisPoolEventType({});
    if (data?.items) {
      return data.items;
    }
  } catch (e) {
    console.error('Get eventTypes error', e);
  }
  return undefined;
};
