import { DrawerActionType, SelectOption } from './type';

import { BizType } from '~/api/product/namespaces/dimensions';

export const DRAWER_ACTION_TEXT_MAP = {
  [DrawerActionType.PREVIEW]: '预览',
  [DrawerActionType.CREATE]: '创建',
  [DrawerActionType.EDIT]: '编辑',
  [DrawerActionType.COPY]: '复制',
};

/** 任务等级列表 */
export const PRIORITY_LIST: SelectOption[] = [
  {
    label: 'P0',
    value: 0,
  },
  {
    label: 'P1',
    value: 1,
  },
  {
    label: 'P2',
    value: 2,
  },
  {
    label: 'P3',
    value: 3,
  },
];

/** 推送周期列表 */
export const INTERVAL_DAY_LIST: SelectOption[] = [
  {
    label: '每日',
    value: 8,
  },
  {
    label: '每周一',
    value: 1,
  },
  {
    label: '每周二',
    value: 2,
  },
  {
    label: '每周三',
    value: 3,
  },
  {
    label: '每周四',
    value: 4,
  },
  {
    label: '每周五',
    value: 5,
  },
  {
    label: '每周六',
    value: 6,
  },
  {
    label: '每周日',
    value: 7,
  },
];

/** 统计周期列表 */
export const TIME_TYPE_LIST: SelectOption[] = [
  {
    label: '最近有数1天',
    value: 1,
  },
  // {
  //   label: '近1日',
  //   value: 13,
  // },
  {
    label: '最近有数2日',
    value: 14,
  },
  {
    label: '最近有数3日',
    value: 15,
  },
  {
    label: '最近有数5日',
    value: 16,
  },
  {
    label: '最近有数7日',
    value: 10,
  },
  {
    label: '最近有数14日',
    value: 11,
  },
  {
    label: '最近有数30日',
    value: 12,
  },
];

/** 统计周期列表 */
export const USE_PRETTY_TIME_TYPE_LIST: SelectOption[] = [
  {
    label: '最近有数1天',
    value: 1,
  },
  // {
  //   label: '近1日',
  //   value: 13,
  // },
  {
    label: '最近有数2日',
    value: 2,
  },
  {
    label: '最近有数3日',
    value: 3,
  },
  {
    label: '最近有数5日',
    value: 5,
  },
  {
    label: '最近有数7日',
    value: 7,
  },
  {
    label: '最近有数14日',
    value: 14,
  },
  {
    label: '最近有数30日',
    value: 30,
  },
];

/** 指标聚合方式列表 */
export const INDICATOR_AGG_TYPE_LIST: SelectOption[] = [
  {
    label: '总和',
    value: 1,
  },
  {
    label: '均值',
    value: 2,
  },
];

/** 维度聚合方式列表 */
export const DIMENSION_AGG_TYPE_LIST: SelectOption[] = [
  {
    label: '去重',
    value: 0,
  },
  {
    label: '不去重',
    value: 3,
  },
];

// 对比结果是比例的对比方式枚举列表
// export const COMPARE_RATE_TYPE_LIST = [2, 4, 6, 8, 9, 12, 13, 16, 18, 20, 22, 24, 26];
export const COMPARE_RATE_TYPE_LIST = [2, 4, 6, 8, 9, 12, 13];

// 今日累计的对比方式
export const COMPARE_TYPE_LIST_CUR_DAY = [1, 4, 5, 8, 9, 10, 11, 12, 13, 14, 15];

// 近2、3、5、7、14、30天的对比方式
export const COMPARE_TYPE_LIST_RANGE_DAY = [1, 2, 3, 8, 9, 10, 11, 12, 13, 14, 15, 20, 21, 22, 23];

/** 对比方式列表 */
export const COMPARE_TYPE_LIST: SelectOption[] = [
  {
    label: '绝对值',
    value: 1,
  },
  {
    label: '环比',
    value: 2,
  },
  {
    label: '环差',
    value: 3,
  },
  {
    label: '相比昨天同时段-比例',
    value: 4,
  },
  {
    label: '相比昨天同时段-差值',
    value: 5,
  },
  {
    label: '相比上周同时段-比例',
    value: 6,
  },
  {
    label: '相比上周同时段-差值',
    value: 7,
  },
  {
    label: '相比前一日同时段上升百分比',
    value: 8,
  },
  {
    label: '相比前一日同时段下降百分比',
    value: 9,
  },
  {
    label: '相比前一日同时段上升绝对值',
    value: 10,
  },
  {
    label: '相比前一日同时段下降绝对值',
    value: 11,
  },
  {
    label: '相比前一周同时段上升百分比',
    value: 12,
  },
  {
    label: '相比前一周同时段下降百分比',
    value: 13,
  },
  {
    label: '相比前一周同时段上升绝对值',
    value: 14,
  },
  {
    label: '相比前一周同时段下降绝对值',
    value: 15,
  },
  // {
  //   label: '相比上月相同时段上升百分比',
  //   value: 16,
  // },
  // {
  //   label: '相比上月相同时段上升绝对值',
  //   value: 17,
  // },
  // {
  //   label: '相比上月相同时段下降百分比',
  //   value: 18,
  // },
  // {
  //   label: '相比上月相同时段下降绝对值',
  //   value: 19,
  // },
  {
    label: '相比前一相同时段上升百分比',
    value: 20,
  },
  {
    label: '相比前一相同时段上升绝对值',
    value: 21,
  },
  {
    label: '相比前一相同时段下降百分比',
    value: 22,
  },
  {
    label: '相比前一相同时段下降绝对值',
    value: 23,
  },
  // {
  //   label: '环比上升百分比',
  //   value: 24,
  // },
  // {
  //   label: '环比上升绝对值',
  //   value: 25,
  // },
  // {
  //   label: '环比下降百分比',
  //   value: 26,
  // },
  // {
  //   label: '环比下降绝对值',
  //   value: 27,
  // },
];

/** 运算符列表 */
export const OP_LIST: SelectOption[] = [
  {
    label: '>',
    value: '>',
  },
  {
    label: '≥',
    value: '>=',
  },
  {
    label: '<',
    value: '<',
  },
  {
    label: '≤',
    value: '<=',
  },
  {
    label: '=',
    value: '=',
  },
  {
    label: '≠',
    value: '!=',
  },
];

/** 触达频次控制列表 */
export const PUSH_FREQUENCY_LIST: SelectOption[] = [
  {
    label: '近1天',
    value: 7,
  },
  {
    label: '近3天',
    value: 1,
  },
  {
    label: '近7天',
    value: 2,
  },
  {
    label: '近15天',
    value: 3,
  },
  {
    label: '近30天',
    value: 4,
  },
  {
    label: '近1个自然日',
    value: 6,
  },
  {
    label: '近1个自然月',
    value: 5,
  },
];

export const DISPLAY_TARGET_NAME_LIST = [
  'pay_ord_cnt',
  'pay_gmv',
  'show_pv',
  'click_pv',
  'gpm',
  'ctr',
  'cvr',
  'pvr',
  'opm',
];

export const GUESSYOULIKE_TARGET_NAME_LIST = [
  'pv_sum',
  'order_sum',
  'gmv_sum',
  'ab_pv_rate',
  'ab_order_rate',
  'ab_gmv_rate',
  'ab_gpm_rate',
  'ab_opm_rate',
];

export const eventType2Tooltip: { [key: string]: string } = {
  // 大盘底表提示词
  app_product_insight_usr_prod_scenario_flow_trd_stats_new_di_arctic:
    '开启该开关后，如果您监控的商品命中以下任意勾选一条规则，平台将向您推送预警消息',
  // 超值购底表提示词
  app_product_insight_usr_prod_billion_flow_trd_stats_di:
    '开启该开关后，如果您监控的商品命中以下任意勾选一条规则，平台将向您推送预警消息',
};

export const eventType2BizType = {
  // 大盘
  app_product_insight_usr_prod_scenario_flow_trd_stats_new_di_arctic: BizType.GrowthProductStrategy,
  // 超值购
  app_product_insight_usr_prod_billion_flow_trd_stats_di: BizType.GreatValueBuy,
};
