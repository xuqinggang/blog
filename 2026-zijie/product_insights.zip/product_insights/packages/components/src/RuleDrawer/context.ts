import React from 'react';

import { BizType, DataReadyTime, GetDimensionListData, TargetMetaInfo } from '~/api/product/namespaces/dimensions';

export interface RuleItemContextValue {
  bizType?: BizType;
  insightReadyTime?: DataReadyTime;
  insightDimData?: GetDimensionListData;
  insightTargetMetaList?: TargetMetaInfo[];
  usePrettyRule?: boolean;
}

export const RuleItemContext = React.createContext<RuleItemContextValue>({
  usePrettyRule: true,
});
