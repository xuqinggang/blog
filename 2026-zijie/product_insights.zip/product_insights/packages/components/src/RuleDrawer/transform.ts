/* eslint-disable @ecom/security-internal-host */

import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';

import { UserInfo } from '@ecop/user';

import { PushSchedule, RuleFormValue } from './type';

import { ecopClient } from '~/api';
import {
  CreateAnalysisPoolAlertRuleReq,
  GetAnalysisPoolAlertRuleDetailData,
  IndicatorNodeValueCondition,
  Rule,
} from '~/api/product/namespaces/analysis_pool_alert_rule';
import { safetyParse } from '~/utils/parse';
dayjs.extend(customParseFormat);

async function searchUser(emailPrefix: string): Promise<UserInfo> {
  try {
    const { data } = await ecopClient.SearchUser({
      keyword: emailPrefix,
    });

    if (data && data.length === 1) {
      return data[0] as UserInfo;
    }

    return {} as UserInfo;
  } catch (e) {
    console.error(`Search user error, emailPrefix: ${emailPrefix}`, e);
    return {} as UserInfo;
  }
}

/**
 * 通过邮箱获取用户信息
 * @param emails 用户邮箱列表
 * @returns 用户信息列表
 */
async function getUsersByEmail(emails?: string[]): Promise<UserInfo[]> {
  if (!emails?.length) {
    return [];
  }

  const promises: Promise<UserInfo>[] = [];
  emails.forEach(email => {
    const emailPrefix = email.split('@');
    if (!emailPrefix?.[0]) {
      return;
    }

    promises.push(searchUser(emailPrefix[0]));
  });

  const result = await Promise.all(promises);
  return result;
}

/**
 * 将RPC接口返回的cron表达式转化为推送频率结构化数据
 * @param cron cron表达式
 * @returns 推送频率
 */
export function transformCron2Schedule(cron: string): PushSchedule | null {
  const withWeek = cron.match(/^(\d+)\s(\d+)\s\*\s\*\s(\d+)$/);
  const withDay = cron.match(/^(\d+)\s(\d+)\s\*\s\*\s\*$/);

  if (withWeek) {
    // 周一 - 周日
    const minute = withWeek[1];
    const hour = withWeek[2];
    const intervalDayOfWeek = withWeek[3];

    if (!minute || !hour || !intervalDayOfWeek) {
      return null;
    }

    return {
      intervalTime: dayjs(`${hour}:${minute}`, 'HH:mm'),
      intervalDayOfWeek: Number(intervalDayOfWeek),
    };
  }

  if (withDay) {
    // 每日
    const minute = withDay[1];
    const hour = withDay[2];

    if (!minute || !hour) {
      return null;
    }

    return {
      intervalTime: dayjs(`${hour}:${minute}`, 'HH:mm'),
      intervalDayOfWeek: 8, // 每日
    };
  }

  return null;
}

function divideCondition(rule: Rule) {
  const condition = { ...rule?.custom_rule_config?.condition } as IndicatorNodeValueCondition | undefined;
  if (!condition) {
    return;
  }

  const conditionLength = condition.conditions?.length;
  if (!conditionLength) {
    if (!rule?.custom_rule_config) {
      rule.custom_rule_config = {
        condition: {
          logic: condition.logic,
          condition_type: -1,
          conditions: [condition],
        },
      } as any;
    } else {
      rule.custom_rule_config!.condition = {
        logic: condition.logic,
        condition_type: -1,
        conditions: [condition],
      };
    }
  }
}

export const transformFormRuleToServerValuesRule = (rule: any, isUsePrettyRule: boolean) => {
  if (!rule) {
    return undefined;
  }
  const res: Rule = {
    logic: rule.logic,
  };
  res.rules = rule.rules?.map((item: any) => {
    const alertPrettyRule = item?.alert_pretty_rule;
    return {
      ...item,
      alert_pretty_rule: isUsePrettyRule ? alertPrettyRule : undefined,
      alert_indicator: isUsePrettyRule
        ? {
            indicator_code: item.custom_rule_config?.indicator?.node_value?.indicator_code,
            compare_type: item.custom_rule_config?.compare_type,
            time_range: item.custom_rule_config?.time_type,
            time_unit: 1, // 目前只支持天级别
          }
        : undefined,
      custom_rule_config: isUsePrettyRule ? undefined : item.custom_rule_config,
    };
  });
  return res;
};

export const transformServerValuesRuleToFormRule = (rule: Rule) => {
  if (!rule) {
    return undefined;
  }
  const res: Rule = {
    logic: rule.logic,
  };
  res.rules = rule.rules?.map((item: any) => {
    const alertPrettyRule = item?.alert_pretty_rule;
    const alertIndicator = item?.alert_indicator;
    return {
      ...item,
      alert_pretty_rule: alertPrettyRule,
      alert_indicator: undefined,
      custom_rule_config:
        alertPrettyRule || alertIndicator
          ? {
              ...(item?.custom_rule_config || {}),
              condition: {
                ...(item?.custom_rule_config?.condition || {}),
              },
              compare_type: item.alert_indicator?.compare_type,
              time_type: item.alert_indicator?.time_range,
              indicator: {
                ...(item?.custom_rule_config?.indicator || {}),
                node_value: {
                  ...(item?.custom_rule_config?.indicator?.node_value || {}),
                  indicator_code: alertIndicator?.indicator_code,
                },
              },
            }
          : item.custom_rule_config,
    };
  });
  return res;
};

export async function transformRule2Form(detail: GetAnalysisPoolAlertRuleDetailData): Promise<Partial<RuleFormValue>> {
  const { ruleData, receiveGroups, receiveUsers, is_analyze_product_status, alert_product_status_rule } = detail;

  const alertProductStatusRule = alert_product_status_rule
    ? safetyParse(alert_product_status_rule, undefined)
    : undefined;
  // 处理用户信息（管理员、推送用户
  // 由于预警平台下发的是邮箱，需要转化为employee_id
  const [adminUserInfos, receiveUserInfos] = await Promise.all([
    getUsersByEmail(ruleData?.admins),
    getUsersByEmail(receiveUsers),
  ]);

  const formValues: Partial<RuleFormValue> = {
    admins: adminUserInfos.map(({ employee_id }) => String(employee_id)),
    receiveUsers: receiveUserInfos.map(({ employee_id }) => String(employee_id)),
    receiveGroups,
    isAnalyzeProductStatus: Boolean(is_analyze_product_status),
    alertProductStatusRule,
    lowDisturb: ruleData?.low_disturb,
  };
  const rule = ruleData?.rule;
  if (rule) {
    const { event_group_by, event_type, rule_name, schedule_strategy, push_frequency, rule_desc, rule: subRule } = rule;

    formValues.ruleName = rule_name;
    formValues.ruleDesc = rule_desc;
    formValues.priority = schedule_strategy?.priority;
    formValues.eventType = event_type;
    formValues.dimensions = event_group_by?.split(',');
    formValues.pushFrequency = push_frequency;
    formValues.rule = {};

    if (schedule_strategy?.cron) {
      formValues.pushSchedule = transformCron2Schedule(schedule_strategy.cron) ?? undefined;
    }

    // 处理rule
    if (subRule) {
      const { rules } = subRule;
      // eslint-disable-next-line max-depth
      if (!rules?.length) {
        // 只有一条规则，将rule抽离到rules
        divideCondition(subRule);
        formValues.rule.rules = [subRule];
        formValues.rule.logic = subRule.logic || 'or';
      } else {
        rules.forEach(divideCondition);
        formValues.rule = subRule;
      }
    }
  }
  formValues.rule = transformServerValuesRuleToFormRule(formValues.rule as Rule);

  return formValues;
}

/** ***********************分割线，下面是transformForm2Rule ****************************/

async function getUsersById(employeeIds?: string[]): Promise<UserInfo[]> {
  try {
    if (!employeeIds?.length) {
      return [];
    }

    const { data } = await ecopClient.BatchGetEaUser({
      employeeIds: employeeIds.join(','),
      isInternalStaff: true,
      withOpenId: true,
    });

    return data as UserInfo[];
  } catch (e) {
    console.error('Get users by id error', e);
    return [];
  }
}

/**
 * 将前端的推送频率转化为RPC接口的cron表达式
 * @param intervalDayOfWeek 每日：8，周一 - 周日：1 - 7
 * @param hour 小时：0-23
 * @param minute 分钟：0-59
 */
function transformSchedule2Cron(intervalDayOfWeek: number, hour: string, minute: string) {
  if (intervalDayOfWeek === 8) {
    return `${minute} ${hour} * * *`;
  }

  return `${minute} ${hour} * * ${intervalDayOfWeek}`;
}

function mergeCondition(rule: Rule) {
  if (!rule?.custom_rule_config?.condition) {
    return;
  }

  const conditionLength = rule.custom_rule_config.condition.conditions?.length;
  if (!conditionLength) {
    // 如果condition下面的conditions为空，删除condition
    delete rule.custom_rule_config.condition;
    return;
  }

  // 如果conditions只有一个元素，将其合并到condition
  const condition = rule.custom_rule_config.condition.conditions?.[0];
  if (conditionLength === 1 && condition) {
    rule.custom_rule_config.condition = condition;
  }
}

export async function transformForm2Rule(
  values: RuleFormValue,
): Promise<Omit<CreateAnalysisPoolAlertRuleReq, 'pool_id'>> {
  const {
    ruleName,
    ruleDesc,
    priority,
    admins,
    eventType,
    dimensions,
    pushSchedule,
    rule,
    isAnalyzeProductStatus,
    alertProductStatusRule,
    pushFrequency,
    receiveGroups,
    receiveUsers,
    lowDisturb,
  } = values;

  const { intervalDayOfWeek, intervalTime } = pushSchedule;
  const timeFormat = intervalTime.format('HH:mm');
  const [hour, minute] = timeFormat.split(':');
  const cron = transformSchedule2Cron(intervalDayOfWeek, hour, minute);

  // 由于预警平台接收的是邮箱，需要将employee_id转化为邮箱
  const [adminUserInfos, receiveUserInfos] = await Promise.all([getUsersById(admins), getUsersById(receiveUsers)]);

  const result: Omit<CreateAnalysisPoolAlertRuleReq, 'pool_id'> = {
    rule_name: ruleName || '',
    desc: ruleDesc || ' ', // rule_desc不填会报错
    admins: adminUserInfos.map(({ email }) => email || ''),
    event_type: eventType,
    event_group_by: dimensions.join(','),
    is_analyze_product_status: isAnalyzeProductStatus ? 1 : 0,
    alert_product_status_rule: alertProductStatusRule,
    low_disturb: lowDisturb,
    push_frequency: pushFrequency,
    schedule_strategy: {
      cron,
      priority,
    },
    receiveGroups,
    receiveUsers: receiveUserInfos.map(({ email }) => email || ''),
    rule: {},
  };

  // 处理rule
  const rulesLength = rule.rules?.length;
  if (rulesLength) {
    const ruleItem = rule.rules?.[0];

    if (rulesLength === 1 && ruleItem) {
      // 只有一条规则将其合并到rule里面
      mergeCondition(ruleItem); // 处理condition
      result.rule = ruleItem;
    } else {
      // 多条规则，批量处理condition
      rule.rules?.forEach(mergeCondition);
      result.rule = rule;
    }
  }

  return result;
}

export const filterNoValueConvertedRule = (data: IndicatorNodeValueCondition | null) => {
  if (!data) {
    return null;
  }
  return {
    ...(data || {}),
    conditions: data.conditions?.filter(item => item?.common_condition?.values?.length),
  };
};
