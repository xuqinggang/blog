import React, { useMemo, useState } from 'react';
import { get } from 'lodash-es';

import { Button, Form, Input, InputNumber, Select, Tooltip } from '@ecom/auxo';
import { FormListFieldData } from '@ecom/auxo/es/components/form';
import { AddIcon, DeleteIcon } from '@ecom/auxo/es/components/icon';
import { FormInstance } from '@ecom/auxo/lib/components/form/component/Form';

import LogicalContainer from '../component/logical-container';
import PercentInput from '../component/percent-input';
import SimplePanel from '../component/simple-panel';
import {
  COMPARE_RATE_TYPE_LIST,
  COMPARE_TYPE_LIST,
  COMPARE_TYPE_LIST_CUR_DAY,
  COMPARE_TYPE_LIST_RANGE_DAY,
  DIMENSION_AGG_TYPE_LIST,
  DISPLAY_TARGET_NAME_LIST,
  GUESSYOULIKE_TARGET_NAME_LIST,
  INDICATOR_AGG_TYPE_LIST,
  OP_LIST,
  TIME_TYPE_LIST,
  USE_PRETTY_TIME_TYPE_LIST,
} from '../constant';
import { RuleItemContext } from '../context';
import { LogicalCode, RuleFormValue, SelectOption } from '../type';

import { FilterItem } from './filter-item';
import InsightFilterForm from './insight-filter-form';

// import InsightFilterLogic from './insight-filter-logic';
import styles from './index.module.scss';

import {
  ArcticAlertIndicator,
  IndicatorNodeValueCondition,
  SelectValue,
} from '~/api/product/namespaces/analysis_pool_alert_rule';
import { BizType } from '~/api/product/namespaces/dimensions';

interface RuleItemProps {
  namePrefix: string[];
  form: FormInstance<RuleFormValue>;
  field: FormListFieldData;
  disabled?: boolean;
  removeRule: () => void;
  indicators: ArcticAlertIndicator[];
  dimensions: SelectValue[];
  defaultFilterCondition?: IndicatorNodeValueCondition | null;
}

export const RuleItem = (props: RuleItemProps) => {
  const { form, disabled, field, namePrefix, removeRule, indicators, dimensions, defaultFilterCondition } = props;
  const [selectedIndicator, setSelectedIndicator] = useState<string>(
    form.getFieldValue([...namePrefix, field.name, 'custom_rule_config', 'indicator', 'node_value', 'indicator_code']),
  );
  const ruleItemContextValue = React.useContext(RuleItemContext);

  // 聚合方式选项(维度 - 去重/不去重；指标 - 总和/均值)
  const aggTypeOptions = useMemo<SelectOption[]>(() => {
    if (!selectedIndicator) {
      return [];
    }

    // 维度 - 去重/不去重
    if (dimensions.some(({ value }) => value === selectedIndicator)) {
      return DIMENSION_AGG_TYPE_LIST;
    }

    // 指标 - 总和/均值
    if (
      indicators.some(({ code }) => code === selectedIndicator) ||
      (ruleItemContextValue.insightTargetMetaList || [])?.some(({ name }) => name === selectedIndicator)
    ) {
      return INDICATOR_AGG_TYPE_LIST;
    }

    return [];
  }, [dimensions, indicators, ruleItemContextValue.insightTargetMetaList, selectedIndicator]);

  return (
    <SimplePanel
      style={{ marginBottom: 16 }}
      headerStyle={{ height: 'fit-content', padding: 8 }}
      title={
        <Form.Item
          style={{ marginBottom: 0 }}
          name={[field.name, 'rule_name'] as any}
          required
          rules={[{ required: true, message: '请填写规则名称' }]}
        >
          <Input disabled={disabled} placeholder="请填写规则名称" />
        </Form.Item>
      }
      operate={<Button type="text" disabled={disabled} onClick={removeRule} icon={<DeleteIcon />} />}
    >
      <Form.Item label="触发值" required style={{ marginBottom: 8 }} />
      <div className={styles.rule_form_item}>
        {/* 统计周期 */}
        <Form.Item
          name={[field.name, 'custom_rule_config', 'time_type'] as any}
          required
          rules={[{ required: true, message: '请选择统计周期' }]}
        >
          <Select
            placeholder="请选择统计周期"
            options={ruleItemContextValue.usePrettyRule ? USE_PRETTY_TIME_TYPE_LIST : TIME_TYPE_LIST}
            disabled={disabled}
          />
        </Form.Item>
        {/* 指标 */}
        <Form.Item
          name={[field.name, 'custom_rule_config', 'indicator', 'node_value', 'indicator_code'] as any}
          required
          rules={[{ required: true, message: '请选择指标' }]}
        >
          <Select
            placeholder="请选择指标"
            dropdownMatchSelectWidth={false}
            // 指标和维度拼接
            options={
              ruleItemContextValue.usePrettyRule
                ? (ruleItemContextValue.insightTargetMetaList || [])
                    .filter(
                      ({ name, biz_type }) =>
                        // 如果是猜喜数据，则直接使用服务端下发的
                        name &&
                        ((biz_type !== BizType.GuessBoostData && DISPLAY_TARGET_NAME_LIST.includes(name)) ||
                          (biz_type === BizType.GuessBoostData && GUESSYOULIKE_TARGET_NAME_LIST.includes(name))),
                    )
                    .map(({ name, display_name }) => ({
                      label: display_name || '',
                      value: name || '',
                    }))
                : indicators.map(({ name, code }) => ({ label: name, value: code }))
              // v0.8中产品要求屏蔽以及来源、叶子类目名称等维度
              // .concat(
              //   dimensions.filter(({ value }) => value !== '__nil__').map(({ name, value }) => ({ label: name, value }))
              // )
            }
            disabled={disabled}
            onSelect={value => {
              setSelectedIndicator(value as string);
            }}
          />
        </Form.Item>
        {/* 聚合方式 */}
        <Form.Item
          name={[field.name, 'custom_rule_config', 'indicator', 'node_value', 'agg_type'] as any}
          required={!ruleItemContextValue.usePrettyRule}
          hidden={ruleItemContextValue.usePrettyRule}
          rules={ruleItemContextValue.usePrettyRule ? undefined : [{ required: true, message: '请选择聚合方式' }]}
        >
          <Select placeholder="请选择聚合方式" options={aggTypeOptions} disabled={disabled} />
        </Form.Item>
        {/* 对比方式 */}

        <Form.Item
          noStyle
          shouldUpdate={(prevValues, currentValues) => {
            return (
              get(prevValues, [field.name, 'custom_rule_config', 'time_type']) !==
              get(currentValues, [field.name, 'custom_rule_config', 'time_type'])
            );
          }}
        >
          {({ getFieldValue }) => {
            const timeType = getFieldValue([...namePrefix, field.name, 'custom_rule_config', 'time_type']);
            let options = COMPARE_TYPE_LIST.filter(item =>
              Boolean(COMPARE_TYPE_LIST_RANGE_DAY.find(v => item.value === v)),
            );
            if (timeType === 1) {
              options = COMPARE_TYPE_LIST.filter(item =>
                Boolean(COMPARE_TYPE_LIST_CUR_DAY.find(v => item.value === v)),
              );
            }
            return (
              <Form.Item
                name={[field.name, 'custom_rule_config', 'compare_type'] as any}
                required
                rules={[{ required: true, message: '请选择对比方式' }]}
              >
                <Select placeholder="请选择对比方式" disabled={disabled}>
                  {(options || []).map(option => (
                    <Select.Option key={option.value} value={option.value}>
                      <Tooltip placement="left" title={option.label}>
                        {option.label}
                      </Tooltip>
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            );
          }}
        </Form.Item>
        {/* 运算符 */}
        <Form.Item name={[field.name, 'op'] as any} required rules={[{ required: true, message: '请选择运算符' }]}>
          <Select placeholder="请选择运算符" options={OP_LIST} disabled={disabled} />
        </Form.Item>
        {/* 阈值 */}
        <Form.Item
          noStyle
          shouldUpdate={(prevValues, currentValues) => {
            return (
              get(prevValues, [field.name, 'custom_rule_config', 'compare_type']) !==
              get(currentValues, [field.name, 'custom_rule_config', 'compare_type'])
            );
          }}
        >
          {({ getFieldValue }) => {
            const compareType = getFieldValue([...namePrefix, field.name, 'custom_rule_config', 'compare_type']);
            if (COMPARE_RATE_TYPE_LIST.includes(compareType)) {
              return (
                <Form.Item
                  name={[field.name, 'value'] as any}
                  required
                  rules={[{ required: true, message: '请输入阈值' }]}
                >
                  <PercentInput placeholder="请输入阈值" disabled={disabled} />
                </Form.Item>
              );
            }
            return (
              <Form.Item
                name={[field.name, 'value'] as any}
                required
                rules={[{ required: true, message: '请输入阈值' }]}
              >
                <InputNumber placeholder="请输入阈值" disabled={disabled} />
              </Form.Item>
            );
          }}
        </Form.Item>
      </div>
      {/* 过滤条件 */}

      <Form.Item name={[field.name, 'custom_rule_config', 'condition'] as any}>
        <Form.Item label="过滤条件" style={{ marginBottom: 8, marginTop: 8 }} />
        {ruleItemContextValue?.usePrettyRule ? (
          <>
            {/* <Form.Item name={[field.name, 'logic'] as any} initialValue="and">
              <InsightFilterLogic />
            </Form.Item> */}
            <Form.Item name={[field.name, 'alert_pretty_rule'] as any}>
              <InsightFilterForm />
            </Form.Item>
          </>
        ) : (
          <Form.List name={[field.name, 'custom_rule_config', 'condition', 'conditions'] as any}>
            {(fields, { add, remove }) => (
              <>
                <LogicalContainer
                  logicalCode={
                    form.getFieldValue([...namePrefix, field.name, 'custom_rule_config', 'condition', 'logic']) === 'or'
                      ? LogicalCode.OR
                      : LogicalCode.AND
                  }
                  spaceSize={17}
                  enableSwitch
                  handleSwitch={nextLogic => {
                    form.setFields(
                      fields
                        .map(({ name: fieldName }) => ({
                          name: [
                            ...namePrefix,
                            field.name,
                            'custom_rule_config',
                            'condition',
                            'conditions',
                            fieldName,
                            'logic',
                          ],
                          value: nextLogic === LogicalCode.AND ? 'and' : 'or',
                        }))
                        .concat({
                          name: [...namePrefix, field.name, 'custom_rule_config', 'condition', 'logic'],
                          value: nextLogic === LogicalCode.AND ? 'and' : 'or',
                        }),
                    );
                  }}
                >
                  {fields.map((filterField, index) => {
                    const currentValues: IndicatorNodeValueCondition[] = form.getFieldValue([
                      ...namePrefix,
                      field.name,
                      'custom_rule_config',
                      'condition',
                      'conditions',
                    ]);

                    // 当当前选项为默认条件时，禁止操作当前选项
                    const isDefault = defaultFilterCondition?.conditions?.some(
                      v => v.common_condition?.dimension === currentValues[index]?.common_condition?.dimension,
                    );

                    return (
                      <FilterItem
                        namePrefix={
                          [...namePrefix, field.name, 'custom_rule_config', 'condition', 'conditions'] as string[]
                        }
                        key={filterField.key}
                        form={form}
                        field={filterField}
                        disabled={isDefault || disabled}
                        removeFilter={() => {
                          remove(index);
                        }}
                        dimensions={dimensions.map(dimension => ({
                          ...dimension,
                          disabled:
                            currentValues?.some(v => v?.common_condition?.dimension === dimension.value) ?? false,
                        }))}
                      />
                    );
                  })}
                </LogicalContainer>
                <Button
                  className={styles.add_button}
                  type="link"
                  disabled={disabled}
                  block
                  icon={<AddIcon />}
                  onClick={() => {
                    // condition_type 写死0，暂时先支持一般过滤条件
                    add({ logic: 'and', condition_type: 0 } as Partial<IndicatorNodeValueCondition>);
                  }}
                >
                  添加过滤规则
                </Button>
              </>
            )}
          </Form.List>
        )}
      </Form.Item>
    </SimplePanel>
  );
};
