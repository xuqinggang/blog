import React from 'react';

import { Col, Row, Select } from '@ecom/auxo';

interface InsightFilterFormProps {
  value?: string;
  onChange?(v: string): void;
}

const LOGIC_OPTIONS = [
  {
    label: '且',
    value: 'and',
  },
  {
    label: '或',
    value: 'or',
  },
];

const InsightFilterLogic = (props: InsightFilterFormProps) => {
  const { onChange, value } = props;
  return (
    <Row>
      <Col span={3}>
        <div
          style={{
            color: '#898b8f',
            display: 'flex',
            flexDirection: 'row-reverse',
            lineHeight: '32px',
            marginRight: 17,
            fontSize: 14,
          }}
        >
          <span>逻辑关系</span>
        </div>
      </Col>
      <Col span={21}>
        <Select placeholder="请选择逻辑关系" options={LOGIC_OPTIONS} value={value} onChange={onChange} />
      </Col>
    </Row>
  );
};

export default InsightFilterLogic;
