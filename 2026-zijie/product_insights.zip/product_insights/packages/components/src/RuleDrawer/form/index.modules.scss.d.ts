declare namespace IndexModulesScssNamespace {
  export interface IIndexModulesScss {
    addButton: string;
    add_button: string;
    filterFormItem: string;
    filter_form_item: string;
    ruleFormItem: string;
    rule_form_item: string;
    subtitle: string;
  }
}

declare const IndexModulesScssModule: IndexModulesScssNamespace.IIndexModulesScss & {
  /** WARNING: Only available when `css-loader` is used without `style-loader` or `mini-css-extract-plugin` */
  locals: IndexModulesScssNamespace.IIndexModulesScss;
};

export = IndexModulesScssModule;
