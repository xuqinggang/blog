import React from 'react';
import { get } from 'lodash-es';

import {
  Button,
  Form,
  Icon,
  Input,
  InputNumber,
  InputNumberProps,
  InputTag,
  InputTagProps,
  Select,
  SelectProps,
  Space,
  Tooltip,
} from '@ecom/auxo';
import { FormListFieldData } from '@ecom/auxo/es/components/form';
import { AddIcon, DeleteIcon } from '@ecom/auxo/es/components/icon';
import { FormInstance } from '@ecom/auxo/lib/components/form/component/Form';

import { RuleFormValue, SelectOption } from '../type';

import { AlertProdStatusRuleIndicator } from '~/api/product/namespaces/analysis_pool_alert_rule';

interface RuleExpressionProps {
  form: FormInstance<RuleFormValue>;
  namePrefix: string[];
  indicatorList?: AlertProdStatusRuleIndicator[];
  field: FormListFieldData;
  disabled?: boolean;
  remove: () => void;
}

interface ProdStatusRuleProps {
  form: FormInstance<RuleFormValue>;
  indicatorList?: AlertProdStatusRuleIndicator[];
  disabled?: boolean;
}

const OP_OPTIONS = [
  {
    label: '>',
    value: '>',
  },
  {
    label: '>=',
    value: '>=',
  },
  {
    label: '<',
    value: '<',
  },
  {
    label: '<=',
    value: '<=',
  },
  {
    label: '=',
    value: '=',
  },
];

const SingleSelectWrapper = (props: SelectProps<any[]>) => {
  const { onChange, value: propsValue, ...restProps } = props;
  const value = React.useMemo(() => {
    if (!propsValue || !propsValue?.length) {
      return undefined;
    }
    return propsValue[0];
  }, [propsValue]);
  const handleChange = React.useCallback(
    (value, option) => {
      onChange?.([value], option);
    },
    [onChange],
  );
  return <Select {...restProps} onChange={handleChange} value={value} />;
};

const SingleInputNumberWrapper = (
  props: {
    onChange?: (value: string[]) => void;
    value?: string[];
  } & Exclude<InputNumberProps, 'value' | 'onChange'>,
) => {
  const { onChange, value: propsValue, ...restProps } = props;
  const value = React.useMemo(() => {
    if (!propsValue || !propsValue?.length) {
      return undefined;
    }
    return Number(propsValue[0]);
  }, [propsValue]);
  const handleChange = React.useCallback(
    value => {
      onChange?.([String(value)]);
    },
    [onChange],
  );
  return <InputNumber {...restProps} onChange={handleChange} value={value} />;
};

const InputTagWrapper = (
  props: {
    onChange?: (value: string[]) => void;
    value?: string[];
  } & Exclude<InputTagProps, 'value' | 'onChange'>,
) => {
  const { onChange, value: propsValue, ...restProps } = props;
  const value = React.useMemo(() => {
    if (!propsValue || !propsValue?.length) {
      return undefined;
    }
    return propsValue.map(item => ({
      value: item,
      label: item,
    }));
  }, [propsValue]);
  const handleChange = React.useCallback(
    (value: InputTagProps['value']) => {
      onChange?.(value ? value.map(item => item.value) : []);
    },
    [onChange],
  );
  return <InputTag {...restProps} onChange={handleChange} value={value} />;
};

const RuleExpression = (props: RuleExpressionProps) => {
  const { form, namePrefix, field, indicatorList, disabled, remove } = props;
  const indicatorOptions = React.useMemo<(SelectOption & { tips?: string })[]>(() => {
    if (!indicatorList) {
      return [];
    }
    return indicatorList.map(item => ({
      value: item.indicator || '',
      label: item.name || '',
      tips: item?.tips,
    }));
  }, [indicatorList]);
  const handleChangeIndicator = React.useCallback(() => {
    form.setFields([
      {
        name: [...namePrefix, field.name, 'op'],
        value: '',
      },
      {
        name: [...namePrefix, field.name, 'value'],
        value: undefined,
      },
    ]);
  }, [field.name, form, namePrefix]);
  return (
    <Space align="start">
      {/* 指标 */}
      <Form.Item
        noStyle
        shouldUpdate={(prevValues, currentValues) => {
          return get(prevValues, [...namePrefix]) !== get(currentValues, [...namePrefix]);
        }}
      >
        {({ getFieldValue }) => {
          const rules = getFieldValue([...namePrefix]);
          const indicatorOptionsFilter = indicatorOptions?.map(item => {
            return {
              ...item,
              label:
                item?.tips && item?.label ? (
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    <Tooltip title={item?.tips} placement="top">
                      <Icon.DoubtIcon />
                    </Tooltip>
                    <div style={{ marginLeft: 2 }}>{item?.label}</div>
                  </div>
                ) : (
                  item?.label || item?.value
                ),
              disabled: rules.some((rule: { indicator: string }) => rule.indicator === item.value),
            };
          });
          return (
            <Form.Item
              name={[field.name, 'indicator'] as any}
              required
              rules={[{ required: true, message: '请选择指标' }]}
            >
              <Select
                style={{ width: 160 }}
                placeholder="请选择指标"
                options={indicatorOptionsFilter}
                onChange={handleChangeIndicator}
                disabled={disabled}
              />
            </Form.Item>
          );
        }}
      </Form.Item>
      {/* op */}
      <Form.Item
        noStyle
        shouldUpdate={(prevValues, currentValues) => {
          return get(prevValues, [field.name, 'indicator']) !== get(currentValues, [field.name, 'indicator']);
        }}
      >
        {({ getFieldValue }) => {
          const indicator = getFieldValue([...namePrefix, field.name, 'indicator']);
          const indicatorConfig = indicatorList?.find(item => indicator === item?.indicator);
          if (indicatorConfig?.show_type === 'threshold_input') {
            return (
              <Form.Item
                name={[field.name, 'op'] as any}
                required
                rules={[{ required: true, message: '请选择操作符' }]}
              >
                <Select style={{ width: 140 }} placeholder="请选择操作符" options={OP_OPTIONS} disabled={disabled} />
              </Form.Item>
            );
          }
          return null;
        }}
      </Form.Item>
      {/* 值 */}
      <Form.Item
        noStyle
        shouldUpdate={(prevValues, currentValues) => {
          return get(prevValues, [field.name, 'indicator']) !== get(currentValues, [field.name, 'indicator']);
        }}
      >
        {({ getFieldValue }) => {
          const indicator = getFieldValue([...namePrefix, field.name, 'indicator']);
          const indicatorConfig = indicatorList?.find(item => indicator === item?.indicator);
          if (
            indicatorConfig?.show_type &&
            ['single_select', 'bool_single_select'].includes(indicatorConfig?.show_type)
          ) {
            return (
              <Form.Item
                name={[field.name, 'value'] as any}
                required
                rules={[{ required: true, message: '请输入配置值' }]}
              >
                <SingleSelectWrapper
                  style={{ width: 348 }}
                  placeholder="请选择配置值"
                  options={indicatorConfig?.options?.map(item => ({
                    label: item?.name || '',
                    value: item?.code || '',
                  }))}
                  disabled={disabled}
                />
              </Form.Item>
            );
          }
          if (indicatorConfig?.show_type && ['threshold_input'].includes(indicatorConfig?.show_type)) {
            return (
              <Form.Item
                name={[field.name, 'value'] as any}
                required
                rules={[{ required: true, message: '请输入配置值' }]}
              >
                <SingleInputNumberWrapper style={{ width: 200 }} placeholder="请输入配置值" disabled={disabled} />
              </Form.Item>
            );
          }
          if (indicatorConfig?.show_type && ['input_tag'].includes(indicatorConfig?.show_type)) {
            return (
              <Form.Item
                name={[field.name, 'value'] as any}
                required
                rules={[{ required: true, message: '请输入配置值' }]}
              >
                <InputTagWrapper style={{ width: 348 }} disabled={disabled} />
              </Form.Item>
            );
          }
          if (indicatorConfig?.show_type && ['multi_select'].includes(indicatorConfig?.show_type)) {
            return (
              <Form.Item
                name={[field.name, 'value'] as any}
                required
                rules={[{ required: true, message: '请输入配置值' }]}
              >
                <Select
                  style={{ width: 348 }}
                  mode="multiple"
                  placeholder="请选择配置值"
                  options={indicatorConfig?.options?.map(item => ({
                    label: item?.name || '',
                    value: item?.code || '',
                  }))}
                  disabled={disabled}
                />
              </Form.Item>
            );
          }
          return (
            <Form.Item
              name={[field.name, 'value'] as any}
              required
              rules={[{ required: true, message: '请输入配置值' }]}
            >
              <Input style={{ width: 200 }} placeholder="请输入配置值" disabled />
            </Form.Item>
          );
        }}
      </Form.Item>
      {/* 删除 */}
      <Button
        style={{ alignSelf: 'self-start', marginTop: 8 }}
        type="text"
        onClick={remove}
        icon={<DeleteIcon />}
        disabled={disabled}
      />
    </Space>
  );
};

const ProdStatusRule = (props: ProdStatusRuleProps) => {
  const { form, indicatorList, disabled } = props;
  return (
    <Form.List name={['alertProductStatusRule', 'rules'] as any}>
      {(fields, { add, remove }) => (
        <Space direction="vertical" align="start">
          {fields.map((field, index) => {
            return (
              <RuleExpression
                form={form}
                key={field.key}
                namePrefix={['alertProductStatusRule', 'rules'] as any}
                field={field}
                remove={() => {
                  remove(index);
                }}
                indicatorList={indicatorList}
                disabled={disabled}
              />
            );
          })}
          <Button
            type="link"
            block
            icon={<AddIcon />}
            onClick={() => {
              add({});
            }}
            disabled={disabled}
          >
            添加规则
          </Button>
        </Space>
      )}
    </Form.List>
  );
};

export default ProdStatusRule;
