import React, { useMemo, useState } from 'react';

import { Button, Form, InputTag, Select } from '@ecom/auxo';
import { FormListFieldData } from '@ecom/auxo/es/components/form';
import { DeleteIcon } from '@ecom/auxo/es/components/icon';
import { FormInstance } from '@ecom/auxo/lib/components/form/component/Form';

import { RuleFormValue, SelectOption } from '../type';

import styles from './index.module.scss';

import { SelectValue } from '~/api/product/namespaces/analysis_pool_alert_rule';

interface FilterItemProps {
  namePrefix: string[];
  form: FormInstance<RuleFormValue>;
  field: FormListFieldData;
  disabled?: boolean;
  removeFilter: () => void;
  dimensions: Array<
    SelectValue & {
      disabled?: boolean;
    }
  >;
}

export const FilterItem = (props: FilterItemProps) => {
  const [selectedDimension, setSelectedDimension] = useState(''); // 选中的过滤维度
  const { namePrefix, form, field, disabled, removeFilter, dimensions } = props;

  const filterOptions = useMemo<SelectOption[]>(() => {
    if (!selectedDimension) {
      return [];
    }

    const dimension = dimensions.find(({ value }) => value === selectedDimension);
    if (!dimension?.support_ops) {
      return [];
    }

    return dimension.support_ops.map(item => ({
      label: item,
      value: item,
    }));
  }, [dimensions, selectedDimension]);

  return (
    <div className={styles.filter_form_item}>
      {/* 过滤维度 */}
      <Form.Item
        name={[field.name, 'common_condition', 'dimension'] as any}
        required
        rules={[{ required: true, message: '请选择过滤维度' }]}
      >
        <Select
          style={{ alignSelf: 'self-start' }}
          placeholder="请选择过滤维度"
          options={dimensions
            .filter(({ value }) => value !== '__nil__')
            .map(({ name, value, disabled: _disabled }) => ({ label: name, value, disabled: _disabled }))}
          disabled={disabled}
          onSelect={value => {
            setSelectedDimension(value as string);
          }}
        />
      </Form.Item>
      {/* 过滤条件判断 */}
      <Form.Item
        name={[field.name, 'common_condition', 'op'] as any}
        required
        rules={[{ required: true, message: '请选择过滤条件判断' }]}
      >
        <Select
          style={{ alignSelf: 'self-start' }}
          placeholder="请选择过滤条件"
          options={filterOptions}
          disabled={disabled}
        />
      </Form.Item>
      {/* 关键词 */}
      <Form.Item
        name={[field.name, 'common_condition', 'values'] as any}
        required
        rules={[
          {
            validator(_, value: string[] | undefined, callback) {
              if (!value?.length) {
                callback('请输入至少一个关键词');
                return;
              }

              callback();
            },
          },
        ]}
      >
        <InputTag
          limit={1000}
          placeholder="请输入关键词，支持批量粘贴，请用英文逗号、空格、回车隔开，最多支持1000个ID"
          mode="single"
          disabled={disabled}
          onChange={(_, stringValue) => {
            form.setFields([
              {
                name: [...namePrefix, field.name, 'common_condition', 'values'],
                value: stringValue,
              },
            ]);
          }}
        />
      </Form.Item>
      {/* 删除 */}
      <Button
        style={{ alignSelf: 'self-start' }}
        type="text"
        disabled={disabled}
        onClick={removeFilter}
        icon={<DeleteIcon />}
      />
    </div>
  );
};
