/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable max-lines-per-function */
/* eslint-disable @ecom/security-link-opener */
import React, { useCallback, useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { get } from 'lodash-es';

import {
  Button,
  Form,
  FormInstance,
  Input,
  InputNumber,
  InputTag,
  Select,
  Space,
  Spin,
  Switch,
  TimePicker,
} from '@ecom/auxo';
import { AddIcon } from '@ecom/auxo/es/components/icon';
import { PeopleSelect } from '@ecop/user';

import LogicalContainer from '../component/logical-container';
import {
  eventType2BizType,
  eventType2Tooltip,
  INTERVAL_DAY_LIST,
  PRIORITY_LIST,
  PUSH_FREQUENCY_LIST,
} from '../constant';
import { RuleItemContext } from '../context';
import { filterNoValueConvertedRule, transformRule2Form } from '../transform';
import { DrawerActionType, HiddenRule, LogicalCode, RuleFormValue } from '../type';

import ProdStatusRule from './prod-status-rule';
import { RuleItem } from './rule-item';

import styles from './index.module.scss';

import { productClient } from '~/api';
import {
  AlertEventTypeItem,
  AlertProdStatusRuleIndicator,
  ArcticAlertIndicator,
  ConvertToAlertRuleResp,
  GetAlertProdStatusRuleIndicatorResp,
  GetAnalysisPoolAlertDimensionsResp,
  GetAnalysisPoolAlertIndicatorsResp,
  GetAnalysisPoolAlertRuleDetailData,
  IndicatorNodeValueCondition,
  Rule,
  SelectValue,
} from '~/api/product/namespaces/analysis_pool_alert_rule';
import {
  BizType,
  DataReadyTime,
  GetDataReadyTimeResponse,
  GetDimensionListData,
  GetDimensionListResponse,
  GetProductAnalysisTargetMetaListResponse,
  ProductAnalysisBaseStruct,
  TargetMetaInfo,
} from '~/api/product/namespaces/dimensions';
import PoolSelect from '~/PoolSelect';

interface RuleFormProps {
  form: FormInstance<RuleFormValue>;
  eventTypes: AlertEventTypeItem[];
  drawerActionType: DrawerActionType;
  ruleDetail: GetAnalysisPoolAlertRuleDetailData | null;
  defaultValue?: Partial<RuleFormValue>;
  hiddenRule?: HiddenRule; // 需要被隐藏的规则，不显示，但是仍然起作用
  baseStruct?: ProductAnalysisBaseStruct; // 货盘规则
  isTotal?: boolean; // 是否为整体数据
  autoCreatePool?: boolean; // 自动创建货盘
}

const DIMENSION_CACHE_KEY_PREFIX = 'INSIGHT_CACHE_DIMENSION_V2';

// 获取商品状态监控指标列表
const getAlertProdStatusRuleIndicator = async function () {
  try {
    const { data }: GetAlertProdStatusRuleIndicatorResp = await productClient.GetAlertProdStatusRuleIndicator();
    if (data) {
      return data.indicator_list;
    }
    return undefined;
  } catch (e) {
    console.error('getAlertProdStatusRuleIndicator error', e);
    return undefined;
  }
};

// 获取货品分析业务指标列表
const getProductInsightsTargetMetaList = async function (bizType: BizType) {
  try {
    const { data }: GetProductAnalysisTargetMetaListResponse = await productClient.GetProductAnalysisTargetMetaList({
      biz_type: bizType,
    });
    if (data) {
      return data;
    }
    return undefined;
  } catch (e) {
    console.error('getProductInsightsTargetMetaList error', e);
    return undefined;
  }
};

// 获取货品分析表readyTime
const getProductInsightsReadyTime = async function (bizType: BizType) {
  try {
    const { data }: GetDataReadyTimeResponse = await productClient.GetReadyTime({ biz_type: bizType });
    if (data) {
      return data;
    }
    return undefined;
  } catch (e) {
    console.error('Get ready time error', e);
    return undefined;
  }
};
// 获取货品分析维度列表
const getProductInsightsDimensionData = async function (bizType: BizType) {
  try {
    // 默认从localStorage里面获取dimension
    const cacheKey = `${DIMENSION_CACHE_KEY_PREFIX}_${bizType}`;
    const { timeStamp = 0, data } = JSON.parse(localStorage.getItem(cacheKey) ?? '{}');
    const isOutDate = dayjs(timeStamp).add(1, 'd').isBefore(dayjs()); // 缓存过期时间为1d

    let dimData: GetDimensionListData | undefined;
    if (!isOutDate && data) {
      // 缓存未过期
      dimData = data;
    } else {
      const { data: resData }: GetDimensionListResponse = await productClient.GetDimensionList({
        biz_type: bizType,
      });

      if (resData) {
        dimData = resData;

        // 更新缓存
        localStorage.setItem(cacheKey, JSON.stringify({ timeStamp: dayjs().toString(), data: resData }));
      }
    }
    return dimData;
  } catch (e) {
    console.error('Get dimension error', e);
    return undefined;
  }
};

// 获取预警维度列表
const getDimensions = async function (eventType: string) {
  try {
    const { data }: GetAnalysisPoolAlertDimensionsResp = await productClient.GetAnalysisPoolAlertDimensions({
      event_type: eventType,
    });
    if (data?.dimensions) {
      return data.dimensions;
    }
  } catch (e) {
    console.error('Get dimensions error', e);
  }
  return undefined;
};

// 获取指标列表
const getIndicators = async function (eventType: string) {
  try {
    const { data }: GetAnalysisPoolAlertIndicatorsResp = await productClient.GetAnalysisPoolAlertIndicators({
      event_type: eventType,
      data_source_type: 1,
    }); // 默认是离线数据

    if (data?.indicators) {
      return data.indicators;
    }
  } catch (e) {
    console.error('Get indicators error', e);
  }
  return undefined;
};

export const RuleForm = (props: RuleFormProps) => {
  const [formLoading, setFormLoading] = useState(false); // 当在获取表单数据的时候显示loading效果
  const [selectEventType, setSelectEventType] = useState(''); // 选中的数据源
  const [insightReadyTime, setInsightReadyTime] = useState<DataReadyTime | undefined>(undefined); // 货品分析数据readyTime
  const [insightDimData, setInsightDimData] = useState<GetDimensionListData | undefined>(undefined); // 货品分析维度列表
  const [insightTargetMetaList, setInsightTargetMetaList] = useState<TargetMetaInfo[] | undefined>(undefined); // 货品分析维度信息列表
  const [prodStatusIndicatorList, setProdStatusIndicatorList] = useState<AlertProdStatusRuleIndicator[] | undefined>(
    undefined,
  ); // 商品状态监控指标列表
  const [selectDimensions, setSelectDimensions] = useState<string[]>([]); // 选中的监控维度
  const [dimensions, setDimensions] = useState<SelectValue[]>([]);
  const [indicators, setIndicators] = useState<ArcticAlertIndicator[]>([]);
  // 默认的筛选条件
  const [defaultFilterCondition, setDefaultFilterCondition] = useState<IndicatorNodeValueCondition | null>(null);
  const {
    form,
    eventTypes,
    drawerActionType,
    ruleDetail,
    defaultValue: _defaultValue,
    hiddenRule: _hiddenRule,
    baseStruct,
    isTotal,
    autoCreatePool,
  } = props;
  const defaultValue = React.useMemo(() => {
    if (drawerActionType === DrawerActionType.CREATE) {
      return {
        ...(_defaultValue || {}),
        // 默认取用增大盘底池的数据源
        eventType: _defaultValue?.eventType ?? 'app_product_insight_usr_prod_scenario_flow_trd_stats_new_di_arctic',
      };
    }
    return _defaultValue;
  }, [_defaultValue, drawerActionType]);

  const isAlertPrettyRule = React.useMemo(() => {
    const rules = ruleDetail?.ruleData?.rule?.rule?.rules;
    if (!rules?.length) {
      return Boolean(
        ruleDetail?.ruleData?.rule?.rule?.alert_pretty_rule || ruleDetail?.ruleData?.rule?.rule?.alert_indicator,
      );
    } else {
      return rules.every(item => Boolean(item?.alert_pretty_rule || item?.alert_indicator));
    }
  }, [ruleDetail]);

  const isUsePrettyRule = React.useMemo(() => {
    return !Boolean(!isAlertPrettyRule && drawerActionType !== DrawerActionType.CREATE);
  }, [isAlertPrettyRule, drawerActionType]);

  const bizType = React.useMemo(() => {
    return baseStruct?.biz_type ?? eventType2BizType[selectEventType as keyof typeof eventType2BizType];
  }, [baseStruct, selectEventType]);

  const [hiddenRule, setHiddenRule] = useState(_hiddenRule);

  const disabled = drawerActionType === DrawerActionType.PREVIEW;

  const disabledPool = React.useMemo(() => {
    return disabled || Boolean(drawerActionType === DrawerActionType.CREATE && defaultValue?.poolId);
  }, [defaultValue?.poolId, disabled, drawerActionType]);

  const initForm = useCallback(async () => {
    setFormLoading(true);

    if (
      (drawerActionType === DrawerActionType.PREVIEW ||
        drawerActionType === DrawerActionType.EDIT ||
        drawerActionType === DrawerActionType.COPY) &&
      ruleDetail
    ) {
      // 预览/更新/复制任务
      const formValues = await transformRule2Form(ruleDetail);
      const { eventType, pushFrequency } = formValues;
      if (eventType) {
        setSelectEventType(eventType);
      }

      if (pushFrequency?.time_type !== undefined && pushFrequency.time_type === 0) {
        // 即使没有配置「推送频率」，服务端会默认下发time_type，值为0，需要进行过滤
        delete formValues.pushFrequency;
      }

      // 设置选中dimensions
      if (formValues.dimensions?.length) {
        setSelectDimensions(formValues.dimensions);
      }

      if (drawerActionType === DrawerActionType.COPY && defaultValue?.admins) {
        formValues.admins = defaultValue?.admins;
      }

      if (drawerActionType === DrawerActionType.COPY && defaultValue?.receiveUsers) {
        formValues.receiveUsers = defaultValue?.receiveUsers;
      }

      if (defaultValue?.poolId) {
        formValues.poolId = defaultValue?.poolId;
      }

      // 设置选中的数据源
      form.setFieldsValue(formValues);
    } else if (drawerActionType === DrawerActionType.CREATE) {
      if (defaultValue?.eventType) {
        setSelectEventType(defaultValue.eventType);
      }

      // 新建任务，注意下筛选条件需要等到接口返回
      form.setFieldsValue({
        isAnalyzeProductStatus: true,
        rule: {
          logic: isUsePrettyRule ? 'or' : 'and', // 规则与规则默认的逻辑是and
        },
        ...(defaultValue ?? {}),
      });
    }
    setFormLoading(false);
    // defaultValue 只随着drawerActionType更新的时候更新一次，不作为依赖
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drawerActionType, form, ruleDetail]);

  // 设置表单初始值
  useEffect(() => {
    initForm();
  }, [initForm]);

  // 获取维度、指标列表
  useEffect(() => {
    if (!selectEventType) {
      return;
    }

    // 数据来源更新需要显隐是否展示商品状态

    // @ts-ignore
    if (eventType2BizType[selectEventType] !== BizType.GreatValueBuy && baseStruct) {
      setHiddenRule(prev => ({ ...prev, isAnalyzeProductStatus: true }));
      form.setFieldsValue({
        isAnalyzeProductStatus: false,
      });
    } else {
      setHiddenRule(prev => ({ ...prev, isAnalyzeProductStatus: false }));
    }

    // 随着selectEventType的更改初始化相关的表单数据
    (async function initRelatedData() {
      setFormLoading(true);
      try {
        // 获取货品分析readyTime
        const readyTime = await getProductInsightsReadyTime(bizType);
        if (readyTime) {
          setInsightReadyTime(readyTime);
        }
        // 获取货品分析维度列表
        const dimData = await getProductInsightsDimensionData(bizType);
        if (dimData) {
          setInsightDimData(dimData);
        }
        // 获取货品分析指标列表
        const targetMetaList = await getProductInsightsTargetMetaList(bizType);
        if (targetMetaList) {
          setInsightTargetMetaList(targetMetaList);
        }
        // 获取货品分析指标列表
        const prodStatusIndicatorList = await getAlertProdStatusRuleIndicator();
        if (prodStatusIndicatorList) {
          setProdStatusIndicatorList(prodStatusIndicatorList);
        }

        // 获取维度相关数据
        const _dimensions = await getDimensions(selectEventType);
        if (_dimensions) {
          setDimensions(_dimensions);
          // 当更新dimension数据后，更新默认值，设置【监控维度】的默认值
          if (_dimensions.length && !form.getFieldValue('dimensions')?.length) {
            // 存在商品id维度时默认选中维度：商品id
            const defaultDimensions = _dimensions
              .filter(
                ({ support_group_by, value }) => support_group_by && (value === 'prod_id' || value === 'prod_name'),
              )
              .map(({ value }) => value);

            if (defaultDimensions.length) {
              form.setFieldsValue({
                dimensions: defaultDimensions,
              });
              setSelectDimensions(defaultDimensions);
            }
          }
        }

        // 获取监控指标
        const _indicators = await getIndicators(selectEventType);
        _indicators && setIndicators(_indicators);

        // 获取默认的筛选条件
        const { data } = await (baseStruct && !isUsePrettyRule
          ? productClient.ConvertToAlertRule({
              // @ts-ignore
              biz_type,
              base_struct: baseStruct,
              // @ts-ignore 服务端还没更新bam
              is_total: isTotal,
            })
          : Promise.resolve({} as ConvertToAlertRuleResp));

        setDefaultFilterCondition(filterNoValueConvertedRule(data ?? null));
      } catch (err) {
        console.log(err);
      } finally {
        setFormLoading(false);
      }
    })();
  }, [selectEventType, baseStruct, form, isTotal, bizType, isUsePrettyRule]);

  useEffect(() => {
    // 初始化/更新默认筛选条件数据后添加默认规则
    if (drawerActionType === DrawerActionType.CREATE) {
      console.log('设置默认规则', form.getFieldValue('rule'));
      form.setFieldsValue({
        rule: {
          logic: 'or',
          rules: [
            {
              rule_name: `规则${1}`, // 规则名称，默认是「规则x」
              op: '>=', // 运算符，默认是「>=」
              value: 100, // 阈值，默认是「100」
              custom_rule_config: {
                id: String(1), // rpc接口必填值，需要保证不重复
                time_type: 1, // 统计周期，默认是「今日累计」
                compare_type: 1, // 告警统计值和阈值对比方式，默认是「绝对值」
                indicator: {
                  indicator_type: 1, // 指标类型，默认是「基础类型指标」
                  left_node: { indicator_type: 0 },
                  right_node: { indicator_type: 0 },
                },
                /**
                 * 最后转换formData的时候需要处理
                 * - 如果condition下面的conditions为空，删除condition
                 * - 如果conditions只有一个元素，将其合并到condition
                 */
                condition: defaultFilterCondition ?? {
                  logic: '', // 默认是and
                  condition_type: -1, // 默认是-1，0:一般过滤条件 1:自定义过滤条件 2:关键词过滤条件
                },
              },
            } as Partial<Rule>,
          ],
        },
      });
    }
  }, [drawerActionType, defaultFilterCondition, form]);

  return (
    <Spin spinning={formLoading} tip="正在加载数据">
      <RuleItemContext.Provider
        value={{
          insightReadyTime,
          insightDimData,
          insightTargetMetaList,
          bizType,
          usePrettyRule: isUsePrettyRule,
        }}
      >
        <Form<RuleFormValue>
          form={form}
          labelCol={{ span: 3 }}
          wrapperCol={{ span: 21 }}
          labelAlign="left"
          layout="horizontal"
          initialValues={{}}
        >
          <div className={styles.subtitle}>基本信息</div>
          {/* 任务名称 */}
          <Form.Item name="ruleName" label="任务名称" required rules={[{ required: true, message: '请输入任务名称' }]}>
            <Input placeholder="请输入任务名称" disabled={disabled} />
          </Form.Item>
          {/* 任务描述 */}
          <Form.Item name="ruleDesc" label="任务描述">
            <Input placeholder="请输入任务描述" disabled={disabled} />
          </Form.Item>
          {/* 任务等级 */}
          <Form.Item name="priority" label="任务等级">
            <Select options={PRIORITY_LIST} placeholder="请选择任务等级" disabled={disabled} />
          </Form.Item>
          {/* 管理员 */}
          <Form.Item
            name="admins"
            label="管理员"
            required
            rules={[
              {
                validator(_, value: string[] | undefined, callback) {
                  if (!value?.length) {
                    callback('请选择至少一名管理员');
                    return;
                  }

                  callback();
                },
              },
            ]}
          >
            <PeopleSelect disabled={disabled} placeholder="请输入任务的管理人" showEmail allowClear mode="multiple" />
          </Form.Item>
          <div className={styles.subtitle}>触发配置</div>
          {/* 数据来源 */}
          <Form.Item
            name="eventType"
            label="数据来源"
            required
            rules={[
              {
                required: true,
                message: '请选择数据来源',
              },
            ]}
            style={{ display: hiddenRule?.eventType ? 'none' : 'block' }}
          >
            <Select
              placeholder="请选择数据来源"
              disabled={disabled}
              options={eventTypes?.map(({ name, code }) => ({ label: name, value: code }))}
              onSelect={value => {
                setSelectEventType(value as string);
              }}
            />
          </Form.Item>
          {/* 监控货盘 */}
          <Form.Item
            name="poolId"
            label="监控货盘"
            required
            rules={
              autoCreatePool
                ? []
                : [
                    {
                      required: true,
                      message: '请选择监控货盘',
                    },
                  ]
            }
            hidden={autoCreatePool ? true : false}
          >
            <PoolSelect disabled={disabledPool} insightDimData={insightDimData} />
          </Form.Item>
          {/* 监控维度 */}
          <Form.Item
            name="dimensions"
            label="监控维度"
            required
            rules={[
              {
                validator(_, value: string[] | undefined, callback) {
                  if (!value?.length) {
                    callback('请选择至少一个监控维度');
                    return;
                  }

                  callback();
                },
              },
            ]}
          >
            <Select
              mode="multiple"
              placeholder="请选择监控维度"
              // disabled={true} // 始终禁用该字段，该字段只允许默认填充
              disabled={disabled}
              onChange={value => {
                setSelectDimensions(value as string[]);
                form.setFieldsValue({ dimensions: value as string[] });
              }}
              options={dimensions
                .filter(({ support_group_by }) => support_group_by)
                .map(({ name, value }) => {
                  let disabledValue = false;
                  if (selectDimensions.length > 0 && value === '__nil__') {
                    disabledValue = selectDimensions.some(item => item !== '__nil__');
                  } else if (selectDimensions.length > 0) {
                    disabledValue = selectDimensions.some(item => item === '__nil__');
                  }
                  return {
                    label: name,
                    value,
                    disabled: disabledValue,
                  };
                })}
            />
          </Form.Item>
          {/* 推送时间 */}
          <Form.Item label="推送时间" required>
            <Space direction="horizontal" size="middle">
              <Form.Item
                style={{ marginBottom: 0 }}
                name={['pushSchedule', 'intervalDayOfWeek'] as any}
                required
                rules={[{ required: true, message: '请选择推送周期' }]}
              >
                <Select placeholder="请选择推送周期" disabled={disabled} options={INTERVAL_DAY_LIST} />
              </Form.Item>
              <Form.Item
                style={{ marginBottom: 0 }}
                name={['pushSchedule', 'intervalTime'] as any}
                required
                rules={[{ required: true, message: '请选择推送周期' }]}
              >
                <TimePicker format="HH:mm" placeholder="请选择时分" disabled={disabled} />
              </Form.Item>
            </Space>
          </Form.Item>
          {/* 触发规则 */}
          <Form.Item label="触发规则" name="rule" required>
            {/* 规则列表 */}
            <Form.List name={['rule', 'rules'] as any}>
              {(fields, { add, remove }) => (
                <>
                  <LogicalContainer
                    logicalCode={form.getFieldValue(['rule', 'logic']) === 'and' ? LogicalCode.AND : LogicalCode.OR}
                    spaceSize={17}
                    enableSwitch={!isUsePrettyRule || bizType === BizType.GuessBoostData}
                    handleSwitch={nextLogic => {
                      form.setFieldsValue({
                        rule: {
                          logic: nextLogic === LogicalCode.AND ? 'and' : 'or',
                        },
                      });
                    }}
                  >
                    {fields.map((field, index) => (
                      <RuleItem
                        namePrefix={['rule', 'rules']}
                        key={field.key}
                        field={field}
                        form={form}
                        disabled={disabled}
                        removeRule={() => {
                          remove(index);
                        }}
                        indicators={indicators}
                        dimensions={dimensions}
                        defaultFilterCondition={null}
                      />
                    ))}
                  </LogicalContainer>
                  <Button
                    className={styles.add_button}
                    type="dashed"
                    disabled={disabled}
                    onClick={() => {
                      add({
                        rule_name: `规则${fields.length + 1}`, // 规则名称，默认是「规则x」
                        op: '>=', // 运算符，默认是「>=」
                        value: 100, // 阈值，默认是「100」
                        custom_rule_config: {
                          id: String(fields.length + 1), // rpc接口必填值，需要保证不重复
                          time_type: 1, // 统计周期，默认是「今日累计」
                          compare_type: 1, // 告警统计值和阈值对比方式，默认是「绝对值」
                          indicator: {
                            indicator_type: 1, // 指标类型，默认是「基础类型指标」
                            left_node: { indicator_type: 0 },
                            right_node: { indicator_type: 0 },
                          },
                          /**
                           * 最后转换formData的时候需要处理
                           * - 如果condition下面的conditions为空，删除condition
                           * - 如果conditions只有一个元素，将其合并到condition
                           */
                          // condition: {
                          //   logic: 'and', // 默认是and
                          //   condition_type: -1, // 默认是-1，0:一般过滤条件 1:自定义过滤条件 2:关键词过滤条件
                          // },
                          condition: defaultFilterCondition,
                        },
                      } as Partial<Rule>);
                    }}
                    block
                    icon={<AddIcon />}
                  >
                    添加规则
                  </Button>
                </>
              )}
            </Form.List>
          </Form.Item>
          {/* 是否监控商品状态*/}
          <Form.Item
            label="是否监控商品状态"
            name="isAnalyzeProductStatus"
            valuePropName="checked"
            labelCol={{ span: 4 }}
            tooltip={eventType2Tooltip[form.getFieldValue('eventType') as string]}
            hidden={hiddenRule?.isAnalyzeProductStatus}
          >
            <Switch disabled={disabled} />
          </Form.Item>
          <Form.Item
            noStyle
            shouldUpdate={(prevValues, currentValues) => {
              return get(prevValues, ['isAnalyzeProductStatus']) !== get(currentValues, ['isAnalyzeProductStatus']);
            }}
          >
            {({ getFieldValue }) => {
              const isAnalyzeProductStatus = getFieldValue(['isAnalyzeProductStatus']);
              if (isAnalyzeProductStatus) {
                return (
                  <Form.Item
                    label="商品状态监控规则"
                    name="alertProductStatusRule"
                    labelCol={{ span: 4 }}
                    hidden={hiddenRule?.isAnalyzeProductStatus}
                  >
                    <ProdStatusRule disabled={disabled} form={form} indicatorList={prodStatusIndicatorList} />
                  </Form.Item>
                );
              }
            }}
          </Form.Item>
          <div className={styles.subtitle}>触达配置</div>
          {/* 推送频率 */}
          <Form.Item label="推送频率">
            <Space direction="horizontal" size="middle">
              <Form.Item style={{ marginBottom: 0 }} name={['pushFrequency', 'time_type'] as any}>
                <Select placeholder="请选择推送频率" disabled={disabled} options={PUSH_FREQUENCY_LIST} />
              </Form.Item>
              <div>最多推送</div>
              <Form.Item style={{ marginBottom: 0 }} name={['pushFrequency', 'max_frequency'] as any}>
                <InputNumber placeholder="请输入最多推送次数" disabled={disabled} />
              </Form.Item>
            </Space>
          </Form.Item>
          {/* 飞书群ID */}
          <Form.Item
            label="飞书群ID"
            name="receiveGroups"
            extra={
              <div>
                请将【笛卡尔系统助手】机器人添加至目标飞书群，以确保能够收到推送消息；支持添加 5 个群，lark群ID查询：
                <a href="https://open.feishu.cn/tool/token?page=1&amp;pageSize=30" target="_blank" rel="noreferrer">
                  点我
                </a>
              </div>
            }
          >
            <InputTag
              limit={5}
              placeholder="请输入飞书群组ID，支持批量粘贴，请用英文逗号、空格、回车隔开，最多支持 5 个群"
              mode="single"
              disabled={disabled}
              onChange={(_, stringValue) => {
                form.setFieldsValue({
                  receiveGroups: stringValue,
                });
              }}
            />
          </Form.Item>
          {/* 飞书用户(employee_id) */}
          <Form.Item label="飞书用户" name="receiveUsers">
            <PeopleSelect
              disabled={disabled}
              placeholder="请输入接受预警的飞书用户"
              showEmail
              allowClear
              mode="multiple"
            />
          </Form.Item>
          {/* 低打扰模式 */}
          <Form.Item
            label="低打扰模式"
            name="lowDisturb"
            valuePropName="checked"
            extra="开启后，若30分钟内已预警，则自动屏蔽预警消息 (高级模式下不影响预警升级)"
          >
            <Switch disabled={disabled} />
          </Form.Item>
        </Form>
      </RuleItemContext.Provider>
    </Spin>
  );
};
