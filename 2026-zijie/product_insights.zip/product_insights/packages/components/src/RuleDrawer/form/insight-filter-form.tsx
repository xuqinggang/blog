import React from 'react';

import { FilterForm as ProductInsightsFilterForm } from '../../filter-form';
import { RuleItemContext } from '../context';

import { BaseStruct, CommonServerFilter } from '~/filter-form/types';

interface InsightFilterFormProps {
  value?: BaseStruct;
  onChange?(v: CommonServerFilter): void;
}

const InsightFilterForm = (props: InsightFilterFormProps) => {
  const { onChange, value } = props;
  const ruleItemContextValue = React.useContext(RuleItemContext);
  const handleChange = React.useCallback(
    (_, v: CommonServerFilter) => {
      onChange && onChange(v);
    },
    [onChange],
  );
  return (
    <ProductInsightsFilterForm
      bizType={ruleItemContextValue.bizType!}
      readyTime={ruleItemContextValue.insightReadyTime}
      dimensionData={ruleItemContextValue.insightDimData}
      showSubTitle={false}
      visible={{
        analysisDate: false,
        compareDate: false,
        drillFilter: false,
        targetFilter: false,
        dimFilter: true,
        ruleFilter: false,
      }}
      baseStruct={value}
      onChange={handleChange}
    />
  );
};

export default InsightFilterForm;
