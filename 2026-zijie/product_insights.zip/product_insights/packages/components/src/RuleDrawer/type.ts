import { Dayjs } from 'dayjs';

import { Int64, PushFrequency, Rule } from '~/api/product/namespaces/analysis_pool_alert_rule';
import { ProductAnalysisBaseStruct } from '~/api/product/namespaces/dimensions';

type OptionKey = string | number;

export interface SelectOption {
  label: string;
  value: OptionKey;
}

// 逻辑语句
export enum LogicalCode {
  AND = 'AND',
  OR = 'OR',
}

export interface PushSchedule {
  intervalDayOfWeek: number; // 每日：8，周一 - 周日：1 - 7
  intervalTime: Dayjs; // 时间
}

export interface RuleFormValue {
  ruleName: string; // 任务名称（必填）
  ruleDesc?: string; // 任务描述
  priority?: Int64; // 任务等级
  admins: string[]; // 管理员邮箱（必填）
  eventType: string; // 数据来源（必填）
  poolId?: string; // 监控货盘
  dimensions: string[]; // 监控维度（必填）
  pushSchedule: PushSchedule; // 推送频率
  rule: Rule; // 触发规则（必填）
  isAnalyzeProductStatus?: boolean; // 是否监控商品状态
  alertProductStatusRule?: string; // 商品状态规则
  pushFrequency?: PushFrequency; // 触达频率控制
  receiveGroups?: string[]; // 推送飞书群ID
  receiveUsers?: string[]; // 推送用户飞书ID
  lowDisturb?: boolean; // 是否开启低打扰模式，默认是false
}

// 需要被隐藏的栏目，目前仅支持数据来源（eventType）隐藏
export type HiddenRule = Pick<
  {
    [key in keyof RuleFormValue]?: boolean;
  },
  'eventType' | 'isAnalyzeProductStatus'
>;

export enum DrawerActionType {
  PREVIEW = 'preview', // 预览
  CREATE = 'create', // 创建
  EDIT = 'edit', // 编辑
  COPY = 'copy', // 编辑
}

export interface IRuleSearchProps {
  pool_id?: string; // 货盘id
}

export interface IFormOptions {
  defaultValue?: Partial<RuleFormValue>;
  hiddenRule?: HiddenRule; // 需要被隐藏的规则，被隐藏的规则不会在表格中显示，但是仍然起作用
  baseStruct: ProductAnalysisBaseStruct; // 货盘结构，内部依赖该字段获取筛选条件
  isTotal?: boolean; // 是否为整体数据
}

export interface IOptions {
  ruleId?: string;
  version?: number;
  poolId: string; // 货盘id，必填
  onClose?: () => void;
  beforeSubmit?: () => Promise<boolean | undefined>; // 提交之前需要执行的额外操作，返回false将会取消后续操作
  afterSubmit?: () => Promise<void>; // 处理提交完成后外部需要的额外操作，例如刷新外部列表、弹出弹窗等
}
