export const COMMON_NODE_TYPE = 'common_node';
