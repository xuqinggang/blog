import {
  createContext,
  PropsWithChildren,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useState,
} from 'react';
import { cloneDeep, merge, noop } from 'lodash-es';

import { Form, FormInstance } from '@ecom/auxo';

import { RecursivePartial } from '~/types';
import { prettyWarn } from '~/utils';

type FormFilterCtxValue<O, T = unknown> = {
  /** 使用的表单实例 */
  form?: FormInstance<O>;
  /** 表单的当前生效值，需要手动set */
  values: O;
  /** 表单的当前生效值， 手动set */
  updateValues: () => void;
  /** 格式化后的表单值 */
  formattedValues?: T | undefined;
  isRoot?: boolean;
};

export const createFormFilterCtx = () =>
  createContext<FormFilterCtxValue<any, unknown>>({
    form: undefined,
    values: {},
    updateValues: noop,
    formattedValues: {},
    isRoot: true,
  });

const defaultFormFilterCtx = createFormFilterCtx();

interface FormFilterCtxProviderProps<O extends Record<string, any> = Record<string, any>, T = unknown> {
  form?: FormInstance<O>;
  formatValues?: (values: O) => T;
  extend?: boolean;
  defaultValues?: RecursivePartial<O>;
  /** 缓存值优先级高于默认值！！！ */
  cacheKey?: string;
  autoUpdate?: boolean;
  FormFilterCtx?: React.Context<FormFilterCtxValue<any, unknown>>;
  onFormValueChange?: (values: O) => void;
}

export const FormFilterCtxProvider = <O extends Record<string, any> = Record<string, any>, T = unknown>({
  children,
  formatValues,
  extend,
  defaultValues,
  cacheKey,
  form: propsForm,
  autoUpdate,
  FormFilterCtx = defaultFormFilterCtx,
  onFormValueChange,
}: PropsWithChildren<FormFilterCtxProviderProps<O, T>>) => {
  const extendValues = useContext(FormFilterCtx)?.values;
  const [values, setValues] = useState<O>({} as O);
  const [innerForm] = Form.useForm<O>();

  const form = propsForm || innerForm;

  const updateValues = useCallback(() => {
    const newValues = cloneDeep(form.getFieldsValue(true));
    setValues(newValues);
    if (cacheKey) {
      localStorage.setItem(cacheKey, JSON.stringify(newValues));
    }
  }, [cacheKey, form]);

  const realValues = useMemo(
    () => (extend ? merge(cloneDeep(extendValues), values) : values),
    [extend, extendValues, values],
  );

  const formattedValues = useMemo(() => {
    try {
      return formatValues?.(realValues);
    } catch (err) {
      prettyWarn('form filter ctx format values error', err);
      return undefined;
    }
  }, [formatValues, realValues]);

  const ctxValue = useMemo<FormFilterCtxValue<O, T>>(() => {
    return {
      form: form,
      values: realValues,
      updateValues,
      formattedValues,
    };
  }, [form, formattedValues, realValues, updateValues]);

  // 在缓存Key发生改变的时候，认为表单的目标发生改变，尝试重设表单数据
  useLayoutEffect(() => {
    let cacheValue;

    try {
      if (cacheKey) {
        const resStr = localStorage.getItem(cacheKey);
        if (resStr) {
          cacheValue = JSON.parse(resStr) as RecursivePartial<O>;
        }
      }
    } catch (err) {
      // _
    }
    const initValue = cacheValue || defaultValues;
    if (initValue) {
      form.setFieldsValue(initValue as any);
      updateValues();
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cacheKey]);

  useEffect(() => {
    updateValues();
  }, [updateValues]);

  return (
    <FormFilterCtx.Provider value={ctxValue}>
      <Form
        form={form}
        onValuesChange={() => {
          const block = onFormValueChange?.(realValues);
          if (block && autoUpdate) {
            updateValues();
          }
        }}
      >
        {children}
      </Form>
    </FormFilterCtx.Provider>
  );
};

export const useFormFilterCtx = <O, T = unknown>(FormFilterCtx = defaultFormFilterCtx) => {
  return useContext(FormFilterCtx) as FormFilterCtxValue<O, T>;
};
