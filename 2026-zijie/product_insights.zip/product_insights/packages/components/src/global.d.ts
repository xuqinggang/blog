interface Window {
  GarfishBridge: Record<string, any>;
}

declare module 'moment' {
  import { Dayjs } from 'dayjs';
  namespace moment {
    type Moment = Dayjs;
  }
  export = moment;
}
declare module 'markdown-it-br' {
  const exportData: any = {};
  export = exportData;
}
