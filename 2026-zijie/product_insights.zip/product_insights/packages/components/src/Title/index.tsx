import classNames from 'classnames';

interface IProps {
  content: string | React.ReactNode;
  type?: 'h1' | 'h2' | 'chart' | 'custom';
  style?: React.CSSProperties;
  className?: string;
}

const Title = (props: IProps): JSX.Element => {
  const { content, style = {}, className = '', type = 'h1' } = props;

  const getDefaultClassName = () => {
    switch (type) {
      case 'h1':
        return 'text-[16px] font-medium text-[#252931] leading-6';
      case 'h2':
        return 'text-[14px] font-medium text-[#252931] leading-5';
      case 'chart':
        return 'text-[14px] text-[#565960] leading-5';
      default:
        return '';
    }
  };

  return (
    <div className={classNames(getDefaultClassName(), className)} style={style}>
      {content}
    </div>
  );
};

export default Title;
