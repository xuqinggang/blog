import { createContext, FC, useContext } from 'react';

export interface EnvCtx {
  openFeelGoodAITask?: () => Promise<void>;
  setFeelGoodUserInfo?: (userInfo: any) => Promise<void>;
  Tea?: any;
}

const envCtx = createContext<EnvCtx>({
  openFeelGoodAITask: undefined,
  setFeelGoodUserInfo: undefined,
  Tea: undefined,
});

export const useInsightEnv = () => useContext(envCtx);
