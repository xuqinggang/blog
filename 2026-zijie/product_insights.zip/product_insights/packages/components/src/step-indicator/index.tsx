import { FC, useState } from 'react';

import { Tooltip } from '@ecom/auxo';
import { FinishBoldIcon } from '@ecom/auxo/es/components/icon';

import LeftActive from './assets/active-left.png';
import RightActive from './assets/active-right.png';
import Left from './assets/left.png';
import Right from './assets/right.png';

const Step: FC<{
  label: string;
  step: number;
  status?: 'active' | 'finish';
  pre?: boolean;
  next?: boolean;
  onClick?: () => void;
}> = ({ label, status, pre, next, step, onClick }) => {
  const active = status === 'active';
  const finish = status === 'finish';
  const bgStyle = {
    backgroundColor: active ? '#4784FF' : '#EBF3FF',
  };
  return (
    <div
      className="h-[32px] flex items-center cursor-pointer flex-1 overflow-hidden"
      onClick={evt => {
        evt.stopPropagation();
        evt.preventDefault();
        onClick?.();
      }}
    >
      {pre ? (
        active ? (
          <img className="h-full !cursor-pointer" src={LeftActive} />
        ) : (
          <img className="h-full !cursor-pointer" src={Left} />
        )
      ) : (
        <div className="w-[16px] h-full rounded-l-[4px]" style={bgStyle} />
      )}
      <div
        className="h-full flex justify-start items-center flex-1 flex-shrink-0 whitespace-nowrap overflow-hidden"
        style={bgStyle}
      >
        <div className="flex justify-center items-center flex-1">
          <div className="flex justify-center items-center text-white bg-[#8CB8FF] rounded-full w-[20px] h-[20px] mr-1">
            {finish ? <FinishBoldIcon /> : step}
          </div>
          <Tooltip title={label}>
            <span
              className="whitespace-nowrap text-ellipsis"
              style={{
                color: active ? 'white' : '#252931',
              }}
            >
              {label}
            </span>
          </Tooltip>
        </div>
      </div>
      {next ? (
        active ? (
          <img className="h-full !cursor-pointer" src={RightActive} />
        ) : (
          <img className="h-full !cursor-pointer" src={Right} />
        )
      ) : (
        <div className="w-[16px] h-full rounded-r-[4px]" style={bgStyle} />
      )}
    </div>
  );
};

export interface StepIndicatorProps {
  steps: string[];
  value: number;
  onChange: (value: number) => void;
}

export const StepIndicator: FC<StepIndicatorProps> = ({ steps, value, onChange }) => {
  return (
    <div className="flex gap-[-2px] items-center overflow-hidden">
      {steps.map((label, idx) => (
        <Step
          key={label}
          label={label}
          step={idx + 1}
          status={idx < value ? 'finish' : idx === value ? 'active' : undefined}
          pre={idx > 0}
          next={idx < steps.length - 1}
          onClick={() => onChange(idx)}
        />
      ))}
    </div>
  );
};

export const Demo = () => {
  const [step, setStep] = useState(0);
  return (
    <div style={{ width: 600 }}>
      <StepIndicator
        steps={['第一步：分析指标', '第二步：策略贡献度评估方法', '第三步：诊断结论配置']}
        value={step}
        onChange={setStep}
      />
    </div>
  );
};
