import { Fragment, ReactElement } from 'react';

import { useNodeRender } from '@ecom/arctic-components';

import { BaseTreeNode, BaseTreeNodeOptions } from '~/analysis-tree/DiagnosisTreeNode';
import { CommonAnalysisRequest } from '~/api/product/namespaces/common_request';
import { RecursivePartial } from '~/types';

export interface LayerOptions extends BaseTreeNodeOptions {
  params?: RecursivePartial<CommonAnalysisRequest>;
  baseParams?: RecursivePartial<CommonAnalysisRequest>;
  sourceNode?: BaseTreeNode;
  subNodes?: (BaseTreeNode | ReactElement)[];
}

const Render = ({ node }: { node: LayerWrapperNode }) => {
  const { renderGraphNode } = useNodeRender();

  return (
    <div className="w-fit flex flex-col gap-2">
      {node.subNodes?.map(subNode => {
        if (subNode instanceof BaseTreeNode) {
          return <Fragment key={subNode.id}>{renderGraphNode(subNode)}</Fragment>;
        } else {
          return subNode;
        }
      })}
    </div>
  );
};

Render.displayName = 'LayerWrapperNode';

interface LayerWrapperOptions extends LayerOptions {
  layerIndex?: number;
}
export class LayerWrapperNode extends BaseTreeNode {
  sourceNode: BaseTreeNode | undefined;
  options: LayerOptions;
  subNodes: (BaseTreeNode | ReactElement)[];
  layerIndex: any;

  constructor(options: LayerWrapperOptions) {
    super(options);
    this.layerIndex = options.layerIndex || 0;
    this.options = options;
    this.render = this.render.bind(this);
    this.sourceNode = options.sourceNode;
    this.source = options.sourceNode?.id;
    this.subNodes = options.subNodes || [];
  }

  render() {
    return <Render node={this} />;
  }
}
