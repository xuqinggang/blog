import { FC } from 'react';

import { BaseTreeNode } from './DiagnosisTreeNode';

export type TreeNodeRender<T extends BaseTreeNode> = FC<{ node: T }>;
