import { BaseNode } from '@ecom/arctic-components';
import { generateRandomId } from '@editor-kit/utils';

export const COMMON_NODE_TYPE = 'common_node';

export interface BaseTreeNodeOptions {
  type?: string;
  id?: string;
  source?: string;
  data?: unknown;
}

/** 诊断树节点 抽象类
 * 这里把归因树中的节点类型进行抽象，预期： \
 * 1. 使用这种管理形式进行节点数据的归一化，后续能够进行更好的抽象，最终形成可以根据配置进行渲染的组件 \
 * 1. 基于这种形式能够进行更加清晰的数据流管理，能够通过react-devtools进行调试 \
 */
export abstract class BaseTreeNode implements BaseNode {
  defaultActive = false;
  type = COMMON_NODE_TYPE;
  id = generateRandomId();

  /** 以下属性与三方库同步 */
  label?: string | undefined;
  source?: string | undefined;
  target?: string | undefined;
  hiddenDataSet?: boolean | undefined;
  data: unknown;
  /** ================ */

  constructor(options: BaseTreeNodeOptions = {}) {
    this.type = options.type || this.type;
    this.id = options.id || this.id;
    this.source = options.source;
    this.data = options.data;
  }

  createId(id = '') {
    return `${this.id}/${id}`;
  }

  /** ================ 节点的渲染方法 ================ \
   * 在渲染时，可以将节点实例传入，通过实例本身控制节点的渲染以及行为
   * 例如：
   * 1. 节点的点击事件
   * 2. 节点的渲染
   * 3. 节点的状态
   *  */ abstract render(): JSX.Element;
}
