import { FC, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { debounce, uniqBy } from 'lodash-es';

import { Form, Select, Tooltip } from '@ecom/auxo';

import { ExtraInfo, isActivityDisabled } from './utils';

import { DataReadyTime, EnumElement, GetDimensionPageEnumInfo } from '~/api/product/namespaces/dimensions';
import { ENUM_LIST_PAGE_SIZE } from '~/constant';

interface ActivitySelectorProps {
  /** 选中的活动值 */
  value?: EnumElement;
  /** 选中改变的回调 */
  onChange?: (value: EnumElement) => void;
  /** 可用时间信息 */
  dataReadyTime?: DataReadyTime;
  /** 获取活动列表的接口函数 */
  fetchActivityList: (params: {
    search?: string;
    page?: number;
    pageSize: number;
  }) => Promise<GetDimensionPageEnumInfo>;
}

export const ActivitySelector: FC<ActivitySelectorProps> = props => {
  const { value, dataReadyTime, onChange, fetchActivityList: fetchActivityListFunc } = props;
  const [searchKeyword, setSearchKeyword] = useState('');
  const [enums, setEnums] = useState<EnumElement[]>([]);
  const [loading, setLoading] = useState(false);
  const pageRef = useRef({
    current: 0,
    total: 0,
  });
  const formInstance = Form.useFormInstance();

  const handleActivityChange = useCallback(
    (activityId: string) => {
      const enumItem = enums.find(item => item.code === activityId);

      if (enumItem) {
        const extraInfoStr = enumItem?.extra_info;
        if (extraInfoStr) {
          const extraInfo = JSON.parse(extraInfoStr) as ExtraInfo;
          const { base_end_date, base_start_date, project_end_date, project_start_date } = extraInfo;
          onChange?.(enumItem);
          formInstance.setFieldsValue({
            compare_end_date: base_end_date,
            compare_start_date: base_start_date,
            start_date: project_start_date,
            end_date: project_end_date,
          });
        }
      }
    },
    [enums, formInstance, onChange],
  );

  const fetchActivityList = useCallback(
    debounce(async (params: { search?: string; page?: number }, clear = false) => {
      setLoading(true);

      try {
        const { search = '', page = 1 } = params;
        const data = await fetchActivityListFunc({
          search,
          page,
          pageSize: ENUM_LIST_PAGE_SIZE,
        });
        setEnums(pre => uniqBy([...(clear ? [] : pre), ...(data.enum_list || [])], 'code'));
        pageRef.current = {
          current: Number(data.page_info?.page_num) || 0,
          total: Math.ceil((Number(data.page_info?.total) || 0) / 10),
        };
      } catch (e) {
        console.error('Get activity list error', e);
        return [];
      } finally {
        setLoading(false);
      }
    }, 1000),
    [fetchActivityListFunc],
  );

  const search = useCallback(
    debounce((v: string) => {
      setSearchKeyword(v);
      fetchActivityList({ search: v }, true);
    }, 1000),
    [fetchActivityList],
  );

  const options = useMemo(() => {
    return enums.map(item => {
      const disabled = isActivityDisabled(item, dataReadyTime);
      const label = disabled ? <Tooltip title={'活动数据暂未就绪'}>{item.name}</Tooltip> : item.name;
      return {
        label,
        value: item.code || '',
        disabled,
      };
    });
  }, [enums, dataReadyTime]);

  // effects
  useEffect(() => {
    fetchActivityList({});
  }, [fetchActivityList]);

  useEffect(() => {
    if (!formInstance.getFieldValue('activity')) {
      const firstOption = options.find(item => !item.disabled);
      if (firstOption) {
        handleActivityChange(firstOption.value || '');
      }
    }
  }, [enums, formInstance, handleActivityChange, options]);

  return (
    <Select
      loading={loading}
      value={value?.code}
      filterOption={false}
      onChange={v => handleActivityChange(v)}
      showSearch
      onSearch={v => {
        search(v);
      }}
      allowClear
      onClear={() => search('')}
      loadMore={async () => {
        await fetchActivityList({ search: searchKeyword, page: pageRef.current.current + 1 });
        return pageRef.current.current < pageRef.current.total - 1;
      }}
    >
      {options.map(item => (
        <Select.Option key={item.value} value={item.value || ''} disabled={item.disabled}>
          {item.label}
        </Select.Option>
      ))}
    </Select>
  );
};
