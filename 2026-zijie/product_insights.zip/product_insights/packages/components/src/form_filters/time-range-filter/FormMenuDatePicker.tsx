/* eslint-disable @ecom/no-chinese */
import React, { memo } from 'react';
import { useMemoizedFn } from 'ahooks';
import dayjs, { Dayjs } from 'dayjs';
import dayjsLocal from 'dayjs/locale/zh-cn';
import advancedFormat from 'dayjs/plugin/advancedFormat';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import localeData from 'dayjs/plugin/localeData';
import updateLocale from 'dayjs/plugin/updateLocale';
import weekday from 'dayjs/plugin/weekday';
import weekOfYear from 'dayjs/plugin/weekOfYear';
import weekYear from 'dayjs/plugin/weekYear';
import { compact } from 'lodash-es';

import { DatePicker, Form } from '@ecom/auxo';

dayjs.extend(updateLocale);
dayjs.locale(dayjsLocal);
dayjs.updateLocale('zh-cn', {
  weekStart: 1,
});
dayjs.extend(customParseFormat);
dayjs.extend(advancedFormat);
dayjs.extend(localeData);
dayjs.extend(weekOfYear);
dayjs.extend(weekYear);
dayjs.extend(weekday);
dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);
dayjs.locale('zh-cn');

export type RangeTime = [Dayjs | null, Dayjs | null] | null | undefined;

export interface MenuDatePickerProps {
  disabled?: boolean;
  keys: [string, string];
  availableDateRange?: Dayjs[];
  label: string;
  extra?: string;
  onValuesChange?: (v: Record<string, string>) => void;
}

export const FormMenuDatePicker = memo(
  ({ keys, label, availableDateRange, extra, disabled, onValuesChange }: MenuDatePickerProps) => {
    const handleDisableDate = useMemoizedFn(date => {
      return Boolean(availableDateRange?.[0]?.isAfter(date) || availableDateRange?.[1]?.isBefore(date));
    });
    return (
      <>
        <Form.Item noStyle shouldUpdate>
          {({ getFieldValue, setFieldsValue }) => {
            const values = keys?.map(key => getFieldValue(key));

            const handleChange = (v: RangeTime) => {
              if (keys) {
                const strs = compact(v?.map(item => item?.format('YYYY-MM-DD')));
                const newVal = {
                  [keys[0]]: strs[0],
                  [keys[1]]: strs[1],
                };
                setFieldsValue?.(newVal);
                onValuesChange?.(newVal);
              }
            };

            return (
              <Form.Item
                name={keys[0]}
                rules={[
                  {
                    validator: (_, val: RangeTime) => {
                      if (!val) {
                        return Promise.reject(new Error('请选择正确时间周期'));
                      }
                      return Promise.resolve();
                    },
                  },
                ]}
                label={label}
                extra={extra}
              >
                <Form.Item noStyle>
                  <DatePicker.RangePicker
                    disabled={disabled}
                    value={values?.map(item => (item ? dayjs(item) : undefined)) as any}
                    allowClear={false}
                    onChange={handleChange}
                    disabledDate={handleDisableDate}
                  />
                </Form.Item>
              </Form.Item>
            );
          }}
        </Form.Item>

        {keys.map(key => (
          <Form.Item hidden key={key} name={key} />
        ))}
      </>
    );
  },
);

FormMenuDatePicker.displayName = 'FormMenuDatePicker';
