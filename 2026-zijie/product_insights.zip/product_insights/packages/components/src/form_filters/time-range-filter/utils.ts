import dayjs from 'dayjs';

import { DataReadyTime, EnumElement } from '~/api/product/namespaces/dimensions';

export function isActivityDisabled(activity: EnumElement, readyTime?: DataReadyTime | null) {
  try {
    const { extra_info } = activity;
    const { project_start_date } = JSON.parse(extra_info || '{}') as any;
    return dayjs(readyTime?.newest_partition).endOf('day').isBefore(dayjs(project_start_date).startOf('day'));
  } catch (e) {
    console.error('Parse activity extra_info error: ', e);
    return true;
  }
}
export const ENUM_LIST_PAGE_SIZE = 10;

export interface ExtraInfo {
  base_end_date: string;
  base_start_date: string;
  project_end_date: string;
  project_start_date: string;
}
