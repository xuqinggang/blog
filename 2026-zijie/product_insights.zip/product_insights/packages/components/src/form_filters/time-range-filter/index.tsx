import { FC, useMemo } from 'react';
import dayjs from 'dayjs';

import { Col, Form, Row } from '@ecom/auxo';

import { ActivitySelector } from './ActivitySelector';
import { FormMenuDatePicker } from './FormMenuDatePicker';
import { ExtraInfo } from './utils';

import { DataReadyTime, EnumElement, GetDimensionPageEnumInfo } from '~/api/product/namespaces/dimensions';
import { getEarlierTime, getLatestTime } from '~/utils';

export interface TimeRange {
  activity?: EnumElement;
  start_date?: string;
  end_date?: string;
  compare_start_date?: string;
  compare_end_date?: string;
}

interface Labels {
  keyName?: string;
  currTimePrefix?: string;
  compareTimePrefix?: string;
}

export interface TimeRangeFilterProps {
  value?: TimeRange;
  onChange?: (value: TimeRange) => void;
  labels?: Labels;
  dataReadyTime?: DataReadyTime;
  readyTime?: DataReadyTime;
  extraInfo: ExtraInfo | null;
  fetchActivityList: (params: {
    search?: string;
    page?: number;
    pageSize: number;
  }) => Promise<GetDimensionPageEnumInfo>;
}

export const TimeRangeFilterComp: FC<TimeRangeFilterProps> = ({
  labels,
  extraInfo,
  dataReadyTime,
  fetchActivityList,
}) => {
  const { keyName = '项目', currTimePrefix = '活动期', compareTimePrefix = '基准期' } = labels || {};

  const timeRange = useMemo(() => {
    const startDay = dayjs(extraInfo?.project_start_date).startOf('day');
    const endDay = dayjs(extraInfo?.project_end_date).startOf('day');
    return [startDay, endDay];
  }, [extraInfo]);

  const timeRangeCompare = useMemo(() => {
    const startDay = getEarlierTime(dayjs(extraInfo?.base_start_date), dayjs(extraInfo?.project_start_date));
    const endDay = getLatestTime(dayjs(extraInfo?.base_end_date), dayjs(extraInfo?.project_end_date));
    return [startDay, endDay];
  }, [extraInfo]);

  return (
    <Row>
      <Col span={8}>
        <Form.Item label={keyName} name="activity">
          <ActivitySelector dataReadyTime={dataReadyTime} fetchActivityList={fetchActivityList} />
        </Form.Item>
      </Col>
      <Col span={8} className="pl-4">
        <FormMenuDatePicker
          keys={['start_date', 'end_date']}
          label={currTimePrefix}
          availableDateRange={timeRange}
          disabled={!extraInfo}
          extra={`${labels?.keyName || ''}活动期：${extraInfo?.project_start_date || ''}-${
            extraInfo?.project_end_date || ''
          }`}
        />
      </Col>
      <Col span={8} className="pl-4">
        <FormMenuDatePicker
          keys={['compare_start_date', 'compare_end_date']}
          label={compareTimePrefix}
          availableDateRange={timeRangeCompare}
          disabled={!extraInfo}
          extra={`${labels?.keyName || ''}基准期：${extraInfo?.base_start_date || ''}-${
            extraInfo?.base_end_date || ''
          }`}
        />
      </Col>
    </Row>
  );
};

export const TimeRangeFilter: FC<Omit<TimeRangeFilterProps, 'extraInfo'>> = ({
  labels,
  dataReadyTime,
  fetchActivityList,
}) => {
  return (
    <Form.Item noStyle shouldUpdate>
      {({ getFieldValue }) => {
        const activity = getFieldValue('activity');
        const extraInfo = activity?.extra_info ? JSON.parse(activity?.extra_info) : null;
        return (
          <TimeRangeFilterComp
            labels={labels}
            dataReadyTime={dataReadyTime}
            extraInfo={extraInfo}
            fetchActivityList={fetchActivityList}
          />
        );
      }}
    </Form.Item>
  );
};

export { FormMenuDatePicker };
