import { FC, useCallback, useEffect, useMemo } from 'react';
import { get } from 'lodash-es';

import { Col, Form, Row, Select } from '@ecom/auxo';

import axios from '~/api/axios';
import { LibraInfo, LibraItem } from '~/api/product/namespaces/prod_review';
import { prettyDebug, useLatestRequest } from '~/utils';

export interface FlightFilterProps {
  name: string | string[];
  /** 关联实验id */
  flightId: string;
  metaInfo?: {
    /** 对照组 */
    base_version_info?: LibraItem;
    /** 实验组 */
    exp_version_info?: Array<LibraItem>;
  };
}

export const FlightFilter: FC<FlightFilterProps> = ({ name, flightId, metaInfo }) => {
  const form = Form.useFormInstance<{
    flight_id: string;
    exp_version: string;
    base_version: string;
  }>();
  const nameArray = Array.isArray(name) ? name : [name];
  const { base_version_info, exp_version_info = [] } = metaInfo || {};

  const fetchFlightMeta = useCallback(async () => {
    const res = await axios.request<LibraInfo>({
      url: '/product_analysis/prod_review/get_libra_info',
      method: 'POST',
      data: {
        flight_id: flightId,
      },
    });
    return res;
  }, [flightId]);

  const { data: libraInfo, loading } = useLatestRequest(fetchFlightMeta);
  const { nameMap, flightName } = useMemo(() => {
    const flightList = libraInfo?.libra_version_info_list || [];
    const flightName = flightList[0]?.flight_display_name;
    const nameMap = Object.fromEntries(flightList.map(item => [item.id, item.display_name]));
    return {
      flightList,
      nameMap,
      flightName,
    };
  }, [libraInfo?.libra_version_info_list]);

  useEffect(() => {
    prettyDebug('flightValues', {
      flightId,
      exp_version_info,
      base_version_info,
    });
    if (name) {
      form?.setFieldValue(name, {
        flight_id: flightId,
        exp_version: exp_version_info[0]?.version_id,
        base_version: base_version_info?.version_id,
      });
    }
  }, [base_version_info, exp_version_info, flightId, form, name]);

  return (
    <Row gutter={[24, 0]}>
      <Col span={8}>
        <Form.Item name={[...nameArray, 'flight_id']} label="选择实验" className="mb-0">
          <Select disabled loading={loading} defaultValue={flightId}>
            <Select.Option value={flightId}>{flightName}</Select.Option>
          </Select>
        </Form.Item>
      </Col>

      <Col span={8}>
        <Form.Item name={[...nameArray, 'exp_version']} label="实验组" className="mb-0">
          <Select defaultValue={exp_version_info[0]?.version_id}>
            {exp_version_info.map(item => (
              <Select.Option key={item.version_id} value={item.version_id || ''}>
                {item.version_name || get(nameMap, item.version_id || '', '') || item.version_id}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
      </Col>
      <Col span={8}>
        <Form.Item name={[...nameArray, 'base_version']} label="对照组" className="mb-0">
          <Select disabled defaultValue={base_version_info?.version_id}>
            <Select.Option value={base_version_info?.version_id || ''}>
              {base_version_info?.version_name ||
                get(nameMap, base_version_info?.version_id || '', '') ||
                base_version_info?.version_id}
            </Select.Option>
          </Select>
        </Form.Item>
      </Col>
    </Row>
  );
};
