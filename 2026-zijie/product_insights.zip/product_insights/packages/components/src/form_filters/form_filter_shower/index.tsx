import { FC } from 'react';

import { Form } from '@ecom/auxo';

import { useFormFilterCtx } from '~/ctx';

export const FormFilterShower: FC = () => {
  const { values } = useFormFilterCtx();
  const jsonStr = JSON.stringify(values, null, 2);
  return (
    <div className="flex flex-col">
      <div className=" font-bold">表单值</div>
      <Form.Item noStyle shouldUpdate>
        {({ getFieldsValue }) => {
          const values = getFieldsValue(true);
          return <div>{JSON.stringify(values, null, 2)}</div>;
        }}
      </Form.Item>
      <div className="mt-2 font-bold">状态值</div>
      <div>{jsonStr}</div>
    </div>
  );
};
