import { omit } from 'lodash-es';

import { DimensionAttributeType, SelectedDimensionInfo } from '~/api/product/namespaces/dimensions';
import { DimensionType } from '~/filter-form/types';
import { getRuleSelectedValues } from '~/filter-form/utils/transform';
import { RuleSelectedOption, RuleValueType } from '~/RuleSelect';

import { ProductPalletFilterFields } from './comp';

const ANALYSIS_FILTER_GROUPS = [
  'order_dimensions',
  'place_dimensions',
  'product_dimensions',
  'user_dimensions',
] as const;

export type AnalysisFilterGroupName = typeof ANALYSIS_FILTER_GROUPS[number];

const TYPE_MAP: Record<AnalysisFilterGroupName, DimensionAttributeType> = {
  order_dimensions: DimensionAttributeType.Order,
  place_dimensions: DimensionAttributeType.Place,
  product_dimensions: DimensionAttributeType.Product,
  user_dimensions: DimensionAttributeType.User,
};

function transformAttrType(attrType?: DimensionAttributeType): DimensionType | undefined {
  switch (attrType) {
    case DimensionAttributeType.User: {
      return 'user_dimensions';
    }
    case DimensionAttributeType.Place: {
      return 'place_dimensions';
    }
    case DimensionAttributeType.Product: {
      return 'product_dimensions';
    }
    case DimensionAttributeType.Order: {
      return 'order_dimensions';
    }
    default: {
      return;
    }
  }
}

export const productPalletFilterFields2SelectedDimensionInfos = (
  values: ProductPalletFilterFields,
): SelectedDimensionInfo[] => {
  // 增加防守代码
  if (!values) return [];
  return Object.entries(values)
    .map(kv => {
      const [attr_type, itemGroup] = kv as [AnalysisFilterGroupName, RuleValueType[]];
      return itemGroup.map(item => ({
        ...omit(item, ['selected_option']),
        attr_type: TYPE_MAP[attr_type],
        selected_values: getRuleSelectedValues(item),
      }));
    })
    .flat();
};

export function transformSelectDims2ProductPalletFilterFields(
  dims: SelectedDimensionInfo[],
): ProductPalletFilterFields {
  const filedValue: ProductPalletFilterFields = {
    order_dimensions: [],
    place_dimensions: [],
    product_dimensions: [],
    user_dimensions: [],
  };
  dims?.forEach(targetDim => {
    const groupKey = transformAttrType(targetDim?.attr_type);
    if (groupKey) {
      filedValue[groupKey]?.push({
        id: targetDim?.id,
        name: targetDim?.name,
        selected_operator: targetDim?.selected_operator,
        selected_values: targetDim?.selected_values?.map(({ code, type_value }) => code || type_value)?.flat() as any,
        selected_option: targetDim?.selected_values as RuleSelectedOption[],
        dim_type: transformAttrType(targetDim?.attr_type),
      });
    }
  });

  return filedValue;
}
