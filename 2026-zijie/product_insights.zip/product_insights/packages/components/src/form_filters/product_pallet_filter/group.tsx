import React from 'react';

import styles from './index.module.less';
import VsIcon from './vs.svg';

export interface VsGroupProps {
  className?: string;
  style?: React.CSSProperties;
}

export const ProductPalletVsGroup: React.FC<VsGroupProps> = ({ children }) => {
  return (
    <div className="flex flex-1 items-stretch">
      <div className="flex items-center mr-2">
        <div className={styles.container}>
          <div className={styles.rounded}>
            <img src={VsIcon} className={styles.icon} />
          </div>
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-4">{children}</div>
    </div>
  );
};

export default ProductPalletVsGroup;
