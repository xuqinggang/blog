import { FC, useRef, useState } from 'react';

import { Button, Drawer } from '@ecom/auxo';
import { EditIcon } from '@ecom/auxo/es/components/icon';
import { FormInstance } from '@ecom/auxo-pro-form/es/types';

import { BizType, GetDimensionListData, SelectedDimensionInfo } from '../../api/product/namespaces/dimensions';
import DimTagsRender from '../../dim-tags-render';
import { DEFAULT_CUSTOMIZE_ITEMS, FilterForm } from '../../filter-form';
import { AnalysisFilter, DefaultEnumMap } from '../../filter-form/types';

import { AnalysisFilterGroupName } from './utils';

export type ProductPalletFilterFields = Pick<AnalysisFilter, AnalysisFilterGroupName>;

export interface ProductPalletFilterProps {
  dimTagsClassName?: string;
  value?: ProductPalletFilterFields;
  onChange?: (v: ProductPalletFilterFields) => void;
  name: string | string[];
  label?: string;
  bizType: BizType;
  dimensionData: GetDimensionListData;
  defaultEnumMap?: DefaultEnumMap;
  requiredDim?: SelectedDimensionInfo[];
  pure?: boolean;
  disabled?: boolean;
}

export const ProductPalletFilterComp: FC<ProductPalletFilterProps> = ({
  // name,
  dimTagsClassName,
  value,
  label,
  onChange,
  dimensionData,
  pure,
  disabled,
  bizType,
  defaultEnumMap,
  requiredDim,
}) => {
  const [drawerVisible, setDrawerVisible] = useState(false);

  const editorFormRef = useRef<FormInstance<ProductPalletFilterFields>>(null);

  const showDrawer = () => {
    setDrawerVisible(true);
    setTimeout(() => {
      editorFormRef.current?.pSetFieldsValue(value);
    }, 1);
  };

  const hideDrawer = async (save = false) => {
    if (save) {
      await editorFormRef.current?.pValidateFields();
      onChange?.(editorFormRef.current?.getFieldsValue(true));
    }
    setDrawerVisible(false);
  };

  return (
    <div className="flex flex-1">
      <DimTagsRender
        className={dimTagsClassName}
        title={label ?? ''}
        suffix={
          <Button onClick={() => showDrawer()} type="link" size="small" disabled={disabled}>
            修改筛选
            <EditIcon />
          </Button>
        }
        values={value}
        dimensionData={dimensionData}
        pure={pure}
      />

      <Drawer
        visible={drawerVisible}
        width={960}
        onCancel={() => hideDrawer(false)}
        onOk={() => {
          hideDrawer(true);
        }}
      >
        <FilterForm
          ref={editorFormRef}
          bizType={bizType}
          dimensionData={dimensionData}
          isProdAnalysis
          defaultEnumMap={defaultEnumMap}
          visible={{
            analysisDate: false,
            compareDate: false,
            drillFilter: false,
            targetFilter: false,
            dimFilter: true,
            ruleFilter: false,
          }}
          showSubTitle={false}
          requiredDimInfo={requiredDim}
          customizeItem={DEFAULT_CUSTOMIZE_ITEMS}
        />
      </Drawer>
    </div>
  );
};
