import { FC } from 'react';

import { Form } from '@ecom/auxo';

import { ProductPalletFilterComp, ProductPalletFilterProps } from './comp';

export const ProductPalletFilter: FC<ProductPalletFilterProps> = props => {
  const { name } = props;

  return (
    <Form.Item name={name} noStyle>
      <ProductPalletFilterComp {...props} />
    </Form.Item>
  );
};

export { ProductPalletVsGroup } from './group';
export { ProductPalletFilterComp } from './comp';
export * from './utils';
