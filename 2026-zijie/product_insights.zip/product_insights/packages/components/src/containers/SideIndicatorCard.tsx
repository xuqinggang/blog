/* eslint-disable @typescript-eslint/naming-convention */
import { CSSProperties, FC, useMemo } from 'react';
import classNames from 'classnames';

const AVAILABLE_TYPES = ['error', 'warning', 'success', 'primary', 'disabled'];
type Type = typeof AVAILABLE_TYPES[number];
interface SideIndicatorCardProps {
  type?: Type;
  className?: string;
  style?: CSSProperties;
  onClick?: () => void;
  active?: boolean;
  grayMode?: boolean;
}

export const SideIndicatorCard: FC<SideIndicatorCardProps> = ({
  type: propsType,
  children,
  className,
  style,
  onClick,
  active,
}) => {
  const type = useMemo(() => (propsType && AVAILABLE_TYPES.includes(propsType) ? propsType : 'primary'), [propsType]);
  return (
    <div
      onClick={onClick}
      className={classNames(
        'border-[1px] ',
        {
          'border-brand': type === 'primary' && active,
          'border-error-active': type === 'error' && active,
          'border-warning-active': type === 'warning' && active,
          'border-success-active': type === 'success' && active,
          'border-text-icon-2': type === 'disabled',
        },
        'rounded-[4px] pl-1',
        {
          'bg-brand': type === 'primary',
          'bg-error-active': type === 'error',
          'bg-warning-active': type === 'warning',
          'bg-success-active': type === 'success',
          'bg-text-icon-2': type === 'disabled',
        },
        className,
      )}
      style={style}
    >
      <div
        className={classNames('rounded-[3px] py-[5px] px-2', {
          'bg-white': !active,
          'bg-highlight': type === 'primary' && active,
          'bg-error-highlight': type === 'error' && active,
          'bg-warning-highlight': type === 'warning' && active,
          'bg-success-highlight': type === 'success' && active,
        })}
      >
        {children}
      </div>
    </div>
  );
};
