import { useEffect, useState } from 'react';
import { isArray } from 'lodash-es';

import { Checkbox } from '@ecom/auxo';
import { EnumOption } from '@ecom/auxo-pro-form';

import { isSelectType } from '../RuleSelect';

import { DimGroupItem } from '~/filter-form/types';

export interface RemoteSelect {
  id: string | number;
  selected_values: (string | number)[];
}

export type DimItem = {
  label: string;
  value: string | number;
  disabled?: boolean;
  group?: string;
  enums?: EnumOption[];
  selected_enums?: EnumOption[];
  remote?: (selected?: Array<RemoteSelect>) => {
    service: (params: { search?: string; page?: number }) => Promise<EnumOption[]>;
    refreshDeps: Array<any>;
  };
  show_type?: string;
  dimension_group?: string;
  dimension_group_order?: string | number;
  dimension_group_dim_order?: string | number;
};

interface DimCheckGroupProps {
  style?: React.CSSProperties;
  overLimit?: boolean;
  underLimit?: boolean;
  mode?: 'single' | 'multiple'; // 单选|多选，默认是多选
  disabledDimList?: string[]; // 不可选中的维度
  groupInValue?: boolean;
  dimension?: string;
  dimGroup: Array<DimGroupItem>;
  value?: Record<string, (string | number)[]> | DimItem[];
  /** 是否在多选框前展示维度类型信息 */
  displayDimensionGroup?: boolean;
  onChange?: (v: any, k?: string) => void;
}

interface DimCheckGroupInLabelProps extends DimCheckGroupProps {
  groupInValue?: true;
  value?: DimItem[];
  onChange?: (v: DimItem[]) => void;
}

interface DimCheckGroupMapProps extends DimCheckGroupProps {
  groupInValue?: false;
  value?: Record<string, (string | number)[]>;
  onChange?: (v: (string | number)[], key?: string) => void;
}

interface CheckboxOption extends DimItem {
  checked: boolean;
  disabled?: boolean;
}

function DimCheckGroup(props: DimCheckGroupMapProps | DimCheckGroupInLabelProps): JSX.Element;

function DimCheckGroup(props: DimCheckGroupProps) {
  const {
    dimGroup,
    value = {},
    onChange,
    style,
    mode = 'multiple',
    underLimit = false,
    overLimit = false,
    groupInValue = false,
    disabledDimList,
    dimension,
    displayDimensionGroup = true,
  } = props;

  const [checked, setChecked] = useState<Record<string, (string | number)[]>>({});
  const [checkedList, setCheckedList] = useState<{ value: number | string; group?: string }[]>([]);

  const handleInValueCheck = (isChecked: boolean, checkValue: string | number, groupKey: string, label = '') => {
    if (isChecked) {
      const newList =
        mode === 'single'
          ? [{ value: checkValue, group: groupKey, label } as DimItem]
          : [...checkedList, { value: checkValue, group: groupKey, label } as DimItem];
      onChange?.(newList);
    } else {
      const newList = mode === 'single' ? [] : checkedList.filter(v => v.value !== checkValue);
      onChange?.(newList);
    }
  };

  const handleCheck = (isChecked: boolean, checkValue: string | number, groupKey: string) => {
    const curChecked = checked[groupKey] ?? [];
    if (isChecked) {
      const newChecked = mode === 'single' ? [checkValue] : [...curChecked, checkValue];
      onChange?.(newChecked, groupKey);
    } else {
      const newChecked = mode === 'single' ? [] : curChecked.filter(v => v !== checkValue);
      onChange?.(newChecked, groupKey);
    }
  };

  const renderCheckoutList = (options: CheckboxOption[], key: string) => {
    return (
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
        {options
          .sort((a, b) => Number(a?.dimension_group_dim_order) - Number(b?.dimension_group_dim_order))
          .map(i => (
            <Checkbox
              style={{ margin: 'unset' }}
              key={i.value}
              {...i}
              onChange={e => {
                groupInValue
                  ? handleInValueCheck(e.target.checked, i.value, key, i.label)
                  : handleCheck(e.target.checked, i.value, key);
              }}
            >
              {i.label}
            </Checkbox>
          ))}
      </div>
    );
  };

  useEffect(() => {
    if (isArray(value)) {
      setCheckedList(value);
      const newChecked = value.reduce((buf, cur) => {
        if (!cur.group) return buf;
        buf[cur.group] = [...(buf[cur.group] ?? []), cur.value];
        return buf;
      }, {} as Record<string, (string | number)[]>);
      setChecked(newChecked);
    } else {
      setChecked(value);
    }
  }, [value]);

  return (
    <>
      {(dimension ? dimGroup.filter(item => item?.key === dimension) : dimGroup).map(group => {
        const { list = [], key } = group;
        if (!list.length) return null;

        function getOption(dim: DimItem) {
          const selected = checked[group.key]?.includes(dim.value);

          return {
            ...dim,
            checked: selected,
            disabled:
              mode === 'single'
                ? false
                : (!selected && overLimit) || (underLimit && selected) || disabledDimList?.includes(String(dim.value)),
          } as CheckboxOption;
        }

        if (dimension === 'product_dimensions') {
          /** 商品属性需要分组展示类型 */
          const dimSubGroup: Record<
            string,
            { dimension_group: string; dimension_group_order: string | number; dimensions: DimItem[] }
          > = {};

          for (const dim of list) {
            const { dimension_group_order = 999, show_type = '' } = dim;
            // 没有分组的按"基础属性"兜底
            const dimension_group = !dim.dimension_group ? '基础属性' : dim.dimension_group;
            if (!isSelectType(show_type)) {
              continue;
            }
            if (dimension_group in dimSubGroup === false) {
              dimSubGroup[dimension_group] = { dimension_group, dimension_group_order, dimensions: [] };
            }
            (dimSubGroup[dimension_group].dimensions as DimItem[]).push(dim);
          }

          return (
            <div className="flex gap-4 mb-4 flex-col" key={group.key} style={style}>
              {displayDimensionGroup ? <div className="text-desc">{group.name}</div> : null}
              {Object.values(dimSubGroup)
                .sort((a, b) => Number(a?.dimension_group_order) - Number(b?.dimension_group_order))
                .map(({ dimension_group, dimensions }) => {
                  const options = dimensions.map(getOption);
                  return (
                    <div key={dimension_group} className="flex flex-row gap-4">
                      <div className="text-desc w-[72px]">{dimension_group}</div>
                      {renderCheckoutList(options, key)}
                    </div>
                  );
                })}
            </div>
          );
        }

        const options = list
          .sort((a, b) => Number(a?.dimension_group_order) - Number(b?.dimension_group_order))
          .map(getOption);

        return (
          <div className="flex gap-4 mb-4" key={group.key} style={style}>
            {displayDimensionGroup ? <div className="text-desc">{group.name}</div> : null}
            {renderCheckoutList(options, key)}
          </div>
        );
      })}
    </>
  );
}

export default DimCheckGroup;
