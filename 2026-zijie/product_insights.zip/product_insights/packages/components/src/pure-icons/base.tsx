import { FC } from 'react';

export const IconWrapper: FC = ({ children, ...otherProps }) => {
  return (
    <span {...otherProps}>
      <svg viewBox="0 0 16 16" className="icon w-[1em] h-[1em]" aria-hidden>
        {children}
      </svg>
    </span>
  );
};

export type CommonIconProps = React.HTMLAttributes<HTMLSpanElement>;
