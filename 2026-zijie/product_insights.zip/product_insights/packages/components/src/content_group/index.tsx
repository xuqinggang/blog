import { ComponentType, createElement, FC, useCallback, useLayoutEffect, useRef, useState } from 'react';

import { Button, Tabs } from '@ecom/auxo';
import { SetUpIcon } from '@ecom/auxo/es/components/icon';
import { generateRandomId } from '@editor-kit/utils';

import { ContentGroupSortModal } from './sort_modal';

import { prettyDebug } from '~/utils';

export interface ContentGroupProps {
  component: ComponentType;
  maxCnt?: number;
}

export interface CardInfo {
  id: string;
  title: string;
}
export const ContentGroup: FC<ContentGroupProps> = ({ component, maxCnt }) => {
  const currentCnt = useRef(0);
  const [visible, setVisible] = useState(false);
  const [activeKey, setActiveKey] = useState<string>();
  const createNewCard = useCallback<() => CardInfo>(() => {
    prettyDebug('CREATE NEW CARD');
    currentCnt.current += 1;
    return {
      id: generateRandomId(),
      title: `洞察${currentCnt.current}`,
    };
  }, []);
  const [cards, setCards] = useState<CardInfo[]>(() => [createNewCard()]);

  const addCard = useCallback(() => {
    prettyDebug('ADD CARD');
    const newCard = createNewCard();
    setCards([...cards, newCard]);
    setActiveKey(newCard.id);
  }, [cards, createNewCard]);

  useLayoutEffect(() => {
    if (!activeKey || (!cards.find(item => item.id === activeKey) && cards.length)) {
      setActiveKey(cards[0].id);
    }
  }, [activeKey, cards]);

  return (
    <>
      <Tabs
        type="editable-card"
        activeKey={activeKey}
        onChange={setActiveKey}
        hideAdd={Boolean(maxCnt && cards.length >= maxCnt)}
        onEdit={(_, type) => {
          if (type === 'add') {
            addCard();
          }
        }}
        tabBarExtraContent={
          <Button onClick={() => setVisible(true)} icon={<SetUpIcon />}>
            管理洞察
          </Button>
        }
      >
        {cards.map(item => (
          <Tabs.TabPane tab={item.title} key={item.id} closeIcon={<div />}>
            {createElement(component)}
          </Tabs.TabPane>
        ))}
      </Tabs>
      <ContentGroupSortModal
        visible={visible}
        cards={cards}
        onCancel={() => setVisible(false)}
        onOk={newCards => {
          setCards(newCards);
          setVisible(false);
        }}
      />
    </>
  );
};
