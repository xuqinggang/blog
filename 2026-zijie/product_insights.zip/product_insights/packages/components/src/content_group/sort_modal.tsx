import { FC, useCallback, useLayoutEffect, useState } from 'react';

import { DragMoveEvent } from '@dnd-kit/core';
import { Button, Divider, Input, Modal, Popover } from '@ecom/auxo';
import { DeleteIcon } from '@ecom/auxo/es/components/icon';

import { CardInfo } from '.';

import DragIcon from '~/assets/svg/drag.svg';
import { DragItem } from '~/dnd/drag-item';
import { DropContainer, useDropContext } from '~/dnd/drop-container';
import { FilterBlock } from '~/style_component';
import { prettyDebug } from '~/utils';

export interface ContentGroupSortModalProps {
  visible?: boolean;
  onOk?: (cards: CardInfo[]) => void;
  onCancel?: () => void;
  cards: CardInfo[];
}

interface ContentItemProps {
  card: CardInfo;
  handleUpdateName: (name: string) => void;
  handleDelete: () => void;
  canDelete?: boolean;
}

const ContentItem: FC<ContentItemProps> = ({ card, handleUpdateName, handleDelete, canDelete }) => {
  const { grabbing } = useDropContext();

  return (
    <DragItem item={card} className="w-full">
      {({ attributes, listeners }) => (
        <FilterBlock className="w-full flex items-center py-1">
          <div {...attributes} {...listeners} className={grabbing ? 'cursor-grabbing' : 'cursor-grab'}>
            <img src={DragIcon} className="mr-2" />
          </div>
          <div className="flex-1">
            <Input
              className="flex-1"
              value={card.title}
              onChange={value => {
                handleUpdateName(value.target.value);
              }}
              limit={6}
              maxLength={6}
            />
          </div>
          {canDelete ? (
            <div className="flex items-center">
              <div>
                <Divider type="vertical" />
              </div>
              <Popover
                trigger="click"
                content={
                  <div>
                    确认移除
                    <b>{card.title}</b>?
                    <Button type="primary" size="mini" danger onClick={() => handleDelete()} className="ml-2">
                      确认移除
                    </Button>
                  </div>
                }
              >
                <Button type="text">
                  <DeleteIcon style={{ fontSize: 16 }} />
                </Button>
              </Popover>
            </div>
          ) : null}
        </FilterBlock>
      )}
    </DragItem>
  );
};
export const ContentGroupSortModal: FC<ContentGroupSortModalProps> = ({ cards, visible, onOk, onCancel }) => {
  const [innerCards, setInnerCards] = useState(cards);

  useLayoutEffect(() => {
    if (cards && visible) {
      setInnerCards(cards);
    }
  }, [cards, visible]);

  const getMoveIndex = useCallback((array: CardInfo[], event: DragMoveEvent) => {
    const { active, over } = event;
    const activeIndex = array.findIndex(item => item.id === active.id);
    const overIndex = array.findIndex(item => item.id === over?.id);

    prettyDebug('activeIndex', activeIndex);
    prettyDebug('overIndex', overIndex);
    // 处理未找到索引的情况
    return {
      activeIndex: activeIndex !== -1 ? activeIndex : 0,
      overIndex: overIndex !== -1 ? overIndex : activeIndex,
    };
  }, []);

  const handleChange = (newCards: CardInfo[]) => {
    setInnerCards(newCards);
  };

  return (
    <Modal
      title={'管理洞察'}
      visible={visible}
      onOk={() => {
        onOk?.(innerCards);
      }}
      onCancel={onCancel}
    >
      <DropContainer value={innerCards} items={innerCards} onChange={handleChange} getMoveIndex={getMoveIndex}>
        <div className="w-full flex flex-col gap-2">
          {innerCards.map(item => (
            <ContentItem
              key={item.id}
              card={item}
              canDelete={innerCards.length > 1}
              handleDelete={() => {
                setInnerCards(pre => pre.filter(_ => _ !== item));
              }}
              handleUpdateName={name => {
                setInnerCards(pre => pre.map(_ => (_ === item ? { ..._, title: name } : _)));
              }}
            />
          ))}
        </div>
      </DropContainer>
    </Modal>
  );
};
