import { ItemData } from '~/api/product/namespaces/common_response';

export const MOCK_DATA: ItemData = {
  item_name: '短期有价值品',
  target_list: [
    {
      name: 'gmv',
      value: 1000000,
      display_value: '3,672万',
      display_name: 'GMV',
      tips: '',
    },
    {
      name: 'gmv_xx',
      value: 1000000,
      display_value: '48%',
      display_name: 'GMV贡献度',
      tips: '',
    },
  ],
};
