/* eslint-disable @typescript-eslint/naming-convention */
import { CSSProperties, FC, ReactElement, useMemo } from 'react';
import classNames from 'classnames';

const AVAILABLE_TYPE = ['success', 'error', 'warning'] as const;

type CardType = typeof AVAILABLE_TYPE[number];

interface ProductValueClassifyCardProps {
  type?: CardType;
  className?: string;
  style?: CSSProperties;
  title: ReactElement | string;
  desc?: ReactElement;
  content?: ReactElement;
}

export const ProductValueClassifyCard: FC<ProductValueClassifyCardProps> = ({
  type: propsType,
  className,
  style,
  title,
  desc,
  content,
}) => {
  const type = useMemo(() => {
    if (propsType && AVAILABLE_TYPE.includes(propsType)) {
      return propsType;
    }
    return 'success';
  }, [propsType]);

  return (
    <div
      className={classNames(
        'product-value-classify-card  flex flex-col rounded-[4px] border-[1px] bg-white',
        {
          'border-success-hover': type === 'success',
          'border-error-hover': type === 'error',
          'border-warning-hover': type === 'warning',
        },
        className,
      )}
      style={style}
    >
      <div
        className={classNames(
          'header',
          'flex flex-row overflow-hidden flex-nowrap h-8 justify-between items-center px-3 shrink-0',
          {
            'bg-success-highlight': type === 'success',
            'bg-error-highlight': type === 'error',
            'bg-warning-highlight': type === 'warning',
          },
        )}
      >
        <span
          className={classNames('title font-medium text-sm leading-5', {
            'text-success-main': type === 'success',
            'text-error-main': type === 'error',
            'text-warning-main': type === 'warning',
          })}
        >
          {title}
        </span>
        <div className="targets">{desc}</div>
      </div>

      {content}
    </div>
  );
};
