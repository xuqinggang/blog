import { createContext, createRef, useContext } from 'react';
import { noop } from 'lodash-es';

import { NodeGraphRefType } from '@ecom/arctic-components';

import { BaseTreeNode } from '~/analysis-tree/DiagnosisTreeNode';
import { TargetCardEntity } from '~/api/product/namespaces/analysis';
import { CommonAnalysisRequest } from '~/api/product/namespaces/common_request';
import { ProdReviewStrategy } from '~/api/product/namespaces/prod_review';
import { useFullscreen } from '~/hooks/use-fullscreen';

export interface ProductValueClassifyTreeContextType {
  refreshLayout: () => void;
  nodeGraphRef: React.Ref<NodeGraphRefType>;
  fullscreen: ReturnType<typeof useFullscreen>;
  handleActiveNode: (idx?: number) => void;
  renderData: Array<TargetCardEntity>;
  targetPoolType: number;
  allNodes: BaseTreeNode[];
  baseParams: CommonAnalysisRequest;
  queryParams: Record<string, string>;
  targets?: {
    short: number;
    long: number;
  };
  strategy?: ProdReviewStrategy;
  definition?: {
    strategy_full?: string;
    strategy_advantage?: string;
    strategy_disadvantage?: string;
    equal?: string;
    short?: string;
    long?: string;
    invalid?: string;
  };
}

export const ProductValueClassifyTreeContext = createContext<ProductValueClassifyTreeContextType>({
  refreshLayout: noop,
  nodeGraphRef: createRef(),
  fullscreen: { isFullScreen: false, handleFullScreen: noop, containerRef: createRef() },
  handleActiveNode: noop,
  renderData: [],
  targetPoolType: 0,
  allNodes: [],
  baseParams: {},
  queryParams: {},
});

export const useTreeCtx = () => useContext(ProductValueClassifyTreeContext);
