export enum Layer1NodeType {
  OverallInfo = 'overall_info',
  Positive = 'advantage',
  Negative = 'disadvantage',
  Equal = 'equal',
}
export enum Layer2NodeType {
  Short = 'short',
  Long = 'long',
  Invalid = 'invalid',
}
