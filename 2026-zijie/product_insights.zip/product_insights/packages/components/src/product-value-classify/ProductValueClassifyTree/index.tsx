import { createRef, FC, useEffect, useMemo } from 'react';

import { NodeGraph, NodeGraphRefType, NodeRender } from '@ecom/arctic-components';
import { Spin } from '@ecom/auxo';
import { generateRandomId } from '@editor-kit/utils';

import { useMainLayer } from './layer/mainLayer';
import { useSecondLayer } from './layer/secondLayer';
import { DetailNode } from './node/DetailNode';
import { OverallInfoNode } from './node/OverallInfoNode';
import { ProductValueClassifyTreeContext, ProductValueClassifyTreeContextType, useTreeCtx } from './ctx';
import { Layer1NodeType, Layer2NodeType } from './enum';

import { COMMON_NODE_TYPE } from '~/analysis_tree/node';
import { BaseTreeNode } from '~/analysis-tree/DiagnosisTreeNode';
import { TargetCardEntity } from '~/api/product/namespaces/analysis';
import { CommonAnalysisRequest } from '~/api/product/namespaces/common_request';
import { ProdReviewStrategy } from '~/api/product/namespaces/prod_review';
import { useFullscreen } from '~/hooks/use-fullscreen';
import { ResizedPlaceholder } from '~/placeholder';

interface ProductValueClassifyTreeProps {
  renderData: Array<TargetCardEntity>;
  handleActiveNode: (idx?: number) => void;
  targetPoolType: number;
  baseParams: CommonAnalysisRequest;
  queryParams: string;
  strategy?: ProdReviewStrategy;

  definition: {
    strategy_full?: string;
    strategy_advantage?: string;
    strategy_disadvantage?: string;
    equal?: string;
    short?: string;
    long?: string;
    invalid?: string;
  };

  targets: {
    short: number;
    long: number;
  };
}

export const ProductValueClassifyTreeComp: FC = ({}) => {
  const { nodeGraphRef, refreshLayout, targetPoolType, allNodes, renderData } = useTreeCtx();
  const { layerNode: firstLayer } = useMainLayer();
  const { layerNode: secondLayer } = useSecondLayer();

  const nodeMap: any = useMemo(() => {
    return {
      centerNodes: [],
      inputLevel: [[firstLayer]],
      outputLevel: [[secondLayer]],
    };
  }, [firstLayer, secondLayer]);

  const nodeRenderList: NodeRender<BaseTreeNode>[] = [
    {
      type: COMMON_NODE_TYPE,
      render: (node: BaseTreeNode) => {
        const { render } = node;
        if (render) return render();
        return null;
      },
    },
  ];

  useEffect(() => {
    setTimeout(refreshLayout, 200);
  }, [targetPoolType, allNodes, renderData]);

  const containerId = useMemo(() => generateRandomId(), []);
  return (
    <div className="w-full border-line-0 flex items-center rounded">
      <NodeGraph
        containerId={containerId}
        data={nodeMap}
        nodeRenderList={nodeRenderList as any}
        ref={nodeGraphRef}
        style={{ paddingTop: 36, paddingBottom: 36, height: '100%' }}
      />
    </div>
  );
};

export const ProductValueClassifyTree: FC<ProductValueClassifyTreeProps> = ({
  renderData,
  handleActiveNode,
  targetPoolType = 0,
  definition = {},
  baseParams,
  queryParams,
  targets,
  strategy,
}) => {
  const nodeGraphRef = createRef<NodeGraphRefType>();
  const fullscreen = useFullscreen();

  const refreshLayout = () => {
    nodeGraphRef.current?.refreshLayout();
  };

  const allNodes = useMemo(() => {
    const nodes: BaseTreeNode[] = [
      new OverallInfoNode({
        title: '策略商品底池',
        data: Layer1NodeType.OverallInfo,
        definition: definition.strategy_full || '策略覆盖的全部商品',
      }),
      new OverallInfoNode({
        title: '策略优势商品',
        data: Layer1NodeType.Positive,
        definition: definition.strategy_advantage || '策略期间日均GMV > 策略前等长周期日均GMV',
      }),
      new OverallInfoNode({
        title: '策略劣势商品',
        data: Layer1NodeType.Negative,
        definition: definition.strategy_disadvantage || '策略期间日均GMV < 策略前等长周期日均GMV',
      }),
    ];

    const activeNode = nodes[targetPoolType];

    nodes.push(
      new DetailNode({
        source: activeNode?.id,
        data: Layer2NodeType.Short,
        title: '短期有价值商品',
        definition: definition.short || '',
      }),
    );

    nodes.push(
      new DetailNode({
        source: activeNode?.id,
        data: Layer2NodeType.Long,
        title: '长期有价值商品',
        definition: definition.long || '',
      }),
    );

    nodes.push(
      new DetailNode({
        source: activeNode?.id,
        data: Layer2NodeType.Invalid,
        title: '策略无效商品',
        definition: definition.invalid || '策略结束后7天日均GMV < 策略期间日均GMV的商品',
      }),
    );

    nodes.push(
      new OverallInfoNode({
        title: '策略效果不明显商品',
        data: Layer1NodeType.Equal,
        definition: definition.equal || '分析周期日均GMV  = 对比周期日均GMV',
      }),
    );
    return nodes;
  }, [definition]);

  const ctxValue: ProductValueClassifyTreeContextType = useMemo(() => {
    const queryParamsObj = JSON.parse(queryParams);
    return {
      refreshLayout,
      nodeGraphRef,
      fullscreen,
      handleActiveNode,
      renderData,
      targetPoolType,
      allNodes,
      baseParams,
      queryParams: queryParamsObj,
      targets,
      strategy,
    };
  }, [
    queryParams,
    refreshLayout,
    nodeGraphRef,
    fullscreen,
    handleActiveNode,
    renderData,
    targetPoolType,
    allNodes,
    baseParams,
    targets,
    strategy,
  ]);

  if (!renderData || renderData.length === 0) {
    return <ResizedPlaceholder />;
  }

  return (
    <Spin spinning={false}>
      <ProductValueClassifyTreeContext.Provider value={ctxValue}>
        <ProductValueClassifyTreeComp />
      </ProductValueClassifyTreeContext.Provider>
    </Spin>
  );
};
