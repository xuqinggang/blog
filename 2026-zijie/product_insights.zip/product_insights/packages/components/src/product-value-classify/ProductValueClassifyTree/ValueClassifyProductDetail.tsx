import { FC, useMemo } from 'react';

import { useTreeCtx } from './ctx';

import { CommonAnalysisRequest } from '~/api/product/namespaces/common_request';
import ProductDetail from '~/ProductDetail';

interface ValueClassifyProductDetailProps {
  index: number;
  baseParams: CommonAnalysisRequest;
}
export const ValueClassifyProductDetail: FC<ValueClassifyProductDetailProps> = ({ index, baseParams }) => {
  const { queryParams } = useTreeCtx();
  const shareInfo = useMemo(() => {
    return {
      base_req: baseParams.base_req,
      compare_req: baseParams.compare_req,
      biz_extra_info: {
        prod_review_params: {
          prod_detail_params: {
            value_classify_query_params: JSON.stringify({
              ...queryParams,
              product_target: index,
            }),
          },
        },
      },
    };
  }, [baseParams.base_req, baseParams.compare_req, index, queryParams]);

  return (
    <ProductDetail
      stopPropagation
      size="mini"
      name="商品明细"
      req_marshal={JSON.stringify(shareInfo)}
      router="/product_analysis/prod_review/analysis_item_data"
    />
  );
};
