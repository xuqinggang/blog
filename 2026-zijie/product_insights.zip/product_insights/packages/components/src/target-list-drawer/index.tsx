import { memo, ReactNode, useEffect, useState } from 'react';
import { groupBy } from 'lodash-es';

import { Button, Checkbox, Divider, Drawer, DrawerProps, Form, Icon, Space, Tooltip } from '@ecom/auxo';
import { FormInstance } from '@ecom/auxo-pro-form';

import { TargetListEditor } from '../target-list-editor';

import { TargetMetaInfo } from '~/api/product/namespaces/dimensions';
import { MAX_ANALYSIS_TARGET, MIN_ANALYSIS_TARGET } from '~/constant';

export interface TargetListDrawerProps extends Omit<DrawerProps, 'visible' | 'onOk'> {
  triggerText?: string;
  triggerClassName?: string;
  min?: number;
  max?: number;
  list?: TargetMetaInfo[];
  form?: FormInstance;
  field?: string;
  value?: string[];
  disabled?: boolean;
  disabledList?: string[]; // 不可选中的维度
  renderTrigger?: ({ onClick }: { onClick: () => void }) => ReactNode;
  onOk?: (value: string[]) => void;
}

interface TargetGroupList {
  group: string;
  list?: TargetMetaInfo[];
}

export const TargetListDrawer = memo((props: TargetListDrawerProps) => {
  const {
    triggerText = '配置指标',
    title = '配置指标',
    triggerClassName,
    min = MIN_ANALYSIS_TARGET,
    max = MAX_ANALYSIS_TARGET,
    list,
    form,
    field,
    value,
    disabled,
    disabledList,
    renderTrigger,
    onOk,
    ...otherProps
  } = props;

  const [visible, setVisible] = useState(false);
  const [selectedList, setSelectedList] = useState<string[]>([]);
  const [errorInfo, setErrorInfo] = useState('');
  const [targetList, setTargetList] = useState<TargetGroupList[]>([]); // 分组后的指标列表

  const openDrawer = () => {
    setVisible(true);
  };

  const validateError = () => {
    if (min !== undefined && selectedList.length < min) {
      const error = `选择的指标个数小于${min}`;
      setErrorInfo(error);
      return error;
    }

    if (max !== undefined && selectedList.length > max) {
      const error = `选择的指标个数大于${max}`;
      setErrorInfo(error);
      return error;
    }

    setErrorInfo('');
    return;
  };

  const onConfirm = () => {
    if (validateError()) {
      return;
    }

    onOk?.(selectedList);
    setVisible(false);
  };

  useEffect(() => {
    if (!visible) {
      return;
    }

    setSelectedList(value ?? form?.pGetFieldValue(field || '') ?? []);
  }, [field, form, value, visible]);

  // 对指标进行分组
  useEffect(() => {
    if (!list?.length) {
      return;
    }

    const sortList = list.sort((a, b) => Number(a?.display_order) - Number(b?.display_order));
    const groupMap = groupBy(sortList, 'attribute_type');
    const groupList = Object.keys(groupMap).reduce<TargetGroupList[]>((prev, curr) => {
      const value = groupMap[curr];
      return prev.concat({
        group: curr,
        list: value,
      });
    }, []);

    setTargetList(groupList);
  }, [list]);

  return (
    <>
      {renderTrigger ? (
        renderTrigger({ onClick: openDrawer })
      ) : (
        <div className={triggerClassName}>
          <Button disabled={disabled} type="dashed" icon={<Icon.SetUpIcon />} onClick={openDrawer}>
            {triggerText}
          </Button>
        </div>
      )}
      <Drawer
        visible={visible}
        title={title}
        width={800}
        onCancel={() => setVisible(false)}
        onOk={onConfirm}
        destroyOnClose
        {...otherProps}
      >
        <Space size={8} style={{ marginBottom: 16 }}>
          <span className="font-medium">添加分析指标</span>
          <span className="text-desc">{`最少选择${min}个指标, 最多选择${max}个指标`}</span>
        </Space>
        <div className="flex gap-4 mb-4 flex-col">
          {targetList.map(({ group, list }) => (
            <div key={group} className="flex gap-4">
              <div className="w-[72px] text-[#898B8F]">{group}</div>
              <div className="flex-1 grid grid-cols-3 gap-x-8 gap-y-4">
                {list?.map(({ name, display_name, tips }) => (
                  <Checkbox
                    style={{ margin: 'unset' }}
                    key={name}
                    value={name}
                    checked={name ? selectedList.includes(name) : false}
                    disabled={
                      (selectedList.length <= min && selectedList.includes(name || '')) || selectedList.length >= max
                    }
                    onChange={e => {
                      if (e.target.checked) {
                        e.target.value && setSelectedList(prev => prev.concat([e.target.value]));
                      } else {
                        setSelectedList(prev => prev.filter(i => i !== e.target.value));
                      }
                    }}
                  >
                    {tips ? <Tooltip title={tips}>{display_name}</Tooltip> : display_name}
                  </Checkbox>
                ))}
              </div>
            </div>
          ))}
        </div>
        {selectedList.length > 0 && (
          <>
            <Divider style={{ width: '100%' }} />
            <Space size={8} style={{ marginBottom: 16 }}>
              <span className="font-medium">调整指标顺序</span>
              <span className="text-desc">分析结果会按以下顺序呈现您选择的指标</span>
            </Space>
            <Form>
              <Form.Item validateStatus={errorInfo ? 'error' : 'success'} help={errorInfo}>
                <TargetListEditor value={selectedList} list={list} min={min} onChange={v => setSelectedList(v)} />
              </Form.Item>
            </Form>
          </>
        )}
      </Drawer>
    </>
  );
});
