import React, { CSSProperties, useCallback, useEffect, useMemo, useState } from 'react';
import cx from 'classnames';

import { Button, ButtonProps, Input, Modal, Space, Table, Tooltip } from '@ecom/auxo';
import { ColumnsType } from '@ecom/auxo/es/components/table';

import CheckModal from './components/check-modal';
import { TagInputII } from './components/tag-input-ii';
import withOkPipe from './hocs/withOkPipe';

import tagInputStyles from './components/tag-input-ii/index.module.scss';
import styles from './dikar-pool-manually.module.scss';

export interface DikarPoolManuallyStruct {
  entity_ids: string[];
  pool_name: string;
}

export interface DikarPoolManuallyProps {
  btnText?: string;
  maxLength?: number;
  name?: string;
  style?: CSSProperties;
  showError?: boolean;
  showPreview?: boolean;
  showBackground?: boolean;
  showOkBtn?: boolean;
  value?: string[];
  okText?: string;
  okPipeText?: string;
  cancelText?: string;
  tips?: string | React.ReactNode;
  buttonProps?: ButtonProps & { tooltipTitle?: string };
  modalProps?: Record<string, any>;
  clearMode?: boolean;
  tipName?: string;
  /** 是否需要去重 */
  noUnique?: boolean;
  /** 点击ok时 管道流程组件 */
  okPipeComponent?: React.Component;
  onOk?: (val: DikarPoolManuallyStruct) => void;
  onCancel?: () => any;
  onChange?: (val: DikarPoolManuallyStruct) => void;
  validate?: (ids: DikarPoolManuallyStruct['entity_ids']) => Promise<ManuallyError[]>;
  check?: (ids: DikarPoolManuallyStruct['entity_ids']) => Promise<CheckError[]>;
}

export interface DikarPoolManuallyRef {
  show: (productIds?: string[]) => void;
}

export interface TagInputValue {
  tags: string[];
  errors: string[];
}

export interface ManuallyError {
  id: string;
  message: string;
}

export interface CheckError {
  id: string;
  name: string;
}

const DikarPoolManually: React.ForwardRefRenderFunction<DikarPoolManuallyRef, DikarPoolManuallyProps> = (
  props,
  ref,
) => {
  const [initial, setInitial] = useState<string[]>();
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [modalErrors, setModalErrors] = useState<CheckError[]>([]);
  const [poolName, setPoolName] = useState<string>('');

  const {
    btnText = '',
    value = [],
    maxLength = 200,
    okText = '录入',
    okPipeText = '录入',
    cancelText = '取消',
    name = '商品',
    tipName,
    showError = true,
    showPreview = true,
    showBackground = false,
    showOkBtn = true,
    clearMode = false,
    tips,
    buttonProps = {},
    style = {},
    modalProps = {},
    noUnique = false,
    okPipeComponent,
    check,
    validate,
    onOk,
    onCancel,
    onChange,
  } = props;
  const [tags, setTags] = useState<string[]>(value);
  const [errors, setErrors] = useState<ManuallyError[]>([]);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [visible, setVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const errorTags = useMemo(() => errors.map(error => error.id), [errors]);
  const OkPipeBtn = useMemo(
    () => (okPipeComponent ? withOkPipe(okPipeComponent, tags) : null),
    [okPipeComponent, tags],
  );

  React.useImperativeHandle(ref, () => ({
    ...((ref as React.MutableRefObject<DikarPoolManuallyRef>)?.current || {}),
    show: (productIds?: string[]) => {
      setVisible(true);
      if (productIds && productIds?.length > 0) {
        setTags(productIds);
      }
    },
  }));

  useEffect(() => {
    setInitial(value);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCancel = React.useCallback(async () => {
    onChange?.({
      entity_ids: initial || [],
      pool_name: '',
    });
    setTags(initial || []);
    setPoolName('');
    setErrors([]);
    setErrorMsg('');
    setVisible(false);
    onCancel?.();
  }, [initial, onCancel, onChange]);

  const handleRemoveErrors = useCallback(() => {
    const legalTags = tags?.filter(tag => !errorTags?.includes(tag));
    setTags(legalTags);
    onChange?.({
      entity_ids: legalTags,
      pool_name: poolName,
    });
    setErrors([]);
  }, [errorTags, onChange, poolName, tags]);

  const handleChangeTags = useCallback(
    (v: TagInputValue) => {
      if (v?.tags?.length > 0) {
        setErrorMsg('');
      }

      setTags(v?.tags);
      onChange?.({
        entity_ids: v?.tags,
        pool_name: poolName,
      });
      const newErrors: ManuallyError[] = [];

      errors?.forEach(e => {
        if (v?.tags?.includes(e.id)) {
          newErrors.push(e);
        }
      });

      setErrors(newErrors);
    },
    [errors, onChange, poolName],
  );

  const handleChangePoolName = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setPoolName(e.target.value);

      onChange?.({
        entity_ids: tags,
        pool_name: e.target.value,
      });
    },
    [onChange, tags],
  );

  const checkTags = useCallback(
    async (v: string[]): Promise<void> => {
      const checkErrors = (await check?.(v)) || [];
      if (checkErrors?.length > 0) {
        setModalErrors(checkErrors);
        setModalVisible(true);
      } else {
        setModalErrors([]);
        setModalVisible(false);
      }
    },
    [check],
  );

  const handleOk = useCallback(async () => {
    if (tags?.length === 0) {
      setErrorMsg(`${tipName || name}id不能为空`);
      return;
    }

    setLoading(true);

    try {
      const errs = (await validate?.(tags)) || [];
      if (errs?.length > 0) {
        setErrors(errs);
      } else {
        // 检查id合法性 (非强卡)
        if (check) {
          checkTags(tags || []);
        }
        onOk?.({
          entity_ids: tags,
          pool_name: poolName,
        });
        setInitial(tags);
        setVisible(false);
        if (clearMode) {
          setTags([]);
          setInitial([]);
        }
      }
    } catch {
    } finally {
      setLoading(false);
    }
  }, [check, checkTags, clearMode, name, onOk, poolName, tags, tipName, validate]);

  const handlePipeValidateError = React.useCallback((errs: ManuallyError[]) => {
    if (errs?.length > 0) {
      setErrors(errs);
    }
  }, []);

  const columns: ColumnsType<ManuallyError> = [
    {
      title: `${name} ID`,
      key: 'id',
      dataIndex: 'id',
    },
    {
      title: '报错原因',
      key: 'message',
      dataIndex: 'message',
    },
  ];

  const renderInputModalFooter = React.useMemo(() => {
    const okPipeBtn = OkPipeBtn ? (
      <OkPipeBtn type="primary" loading={loading} onOk={handleOk} onValidateError={handlePipeValidateError}>
        {okPipeText}
      </OkPipeBtn>
    ) : null;
    const okBtn = showOkBtn ? (
      <Button type="primary" loading={loading} onClick={handleOk}>
        {okText}
      </Button>
    ) : null;
    return (
      <Space>
        {okPipeBtn}
        {okBtn}
        <Button loading={loading} onClick={handleCancel}>
          {cancelText}
        </Button>
      </Space>
    );
  }, [OkPipeBtn, loading, handleOk, handlePipeValidateError, okPipeText, showOkBtn, okText, handleCancel, cancelText]);

  return (
    <div
      className={cx({
        [styles.background]: showBackground,
      })}
      style={style}
    >
      {buttonProps.disabled ? (
        <Tooltip title={buttonProps.tooltipTitle}>
          <Button type="dashed" {...buttonProps}>
            {btnText || `录入${name || '素材'}`}
          </Button>
        </Tooltip>
      ) : (
        <Button
          type="dashed"
          onClick={() => {
            setVisible(true);
          }}
          {...buttonProps}
        >
          {btnText || `录入${name || '素材'}`}
        </Button>
      )}

      {showPreview && tags?.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <TagInputII
            readOnly
            showLimit
            maxLength={maxLength}
            className={styles.tagInput}
            onChange={handleChangeTags}
            noUnique={noUnique}
            value={{ tags: tags, errors: [] }}
          />
        </div>
      )}

      <CheckModal
        visible={modalVisible}
        errors={modalErrors}
        onCancel={() => {
          setModalErrors([]);
          setModalVisible(false);
        }}
        onOk={() => {
          setModalErrors([]);
          setModalVisible(false);
        }}
        modalProps={modalProps}
      />

      <Modal
        className={styles.modal}
        title={`录入${name}`}
        destroyOnClose
        visible={visible}
        footer={renderInputModalFooter}
        onCancel={handleCancel}
        // okText={okText}
        // cancelText={cancelText}
        // onOk={handleOk}
        // okButtonProps={{ loading }}
      >
        {tips}
        <Space direction="vertical" className={styles.formSpace}>
          <div className={styles.formItem}>
            <div className={styles.formItemLabel}>圈选包名称</div>
            <Input onChange={handleChangePoolName} value={poolName} placeholder="请输入圈选包名称" />
          </div>
          <div className={styles.formItem}>
            <div className={styles.formItemLabel}>圈选包商品</div>
            <TagInputII
              showLimit
              maxLength={maxLength}
              placeholder={`请输入${
                tipName || name
              }ID，支持批量粘贴，请用英文逗号、空格、回车隔开，最多支持${maxLength}个ID`}
              className={cx({
                [styles.tagInput]: true,
                [tagInputStyles.tagInputError]: errorMsg,
              })}
              noUnique={noUnique}
              onChange={handleChangeTags}
              value={{ tags, errors: errorTags }}
            />
          </div>
        </Space>

        {errorMsg && (
          <div>
            <span className={styles.errorTip}>{errorMsg}</span>
          </div>
        )}

        {errors?.length > 0 && showError && (
          <>
            <div>
              <span className={styles.errorTip}>
                共有{errors.length}个{name}ID识别失败
              </span>

              <Button type="link" onClick={handleRemoveErrors} style={{ marginLeft: 16 }}>
                一键清空失效{name}
              </Button>
            </div>

            <div className={styles.tableContainer}>
              <b>以下{name}识别失败</b>
              <Table
                rowKey="id"
                className={styles.table}
                scroll={{ y: 160 }}
                pagination={false}
                dataSource={errors}
                columns={columns}
              />
            </div>
          </>
        )}
      </Modal>
    </div>
  );
};

export default React.forwardRef(DikarPoolManually);
