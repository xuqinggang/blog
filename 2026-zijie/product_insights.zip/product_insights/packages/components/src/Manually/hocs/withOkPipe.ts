import React from 'react';
import { omit } from 'lodash-es';

export default function withOkPipe(OkPipeBtnComponent: any, ids: string[]) {
  return function (props: any) {
    const { onOk, onValidateError, inject } = props;
    const componentProps: any = Object.assign({}, omit(props, ['onOk', 'onValidateError']), {
      inject: {
        ...(inject || {}),
        onOk,
        onValidateError,
        ids,
      },
    });
    return React.createElement(OkPipeBtnComponent, componentProps);
  };
}

export function withOkPipeInject(OkPipeBtnComponent: any, injectParams: Record<string, unknown>) {
  return function (props: any) {
    const { inject } = props;
    const componentProps: any = Object.assign({}, props || {}, {
      inject: {
        ...(inject || {}),
        injectParams: Object.assign({}, inject?.injectParams || {}, injectParams || {}),
      },
    });
    return React.createElement(OkPipeBtnComponent, componentProps);
  };
}
