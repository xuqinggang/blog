import React from 'react';
import classNames from 'classnames';

import { DraggableAttributes, UniqueIdentifier } from '@dnd-kit/core';
import { SyntheticListenerMap } from '@dnd-kit/core/dist/hooks/utilities';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

import { useDropContext } from './drop-container';

export interface CommonDragItem {
  id: UniqueIdentifier;
}

interface DragItemProps<T extends CommonDragItem = CommonDragItem> {
  item: T;
  className?: string;
  disabledDrag?: boolean;
  children: (opts: {
    attributes: DraggableAttributes;
    listeners?: SyntheticListenerMap;
  }) => React.ReactElement<HTMLElement>;
}

export function DragItem<T extends CommonDragItem = CommonDragItem>(props: DragItemProps<T>) {
  const { item, className, disabledDrag, children } = props;
  const { grabbing, dragId } = useDropContext();

  const { setNodeRef, attributes, listeners, transform, transition } = useSortable({
    id: item.id,
    disabled: disabledDrag,
    transition: {
      duration: 500,
      easing: 'cubic-bezier(0.25, 1, 0.5, 1)',
    },
  });
  const styles = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div ref={setNodeRef} style={styles} className={classNames(className, { 'z-10': dragId === item.id && grabbing })}>
      {children({ attributes, listeners })}
    </div>
  );
}
