import React, { PropsWithChildren, useContext, useState } from 'react';

import {
  closestCenter,
  DndContext,
  DragEndEvent,
  DragMoveEvent,
  DragStartEvent,
  MouseSensor,
  TouchSensor,
  UniqueIdentifier,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import { restrictToParentElement } from '@dnd-kit/modifiers';
import { arrayMove, rectSortingStrategy, SortableContext } from '@dnd-kit/sortable';

import { CommonDragItem } from './drag-item';

export type GetMoveIndex<T> = (
  array: T[],
  event: DragMoveEvent,
) => {
  activeIndex: number;
  overIndex: number;
};

interface DropContainerProps<T, U extends CommonDragItem = CommonDragItem> {
  value: T[];
  items: U[];
  getMoveIndex: GetMoveIndex<T>;
  onChange?: (v: T[]) => void;
}

const DropContext = React.createContext<{
  grabbing: boolean;
  dragId: UniqueIdentifier;
}>({
  grabbing: false,
  dragId: '',
});

export function DropContainer<T, U extends CommonDragItem = CommonDragItem>(
  props: PropsWithChildren<DropContainerProps<T, U>>,
) {
  const { value, items, children, getMoveIndex, onChange } = props;
  const [grabbing, setGrabbing] = useState(false);
  const [dragId, setDragId] = useState<UniqueIdentifier>('');

  const mouseSensor = useSensor(MouseSensor, {
    activationConstraint: {
      distance: 10,
    },
  });
  const touchSensor = useSensor(TouchSensor, {
    activationConstraint: {
      delay: 200,
      tolerance: 0,
    },
  });

  const sensors = useSensors(mouseSensor, touchSensor);

  const onDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!active || !over) {
      // 处理边界情况
      setGrabbing(false);
      setDragId('');
      return;
    }

    const moveValue = [...value];
    const { activeIndex, overIndex } = getMoveIndex(moveValue, event);

    if (activeIndex !== overIndex) {
      const newValue = arrayMove(moveValue, activeIndex, overIndex);
      onChange?.(newValue);
    }

    setGrabbing(false);
    setDragId('');
  };

  const onDragStart = (event: DragStartEvent) => {
    setGrabbing(true);
    setDragId(event.active.id);
  };

  return (
    <DropContext.Provider value={{ grabbing, dragId }}>
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={onDragEnd}
        onDragStart={onDragStart}
        modifiers={[restrictToParentElement]}
      >
        <SortableContext items={items} strategy={rectSortingStrategy}>
          {children}
        </SortableContext>
      </DndContext>
    </DropContext.Provider>
  );
}

export function useDropContext() {
  return useContext(DropContext);
}
