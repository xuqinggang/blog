export const dragHandles = [
  {
    id: 'left',
    direction: ['left' as const],
    classNames: 'draggable-window__resizer draggable-window__resizer-left',
  },
  {
    id: 'right',
    direction: ['right' as const],
    classNames: 'draggable-window__resizer draggable-window__resizer-right',
  },
  {
    id: 'top',
    direction: ['top' as const],
    classNames: 'draggable-window__resizer draggable-window__resizer-top',
  },
  {
    id: 'bottom',
    direction: ['bottom' as const],
    classNames: 'draggable-window__resizer draggable-window__resizer-bottom',
  },
  {
    id: 'top-left',
    direction: ['top' as const, 'left' as const],
    classNames: 'draggable-window__resizer draggable-window__resizer-top-left',
  },
  {
    id: 'bottom-right',
    direction: ['bottom' as const, 'right' as const],
    classNames: 'draggable-window__resizer draggable-window__resizer-bottom-right',
  },
  {
    id: 'top-right',
    direction: ['top' as const, 'right' as const],
    classNames: 'draggable-window__resizer draggable-window__resizer-top-right',
  },
  {
    id: 'bottom-left',
    direction: ['bottom' as const, 'left' as const],
    classNames: 'draggable-window__resizer draggable-window__resizer-bottom-left',
  },
];
