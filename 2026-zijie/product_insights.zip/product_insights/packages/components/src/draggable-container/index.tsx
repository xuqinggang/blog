import React, { forwardRef, useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { useUpdateEffect } from 'ahooks';
import { createPortal } from 'react-dom';

import { dragHandles } from './handles';

import './index.less';

export const DRAGGABLE_WINDOW_HEADER_HEIGHT = 64;
export const DRAGGABLE_WINDOW_BOUNDING = 16;
export const DRAGGABLE_WINDOW_DEFAULT_WIDTH = 600;
const DOUBLE = 2;
const MIN_WINDOW = { height: 400, width: 300 };
const Z_INDEX = 1030;

export function getDefaultWindowPosition() {
  return {
    width: DRAGGABLE_WINDOW_DEFAULT_WIDTH,
    // eslint-disable-next-line @typescript-eslint/no-magic-numbers
    height: window.innerHeight - 2 * DRAGGABLE_WINDOW_BOUNDING - 64,
    // eslint-disable-next-line @typescript-eslint/no-magic-numbers
    x: window.innerWidth - DRAGGABLE_WINDOW_DEFAULT_WIDTH - DRAGGABLE_WINDOW_BOUNDING,
    y: DRAGGABLE_WINDOW_HEADER_HEIGHT + DRAGGABLE_WINDOW_BOUNDING,
  };
}
export interface WindowPosition {
  x: number;
  y: number;
  width: number;
  height: number;
}
export interface DraggableWindowRef {
  position: WindowPosition;
  setPosition: (p: WindowPosition) => void;
  setZIndex?: (zIndex: number) => void;
  recoverZIndex?: () => void;
}

type DraggableWindowProps = React.PropsWithChildren<{
  id?: string;
  hidden?: boolean;
  title?: React.ReactElement;
  style?: React.CSSProperties;
  embedded?: boolean;
  position?: Partial<WindowPosition>;
}>;
export const DraggableWindow = forwardRef<DraggableWindowRef, DraggableWindowProps>(
  ({ id, title, children, style, hidden, embedded, position: propsPosition }: DraggableWindowProps, ref) => {
    const { pathname } = location;
    const [position, setPosition] = useState({
      ...getDefaultWindowPosition(),
      ...propsPosition,
    });
    const [zIndex, setZIndex] = useState(Z_INDEX);
    const isDragging = useRef(false);
    const resizingDirection = useRef<('right' | 'bottom' | 'top' | 'left')[] | null>(null);
    const offset = useRef({ x: 0, y: 0 });
    const windowRef = useRef<HTMLDivElement>(null);

    const startDrag = useCallback((e: React.MouseEvent) => {
      if (windowRef.current) {
        const rect = windowRef.current.getBoundingClientRect();
        offset.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
      }
      isDragging.current = true;
    }, []);

    const startResize = useCallback((e: React.MouseEvent, direction: ('right' | 'bottom' | 'top' | 'left')[]) => {
      e.stopPropagation();
      resizingDirection.current = direction;
    }, []);

    const onDrag = useCallback(
      (e: MouseEvent) => {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        isDragging.current && moveWindow(e.clientX - offset.current.x, e.clientY - offset.current.y);
      },
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [isDragging, offset, hidden],
    );

    const endDragOrResize = useCallback(() => {
      isDragging.current = false;
      resizingDirection.current = null;
    }, []);

    const resizeWindow = useCallback(
      (x: number, y: number) => {
        if (resizingDirection.current && windowRef.current && !hidden) {
          const rect = windowRef.current.getBoundingClientRect();
          if (resizingDirection.current.includes('right')) {
            const maxWidth = window.innerWidth - rect.left - DRAGGABLE_WINDOW_BOUNDING;
            const newWidth = Math.min(maxWidth, Math.max(MIN_WINDOW.width, x - rect.left));
            setPosition(size => ({ ...size, width: newWidth }));
          }
          if (resizingDirection.current.includes('left')) {
            const maxWidth = rect.right - DRAGGABLE_WINDOW_BOUNDING;
            const newWidth = Math.min(maxWidth, Math.max(MIN_WINDOW.width, rect.right - x));
            const newX = rect.right - newWidth;
            setPosition(size => ({ ...size, x: newX, width: newWidth }));
          }
          if (resizingDirection.current.includes('bottom')) {
            const newHeight = Math.max(MIN_WINDOW.height, y - rect.top);
            const maxHeight = window.innerHeight - rect.top - DRAGGABLE_WINDOW_BOUNDING;
            setPosition(size => ({ ...size, height: Math.min(maxHeight, newHeight) }));
          }
          if (resizingDirection.current.includes('top')) {
            const maxHeight = rect.bottom - DRAGGABLE_WINDOW_BOUNDING;
            const newHeight = Math.min(maxHeight, Math.max(MIN_WINDOW.height, rect.bottom - y));
            const newY = rect.bottom - newHeight;
            setPosition(prevPosition => ({ ...prevPosition, y: newY, height: newHeight }));
          }
        }
      },
      [hidden],
    );

    const moveWindow = useCallback(
      (x?: number, y?: number) => {
        if (windowRef.current && !hidden) {
          const rect = windowRef.current.getBoundingClientRect();
          const rightEdge = window.innerWidth - rect.width - DRAGGABLE_WINDOW_BOUNDING;
          const bottomEdge = window.innerHeight - rect.height - DRAGGABLE_WINDOW_BOUNDING;
          const clampedX = Math.max(DRAGGABLE_WINDOW_BOUNDING, Math.min(x ?? rect.x, rightEdge));
          const clampedY = Math.max(DRAGGABLE_WINDOW_BOUNDING, Math.min(y ?? rect.y, bottomEdge));
          const clampedHeight = Math.max(
            Math.min(window.innerHeight - DOUBLE * DRAGGABLE_WINDOW_BOUNDING, rect.height),
            MIN_WINDOW.height,
          );
          const clampedWidth = Math.max(
            Math.min(window.innerWidth - DOUBLE * DRAGGABLE_WINDOW_BOUNDING, rect.width),
            MIN_WINDOW.width,
          );
          setPosition(() => ({ height: clampedHeight, width: clampedWidth, x: clampedX, y: clampedY }));
        }
      },
      [hidden],
    );

    useImperativeHandle(
      ref,
      () => ({
        position,
        setPosition: e => {
          setPosition(e);
          window.setTimeout(() => moveWindow(), 0); // next tick
        },
        setZIndex: (number: number) => {
          setZIndex(number);
        },
        recoverZIndex: () => {
          setZIndex(Z_INDEX);
        },
      }),
      [moveWindow, position],
    );

    // position受控
    useUpdateEffect(() => {
      if (propsPosition) {
        setPosition(prevPosition => ({
          ...prevPosition,
          ...propsPosition,
        }));
      }
    }, [propsPosition]);

    useEffect(() => {
      const handleMouseMove = (e: MouseEvent) => {
        requestAnimationFrame(() => {
          isDragging.current && onDrag(e);
          resizingDirection.current && resizeWindow(e.clientX, e.clientY);
        });
      };

      const handleMouseUp = () => endDragOrResize();
      const handleResize = () => moveWindow();

      window.addEventListener('resize', handleResize);
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);

      return () => {
        window.removeEventListener('resize', handleResize);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }, [onDrag, resizeWindow, endDragOrResize, moveWindow]);

    useEffect(() => {
      setZIndex(hidden ? -10000 : Z_INDEX);
    }, [hidden]);

    if (embedded) {
      return (
        <div className="embedded-window" style={{ visibility: hidden ? 'hidden' : 'visible' }} ref={windowRef} id={id}>
          <div className="embedded-window__content">
            <div className="embedded-window__header">{title}</div>
            <div className="embedded-window__body">{children}</div>
          </div>
        </div>
      );
    }

    return createPortal(
      <div
        ref={windowRef}
        id={id}
        className="draggable-window"
        style={{
          transform: `translate(${position.x}px, ${position.y}px)`,
          width: position.width,
          height: position.height,
          zIndex,
          ...style,
        }}
      >
        <div className="draggable-window__content">
          <div onMouseDown={startDrag} className="draggable-window__header">
            {title}
          </div>
          <div className="draggable-window__body">{children}</div>
        </div>
        {dragHandles.map(({ id, direction, classNames }) => (
          <div key={id} className={classNames} onMouseDown={e => startResize(e, direction)} />
        ))}
      </div>,
      // 查找 data-pid 为当前 pathname 的节点，不存在则回退到 body
      document.querySelector(`[data-pid="/product_insight${pathname}"]`) || document.body,
    );
  },
);
