import dayjs from 'dayjs';

import { DimensionType, DimGroupItem, FilterDateRange } from './filter-form/types';

import { DimensionAttributeType } from '~/api/product/namespaces/dimensions';

// 缓存维度数据的key前缀
export const DIMENSION_CACHE_KEY_PREFIX = 'INSIGHT_CACHE_DIMENSION_V2';

// 缓存下钻筛选项的key前缀
export const DRILL_CACHE_KEY_PREFIX = 'INSIGHT_DRILL_FILTER';

// 缓存最近筛选项的key
export const LATEST_CACHE_KEY_PREFIX = 'INSIGHT_LATEST_FILTER';

// 商品分析默认日期选择范围
export const PRODUCT_ANALYSIS_DEFAULT_DATE: FilterDateRange = {
  start_date: dayjs().subtract(1, 'week').startOf('week'),
  end_date: dayjs().subtract(1, 'week').endOf('week'),
  compare_start_date: dayjs().subtract(2, 'week').startOf('week'),
  compare_end_date: dayjs().subtract(2, 'week').endOf('week'),
};

// 价格力趋势分析默认日期选择范围（默认选择4周）
export const PRICE_ANALYSIS_DEFAULT_DATE: Omit<FilterDateRange, 'compare_start_date' | 'compare_end_date'> = {
  start_date: dayjs().subtract(4, 'week').startOf('week'),
  end_date: dayjs().subtract(1, 'week').endOf('week'),
};

// 价格力aa变化默认日期选择范围（默认选择1周）
export const PRICE_COMPARE_DEFAULT_DATE: Omit<FilterDateRange, 'compare_start_date' | 'compare_end_date'> = {
  start_date: dayjs().subtract(1, 'week').startOf('week'),
  end_date: dayjs().subtract(1, 'week').endOf('week'),
};

// 价格力aa变化必选维度
export const PRICE_COMPARE_REQUIRED_DIMS: Array<{ id: string; name: string }> = [
  { id: '10050', name: '站外价格力变化' },
  { id: '10051', name: '站内价格力变化' },
];

// 展示特殊提示的维度
export const SPECIAL_TIPS_DIMS: Array<{ id: string; name: string }> = [{ id: '10102', name: '自定义货盘' }];

// 操作符仅有包含的维度
export const OP_ONLY_IN_DIMS: Array<{ id: string; name: string }> = [{ id: '10102', name: '自定义货盘' }];

// 维度key列表
export const DIMENSION_TYPE_LIST = ['user_dimensions', 'product_dimensions', 'place_dimensions', 'order_dimensions'];

export const DIM_GROUPS: Array<DimGroupItem> = [
  { name: '商品属性', key: 'product_dimensions', attrType: DimensionAttributeType.Product },
  { name: '用户属性', key: 'user_dimensions', attrType: DimensionAttributeType.User },
  { name: '场域属性', key: 'place_dimensions', attrType: DimensionAttributeType.Place },
  { name: '订单属性', key: 'order_dimensions', attrType: DimensionAttributeType.Order },
];

export const DIM_KEY_MAP: Record<DimensionType, DimensionAttributeType> = {
  user_dimensions: DimensionAttributeType.User,
  product_dimensions: DimensionAttributeType.Product,
  place_dimensions: DimensionAttributeType.Place,
  order_dimensions: DimensionAttributeType.Order,
};

// 最小可选的分析指标个数
export const MIN_ANALYSIS_TARGET = 1;

// 最大可选的分析指标个数
export const MAX_ANALYSIS_TARGET = 12;

// 最小可选的多维分析维度个数
export const MIN_MULTI_DIM = 1;

// 最大可选的多维分析维度个数
export const MAX_MULTI_DIM = 3;

// 最大展示的报错维度个数
export const MAX_ERROR_DIM_COUNT = 5;

/** 单维度最大的枚举值数目 */
export const MAX_SINGLE_DIMENSION_ENUM_COUNT = 200;

/** 筛选区每页搜索的枚举值数目 */
export const ENUM_LIST_PAGE_SIZE = 10;

export const ServerRange = ['NEGATIVE_INFINITY', 'POSITIVE_INFINITY'];

/** 单维度最小枚举值数目 */
export const MIN_SINGLE_DIMENSION_ENUM_COUNT = 1;

// 模块缓存key（趋势分析、漏斗分析、商品榜单）
export const INSIGHT_CACHE_MODULE_KEY = 'INSIGHT_CACHE_MODULE';

/** 关闭掉的通知列表缓存key */
export const INSIGHT_CACHE_CLOSE_NOTICE = 'INSIGHT_CACHE_CLOSE_NOTICE';

// 特殊的维度id
export const BIG_ACTIVITY_DIM_ID = '10366'; // 大促维度id
export const PROD_COLLECTION_DIM_ID = '10365'; // 招商选品集id
export const CUSTOM_POOL_DIM_ID = '10102'; // 自定义货盘id
export const PROD_BRAIN_DIM_ID = '92002'; // 选品大脑货品id
