/** @type {import('tailwindcss').Config} */
import type { Config } from 'tailwindcss';

import colors from '../../config/tailwind-color.json';

export default {
  content: ['./src/**/*.{html,js,ts,tsx,jsx}', './docs/**/*.{mdx}'],
  theme: {
    extend: {
      colors: {
        red: '#ff4d4d',
        green: '#27c24e',
        desc: '#898B8F',

        ...colors,
      },
    },
  },
  variants: {
    extends: {
      opacity: ['hover', 'group-hover'],
    },
  },
} as Config;
