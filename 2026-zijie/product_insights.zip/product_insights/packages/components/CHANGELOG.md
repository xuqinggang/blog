# @ecom/product-insights-components

## 1.0.0

### Major Changes

- 修改筛选表单初始化
- 移除改动
- 测试
- 增加订阅弹窗
- 移除 tooltip
- 修改
- 修改订阅弹窗
- 增加禁用能力
- 增加参数透传
- 修改参数透传

## 0.0.0

### Patch Changes

- 修复商品状态监控高价

## 0.5.5

### Patch Changes

- 92b0f97: 修改监控抽屉
- 对外透出更多组件和方法内容
- c9c812c: 增加 CrossDimPicker 导出
- 2050aff: 修改监控规则默认 logic

## 0.0.0

### Patch Changes

- 51d1734: 组件库初始化
