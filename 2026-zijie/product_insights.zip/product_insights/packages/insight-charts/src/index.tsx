import { FC } from 'react';

import ErrorBoundary from '@ecom/auxo/es/components/alert/component/ErrorBoundary';

import { VSeedRenderer } from './components/renderer/vseed-render';
import { InsightChartRender } from './components';
import { ChartSchema, isInsightSchema } from './types';

import '@ecom/auxo/dist/auxo.min.css';

export * from './types';
export * from './components';
export * from './material';
export interface InsightChartProps {
  schema: ChartSchema;
}

export const InsightChart: FC<InsightChartProps> = ({ schema }) => {
  if (isInsightSchema(schema)) {
    return (
      <ErrorBoundary>
        <InsightChartRender schema={schema} />
      </ErrorBoundary>
    );
  }
  return (
    <ErrorBoundary>
      <VSeedRenderer schema={schema} />
    </ErrorBoundary>
  );
};
