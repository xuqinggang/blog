export interface TableMaterialProps {
  rowData: Record<string, any>;
  dataIndex: string;
}
