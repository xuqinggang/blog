import { FC } from 'react';
import { get } from 'lodash-es';

import { formatNumber } from '../../utils';
import { TableMaterialProps } from '../types';

import './index.less';

interface TablePercentageCellProps extends TableMaterialProps {
  rowData: Record<string, unknown>;
  dataIndex: string;
  percentageIndex?: string;
}
export const TablePercentageCell: FC<TablePercentageCellProps> = ({ rowData, dataIndex, percentageIndex }) => {
  const valueOrigin = get(rowData, dataIndex);
  const value = valueOrigin !== undefined ? Number(valueOrigin) : 0;
  const p_key = percentageIndex || `${dataIndex}_percentage`;
  const pValueOrigin = get(rowData, p_key);
  const pValue = pValueOrigin !== undefined ? Number(pValueOrigin) : undefined;
  return (
    <div className="table_percentage_cell">
      {pValue ? <div className="cell_bg" style={{ width: `${pValue * 100}%` }} /> : null}
      <div className="cell_text">
        <div className="cell_absolute_value">{formatNumber(value)}</div>
        {pValue !== undefined ? (
          <div className="cell_percentage_value">
            {formatNumber(pValue, {
              format: '%',
            })}
          </div>
        ) : null}
      </div>
    </div>
  );
};
