import { FC } from 'react';

import { TableMaterialProps } from '../types';

export const GylCategoryCell: FC<TableMaterialProps> = ({ rowData }) => {
  const { aim, group, sub_cnt, category } = rowData;

  if (category) {
    return <div>{category}</div>;
  }
  return (
    <div>
      <div>{aim}</div>
      <div>{group}</div>
      <div>共{sub_cnt}个策略</div>
    </div>
  );
};
