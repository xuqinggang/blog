interface FormatNumberOptions {
  format?: 'absolute' | '%' | 'pp';
  digits?: number;
  showSign?: boolean;
  comma?: boolean;
  signs?: {
    positive: string;
    negative: string;
    equal: string;
  };
}
export const formatNumber = (num: number, options?: FormatNumberOptions) => {
  const { format = 'absolute', digits = 2, comma = true, showSign = false, signs } = options || {};

  let showNum = num;
  if (format === '%' || format === 'pp') {
    showNum = showNum * 100;
  }
  let showNumStr = showNum.toFixed(digits);
  if (comma) {
    // eslint-disable-next-line @ecom/security-unsafe-regex
    showNumStr = showNumStr.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  if (format === '%' || format === 'pp') {
    showNumStr += format;
  }
  if (showSign) {
    const sign = signs?.[num >= 0 ? 'positive' : 'negative'] || '';
    return `${sign}${showNumStr}`;
  }
  return showNumStr;
};

export const generateRandomId = (len = 12) => {
  let randomStr = Math.random().toString(36).substring(2);
  if (randomStr.length < len) {
    randomStr += Math.random().toString(36).substring(2);
  }
  return randomStr.substring(0, len);
};
