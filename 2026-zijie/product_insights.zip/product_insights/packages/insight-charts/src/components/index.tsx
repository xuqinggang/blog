import { FC } from 'react';

import { ChartSchema } from '../types';
import { InsightChartType } from '../types/chart_type';

import { ChartTable } from './chart/table';

export interface InsightChartProps {
  className?: string;
  style?: React.CSSProperties;
  schema: ChartSchema;
}

export const InsightChartRender: FC<InsightChartProps> = ({ className, style, schema }) => {
  const { chartType } = schema;
  const renderChart = () => {
    switch (chartType) {
      case InsightChartType.InsightTable:
        return <ChartTable schema={schema} />;
      default:
        return null;
    }
  };
  return (
    <div className={className} style={style}>
      {renderChart()}
    </div>
  );
};
