import { PureComponent } from 'react';

export class ErrorBoundary extends PureComponent {
  state = {
    hasError: false,
  };
  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error(`ERROR 🦁 [>>>>>>] `, error, info);
    this.setState({ hasError: true });
  }

  render() {
    const { hasError } = this.state;
    if (hasError) {
      return <div>组件运行出错了</div>;
    }
    return this.props.children;
  }
}
