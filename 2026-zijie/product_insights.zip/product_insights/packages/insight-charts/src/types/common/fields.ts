export interface Field {
  /** 字段ID 字段的标识，需要保持唯一 */
  id: string;
  /** 字段名称，用于进行渲染 */
  name: string;
  type: 'measure' | 'dimension';
}
