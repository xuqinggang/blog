export enum InsightChartType {
  /** 表格 */
  InsightTable,
}
