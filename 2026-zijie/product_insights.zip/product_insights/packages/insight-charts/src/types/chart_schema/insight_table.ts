import { Dataset } from '@visactor/vseed';

import { GylCategoryCell } from '../../material';
import { TablePercentageCell } from '../../material/table_percentage_cell';
import { TableMaterialProps } from '../../material/types';
import { InsightChartType } from '../chart_type';
import { Field } from '../common/fields';

export type ColGroup = {
  name: string;
  children: (ColGroup | string)[];
};

export interface RowGroup {
  deps: string[];
  dataIndex: string;
}

export enum TableMaterial {
  StandardWithPercentage,
  GylCategoryCell,
}
export const TABLE_MATERIAL_MAP: Record<TableMaterial, React.ComponentType<any>> = {
  [TableMaterial.StandardWithPercentage]: TablePercentageCell,
  [TableMaterial.GylCategoryCell]: GylCategoryCell,
};

export interface Schema_InsightTable {
  chartType: InsightChartType.InsightTable;
  fields: (Field & {
    material?: TableMaterial;
    render?: React.ComponentType<TableMaterialProps>;
  })[];
  col_groups?: ColGroup[];
  row_groups?: RowGroup[];
  dataset: Dataset;
}
