import { VSeed } from '@visactor/vseed';

import { Schema_InsightTable } from './chart_schema';
import { InsightChartType } from './chart_type';
export * from './chart_schema';

type InsightChartSchema = Schema_InsightTable;
export type ChartSchema = InsightChartSchema | VSeed;

export function isInsightSchema(schema: ChartSchema): schema is Schema_InsightTable {
  return Object.values(InsightChartType).includes(schema.chartType);
}

export type ChartSourceData = Record<string, unknown>[];
export { InsightChartType } from './chart_type';
