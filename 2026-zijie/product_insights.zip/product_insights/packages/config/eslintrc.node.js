module.exports = {
  root: true,
  extends: ['@gulux'],
  rules: {
    'prettier/prettier': 0,
    '@typescript-eslint/no-useless-constructor': 0,
    '@typescript-eslint/ban-ts-comment': 0,
    '@typescript-eslint/no-unused-vars': 0,
  },
  parserOptions: { tsconfigRootDir: __dirname },
};
