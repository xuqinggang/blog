module.exports = {
  root: true,
  plugins: ['simple-import-sort'],
  extends: [
    '@ecom/eslint-config/src/huatuo-base-std.js',
    '@ecom/eslint-config/src/ecom-react-std.js',
    '@ecom/eslint-config/src/ecom-base-std.js',
    '@ecom/eslint-config/src/ecom-typescript-std',
    'plugin:prettier/recommended',
  ],
  rules: {
    'simple-import-sort/imports': 'error',
    'react/react-in-jsx-scope': 'off',
    'react/jsx-uses-react': 'off',
    '@ecom/variable-length': 'off',
    'no-console': 'off',
    'no-nested-ternary': 'off',
    '@typescript-eslint/naming-convention': [
      'warn',
      {
        format: ['camelCase', 'snake_case', 'PascalCase', 'UPPER_CASE'],
        selector: ['memberLike', 'property'],
      },
    ],
    '@typescript-eslint/no-shadow': 'off',
  },
  overrides: [
    {
      files: ['**/*.js', '**/*.ts', '**/*.tsx'],
      rules: {
        'simple-import-sort/imports': [
          'error',
          {
            groups: [
              ['^react$', '^next', '^[a-z]'],
              ['^@[a-z]'],
              ['^@'],
              ['^~'],
              ['^\\.\\.(?!/?$)', '^\\.\\./?$'],
              ['^\\./(?=.*/)(?!/?$)', '^\\.(?!/?$)', '^\\./?$'],
              ['^.+\\.s?css$'],
              ['^\\u0000'],
            ],
          },
        ],
      },
    },
  ],
};
