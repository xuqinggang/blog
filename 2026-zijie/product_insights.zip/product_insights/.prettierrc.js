// 配置可参考 https://prettier.io/en/configuration.html
module.exports = {
  singleQuote: true,
  trailingComma: 'all',
  arrowParens: 'avoid',
  printWidth: 120,
  semi: true,
  tabWidth: 2,
};
