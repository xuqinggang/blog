package subscription

import (
	"context"
	"runtime/debug"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	subscription_service "code.byted.org/ecom/smartop_product_analysis/biz/service/subscription"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/subscription"
	eventbus "code.byted.org/eventbus/client-go"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"github.com/bytedance/sonic"
)

const (
	eventName = "platform.ecom.smartop.data.subcribe" // 在eventbus管理平台上注册的事件名称
	group     = "product_analysis"                    // 消费者组
)

var DimensionListDao = &dao.DimensionListDao{}
var DimensionEnumDao = &dao.DimensionEnumDao{}
var DimensionBizListDao = &dao.DimensionBizListDao{}
var AttributeDao = &dao.AttributeDao{}

var DimensionService = &dimension_service.DimensionService{
	DimensionListDao:    DimensionListDao,
	DimensionEnumDao:    DimensionEnumDao,
	AttributeDao:        AttributeDao,
	DimensionBizListDao: DimensionBizListDao,
}
var subService = &subscription_service.SubscriptionService{DimensionService: DimensionService}

func ConsumerRun() {
	if env.IsBoe() {
		return
	}
	ctx := context.Background()
	// 创建消费者配置，可通过conf配置worker数量，消息订阅tag等
	conf, err := eventbus.NewConsumerConfig(eventName, env.PSM(), group)
	if err != nil {
		panic(err)
	}

	// 指定tag。
	conf.Consumer.Tags = []string{"business_id_1000"}

	// 创建消费者
	c, err := eventbus.NewConsumer(conf, handler)
	if err != nil {
		logs.CtxError(ctx, "[ConsumerRun] NewConsumer error %v, stack: %v", err, debug.Stack())
		panic(err)
	}
	// 运行
	go func() {
		defer func() {
			if recoverErr := recover(); recoverErr != nil {
				logs.CtxError(ctx, "[ConsumerRun] panic error %v, stack: %v", recoverErr, debug.Stack())
				panic(recoverErr)
			}
		}()

		// 同步调用会阻塞当前goroutine
		if err = c.Run(); err != nil {
			panic(err)
		}
	}()
}

// 定义消息处理函数func
func handler(ctx context.Context, event *eventbus.ConsumerEvent) error {
	// 字段Key对应生产者发送消息的key，Value表示生产者发送的消息体内容
	logs.CtxInfo(ctx, "consume event key:%v,value:%v", event.Key, string(event.Value))
	logs.CtxInfo(ctx, "EventID: %v", event.ID()) // sdk版本大于1.5.0-Faas的Event需要转换一下，详情看评论
	// 始终返回nil，不使用eventbus SDK的重试。对于出错的任务订阅中台的调度可以重试
	logs.CtxInfo(ctx, "receive SubscriptionEvent, value: %v", string(event.GetValue()))
	var subReportMsg subscription_service.SubReportMsg
	if err := sonic.Unmarshal(event.GetValue(), &subReportMsg); err != nil {
		logs.CtxInfo(ctx, "SubscriptionEvent unmarshal error, value: %v, err: %v", string(event.GetValue()), err.Error())
		return nil
	}
	logs.CtxInfo(ctx, "SubscriptionHandler subReportMsg: %+v", subReportMsg)
	if subReportMsg.BusinessId != int64(subscription.BusinessId_ProductAnalysis) {
		return nil
	}
	if subReportMsg.TaskId == 0 {
		logs.CtxError(ctx, "SubscriptionHandler SendCard taskId=0, input=+%v", subReportMsg)
		return nil
	}
	err := subService.SendCard(ctx, subReportMsg)
	if err != nil {
		logs.CtxError(ctx, "SubscriptionHandler SendCard msg=+%v, error：%+v", subReportMsg, err.Error())
	}
	return nil
}
