package main

import (
	"context"
	"fmt"
	"os"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"

	"code.byted.org/gorm/bytedgen"
	"gorm.io/gen"
)

// GEN Guideline: https://bytedance.feishu.cn/wiki/wikcnbYLEL78aOYLBsT2ExUGiEd

// generate code
func main() {
	ctx := context.Background()
	fmt.Printf("CONSUL_HTTP_HOST=%s\n", os.Getenv("CONSUL_HTTP_HOST"))
	mysql.Init()

	g := bytedgen.NewGenerator(gen.Config{
		OutPath:      "dal/db/query",
		ModelPkgPath: "dal/db/model",
		//Mode:         gen.WithDefaultQuery,
	})

	g.UseDB(mysql.DB(ctx))

	g.ApplyBasic(
		g.GenerateModel("two_side_experiment_object_config"),
		g.GenerateModel("need_dump_dimension_info"),
		g.GenerateModel("target_meta"),
		g.GenerateModel("target_index_details"),
		g.GenerateModel("dump_dimension_date_relation"),
		g.GenerateModel("need_dump_prod_user_dimension"),
	)

	g.Execute()
}
