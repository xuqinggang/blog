package model

import "code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"

type TemplateInfo struct {
	TemplateId    string `json:"template_id"`
	IsCommon      bool   `json:"is_common"`
	Name          string `json:"name"`
	StructMarshal string `json:"struct_marshal"`
	Ext           string `json:"ext"`
}

type AnalysisRes struct {
	ProdSubSql   string                              `json:"prod_sub_sql"`
	WhereFilter  []*dimensions.SelectedDimensionInfo `json:"where_filter"`
	BizType      dimensions.BizType                  `json:"biz_type"`
	TopNFilter   []*dimensions.ThresholdAttr         `json:"top_n_filter"`
	AppendParams map[string]interface{}              `json:"append_params"`
}
