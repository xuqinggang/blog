package mongo_util

import (
	"context"
	"fmt"

	"code.byted.org/bytedoc/mongo-go-driver/mongo"
	"code.byted.org/bytedoc/mongo-go-driver/mongo/options"
)

var DB_NAME = "ecom_product_analysis"
var COLLECTION_RESULT = "activity_review_result"
var COLLECTION_BIZ_TASK = "activity_review_task"
var COLLECTION_JUPYTER_TASK = "activity_review_jupyter_task"

var client *mongo.Client = nil // client是全局变量
func GetClient() *mongo.Client {
	URI := "mongodb+consul+token://bytedance.bytedoc.ecom_product_analysis/ecom_product_analysis"
	client, err := mongo.Connect(context.Background(), options.Client().ApplyURI(URI))
	if err != nil {
		fmt.Printf("mongo connect err %v, uri=%s", err, URI)
	}
	return client
	// client.Disconnect(context.Background())
}
