package metric

import (
	m "code.byted.org/gopkg/metrics/v4"
	"fmt"
	"time"
)

var client m.Client

var initMetricNameTagMap = map[string][]string{
	"method_latency": {"biz_type", "method_name"},
	"method_count":   {"biz_type", "method_name"},
}

var nameMetricMap = map[string]m.Metric{}

func init() {
	var err error
	client, err = m.NewClient("ecom.smartop.product_analysis")
	if err != nil {
		panic(fmt.Sprintf("failed to create the client: %v\n", err))
	}

	//metric, err = client.NewMetricWithOps("my.metric", []string{"tag0", "tag1", "tag2"},
	//	m.SetHistogramBucket(m.LinearBuckets(1, 2, 3)),
	//	m.SetMultiFieldTimer(),
	//)
	for name, tagNames := range initMetricNameTagMap {
		metric, err := client.NewMetricWithOps(name, tagNames,
			m.SetHistogramBucket(m.LinearBuckets(1, 2, 3)),
			m.SetMultiFieldTimer(),
		)
		if err != nil {
			panic(fmt.Sprintf("failed to create metric %s: %v", name, err))
		}
		nameMetricMap[name] = metric
	}

}

func EmitTimer(name string, start time.Time, tags map[string]string) {
	milliSecond := time.Since(start).Milliseconds()
	tagsT := make([]m.T, 0, len(tags))
	for k, v := range tags {
		tagsT = append(tagsT, m.T{k, v})
	}
	if metric, ok := nameMetricMap[name]; ok {
		_ = metric.WithTags(tagsT...).Emit(
			m.Observe(int(milliSecond)),
			m.Incr(1),
			m.IncrCounter(1),
		)
	}
}
