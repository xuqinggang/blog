package tcc

import (
	"context"

	"code.byted.org/gopkg/pkg/errors"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/gopkg/logs/v2"
)

func GetDorisConfig(ctx context.Context) (*ai_analysis.DorisConfig, error) {
	var ret *ai_analysis.DorisConfig
	if err := GetTccConfWithUnmarshalTarget(ctx, "doris_config", &ret); err != nil {
		logs.CtxError(ctx, "GetDorisConfig Error, err=%v", err)
		return nil, errors.WithMessage(err, "GetDorisConfig Error, doris_config")
	}
	return ret, nil
}
