package tcc

import (
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/gopkg/tccclient"
	"context"
	"github.com/bytedance/sonic"
)

func GetTccConf(ctx context.Context, key string) (string, error) {
	res, err := GetInstance().Get(ctx, key)
	if err != nil {
		return "", errors.WithMessagef(err, "GetTccConf failed")
	}

	return res, nil
}

func GetKeyList(ctx context.Context) ([]string, error) {
	res, err := GetInstance().KeyList(ctx)
	if err != nil {
		return nil, errors.WithMessagef(err, "GetKeyList failed")
	}

	return res, nil
}

func GetTccConfWithUnmarshalTarget(ctx context.Context, key string, target interface{}) error {
	res, err := GetInstance().Get(ctx, key)
	if err != nil {
		return errors.WithMessagef(err, "GetTccConf failed")
	}

	err = sonic.UnmarshalString(res, target)
	if err != nil {
		return errors.WithMessagef(err, "GetTccConf, sonic.UnmarshalString failed")
	}

	return nil
}

func GetTccConfWithUnmarshalTargetByClient(ctx context.Context, client *tccclient.ClientV2, key string, target interface{}) error {
	res, err := client.Get(ctx, key)
	if err != nil {
		return errors.WithMessagef(err, "GetTccConf failed")
	}

	err = sonic.UnmarshalString(res, target)
	if err != nil {
		return errors.WithMessagef(err, "GetTccConf, sonic.UnmarshalString failed")
	}

	return nil
}
