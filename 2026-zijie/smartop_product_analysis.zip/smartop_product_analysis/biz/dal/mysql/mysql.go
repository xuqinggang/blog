package mysql

import (
	"context"
	"os"
	"sync"

	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gorm/bytedgorm"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
)

var (
	db     *gorm.DB
	dbName = "smartop_product_analysis"
	psm    = "toutiao.mysql.smartop_product_analysis"
	once   sync.Once
)

func Init() {
	once.Do(func() {
		initPSM := psm
		initDBName := dbName
		if env.IsPPE() || os.Getenv("cron_env") == "ppe" {
			initPSM += "_ppe"
			initDBName += "_ppe"
		}

		// init
		DB, err := gorm.Open(
			bytedgorm.MySQL(initPSM /*数据库PSM*/, initDBName /*数据库名*/).WithReadReplicas(),
			bytedgorm.WithDefaults(), bytedgorm.WithSingularTable(),
		)
		// check err
		if err != nil {
			panic(err)
		}
		db = DB
		if env.IsBoe() {
			db = db.Debug()
		}
		logs.Info("init mysql for %s success", psm)
	})
}

// WriteDB ...
func WriteDB(ctx context.Context) *gorm.DB {
	return db.Clauses(dbresolver.Write).WithContext(ctx)
}

// ReadDB ...
func ReadDB(ctx context.Context) *gorm.DB {
	return db.Clauses(dbresolver.Read).WithContext(ctx)
}

// Read write separation
func DB(ctx context.Context) *gorm.DB {
	return db.WithContext(ctx)
}
