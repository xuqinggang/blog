package redis

import (
	"context"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/gopkg/env"
	"code.byted.org/kv/goredis"
	"code.byted.org/temai/marketing_common/test_utils"
)

const (
	//FIXME 暂时用descition的吧
	redisPsmBOE = "toutiao.redis.ecom_marketing_decision"
	// 生产环境的redis库
	redisPsmPPE = "toutiao.redis.smartop_product_analysis"

	// 和实验平台共用redis库，修改前先联系@张隽睿确认
	growthExperimentRedisPsmPPE = "toutiao.redis.marketing_common_cache"
)

var Client *goredis.Client
var GrowthExperimentClient *goredis.Client

func Init() {
	var err, err2 error
	options := goredis.NewOptionWithTimeout(
		300*time.Millisecond,
		300*time.Millisecond,
		300*time.Millisecond,
		300*time.Millisecond,
		5*time.Minute,
		0,
		1000)
	options.SetMaxRetries(0)
	options.SetServiceDiscoveryWithConsul()
	if env.IsBoe() {
		Client, err = goredis.NewClientWithOption(redisPsmBOE, options)
		GrowthExperimentClient, err2 = goredis.NewClientWithOption(redisPsmBOE, options)
	} else {
		Client, err = goredis.NewClientWithOption(redisPsmPPE, options)
		GrowthExperimentClient, err2 = goredis.NewClientWithOption(growthExperimentRedisPsmPPE, options)
	}
	if err != nil {
		panic(err)
	}
	if err2 != nil {
		panic(err2)
	}
}

func GetRedis(ctx context.Context) *goredis.Client {
	if test_utils.IsMockMode() {
		e := test_utils.GetCurrentEnv()
		return e.Cache()
	}
	if clusterName, ok := ctx.Value(consts.CtxRedisCluster).(consts.ClusterName); ok {
		if clusterName == consts.ClusterName_GrowthExperimentPlatform {
			return GrowthExperimentClient.WithContext(ctx)
		}
	}
	return Client.WithContext(ctx)
}
