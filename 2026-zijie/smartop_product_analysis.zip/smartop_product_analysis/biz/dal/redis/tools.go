package redis

import (
	"code.byted.org/gopkg/logs"
	"code.byted.org/kv/redis-v6"
	"context"
	"time"
)

// MGet MIGHTDO: pipeline 命令超过50个可能有请求失败的风险。
func MGet(ctx context.Context, keys []string) (map[string]string, []string, error) {
	resultMap := make(map[string]string)
	missKeys := make([]string, 0)

	if len(keys) <= 0 {
		return nil, nil, nil
	}

	// 只有1个,不开ppl
	if len(keys) == 1 {
		for _, key := range keys {
			result, err := GetRedis(ctx).Get(key).Result()
			if err != nil {
				if err == redis.Nil {
					missKeys = append(missKeys, key)
				} else {
					missKeys = append(missKeys, key)
				}
				continue
			}
			resultMap[key] = result
		}

		return resultMap, missKeys, nil
	}

	pipeline := GetRedis(ctx).NewPipeline("PipelineGet")
	defer func() {
		_ = pipeline.Close()
	}()
	cmdMap := make(map[string]*redis.StringCmd)
	for _, key := range keys {
		cmdMap[key] = pipeline.Get(key)
	}
	_, err := pipeline.Exec()
	if err != nil {
		logs.CtxError(ctx, "pipeline exec error:%s", err.Error())
		return nil, nil, err
	}

	for key, cmd := range cmdMap {
		result, err := cmd.Result()
		if err != nil {
			if err == redis.Nil {
				missKeys = append(missKeys, key)
			} else {
				missKeys = append(missKeys, key)
			}
			continue
		}
		resultMap[key] = result
	}

	return resultMap, missKeys, nil
}

func MSet(ctx context.Context, kvs map[string]string, expires map[string]time.Duration) (map[string]error, error) {
	errMap := make(map[string]error)

	if len(kvs) == 0 {
		return nil, nil
	}

	// 只有1个,不开ppl
	if len(kvs) == 1 {
		for k, v := range kvs {
			resp, err := GetRedis(ctx).Set(k, v, expires[k]).Result()
			logs.CtxInfo(ctx, "set k:%v, v:%v, expires:%v, resp:%s", k, v, expires[k], resp)
			if err != nil {
				errMap[k] = err
			}
		}
		return errMap, nil
	}

	pipeline := GetRedis(ctx).NewPipeline("PipelineSet")
	defer func() {
		_ = pipeline.Close()
	}()
	cmdMap := make(map[string]*redis.StatusCmd)
	for key, value := range kvs {
		cmdMap[key] = pipeline.Set(key, value, expires[key])
	}

	_, err := pipeline.Exec()
	if err != nil {
		logs.CtxError(ctx, "pipeline exec error:%s", err.Error())
		return nil, err
	}

	for key, cmd := range cmdMap {
		_, err = cmd.Result()
		if err != nil {
			errMap[key] = err
		}
	}
	return errMap, nil
}

func MDel(ctx context.Context, keys []string) (map[string]error, error) {
	if len(keys) == 0 {
		return nil, nil
	}
	pipeline := GetRedis(ctx).NewPipeline("PipelineDel")
	defer func() {
		_ = pipeline.Close()
	}()
	cmdMap := make(map[string]*redis.IntCmd)
	for _, key := range keys {
		cmdMap[key] = pipeline.Del(key)
	}

	_, err := pipeline.Exec()
	if err != nil {
		logs.CtxError(ctx, "pipeline exec error:%s", err.Error())
		return nil, err
	}

	errMap := make(map[string]error)
	for key, cmd := range cmdMap {
		_, err = cmd.Result()
		if err != nil {
			errMap[key] = err
		}
	}
	return errMap, nil
}

func Del(ctx context.Context, key string) error {
	return GetRedis(ctx).Del(key).Err()
}

// PPLRPushWithExpire 设置缓存补偿, mq调用
func PPLRPushWithExpire(ctx context.Context, key string, value string, duration time.Duration) (err error) {
	defer func() {
		if err != nil {
			logs.CtxWarn(ctx, "PPLRPushWithExpire causes error: %v", err)
		}
	}()
	logs.CtxInfo(ctx, "PPLRPushWithExpire, key: %v, value: %v, duration: %v", key, value, duration)
	pip := GetRedis(ctx).Pipeline()
	pip.RPush(key, value)
	pip.Expire(key, duration)
	results, err := pip.Exec()
	if err != nil {
		return err
	}
	for _, cmder := range results {
		err = cmder.Err()
		if err != nil {
			return err
		}
	}
	return nil
}

func Set(ctx context.Context, key string, value string, duration time.Duration) (err error) {
	if _, err = GetRedis(ctx).Set(key, value, duration).Result(); err != nil {
		logs.CtxErrorKvs(ctx, "设置redis失败, key", key, "value", value, "err", err)
		return err
	}
	return nil
}

func Get(ctx context.Context, key string) (value string, err error) {
	value, err = GetRedis(ctx).Get(key).Result()
	if err == redis.Nil {
		return "", nil
	}
	return
}

func SetNx(ctx context.Context, key string, value string, duration time.Duration) (isSuccess bool, err error) {
	ret := GetRedis(ctx).SetNX(key, value, duration)
	return ret.Result()
}
