package export_data

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_aa_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"context"
)

type IExportService interface {
	GetProductAnalysisCoreOverviewDownload(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp bool, err error)
	GetProductAnalysisMultiDimProductListDownload(ctx context.Context, req *analysis.GetProductAnalysisMultiDimProductListRequest) (resp bool, err error)
	GetProductAnalysisMultiDimDownload(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp bool, err error)
	GetPriceAACoreOverviewDownload(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp bool, err error)
	GetPriceAABizIncomeTargetCardDownload(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp bool, err error)
	GetMultipleRatioTableDownload(ctx context.Context, req *analysis.GetMultipleRatioTableRequest) (resp bool, err error)
	GetOrderResponsibilityCoreOverviewDownload(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp bool, err error)
	GetOrderResponsibilityTargetListDownload(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp bool, err error)
	GetOrderResponsibilityIndustryListDownload(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp bool, err error)
	GetPordDetailListDownload(ctx context.Context, req *analysis.GetPordDetailListRequest) (resp bool, err error)
}

type ExportService struct {
	AnalysisService      analysis_service.IAnalysisService
	PriceAAService       price_aa_service.IPriceAAService
	DimensionListDao     dao.IDimensionListDao
	PriceAnalysisService price_analysis_service.IPriceAnalysisService
	ProdPortraitService  prod_portrait.IProdPortraitService
}
