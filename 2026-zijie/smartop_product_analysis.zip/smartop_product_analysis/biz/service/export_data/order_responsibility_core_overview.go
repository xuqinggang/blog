package export_data

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"context"
	"fmt"
)

func (e *ExportService) GetOrderResponsibilityCoreOverviewDownload(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := e.PriceAnalysisService.GetOrderResponsibilityCoreOverview(ctx, req.BaseReq)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	targets := append(coreRet.ResponsibilityTotalTargets, coreRet.ResponsibilitySameTargets...)
	table,dateList := GetTableAndDateList(targets)

	f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, GenOrderResponsibilityCoreOverviewTable, param.SinkTable("target_data"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())), param.SourceConst(dateList)}, doExportOrderResponsibilityCoreOverview, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func GenOrderResponsibilityCoreOverviewTable(ctx context.Context, table []map[string]interface{}) (*onetable.Table, error) {
	return onetable.NewTable(table), nil
}

func doExportOrderResponsibilityCoreOverview(ctx context.Context, table *onetable.Table, email string, analysisRange string, dateList []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("指标数据", table)
	sheet1.AddHead([][]string{{"分析周期", analysisRange}})

	sheet1.AddColumn("指标", "name")
	for _, d := range dateList {
		sheet1.AddColumn(d, d)
	}
	sheet1.AddColumn("DIFF", "diff").AddColumn("幅度", "diff_ratio")
	formatter.AddSheet(sheet1)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "订单价格力-分工分布-高价率核心指标")
	return nil, formatter.Export(ctx, email, nil, nil)
}
