package export_data

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"context"
	"fmt"
)

func (e *ExportService) GetProductAnalysisCoreOverviewDownload(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangjunrui.1998@bytedance.com"
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	result, err := e.AnalysisService.GetProductAnalysisCoreOverview(ctx, req, false)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	f.ExeQueryCustom([]param.Source{param.SourceConst(result)}, GenTargetCardTable, param.SinkTable("target_data"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.GetStartDate(), req.GetEndDate())),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.GetCompareStartDate(), req.GetCompareEndDate()))}, doExportTargetCard, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func GenTargetCardTable(ctx context.Context, data []*analysis.TargetCategoryList) (*onetable.Table, error) {
	table := make([]map[string]interface{}, 0)
	for _, category := range data {
		for _, cardTarget := range category.TargetList {
			if cardTarget.NeedSecondQuery {
				continue
			}
			var ratio string
			if cardTarget.CycleChangeRatio == consts.MagicNumber {
				ratio = "0%"
			} else {
				ratio = fmt.Sprintf("%.2f%%", cardTarget.CycleChangeRatio*100)
			}
			t := map[string]interface{}{
				"category_name": category.CategoryName,
				"name":          cardTarget.DisplayName,
				"value":         cardTarget.Value,
				"cycle_value":   cardTarget.CycleValue,
				"market_value":  cardTarget.GetExtra().GetMarketValue(),
				"change_ratio":  ratio,
			}
			if cardTarget.GetExtra().GetPercentFlag() == false {
				t["market_percent"] = "-"
				if cardTarget.GetExtra().GetMarketValue() > cardTarget.Value {
					t["market_compare"] = "低于大盘"
				} else if cardTarget.GetExtra().GetMarketValue() == cardTarget.Value {
					t["market_compare"] = "等于大盘"
				} else {
					t["market_compare"] = "高于大盘"
				}
			} else {
				if cardTarget.GetExtra().GetMarketPercent() == consts.MagicNumber {
					t["market_percent"] = "0%"
				} else {
					t["market_percent"] = fmt.Sprintf("%.2f%%", cardTarget.GetExtra().GetMarketPercent()*100)
				}
				t["market_compare"] = "-"
			}
			table = append(table, t)
		}
	}
	return onetable.NewTable(table), nil
}

func doExportTargetCard(ctx context.Context, table *onetable.Table, email string, analysisRange, compareRange string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("指标卡数据", table)
	sheet1.AddHead([][]string{{"分析周期", analysisRange}, {"对比周期", compareRange}})
	sheet1.AddColumn("指标类型", "category_name").
		AddColumn("指标名称", "name").
		AddColumn("分析周期指标值", "value").
		AddColumn("对比周期指标值", "cycle_value").
		AddColumn("占大盘比例", "market_percent").
		AddColumn("大盘指标值", "market_value").
		AddColumn("与大盘比较", "market_compare").
		AddColumn("两期对比变化率", "change_ratio")
	formatter.AddSheet(sheet1)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "核心指标")
	return nil, formatter.Export(ctx, email, nil, nil)
}
