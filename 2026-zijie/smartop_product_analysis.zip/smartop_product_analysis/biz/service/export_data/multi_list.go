package export_data

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"sort"
	"strings"
)

type multiHeaderStruct struct {
	Name    string `json:"name"`
	ColName string `json:"col_name"`
}

// GetProductAnalysisMultiDimDownload 获取维度列表清单
func (d *ExportService) GetProductAnalysisMultiDimDownload(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp bool, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	if len(req.GroupAttrs) == 0 {
		return resp, errors.New("获取多维分析参数失败")
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	// 获取分析的维度信息
	groupCols := make([]string, 0)
	dimColEnumCodeMap := make(map[string]map[string]string)
	for _, attr := range req.GroupAttrs {
		req.Dimensions = append(req.Dimensions, attr.DimInfo)

		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		groupCols = append(groupCols, dimInfo.DimColumn)

		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			enumCodeMap := make(map[string]string)
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
			dimColEnumCodeMap[dimInfo.DimColumn] = enumCodeMap
		}
	}

	curr, compare, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: append(groupCols, base_struct_condition.GenerateDimKey(groupCols, consts.Empty)),
	})
	if err != nil {
		return
	}

	subSelect := make([]string, 0)
	for _, col := range groupCols {
		if dimInfo, exist := dimColMap[col]; exist && len(dimInfo.DimExpr) > 0 {
			subSelect = append(subSelect, fmt.Sprintf("cast(%s as String) as %s", dimInfo.DimExpr, col))
		} else {
			subSelect = append(subSelect, fmt.Sprintf("cast(%s as String) as %s", col, col))
		}
	}

	curr["sub_select"] = strings.Join(subSelect, ",")
	curr["sub_select_join_on"] = base_struct_condition.GenerateDimKeyJoinOn(groupCols)
	curr["sub_group"] = strings.Join(groupCols, ",")
	curr["export_select"] = strings.Join(append(groupCols, base_struct_condition.GenerateDimKey(groupCols, "")), ",")
	curr["dimension_rollup"] = strings.Join(groupCols, ",")
	curr["dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(groupCols, "str_"), ",")

	compare["sub_select"] = strings.Join(subSelect, ",")
	compare["sub_select_join_on"] = base_struct_condition.GenerateDimKeyJoinOn(groupCols)
	compare["sub_group"] = strings.Join(groupCols, ",")
	compare["export_select"] = strings.Join(append(groupCols, base_struct_condition.GenerateDimKey(groupCols, "")), ",")
	compare["dimension_rollup"] = strings.Join(groupCols, ",")
	compare["dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(groupCols, "str_"), ",")

	apiPath := bizMetaInfo.MultiDimApiID
	targetMetaMap, err := base_struct_condition.GetFilterTargetMetaInfoMap(ctx, int64(req.BizType), false, true, req.TargetMetaList)
	if err != nil {
		return
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(req.BizType), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryCustom([]param.Source{param.SourceConst(req.GroupAttrs), param.SourceConst(dimMap)}, getDocHeader, param.SinkTable("doc_header"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("curr_data"))
	f.ExeQueryInvokerRaw(compare, apiPath, param.SinkTable("compare_data"))
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return resp, err
	}

	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}
	f.ExeQueryCustom([]param.Source{param.SourceConst(dimColEnumCodeMap), param.SourceConst(groupCols), param.SourceTable("curr_data")}, GetMultiDimDownloadData, param.SinkTable("curr_export_data"))
	f.ExeQueryCustom([]param.Source{param.SourceConst(dimColEnumCodeMap), param.SourceConst(groupCols), param.SourceTable("compare_data")}, GetMultiDimDownloadData, param.SinkTable("compare_export_data"))
	f.ExeCustom([]param.Source{param.SourceTable("curr_export_data"), param.SourceTable("compare_export_data"), param.SourceConst(email), param.SourceTable("doc_header"), param.SourceConst(targetMetaMap), param.SourceConst(groupCols)}, doMultiDimDownloadExport, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return resp, err
	}
	return true, nil
}

func doMultiDimDownloadExport(ctx context.Context, table1, table2 *onetable.Table, email string, docHeader *onetable.Table, targetMetaMap map[string]*dao.TargetMetaInfo, groupCols []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	if docHeader == nil || len(docHeader.ToRawMap()) == 0 || table1 == nil || len(table1.ToRawMap()) == 0 {
		sheet1 := lark_export.NewLarkDocSheet("当前周期", table1)
		sheet1.AddHead([][]string{{"暂无数据"}})
		return nil, formatter.Export(ctx, email, nil, nil)
	}

	tableMap := table1.ToRawMap()
	targetRawMap := make([]map[string]interface{}, 0)
	for col, _ := range tableMap[0] {
		if !slices.ContainsString(groupCols, col) {
			metaInfo, exist := targetMetaMap[col]
			if exist {
				targetRawMap = append(targetRawMap, map[string]interface{}{
					"display_order": metaInfo.DisplayOrder,
					"name":          metaInfo.DisplayName,
					"col_name":      metaInfo.Name,
				})
			}
		}
	}

	sort.Slice(targetRawMap, func(i, j int) bool {
		valueI := convert.ToInt64(targetRawMap[i]["display_order"])
		valueJ := convert.ToInt64(targetRawMap[j]["display_order"])
		return valueI < valueJ
	})

	sheet1 := lark_export.NewLarkDocSheet("当前周期", table1)
	sheet2 := lark_export.NewLarkDocSheet("对比周期", table2)
	for _, h := range docHeader.ToRawMap() {
		sheet1.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
		sheet2.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
	}
	for _, h := range targetRawMap {
		sheet1.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
		sheet2.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
	}
	formatter.AddSheet(sheet1, sheet2)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "多维分析列表")
	return nil, formatter.Export(ctx, email, nil, nil)
}

func GetMultiDimDownloadData(ctx context.Context, dimColEnumCodeMap map[string]map[string]string, groupCols []string, table *onetable.Table) (*onetable.Table, error) {
	if len(table.ToRawMap()) > 10000 {
		return nil, errors.New("MAX_10000_LIMIT_ERROR")
	}
	outMap := make(map[string]map[string]interface{}, 0)
	dimKeyList := make([]string, 0)
	for _, infoMap := range table.ToRawMap() {
		dimKey := convert.ToString(infoMap["dim_key"])
		dimKeyList = append(dimKeyList, dimKey)
		outV, exist := outMap[dimKey]
		if !exist {
			outV = make(map[string]interface{})
		}

		for i, c := range groupCols {
			if len(strings.ReplaceAll(dimKey, "#", "")) == 0 {
				outV[c] = utils.If(i == 0, "整体", "-")
			} else {
				enumCode := convert.ToString(infoMap[c])
				enumMap, existEnumMap := dimColEnumCodeMap[c]
				if !existEnumMap {
					outV[c] = "-"
				} else if enumValue, existEnumV := enumMap[enumCode]; existEnumV {
					outV[c] = enumValue
				} else {
					outV[c] = "-"
				}
			}
		}

		for col, value := range infoMap {
			if !slices.ContainsString(groupCols, col) && col != "dim_key" {
				outV[convert.ToString(col)] = value
			}
		}
		outMap[dimKey] = outV
	}

	dimKeyList = slices.DistinctString(dimKeyList)
	sort.Strings(dimKeyList)
	out := make([]map[string]interface{}, 0)
	for _, dimKey := range dimKeyList {
		out = append(out, outMap[dimKey])
	}
	return onetable.NewTable(out), nil
}

func getDocHeader(ctx context.Context, groupAttrs []*dimensions.SelectedMultiDimensionInfo, dimMap map[int64]*dao.DimensionInfo) ([]*multiHeaderStruct, error) {
	docHeader := make([]*multiHeaderStruct, 0) // 文档表头
	for _, attr := range groupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return docHeader, errors.New("未查询到维度信息")
		}
		docHeader = append(docHeader, &multiHeaderStruct{
			Name:    dimInfo.ShowName,
			ColName: dimInfo.DimColumn,
		})
	}

	return docHeader, nil
}
