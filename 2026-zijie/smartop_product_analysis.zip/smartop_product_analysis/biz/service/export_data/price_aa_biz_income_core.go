package export_data

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"context"
	"fmt"
)

func (e *ExportService) GetPriceAABizIncomeTargetCardDownload(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := e.PriceAAService.GetPriceAACoreOverview(ctx, req.BaseReq, req.Channel)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	beforePriceTagName, afterPriceTagName, err := biz_info.GetCtxBizInfoPriceAAChangeSourceName(ctx)
	if err != nil {
		return false, err
	}
	for _, card := range coreRet {
		card.DisplayName = fmt.Sprintf("%s时-%s", afterPriceTagName, card.DisplayName)
	}
	f.ExeQueryCustom([]param.Source{param.SourceConst(coreRet), param.SourceConst(beforePriceTagName)}, GenPriceAABizIncomeCoreTable, param.SinkTable("target_data"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())), param.SourceConst(beforePriceTagName)}, doExportPriceAABizIncomeCoreCard, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func GenPriceAABizIncomeCoreTable(ctx context.Context, coreRet []*analysis.TargetCardEntity, beforePriceTagName string) (*onetable.Table, error) {
	table := make([]map[string]interface{}, 0)
	for _, cardTarget := range coreRet {
		beforeValue := "-"
		if len(cardTarget.SubTargetList) > 0 {
			for _, sub := range cardTarget.SubTargetList {
				if sub.DisplayName == beforePriceTagName+"时" {
					beforeValue = fmt.Sprintf("%.4f", sub.Value)
				}
			}
		}

		diff, ratio := GetDiffStr(cardTarget.DiffExtra)
		t := map[string]interface{}{
			"name":         cardTarget.DisplayName,
			"value":        cardTarget.Value,
			"before_value": beforeValue,
			"diff":         diff,
			"diff_ratio":   ratio,
		}
		table = append(table, t)
	}
	return onetable.NewTable(table), nil
}

func doExportPriceAABizIncomeCoreCard(ctx context.Context, table *onetable.Table, email string, analysisRange, beforePriceTagName string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("指标卡数据", table)
	sheet1.AddHead([][]string{{"分析周期", analysisRange}})
	sheet1.AddColumn("指标名称", "name").
		AddColumn("指标值", "value").
		AddColumn(fmt.Sprintf("%s时指标值", beforePriceTagName), "before_value").
		AddColumn("DIFF", "diff").
		AddColumn("幅度", "diff_ratio")
	formatter.AddSheet(sheet1)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "AA分析-改价后核心指标")
	return nil, formatter.Export(ctx, email, nil, nil)
}
