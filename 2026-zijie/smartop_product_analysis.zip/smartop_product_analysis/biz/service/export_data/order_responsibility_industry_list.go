package export_data

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"context"
	"fmt"
	"strings"
)

func (e *ExportService) GetOrderResponsibilityIndustryListDownload(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	industryRet, err := e.PriceAnalysisService.GetOrderResponsibilityIndustryList(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	f.ExeQueryCustom([]param.Source{param.SourceConst(industryRet)}, GenOrderResponsibilityIndustryListTable, param.SinkTable("target_data"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())), param.SourceConst(industryRet.Total)}, doExportOrderResponsibilityIndustryList, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func GenOrderResponsibilityIndustryListTable(ctx context.Context, industryRet *analysis.GetOrderResponsibilityIndustryListData) (*onetable.Table, error) {
	table := make([]map[string]interface{}, 0)
	if industryRet != nil {
		totalRecord := make(map[string]interface{})
		totalRecord["first_vbline_name"] = "整体"
		totalRecord["second_vbline_name"] = "-"
		for _, t := range industryRet.Total {
			totalRecord[t.Name] = t.Value
		}
		table = append(table, totalRecord)

		for _, industryInfo := range industryRet.IndustryList {
			record := make(map[string]interface{})
			record["first_vbline_name"] = industryInfo.Name
			record["second_vbline_name"] = "-"
			for _, t := range industryInfo.Targets {
				record[t.Name] = t.Value
			}
			table = append(table, record)
			if len(industryInfo.Children) > 0 {
				for _, subInfo := range industryInfo.Children {
					subRecord := make(map[string]interface{})
					subRecord["first_vbline_name"] = industryInfo.Name
					subRecord["second_vbline_name"] = subInfo.Name
					for _, t := range subInfo.Targets {
						subRecord[t.Name] = t.Value
					}
					table = append(table, subRecord)
				}
			}
		}
	}

	return onetable.NewTable(table), nil
}

func doExportOrderResponsibilityIndustryList(ctx context.Context, table *onetable.Table, email string, analysisRange string, targets []*analysis.TargetCardEntity) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("指标数据", table)
	sheet1.AddHead([][]string{{"分析周期", analysisRange}})

	sheet1.AddColumn("一级行业", "first_vbline_name").
		AddColumn("二级行业", "second_vbline_name")
	for _, t := range targets {
		if strings.Contains(t.Name + "_", price_analysis_service.SupplyHpricePercentPrefix) {
			sheet1.AddColumn(t.DisplayName + "(占比)", t.Name)
		} else {
			sheet1.AddColumn(t.DisplayName, t.Name)
		}
	}
	formatter.AddSheet(sheet1)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "订单价格力-供给分工-行业分析")
	return nil, formatter.Export(ctx, email, nil, nil)
}
