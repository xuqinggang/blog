package export_data

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"context"
	"fmt"
)

func (e *ExportService) GetMultipleRatioTableDownload(ctx context.Context, req *analysis.GetMultipleRatioTableRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangjunrui.1998@bytedance.com"
	}
	multipleRatioTableData, err := e.PriceAnalysisService.GetMultipleRatioTable(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	var targetName string
	if len(multipleRatioTableData) > 0 && len(multipleRatioTableData[0].Item) > 0 && multipleRatioTableData[0].Item[0].TargetInfo != nil {
		targetName = multipleRatioTableData[0].Item[0].TargetInfo.DisplayName
	}
	var maxPointNum int
	var dateList []string
	for _, subTable := range multipleRatioTableData {
		for _, row := range subTable.Item {
			if len(row.MultipleRatioTrend) > maxPointNum {
				maxPointNum = len(row.MultipleRatioTrend)
				dateList = make([]string, 0)
				for _, point := range row.MultipleRatioTrend {
					dateList = append(dateList, point.X)
				}
			}
		}
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeCustom([]param.Source{param.SourceConst(multipleRatioTableData)}, GetMultipleTable, []param.Sink{param.SinkDoc("table_map")})
	f.ExeCustom([]param.Source{param.SourceDoc("table_map"), param.SourceConst(maxPointNum), param.SourceConst(dateList), param.SourceConst(email), param.SourceConst(targetName),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.GetBaseReq().GetStartDate(), req.GetBaseReq().GetEndDate()))}, doExportMultipleTable, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func GetMultipleTable(ctx context.Context, data []*analysis.MultipleRatioTableItem) (map[string]*onetable.Table, error) {
	resMap := make(map[string]*onetable.Table)
	for _, subTable := range data {
		table := make([]map[string]interface{}, 0)
		for _, row := range subTable.Item {
			t := map[string]interface{}{
				"row_name": row.RowName,
			}
			for i, point := range row.MultipleRatioTrend {
				t[fmt.Sprintf("multiple_rtatio_%d", i)] = point.Value
				t[fmt.Sprintf("target_value_%d", i)] = point.DimName
				t[fmt.Sprintf("overall_value_%d", i)] = point.DimDisplayName
			}
			table = append(table, t)
		}
		resMap[subTable.TableName] = onetable.NewTable(table)
	}
	return resMap, nil
}

func doExportMultipleTable(ctx context.Context, tables map[string]*onetable.Table, pointNum int, dateList []string, email, targetName, analysisRange string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	for tableName, table := range tables {
		sheet := lark_export.NewLarkDocSheet(tableName, table)
		sheet.AddHead([][]string{{"分析周期", analysisRange}, {"（数据导出暂不支持合并单元格，如有需要，请手动调整）"}})
		sheet.AddColumnMultiHead([]string{"", ""}, "row_name")
		for i := 0; i < pointNum && i < len(dateList); i++ {
			sheet.AddColumnMultiHead([]string{targetName, dateList[i]}, fmt.Sprintf("target_value_%d", i)).
				AddColumnMultiHead([]string{"大盘" + targetName, ""}, fmt.Sprintf("overall_value_%d", i)).
				AddColumnMultiHead([]string{"倍比", ""}, fmt.Sprintf("multiple_rtatio_%d", i))
		}
		formatter.AddSheet(sheet)
	}
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "商品价格力流量洞察-"+targetName+"-倍比数据")
	return nil, formatter.Export(ctx, email, nil, nil)
}
