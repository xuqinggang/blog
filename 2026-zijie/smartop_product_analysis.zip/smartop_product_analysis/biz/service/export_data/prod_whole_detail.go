package export_data

import (
	"context"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/great_value_buy_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
)

const apiPathProdDetail = "7399935196486829066"

func (e *ExportService) GetPordDetailListDownload(ctx context.Context, req *analysis.GetPordDetailListRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangjunrui.1998@bytedance.com"
	}
	var prodSubSql string
	var appendParams map[string]interface{}
	var bizType dimensions.BizType
	var osReq base_struct_condition.OsParamsReq
	// 直接查商品明细，不是从特定位置跳转的情况
	if req != nil && req.BaseReq != nil && req.BaseReq.IsNative != nil && *req.BaseReq.IsNative {
		baseReq := &dimensions.ProductAnalysisBaseStruct{}
		paramReq := &analysis.GetProductAnalysisBaseRequest{}
		err = sonic.UnmarshalString(req.BaseReq.ReqMarshal, &paramReq)
		if err != nil {
			logs.CtxWarn(ctx, "指标入参反序列化失败，err:"+err.Error())
		}
		// 再尝试用baseStruct结构做反序列化
		if err != nil || paramReq.BaseReq == nil {
			err = sonic.UnmarshalString(req.BaseReq.ReqMarshal, &baseReq)
			if err != nil {
				logs.CtxError(ctx, "指标入参反序列化失败，err:"+err.Error())
				return false, err
			}
		} else {
			baseReq = paramReq.BaseReq
		}
		logs.CtxInfo(ctx, "baseReq = %v", convert.ToJSONString(baseReq))
		bizType = baseReq.BizType
		dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "[GetProdPortrait]获取map失败，err=%v+", err)
			return false, err
		}
		// 如果没传order by 参数，默认根据show_pv排序
		if req.OrderBy == nil {
			var orderField = base.OrderByField_ShowPv
			req.OrderBy = &base.OrderByInfo{
				Field:  &orderField,
				IsDesc: true,
			}
		}
		osReq = base_struct_condition.OsParamsReq{
			BaseStruct: baseReq,
			DimMap:     dimMap,
			PageInfo:   req.PageReq,
			OrderBy:    req.OrderBy,
		}
	} else { // 特定位置跳转的商品明细
		analysisRes, err := prod_portrait.AnalysisModule(ctx, req.BaseReq)
		if err != nil {
			logs.CtxError(ctx, "解析商品画像参数失败，err:"+err.Error())
			return false, err
		}
		bizType = analysisRes.BizType
		prodSubSql = analysisRes.ProdSubSql
		appendParams = analysisRes.AppendParams
		// 获取跳转位置的与MVP版重叠人、场属性，拼接到筛选项中
		dimFilters, err := prod_portrait.MergeDimensions(ctx, req.BaseReq.Dimensions, analysisRes, bizType)
		if err != nil {
			return false, err
		}

		dimMap, err := e.DimensionListDao.GetAllDimensionMap(ctx)
		//dimMap, err := prod_portrait.GetProdDetailDimMap(ctx, dimFilters, bizType)
		if err != nil {
			logs.CtxError(ctx, "[GetProdPortrait]获取map失败，err=%v+", err)
			return false, err
		}
		// 如果没传order by 参数，默认根据show_pv排序
		if req.OrderBy == nil {
			var orderField = base.OrderByField_ShowPv
			req.OrderBy = &base.OrderByInfo{
				Field:  &orderField,
				IsDesc: true,
			}
		}
		osReq = base_struct_condition.OsParamsReq{
			BaseStruct: &dimensions.ProductAnalysisBaseStruct{
				BizType:        bizType,
				StartDate:      req.BaseReq.StartDate,
				EndDate:        req.BaseReq.EndDate,
				Dimensions:     dimFilters,
				ThresholdAttrs: analysisRes.TopNFilter,
			},
			DimMap:   dimMap,
			PageInfo: req.PageReq,
			OrderBy:  req.OrderBy,
		}
	}
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成oneService api 入参失败,err:"+err.Error())
		return false, err
	}
	if len(prodSubSql) > 0 {
		curr["prod_sub_sql"] = prodSubSql
	}
	if len(appendParams) > 0 {
		for k, v := range appendParams {
			curr[k] = v
		}
	}
	var extrapParams = make(map[string]string)
	if req.BaseReq.SubScenarioInfo != nil && *req.BaseReq.SubScenarioInfo == analysis.SubScenarioType_Search {
		extrapParams["origin"] = "search"
	}
	if req.BaseReq.SubScenarioInfo != nil && (*req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForKeyInSupply || *req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForSuggestInSupply) {
		extrapParams["origin"] = "search_in_supply"
		if *req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForKeyInSupply { // 重点引入供给品
			curr["key_prod"] = 1
		}
	}

	prodPortraitApiPathData := prod_portrait.GetProdPortraitApiPath(ctx, bizType, extrapParams)

	// 没有传递分页参数时，代表全量下载
	if req.PageReq == nil || req.PageReq.PageSize == 0 || req.PageReq.PageNum == 0 {
		// 下载接口的limit 飞书表格导出数据行数和单元格有上限，暂时写死
		curr["limit"] = 10000
		curr["offset"] = 0
	}
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return false, err
	}
	// 文档名前缀
	if bizInfo.ProdDetailExportType == 1 {
		ctx = context.WithValue(ctx, consts.CtxExportModuleName, "商品明细列表")
	} else {
		ctx = context.WithValue(ctx, consts.CtxExportModuleName, "商品ID清单")
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(curr, prodPortraitApiPathData.ProdDetailPath, param.SinkTable("product_detail")).SetParallel(true).SetMaxParallelNum(5)
	if bizType == dimensions.BizType_GreatValueBuy {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportProductDetailTableChaoZhiGou, nil)
	} else if bizType == dimensions.BizType_ProdSeckill {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportProductDetailTableSeckill, nil)
	} else if bizType == dimensions.BizType_MorningMarketProduct {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportProductDetailTableMorningMarket, nil)
	} else if bizType == dimensions.BizType_GuessBoostData {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportGuessBoost, nil)
	} else if bizType == dimensions.BizType_GreatValueBuyBigLink {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportGreatValueBuyBigLink, nil)
	} else if bizInfo.ProdDetailExportType == 1 {
		targetMetaMap, err := dao.GetTargetMetaInfoMap(ctx, int64(bizType), false, []string{})
		if err != nil {
			logs.CtxError(ctx, err.Error())
			return false, err
		}
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email), param.SourceConst(targetMetaMap)}, doExportProdDetailCommon, nil)
	} else {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportProductDetailTable, nil)
	}
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func doExportProdDetailCommon(ctx context.Context, table *onetable.Table, email string, targetMetaMap map[string]*dao.TargetMetaInfo) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("商品信息", table)
	tableMap := table.ToRawMap()
	targetRawMap := make([]map[string]interface{}, 0)
	for col, _ := range tableMap[0] {
		metaInfo, exist := targetMetaMap[col]
		if exist {
			targetRawMap = append(targetRawMap, map[string]interface{}{
				"display_order": metaInfo.DisplayOrder,
				"name":          metaInfo.DisplayName,
				"col_name":      metaInfo.Name,
			})
		}
	}
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("商品ID", "prod_id").
		AddColumn("商品名称", "prod_name")

	for _, h := range targetRawMap {
		sheet1.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
	}

	sheet1.AddColumn("垂类", "industry_name").
		AddColumn("一级类目", "first_level_cate_name").
		AddColumn("二级类目", "second_level_cate_name").
		AddColumn("叶子类目", "leaf_cate_name").
		AddColumn("所属商家", "shop_name").
		AddColumn("商家ID", "shop_id").
		AddColumn("所属品牌", "brand_name").
		AddColumn("品牌等级", "complex_brand_s_level")

	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}
