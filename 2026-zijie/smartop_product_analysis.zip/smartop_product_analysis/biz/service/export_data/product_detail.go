package export_data

import (
	"context"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
)

const apiPathProductDetail = "7371004413084795954"

func (e *ExportService) GetProductAnalysisMultiDimProductListDownload(ctx context.Context, req *analysis.GetProductAnalysisMultiDimProductListRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangjunrui.1998@bytedance.com"
	}
	// 文档名前缀
	if req.GetBaseReq().GetBizType() == dimensions.BizType_GreatValueBuy {
		ctx = context.WithValue(ctx, consts.CtxExportModuleName, "商品明细列表")
	} else {
		ctx = context.WithValue(ctx, consts.CtxExportModuleName, "商品ID清单")
	}
	// 获取业务线的维度信息
	dimensionDao := new(dao.DimensionListDao)
	dimMap, err := dimensionDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取map失败，err=%v+", err)
		return false, err
	}
	dimColMap, err := dimensionDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取col map失败，err=%v+", err)
		return resp, err
	}
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
				if dimInfo == nil {
					logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
					return false, errors.New("未查询到维度信息")
				}
				groupCol = dimInfo.DimColumn
			}
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
	}
	// 如果没传order by 参数，默认根据show_pv排序
	if req.OrderBy == nil {
		var orderField = base.OrderByField_ShowPv
		req.OrderBy = &base.OrderByInfo{
			Field:  &orderField,
			IsDesc: true,
		}
	}
	// 获取invoker的入参
	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
		OrderBy:        req.OrderBy,
	})
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	// 没有传递分页参数时，代表全量下载
	if req.PageReq == nil {
		// 下载接口的limit 飞书表格导出数据行数和单元格有上限，暂时写死
		curr["limit"] = 10000
		curr["offset"] = 0
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(curr, apiPathProductDetail, param.SinkTable("product_detail"))
	if req.GetBaseReq().GetBizType() == dimensions.BizType_GreatValueBuy {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportProductDetailTableChaoZhiGou, nil)
	} else if req.GetBaseReq().GetBizType() == dimensions.BizType_ProdSeckill {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportProductDetailTableSeckill, nil)
	} else {
		f.ExeCustom([]param.Source{param.SourceTable("product_detail"), param.SourceConst(email)}, doExportProductDetailTable, nil)
	}
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

// 考虑到商品信息的机密性，这里只支持导出商品ID
func doExportProductDetailTable(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("商品信息", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("商品ID", "prod_id")
	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}

// 秒杀商品明细导出
func doExportProductDetailTableSeckill(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("商品信息", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("商品ID", "prod_id").
		AddColumn("商品名称", "prod_name").
		AddColumn("支付订单数", "pay_ord_cnt").
		AddColumn("支付GMV", "pay_gmv").
		AddColumn("单均价", "avg_order_gmv").
		AddColumn("OPM", "opm").
		AddColumn("GPM", "gpm").
		AddColumn("曝光PV", "show_pv").
		AddColumn("点击PV", "click_pv").
		AddColumn("CTR", "ctr").
		AddColumn("CVR", "cvr").
		AddColumn("垂类", "industry_name").
		AddColumn("一级类目", "first_level_cate_name").
		AddColumn("二级类目", "second_level_cate_name").
		AddColumn("叶子类目", "leaf_cate_name").
		AddColumn("所属商家", "shop_name").
		AddColumn("所属品牌", "brand_name").
		AddColumn("品牌等级", "complex_brand_s_level")

	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}

// 早晚市商品明细导出
func doExportProductDetailTableMorningMarket(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("商品信息", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("商品ID", "prod_id").
		AddColumn("商品名称", "prod_name").
		AddColumn("商品曝光PV", "show_pv").
		AddColumn("支付订单数", "pay_ord_cnt").
		AddColumn("支付GMV", "pay_ord_amt").
		AddColumn("支付UV", "pay_uv").
		AddColumn("单均价", "avg_order_gmv").
		AddColumn("客单价", "user_unit_price").
		AddColumn("OPM", "opm").
		AddColumn("GPM", "gpm").
		AddColumn("对应叶子类目opm", "leaf_cate_opm").
		AddColumn("对应二级类目opm", "second_level_cate_opm").
		AddColumn("垂类", "industry_name").
		AddColumn("一级类目", "first_level_cate_name").
		AddColumn("二级类目", "second_level_cate_name").
		AddColumn("叶子类目", "leaf_cate_name").
		AddColumn("所属商家", "shop_name").
		AddColumn("所属品牌", "brand_name").
		AddColumn("品牌等级", "complex_brand_s_level")

	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}

// 猜喜扶持洞察导出
func doExportGuessBoost(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("商品信息", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("商品ID", "prod_id").
		AddColumn("商品名称", "prod_name").
		AddColumn("曝光AB增幅", "ab_pv_rate").
		AddColumn("GMVAB增幅", "ab_gmv_rate").
		AddColumn("订单AB增幅", "ab_order_rate").
		AddColumn("GPMAB增幅", "ab_gpm_rate").
		AddColumn("OPMAB增幅", "ab_opm_rate").
		AddColumn("实验组总曝光", "exp_pv_sum").
		AddColumn("实验组总订单", "exp_order_sum").
		AddColumn("实验组总GMV", "exp_gmv_sum").
		AddColumn("对照组总曝光", "base_pv_sum").
		AddColumn("对照组总订单", "base_order_sum").
		AddColumn("对照组总GMV", "base_gmv_sum").
		// 日均
		AddColumn("扶持品日均PV", "pv_avg").
		AddColumn("扶持品日均GMV", "gmv_avg").
		AddColumn("扶持品日均订单", "order_avg").
		AddColumn("扶持品GPM", "gpm_avg").
		AddColumn("扶持品OPM", "opm_avg").
		// ids
		AddColumn("计划IDS", "plan_ids").
		AddColumn("信号IDS", "signal_ids")
	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}

// 超值购商品明细导出
func doExportProductDetailTableChaoZhiGou(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("商品信息", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("商品ID", "prod_id").
		AddColumn("商品名称", "prod_name").
		AddColumn("近30天商品可售天数", "last_30_day_sale_days").
		AddColumn("最新曝光时间", "last_pv_date").
		AddColumn("支付订单数", "pay_ord_cnt").
		AddColumn("支付GMV", "pay_gmv").
		AddColumn("单均价", "avg_order_gmv").
		AddColumn("OPM", "opm").
		AddColumn("GPM", "gpm").
		AddColumn("曝光PV", "show_pv").
		AddColumn("点击PV", "click_pv").
		AddColumn("CTR", "ctr").
		AddColumn("CVR", "cvr").
		AddColumn("垂类", "industry_name").
		AddColumn("一级类目", "first_level_cate_name").
		AddColumn("二级类目", "second_level_cate_name").
		AddColumn("叶子类目", "leaf_cate_name").
		AddColumn("所属商家", "shop_name").
		AddColumn("所属品牌", "brand_name").
		AddColumn("品牌等级", "complex_brand_s_level")

	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}

// 超值购聚合链接
func doExportGreatValueBuyBigLink(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("聚合链接信息", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("聚合链接ID", "sku_id").
		AddColumn("聚合链接名称", "sku_name").
		AddColumn("同款簇ID", "sku_cluster_id").
		AddColumn("同款簇名称", "sku_cluster_name").
		AddColumn("商品ID", "prod_id").
		AddColumn("商品名称", "prod_name")
	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}
