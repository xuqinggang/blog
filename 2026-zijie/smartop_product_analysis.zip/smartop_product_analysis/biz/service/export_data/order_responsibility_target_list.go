package export_data

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs/v2"
	"context"
	"fmt"
	"sort"
)

func (e *ExportService) GetOrderResponsibilityTargetListDownload(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := e.PriceAnalysisService.GetOrderResponsibilityTargetList(ctx, req, false)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	table1, dateList1 := GetTableAndDateList(coreRet.ResponsibilityTotalTargets)
	table2, dateList2 := GetTableAndDateList(coreRet.ResponsibilitySameTargets)
	dateList := slices.DistinctString(append(dateList1, dateList2...))
	sort.Strings(dateList)

	f.ExeQueryCustom([]param.Source{param.SourceConst(table1)}, GenOrderResponsibilityCoreOverviewTable, param.SinkTable("target_data_total"))
	f.ExeQueryCustom([]param.Source{param.SourceConst(table2)}, GenOrderResponsibilityCoreOverviewTable, param.SinkTable("target_data_same"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data_total"), param.SourceTable("target_data_same"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())), param.SourceConst(dateList), param.SourceConst(price_analysis_service.GetResponsibilityAllColumn(req.ResponsibilityAll))}, doExportOrderResponsibilityTargetList, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func GetTableAndDateList(targets []*analysis.TargetCardEntity) ([]map[string]interface{}, []string) {
	table := make([]map[string]interface{}, 0)
	dateList := make([]string, 0)
	if len(targets) > 0 {
		for _, target := range targets {
			record := make(map[string]interface{})
			record["first_name"] = target.DisplayName
			if len(target.TrendData) > 0 {
				for _, trend := range target.TrendData {
					record[trend.X] = trend.Value
					dateList = append(dateList, trend.X)
				}
			}

			record["second_name"] = "-"
			record["diff"], record["diff_ratio"] = GetDiffStr(target.DiffExtra)
			table = append(table, record)

			if target.GroupInfo != nil && len(target.GroupInfo.GroupList) > 0 {
				for _, subTarget := range target.GroupInfo.GroupList {
					subRecord := make(map[string]interface{})
					subRecord["first_name"] = target.DisplayName
					subRecord["second_name"] = subTarget.DisplayName
					if len(subTarget.TrendData) > 0 {
						for _, trend := range subTarget.TrendData {
							subRecord[trend.X] = trend.Value
							dateList = append(dateList, trend.X)
						}
					}

					subRecord["diff"], subRecord["diff_ratio"] = GetDiffStr(target.DiffExtra)
					table = append(table, subRecord)
				}
			}
		}
	}
	dateList = slices.DistinctString(dateList)
	sort.Strings(dateList)
	return table, dateList
}

func GetDiffStr(info *analysis.DiffExtraInfo) (diff, ratio string) {
	diff = "-"
	ratio = "-"
	if info != nil {
		diff = fmt.Sprintf("%.4f", info.Diff)
		if info.DiffRatio == consts.MagicNumber {
			ratio = "0%"
		} else {
			ratio = fmt.Sprintf("%.2f%%", info.DiffRatio*100)
		}
	}
	return diff, ratio
}

func doExportOrderResponsibilityTargetList(ctx context.Context, table1, table2 *onetable.Table, email string, analysisRange string, dateList []string, responsibilityType string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("标准订单高价率口径", table1)
	sheet2 := lark_export.NewLarkDocSheet("只看有同款订单高价率口径", table2)
	sheet1.AddHead([][]string{{"分析周期", analysisRange}})
	sheet2.AddHead([][]string{{"分析周期", analysisRange}})

	sheet1.AddColumn("一级分工", "first_name")
	sheet1.AddColumn("二级分工", "second_name")
	sheet2.AddColumn("一级分工", "first_name")
	sheet2.AddColumn("二级分工", "second_name")
	for _, d := range dateList {
		sheet1.AddColumn(d, d)
		sheet2.AddColumn(d, d)
	}
	sheet1.AddColumn("DIFF", "diff").AddColumn("幅度", "diff_ratio")
	sheet2.AddColumn("DIFF", "diff").AddColumn("幅度", "diff_ratio")
	formatter.AddSheet(sheet1)
	formatter.AddSheet(sheet2)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, fmt.Sprintf("%s高价率下拆", responsibilityType))
	return nil, formatter.Export(ctx, email, nil, nil)
}
