package prod_portrait

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/great_value_buy_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/jsonx"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
	"github.com/sanity-io/litter"
)

func (p *ProdPortraitService) GetPordDetailList(ctx context.Context, req *analysis.GetPordDetailListRequest) (resp *analysis.GetProductAnalysisMultiDimProductListData, err error) {
	var prodSubSql string
	var appendParams map[string]interface{}
	var bizType dimensions.BizType
	var bizInfo *biz_utils.BizMetaInfo
	var osReq base_struct_condition.OsParamsReq
	// 直接查商品明细，不是从特定位置跳转的情况
	if req != nil && req.BaseReq != nil && req.BaseReq.IsNative != nil && *req.BaseReq.IsNative {
		baseReq := &dimensions.ProductAnalysisBaseStruct{}
		paramReq := &analysis.GetProductAnalysisBaseRequest{}
		err = sonic.UnmarshalString(req.BaseReq.ReqMarshal, &paramReq)
		if err != nil {
			logs.CtxWarn(ctx, "指标入参反序列化失败，err:"+err.Error())
		}
		// 再尝试用baseStruct结构做反序列化
		if err != nil || paramReq.BaseReq == nil {
			err = sonic.UnmarshalString(req.BaseReq.ReqMarshal, &baseReq)
			if err != nil {
				logs.CtxError(ctx, "指标入参反序列化失败，err:"+err.Error())
				return nil, err
			}
		} else {
			baseReq = paramReq.BaseReq
		}
		logs.CtxInfo(ctx, "baseReq = %v", convert.ToJSONString(baseReq))

		// 获取业务线信息
		bizInfo, ctx, err = biz_utils.GetBizMetaInfo(ctx, baseReq.BizType)
		if err != nil || bizInfo == nil {
			logs.CtxWarn(ctx, "[GetPordDetailList]业务线未发现元信息, req = %s", convert.ToJSONString(req))
			return nil, err
		}
		baseReq.BizType = biz_utils.GetAnalysisBizType(baseReq.BizType, bizInfo.DependBizID)
		bizType = baseReq.BizType
		dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "[GetProdPortrait]获取map失败，err=%v+", err)
			return nil, err
		}
		// 如果没传order by 参数，默认根据show_pv排序
		if req.OrderBy == nil {
			var orderField = base.OrderByField_ShowPv
			req.OrderBy = &base.OrderByInfo{
				Field:  &orderField,
				IsDesc: true,
			}
		}
		osReq = base_struct_condition.OsParamsReq{
			BaseStruct: baseReq,
			DimMap:     dimMap,
			PageInfo:   req.PageReq,
			OrderBy:    req.OrderBy,
		}
	} else { // 特定位置跳转的商品明细
		analysisRes, err := AnalysisModule(ctx, req.BaseReq)
		if err != nil {
			logs.CtxError(ctx, "解析商品画像参数失败，err:"+err.Error())
			return nil, err
		}
		// 获取业务线信息
		bizInfo, ctx, err = biz_utils.GetBizMetaInfo(ctx, analysisRes.BizType)
		if err != nil || bizInfo == nil {
			logs.CtxWarn(ctx, "[GetPordDetailList]业务线未发现元信息, req = %s", convert.ToJSONString(req))
			return nil, err
		}
		bizType = biz_utils.GetAnalysisBizType(analysisRes.BizType, bizInfo.DependBizID) // 如果有依赖的业务线，替换掉原业务线 PS: A1大服饰依赖的是大盘
		prodSubSql = analysisRes.ProdSubSql
		appendParams = analysisRes.AppendParams
		// 获取跳转位置的与MVP版重叠人、场属性，拼接到筛选项中
		dimFilters, err := MergeDimensions(ctx, req.BaseReq.Dimensions, analysisRes, bizType)
		if err != nil {
			return nil, err
		}

		dimMap, err := p.DimensionListDao.GetAllDimensionMap(ctx)
		//dimMap, err := GetProdDetailDimMap(ctx, dimFilters, bizType)
		if err != nil {
			logs.CtxError(ctx, "[GetPordDetailList]获取map失败，err=%v+", err)
			return nil, err
		}
		// 如果没传order by 参数，默认根据show_pv排序
		if req.OrderBy == nil {
			var orderField = base.OrderByField_ShowPv
			req.OrderBy = &base.OrderByInfo{
				Field:  &orderField,
				IsDesc: true,
			}
			if analysisRes.BizType == dimensions.BizType_MarketingEngine {
				orderField = base.OrderByField_GMV
				req.OrderBy.Field = &orderField
			}
		}
		osReq = base_struct_condition.OsParamsReq{
			BaseStruct: &dimensions.ProductAnalysisBaseStruct{
				BizType:        bizType,
				StartDate:      req.BaseReq.StartDate,
				EndDate:        req.BaseReq.EndDate,
				Dimensions:     dimFilters,
				ThresholdAttrs: analysisRes.TopNFilter,
			},
			DimMap:   dimMap,
			PageInfo: req.PageReq,
			OrderBy:  req.OrderBy,
		}
	}
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成oneService api 入参失败,err:"+err.Error())
		return nil, err
	}
	if len(prodSubSql) > 0 {
		curr["prod_sub_sql"] = prodSubSql
	}

	if bizInfo.EffectModule == "大促视图" {
		curr["biz_effect_module"] = "big_promotion_view"
	}
	if len(appendParams) > 0 {
		for k, v := range appendParams {
			curr[k] = v
		}
	}
	var extrapParams = make(map[string]string)
	if req.BaseReq.SubScenarioInfo != nil && *req.BaseReq.SubScenarioInfo == analysis.SubScenarioType_Search {
		extrapParams["origin"] = "search"
	}
	if req.BaseReq.SubScenarioInfo != nil && (*req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForKeyInSupply || *req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForSuggestInSupply) {
		extrapParams["origin"] = "search_in_supply"
		if *req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForKeyInSupply { // 重点引入供给品
			curr["key_prod"] = 1
		}
	}

	prodPortraitApiPathData := GetProdPortraitApiPath(ctx, bizType, extrapParams)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()

	if req.BaseReq.Router == ProductSelectProdDetailList {
		routerReq := common_request.CommonAnalysisRequest{}
		if unmarshalErr := sonic.UnmarshalString(req.BaseReq.ReqMarshal, &routerReq); unmarshalErr != nil {
			logs.CtxError(ctx, "UnmarshalString error, %s", unmarshalErr.Error())
		}
		if routerReq.BaseReq != nil {
			curr["biz_type"] = routerReq.BaseReq.BizType
		}
		//f.ExeQueryInvokerRaw(curr, "7576647297522467867", param.SinkTable("product_extra")).SetParallel(true).SetMaxParallelNum(5)
	}
	logs.CtxInfo(ctx, "GetPordDetailList curr, %s", jsonx.ToString(curr))

	if bizType == dimensions.BizType_GreatValueBuyBigLink {
		f.ExeQueryInvokerRaw(curr, prodPortraitApiPathData.ProdDetailPath, param.SinkTable("product_detail")).SetParallel(true).SetMaxParallelNum(5)
		// 整体信息，商家数, 商品总数
		f.ExeQueryInvokerRaw(curr, prodPortraitApiPathData.ProdOverallPath, param.SinkTable("overview_info")).SetParallel(true).SetMaxParallelNum(5)
		// 商品去重
		f.ExeProduceSql(`
		select  distinct prod_id as prod_id
		from    product_detail 
		`, param.SinkTable("distinct_prod_id"))
		// 输入商品id信息，拿到商品图片信息
		f.ExeProduceCustom([]param.Source{param.SourceTable("distinct_prod_id")}, analysis_service.AddProductImage, param.SinkTable("product_images"))
		f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("product_detail"), param.SinkTable("target_data")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").
			SetDimColumns([]string{"sku_id", "prod_id"}))
		var effectModuleList = make([]string, 0)

		if bizType == dimensions.BizType_MorningMarketProduct || bizType == dimensions.BizType_VolumePrice {
			effectModuleList = []string{"商品明细"}
		} else {
			effectModuleList = []string{"指标卡", "商品明细"}
		}
		f.ExeQueryCustom([]param.Source{param.SourceConst(int64(bizType)), param.SourceConst(false), param.SourceConst(effectModuleList)}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
		f.ExeProduceSql(`
		select  sku_id,
		    	prod_id,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.display_order as display_order
		from    target_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		`, param.SinkTable("target_data")).SetUdfs(map[string]*onetable.UdfFunction{
			"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		})
	} else {
		f.ExeQueryInvokerRaw(curr, prodPortraitApiPathData.ProdDetailPath, param.SinkTable("product_detail")).SetParallel(true).SetMaxParallelNum(5)
		// 整体信息，商家数, 商品总数
		if len(curr) > 0 {
			curr["select_type"] = "overview_info"
		}
		f.ExeQueryInvokerRaw(curr, prodPortraitApiPathData.ProdOverallPath, param.SinkTable("overview_info")).SetParallel(true).SetMaxParallelNum(5)
		// 输入商品id信息，拿到商品图片信息
		f.ExeProduceCustom([]param.Source{param.SourceTable("product_detail")}, analysis_service.AddProductImage, param.SinkTable("product_images"))
		f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("product_detail"), param.SinkTable("target_data")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").
			SetDimColumns([]string{"prod_id"}))
		var effectModuleList = make([]string, 0)

		if bizType == dimensions.BizType_MorningMarketProduct || bizType == dimensions.BizType_VolumePrice {
			effectModuleList = []string{"商品明细"}
		} else {
			effectModuleList = []string{"指标卡", "商品明细"}
		}
		f.ExeQueryCustom([]param.Source{param.SourceConst(int64(bizType)), param.SourceConst(false), param.SourceConst(effectModuleList)}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
		f.ExeProduceSql(`
		select  prod_id,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.display_order as display_order
		from    target_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		`, param.SinkTable("target_data")).SetUdfs(map[string]*onetable.UdfFunction{
			"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		})
	}

	var dimSubSql string
	if bizType == dimensions.BizType_MorningMarketProduct {
		dimSubSql = `prod_level,`
	}

	basicInfo := `a.prod_name as prod_name,
				shop_id,
				shop_name,
				brand_name,
				complex_brand_s_level as brand_level,
				show_pv,
				pay_ord_cnt as order_num,
				industry_name,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name,`
	if bizType == dimensions.BizType_VolumePrice {
		basicInfo = `a.prod_name as prod_name,
				shop_id,
				shop_name,
				brand_name,
				complex_brand_s_level as brand_level,
				industry_name,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name,`
	}
	if bizType == dimensions.BizType_GuessBoostData {
		basicInfo = `a.prod_name as prod_name,`
	}

	if bizType == dimensions.BizType_GreatValueBuySearch {
		basicInfo = `a.prod_name as prod_name,
				shop_id,
				shop_name,
			  brand_name,
				industry_name,
				complex_brand_s_level as brand_level,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name,
		`
	}
	if bizType == dimensions.BizType_GreatValueBuyBigLink {
		basicInfo = `a.prod_name as prod_name,
                sku_name,
                brand_name,
				sku_cluster_id,
				sku_cluster_name,
				in_compare_price_tag,
				out_compare_price_tag,
                first_level_cate_name,
                second_level_cate_name,
                leaf_cate_name,
                shop_id,
                shop_name,
                industry_name,
                complex_brand_s_level,
		`
	}
	if bizInfo.EffectModule == "大促视图" {
		basicInfo = `a.prod_name as prod_name,
				shop_id,
				shop_name,
				brand_name,
				complex_brand_s_level as brand_level,
				industry_name,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name,`
	}
	if strings.Contains(bizInfo.EffectModule, "货盘复盘") {
		basicInfo = `a.prod_name as prod_name,
				shop_id,
				shop_name,
				'-' as brand_name,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name,
				complex_brand_s_level as brand_level,
				`
	}
	if bizType == dimensions.BizType_MarketingEngine {
		basicInfo = `a.prod_name as prod_name,
					 a.pay_ord_cnt as order_num,
					first_level_cate_name,
					second_level_cate_name,
					shop_id,
					shop_name,
					brand_name,
					complex_brand_s_level as brand_level,
					industry_name,
					leaf_cate_name,`
	}

	if bizType == dimensions.BizType_GreatValueBuyBigLink {
		f.ExeProduceSql(fmt.Sprintf(`
			select  a.sku_id as sku_id,
			    	a.prod_id as prod_id,
					b.images as prod_images,
					%s
					%v
					(select * from target_data where target_data.sku_id = product_detail.sku_id) as target_list
			from    product_detail a
			left join
					product_images b
			on      a.prod_id=b.prod_id
		`, basicInfo, dimSubSql), param.SinkTable("res_data"))
	} else {
		f.ExeProduceSql(fmt.Sprintf(`
		select  a.prod_id as prod_id,
				b.images as prod_images,
				%s
				%v
				(select * from target_data where target_data.prod_id = product_detail.prod_id) as target_list
		from    product_detail a
		left join
				product_images b
		on      a.prod_id=b.prod_id
	`, basicInfo, dimSubSql), param.SinkTable("res_data"))
	}

	var productInfoList = make([]*analysis_service.ProductInfo, 0)
	var overviewInfo = make(map[string]int64)
	//var productExtra = make(map[string]string)
	f.ExeView(param.SourceTable("res_data"), &productInfoList)
	f.ExeView(param.SourceTable("overview_info"), &overviewInfo)
	//f.ExeView(param.SourceTable("product_extra"), &productExtra)
	//logs.CtxInfo(ctx, "product extra info:", productExtra)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	logs.CtxInfo(ctx, "productInfoList = "+litter.Sdump(productInfoList))
	resp, err = analysis_service.PackerProductDetail(
		req.GetPageReq().GetPageNum(), req.GetPageReq().GetPageSize(), overviewInfo, productInfoList, bizType)
	if err != nil {
		logs.CtxError(ctx, "打包结果数据失败,err:"+err.Error())
		return nil, err
	}
	if bizType == dimensions.BizType_GrowthProductStrategy {
		err = analysis_service.GetProductDetailCostData(ctx, osReq, resp)
		if err != nil {
			logs.CtxError(ctx, "添加货补数据失败,err:"+err.Error())
			return nil, err
		}
	}
	// 指标排序
	if resp != nil {
		for _, prodInfo := range resp.ProductList {
			if prodInfo != nil {
				sort.Slice(prodInfo.TargetList, func(i, j int) bool {
					return prodInfo.TargetList[i].DisplayOrder < prodInfo.TargetList[j].DisplayOrder
				})
			}
		}
	}
	return resp, nil
}

func GetProdPortraitApiPath(ctx context.Context, bizType dimensions.BizType, extraParam map[string]string) biz_utils.ProdPortraitApiPathData {
	prodPortraitApiPathData := biz_utils.ProdPortraitApiPathData{
		ProdDetailPath:  apiPathProdDetail,
		ProdOverallPath: apiPathProdOverall,
		PieGraphPath:    apiPathPieGraph,
		Top9EnumPath:    apiPathTop9Enum,
	}
	apiPathInfo := biz_utils.ApiPathMap[bizType]
	conf, _ := tcc.GetBigLinkClusterSwitchConf(ctx)
	if bizType == dimensions.BizType_GreatValueBuyBigLink && conf != nil && !conf.Switch { // 聚合链接诊断，未迁移的话用原来的表
		apiPathInfo = &prodPortraitApiPathData
	}
	bizInfo, ctx, _ := biz_utils.GetBizMetaInfo(ctx, bizType)
	if bizInfo != nil && apiPathInfo == nil {
		apiPathInfo = biz_utils.ApiPathMapByEffectiveModule[bizInfo.EffectModule]
	}
	if apiPathInfo != nil {
		if len(apiPathInfo.ProdDetailPath) > 0 {
			prodPortraitApiPathData.ProdDetailPath = apiPathInfo.ProdDetailPath
		}
		if len(apiPathInfo.ProdOverallPath) > 0 {
			prodPortraitApiPathData.ProdOverallPath = apiPathInfo.ProdOverallPath
		}
		if len(apiPathInfo.PieGraphPath) > 0 {
			prodPortraitApiPathData.PieGraphPath = apiPathInfo.PieGraphPath
		}
		if len(apiPathInfo.Top9EnumPath) > 0 {
			prodPortraitApiPathData.Top9EnumPath = apiPathInfo.Top9EnumPath
		}
	}

	if extraParam != nil {
		originValue, exists := extraParam["origin"]
		if exists {
			if originValue == "search" {
				prodPortraitApiPathData.ProdDetailPath = apiPathProdSearchDetail
				prodPortraitApiPathData.ProdOverallPath = apiPathProdSearchOverall
				prodPortraitApiPathData.PieGraphPath = apiPathPieSearchGraph
				prodPortraitApiPathData.Top9EnumPath = apiPathTop9SearchEnum
			} else if originValue == "search_in_supply" {
				prodPortraitApiPathData.ProdDetailPath = apiPathProdSearchV3Detail
				prodPortraitApiPathData.ProdOverallPath = apiPathProdSearchV3Overall
				prodPortraitApiPathData.PieGraphPath = apiPathPieSearchV3Graph
				prodPortraitApiPathData.Top9EnumPath = apiPathTop9SearchV3Enum
			}
		}
	}
	return prodPortraitApiPathData
}
