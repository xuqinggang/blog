package prod_portrait

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"context"
)

func (p *ProdPortraitService) GetProdDetailDimensions(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp *dimensions.GetDimensionListData, err error) {
	analysisRes, err := AnalysisModule(ctx, req.BaseReq)
	if err != nil {
		logs.CtxError(ctx, "解析商品画像参数失败，err:"+err.Error())
		return nil, err
	}
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, analysisRes.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "[GetProdDetailDimensions]业务线未发现元信息, bizType = %s", analysisRes.BizType)
		return nil, err
	}
	ret := &dimensions.GetDimensionListData{
		UserDimensions:    make([]*dimensions.DimensionInfo, 0),
		PlaceDimensions:   make([]*dimensions.DimensionInfo, 0),
		ProductDimensions: make([]*dimensions.DimensionInfo, 0),
		OrderDimensions:   make([]*dimensions.DimensionInfo, 0),
		DefaultGroupAttrs: make([]*dimensions.SelectedMultiDimensionInfo, 0),
		ThresholdAttrMeta: make([]*dimensions.ThresholdAttrMeta, 0),
	}
	dimInfoList, err := new(dao.DimensionListDao).BatchGetDimensionByIdList(ctx, bizInfo.ProdPortraitDims)
	if err != nil {
		return nil, err
	}
	dimList, err := p.DimensionService.GetDimEnumInfoByDimInfoList(ctx, dimInfoList, &analysisRes.BizType)
	if err != nil {
		return nil, err
	}
	for _, dim := range dimList {
		switch dim.DimensionCategory {
		case dimensions.DimensionAttributeType_User:
			ret.UserDimensions = append(ret.UserDimensions, dim)
		case dimensions.DimensionAttributeType_Product:
			ret.ProductDimensions = append(ret.ProductDimensions, dim)
		case dimensions.DimensionAttributeType_Place:
			ret.PlaceDimensions = append(ret.PlaceDimensions, dim)
		case dimensions.DimensionAttributeType_Order:
			ret.OrderDimensions = append(ret.OrderDimensions, dim)
		default:
			return
		}
	}
	return ret, nil
}
