package prod_portrait

import (
	"context"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/model"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait/attribution_analysis"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait/common_request"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait/order_responseibility"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait/price_aa_analysis"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait/price_trend"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait/prod_analysis"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait/volume_price"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
)

type IProdPortraitService interface {
	GetProdPortrait(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp []*analysis.PieGraphItem, err error)
	GetPordDetailList(ctx context.Context, req *analysis.GetPordDetailListRequest) (resp *analysis.GetProductAnalysisMultiDimProductListData, err error)
	GetEchoDisplayDims(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp []*dimensions.SelectedDimensionInfo, err error)
	GetProdDetailDimensions(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp *dimensions.GetDimensionListData, err error)
}

type ProdPortraitService struct {
	DimensionListDao dao.IDimensionListDao
	DimensionEnumDao dao.IDimensionEnumDao
	AttributeDao     dao.IAttributeDao
	DimensionService dimension_service.IDimensionService
}

const (
	apiPathPieGraph    = "7399919760391095306"
	apiPathProdDetail  = "7399935196486829066"
	apiPathProdOverall = "7400375325433021491"
	apiPathTop9Enum    = "7416249372020605989"
)

const (
	apiPathPieSearchGraph    = "7486010076340290597"
	apiPathProdSearchDetail  = "7484176139192173631"
	apiPathProdSearchOverall = "7484182568737227787"
	apiPathTop9SearchEnum    = "7486010113120060453"
)

// 搜索三期供给商品的商品明细
const (
	apiPathPieSearchV3Graph    = "7507461595027604530"
	apiPathProdSearchV3Detail  = "7505044045333349427"
	apiPathProdSearchV3Overall = "7507467307652842522"
	apiPathTop9SearchV3Enum    = "7507478643354993702"
)

// 模块路由
const (
	prodAnalysisMultipleDimList     = "/product_analysis/analysis/get_multi_dim_list"
	prodAnalysisMultipleDimFullList = "/product_analysis/analysis/get_multi_dim_full_list"
	prodAnalysisCoreTargetCard      = "/product_analysis/analysis/get_core_overview"
	prodAnalysisReportTable         = "/product_analysis/analysis/get_product_report_table"
	priceTrendDistribution          = "/product_analysis/price_trend/get_price_insight_hierarchical_trend"
	priceTrendBubbleChart           = "/product_analysis/price_trend/get_price_insight_bubble_chart"
	priceAAFlowStandardCoreOverview = "/product_analysis/price_aa/get_flow_standard_core_overview"
	priceAADiffDistributed          = "/product_analysis/price_aa/get_biz_income_diff_distributed"
	priceAAFlowDiffStandardCard     = "/product_analysis/price_aa/get_flow_diff_standard_card"
	priceAASupplyCntList            = "/product_analysis/price_aa/get_supply_cnt_list"
	priceAASupplyDistributed        = "/product_analysis/price_aa/get_supply_distributed"

	orderResponsibilityDistributed = "/product_analysis/price_trend/get_price_responsibility_distributed"
	orderResponsibilityChange      = "/product_analysis/price_trend/get_price_responsibility_change"
	orderResponsibilityTargetList  = "/product_analysis/price_trend/get_price_responsibility_target_list"
	orderResponsibilityBubbleChart = "/product_analysis/price_trend/get_order_responsibility_bubble_chart"

	productAnalysisProdPool      = "/product_analysis/product_alert/query_analysis_pool_detail"
	attributionPriceDistribution = "/product_analysis/attribution/get_prod_price_distribution"

	volumePriceMultipleDimFullList     = "/product_analysis/volume_price/get_multi_dim_full_list"
	guessAttributionTreeMultiDim       = "/product_analysis/attribution/get_attribution_multi_dim_analysis"
	greatValueBuyMultiDimTable         = "/product_analysis/great_value_buy/get_product_multi_dimension_table"
	greatValueBuyDiagnosisCoreOverview = "/product_analysis/great_value_buy/get_product_diagnosis_common_core_overview"
	// 货盘复盘
	prodReviewMultiDimTable    = "/product_analysis/prod_review/multi_dim_table"    // 人货场洞察
	prodReviewAnalysisItemData = "/product_analysis/prod_review/analysis_item_data" // 四象限分析
	prodReviewBubbleChart      = "/product_analysis/prod_review/get_bubble_chart"   // 气泡图

	ProductSelectProdDetailList = "/product_analysis/product_select/get_prod_detail_list" // 选品任务-商品列表

	ProductAnalysisMarketingEngineMultiDimTable = "/product_analysis/marketing_engine/multi_dim_table"
)

// AnalysisModule 解析入参，生成prod_id子查询,外层需要拼接的where条件，走超值购还是大盘表查商品明细
func AnalysisModule(ctx context.Context, baseReq *analysis.ProdDetailBaseRequest) (analysisRes *model.AnalysisRes, err error) {
	if baseReq == nil {
		return
	}
	switch baseReq.Router {
	case prodAnalysisCoreTargetCard:
		return prod_analysis.GenMultipleAnalysis(ctx, baseReq, false)
	case prodAnalysisMultipleDimList:
		return prod_analysis.GenMultipleAnalysis(ctx, baseReq, false)
	case prodAnalysisMultipleDimFullList:
		return prod_analysis.GenMultipleAnalysis(ctx, baseReq, true)
	case prodAnalysisReportTable:
		return prod_analysis.GenMultipleAnalysis(ctx, baseReq, false) // TODO: 待确认是否需要该逻辑
	case priceTrendBubbleChart:
		return price_trend.GenPriceTrendBubbleChart(ctx, baseReq)
	case priceTrendDistribution:
		return price_trend.GenPriceTrendDistribution(ctx, baseReq)
	case priceAAFlowStandardCoreOverview:
		return price_aa_analysis.GenPriceAAFlowStandardCoreOverview(ctx, baseReq)
	case priceAAFlowDiffStandardCard:
		return price_aa_analysis.GenPriceAAFlowDiffStandardCard(ctx, baseReq)
	case priceAADiffDistributed:
		return price_aa_analysis.GenPriceAADiffDistributed(ctx, baseReq)
	case priceAASupplyCntList:
		return price_aa_analysis.GenPriceAASupplyCntList(ctx, baseReq)
	case priceAASupplyDistributed:
		return price_aa_analysis.GenPriceAASupplyDistributed(ctx, baseReq)
	case orderResponsibilityDistributed:
		return order_responseibility.GenOrderResponsibilityDistributed(ctx, baseReq, true)
	case orderResponsibilityChange:
		codeArr := strings.Split(baseReq.Code, consts.ThreeEqualsSymbols)
		return order_responseibility.GenOrderResponsibilityDistributed(ctx, baseReq, len(codeArr) >= 3 && codeArr[2] == consts.IsTrueString)
	case orderResponsibilityTargetList:
		return order_responseibility.GenOrderResponsibilityDistributed(ctx, baseReq, false)
	case orderResponsibilityBubbleChart:
		return order_responseibility.GenOrderResponsibilityBubbleChart(ctx, baseReq)
	case productAnalysisProdPool:
		return prod_analysis.GenProdPoolAnalysis(ctx, baseReq)
	case attributionPriceDistribution:
		return attribution_analysis.GenAttributionPriceDistribution(ctx, baseReq)
	case guessAttributionTreeMultiDim:
		return attribution_analysis.GenGuessAttributionAnalysis(ctx, baseReq)
	case volumePriceMultipleDimFullList:
		return volume_price.GenMultipleAnalysis(ctx, baseReq)
	case greatValueBuyMultiDimTable:
		return prod_analysis.GenMultipleAnalysis(ctx, baseReq, true)
	case greatValueBuyDiagnosisCoreOverview:
		return prod_analysis.GenMultipleAnalysis(ctx, baseReq, true)
	case prodReviewMultiDimTable:
		return common_request.GenCommonAnalysis(ctx, baseReq, true)
	case prodReviewAnalysisItemData:
		return common_request.GenCommonAnalysis(ctx, baseReq, true)
	case prodReviewBubbleChart:
		return common_request.GenCommonAnalysis(ctx, baseReq, true)
	case ProductSelectProdDetailList:
		res, aErr := common_request.GenCommonAnalysis(ctx, baseReq, true)
		if aErr != nil {
			logs.CtxError(ctx, "ProductSelectProdDetailList GenCommonAnalysis error, %s", aErr.Error())
			return nil, aErr
		}
		res.BizType = dimensions.BizType_GrowthProductStrategy
		res.WhereFilter = nil
		res.AppendParams = nil
		return res, nil
	case ProductAnalysisMarketingEngineMultiDimTable:
		return common_request.GenCommonAnalysis(ctx, baseReq, true)
	}
	return nil, errors.New("[AnalysisModule]所传入的router未注册，请检查传入的router是否正确")
}

type ProdPortraitApiPathData struct {
	ProdDetailPath  string
	ProdOverallPath string
	PieGraphPath    string
	Top9EnumPath    string
}

var apiPathMap = map[dimensions.BizType]*ProdPortraitApiPathData{
	dimensions.BizType_VolumePrice: {
		ProdDetailPath:  "7444886720778208283",
		ProdOverallPath: "7446241341882844170",
	},
	dimensions.BizType_GuessBoostData: {
		ProdDetailPath:  "7487813335765795891",
		ProdOverallPath: "7487813335765795891",
	},
}
