package prod_portrait

import (
	"context"
	"fmt"
	"strconv"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/model"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/great_value_buy_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
)

func (p *ProdPortraitService) GetProdPortrait(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp []*analysis.PieGraphItem, err error) {
	analysisRes, err := AnalysisModule(ctx, req.BaseReq)
	if err != nil {
		logs.CtxError(ctx, "解析商品画像参数失败，err:"+err.Error())
		return nil, err
	}
	// 获取跳转位置的与MVP版重叠人、场属性，拼接到筛选项中
	dimFilters, err := MergeDimensions(ctx, req.BaseReq.Dimensions, analysisRes, analysisRes.BizType)
	if err != nil {
		return nil, err
	}

	dimMap, err := p.DimensionListDao.GetAllDimensionMap(ctx)
	//dimMap, err := GetProdDetailDimMap(ctx, dimFilters, analysisRes.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProdPortrait]获取map失败，err=%v+", err)
		return nil, err
	}
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: &dimensions.ProductAnalysisBaseStruct{
			BizType:        analysisRes.BizType,
			StartDate:      req.BaseReq.StartDate,
			EndDate:        req.BaseReq.EndDate,
			Dimensions:     dimFilters,
			ThresholdAttrs: analysisRes.TopNFilter,
		},
		DimMap: dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return
	}
	if len(analysisRes.ProdSubSql) > 0 {
		curr["prod_sub_sql"] = analysisRes.ProdSubSql
	}
	if len(analysisRes.AppendParams) > 0 {
		for k, v := range analysisRes.AppendParams {
			curr[k] = v
		}
	}
	var extrapParams = make(map[string]string)
	if req.BaseReq.SubScenarioInfo != nil && *req.BaseReq.SubScenarioInfo == analysis.SubScenarioType_Search {
		extrapParams["origin"] = "search"
	}
	if req.BaseReq.SubScenarioInfo != nil && (*req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForKeyInSupply || *req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForSuggestInSupply) {
		extrapParams["origin"] = "search_in_supply"
		if *req.BaseReq.SubScenarioInfo == great_value_buy_service.SubScenarioInfoForKeyInSupply { // 重点引入供给品
			curr["key_prod"] = 1
		}
	}

	prodPortraitApiPathData := GetProdPortraitApiPath(ctx, analysisRes.BizType, extrapParams)
	dimIdInfoMap, groupDimIds, err := GetGroupDimExpresses(ctx, analysisRes.BizType)
	if err != nil {
		return nil, err
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	resp = make([]*analysis.PieGraphItem, len(groupDimIds))
	// 生成ID和排序顺序的map
	var idIndexMap = make(map[int64]int)
	for i, id := range groupDimIds {
		idIndexMap[id] = i
	}
	f := flow.Empty()
	for id, dim := range dimIdInfoMap {
		pieGraphTableName := fmt.Sprintf("pie_graph_%v", id)
		item := &analysis.PieGraphItem{
			Name:  fmt.Sprintf("商品%s分层", dim.DimName),
			Value: make([]*analysis.DimEnumTargetCard, 0),
		}
		curr["dimension"] = dim.Express
		top9TableName := fmt.Sprintf("top9_%v", id)
		f.ExeQueryInvokerRaw(curr, prodPortraitApiPathData.Top9EnumPath, param.SinkTable(top9TableName)).SetParallel(true).SetMaxParallelNum(12)
		f.ExeQueryInvokerRaw(curr, prodPortraitApiPathData.PieGraphPath, param.SinkTable(pieGraphTableName)).
			AddParam("enum_array", param.SourceSqlWithType(fmt.Sprintf("select `group_dim` from %v union all select 'zjr_mock' as `group_dim`", top9TableName), []interface{}{})).SetParallel(true).SetMaxParallelNum(12)
		f.ExeProduceCustom([]param.Source{param.SourceTable(pieGraphTableName), param.SourceConst(strconv.Itoa(int(id))), param.SourceConst("group_dim")},
			price_analysis_service.GetEnumDisplayNameTable, param.SinkTable("enum_code_name"))
		f.ExeProduceSql(fmt.Sprintf(`
			select  'prod_cnt' as target_name,
					prod_cnt as target_value,
					'商品数' as display_name,
					get_display_value(prod_cnt, 'int', '', 2) as display_value,
					group_dim as enum_code,
					case when b.name='' then '其他' else b.name end as enum_name, 
					%v as dimension_id,
					'%v' as dimension_name,
					prod_cnt/(select sum(prod_cnt) from %s) as percent,
					case when group_dim in ('其他') then true else false end as is_fake_dim_id
			from   %s a 
			left join enum_code_name b
			on a.group_dim = b.code`, id, dim.DimName, pieGraphTableName, pieGraphTableName),
			param.SinkTable(fmt.Sprintf("res_data_%v", id))).SetUdfs(map[string]*onetable.UdfFunction{
			"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		})
		f.ExeView(param.SourceTable(fmt.Sprintf("res_data_%v", id)), &item.Value)
		// 按照tcc配置的顺序排序
		if _, ok := idIndexMap[id]; ok && idIndexMap[id] < len(resp) && idIndexMap[id] >= 0 {
			resp[idIndexMap[id]] = item
		}
	}
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return resp, nil
}

func GetGroupDimExpresses(ctx context.Context, bizType dimensions.BizType) (map[int64]*dimInfo, []int64, error) {
	var groupDims []int64
	//if err := tcc.GetTccConfWithUnmarshalTarget(ctx, "prod_detail_group_dim_ids", &groupDims); err != nil {
	//	logs.CtxError(ctx, "GetProdDetailPieGraphDim Error, tcc key: prod_detail_group_dim_ids,err:"+err.Error())
	//	return nil, nil, errors.WithMessage(err, "GetProdDetailPieGraphDim failed")
	//}
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "[GetProdDetailDimMap]业务线未发现元信息, bizType = %s", bizType)
		return nil, nil, err
	}
	groupDims = bizInfo.ProdPortraitPieGraphDims

	var dimInfoMap = make(map[int64]*dimInfo)
	//var expressList = make([]string, 0)
	var dimService = &dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao), DimensionEnumDao: new(dao.DimensionEnumDao)}
	for _, dimId := range groupDims {
		express, err := dimService.GetDimColumnExpressStr(ctx, dimId)
		if err != nil {
			logs.CtxError(ctx, "生成维度表达式失败，err:"+err.Error())
			return nil, nil, err
		}
		dimInfoMap[dimId] = &dimInfo{
			DimId:   dimId,
			Express: express,
		}
		//expressList = append(expressList, express)
	}
	dimMap, err := dimService.GetDimensionMapByIDList(ctx, groupDims)
	if err != nil {
		return nil, nil, err
	}
	for dimId, dimInfo := range dimInfoMap {
		dimIdString := strconv.Itoa(int(dimId))
		if dim, ok := dimMap[dimIdString]; ok {
			dimInfo.DimName = dim.ShowName
		}
	}

	return dimInfoMap, groupDims, nil
}

type dimInfo struct {
	DimId   int64  `json:"dim_id"`
	Express string `json:"express"`
	DimName string `json:"dim_name"`
}

func MergeDimensions(ctx context.Context, prodFilters []*dimensions.SelectedDimensionInfo, analysisRes *model.AnalysisRes, bizType dimensions.BizType) ([]*dimensions.SelectedDimensionInfo, error) {
	var dimFilters = make([]*dimensions.SelectedDimensionInfo, 0)
	if len(prodFilters) > 0 {
		dimFilters = append(dimFilters, prodFilters...)
	}
	if analysisRes != nil {
		if analysisRes.ProdSubSql == consts.Empty {
			dimFilters = append(dimFilters, analysisRes.WhereFilter...)
		} else {
			// 获取人、场的筛选条件
			idMap, err := GetPersonPlaceDimIdsMap(ctx, bizType)
			if err != nil {
				return nil, err
			}

			for _, filter := range analysisRes.WhereFilter {
				if _, ok := idMap[convert.ToInt64(filter.Id)]; ok {
					dimFilters = append(dimFilters, filter)
				}
			}
		}
	}
	return dimFilters, nil
}

func GetPersonPlaceDimIdsMap(ctx context.Context, bizType dimensions.BizType) (map[int64]*dao.DimensionInfo, error) {
	var resMap = make(map[int64]*dao.DimensionInfo)
	dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, bizType)
	if err != nil {
		return nil, err
	}
	for _, dimData := range dimMap {
		if dimData.DimensionCategory == int64(dimensions.DimensionAttributeType_Place) || dimData.DimensionCategory == int64(dimensions.DimensionAttributeType_User) {
			resMap[dimData.ID] = dimData
		}
	}
	return resMap, nil
}

func GetProdDetailDimMap(ctx context.Context, dimFilters []*dimensions.SelectedDimensionInfo, bizType dimensions.BizType) (map[int64]*dao.DimensionInfo, error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "[GetProdDetailDimMap]业务线未发现元信息, bizType = %s", bizType)
		return nil, err
	}
	dimInfoList, err := new(dao.DimensionListDao).BatchGetDimensionByIdList(ctx, bizInfo.ProdPortraitDims)
	if err != nil {
		return nil, err
	}
	var dimMap = make(map[int64]*dao.DimensionInfo)
	for _, dim := range dimInfoList {
		dimMap[dim.ID] = dim
	}
	//dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, dimensions.BizType_ProdDetail)
	//if err != nil {
	//	logs.CtxError(ctx, "[GetProdPortrait]获取map失败，err=%v+", err)
	//	return nil, err
	//}
	dimMap, err = MergeDimMap(ctx, dimFilters, dimMap)
	if err != nil {
		return nil, err
	}
	return dimMap, nil
}

func MergeDimMap(ctx context.Context, dimFilter []*dimensions.SelectedDimensionInfo, dimMap map[int64]*dao.DimensionInfo) (map[int64]*dao.DimensionInfo, error) {
	var idList = make([]int64, 0)
	for _, filter := range dimFilter {
		filterIdInt64 := convert.ToInt64(filter.Id)
		if _, ok := dimMap[filterIdInt64]; !ok {
			idList = append(idList, filterIdInt64)
		}
	}
	dimInfoList, err := new(dao.DimensionListDao).BatchGetDimensionByIdList(ctx, idList)
	if err != nil {
		return nil, err
	}
	for _, info := range dimInfoList {
		dimMap[info.ID] = info
	}
	return dimMap, nil
}
