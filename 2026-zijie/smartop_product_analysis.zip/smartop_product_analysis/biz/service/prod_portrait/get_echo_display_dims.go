package prod_portrait

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

func (p *ProdPortraitService) GetEchoDisplayDims(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp []*dimensions.SelectedDimensionInfo, err error) {
	analysisRes, err := AnalysisModule(ctx, req.BaseReq)
	if err != nil {
		logs.CtxError(ctx, "解析商品画像参数失败，err:"+err.Error())
		return nil, err
	}
	resp = make([]*dimensions.SelectedDimensionInfo, 0)
	for _, filter := range analysisRes.WhereFilter {
		if filter != nil && len(filter.SelectedValues) > 0 {
			if filter.Name == "" {
				dim, err := p.DimensionListDao.GetDimensionById(ctx, convert.ToInt64(filter.Id))
				if err != nil || dim == nil {
					if err != nil {
						logs.CtxError(ctx, "获取维度信息失败,err:"+err.Error())
					}
					logs.CtxError(ctx, "[GetEchoDisplayDims]获取的维度信息为nil")
				} else {
					filter.Name = dim.ShowName
				}
			}
			resp = append(resp, filter)
		}
	}

	//idMap, err := GetPersonPlaceDimIdsMap(ctx, bizType)
	//if err != nil {
	//	return nil, err
	//}
	//resp = make([]*dimensions.SelectedDimensionInfo, 0)
	// 在TCC配置的MVP人、场属性的维度筛选 与 whereFilter的重叠项，返回前端回显
	//for _, filter := range whereFilter {
	//	if _, ok := idMap[convert.ToInt64(filter.Id)]; ok && len(filter.SelectedValues) > 0 {
	//		if _, ok2 := respDimMap[filter.Id]; !ok2 {
	//			respDimMap[filter.Id] = filter
	//		} else { // 相同的维度，维值需要取交集
	//			respDimMap[filter.Id].SelectedValues = intersect(respDimMap[filter.Id].SelectedValues, filter.SelectedValues)
	//		}
	//	}
	//}

	//for _, info := range resp {
	//	// 如果info的name为空串，需要读mysql匹配
	//	if info.Name == "" {
	//		dim, err := p.DimensionListDao.GetDimensionById(ctx, convert.ToInt64(info.Id))
	//		if err != nil {
	//			logs.CtxError(ctx, "获取维度信息失败,err:"+err.Error())
	//		}
	//		info.Name = dim.ShowName
	//	}
	//	resp = append(resp, info)
	//}

	return resp, nil
}

// intersect 返回两个切片的交集
func intersect(slice1, slice2 []*dimensions.EnumElement) []*dimensions.EnumElement {
	m := make(map[string]bool)
	var intersection = make([]*dimensions.EnumElement, 0)

	// 将 slice1 的元素存入 map
	for _, item := range slice1 {
		m[item.Code] = true
	}

	// 检查 slice2 的元素是否在 map 中
	for _, item := range slice2 {
		if _, ok := m[item.Code]; ok {
			intersection = append(intersection, item)
			// 防止重复添加相同的元素
			delete(m, item.Code)
		}
	}

	return intersection
}
