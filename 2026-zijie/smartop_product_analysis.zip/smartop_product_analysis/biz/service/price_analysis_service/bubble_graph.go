package price_analysis_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"context"
	"fmt"
	"github.com/bytedance/sonic"
	"sort"
	"strconv"
	"strings"
)

const (
	ZAxisTarget            = "pay_sku_cnt"
	ShowZAxisTarget        = "show_sku_cnt"
	PriceChangeZAxisTarget = "price_change_sku_cnt"
)

var TypeDimCodeSqlMap = map[dimensions.PriceComparisonType]map[string]string{
	dimensions.PriceComparisonType_Hybrid: {
		"90006": `                        
			case
				when sku_out_price_hybrid_power_tag_name in('无同款', '未覆盖') OR sku_xd_price_hybrid_power_tag_name in('无同款', '未覆盖') then '无同款or未覆盖'
				else concat(
					case
						when sku_out_price_hybrid_power_tag_name in('均价', '优价') then '站外非高价'
						else concat('站外', sku_out_price_hybrid_power_tag_name)
					end,
					'-',
					case
						when sku_xd_price_hybrid_power_tag_name in('均价', '优价') then '站内非高价'
						else concat('站内', sku_xd_price_hybrid_power_tag_name)
					end
				)
			end`, // SKU站内站外比价分层
		"90007": `
			case
				when order_out_price_hybrid_power_tag_name in('无同款', '未覆盖') OR order_xd_price_hybrid_power_tag_name in('无同款', '未覆盖') then '无同款or未覆盖'
				else concat(
					case
						when order_out_price_hybrid_power_tag_name in('均价', '优价') then '站外非高价'
						else concat('站外', order_out_price_hybrid_power_tag_name)
					end,
					'-',
					case
						when order_xd_price_hybrid_power_tag_name in('均价', '优价') then '站内非高价'
						else concat('站内', order_xd_price_hybrid_power_tag_name)
					end
				)
			end`, // 订单站内站外比价分层
		"90008": `
			case
				when show_out_price_power_tag_name in('无同款', '未覆盖') OR show_xd_price_power_tag_name in('无同款', '未覆盖') then '无同款or未覆盖'
				else concat(
					case
						when show_out_price_power_tag_name in('均价', '优价') then '站外非高价'
						else concat('站外', show_out_price_power_tag_name)
					end,
					'-',
					case
						when show_xd_price_power_tag_name in('均价', '优价') then '站内非高价'
						else concat('站内', show_xd_price_power_tag_name)
					end
				)
			end`,                               // 曝光站内站外比价分层
		"90002": "",                            // 高价改非高价流量效果分层
		"90001": "out_price_power_change_type", // 改价类型分层
	},
	dimensions.PriceComparisonType_NewStage: {
		"90006": `                        
			case
				when sku_out_price_power_tag_name in('无同款', '未覆盖') OR sku_xd_price_power_tag_name in('无同款', '未覆盖') then '无同款or未覆盖'
				else concat(
					case
						when sku_out_price_power_tag_name in('均价', '优价') then '站外非高价'
						else concat('站外', sku_out_price_power_tag_name)
					end,
					'-',
					case
						when sku_xd_price_power_tag_name in('均价', '优价') then '站内非高价'
						else concat('站内', sku_xd_price_power_tag_name)
					end
				)
			end `, // SKU站内站外比价分层
		"90007": `
			case
				when order_out_price_power_tag_name in('无同款', '未覆盖') OR order_xd_price_power_tag_name in('无同款', '未覆盖') then '无同款or未覆盖'
				else concat(
					case
						when order_out_price_power_tag_name in('均价', '优价') then '站外非高价'
						else concat('站外', order_out_price_power_tag_name)
					end,
					'-',
					case
						when order_xd_price_power_tag_name in('均价', '优价') then '站内非高价'
						else concat('站内', order_xd_price_power_tag_name)
					end
				)
			end`, // 订单站内站外比价分层
		"90008": `
			case
				when show_out_price_power_tag_name in('无同款', '未覆盖') OR show_xd_price_power_tag_name in('无同款', '未覆盖') then '无同款or未覆盖'
				else concat(
					case
						when show_out_price_power_tag_name in('均价', '优价') then '站外非高价'
						else concat('站外', show_out_price_power_tag_name)
					end,
					'-',
					case
						when show_xd_price_power_tag_name in('均价', '优价') then '站内非高价'
						else concat('站内', show_xd_price_power_tag_name)
					end
				)
			end`,                               // 曝光站内站外比价分层
		"90002": "",                            // 高价改非高价流量效果分层
		"90001": "out_price_power_change_type", // 改价类型分层
	},
}

func (p *PriceAnalysisService) GetPriceInsightBubbleChart(ctx context.Context, req *analysis.GetPriceInsightBubbleChartRequest) (resp *analysis.PriceInsightBubbleChartItem, err error) {
	dimMap, err := new(dao.DimensionListDao).GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceInsightCoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}
	curr, err := base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceInsightCoreOverview]生成os api查询参数失败，err=%v+", err)
		return nil, err
	}
	if req.IsPriceChange {
		priceChangeWhereStr, err := base_struct_condition.GetOutXdPriceChangeWhereStr(ctx, biz_info.GetCtxBizInfoPriceAAInOutType(ctx))
		if err != nil {
			logs.CtxError(ctx, "[GetPriceChangeFlowStandardSubSQL]GetOutXdPriceChangeWhereStr Err, %v", err)
			return nil, err
		}
		curr["price_change_filter"] = priceChangeWhereStr
	}
	var drillDimID string
	drillDimID, curr, err = AddBubbleParams(ctx, req, curr)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceInsightCoreOverview]添加额外筛选参数失败，err=%v+", err)
		return nil, err
	}
	apiPath := GetBubbleGraphApiPath(req)
	var effectModule []string
	if req.IsPriceChange {
		effectModule = []string{effectModulePriceChangeBubbleGraph}
	} else {
		effectModule = []string{effectModuleBubbleGraph}
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst(effectModule)}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("bubble_data")).SetParallel(true).SetMaxParallelNum(6)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("bubble_data"), param.SinkTable("bubble_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"drill_dim"}))
	f.ExeProduceCustom([]param.Source{param.SourceTable("bubble_data"), param.SourceConst(drillDimID), param.SourceConst("drill_dim")}, GetEnumDisplayNameTable, param.SinkTable("drill_dim_code_name"))
	f.ExeProduceSql(`
		select  a.*,
				case when b.name='' then a.drill_dim else b.name end as drill_display_name
		from    bubble_data a
		left join
				drill_dim_code_name b
		on      a.drill_dim=b.code`, param.SinkTable("bubble_data"))
	if req.GroupDimension != nil {
		curr, err = AddGroupDim(ctx, req.GroupDimension, curr)
		if err != nil {
			return
		}
		f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("group_data")).SetParallel(true).SetMaxParallelNum(6)
		f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("group_data"), param.SinkTable("group_data")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").SetDimColumns([]string{"drill_dim", "group_dim"}))
		f.ExeProduceCustom([]param.Source{param.SourceTable("group_data"), param.SourceConst(req.GroupDimension.Id), param.SourceConst("group_dim")}, GetEnumDisplayNameTable, param.SinkTable("group_dim_code_name"))
		f.ExeProduceSql(`
		select  a.*,
				case when b.name='' then a.group_dim else b.name end as group_display_name
		from    group_data a
		left join
				group_dim_code_name b
		on      a.group_dim=b.code`, param.SinkTable("group_data"))
	}
	AddBubbleFlow(f, req.XAxisTargetName, "group_data_x", "x_res_data", req.GroupDimension != nil)
	AddBubbleFlow(f, req.YAxisTargetName, "group_data_y", "y_res_data", req.GroupDimension != nil)

	var zAxis string
	if req.IsPriceChange {
		zAxis = PriceChangeZAxisTarget
	} else {
		if req.BaseReq.BizType == dimensions.BizType_PriceTrendShow {
			zAxis = ShowZAxisTarget
		} else {
			zAxis = ZAxisTarget
		}
	}
	AddBubbleFlow(f, zAxis, "group_data_z", "z_res_data", req.GroupDimension != nil)
	f.ExeProduceSql(`select distinct drill_dim from x_res_data`, param.SinkTable("bubble_point"))
	f.ExeProduceSql(`
		select  drill_dim,
				drill_dim as legend_code, 
				(
					select  *
					from    x_res_data a
					where   a.drill_dim=bubble_point.drill_dim
				) as x_axis,
				(
					select  *
					from    y_res_data a
					where   a.drill_dim=bubble_point.drill_dim
				) as y_axis,
				(
					select  *
					from    z_res_data a
					where   a.drill_dim=bubble_point.drill_dim
				) as z_axis
		from    bubble_point`, param.SinkTable("res_data"))
	resp = &analysis.PriceInsightBubbleChartItem{
		PointList: make([]*analysis.AxisPoint, 0),
	}
	f.ExeView(param.SourceTable("res_data"), &resp.PointList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	if req.Type == analysis.CoordinateAxisType_Avg { // 加权平均
		AddAvgData(resp)
	} else if req.Type == analysis.CoordinateAxisType_P50 { // 中位数
		AddMedianData(resp)
	}
	AddBubbleGraphProdTagCode(req, resp)
	AddBubbleLegend(resp)
	return resp, nil
}

type BubbleGraphTag struct {
	SelectDim *dimensions.SelectedDimensionInfo `json:"select_dim"`
	DrillDim  *dimensions.SelectedDimensionInfo `json:"drill_dim"`
}

func AddBubbleGraphProdTagCode(req *analysis.GetPriceInsightBubbleChartRequest, resp *analysis.PriceInsightBubbleChartItem) {
	if req.GroupDimension != nil {
		for _, point := range resp.PointList {
			addPointTag(req, point.XAxis)
			addPointTag(req, point.YAxis)
			addPointTag(req, point.ZAxis)
		}
	}
}

func addPointTag(req *analysis.GetPriceInsightBubbleChartRequest, axisPoint *analysis.TargetCardEntity) {
	if axisPoint != nil && axisPoint.GroupInfo != nil && len(axisPoint.GroupInfo.GroupList) > 0 {
		var drillDim = &dimensions.SelectedDimensionInfo{}
		if req.DrillDimension == nil && req.AnalysisDimension != nil {
			drillDim.Id = req.AnalysisDimension.Id
			drillDim.Name = req.AnalysisDimension.Name
			drillDim.AttrType = req.AnalysisDimension.AttrType
			drillDim.SelectedOperator = req.AnalysisDimension.SelectedOperator
			drillDim.SelectedValues = []*dimensions.EnumElement{{Code: axisPoint.GroupInfo.Name, Name: axisPoint.GroupInfo.DisplayName}}
		} else if req.DrillDimension != nil {
			drillDim.Id = req.DrillDimension.Id
			drillDim.Name = req.DrillDimension.Name
			drillDim.AttrType = req.DrillDimension.AttrType
			drillDim.SelectedOperator = req.DrillDimension.SelectedOperator
			drillDim.SelectedValues = []*dimensions.EnumElement{{Code: axisPoint.GroupInfo.Name, Name: axisPoint.GroupInfo.DisplayName}}
		}
		for _, entity := range axisPoint.GroupInfo.GroupList {
			var dimValue = &dimensions.SelectedDimensionInfo{
				Id:               req.GroupDimension.Id,
				Name:             req.GroupDimension.Name,
				AttrType:         req.GroupDimension.AttrType,
				SelectedOperator: req.GroupDimension.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{{Code: entity.GroupInfo.Name, Name: entity.GroupInfo.DisplayName}},
				IsGroup:          req.GroupDimension.IsGroup,
			}
			var code = &BubbleGraphTag{SelectDim: dimValue, DrillDim: drillDim}
			marshalString, err := sonic.MarshalString(code)
			if err == nil {
				entity.Extra = &analysis.TargetCardExtraInfo{ProdTagCode: marshalString}
			}
		}
	}
}

func AddBubbleParams(ctx context.Context, req *analysis.GetPriceInsightBubbleChartRequest, params map[string]interface{}) (string, map[string]interface{}, error) {
	var dimId string
	if req.DrillDimension == nil {
		if req.AnalysisDimension == nil {
			params["drill_dim"] = "price_tag"
		} else if _, ok := DimCodeNameMap[req.AnalysisDimension.Id]; ok {
			params["drill_dim"] = DimCodeNameMap[req.AnalysisDimension.Id]
		} else {
			return "", nil, errors.New("未匹配到输入的下钻维度")
		}
		dimId = req.AnalysisDimension.Id
	} else {
		if _, ok := DimCodeNameMap[req.DrillDimension.Id]; ok {
			params["drill_dim"] = DimCodeNameMap[req.DrillDimension.Id]
		} else {
			id, err := strconv.ParseInt(req.DrillDimension.Id, 10, 64)
			if err != nil {
				return "", nil, errors.WithMessage(err, "维度id类型转化失败")
			}
			dimC, err := (&dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao)}).GetDimColumnExpressStr(ctx, id)
			if err != nil {
				return consts.Empty, nil, err
			}
			params["drill_dim"] = dimC
		}
		dimId = req.DrillDimension.Id
	}
	params["main_target"] = req.YAxisTargetName

	// 如果是点击第一幅图的某个节点进行下钻，需要把下钻的条件加入筛选条件
	if req.DrillDimension != nil && req.AnalysisDimension != nil && len(req.AnalysisDimension.SelectedValues) > 0 {
		if dimCodeSql, ok := TypeDimCodeSqlMap[req.GetBaseReq().GetPriceComparisonType()]; ok {
			var enums strings.Builder
			for i, element := range req.AnalysisDimension.SelectedValues {
				if i > 0 {
					enums.WriteString(",")
				}
				enums.WriteString("'")
				enums.WriteString(element.Code)
				enums.WriteString("'")
			}
			if req.AnalysisDimension.Id == "90002" { // 高价改非高价流量效果分层
				params["analysis_dimension_filter"] = fmt.Sprintf(`
					hasAny(
						arrayConcat(
							if(aa_change_rate>=0.3, ['改价流量效果符合预期-aa30'], []),
							if(
								tk_lower_price_prod_show_cnt_rate>=0.5,
								['改价流量效果符合预期-同蔟50'],
								[]
							),
							if(
								aa_change_rate<0.3 AND tk_lower_price_prod_show_cnt_rate<0.5,
								['改价流量效果不及预期'],
								[]
							)
						),
						[%s]
					)`, enums.String())
			} else {
				if dimSql, ok := dimCodeSql[req.AnalysisDimension.Id]; ok {
					params["analysis_dimension_filter"] = fmt.Sprintf(`%s in (%s)`, dimSql, enums.String())
				}
			}
		}
	}
	return dimId, params, nil
}

func AddBubbleFlow(f flow.Flow, targetName, groupTableName, resTableName string, groupFlag bool) {
	var subSql string
	if groupFlag {
		f.ExeProduceSql(fmt.Sprintf(`
				select  g.target_value as value,
						g.target_name as name,
						b.display_name as display_name,
						g.drill_dim as drill_dim,
						get_display_value(g.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
						b.tips as tips,
						(
							select  group_dim as name,
									group_display_name as display_name,
									case
										when b.is_compute_percent = true then g.target_value/c.target_value
										else 0
									end as percent,
									b.is_compute_percent as is_show_percent
						) as group_info
				from    group_data g
				inner   join
						target_meta b
				on      g.target_name=b.name
				inner join 
						bubble_data c
				on c.target_name = g.target_name and c.drill_dim = g.drill_dim
				where   g.target_name='%v'`, targetName), param.SinkTable(groupTableName)).
			SetUdfs(map[string]*onetable.UdfFunction{
				"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
			})
		subSql = fmt.Sprintf(`(select * from %v g where g.name='%v' and  g.drill_dim=bubble_data.drill_dim)`, groupTableName, targetName)
	} else {
		subSql = `null`
	}
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.target_value as value,
				a.target_name as name,
				b.display_name as display_name,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				b.tips as tips,
				(
					select  drill_dim as name,
							drill_display_name as display_name,
							%v as group_list
				) as group_info,
				a.drill_dim as drill_dim
		from    bubble_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		where   a.target_name='%v'`, subSql, targetName), param.SinkTable(resTableName)).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
}

func GetBubbleGraphApiPath(req *analysis.GetPriceInsightBubbleChartRequest) string {
	if req.BaseReq.BizType == dimensions.BizType_PriceTrendSku {
		if req.IsPriceChange {
			return ApiPathSKuPriceChangeBubbleGraph
		} else {
			return ApiPathSkuBubbleGraph
		}
	} else if req.BaseReq.BizType == dimensions.BizType_PriceTrendOrder {
		return ApiPathOrderBubbleGraph
	} else {
		return ApiPathShowBubbleGraph
	}
}

func AddAvgData(resp *analysis.PriceInsightBubbleChartItem) {
	if len(resp.PointList) > 0 {
		var skuCnt int64
		for _, point := range resp.PointList {
			if point.ZAxis != nil {
				skuCnt += int64(point.ZAxis.Value)
			}
		}
		var avgDataX, avgDataY float64
		for _, point := range resp.PointList {
			if point.XAxis != nil && point.ZAxis != nil {
				avgDataX += point.XAxis.Value * (point.ZAxis.Value / float64(skuCnt))
			}
			if point.YAxis != nil && point.ZAxis != nil {
				avgDataY += point.YAxis.Value * (point.ZAxis.Value / float64(skuCnt))
			}
		}
		resp.XCoordinateAxisValue = avgDataX
		resp.XDisplayName, _ = framework_udf.GetBriefMetricDisplayValue(avgDataX, "int", "", 0)
		resp.YCoordinateAxisValue = avgDataY
		resp.YDisplayName, _ = framework_udf.GetBriefMetricDisplayValue(avgDataY, "int", "", 0)
	}
}

func AddMedianData(resp *analysis.PriceInsightBubbleChartItem) {
	var xValueList = make([]float64, 0)
	var yValueList = make([]float64, 0)
	if len(resp.PointList) > 0 {
		for _, point := range resp.PointList {
			if point.XAxis != nil {
				xValueList = append(xValueList, point.XAxis.Value)
			}
			if point.YAxis != nil {
				yValueList = append(yValueList, point.YAxis.Value)
			}
		}
	}
	if len(xValueList) > 0 {
		sort.Slice(xValueList, func(i, j int) bool {
			return xValueList[i] < xValueList[j]
		})
		if len(xValueList)%2 == 0 {
			resp.XCoordinateAxisValue = (xValueList[len(xValueList)/2] + xValueList[len(xValueList)/2-1]) / 2
		} else {
			resp.XCoordinateAxisValue = xValueList[len(xValueList)/2]
		}
		resp.XDisplayName, _ = framework_udf.GetBriefMetricDisplayValue(resp.XCoordinateAxisValue, "int", "", 0)
	}
	if len(yValueList) > 0 {
		sort.Slice(yValueList, func(i, j int) bool {
			return yValueList[i] < yValueList[j]
		})
		if len(yValueList)%2 == 0 {
			resp.YCoordinateAxisValue = (yValueList[len(yValueList)/2] + yValueList[len(yValueList)/2-1]) / 2
		} else {
			resp.YCoordinateAxisValue = yValueList[len(yValueList)/2]
		}
		resp.YDisplayName, _ = framework_udf.GetBriefMetricDisplayValue(resp.YCoordinateAxisValue, "int", "", 0)
	}
}

func AddBubbleLegend(resp *analysis.PriceInsightBubbleChartItem) {
	var legends = make([]*dimensions.EnumElement, 0)
	if len(resp.PointList) > 0 {
		for _, point := range resp.PointList {
			if point.XAxis != nil && point.XAxis.GroupInfo != nil {
				legends = append(legends, &dimensions.EnumElement{
					Code: point.XAxis.GroupInfo.Name,
					Name: point.XAxis.GroupInfo.DisplayName,
				})
			}
		}
	}
	resp.Legend = legends
}
