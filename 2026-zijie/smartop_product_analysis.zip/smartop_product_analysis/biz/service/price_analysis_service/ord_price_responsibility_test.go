package price_analysis_service

import (
	"fmt"
	"testing"
)

func TestGetResponsibilityName(t *testing.T) {
	fmt.Println(GetResponsibilityName("(一级分工)供给分工-商品价格力不足", true))
}