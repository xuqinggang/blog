package price_analysis_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/dynamic_enum"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/jinzhu/copier"
	"regexp"
	"sort"
	"strings"
)

func (d *PriceAnalysisService) GetOrderResponsibilityDistributed(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp []*analysis.TargetTrendPoint, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}

	if len(req.BaseReq.Dimensions) == 0 {
		req.BaseReq.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	if len(req.FilterDimensions) > 0 {
		req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, req.FilterDimensions...)
	}

	var hybridPrefix string
	if req.BaseReq.PriceComparisonType == dimensions.PriceComparisonType_Hybrid {
		hybridPrefix = "hybrid_"
	}

	cql, err := GetOrderResponsibilityDistributedCql(ctx, req, dimMap, consts.Empty, true)
	if err != nil {
		return
	}
	firstParams := make(map[string]interface{})
	firstParams["sub_sql_str"] = cql.Select("count(1) as out_hprice_ord_cnt", fmt.Sprintf("%sresponsibility_first as type", hybridPrefix)).GroupBy("type").Compile()
	firstParams["total_sql_str"] = cql.Select("count(1) as out_hprice_ord_cnt", "'整体' as type").Compile()

	secondParams := make(map[string]interface{})
	// 选择订单分工的范围
	responsibilityFirstList, err := dynamic_enum.GetResponsibilityFirstListWithSub(ctx)
	if err != nil {
		return nil, err
	}
	if len(responsibilityFirstList) == 0 {
		return nil, errors.New("一级订单分工枚举(包含二级分工枚举)获取失败")
	}
	cql.AddWhere(hybridPrefix+"responsibility_first", sql_parse.IN, responsibilityFirstList)
	secondParams["sub_sql_str"] = cql.Select("count(1) as out_hprice_ord_cnt",
		fmt.Sprintf("%sresponsibility_first as parent_type", hybridPrefix),
		fmt.Sprintf("%sresponsibility_second as type", hybridPrefix)).GroupBy("type", "parent_type").Compile()
	secondParams["total_sql_str"] = cql.Select("count(1) as out_hprice_ord_cnt",
		fmt.Sprintf("%sresponsibility_first as parent_type", hybridPrefix), "'整体' as type").GroupBy("parent_type").Compile()

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(firstParams, consts.OrdPriceResponsibilityDistributed, param.SinkTable("first_target_card")).SetParallel(true)
	f.ExeQueryInvokerRaw(secondParams, consts.OrdPriceResponsibilityDistributed, param.SinkTable("second_target_card")).SetParallel(true)
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("first_target_card"), param.SinkTable("first_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"type"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("second_target_card"), param.SinkTable("second_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"type", "parent_type"}))
	// 拆分改价前后数据
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				a.type as x,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order
		from    first_target_card a
		inner join
				target_meta b
		on      a.target_name=b.name order by b.display_order asc
	`), param.SinkTable("first_target_card")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	// 拆分改价前后数据
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.parent_type as parent_type,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				a.type as x,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order
		from    second_target_card a
		inner join
				target_meta b
		on      a.target_name=b.name order by b.display_order asc
	`), param.SinkTable("second_target_card")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeProduceSql(fmt.Sprintf(`
        select  name,
                value,
                display_value,
                display_name,
                x,
                tips,
                unit,
                category_name,
                display_order,
                (
                    select name,value,display_value,display_name,x,tips,unit,category_name,display_order,concat('%sresponsibility_second%s', x) as prod_tag_code
                    from second_target_card sub where sub.parent_type = first_target_card.x
                ) as children,
				concat('%sresponsibility_first%s', x) as prod_tag_code
        from    first_target_card
	`, hybridPrefix, consts.ThreeEqualsSymbols, hybridPrefix, consts.ThreeEqualsSymbols), param.SinkTable("res_data"))
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	rNameLevel := utils.If(req.ResponsibilityAll == nil, ResponsibilityNameLevel_Mid, ResponsibilityNameLevel_Simple)
	if len(resp) > 0 {
		for _, trendInfo := range resp {
			FormatResponsibilityTrendName(trendInfo.Children, rNameLevel)
			SortDistributedTrends(trendInfo.Children)
		}
		FormatResponsibilityTrendName(resp, rNameLevel)
		SortDistributedTrends(resp)
	}
	return
}

func SortDistributedTrends(trends []*analysis.TargetTrendPoint) {
	if len(trends) > 0 {
		sort.Slice(trends, func(i, j int) bool {
			if trends[i].X == "整体" {
				return true
			}
			if trends[j].X == "整体" {
				return false
			}
			return trends[i].X < trends[j].X
		})
	}
}

func GetOrderResponsibilityDistributedCql(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest, dimMap map[int64]*dao.DimensionInfo, prodTagCode string, onlyHighFlag bool) (cql *sql_parse.CQL, err error) {
	var hybridPrefix string
	if req.BaseReq.PriceComparisonType == dimensions.PriceComparisonType_Hybrid {
		hybridPrefix = "hybrid_"
	}

	cql = sql_parse.NewCQL().Select(consts.ProductID)
	cql.From(consts.OrdPricePowerTableName + " as ord_resp_distributed_sub_cql").
		AddWhereRawCond("date between ? and ?", req.BaseReq.StartDate, req.BaseReq.EndDate).
		AddWhere("order_out_is_high_price_range_tag", sql_parse.EQUAL, 1).
		AddWhere("order_out_price_power_tag_name", sql_parse.EQUAL, consts.PricePowerList).
		AddWhere("app_name", sql_parse.IN, []string{"抖音", "抖音极速版"})

	if onlyHighFlag {
		cql.AddWhere("order_out_price_power_tag_name", sql_parse.EQUAL, "高价")
	}

	// 填充条件
	// 解析所选维度过滤信息
	exprCql, err := base_struct_condition.GetPriceBaseConditionWithDims(ctx, req.BaseReq, dimMap)
	if err != nil {
		return
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}

	cql.AddWhereAndValue(exprCql.WhereClause)
	if len(exprCql.RawWhereClause) > 0 {
		cql.AddRawWhereAndValue(exprCql.RawWhereClause...)
	}

	if req.ResponsibilityAll != nil {
		cql.AddWhere(hybridPrefix+"responsibility_all", sql_parse.EQUAL, GetResponsibilityAllColumn(req.ResponsibilityAll))
	}

	if len(prodTagCode) > 0 {
		prodTagCodeArr := strings.Split(prodTagCode, consts.ThreeEqualsSymbols)
		if len(prodTagCodeArr) < 2 {
			logs.CtxError(ctx, "[GetOrderResponsibilityDistributedCql] prodTagCode参数错误, %s", prodTagCode)
			return nil, errors.New("商品画像Code参数错误")
		}
		if prodTagCodeArr[1] != "整体" {
			cql.AddWhere(prodTagCodeArr[0], sql_parse.EQUAL, prodTagCodeArr[1])
		}
	}

	return cql, nil
}

func (d *PriceAnalysisService) GetOrderResponsibilityCoreOverview(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp *analysis.GetOrderResponsibilityCoreOverviewData, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}

	//获取invoker的入参
	curr, trend, _, err := base_struct_condition.GetPriceBaseStructConditionParams(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	trend["date_type"] = req.DateType.String()
	curr["new_responsibility_all"] = utils.If(req.PriceComparisonType == dimensions.PriceComparisonType_Hybrid, "hybrid_responsibility_all", "responsibility_all")
	trend["new_responsibility_all"] = utils.If(req.PriceComparisonType == dimensions.PriceComparisonType_Hybrid, "hybrid_responsibility_all", "responsibility_all")

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.OrdPriceResponsibilityCoreOverview, param.SinkTable("target_card")).SetParallel(true)
	f.ExeQueryInvokerRaw(trend, consts.OrdPriceResponsibilityCoreOverview, param.SinkTable("trend_data")).SetParallel(true)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"time"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order,
				(
					select custom_date(time, %v) as x,
						target_name as name,
						m.display_name as display_name,
						target_value as value,
						get_display_value(target_value, m.value_type, m.value_unit, m.target_precision) as display_value
					from trend_data t
					inner join target_meta m
					on t.target_name = m.name
					where t.target_name=target_card.target_name
					order by x asc
				) as trend_data
		from target_card a
		inner join
				target_meta b
		on      a.target_name=b.name 
	`, int64(req.GetDateType())), param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDateByDateType),
	})
	var targets []*analysis.TargetCardEntity
	f.ExeView(param.SourceTable("res_data"), &targets)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAAFlowStandardCoreOverview], err=%v+", err.Error())
		return nil, err
	}
	resp = &analysis.GetOrderResponsibilityCoreOverviewData{
		ResponsibilityTotalTargets: make([]*analysis.TargetCardEntity, 0),
		ResponsibilitySameTargets:  make([]*analysis.TargetCardEntity, 0),
	}
	if len(targets) > 0 {
		subTargets := make(map[string][]*analysis.TargetCardEntity)
		for _, t := range targets {
			if strings.HasPrefix(t.Name, "sub_target_") {
				arr := strings.Split(t.Name, "_")
				if len(arr) >= 3 {
					tmp, exist := subTargets[arr[2]]
					if !exist {
						tmp = make([]*analysis.TargetCardEntity, 0)
					}
					tmp = append(tmp, t)
					subTargets[arr[2]] = tmp
				}
			} else if strings.HasSuffix(t.Name, "_1") {
				resp.ResponsibilityTotalTargets = append(resp.ResponsibilityTotalTargets, t)
			} else if strings.HasSuffix(t.Name, "_2") {
				resp.ResponsibilitySameTargets = append(resp.ResponsibilitySameTargets, t)
			}
		}
		resp.ResponsibilityTotalTargets = GetOrderResponsibilityCoreOverviewSubTargets(resp.ResponsibilityTotalTargets, subTargets)
		err = AddDiff(ctx, resp.ResponsibilityTotalTargets, int64(req.BizType))
		if err != nil {
			logs.CtxError(ctx, "[GetOrderResponsibilityCoreOverview]AddDiff Error, resp.ResponsibilityTotalTargets = %s, err = %v", convert.ToJSONString(resp.ResponsibilityTotalTargets), err)
			return nil, err
		}
		resp.ResponsibilitySameTargets = GetOrderResponsibilityCoreOverviewSubTargets(resp.ResponsibilitySameTargets, subTargets)
		err = AddDiff(ctx, resp.ResponsibilitySameTargets, int64(req.BizType))
		if err != nil {
			logs.CtxError(ctx, "[GetOrderResponsibilityCoreOverview]AddDiff Error, resp.ResponsibilitySameTargets = %s, err = %v", convert.ToJSONString(resp.ResponsibilitySameTargets), err)
			return nil, err
		}
	}
	return

}

func GetOrderResponsibilityCoreOverviewSubTargetMap(input []*analysis.TargetCardEntity, subFlagTypeTargetMap map[string]map[string][]*analysis.TargetCardEntity) []*analysis.TargetCardEntity {
	if len(input) == 0 {
		return input
	}
	for _, t := range input {
		if subMap, exist := subFlagTypeTargetMap[strings.Split(t.Name, "_")[0]]; exist {
			if subs, existS := subMap[t.DisplayName]; existS {
				t.SubTargetList = make([]*analysis.TargetBasicInfo, 0)
				analysis_service.SortTargetCardEntity(subs)
				for _, s := range subs {
					t.SubTargetList = append(t.SubTargetList, &analysis.TargetBasicInfo{
						Value:        s.Value,
						DisplayValue: s.DisplayValue,
						Name:         s.Name,
						DisplayName:  s.DisplayName,
					})
				}
			}
		}
	}
	analysis_service.SortTargetCardEntity(input)
	return input
}

func GetOrderResponsibilityCoreOverviewSubTargets(input []*analysis.TargetCardEntity, subMap map[string][]*analysis.TargetCardEntity) []*analysis.TargetCardEntity {
	if len(input) == 0 {
		return input
	}
	for _, t := range input {
		if subs, exist := subMap[strings.Split(t.Name, "_")[0]]; exist {
			t.SubTargetList = make([]*analysis.TargetBasicInfo, 0)
			analysis_service.SortTargetCardEntity(subs)
			for _, s := range subs {
				t.SubTargetList = append(t.SubTargetList, &analysis.TargetBasicInfo{
					Value:        s.Value,
					DisplayValue: s.DisplayValue,
					Name:         s.Name,
					DisplayName:  s.DisplayName,
				})
			}
		}
	}
	analysis_service.SortTargetCardEntity(input)
	return input
}

func (d *PriceAnalysisService) GetOrderResponsibilityChange(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp []*analysis.GetOrderResponsibilityChangeTargetInfo, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}
	if len(req.BaseReq.Dimensions) == 0 {
		req.BaseReq.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	if len(req.FilterDimensions) > 0 {
		req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, req.FilterDimensions...)
	}

	//获取invoker的入参
	firstParams, err := base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if req.ResponsibilityAll != nil {
		firstParams["responsibility_all"] = GetResponsibilityAllColumn(req.ResponsibilityAll)
	}
	firstParams["pre_start_date"], firstParams["pre_end_date"], firstParams["suf_start_date"], firstParams["suf_end_date"], err = time_utils.GetPrefixSuffixCustomDateByDateType(req.BaseReq.StartDate, req.BaseReq.EndDate, req.BaseReq.DateType)
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityChange]GetPrefixSuffixCustomDateByDateType Err: %v", err)
		return nil, err
	}

	secondParams := make(map[string]interface{})
	err = copier.CopyWithOption(&secondParams, firstParams, copier.Option{DeepCopy: true})
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityChange]CopyWithOption err = %v", err)
		return
	}
	// 选择订单分工的范围
	responsibilityFirstList, err := dynamic_enum.GetResponsibilityFirstListWithSub(ctx)
	if err != nil {
		return nil, err
	}
	if len(responsibilityFirstList) == 0 {
		return nil, errors.New("一级订单分工枚举(包含二级分工枚举)获取失败")
	}
	secondParams["responsibility_first_list"] = responsibilityFirstList

	var hybridPrefix string
	if req.BaseReq.PriceComparisonType == dimensions.PriceComparisonType_Hybrid {
		hybridPrefix = "hybrid_"
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(firstParams, consts.OrdPriceResponsibilityChange, param.SinkTable("first_target_card")).SetParallel(true)
	f.ExeQueryInvokerRaw(secondParams, consts.OrdPriceResponsibilityChange, param.SinkTable("second_target_card")).SetParallel(true)
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("first_target_card"), param.SinkTable("first_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"type"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("second_target_card"), param.SinkTable("second_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"type", "parent_type"}))
	// 拆分改价前后数据
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				a.type as x,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order
		from    first_target_card a
		inner join
				target_meta b
		on      a.target_name=b.name order by b.display_order asc
	`), param.SinkTable("first_target_card")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	// 拆分改价前后数据
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.parent_type as parent_type,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				a.type as x,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order
		from    second_target_card a
		inner join
				target_meta b
		on      a.target_name=b.name order by b.display_order asc
	`), param.SinkTable("second_target_card")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeProduceSql(fmt.Sprintf(`
        select  name,
                value,
                display_value,
                display_name,
                x,
                tips,
                unit,
                category_name,
                display_order,
                (
                    select 
						name,value,display_value,display_name,x,tips,unit,category_name,display_order,
						case when display_name = '高价订单数' then concat('%sresponsibility_second%s', x, '%s1') else concat('%sresponsibility_second%s', x) end as prod_tag_code
                    from second_target_card sub 
                    where sub.parent_type = first_target_card.x and sub.display_name = first_target_card.display_name 
                ) as children
        from    first_target_card
	`, hybridPrefix, consts.ThreeEqualsSymbols, consts.ThreeEqualsSymbols, hybridPrefix, consts.ThreeEqualsSymbols), param.SinkTable("target_card_new"))
	f.ExeProduceSql(fmt.Sprintf(`
		select  display_name
		from    first_target_card
		group by display_name
	`), param.SinkTable("display_name_list"))
	f.ExeProduceSql(fmt.Sprintf(`
		select  display_name as show_name,
				(
					select 
						name,value,display_value,display_name,x,tips,unit,category_name,display_order,children,
						case when display_name = '高价订单数' then concat('%sresponsibility_first%s', x, '%s1') else concat('%sresponsibility_first%s', x) end as prod_tag_code
					from target_card_new sub
					where sub.display_name = display_name_list.display_name
				) as targets
		from    display_name_list
	`, hybridPrefix, consts.ThreeEqualsSymbols, consts.ThreeEqualsSymbols, hybridPrefix, consts.ThreeEqualsSymbols), param.SinkTable("res_data"))
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	rNameLevel := utils.If(req.ResponsibilityAll == nil, ResponsibilityNameLevel_Mid, ResponsibilityNameLevel_Simple)
	if len(resp) > 0 {
		for _, ret := range resp {
			if len(ret.Targets) > 0 {
				for _, trendInfo := range ret.Targets {
					FormatResponsibilityTrendName(trendInfo.Children, rNameLevel)
					SortDistributedTrends(trendInfo.Children)
				}
				FormatResponsibilityTrendName(ret.Targets, rNameLevel)
				SortDistributedTrends(ret.Targets)
			}
		}
	}
	return
}

func (d *PriceAnalysisService) GetOrderResponsibilityTargetList(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest, needSimpleName bool) (resp *analysis.GetOrderResponsibilityCoreOverviewData, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityTargetList]获取map失败，err=%v+", err)
		return nil, err
	}

	firstListMap, err := GetOrderResponsibilityTargetList(ctx, req, false, dimMap, needSimpleName)
	if err != nil {
		return nil, err
	}
	secondListMap, err := GetOrderResponsibilityTargetList(ctx, req, true, dimMap, needSimpleName)
	if err != nil {
		return nil, err
	}

	resp = &analysis.GetOrderResponsibilityCoreOverviewData{
		ResponsibilityTotalTargets: make([]*analysis.TargetCardEntity, 0),
		ResponsibilitySameTargets:  make([]*analysis.TargetCardEntity, 0),
	}
	for _, values := range firstListMap {
		if len(values.ResponsibilitySameTargets) > 0 {
			for _, value := range values.ResponsibilitySameTargets {
				if secondInfo, exist := secondListMap[value.DisplayName]; exist {
					value.GroupInfo = &analysis.TargetCardGroupInfo{
						GroupList: secondInfo.ResponsibilitySameTargets,
					}
				}
				resp.ResponsibilitySameTargets = append(resp.ResponsibilitySameTargets, value)
			}
		}
		if len(values.ResponsibilityTotalTargets) > 0 {
			for _, value := range values.ResponsibilityTotalTargets {
				if secondInfo, exist := secondListMap[value.DisplayName]; exist {
					value.GroupInfo = &analysis.TargetCardGroupInfo{
						GroupList: secondInfo.ResponsibilityTotalTargets,
					}
				}
				resp.ResponsibilityTotalTargets = append(resp.ResponsibilityTotalTargets, value)
			}
		}
	}
	return
}

type GetOrderResponsibilityTargetParentInfo struct {
	ParentType string                       `json:"parent_type"`
	Type       string                       `json:"type"`
	Targets    []*analysis.TargetCardEntity `json:"targets"`
}

func GetOrderResponsibilityTargetList(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest, isSecond bool, dimMap map[int64]*dao.DimensionInfo, needSimpleName bool) (respMap map[string]*analysis.GetOrderResponsibilityCoreOverviewData, err error) {
	//获取invoker的入参
	curr, trend, _, err := base_struct_condition.GetPriceBaseStructConditionParams(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityTargetList]生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	trend["date_type"] = req.BaseReq.DateType.String()
	if req.ResponsibilityAll != nil {
		curr["responsibility_all"] = GetResponsibilityAllColumn(req.ResponsibilityAll)
		trend["responsibility_all"] = GetResponsibilityAllColumn(req.ResponsibilityAll)
	}

	var hybridPrefix string
	if req.BaseReq.PriceComparisonType == dimensions.PriceComparisonType_Hybrid {
		hybridPrefix = "hybrid_"
	}
	prodTagCol := "responsibility_first"
	if isSecond {
		prodTagCol = "responsibility_second"

		// 选择订单分工的范围
		responsibilityFirstList, err := dynamic_enum.GetResponsibilityFirstListWithSub(ctx)
		if err != nil {
			return nil, err
		}
		if len(responsibilityFirstList) == 0 {
			return nil, errors.New("一级订单分工枚举(包含二级分工枚举)获取失败")
		}
		curr["responsibility_first_list"] = responsibilityFirstList
		trend["responsibility_first_list"] = responsibilityFirstList
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.OrdPriceResponsibilityTargetList, param.SinkTable("target_card")).SetParallel(true)
	f.ExeQueryInvokerRaw(trend, consts.OrdPriceResponsibilityTargetList, param.SinkTable("trend_data")).SetParallel(true)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"parent_type", "type", "time"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"parent_type", "type"}))
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.parent_type as parent_type,
				a.type as type,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order,
				(
					select custom_date(time, %v) as x,
						target_name as name,
						m.display_name as display_name,
						target_value as value,
						get_display_value(target_value, m.value_type, m.value_unit, m.target_precision) as display_value
					from trend_data t
					inner join target_meta m
					on t.target_name = m.name
					where t.target_name=target_card.target_name and t.parent_type = target_card.parent_type and t.type = target_card.type
					order by x asc
				) as trend_data,
				(
					select concat('%s',a.type) as prod_tag_code
				) as extra
		from target_card a
		inner join
				target_meta b
		on      a.target_name=b.name order by b.display_order asc
	`, int64(req.BaseReq.GetDateType()), hybridPrefix+prodTagCol+consts.ThreeEqualsSymbols), param.SinkTable("target_card_new")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDateByDateType),
	})
	f.ExeProduceSql(`
		select  parent_type, type
		from target_card 
		group by parent_type, type
	`, param.SinkTable("parent_type_list"))
	f.ExeProduceSql(`
		select 	parent_type, type,
				( 
					select name,value,display_value,display_name,tips,unit,category_name,display_order,trend_data,extra
					from target_card_new tt
					where tt.parent_type = parent_type_list.parent_type and tt.type = parent_type_list.type 
				) as targets
		from parent_type_list
	`, param.SinkTable("res_data"))
	var targets []*GetOrderResponsibilityTargetParentInfo
	f.ExeView(param.SourceTable("res_data"), &targets)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityTargetList], err=%v+", err.Error())
		return nil, err
	}
	respMap = make(map[string]*analysis.GetOrderResponsibilityCoreOverviewData)
	if len(targets) > 0 {
		for _, info := range targets {
			subFlagTypeTargetMap := make(map[string]map[string][]*analysis.TargetCardEntity)
			overviewData, exist := respMap[info.ParentType]
			if !exist {
				overviewData = &analysis.GetOrderResponsibilityCoreOverviewData{
					ResponsibilityTotalTargets: make([]*analysis.TargetCardEntity, 0),
					ResponsibilitySameTargets:  make([]*analysis.TargetCardEntity, 0),
				}
			}
			if len(info.Targets) > 0 {
				for _, t := range info.Targets {
					if strings.HasPrefix(t.Name, "sub_target_") {
						arr := strings.Split(t.Name, "_")
						if len(arr) >= 3 {
							flagTmpMap, existFT := subFlagTypeTargetMap[arr[2]]
							if !existFT {
								flagTmpMap = make(map[string][]*analysis.TargetCardEntity)
							}
							typeTargets, existTT := flagTmpMap[info.Type]
							if !existTT {
								typeTargets = make([]*analysis.TargetCardEntity, 0)
							}
							typeTargets = append(typeTargets, t)
							flagTmpMap[info.Type] = typeTargets
							subFlagTypeTargetMap[arr[2]] = flagTmpMap
						}
					} else if strings.HasSuffix(t.Name, "_1") {
						t.DisplayName = info.Type
						overviewData.ResponsibilityTotalTargets = append(overviewData.ResponsibilityTotalTargets, t)
					} else if strings.HasSuffix(t.Name, "_2") {
						t.DisplayName = info.Type
						overviewData.ResponsibilitySameTargets = append(overviewData.ResponsibilitySameTargets, t)
					}
				}

				overviewData.ResponsibilityTotalTargets = GetOrderResponsibilityCoreOverviewSubTargetMap(overviewData.ResponsibilityTotalTargets, subFlagTypeTargetMap)
				err = AddDiff(ctx, overviewData.ResponsibilityTotalTargets, int64(req.BaseReq.BizType))
				if err != nil {
					logs.CtxError(ctx, "[GetOrderResponsibilityTargetList]AddDiff Error, resp.ResponsibilityTotalTargets = %s, err = %v", convert.ToJSONString(overviewData.ResponsibilityTotalTargets), err)
					return nil, err
				}
				overviewData.ResponsibilitySameTargets = GetOrderResponsibilityCoreOverviewSubTargetMap(overviewData.ResponsibilitySameTargets, subFlagTypeTargetMap)
				err = AddDiff(ctx, overviewData.ResponsibilitySameTargets, int64(req.BaseReq.BizType))
				if err != nil {
					logs.CtxError(ctx, "[GetOrderResponsibilityTargetList]AddDiff Error, resp.ResponsibilitySameTargets = %s, err = %v", convert.ToJSONString(overviewData.ResponsibilitySameTargets), err)
					return nil, err
				}
			}

			rNamelevel := utils.If(needSimpleName, ResponsibilityNameLevel_Simple, ResponsibilityNameLevel_Full)
			FormatResponsibilityName(overviewData.ResponsibilityTotalTargets, rNamelevel, true)
			FormatResponsibilityName(overviewData.ResponsibilitySameTargets, rNamelevel, true)
			respMap[GetResponsibilityName(info.ParentType, rNamelevel)] = overviewData
		}
	}
	return
}

func (d *PriceAnalysisService) GetOrderResponsibilityIndustryList(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetOrderResponsibilityIndustryListData, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityTargetList]获取map失败，err=%v+", err)
		return nil, err
	}
	resp = &analysis.GetOrderResponsibilityIndustryListData{}

	dimEnumMap, err := d.DimensionService.GetDimensionMapByIDList(ctx, []int64{convert.ToInt64(consts.FirstAVblineDim), convert.ToInt64(consts.SecondAVblineDim), convert.ToInt64(consts.SecondBVblineDim)})
	if err != nil {
		return nil, err
	}

	resp.Total, err = GetOrderResponsibilityIndustryTotal(ctx, req, dimMap)
	if err != nil {
		return
	}
	resp.IndustryList, err = GetOrderResponsibilityIndustrySubList(ctx, req, dimMap, dimEnumMap)
	if err != nil {
		return
	}
	return
}

var SupplyHpricePercentPrefix = "supply_hprice_ord_cnt_percent_"

func GetOrderResponsibilityIndustryTotal(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest, dimMap map[int64]*dao.DimensionInfo) (resp []*analysis.TargetCardEntity, err error) {
	//获取invoker的入参
	curr, _, _, err := base_struct_condition.GetPriceBaseStructConditionParams(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityTargetList]生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	curr["is_total"] = 1
	responsibilityFirstList, err := dynamic_enum.GetResponsibilityFirstList(ctx, "供给分工")
	if err != nil {
		return nil, err
	}
	if len(responsibilityFirstList) == 0 {
		return nil, errors.New("一级订单分工枚举获取失败")
	}
	curr["responsibility_first_list"] = responsibilityFirstList
	responsibilityFirstIndexMap := make(map[int]string)
	for i, str := range responsibilityFirstList {
		responsibilityFirstIndexMap[i] = str
	}

	resp, err = base_struct_condition.GetTargetListWithoutKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, ApiPath: consts.OrdPriceResponsibilityIndustryList, BizType: req.BaseReq.BizType, KeyCols: []string{},
	})
	if err != nil {
		return
	}
	if len(resp) > 0 {
		for _, targetEntity := range resp {
			if strings.Contains(targetEntity.Name, SupplyHpricePercentPrefix) {
				idxStr := strings.ReplaceAll(targetEntity.Name, SupplyHpricePercentPrefix, consts.Empty)
				if len(idxStr) > 0 {
					targetEntity.DisplayName = responsibilityFirstIndexMap[convert.ToInt(idxStr)]
				}
			}
		}
		FormatResponsibilityName(resp, ResponsibilityNameLevel_Mid, false)
		analysis_service.SortTargetCardEntity(resp)
	}
	return
}

func GetOrderResponsibilityIndustrySubList(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest, dimMap map[int64]*dao.DimensionInfo, dimEnumMap map[string]*dimensions.DimensionInfo) (resp []*analysis.GetOrderResponsibilityIndustryInfo, err error) {
	//获取invoker的入参
	curr, _, _, err := base_struct_condition.GetPriceBaseStructConditionParams(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityTargetList]生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	curr["is_total"] = 0
	// 获取子赛道维表最新可用时间
	newestDate, err := utils.GetNewestDay(ctx, dynamic_enum.DimVblineLogicTableID)
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, err
	}
	curr["newest_date"] = newestDate
	// 获取一级分工的所有枚举值
	responsibilityFirstList, err := dynamic_enum.GetResponsibilityFirstList(ctx, "供给分工")
	if err != nil {
		return nil, err
	}
	if len(responsibilityFirstList) == 0 {
		return nil, errors.New("一级订单分工枚举获取失败")
	}
	curr["responsibility_first_list"] = responsibilityFirstList
	responsibilityFirstIndexMap := make(map[int]string)
	for i, str := range responsibilityFirstList {
		responsibilityFirstIndexMap[i] = str
	}

	keyColTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, ApiPath: consts.OrdPriceResponsibilityIndustryList, BizType: req.BaseReq.BizType, KeyCols: []string{"first_vbline_name", "second_vbline_name", "type"},
	})
	if err != nil {
		return
	}

	resp = make([]*analysis.GetOrderResponsibilityIndustryInfo, 0)
	subMap := make(map[string][]*analysis.GetOrderResponsibilityIndustryInfo)
	for _, keyColTarget := range keyColTargetList {
		if len(keyColTarget.KeyColValues) != 3 {
			continue
		}
		firstVblineName := convert.ToString(keyColTarget.KeyColValues[0])
		secondVblineName := convert.ToString(keyColTarget.KeyColValues[1])
		typeStr := convert.ToString(keyColTarget.KeyColValues[2])
		if len(firstVblineName) == 0 {
			continue
		}

		var responsibilityIndustryType analysis.ResponsibilityIndustryType
		switch typeStr {
		case "A":
			responsibilityIndustryType = analysis.ResponsibilityIndustryType_A_GROUP
		case "B":
			responsibilityIndustryType = analysis.ResponsibilityIndustryType_B_GROUP
		default:
			continue
		}

		if len(keyColTarget.TargetEntity) > 0 {
			for _, targetEntity := range keyColTarget.TargetEntity {
				if strings.Contains(targetEntity.Name, SupplyHpricePercentPrefix) {
					idxStr := strings.ReplaceAll(targetEntity.Name, SupplyHpricePercentPrefix, consts.Empty)
					if len(idxStr) > 0 {
						targetEntity.DisplayName = responsibilityFirstIndexMap[convert.ToInt(idxStr)]
					}
				}
			}
		}
		analysis_service.SortTargetCardEntity(keyColTarget.TargetEntity)
		if len(secondVblineName) == 0 {
			resp = append(resp, &analysis.GetOrderResponsibilityIndustryInfo{
				Name:    firstVblineName,
				Type:    responsibilityIndustryType,
				Targets: keyColTarget.TargetEntity,
			})
		} else {
			subList := subMap[firstVblineName]
			if len(subList) == 0 {
				subList = make([]*analysis.GetOrderResponsibilityIndustryInfo, 0)
			}
			subList = append(subList, &analysis.GetOrderResponsibilityIndustryInfo{
				Name:    secondVblineName,
				Type:    responsibilityIndustryType,
				Targets: keyColTarget.TargetEntity,
			})
			subMap[firstVblineName] = subList
		}
	}

	if len(resp) > 0 {
		for _, info := range resp {
			FormatResponsibilityName(info.Targets, ResponsibilityNameLevel_Mid, false)
			if subList, exist := subMap[info.Name]; exist {
				for _, subInfo := range subList {
					FormatResponsibilityName(subInfo.Targets, ResponsibilityNameLevel_Mid, false)
				}
				sort.Slice(subList, func(i, j int) bool {
					return subList[i].Name < subList[j].Name
				})
				info.Children = subList
			}
		}
		sort.Slice(resp, func(i, j int) bool {
			return resp[i].Name < resp[j].Name
		})
	}

	return
}

func (d *PriceAnalysisService) GetOrderResponsibilityBubbleChart(ctx context.Context, req *analysis.GetOrderResponsibilityBubbleChartRequest) (resp *analysis.PriceInsightBubbleChartItem, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityBubbleChart]获取map失败，err=%v+", err)
		return nil, err
	}

	dimInfo := dimMap[convert.ToInt64(req.DimId)]
	if dimInfo == nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityBubbleChart]未查询到维度信息,id=%d", req.DimId)
		return nil, errors.New("未查询到维度信息")
	}

	dimEnumsInfo, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(req.DimId))
	if err != nil {
		return
	}

	enumCodeNameMap := make(map[string]string)
	if dimEnumsInfo != nil && len(dimEnumsInfo.Values) > 0 {
		if req.BaseReq.Dimensions == nil {
			req.BaseReq.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		}
		req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
			Id:               convert.ToString(dimInfo.ID),
			Name:             dimInfo.ShowName,
			AttrType:         dimEnumsInfo.DimensionCategory,
			SelectedOperator: base.OperatorType_IN,
			SelectedValues:   dimEnumsInfo.Values,
		})
		for _, enum := range dimEnumsInfo.Values {
			enumCodeNameMap[enum.Code] = enum.Name
		}
	}

	//获取invoker的入参
	curr, _, _, err := base_struct_condition.GetPriceBaseStructConditionParams(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetOrderResponsibilityBubbleChart]生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	curr["sub_dimension"], err = d.DimensionService.GetDimColumnExpressStr(ctx, convert.ToInt64(req.DimId))
	if err != nil {
		return nil, err
	}
	curr["base_dimension"] = dimInfo.DimColumn
	curr["new_responsibility_all"] = utils.If(req.BaseReq.PriceComparisonType == dimensions.PriceComparisonType_Hybrid, "hybrid_responsibility_all", "responsibility_all")

	keyColTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, ApiPath: consts.OrdPriceResponsibilityBubbleChart, BizType: req.BaseReq.BizType, KeyCols: []string{dimInfo.DimColumn},
	})
	if err != nil {
		return
	}

	var allHPriceOrderRate float64
	for _, info := range keyColTargetList {
		if len(info.TargetEntity) > 0 {
			for _, t := range info.TargetEntity {
				if t.Name == "out_ord_hprice_rate" {
					allHPriceOrderRate += t.Value
				}
			}
		}
	}
	avgHPriceOrderRate := allHPriceOrderRate / convert.ToFloat64(len(keyColTargetList))

	resp = &analysis.PriceInsightBubbleChartItem{
		PointList: make([]*analysis.AxisPoint, 0),
		Legend: []*dimensions.EnumElement{
			{
				Code: convert.ToString(true), Name: "站外高价率高于均值",
			},
			{
				Code: convert.ToString(false), Name: "站外高价率低于均值",
			},
		},
	}
	for _, info := range keyColTargetList {
		if len(info.TargetEntity) > 0 && len(info.KeyColValues) > 0 {
			point := &analysis.AxisPoint{
				ShowName: enumCodeNameMap[convert.ToString(info.KeyColValues[0])],
				ProdTagCode: convert.ToString(info.KeyColValues[0]),
			}
			for _, t := range info.TargetEntity {
				switch t.Name {
				case "out_ord_hprice_rate":
					point.LegendCode = convert.ToString(t.Value > avgHPriceOrderRate)
				case "supply_out_hprice_ord_rate":
					point.XAxis = t
				case "out_same_price_rate":
					point.YAxis = t
				case "out_hprice_ord_cnt":
					point.ZAxis = t
				default:
					continue
				}
			}
			resp.PointList = append(resp.PointList, point)
		}
	}
	AddAvgData(resp)
	return
}

func GetResponsibilityAllColumn(rType *analysis.ResponsibilityAllType) string {
	if rType != nil && *rType == analysis.ResponsibilityAllType_FLOW {
		return "流量分工"
	}
	return "供给分工"
}

var compileRegex = regexp.MustCompile("^\\([一|二]级分工\\)(供给分工|流量分工)-(.*)")

func FormatResponsibilityName(targets []*analysis.TargetCardEntity, level ResponsibilityNameLevel, isOrderName bool) {
	if len(targets) > 0 {
		for _, t := range targets {
			t.DisplayName = GetResponsibilityName(t.DisplayName, level)
		}
		if isOrderName {
			sort.Slice(targets, func(i, j int) bool {
				// 按照分工名称排序
				return targets[i].DisplayName < targets[j].DisplayName
			})
		} else {
			sort.Slice(targets, func(i, j int) bool {
				// 按照分工名称排序
				return targets[i].DisplayOrder < targets[j].DisplayOrder
			})
		}
	}
}

func FormatResponsibilityTrendName(targets []*analysis.TargetTrendPoint, level ResponsibilityNameLevel) {
	if len(targets) > 0 {
		for _, t := range targets {
			t.X = GetResponsibilityName(t.X, level)
		}
	}
}

type ResponsibilityNameLevel int64

const (
	ResponsibilityNameLevel_Full   ResponsibilityNameLevel = 1
	ResponsibilityNameLevel_Mid    ResponsibilityNameLevel = 2
	ResponsibilityNameLevel_Simple ResponsibilityNameLevel = 3
)

func GetResponsibilityName(name string, level ResponsibilityNameLevel) string {
	if level == ResponsibilityNameLevel_Full {
		return name
	}

	matchArr := compileRegex.FindStringSubmatch(name)
	fmt.Println(convert.ToJSONString(matchArr))
	if len(matchArr) <= 2 {
		return name
	}
	if level == ResponsibilityNameLevel_Mid {
		return fmt.Sprintf("%s-%s", matchArr[1], matchArr[2])
	}

	return matchArr[2]
}
