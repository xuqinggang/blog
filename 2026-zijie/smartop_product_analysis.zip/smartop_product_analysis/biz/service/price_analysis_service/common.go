package price_analysis_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"context"
	"strconv"
)

type IPriceAnalysisService interface {
	GetPriceInsightCoreOverview(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp []*analysis.TargetCardEntity, err error)
	GetPriceInsightHierarchicalTrend(ctx context.Context, req *analysis.GetPriceInsightHierarchicalTrendRequest) (resp *analysis.PriceInsightHierarchicalTrendItem, err error)
	GetPriceInsightMeta(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp *analysis.GetPriceInsightMetaItem, err error)
	GetMultipleRatioTable(ctx context.Context, req *analysis.GetMultipleRatioTableRequest) (resp []*analysis.MultipleRatioTableItem, err error)
	GetPriceInsightBubbleChart(ctx context.Context, req *analysis.GetPriceInsightBubbleChartRequest) (resp *analysis.PriceInsightBubbleChartItem, err error)
	GetOrderResponsibilityDistributed(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp []*analysis.TargetTrendPoint, err error)
	GetOrderResponsibilityCoreOverview(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp *analysis.GetOrderResponsibilityCoreOverviewData, err error)
	GetOrderResponsibilityChange(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp []*analysis.GetOrderResponsibilityChangeTargetInfo, err error)
	GetOrderResponsibilityTargetList(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest, needSimpleName bool) (resp *analysis.GetOrderResponsibilityCoreOverviewData, err error)
	GetOrderResponsibilityIndustryList(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetOrderResponsibilityIndustryListData, err error)
	GetOrderResponsibilityBubbleChart(ctx context.Context, req *analysis.GetOrderResponsibilityBubbleChartRequest) (resp *analysis.PriceInsightBubbleChartItem, err error)
}

type PriceAnalysisService struct {
	DimensionListDao dao.IDimensionListDao
	DimensionEnumDao dao.IDimensionEnumDao
	AttributeDao     dao.IAttributeDao
	DimensionService dimension_service.IDimensionService
}

const (
	effectModuleDistribution            = "分层趋势"
	effectModulePriceChangeDistribution = "改价分层趋势"
	effectModuleMultiRatioTable         = "倍比表格"
	effectModuleBubbleGraph             = "气泡图"
	effectModulePriceChangeBubbleGraph  = "改价气泡图"
)

const (
	ApiPathSKUPriceTargetCard    = "7386538801025336346"
	ApiPathOrderPriceTargetCard  = "7386641885655335974"
	ApiPathShowPriceTargetCard   = "7386646894425932851"
	ApiPathPriceChangeTargetCard = "7395868835749889074"

	ApiPathSkuPriceTrend       = "7386641885655204902"
	ApiPathShowPriceTrend      = "7386642366477698074"
	ApiPathOrderPriceTrend     = "7389965776305783817"
	ApiPathSkuPriceChangeTrend = "7387461596945056777"

	ApiPathSkuMultipleRatioTable   = "7386939901209478154"
	ApiPathOrderMultipleRatioTable = "7390570179366781961"
	ApiPathShowMultipleRatioTable  = "7390566025038808090"

	ApiPathSkuBubbleGraph            = "7386943757352027187"
	ApiPathOrderBubbleGraph          = "7391697837593035814"
	ApiPathShowBubbleGraph           = "7391690267268498458"
	ApiPathSKuPriceChangeBubbleGraph = "7391694984627405862"
)

var DimCodeNameMap = map[string]string{
	"90006": "price_tag",         // SKU站内站外比价分层
	"90007": "price_tag",         // 订单站内站外比价分层
	"90008": "price_tag",         // 曝光站内站外比价分层
	"10076": "order_source",      // 订单来源场域
	"10077": "channel",           // 曝光场域
	"90002": "h2l_pv_type",       // 高价改非高价流量效果分层
	"90001": "price_change_type", // 改价类型分层
}

type PriceInsightMetaAll struct {
	SkuPrice   *PriceInsightMeta `json:"sku_price"`
	OrderPrice *PriceInsightMeta `json:"order_price"`
	ShowPrice  *PriceInsightMeta `json:"show_price"`
}

type PriceInsightMeta struct {
	PriceTrendMeta         *HierarchicalMeta                `json:"price_trend_meta"`
	PriceChangeTrendMeta   *HierarchicalMeta                `json:"price_change_trend_meta"`
	MultipleRatioTableMeta *analysis.MultipleRatioTableMeta `json:"multiple_ratio_table_meta"`
	PriceBubbleMeta        *BubbleChartMeta                 `json:"price_bubble_meta"`
	PriceChangeBubbleMeta  *BubbleChartMeta                 `json:"price_change_bubble_meta"`
}

type HierarchicalMeta struct {
	Targets               []*analysis.TargetBasicInfo              `json:"targets"`
	SourceField           int64                                    `json:"source_field"`
	DrillDimensions       []int64                                  `json:"drill_dimensions"`
	DefaultGroupDimension []*dimensions.SelectedMultiDimensionInfo `json:"default_group_dimension"`
}

type BubbleChartMeta struct {
	Targets               []*analysis.TargetBasicInfo              `json:"targets"`
	AnalysisDimensions    []int64                                  `json:"analysis_dimensions"`
	DrillDimensions       []int64                                  `json:"drill_dimensions"`
	DefaultGroupDimension []*dimensions.SelectedMultiDimensionInfo `json:"default_group_dimension"`
}

func (p *PriceAnalysisService) GetPriceInsightMeta(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp *analysis.GetPriceInsightMetaItem, err error) {
	meta, err := GetPriceAnalysisMetaByTCC(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "获取价格力趋势TCC配置失败, "+err.Error())
		return nil, err
	}
	var effectModules []string
	if req.BizType == dimensions.BizType_PriceTrendSku {
		effectModules = []string{effectModuleDistribution, effectModulePriceChangeDistribution, effectModuleMultiRatioTable, effectModuleBubbleGraph, effectModulePriceChangeBubbleGraph}
	} else {
		effectModules = []string{effectModuleDistribution, effectModuleMultiRatioTable, effectModuleBubbleGraph}
	}
	targetMap, err := dao.GetEffectModuleTargetsMap(ctx, int64(req.BizType), effectModules)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceInsightMeta]读取指标元信息失败, "+err.Error())
		return nil, err
	}
	// 添加指标元信息
	meta.PriceTrendMeta.Targets = getTargetMeta(effectModuleDistribution, targetMap)
	meta.MultipleRatioTableMeta.Targets = getTargetMeta(effectModuleMultiRatioTable, targetMap)
	meta.PriceBubbleMeta.Targets = getTargetMeta(effectModuleBubbleGraph, targetMap)
	if req.BizType == dimensions.BizType_PriceTrendSku {
		meta.PriceChangeTrendMeta.Targets = getTargetMeta(effectModulePriceChangeDistribution, targetMap)
		meta.PriceChangeBubbleMeta.Targets = getTargetMeta(effectModulePriceChangeBubbleGraph, targetMap)
	}
	// 把指标元信息打包到meta里面
	idList := getIdListFromMeta(meta)
	object := &dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao), DimensionEnumDao: new(dao.DimensionEnumDao)}
	dimMap, err := object.GetDimensionMapByIDList(ctx, idList)
	var priceChangeDims []*dimensions.DimensionInfo
	dims, err := object.GetDimensionList(ctx, req.BizType)
	if req.BizType == dimensions.BizType_PriceTrendSku {
		priceChangeDims, err = object.GetDimensionList(ctx, req.BizType)
		if err != nil {
			return nil, err
		}
	}
	if err != nil {
		logs.CtxError(ctx, "根据维度ID查询维度数据失败,"+err.Error())
		return nil, err
	}
	return PackMetaInfo(dimMap, meta, dims, priceChangeDims), nil
}

func getTargetMeta(moduleName string, targetMap map[string][]*dao.TargetMetaInfo) []*analysis.TargetBasicInfo {
	if targetList, ok := targetMap[moduleName]; ok {
		var targetBasic = make([]*analysis.TargetBasicInfo, 0)
		for _, target := range targetList {
			targetBasic = append(targetBasic, &analysis.TargetBasicInfo{
				Name:        target.Name,
				DisplayName: target.DisplayName,
				Tips:        target.Tips,
			})
		}
		return targetBasic
	}
	return make([]*analysis.TargetBasicInfo, 0)
}

func GetPriceAnalysisMetaByTCC(ctx context.Context, bizType dimensions.BizType) (*PriceInsightMeta, error) {
	var meta = &PriceInsightMetaAll{}
	if err := tcc.GetTccConfWithUnmarshalTarget(ctx, "price_trend_analysis_meta", &meta); err != nil {
		logs.CtxError(ctx, "GetPriceChangePowerMap Error, price_change_power_mapping")
		return nil, errors.WithMessage(err, "GetPriceAnalysisMetaByTCC failed")
	}
	switch bizType {
	case dimensions.BizType_PriceTrendSku:
		return meta.SkuPrice, nil
	case dimensions.BizType_PriceTrendOrder:
		return meta.OrderPrice, nil
	case dimensions.BizType_PriceTrendShow:
		return meta.ShowPrice, nil
	default:
		return nil, errors.New("输入的业务线没有对应的TCC配置")
	}
}

func getIdListFromMeta(meta *PriceInsightMeta) []int64 {
	var idList = make([]int64, 0)
	if meta != nil {
		if meta.PriceTrendMeta != nil {
			idList = append(idList, meta.PriceTrendMeta.SourceField)
			idList = append(idList, meta.PriceTrendMeta.DrillDimensions...)
		}
		if meta.PriceChangeTrendMeta != nil {
			idList = append(idList, meta.PriceChangeTrendMeta.SourceField)
			idList = append(idList, meta.PriceChangeTrendMeta.DrillDimensions...)
		}
		if meta.PriceBubbleMeta != nil {
			idList = append(idList, meta.PriceBubbleMeta.DrillDimensions...)
			idList = append(idList, meta.PriceBubbleMeta.AnalysisDimensions...)
		}
		if meta.PriceChangeBubbleMeta != nil {
			idList = append(idList, meta.PriceChangeBubbleMeta.DrillDimensions...)
			idList = append(idList, meta.PriceChangeBubbleMeta.DrillDimensions...)
		}
	}
	return idList
}

func PackMetaInfo(dimMap map[string]*dimensions.DimensionInfo, meta *PriceInsightMeta, dims, priceChangeDims []*dimensions.DimensionInfo) *analysis.GetPriceInsightMetaItem {
	var res = &analysis.GetPriceInsightMetaItem{}
	if meta != nil {
		res.MultipleRatioTableMeta = meta.MultipleRatioTableMeta
		if meta.PriceTrendMeta != nil {
			res.PriceTrendMeta = &analysis.HierarchicalTrendMeta{
				Targets:               meta.PriceTrendMeta.Targets,
				DefaultGroupDimension: meta.PriceTrendMeta.DefaultGroupDimension,
			}
			if dim, ok := dimMap[strconv.Itoa(int(meta.PriceTrendMeta.SourceField))]; ok {
				res.PriceTrendMeta.SourceField = dim
			}
			var drillDims = make([]*dimensions.DimensionInfo, 0)
			for _, dimId := range meta.PriceTrendMeta.DrillDimensions {
				if dim, ok := dimMap[strconv.Itoa(int(dimId))]; ok {
					drillDims = append(drillDims, dim)
				}
			}
			res.PriceTrendMeta.DrillDimensions = drillDims
		}
		if meta.PriceChangeTrendMeta != nil {
			res.PriceChangeTrendMeta = &analysis.HierarchicalTrendMeta{
				Targets:               meta.PriceChangeTrendMeta.Targets,
				DefaultGroupDimension: meta.PriceChangeTrendMeta.DefaultGroupDimension,
			}
			// 改价表不拆订单场域
			res.PriceChangeTrendMeta.SourceField = nil
			var drillDims = make([]*dimensions.DimensionInfo, 0)
			for _, dimId := range meta.PriceChangeTrendMeta.DrillDimensions {
				if dim, ok := dimMap[strconv.Itoa(int(dimId))]; ok {
					drillDims = append(drillDims, dim)
				}
			}
			res.PriceChangeTrendMeta.DrillDimensions = drillDims
		}
		if meta.PriceBubbleMeta != nil {
			res.PriceBubbleMeta = &analysis.GetPriceInsightBubbleChartMeta{
				Targets:               meta.PriceBubbleMeta.Targets,
				DefaultGroupDimension: meta.PriceBubbleMeta.DefaultGroupDimension,
			}
			var drillDims = make([]*dimensions.DimensionInfo, 0)
			for _, dimId := range meta.PriceBubbleMeta.DrillDimensions {
				if dim, ok := dimMap[strconv.Itoa(int(dimId))]; ok {
					drillDims = append(drillDims, dim)
				}
			}
			for _, dim := range dims {
				if dim.IsMultiDim {
					drillDims = append(drillDims, dim)
				}
			}
			var analysisDims = make([]*dimensions.DimensionInfo, 0)
			for _, dimId := range meta.PriceBubbleMeta.AnalysisDimensions {
				if dim, ok := dimMap[strconv.Itoa(int(dimId))]; ok {
					analysisDims = append(analysisDims, dim)
				}
			}
			res.PriceBubbleMeta.DrillDimensions = drillDims
			res.PriceBubbleMeta.AnalysisDimensions = analysisDims
		}
		if meta.PriceChangeBubbleMeta != nil {
			res.PriceChangeBubbleMeta = &analysis.GetPriceInsightBubbleChartMeta{
				Targets:               meta.PriceChangeBubbleMeta.Targets,
				DefaultGroupDimension: meta.PriceChangeBubbleMeta.DefaultGroupDimension,
			}
			var drillDims = make([]*dimensions.DimensionInfo, 0)
			for _, dimId := range meta.PriceChangeBubbleMeta.DrillDimensions {
				if dim, ok := dimMap[strconv.Itoa(int(dimId))]; ok {
					drillDims = append(drillDims, dim)
				}
			}
			if len(priceChangeDims) > 0 {
				for _, dim := range priceChangeDims {
					if dim.IsMultiDim {
						drillDims = append(drillDims, dim)
					}
				}
			}
			var analysisDims = make([]*dimensions.DimensionInfo, 0)
			for _, dimId := range meta.PriceChangeBubbleMeta.AnalysisDimensions {
				if dim, ok := dimMap[strconv.Itoa(int(dimId))]; ok {
					analysisDims = append(analysisDims, dim)
				}
			}
			res.PriceChangeBubbleMeta.DrillDimensions = drillDims
			res.PriceChangeBubbleMeta.AnalysisDimensions = analysisDims
		}
	}
	return res
}
