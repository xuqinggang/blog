package price_analysis_service

import (
	"code.byted.org/aweme-go/hstruct/cast"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"context"
	"fmt"
	"github.com/bytedance/sonic"
	"github.com/shopspring/decimal"
	"sort"
	"strconv"
	"strings"
	"time"
)

func (p *PriceAnalysisService) GetPriceInsightHierarchicalTrend(ctx context.Context, req *analysis.GetPriceInsightHierarchicalTrendRequest) (
	resp *analysis.PriceInsightHierarchicalTrendItem, err error) {
	dimMap, err := new(dao.DimensionListDao).GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceInsightCoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}
	if req.SourceField != nil && req.SourceField.Id != "" {
		if req.BaseReq.Dimensions != nil {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, req.SourceField)
		} else {
			req.BaseReq.Dimensions = []*dimensions.SelectedDimensionInfo{req.SourceField}
		}
	}
	// 多维分析的枚举值需要作为筛选条件，这里添加到筛选参数内
	if req.GroupDimension != nil {
		if req.BaseReq.Dimensions == nil {
			req.BaseReq.Dimensions = []*dimensions.SelectedDimensionInfo{req.GroupDimension}
		} else {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, req.GroupDimension)
		}
	}
	trend, err := base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Trend)
	if err != nil {
		return
	}
	// 添加额外的参数
	trend, err = AddBaseParams(ctx, req, trend)
	if err != nil {
		return
	}
	if req.IsPriceChange {
		priceChangeWhereStr, err := base_struct_condition.GetOutXdPriceChangeWhereStr(ctx, biz_info.GetCtxBizInfoPriceAAInOutType(ctx))
		if err != nil {
			logs.CtxError(ctx, "[GetPriceChangeFlowStandardSubSQL]GetOutXdPriceChangeWhereStr Err, %v", err)
			return nil, err
		}
		trend["price_change_filter"] = priceChangeWhereStr
	}

	var effectModule []string
	if req.IsPriceChange {
		effectModule = []string{effectModulePriceChangeDistribution}
	} else {
		effectModule = []string{effectModuleDistribution}
	}
	apiPath := GetPriceTrendApiPath(req)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst(effectModule)}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryInvokerRaw(trend, apiPath, param.SinkTable("overall_data")).SetParallel(true).SetMaxParallelNum(6)
	// 大盘数据处理
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("overall_data"), param.SinkTable("overall_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"time"}))
	f.ExeProduceSql(fmt.Sprintf(`select  
				time,
				custom_date(time, %v) as x,
				target_name as name,
				m.display_name as display_name,
				target_value as value,
				target_name as dim_name,
				m.display_name as dim_display_name,
				1 as percent,
				get_display_value(target_value, m.value_type, m.value_unit, m.target_precision) as display_value
		from    overall_data t
		inner join target_meta m
		on t.target_name = m.name
		order by x asc`, int(req.BaseReq.GetDateType())), param.SinkTable("overall_data_all")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDateByDateType),
	})
	// 多维分析处理
	if req.GroupDimension != nil {
		trend, err = AddGroupDim(ctx, req.GroupDimension, trend)
		if err != nil {
			return
		}
		f.ExeQueryInvokerRaw(trend, apiPath, param.SinkTable("group_data")).SetParallel(true).SetMaxParallelNum(6)
		f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("group_data"), param.SinkTable("group_data")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").SetDimColumns([]string{"time", "group_dim"}))
		f.ExeProduceCustom([]param.Source{param.SourceTable("group_data"), param.SourceConst(req.GroupDimension.Id), param.SourceConst("group_dim")}, GetEnumDisplayNameTable, param.SinkTable("group_dim_code_name"))
		f.ExeProduceSql(`
		select  a.*,
				case when b.name='' then a.group_dim else b.name end as group_display_name
		from    group_data a
		left join
				group_dim_code_name b
		on      a.group_dim=b.code`, param.SinkTable("group_data"))
		f.ExeProduceSql(fmt.Sprintf(`select  custom_date(time, %v) as x,
				target_name as name,
				m.display_name as display_name,
				target_value as value,
				group_dim as dim_name,
				group_display_name as dim_display_name,
				target_value/(select value from overall_data_all a where a.name = group_data.target_name and a.time = group_data.time) as percent,
				get_display_value(target_value, m.value_type, m.value_unit, m.target_precision) as display_value
		from    group_data t
		inner join target_meta m
		on t.target_name = m.name
		order by x asc`, int(req.BaseReq.GetDateType())), param.SinkTable("group_data")).SetUdfs(map[string]*onetable.UdfFunction{
			"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
			"custom_date":       onetable.NormalFunc(framework_udf.CustomDateByDateType),
		})
	}
	trend, err = AddDrillDim(req, trend)
	if err != nil {
		return
	}
	// 下钻维度时不能加多维分析
	delete(trend, "group_dim")
	// 下钻维度
	f.ExeQueryInvokerRaw(trend, apiPath, param.SinkTable("drill_data")).SetParallel(true).SetMaxParallelNum(6)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("drill_data"), param.SinkTable("drill_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"time", "drill_dim"}))
	f.ExeProduceCustom([]param.Source{param.SourceTable("drill_data"), param.SourceConst(req.DrillDimension.Id), param.SourceConst("drill_dim")}, GetEnumDisplayNameTable, param.SinkTable("drill_dim_code_name"))
	f.ExeProduceSql(`
		select  a.*,
				case when b.name='' then a.drill_dim else b.name end as drill_display_name
		from    drill_data a
		left join
				drill_dim_code_name b
		on      a.drill_dim=b.code`, param.SinkTable("drill_data"))
	f.ExeProduceSql(fmt.Sprintf(`select  custom_date(time, %v) as x,
				target_name as name,
				m.display_name as display_name,
				target_value as value,
				drill_dim as dim_name,
				drill_display_name as dim_display_name,
				target_value/(select value from overall_data_all a where a.name = drill_data.target_name and a.time = drill_data.time) as percent,
				get_display_value(target_value, m.value_type, m.value_unit, m.target_precision) as display_value
		from    drill_data t
		inner join target_meta m
		on t.target_name = m.name
		order by x asc`, int(req.BaseReq.GetDateType())), param.SinkTable("drill_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDateByDateType),
	})
	// 加工占比指标
	f.ExeProduceSql(`
		select * from drill_data
		union all
		select  a.x as x,
				concat(a.name, '_percent') as name,
				concat(a.display_name, '占比') as display_name,
				b.value/a.value as value,
				b.dim_name as dim_name,
				b.dim_display_name as dim_display_name,
				get_display_value(b.value/a.value, 'double', '%', 2) as display_value,
				b.value/a.value as percent
		from    overall_data_all a
		inner   join
				drill_data b
		on      a.x=b.x
		and     a.name=b.name
	`, param.SinkTable("drill_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})

	var overallTrend, drillTrend = make([]*analysis.TargetTrendPoint, 0), make([]*analysis.TargetTrendPoint, 0)
	var groupTrend []*analysis.TargetTrendPoint
	f.ExeView(param.SourceTable("overall_data_all"), &overallTrend)
	f.ExeView(param.SourceTable("drill_data"), &drillTrend)
	if req.GroupDimension != nil {
		groupTrend = make([]*analysis.TargetTrendPoint, 0)
		f.ExeView(param.SourceTable("group_data"), &groupTrend)
	}
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	resp = &analysis.PriceInsightHierarchicalTrendItem{
		TargetTrend: packPriceTrendData(overallTrend, drillTrend, groupTrend, req.TargetName),
	}
	// 添加prodTagCode
	AddTargetCode(req, resp)
	// 加工图例
	mainLegends, subLegends := GetLegends(resp.TargetTrend)
	resp.MainLegend = mainLegends
	resp.SubLegend = subLegends
	return resp, nil
}

func GetEnumDisplayNameTable(ctx context.Context, groupTable *onetable.Table, dimensionId, dimColumnName string) (*onetable.Table, error) {
	var enumCodeList = make([]string, 0)
	var enumCodeSet = make(map[string]bool)
	for _, row := range groupTable.ToRawMap() {
		if id, ok := row[dimColumnName]; ok {
			enumCodeSet[cast.ToString(id)] = true
		}
	}
	for key := range enumCodeSet {
		enumCodeList = append(enumCodeList, key)
	}
	resTableMap := make([]map[string]interface{}, 0)
	// 订单来源场域 玉哲的处理逻辑并没有做底表英文名映射，这里需要处理一下
	if dimensionId == "10076" {
		for _, enum := range enumCodeList {
			var name string
			switch enum {
			case "guess":
				name = "双端猜你喜欢（不限制货架）"
			case "live":
				name = "双端直播体裁"
			case "search":
				name = "双端搜索整体（不限制货架）"
			case "video":
				name = "双端短视频体裁"
			case "tens_subsidy":
				name = "双端超值购"
			default:
				name = enum
			}
			resTableMap = append(resTableMap, map[string]interface{}{
				"code": enum,
				"name": name,
			})
		}
	} else {
		object := &dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao), DimensionEnumDao: new(dao.DimensionEnumDao)}
		enumInfo, err := object.GetDimensionPageEnumList(ctx, &dimensions.GetDimensionPageEnumListRequest{
			DimensionId:  dimensionId,
			EnumCodeList: enumCodeList,
		})
		// 添加一个肯定匹配不上的mock数据行，防止右表为空关联不上
		resTableMap = append(resTableMap, map[string]interface{}{"code": -1234567890, "name": "zjr_mock"})
		if err != nil {
			logs.CtxWarn(ctx, "获取到的映射信息为空，请检查入参的底表是否为空,err:"+err.Error())
			return onetable.NewTable(resTableMap), nil
		}
		if enumInfo != nil {
			for _, element := range enumInfo.EnumList {
				t := map[string]interface{}{
					"code": element.Code,
					"name": element.Name,
				}
				resTableMap = append(resTableMap, t)
			}
		} else {
			return onetable.NewTable(resTableMap), nil
		}
	}
	return onetable.NewTable(resTableMap), nil
}

func AddBaseParams(ctx context.Context, req *analysis.GetPriceInsightHierarchicalTrendRequest, params map[string]interface{}) (map[string]interface{}, error) {
	//var err error
	//params["order_source_channel_selects"], params["order_source_channel_array_join"], err = base_struct_condition.GetOrderSourceChannelSelect(ctx, false)
	//if err != nil {
	//	return nil, err
	//}
	params["main_target"] = req.TargetName
	// 是否广告流量
	if req.IsAd != nil {
		if *req.IsAd {
			params["is_ad"] = 1
		} else {
			params["is_ad"] = 0
		}
	}
	return params, nil
}

func AddDrillDim(req *analysis.GetPriceInsightHierarchicalTrendRequest, params map[string]interface{}) (map[string]interface{}, error) {
	if req.DrillDimension == nil {
		params["drill_dim"] = "price_tag"
	} else if _, ok := DimCodeNameMap[req.DrillDimension.Id]; ok {
		params["drill_dim"] = DimCodeNameMap[req.DrillDimension.Id]
	} else {
		return nil, errors.New("未匹配到输入的下钻维度")
	}
	return params, nil
}

func AddGroupDim(ctx context.Context, groupInfo *dimensions.SelectedDimensionInfo, params map[string]interface{}) (map[string]interface{}, error) {
	//var err error
	if groupInfo != nil {
		//params["group_filter_param"], err = utils.GenerateFilterParam([]*dimensions.SelectedDimensionInfo{groupInfo})
		//if err != nil {
		//	logs.CtxWarn(ctx, err.Error())
		//	return nil, err
		//}
		id, err := strconv.ParseInt(groupInfo.Id, 10, 64)
		if err != nil {
			return nil, errors.WithMessage(err, "维度id类型转化失败")
		}
		dimC, err := (&dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao)}).GetDimColumnExpressStr(ctx, id)
		if err != nil {
			return nil, err
		}
		params["group_dim"] = dimC
	}
	return params, nil
}

func GetPriceTrendApiPath(req *analysis.GetPriceInsightHierarchicalTrendRequest) string {
	if req.BaseReq.BizType == dimensions.BizType_PriceTrendSku {
		if req.IsPriceChange {
			return ApiPathSkuPriceChangeTrend
		} else {
			return ApiPathSkuPriceTrend
		}
	} else if req.BaseReq.BizType == dimensions.BizType_PriceTrendOrder {
		return ApiPathOrderPriceTrend
	} else {
		return ApiPathShowPriceTrend
	}
}

func GetLegends(trendList []*analysis.TargetTrendPoint) ([]*dimensions.EnumElement, []*dimensions.EnumElement) {
	// 加工图例
	var mainLegends = make([]*dimensions.EnumElement, 0)
	var subLegends = make([]*dimensions.EnumElement, 0)
	if len(trendList) > 0 {
		mainLegends = append(mainLegends, &dimensions.EnumElement{
			Code: trendList[0].Name,
			Name: trendList[0].DisplayName,
			LegendExtra: &dimensions.LegendExtraInfo{
				IsMain:   true,
				ShowType: dimensions.GraphType_BarChart,
			},
		})
		for _, child := range trendList[0].Children {
			mainLegends = append(mainLegends, &dimensions.EnumElement{
				Code: child.DimName,
				Name: child.DimDisplayName,
				LegendExtra: &dimensions.LegendExtraInfo{
					IsMain:   false,
					ShowType: dimensions.GraphType_LineChart,
				},
			})
		}
		if trendList[0].Children != nil && len(trendList[0].Children) > 0 {
			for _, subTarget := range trendList[0].Children[0].SubTargetList {
				var showType dimensions.GraphType
				if strings.HasSuffix(subTarget.Name, "_percent") {
					showType = dimensions.GraphType_LineChart
				} else {
					showType = dimensions.GraphType_BarChart
				}
				subLegends = append(subLegends, &dimensions.EnumElement{
					Code: subTarget.Name,
					Name: subTarget.DisplayName,
					LegendExtra: &dimensions.LegendExtraInfo{
						IsMain:   false,
						ShowType: showType,
					},
				})
			}
		}
	}
	return mainLegends, subLegends
}

// PackSubList 把子列表的指标打包到嵌套结构中, 效果等同于下面的框架代码，但是框架代码执行效率很差
/*
	f.ExeProduceSql(fmt.Sprintf(`
				select  *
				from    group_data a
				where   name != '%v'`, req.TargetName), param.SinkTable("group_data_target"))
	f.ExeProduceSql(fmt.Sprintf(`
	select  *,
			(
				select  *
				from    group_data_target a
				where a.x = group_data.x
				and a.dim_name = group_data.dim_name
			) as sub_target_list
	from    group_data
	where   name='%v'`, req.TargetName), param.SinkTable("group_data"))
*/
func PackSubList(ctx context.Context, targetTable *onetable.Table, mainTargetName string) (*onetable.Table, error) {
	// key 日期+dimName，key2 targetName value 某指标在某维度下的趋势图节点
	var cardMap = make(map[string]map[string]*analysis.TargetTrendPoint)
	for _, m := range targetTable.ToRawMap() {
		if value, ok := m["percent"]; ok {
			if temp, ok := value.(decimal.Decimal); ok {
				m["percent"], _ = temp.Float64()
			}
		}
		if value, ok := m["value"]; ok {
			if temp, ok := value.(decimal.Decimal); ok {
				m["value"], _ = temp.Float64()
			}
		}
		var trendPoint = &analysis.TargetTrendPoint{}
		err := utils.MapToStruct(ctx, m, trendPoint)
		if err != nil {
			return nil, err
		}
		var mapKey = trendPoint.X + "_" + trendPoint.DimName
		if targetMap, ok := cardMap[mapKey]; ok {
			targetMap[trendPoint.Name] = trendPoint
		} else {
			cardMap[mapKey] = map[string]*analysis.TargetTrendPoint{trendPoint.Name: trendPoint}
		}
	}
	var resMapList = make([]map[string]interface{}, 0)
	for _, card := range cardMap {
		var subTargetList = make([]*analysis.TargetBasicInfo, 0)
		for targetName, point := range card {
			if targetName != mainTargetName {
				subTargetList = append(subTargetList, &analysis.TargetBasicInfo{
					Name:         point.Name,
					DisplayName:  point.DisplayName,
					Value:        point.Value,
					DisplayValue: point.DisplayValue,
					Percent:      point.Percent,
				})
			}
		}
		if _, ok := card[mainTargetName]; ok {
			card[mainTargetName].SubTargetList = subTargetList
			resMap := map[string]interface{}{
				"value":            card[mainTargetName].Value,
				"display_value":    card[mainTargetName].DisplayValue,
				"name":             card[mainTargetName].Name,
				"display_name":     card[mainTargetName].DisplayName,
				"x":                card[mainTargetName].X,
				"sub_target_list":  card[mainTargetName].SubTargetList,
				"dim_display_name": card[mainTargetName].DimDisplayName,
				"dim_name":         card[mainTargetName].DimName,
				"percent":          card[mainTargetName].Percent,
				"children":         card[mainTargetName].Children,
				"group_list":       card[mainTargetName].GroupList,
			}
			//resMap, err := utils.StructToMap(card[mainTargetName])
			//if err != nil {
			//	return nil, err
			//}
			resMapList = append(resMapList, resMap)
		}
	}

	return onetable.NewTable(resMapList), nil
}

func packPriceTrendData(overallTrend, drillTrend, groupTrend []*analysis.TargetTrendPoint, mainTargetName string) []*analysis.TargetTrendPoint {
	overallTrend = packSubTargetList(overallTrend, mainTargetName)
	drillTrend = packSubTargetList(drillTrend, mainTargetName)
	if groupTrend != nil {
		groupTrend = packSubTargetList(groupTrend, mainTargetName)
		groupMap := getTrendMap(groupTrend)
		for _, point := range overallTrend {
			if _, ok := groupMap[point.X]; ok {
				point.GroupList = groupMap[point.X]
			}
		}
	}
	drillMap := getTrendMap(drillTrend)
	for _, point := range overallTrend {
		if _, ok := drillMap[point.X]; ok {
			point.Children = drillMap[point.X]
		}
	}
	// 排序
	sort.Slice(overallTrend, func(i, j int) bool {
		return overallTrend[i].X < overallTrend[j].X
	})
	return overallTrend
}

func packSubTargetList(targetList []*analysis.TargetTrendPoint, mainTargetName string) []*analysis.TargetTrendPoint {
	// key 日期+dimName，key2 targetName value 某指标在某维度下的趋势图节点
	var cardMap = make(map[string]map[string]*analysis.TargetTrendPoint)
	for _, trendPoint := range targetList {
		// 日期和维度值可以唯一确认一类指标
		var mapKey = trendPoint.X + "_" + trendPoint.DimName
		if targetMap, ok := cardMap[mapKey]; ok {
			targetMap[trendPoint.Name] = trendPoint
		} else {
			cardMap[mapKey] = map[string]*analysis.TargetTrendPoint{trendPoint.Name: trendPoint}
		}
	}
	var resList = make([]*analysis.TargetTrendPoint, 0)
	for _, card := range cardMap {
		var subTargetList = make([]*analysis.TargetBasicInfo, 0)
		for targetName, point := range card {
			if targetName != mainTargetName {
				subTargetList = append(subTargetList, &analysis.TargetBasicInfo{
					Name:         point.Name,
					DisplayName:  point.DisplayName,
					Value:        point.Value,
					DisplayValue: point.DisplayValue,
					Percent:      point.Percent,
				})
			}
		}
		if _, ok := card[mainTargetName]; ok {
			card[mainTargetName].SubTargetList = subTargetList
			resList = append(resList, card[mainTargetName])
		}
	}
	return resList
}

func getTrendMap(trendList []*analysis.TargetTrendPoint) map[string][]*analysis.TargetTrendPoint {
	var resMap = make(map[string][]*analysis.TargetTrendPoint)
	for _, point := range trendList {
		if _, ok := resMap[point.X]; ok {
			resMap[point.X] = append(resMap[point.X], point)
		} else {
			resMap[point.X] = []*analysis.TargetTrendPoint{point}
		}
	}
	// 多维分析按照指标值降序排序
	for _, groupList := range resMap {
		sort.Slice(groupList, func(i, j int) bool {
			return groupList[i].Value > groupList[j].Value
		})
	}
	return resMap
}

type PriceDistributionTrendCode struct {
	SelectDim *dimensions.SelectedDimensionInfo `json:"select_dim"`
	StartDate string                            `json:"start_date"`
	EndDate   string                            `json:"end_date"`
}

func AddTargetCode(req *analysis.GetPriceInsightHierarchicalTrendRequest, resp *analysis.PriceInsightHierarchicalTrendItem) {
	if req.GroupDimension != nil {
		for i, point := range resp.TargetTrend {
			startDate, endDate := getStartEndDate(req, i)
			for _, enum := range point.GroupList {
				codeObject := &PriceDistributionTrendCode{
					SelectDim: &dimensions.SelectedDimensionInfo{
						Id:               req.GroupDimension.Id,
						Name:             req.GroupDimension.Name,
						AttrType:         req.GroupDimension.AttrType,
						SelectedOperator: req.GroupDimension.SelectedOperator,
						IsGroup:          req.GroupDimension.IsGroup,
						SelectedValues: []*dimensions.EnumElement{
							{
								Code: enum.DimName,
								Name: enum.DimDisplayName,
							},
						},
					},
					StartDate: startDate,
					EndDate:   endDate,
				}
				marshalStr, err := sonic.MarshalString(codeObject)
				if err != nil {
					return
				}
				enum.ProdTagCode = marshalStr
			}
		}
	}
}

func getStartEndDate(req *analysis.GetPriceInsightHierarchicalTrendRequest, index int) (string, string) {
	var startDate, endDate string
	startTime, _ := time.Parse(consts.Fmt_Date, req.BaseReq.StartDate)
	switch req.BaseReq.DateType {
	case base.DateType_DAY:
		startDate = startTime.AddDate(0, 0, index).Format(consts.Fmt_Date)
		endDate = startDate
	case base.DateType_WEEK:
		startDate = startTime.AddDate(0, 0, 7*index).Format(consts.Fmt_Date)
		endDate = startTime.AddDate(0, 0, 7*index+6).Format(consts.Fmt_Date)
	case base.DateType_MONTH:
		startDate = startTime.AddDate(0, index, 0).Format(consts.Fmt_Date)
		endDate = startTime.AddDate(0, index+1, -1).Format(consts.Fmt_Date)
	}
	return startDate, endDate
}
