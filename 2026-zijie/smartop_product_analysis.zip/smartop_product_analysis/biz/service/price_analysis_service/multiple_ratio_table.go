package price_analysis_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"context"
	"fmt"
)

func (p *PriceAnalysisService) GetMultipleRatioTable(ctx context.Context, req *analysis.GetMultipleRatioTableRequest) (resp []*analysis.MultipleRatioTableItem, err error) {
	dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceInsightCoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}
	curr, trend, _, err := base_struct_condition.GetPriceBaseStructConditionParams(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "GetPriceBaseStructConditionParams失败, "+err.Error())
		return nil, err
	}
	err = addOtherParam(curr, trend, req)
	if err != nil {
		logs.CtxError(ctx, "添加额外的os入参失败, "+err.Error())
		return nil, err
	}
	var apiPath string
	if req.BaseReq.BizType == dimensions.BizType_PriceTrendSku {
		apiPath = ApiPathSkuMultipleRatioTable
	} else if req.BaseReq.BizType == dimensions.BizType_PriceTrendOrder {
		apiPath = ApiPathOrderMultipleRatioTable
	} else if req.BaseReq.BizType == dimensions.BizType_PriceTrendShow {
		apiPath = ApiPathShowMultipleRatioTable
	} else {
		return nil, errors.New("入参的bizType不匹配")
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{effectModuleMultiRatioTable})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// whole_value 是只看顶部筛选区和是否广告筛选的汇总值，不需要下拆场域和价格力分层，只有一行，用于作为分母计算倍比
	//curr["is_whole"] = true
	//f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("whole_value")).SetParallel(true).SetMaxParallelNum(6)
	//curr["is_whole"] = false
	//trend["is_whole"], trend["is_whole_trend"] = true, true
	//f.ExeQueryInvokerRaw(trend, apiPath, param.SinkTable("whole_value_trend")).SetParallel(true).SetMaxParallelNum(6)
	//trend["is_whole"], trend["is_whole_trend"] = false, false
	f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("overall_data")).SetParallel(true).SetMaxParallelNum(6)
	curr["drill_price_tag"] = true
	f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("curr_data")).SetParallel(true).SetMaxParallelNum(6)
	f.ExeQueryInvokerRaw(trend, apiPath, param.SinkTable("trend_overall_data")).SetParallel(true).SetMaxParallelNum(6)
	trend["drill_price_tag"] = true
	f.ExeQueryInvokerRaw(trend, apiPath, param.SinkTable("trend_drill_data")).SetParallel(true).SetMaxParallelNum(6)
	//f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("whole_value"), param.SinkTable("whole_value")).
	//	SetValueColumn("target_value").
	//	SetTargetNameColumn("target_name").SetDimColumns([]string{"sku_cnt"}))
	//f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("whole_value_trend"), param.SinkTable("whole_value_trend")).
	//	SetValueColumn("target_value").
	//	SetTargetNameColumn("target_name").SetDimColumns([]string{"time", "sku_cnt"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("overall_data"), param.SinkTable("overall_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"source", "sku_cnt"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("curr_data"), param.SinkTable("curr_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"source", "sku_cnt", "price_range"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_overall_data"), param.SinkTable("trend_overall_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"source", "sku_cnt", "time"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_drill_data"), param.SinkTable("trend_drill_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"source", "sku_cnt", "time", "price_range"}))

	// 这里有个trick逻辑，把每天的value值塞到dim_name和dim_display_name里面，方便导出接口使用
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.target_value as value,
				custom_source(a.source,%v) as table_name,
				'总体' as row_name,
				1.00 as multiple_ratio,
				a.target_name as name,
				b.display_name as display_name,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				(
				select  custom_date(t.time, %v) as x,
						t.target_name as name,
						'倍比' as display_name,
						1.00 as value,
						'1.00' as display_value,
						t.target_value as dim_name,
						t.target_value as dim_display_name
				from    trend_overall_data t
				where   t.source = overall_data.source
						and t.target_name = overall_data.target_name
				order by x asc) as multiple_ratio_trend
		from    overall_data a
		inner   join
				target_meta b
		on      a.target_name=b.name`, int(req.BaseReq.GetBizType()), int(req.BaseReq.GetDateType())), param.SinkTable("overall_data_new")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDateByDateType),
		"custom_source":     onetable.NormalFunc(CustomSource),
	})
	var multipleRatioSql, multipleRatioTrendSql string
	if req.BaseReq.BizType == dimensions.BizType_PriceTrendSku || req.BaseReq.BizType == dimensions.BizType_PriceTrendOrder {
		multipleRatioSql = `a.target_value/a.sku_cnt/(d.target_value/d.sku_cnt)`
		multipleRatioTrendSql = `t.target_value/t.sku_cnt/(c.target_value/c.sku_cnt)`
	} else {
		multipleRatioSql = `a.target_value/d.target_value`
		multipleRatioTrendSql = `t.target_value/c.target_value`
	}
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.target_value as value,
				a.target_name as name,
				custom_source(a.source,%v) as table_name,
				a.price_range as row_name,
				%v as multiple_ratio,
				b.display_name as display_name,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				(
				select  custom_date(t.time, %v) as x,
						t.target_name as name,
						'倍比' as display_name,
						%v as value,
						get_display_value(%v, 'double', '', 2) as display_value,
						t.target_value as dim_name,
						c.target_value as dim_display_name
				from    trend_drill_data t
				inner join trend_overall_data c
						on t.time = c.time
						and t.source = c.source
				where   t.source = curr_data.source
						and t.price_range = curr_data.price_range
						and t.target_name = curr_data.target_name
				order by x asc) as multiple_ratio_trend
		from    curr_data a
		inner   join
				target_meta b
		on      a.target_name = b.name
		inner   join 
				overall_data d
		on      a.source = d.source`, int(req.BaseReq.GetBizType()), multipleRatioSql, int(req.BaseReq.GetDateType()), multipleRatioTrendSql, multipleRatioTrendSql), param.SinkTable("curr_data_new")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDateByDateType),
		"custom_source":     onetable.NormalFunc(CustomSource),
	})
	f.ExeProduceSql(`					
					select  row_name,
							table_name,
							multiple_ratio,
							multiple_ratio_trend,
							(
								select  value,
										display_value,
										name,
										display_name
							) as target_info
					from    overall_data_new `, param.SinkTable("overall_table"))
	f.ExeProduceSql(`
		select  table_name,
				(
					select * 
					from overall_table b 
					where b.table_name = overall_data_new.table_name
					union all 
					select row_name,
						multiple_ratio,
						multiple_ratio_trend,
						(
							select  value,
									display_value,
									name,
									display_name
						) as target_info
					from curr_data_new a 
					where a.table_name = overall_data_new.table_name
				) as item
		from    overall_data_new`, param.SinkTable("res_data"))
	resp = make([]*analysis.MultipleRatioTableItem, 0)
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return resp, nil
}

func addOtherParam(curr, trend map[string]interface{}, req *analysis.GetMultipleRatioTableRequest) error {
	curr["target_name"] = req.TargetName
	trend["target_name"] = req.TargetName
	if req.IsAd != nil {
		curr["is_ad"] = *req.IsAd
		trend["is_ad"] = *req.IsAd
	}
	return nil
}

func CustomSource(orderSource string, bizType int64) (string, error) {
	var name string
	if bizType == int64(dimensions.BizType_PriceTrendSku) || bizType == int64(dimensions.BizType_PriceTrendOrder) {
		switch orderSource {
		case "guess":
			name = "双端猜你喜欢（不限制货架）"
		case "live":
			name = "双端直播体裁"
		case "search":
			name = "双端搜索整体（不限制货架）"
		case "video":
			name = "双端短视频体裁"
		case "tens_subsidy":
			name = "双端超值购"
		default:
			name = orderSource
		}
	} else if bizType == int64(dimensions.BizType_PriceTrendShow) {
		switch orderSource {
		case "guess":
			name = "猜喜"
		case "live":
			name = "直播"
		case "search":
			name = "搜素"
		case "video":
			name = "短视频"
		case "tens_subsidy":
			name = "超值购"
		case "product_detail":
			name = "商详"
		case "seckill":
			name = "秒杀"
		case "shop":
			name = "店铺"
		case "window":
			name = "橱窗"
		default:
			name = orderSource
		}
	}
	return name, nil
}
