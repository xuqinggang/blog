package price_analysis_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"context"
	"fmt"
	"sort"
)

func (p *PriceAnalysisService) GetPriceInsightCoreOverview(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp []*analysis.TargetCardEntity, err error) {
	dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceInsightCoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}
	apiId := getTargetCardApiId(req)
	if apiId == "" {
		return nil, errors.New("价格力趋势指标卡接口，传入的bizType匹配有误")
	}
	curr, trend, overall, err := base_struct_condition.GetPriceBaseStructConditionParams(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetPriceInsightCoreOverview]GetPriceBaseStructConditionParams Error，err=%v+", err)
		return nil, err
	}
	// sku价格力需要改价指标需要限制条件
	if req.GetBaseReq().GetBizType() == dimensions.BizType_PriceTrendSku {
		priceChangeWhereStr, err := base_struct_condition.GetOutXdPriceChangeWhereStr(ctx, biz_info.GetCtxBizInfoPriceAAInOutType(ctx))
		if err != nil {
			logs.CtxError(ctx, "[GetPriceChangeFlowStandardSubSQL]GetOutXdPriceChangeWhereStr Err, %v", err)
			return nil, err
		}
		curr["price_change_filter"] = priceChangeWhereStr
		trend["price_change_filter"] = priceChangeWhereStr
		overall["price_change_filter"] = priceChangeWhereStr
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryInvokerRaw(curr, apiId, param.SinkTable("target_data")).SetParallel(true).SetMaxParallelNum(6)
	f.ExeQueryInvokerRaw(trend, apiId, param.SinkTable("trend_data")).SetParallel(true).SetMaxParallelNum(6)
	f.ExeQueryInvokerRaw(overall, apiId, param.SinkTable("overall_data")).SetParallel(true).SetMaxParallelNum(6)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_data"), param.SinkTable("target_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"time"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("overall_data"), param.SinkTable("overall_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	trendSubSql := fmt.Sprintf(`
		(select  custom_date(time, %v) as x,
				target_name as name,
				m.display_name as display_name,
				target_value as value,
				get_display_value(target_value, m.value_type, m.value_unit, m.target_precision) as display_value
		from    trend_data t
		inner join target_meta m
		on t.target_name = m.name
		where   t.target_name=target_data_new.name
		order by x asc)
	`, int64(req.GetBaseReq().GetDateType()))
	f.ExeProduceSql(`
		select 
			a.target_name as name,
			a.target_value as value,
			c.target_value as whole_value
		from target_data a
		left join overall_data c
		on a.target_name = c.target_name
	`, param.SinkTable("target_data_new"))

	marketSubSql := `
				(
				select  b.whole_value as market_value,
						get_display_value(b.whole_value, a.value_type, a.value_unit,a.target_precision) as display_value,
						a.is_compute_percent as percent_flag,
						case
							when a.is_compute_percent = true then b.value/b.whole_value
							else 0
						end as market_percent,
						a.is_larger_advantage as is_larger_advantage
				)`
	// 关联指标元信息, 处理额外信息
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.name as name,
				b.value as value,
				get_display_value(b.value, a.value_type, a.value_unit,a.target_precision) as display_value,
				%v as trend_data,
				a.display_name as display_name,
				a.tips as tips,
				a.value_unit as unit,
				a.attribute_type as category_name,
				%v as extra,
				a.display_order as display_order,
				a.need_second_query as need_second_query,
				a.is_use_pp as is_use_pp
		from    target_meta a
		inner join
				target_data_new b
		on      a.name=b.name
		order by a.display_order asc
	`, trendSubSql, marketSubSql), param.SinkTable("card_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDateByDateType),
	})
	resp = make([]*analysis.TargetCardEntity, 0)
	f.ExeView(param.SourceTable("card_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	if len(resp) > 0 {
		sort.Slice(resp, func(i, j int) bool {
			return resp[i].DisplayOrder < resp[j].DisplayOrder
		})
	}
	err = AddDiff(ctx, resp, int64(req.BaseReq.BizType))
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return
}

func getTargetCardApiId(req *analysis.GetPriceInsightCoreOverviewRequest) string {
	if req.GetBaseReq().GetBizType() == dimensions.BizType_PriceTrendSku {
		if req.IsPriceChange {
			return ApiPathPriceChangeTargetCard
		} else {
			return ApiPathSKUPriceTargetCard
		}
	} else if req.GetBaseReq().GetBizType() == dimensions.BizType_PriceTrendOrder {
		return ApiPathOrderPriceTargetCard
	} else if req.GetBaseReq().GetBizType() == dimensions.BizType_PriceTrendShow {
		return ApiPathShowPriceTargetCard
	}
	return ""
}

func AddDiff(ctx context.Context, targetList []*analysis.TargetCardEntity, bizType int64) error {
	targetMeta, err := dao.GetTargetMetaInfo(ctx, bizType, false, []string{})
	if err != nil {
		return err
	}
	var targetMetaMap = make(map[string]*dao.TargetMetaInfo)
	for _, info := range targetMeta {
		targetMetaMap[info.Name] = info
	}
	for _, entity := range targetList {
		if len(entity.TrendData) >= 2 {

			entity.DiffExtra = &analysis.DiffExtraInfo{
				Diff:      entity.TrendData[len(entity.TrendData)-1].Value - entity.TrendData[0].Value,
				DiffRatio: (entity.TrendData[len(entity.TrendData)-1].Value - entity.TrendData[0].Value) / entity.TrendData[0].Value,
			}
			if meta, ok := targetMetaMap[entity.Name]; ok {
				entity.DiffExtra.DisplayValue, _ = framework_udf.GetBriefMetricDisplayValue(
					entity.TrendData[len(entity.TrendData)-1].Value-entity.TrendData[0].Value, meta.ValueType, meta.ValueUnit, meta.TargetPrecision)
			}
		}
	}
	return nil
}
