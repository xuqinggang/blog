package great_value_buy_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/lang/maths"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/mohae/deepcopy"
)

func (s *GreatValueBuyService) GetOptimizeActionInfo(ctx context.Context, reqSrc *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.DimensionActionIncomeSummary, err error) {
	resp = &great_value_buy.DimensionActionIncomeSummary{}
	resp.ReachDimensions = make([]*dimensions.DimensionInfo, 0)
	resp.NonReachDimensions = make([]*dimensions.DimensionInfo, 0)
	resp.OptimizeInfos = make([]*great_value_buy.OptimizeActionInfo, 0)
	// 深拷贝
	req := &great_value_buy.GetGreatValueBuyCommonRequest{}
	if req1, ok := deepcopy.Copy(reqSrc).(*great_value_buy.GetGreatValueBuyCommonRequest); ok {
		req = req1
	}
	defer func() {
		logs.CtxInfo(ctx, "[GetOptimizeActionInfo]req=%s,\n resp=%s", convert.ToJSONString(req), convert.ToJSONString(resp))
	}()
	if req.OverallCommonReq == nil {
		req.OverallCommonReq = &analysis.OverallCommonRequest{}
	}
	if req.OverallCommonReq != nil && req.OverallCommonReq.BaseReq != nil && req.OverallCommonReq.BaseReq.StartDate == "" ||
		req.OverallCommonReq.BaseReq.EndDate == "" {
		req.OverallCommonReq.BaseReq.StartDate = req.BaseReq.StartDate
		req.OverallCommonReq.BaseReq.EndDate = req.BaseReq.EndDate
		req.OverallCommonReq.BaseReq.CompareStartDate = req.BaseReq.CompareStartDate
		req.OverallCommonReq.BaseReq.CompareEndDate = req.BaseReq.CompareEndDate
		req.OverallCommonReq.BaseReq.TargetMetaList = req.BaseReq.TargetMetaList
	}
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		// 各维度汇总
		coreTreeType := great_value_buy.CoreTreeType_DimensionSummary
		req.CoreTreeType = &coreTreeType
		summaryRes, err := s.GetGreatValueBuyAttributionCoreTree(ctx, req)
		if err != nil {
			logs.CtxError(ctx, "GetOptimizeActionInfo, err=%v", err)
			return err
		}
		// 维度汇总
		if summaryRes != nil && len(summaryRes.DataList) > 0 {
			total := summaryRes.DataList[0]
			if total == nil {
				logs.CtxError(ctx, "GetOptimizeActionInfo, total is nil")
				return errors.New("total is nil")
			}
			for _, target := range total.TargetList {
				if target != nil && target.Extra.TargetType == analysis.TargetType_BigActivityVsOverallDiff {
					logs.CtxInfo(ctx, "[GetOptimizeActionInfo][DimensionSummary][Total] %v=%v", target.Name, target.Extra.MarketPercent)
				}
				if target.Name == "accumulate_increase_gmv_diff" && target.Extra.MarketPercent < 0 {
					resp.EstimateAccumulateIncreaseGmv = fmt.Sprintf("+%.2fpp", maths.AbsFloat64(target.Extra.MarketPercent)*100)
				} else if target.Name == "accumulate_gmv_diff" && target.Extra.MarketPercent < 0 {
					resp.EstimateAccumulateGmv = fmt.Sprintf("+%.2fpp", maths.AbsFloat64(target.Extra.MarketPercent)*100)
				} else if target.Name == "accumulate_gmv_burst_rate_diff" && target.Extra.MarketPercent < 0 {
					resp.EstimateAccumulateGmvBurstRate = fmt.Sprintf("+%.2fpp", maths.AbsFloat64(target.Extra.MarketPercent)*100)
				} else if target.Name == "accumulate_increase_gmv_gov_diff" && target.Extra.MarketPercent < 0 {
					resp.EstimateAccumulateIncreaseGmv = fmt.Sprintf("+%.2fpp", maths.AbsFloat64(target.Extra.MarketPercent)*100)
				} else if target.Name == "accumulate_gmv_gov_diff" && target.Extra.MarketPercent < 0 {
					resp.EstimateAccumulateGmv = fmt.Sprintf("+%.2fpp", maths.AbsFloat64(target.Extra.MarketPercent)*100)
				} else if target.Name == "accumulate_gmv_burst_rate_gov_diff" && target.Extra.MarketPercent < 0 {
					resp.EstimateAccumulateGmvBurstRate = fmt.Sprintf("+%.2fpp", maths.AbsFloat64(target.Extra.MarketPercent)*100)
				}
			}
			firstLevel := make([]*great_value_buy.GetGreatValueBuyAttributionCoreTreeData, 0)
			if total != nil && len(total.Children) > 0 {
				firstLevel = total.Children
			}
			for _, row := range firstLevel {
				if row != nil && len(row.TargetList) > 0 {
					var accumulateIncreaseGmvDiff string
					for _, target := range row.TargetList {
						if target != nil && (target.Name == "accumulate_increase_gmv_diff" || target.Name == "accumulate_increase_gmv_gov_diff") {
							accumulateIncreaseGmvDiff = target.DisplayValue
							if target.Value > 0 {
								resp.ReachDimensions = append(resp.ReachDimensions, &dimensions.DimensionInfo{
									ShowName: row.Code,
								})
							} else if target.Value < 0 {
								resp.NonReachDimensions = append(resp.NonReachDimensions, &dimensions.DimensionInfo{
									ShowName: row.Code,
								})
							}
							break
						}
					}
					logs.CtxInfo(ctx, "[GetOptimizeActionInfo][DimensionSummary][Row] row_name=%v,accumulateIncreaseGmvDiff=%v", row.Name, accumulateIncreaseGmvDiff)
				}
			}
		}
		return nil
	})
	var funnelRes *great_value_buy.GetGreatValueBuyAttributionCoreTreeDataList
	cc.GoV2(func() error {
		funnelReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
		if req1, ok := deepcopy.Copy(req).(*great_value_buy.GetGreatValueBuyCommonRequest); ok {
			funnelReq = req1
		}
		coreTreeType2 := great_value_buy.CoreTreeType_FunnelAnalysis
		funnelReq.CoreTreeType = &coreTreeType2
		// 漏斗分析
		funnelRes, err = s.GetGreatValueBuyAttributionCoreTree(ctx, funnelReq)
		if err != nil {
			logs.CtxError(ctx, "GetOptimizeActionInfo, err=%v", err)
			return err
		}
		return nil
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "GetOptimizeActionInfo err=%v", err)
		return nil, err
	}

	//bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	//bizType := req.BaseReq.BizType
	//if bizInfo != nil && bizInfo.DependBizID > 0 {
	//	bizType = dimensions.BizType(bizInfo.DependBizID)
	//}
	//configReq := &great_value_buy.GetGreatValueBuyDiagnosisConfigDataRequest{
	//	BizType: bizType,
	//}
	//configRes, err := s.GetGreatValueBuyDiagnosisConfig(ctx, configReq)

	funnelTotal := &great_value_buy.GetGreatValueBuyAttributionCoreTreeData{}
	if funnelRes != nil && len(funnelRes.DataList) > 0 {
		funnelTotal = funnelRes.DataList[0]
	}
	var accumulateGmvBurstRateDiff, newProdAccumulateGmvBurstRateDiff, oldProdAccumulateGmvBurstRateDiff float64
	for _, item := range funnelTotal.TargetList {
		if item.Name == "new_prod_accumulate_gmv_burst_rate_diff" {
			newProdAccumulateGmvBurstRateDiff = item.Value
		} else if item.Name == "old_prod_accumulate_gmv_burst_rate_diff" {
			oldProdAccumulateGmvBurstRateDiff = item.Value
		} else if item.Name == "accumulate_gmv_burst_rate_diff" {
			accumulateGmvBurstRateDiff = item.Value
		}
	}
	logs.CtxInfo(ctx, "[GetOptimizeActionInfo][DimensionFunnel] accumulateGmvBurstRateDiff=%v,newProdAccumulateGmvBurstRateDiff=%v,oldProdAccumulateGmvBurstRateDiff=%v",
		newProdAccumulateGmvBurstRateDiff, oldProdAccumulateGmvBurstRateDiff, accumulateGmvBurstRateDiff)
	fmt.Println(accumulateGmvBurstRateDiff, newProdAccumulateGmvBurstRateDiff, oldProdAccumulateGmvBurstRateDiff)

	overviewReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	if req1, ok := deepcopy.Copy(req).(*great_value_buy.GetGreatValueBuyCommonRequest); ok {
		overviewReq = req1
	}
	overviewReq.DiagnosisTargetList = make([]*great_value_buy.GetGreatValueBuyDiagnosisTopicTargetInfo, 0)
	var avgNewProdPoolProdCntDiff, avgOldProdPoolProdCntDiff float64
	// 不需要新老品促报名动作
	if newProdAccumulateGmvBurstRateDiff < 0 || oldProdAccumulateGmvBurstRateDiff < 0 {
		overviewReq.DiagnosisTargetList = append(overviewReq.DiagnosisTargetList,
			&great_value_buy.GetGreatValueBuyDiagnosisTopicTargetInfo{
				TargetType: great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_BigActivityShowPvDiagnosis,
			})
		overviewResp, _ := s.GetGreatValueBuyDiagnosisCommonCoreOverview(ctx, overviewReq)
		fmt.Println(overviewResp)
		if overviewResp != nil && len(overviewResp.TargetList) > 0 {
			for _, target := range overviewResp.TargetList {
				if target.Name == "avg_new_prod_pool_prod_cnt" {
					avgNewProdPoolProdCntDiff = target.ComparePeriodData.CompareDiff
				} else if target.Name == "avg_old_prod_pool_prod_cnt" {
					avgOldProdPoolProdCntDiff = target.ComparePeriodData.CompareDiff
				}
			}
		}
	}
	fmt.Println(avgNewProdPoolProdCntDiff, avgOldProdPoolProdCntDiff)

	if newProdAccumulateGmvBurstRateDiff < 0 && avgNewProdPoolProdCntDiff < 0 {
		temp := &great_value_buy.OptimizeActionInfo{
			OptimizeItem: &great_value_buy.OptimizeItem{
				Code: "new_prod_sign_up",
				Name: "新品追报名",
			},
			CrmTask: &great_value_buy.CrmTask{
				Code: "crm_sign_up",
				Name: "CRM追报名",
			},
			EstimateIncreaseGmv: fmt.Sprintf("+%.2fpp", maths.AbsFloat64(newProdAccumulateGmvBurstRateDiff)*100),
		}
		resp.OptimizeInfos = append(resp.OptimizeInfos, temp)
	}
	if oldProdAccumulateGmvBurstRateDiff < 0 && avgOldProdPoolProdCntDiff < 0 {
		temp := &great_value_buy.OptimizeActionInfo{
			OptimizeItem: &great_value_buy.OptimizeItem{
				Code: "old_prod_sign_up",
				Name: "老品追报名",
			},
			CrmTask: &great_value_buy.CrmTask{
				Code: "crm_sign_up",
				Name: "CRM追报名",
			},
			EstimateIncreaseGmv: fmt.Sprintf("+%.2fpp", maths.AbsFloat64(oldProdAccumulateGmvBurstRateDiff)*100),
		}
		resp.OptimizeInfos = append(resp.OptimizeInfos, temp)
	}
	quality := &great_value_buy.OptimizeActionInfo{
		OptimizeItem: &great_value_buy.OptimizeItem{
			Code: "optimize_quality_score",
			Name: "优化质量分",
		},
		CrmTask: &great_value_buy.CrmTask{
			Code: "crm_quality_score_optimize",
			Name: "CRM质量分优化",
		},
		EstimateIncreaseGmv: fmt.Sprintf("+%.2fpp", maths.AbsFloat64(accumulateGmvBurstRateDiff)*100),
	}
	resp.OptimizeInfos = append(resp.OptimizeInfos, quality)
	commission := &great_value_buy.OptimizeActionInfo{
		OptimizeItem: &great_value_buy.OptimizeItem{
			Code: "optimize_commission_rate",
			Name: "优化佣金率",
		},
		CrmTask: &great_value_buy.CrmTask{
			Code: "crm_commission_optimize",
			Name: "CRM佣金优化",
		},
		EstimateIncreaseGmv: fmt.Sprintf("+%.2fpp", maths.AbsFloat64(accumulateGmvBurstRateDiff)*100),
	}
	resp.OptimizeInfos = append(resp.OptimizeInfos, commission)
	opportunity := &great_value_buy.OptimizeActionInfo{
		OptimizeItem: &great_value_buy.OptimizeItem{
			Code: "opportunity_prod_sign_up",
			Name: "机会品追报名",
		},
		CrmTask: &great_value_buy.CrmTask{
			Code: "crm_sign_up",
			Name: "CRM追报名",
		},
		EstimateIncreaseGmv: fmt.Sprintf("+%.2fpp", maths.AbsFloat64(accumulateGmvBurstRateDiff)*100),
	}
	resp.OptimizeInfos = append(resp.OptimizeInfos, opportunity)

	logs.CtxInfo(ctx, "[GetOptimizeActionInfo]req=%s,\n resp=%s", convert.ToJSONString(req), convert.ToJSONString(resp))
	if err != nil {
		return nil, err
	}
	return resp, nil
}
