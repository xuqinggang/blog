package great_value_buy_service

import (
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"sort"
	"strings"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_portal_sdk/portal_agw"
	lark2 "github.com/larksuite/oapi-sdk-go/v3"
	larkim "github.com/larksuite/oapi-sdk-go/v3/service/im/v1"
)

// LarkURI Lark 使用的Uri数据结构
type LarkURI struct {
	PCUrl      string `json:"pc_url"`
	AndroidURL string `json:"android_url"`
	IosURL     string `json:"ios_url"`
	URL        string `json:"url"`
}

// CardConclusion 卡片的小结，循环渲染
type CardConclusion struct {
	DetailLink LarkURI `json:"detail_link"`
	BtnLabel   string  `json:"btn_label"`
	Text1      string  `json:"text_1"`
	Text2      string  `json:"text_2"`
	Text3      string  `json:"text_3"`
	Text4      string  `json:"text_4"`
}

// LarkCardVariables 卡片使用到的参数
type LarkCardVariables struct {
	CardTitle      string           `json:"card_title"`
	PushTime       string           `json:"push_time"`
	PushUser       string           `json:"push_user"`
	BasePeriod     string           `json:"base_period"`
	AnalysisPeriod string           `json:"analysis_period"`
	FilterRules    string           `json:"filter_rules"`
	AnalysisDim    string           `json:"analysis_dim"`
	AnalysisMethod string           `json:"analysis_method"`
	Conclusion     string           `json:"conclusion"`
	DetailList     []CardConclusion `json:"detail_list"`
	OverallLink    LarkURI          `json:"overall_link"`
	ThemeColor     string           `json:"theme_color"`
}

// LarkCardData 飞书卡片数据
type LarkCardData struct {
	TemplateID       string            `json:"template_id"`
	TemplateVariable LarkCardVariables `json:"template_variable"`
}

// LarkCardRequestData 发送卡片时使用的数据结构
type LarkCardRequestData struct {
	Type string       `json:"type"`
	Data LarkCardData `json:"data"`
}

// CardDetailItem 卡片中每个小结的数据结构
// ---------- 1. 数据结构扩展 ----------
type CardDetailItem struct {
	DimName string
	DimCode string

	// === 四种指标的核心数值 ===
	// 1. 大促累计增量GMV
	AccumulateIncreaseGMVActivity float64
	AccumulateIncreaseGMVOverall  float64
	// 2. 动销商品平均日均增量GMV（示例名，需与OS指标名一致）
	ValidProdAvgIncreaseActivity float64
	ValidProdAvgIncreaseOverall  float64
	// 3. 大促累计GMV占比大盘
	AccumulateGMVInOverallRateActivity float64
	// 4. 大促累计GMV占比大盘整体
	AvgGMVInOverallTotalRateActivity float64

	// 通用辅助字段
	ThresholdValue                 float64 // 配置里的阈值
	AccumulateGMVBurstRateActivity float64
	AccumulateGMVBurstRateOverall  float64
	AccumulateGPMBurstRateActivity float64
	AccumulateGPMBurstRateOverall  float64
	QSScoreMoreThan85              float64
	CommissionRate                 float64
	GMVDiff                        float64
	DiffValue                      float64 // 当前值与阈值的差值，用于排序
}

// ColorText 输出飞书中使用的富文本文字
func ColorText(text string, color string, bold bool) string {
	if bold {
		text = fmt.Sprintf("**%s**", text)
	}

	return fmt.Sprintf("<font color='%s'>%s</font>", color, text)
}

// generateDimStr 用于生成维度展示的字符串
func generateDimStr(dims []*dimensions.SelectedDimensionInfo) string {

	dimString := []string{}
	for _, dim := range dims {
		if len(dim.SelectedValues) > 0 {
			values := []string{}
			for _, value := range dim.SelectedValues {
				values = append(values, value.Name)
			}
			dimString = append(dimString, fmt.Sprintf("%s: %s", dim.Name, strings.Join(values, ",")))
		}
	}
	return strings.Join(dimString, ";")
}

// generateLarkConclusion 用于生成展示在卡片上的具体富文本内容
func generateLarkConclusion(ctx context.Context, total CardDetailItem, item CardDetailItem, baseUri string, tagType great_value_buy.BigActIncreaseTagType) *CardConclusion {

	var Text2, Text4 string
	switch tagType { // 假设 cfg 已注入到 CardDetailItem
	case great_value_buy.BigActIncreaseTagType_Diff_AccumulateIncreaseGMV:
		baseGMV := total.AccumulateIncreaseGMVOverall
		if baseGMV == 0 {
			logs.CtxError(ctx, "Base Gmv is ZERO while generate lark conclusion")
			return nil
		}
		activityGMVRate := item.AccumulateIncreaseGMVActivity / baseGMV * 100
		overallGMVRate := item.AccumulateIncreaseGMVOverall / baseGMV * 100
		gmvDiff := activityGMVRate - overallGMVRate

		Text2 = fmt.Sprintf(`🔬 **数据**：
		增量GMV占比<font color='red-500'>低于</font>大盘(%.2fpp VS %.2fpp %s)<font>`,
			activityGMVRate,
			overallGMVRate,
			ColorText(fmt.Sprintf("%.2fpp", gmvDiff), "red-500", false))
		Text4 = fmt.Sprintf("✅ **预估优化收益**：\n增量GMV占比 %s", ColorText(fmt.Sprintf("+%.2fpp", -gmvDiff), "green-500", true))

	case great_value_buy.BigActIncreaseTagType_Diff_ValidProdAvgIncreaseGMV:
		baseGMV := total.ValidProdAvgIncreaseOverall
		if baseGMV == 0 {
			logs.CtxError(ctx, "Base Gmv is ZERO while generate lark conclusion")
			return nil
		}
		activityGMVRate := item.ValidProdAvgIncreaseActivity / baseGMV * 100
		overallGMVRate := item.ValidProdAvgIncreaseOverall / baseGMV * 100
		gmvDiff := activityGMVRate - overallGMVRate
		Text2 = fmt.Sprintf(`🔬 **数据**：动销商品平均日均增量GMV <font color='red-500'>%.2f</font>，大盘 <font color='green-500'>%.2f</font>，差值 <font color='red-500'>%.2f</font>`,
			item.ValidProdAvgIncreaseActivity,
			item.ValidProdAvgIncreaseOverall,
			item.DiffValue)
		Text4 = fmt.Sprintf("✅ **预估优化收益**：\n动销商品平均日均增量GMV %s", ColorText(fmt.Sprintf("+%.2f", gmvDiff), "green-500", true))

	case great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallRate:
		Text2 = fmt.Sprintf(`🔬 **数据**：大促日均GMV占比大盘 <font color='red-500'>%.2f%%</font>，阈值 <font color='blue-500'>%.2f%%</font>，差值 <font color='red-500'>%.2fpp</font>`,
			item.AccumulateGMVInOverallRateActivity*100,
			item.ThresholdValue,
			item.DiffValue)
		Text4 = fmt.Sprintf("✅ **预估优化收益**：\n大促累计GMV占比大盘 %s", ColorText(fmt.Sprintf("+%.2f%%", -item.DiffValue), "green-500", true))

	case great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallTotalRate:
		Text2 = fmt.Sprintf(`🔬 **数据**：大促累计GMV占比大盘整体 <font color='red-500'>%.2f%%</font>，阈值 <font color='blue-500'>%.2f%%</font>，差值 <font color='red-500'>%.2fpp</font>`,
			item.AvgGMVInOverallTotalRateActivity*100,
			item.ThresholdValue,
			item.DiffValue)
		Text4 = fmt.Sprintf("✅ **预估优化收益**：\n大促累计GMV占比大盘整体 %s", ColorText(fmt.Sprintf("+%.2f%%", -item.DiffValue), "green-500", true))
	default:
		logs.CtxError(ctx, "GenerateData failed, cfg.GetBigActIncreaseTagType() not support")
		return nil
	}

	Text3 := `💪 **建议优化动作**：\n- 对双高/潜力品中的未报名商品，追报名`

	if item.AccumulateGMVBurstRateActivity < item.AccumulateGMVBurstRateOverall {
		Text2 += fmt.Sprintf("\n- 商品GMV爆发系数低于大盘（%.2fpp VS %.2fpp %s）",
			item.AccumulateGMVBurstRateActivity*100,
			item.AccumulateGMVBurstRateOverall*100,
			ColorText(fmt.Sprintf("%.2fpp", (item.AccumulateGMVBurstRateActivity-item.AccumulateGMVBurstRateOverall)*100), "red-500", false))
	}

	if item.AccumulateGPMBurstRateActivity < item.AccumulateGPMBurstRateOverall {
		Text2 += fmt.Sprintf("\n- GPM爆发系数低于大盘（%.2fpp VS %.2fpp %s）",
			item.AccumulateGPMBurstRateActivity*100,
			item.AccumulateGPMBurstRateOverall*100,
			ColorText(fmt.Sprintf("%.2fpp", (item.AccumulateGPMBurstRateActivity-item.AccumulateGPMBurstRateOverall)*100), "red-500", false))

		if item.QSScoreMoreThan85 < 0.1 {
			Text2 += fmt.Sprintf("\n  - 质量分>=85分的商品占比<10%%（%.2f%%）", item.QSScoreMoreThan85*100)
			Text3 += "\n- 对双高/潜力品中质量分<85分商品，优化质量分"
		}
		if item.CommissionRate < 0.1 {
			Text2 += fmt.Sprintf("\n  - 联盟佣金率的商品增量GMV占比<10%%（%.2f%%）", item.CommissionRate*100)
			Text3 += "\n- 对双高/潜力品中佣金率<5%商品，追佣金"
		}
	}

	params := url.Values{}
	params.Set("append_drill", item.DimName)

	uri := baseUri + "&" + params.Encode()

	return &CardConclusion{
		DetailLink: LarkURI{
			URL: uri,
		},
		BtnLabel: fmt.Sprintf(`查看【%s】诊断详情`, item.DimName),
		Text1:    fmt.Sprintf(`**<font color='red-500'>%s</font>**`, item.DimName),
		Text2:    Text2,
		Text3:    "💪 **建议优化动作**：\n- 对双高/潜力品中质量分<85分商品，优化质量分",
		Text4:    Text4,
	}
}

// ---------- 2. collectCardDetailItem ----------
func collectCardDetailItem(ctx context.Context, row *great_value_buy.GetGreatValueBuyMultiDimRow, cfg *great_value_buy.BigActIncreaseTagConfig, actProdNeedGov, overallNeedGov bool) (*CardDetailItem, bool) {
	val := func(key string) (float64, bool) {
		for _, t := range row.TargetList {
			if t.Name == key {
				return t.Value, true
			}
		}
		return 0, false
	}

	item := &CardDetailItem{
		DimName:        row.DisplayName,
		DimCode:        row.DimKey,
		ThresholdValue: cfg.GetThresholdValue(),
	}
	// TODO zgx 1. 根据是否国补选择指标(done) 2. OS API 添加目标指标
	ok := false
	switch cfg.GetBigActIncreaseTagType() {
	case great_value_buy.BigActIncreaseTagType_Diff_AccumulateIncreaseGMV:
		if actProdNeedGov {
			item.AccumulateIncreaseGMVActivity, ok = val("bigact_accumulate_increase_gmv_gov")
		} else {
			item.AccumulateIncreaseGMVActivity, ok = val("bigact_accumulate_increase_gmv")
		}
		if overallNeedGov {
			item.AccumulateIncreaseGMVOverall, ok = val("accumulate_increase_gmv_gov")
		} else {
			item.AccumulateIncreaseGMVOverall, ok = val("accumulate_increase_gmv")
		}
		item.DiffValue = item.AccumulateIncreaseGMVActivity - item.AccumulateIncreaseGMVOverall
	case great_value_buy.BigActIncreaseTagType_Diff_ValidProdAvgIncreaseGMV:
		if actProdNeedGov {
			item.ValidProdAvgIncreaseActivity, ok = val("bigact_selling_prod_avg_increase_gmv_gov")
		} else {
			item.ValidProdAvgIncreaseActivity, ok = val("bigact_selling_prod_avg_increase_gmv")
		}
		if overallNeedGov {
			item.ValidProdAvgIncreaseOverall, ok = val("selling_prod_avg_increase_gmv_gov")
		} else {
			item.ValidProdAvgIncreaseOverall, ok = val("selling_prod_avg_increase_gmv")
		}
		item.DiffValue = item.ValidProdAvgIncreaseActivity - item.ValidProdAvgIncreaseOverall
	case great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallTotalRate:
		item.AvgGMVInOverallTotalRateActivity, ok = val("bigact_avg_gmv_in_overall_total")
		item.DiffValue = item.AvgGMVInOverallTotalRateActivity*100 - item.ThresholdValue
	case great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallRate:
		item.AccumulateGMVInOverallRateActivity, ok = val("bigact_accumulate_gmv_in_overall")
		item.DiffValue = item.AccumulateGMVInOverallRateActivity*100 - item.ThresholdValue
	default:
		logs.CtxError(ctx, "GenerateData failed, cfg.GetBigActIncreaseTagType() not support")
		return item, false
	}

	var isOK1, isOK2, isOK3, isOK4, isOK5, isOK6 bool

	if actProdNeedGov {
		item.AccumulateGMVBurstRateActivity, isOK1 = val("bigact_accumulate_gmv_burst_rate_gov")
		item.AccumulateGPMBurstRateActivity, isOK3 = val("bigact_accumulate_gpm_burst_rate_gov")
	} else {
		item.AccumulateGMVBurstRateActivity, isOK1 = val("bigact_accumulate_gmv_burst_rate")
		item.AccumulateGPMBurstRateActivity, isOK3 = val("bigact_accumulate_gpm_burst_rate")
	}
	if overallNeedGov {
		item.AccumulateGMVBurstRateOverall, isOK2 = val("accumulate_gmv_burst_rate_gov")
		item.AccumulateGPMBurstRateOverall, isOK4 = val("accumulate_gpm_burst_rate_gov")
	} else {
		item.AccumulateGMVBurstRateOverall, isOK2 = val("accumulate_gmv_burst_rate")
		item.AccumulateGPMBurstRateOverall, isOK4 = val("accumulate_gpm_burst_rate")
	}
	item.QSScoreMoreThan85, isOK5 = val("score_more_than_85_increase_gmv_rate")
	item.CommissionRate, isOK6 = val("commission_reach_increase_gmv_rate")
	if !(isOK1 && isOK2 && isOK3 && isOK4 && isOK5 && isOK6) {
		logs.CtxError(ctx, "GenerateData failed, isOK1: %v, isOK2: %v, isOK3: %v, isOK4: %v, isOK5: %v, isOK6: %v", isOK1, isOK2, isOK3, isOK4, isOK5, isOK6)
		return nil, false
	}

	return item, ok
}

// GenerateDataType 需要从OS获取的数据
type GenerateDataType struct {
	Conclusion     string
	DetailList     []CardConclusion
	AnalysisDim    string
	AnalysisMethod string
}

// ---------- 3. GenerateData ----------
func (s *GreatValueBuyService) GenerateData(
	ctx context.Context,
	req *great_value_buy.SendAttributionReportRequest,
	overallURI string,
) (data GenerateDataType, err error) {

	if req.OriginReq == nil || req.OriginReq.BaseReq == nil {
		logs.CtxError(ctx, "GenerateData failed, req.OriginReq is nil")
		return data, errors.New("BaseReq is empty")
	}
	baseReq := req.OriginReq.BaseReq
	if len(baseReq.GroupAttrs) == 0 {
		return data, errors.New("Drill attrs is empty")
	}
	drillAttrName := baseReq.GroupAttrs[0].DimInfo.Name

	larkData, err := s.GetBigactMultiDimensionTable(ctx, req.OriginReq, TableSceneBigActivityLarkCard)
	if err != nil {
		return
	}
	var cfg *great_value_buy.BigActIncreaseTagConfig
	if req.OriginReq == nil || req.OriginReq.TargetConfigList == nil || req.OriginReq.TargetConfigList.BigActIncreaseTagConfig == nil {
		logs.CtxError(ctx, "GenerateData failed, req.OriginReq.TargetConfigList.BigActIncreaseTagConfig is nil")
		return
	}
	cfg = req.OriginReq.TargetConfigList.BigActIncreaseTagConfig

	// 判断大盘大促指标是否包含国补数据
	var actProdNeedGov, overallNeedGov bool
	if req.OriginReq.TargetConfigList != nil && req.OriginReq.TargetConfigList.GovTargetConfig != nil {
		if req.OriginReq.TargetConfigList.GovTargetConfig.ActNeedGov {
			actProdNeedGov = true
		}
		if req.OriginReq.TargetConfigList.GovTargetConfig.OverallNeedGov {
			overallNeedGov = true
		}
	}

	totalRow, ok := collectCardDetailItem(ctx, larkData.Total, cfg, actProdNeedGov, overallNeedGov)
	if !ok {
		return data, errors.New("获取数据失败")
	}

	// 统一筛选：差值 < 0 即视为“不达标”
	var cardItems []CardDetailItem
	for _, row := range larkData.Rows {
		if item, ok := collectCardDetailItem(ctx, row, cfg, actProdNeedGov, overallNeedGov); ok && item.DiffValue < 0 {
			cardItems = append(cardItems, *item)
		}
	}
	sort.Slice(cardItems, func(i, j int) bool {
		return cardItems[i].DiffValue < cardItems[j].DiffValue
	})

	// 最终使用的推送详情数据
	detailList := []CardConclusion{}
	for _, item := range cardItems {
		conclusion := generateLarkConclusion(ctx, *totalRow, item, overallURI, cfg.BigActIncreaseTagType)
		if conclusion != nil {
			detailList = append(detailList, *conclusion)
		}
	}

	// 构造结论文案
	var conclusionTpl, analysisMethodTpl string
	switch cfg.GetBigActIncreaseTagType() {
	case great_value_buy.BigActIncreaseTagType_Diff_AccumulateIncreaseGMV:
		conclusionTpl = "以下【%s】，已筛选大促商品的【累计增量GMV】低于已筛选大盘商品"
		analysisMethodTpl = "定位【大促累计增量GMV】> 【大盘累计增量GMV】 的【%s】"
	case great_value_buy.BigActIncreaseTagType_Diff_ValidProdAvgIncreaseGMV:
		conclusionTpl = "以下【%s】，已筛选大促商品的【动销商品平均日均增量GMV】低于已筛选大盘商品"
		analysisMethodTpl = "定位【大促动销商品平均日均增量GMV】> 【大盘动销商品平均日均增量GMV】 的【%s】"
	case great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallRate:
		conclusionTpl = "以下【%s】，大促累计GMV占比大盘不满足阈值%.2f%%"
		analysisMethodTpl = "定位【大促累计GMV占比大盘】不满足阈值 的【%s】"
	case great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallTotalRate:
		conclusionTpl = "以下【%s】，大促累计GMV占比大盘整体不满足阈值%.2f%%"
		analysisMethodTpl = "定位【大促累计GMV占比大盘整体】不满足阈值 的【%s】"
	default:
		logs.CtxError(ctx, "GenerateData failed, cfg.GetBigActIncreaseTagType() not support")
		return data, errors.New("GenerateData failed, cfg.GetBigActIncreaseTagType() not support")
	}

	conclusion := fmt.Sprintf(conclusionTpl, drillAttrName, cfg.GetThresholdValue())
	if len(cardItems) == 0 {
		conclusion = "当前筛选条件没有需要特别关注的case，请继续保持🎉🎉🎉"
	}

	return GenerateDataType{
		Conclusion:     conclusion,
		DetailList:     detailList,
		AnalysisDim:    drillAttrName,
		AnalysisMethod: fmt.Sprintf(analysisMethodTpl, drillAttrName),
	}, nil
}

// SendReport 发送卡片的流程
func (s *GreatValueBuyService) SendReport(ctx context.Context, req *great_value_buy.SendAttributionReportRequest, contentStr string, client lark2.Client) (userIds []string, groupIds []string, errUsers []string, errGroups []string) {

	for _, user := range req.Users {
		larkReq := larkim.NewCreateMessageReqBuilder().
			ReceiveIdType(`email`).
			Body(larkim.NewCreateMessageReqBodyBuilder().
				ReceiveId(user.Id).
				MsgType("interactive").
				Content(contentStr).
				Build()).
			Build()
		_, err := client.Im.V1.Message.Create(ctx, larkReq)
		userIds = append(userIds, user.Id)
		if err != nil {
			errUsers = append(errUsers, user.Id)
		}
	}
	for _, group := range req.Groups {
		larkReq := larkim.NewCreateMessageReqBuilder().
			ReceiveIdType("chat_id").
			Body(larkim.NewCreateMessageReqBodyBuilder().
				ReceiveId(group.Id).
				MsgType("interactive").
				Content(contentStr).
				Build()).
			Build()
		_, err := client.Im.V1.Message.Create(ctx, larkReq)
		groupIds = append(groupIds, group.Id)
		if err != nil {
			errGroups = append(errGroups, group.Id)
		}
	}
	return
}

// SendAttributionReport 是发送卡片的处理函数，用于管理整个发送流程
func (s *GreatValueBuyService) SendAttributionReport(ctx context.Context, req *great_value_buy.SendAttributionReportRequest) (err error) {
	email := (portal_agw.GetUserInfo(ctx).Email)
	if email == nil {
		return errors.New("获取用户信息出错")
	}

	currentUser := *email
	baseReq := req.OriginReq.BaseReq
	overallReq := req.OriginReq.OverallCommonReq.BaseReq
	startData := baseReq.StartDate
	endData := baseReq.EndDate
	compareStartData := baseReq.CompareStartDate
	compareEndData := baseReq.CompareEndDate

	activityDims := baseReq.Dimensions
	overallDims := overallReq.Dimensions
	activityDimsStr := generateDimStr(activityDims)
	overallDimsStr := generateDimStr(overallDims)

	overallURI := fmt.Sprintf(`https://ecop.bytedance.net/product_insight/attribution?view=big_activity&res_id=%s`, req.ResId)

	otherInfos, err1 := s.GenerateData(ctx, req, overallURI)

	filterRules := "- 大促品：" + activityDimsStr
	if overallDimsStr != "" {
		filterRules += "\n- 大盘品：" + overallDimsStr
	}

	msgParam := LarkCardRequestData{
		Type: "template",
		Data: LarkCardData{
			TemplateID: "AAqdpJfspKx1S",
			TemplateVariable: LarkCardVariables{
				CardTitle:      "大促商品诊断简报",
				PushTime:       time.Now().Format("2006-01-02"),
				PushUser:       currentUser,
				AnalysisPeriod: fmt.Sprintf(`%s~%s`, startData, endData),
				BasePeriod:     fmt.Sprintf(`%s~%s`, compareStartData, compareEndData),
				FilterRules:    filterRules,
				AnalysisDim:    otherInfos.AnalysisDim,
				AnalysisMethod: otherInfos.AnalysisMethod,
				Conclusion:     otherInfos.Conclusion,
				DetailList:     otherInfos.DetailList,
				OverallLink: LarkURI{
					URL: overallURI,
				},
				ThemeColor: "red",
			},
		},
	}

	jsonStr, err2 := json.Marshal(msgParam)
	client := lark_service.GetInstance(int64(req.OriginReq.BaseReq.BizType))

	if client == nil {
		err = errors.New("lark instance init error")
		return
	}

	if err1 != nil || err2 != nil {
		msgParam.Data.TemplateVariable.Conclusion = "您的推送任务失败了，请稍后重试"
		msgParam.Data.TemplateVariable.DetailList = []CardConclusion{}
		jsonStr, err = json.Marshal(msgParam)
		larkReq := larkim.NewCreateMessageReqBuilder().
			ReceiveIdType(`email`).
			Body(larkim.NewCreateMessageReqBodyBuilder().
				ReceiveId(*email).
				MsgType("interactive").
				Content(string(jsonStr)).
				Build()).
			Build()

		// 发起请求
		_, err = client.Im.V1.Message.Create(ctx, larkReq)
		return
	}

	contentStr := string(jsonStr)

	if req.IsTest {
		larkReq := larkim.NewCreateMessageReqBuilder().
			ReceiveIdType(`email`).
			Body(larkim.NewCreateMessageReqBodyBuilder().
				ReceiveId(currentUser).
				MsgType("interactive").
				Content(contentStr).
				Build()).
			Build()

		// 发起请求
		_, err := client.Im.V1.Message.Create(ctx, larkReq)

		return err
	}

	pushUsers, pushGroups, errUsers, errGroups := s.SendReport(ctx, req, contentStr, *client)

	push_users := strings.Join(pushUsers, ",")
	push_groups := strings.Join(pushGroups, ",")

	activityJSON, err1 := json.Marshal(req.OriginReq.BaseReq)
	overallJSON, err2 := json.Marshal(req.OriginReq.OverallCommonReq)
	if err1 == nil && err2 == nil {
		err = mysql.DB(ctx).Exec(`insert into lark_conclusion_card set push_time = ?, push_user = ?, receive_users = ?, receive_groups = ?, activity_rule = ?, overall_rule = ?, snapshot = ?`,
			time.Now(),
			currentUser,
			push_users,
			push_groups,
			string(activityJSON),
			string(overallJSON),
			"",
		).Error
	}
	if err1 != nil || err2 != nil || err != nil {
		logs.CtxError(ctx, "[Rds] Insert push record error, err=%s", err.Error())
		// return "", err
	}

	if len(errUsers) > 0 || len(errGroups) > 0 {
		// 发送失败的消息
		msgParam.Data.TemplateVariable.Conclusion = "卡片推送完成，但是有部分任务发送失败了"
		msgParam.Data.TemplateVariable.DetailList = []CardConclusion{}
	} else {
		msgParam.Data.TemplateVariable.CardTitle = "大促商品诊断简报-推送结果通知"
		msgParam.Data.TemplateVariable.Conclusion = "您的卡片推送任务已完成"
		msgParam.Data.TemplateVariable.DetailList = []CardConclusion{}
		msgParam.Data.TemplateVariable.ThemeColor = "green"
	}
	jsonStr, err = json.Marshal(msgParam)
	larkReq := larkim.NewCreateMessageReqBuilder().
		ReceiveIdType(`email`).
		Body(larkim.NewCreateMessageReqBodyBuilder().
			ReceiveId(*email).
			MsgType("interactive").
			Content(string(jsonStr)).
			Build()).
		Build()

	// 发起请求
	_, err = client.Im.V1.Message.Create(ctx, larkReq)
	return
}
