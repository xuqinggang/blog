package great_value_buy_service

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"strings"
	"sync"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/facility/log"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
	"github.com/jinzhu/copier"
)

type DiagnosisConclusionDim struct {
	DimGroups []dimensions.DimGroup `json:"dim_groups"` // 大促：0，大盘：1
	Id        string                `json:"id"`         // 维度id
	EnumCode  string                `json:"enum_code"`  // 枚举code
}

const (
	DiagnosisConclusionType_CommonResult    = "业务结果"
	DiagnosisConclusionType_GMVYOY          = "今年GMV增量的位置"
	DiagnosisConclusionType_GMVIncrease     = "日均增量GMV大盘优于活动品的维度"
	DiagnosisConclusionType_GMVNonReach     = "大促品累计增量GMV不足的维度"
	DiagnosisConclusionType_GMVReach        = "大促品累计增量GMV达标的维度"
	DiagnosisConclusionType_OpportunityProd = "机会商品"
)

type DiagnosisConclusionType struct {
	Name         string `json:"name"`
	EmptyText    string `json:"empty_text"`
	DisplayOrder int    `json:"display_order"`
}

var DiagnosisConclusionTypeMap = map[string]*DiagnosisConclusionType{
	DiagnosisConclusionType_CommonResult: {
		Name:         DiagnosisConclusionType_CommonResult,
		EmptyText:    "",
		DisplayOrder: 1,
	},
	DiagnosisConclusionType_GMVYOY: {
		Name:         DiagnosisConclusionType_GMVYOY,
		EmptyText:    "暂未发现今年GMV增量的位置～",
		DisplayOrder: 2,
	},
	DiagnosisConclusionType_GMVIncrease: {
		Name:         DiagnosisConclusionType_GMVIncrease,
		EmptyText:    "暂未发现。各维度下活动品日均增量GMV表现均比大盘突出，请继续保持～",
		DisplayOrder: 3,
	},
	DiagnosisConclusionType_GMVNonReach: {
		Name:         DiagnosisConclusionType_GMVNonReach,
		EmptyText:    "暂未发现。各维度下大促商品增量GMV贡献达标，请继续保持～",
		DisplayOrder: 4,
	},
	DiagnosisConclusionType_GMVReach: {
		Name:         DiagnosisConclusionType_GMVReach,
		EmptyText:    "暂未发现。各维度下大促商品增量GMV贡献不足，请及时检查并反馈～",
		DisplayOrder: 5,
	},
	DiagnosisConclusionType_OpportunityProd: {
		Name:         DiagnosisConclusionType_OpportunityProd,
		EmptyText:    "暂未发现有机会的商品～",
		DisplayOrder: 6,
	},
}

func (d *GreatValueBuyService) GetGreatValueBuyCommonDiagnosisConclusion(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetMultiDimCoreConclusionData, err error) {
	resp = &great_value_buy.GetMultiDimCoreConclusionData{}
	resp.GroupList = make([]*great_value_buy.GetMultiDimCoreConclusionGroup, 0)
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	if bizMetaInfo.EffectModule == "大促视图" {
		// 大促视图的处理逻辑
		if req.OverallCommonReq != nil && req.OverallCommonReq.BaseReq != nil {
			req.OverallCommonReq.BaseReq.BizType = req.BaseReq.BizType
		}
		groupList := make([]*great_value_buy.GetMultiDimCoreConclusionGroup, 0)
		var listMutex sync.Mutex
		cc := co.NewConcurrent(ctx)
		cc.GoV2(func() error {
			// 获取大促视图的多维分析结论数据
			tmpReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
			err = copier.CopyWithOption(tmpReq, req, copier.Option{DeepCopy: true})
			if err != nil {
				log.CtxError(ctx, "copier.CopyWithOption err=%v", err)
				return err
			}

			multiTableResp, multiTableRespErr := d.GetBigactMultiDimensionTable(ctx, tmpReq, TableSceneDiagnosisConclusion)
			if multiTableRespErr != nil {
				return multiTableRespErr
			}
			// 处理多维分析结论数据，生成结论数据
			tmpReq = &great_value_buy.GetGreatValueBuyCommonRequest{}
			err = copier.CopyWithOption(tmpReq, req, copier.Option{DeepCopy: true})
			if err != nil {
				log.CtxError(ctx, "copier.CopyWithOption err=%v", err)
				return err
			}
			currGroupList, currGroupListErr := d.packBigactMultiDimTableToConclusion(ctx, tmpReq, multiTableResp)
			if currGroupListErr != nil {
				return currGroupListErr
			}
			// 加锁
			listMutex.Lock()
			groupList = append(groupList, currGroupList...)
			listMutex.Unlock()
			return nil
		})
		cc.GoV2(func() error {
			// 获取归因树多维分析结论数据
			tmpReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
			err = copier.CopyWithOption(tmpReq, req, copier.Option{DeepCopy: true})
			if err != nil {
				log.CtxError(ctx, "copier.CopyWithOption err=%v", err)
				return err
			}
			treeResp, treeRespErr := d.GetOptimizeActionInfo(ctx, tmpReq)
			if treeRespErr != nil {
				return treeRespErr
			}
			// 处理多维分析结论数据，生成结论数据
			tmpReq = &great_value_buy.GetGreatValueBuyCommonRequest{}
			err = copier.CopyWithOption(tmpReq, req, copier.Option{DeepCopy: true})
			if err != nil {
				log.CtxError(ctx, "copier.CopyWithOption err=%v", err)
				return err
			}
			currGroupList, currGroupListErr := d.packBigactMultiDimTreeToConclusion(ctx, tmpReq, treeResp)
			if currGroupListErr != nil {
				return currGroupListErr
			}
			// 加锁
			listMutex.Lock()
			groupList = append(groupList, currGroupList...)
			listMutex.Unlock()
			return nil
		})
		err = cc.WaitV2()
		if err != nil {
			logs.CtxError(ctx, "GetGreatValueBuyCommonDiagnosisConclusion err=%v", err)
			return resp, err
		}
		// 对结论数据进行排序
		sort.SliceStable(groupList, func(i, j int) bool {
			return DiagnosisConclusionTypeMap[groupList[i].Name].DisplayOrder < DiagnosisConclusionTypeMap[groupList[j].Name].DisplayOrder
		})
		resp.GroupList = groupList
		return resp, nil
	}
	return resp, nil
}

func (d *GreatValueBuyService) packBigactMultiDimTreeToConclusion(
	ctx context.Context,
	req *great_value_buy.GetGreatValueBuyCommonRequest,
	treeData *great_value_buy.DimensionActionIncomeSummary,
) ([]*great_value_buy.GetMultiDimCoreConclusionGroup, error) {
	if treeData == nil {
		logs.CtxError(ctx, "诊断分析数据为空")
		return nil, errors.New("诊断分析数据为空")
	}
	dimInfo, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(req.BaseReq.GroupAttrs[0].DimInfo.Id))
	if err != nil {
		logs.CtxError(ctx, "GetDimensionByID err=%v", err)
		return nil, err
	}
	var opportunityProdOppptimizeInfo *great_value_buy.OptimizeItemDetail
	var mergeNonReachDimension *dimensions.SelectedDimensionInfo
	groupList := make([]*great_value_buy.GetMultiDimCoreConclusionGroup, 0)
	// 处理诊断分析结论数据，生成结论数据
	// 1.大促品增量不足的维度
	results := &great_value_buy.GetMultiDimCoreConclusionGroup{
		Name:        DiagnosisConclusionTypeMap[DiagnosisConclusionType_GMVNonReach].Name,
		Conclusions: &great_value_buy.GetMultiDimCoreConclusion{},
	}
	if len(treeData.NonReachDimensions) > 0 {
		nonReachDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
		mergeNonReachDimension, nonReachDimensions, err = transSelectedDimensions(ctx, dimInfo, treeData.NonReachDimensions)
		// 获取可优化任务
		optimizeConfigs := &great_value_buy.OptimizeActionConfig{
			OptimizeItems: []*great_value_buy.OptimizeItem{},
			CrmActions:    []*great_value_buy.CrmTask{},
		}
		for _, optimizeItem := range treeData.OptimizeInfos {
			optimizeConfigs.OptimizeItems = append(optimizeConfigs.OptimizeItems, &great_value_buy.OptimizeItem{
				Code: optimizeItem.OptimizeItem.Code,
				Name: optimizeItem.OptimizeItem.Name,
			})
			optimizeConfigs.CrmActions = append(optimizeConfigs.CrmActions, &great_value_buy.CrmTask{
				Code: optimizeItem.CrmTask.Code,
				Name: optimizeItem.CrmTask.Name,
			})
		}
		getOptimizeItemDetailReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
		err = copier.CopyWithOption(getOptimizeItemDetailReq, req, copier.Option{DeepCopy: true})
		if err != nil {
			logs.CtxError(ctx, "copier.CopyWithOption err=%v", err)
			return nil, err
		}
		// 拼接筛选下钻维度
		groupDims := make([]*dimensions.SelectedDimensionInfo, 0)
		groupDims = append(groupDims, mergeNonReachDimension)
		for i, attr := range req.BaseReq.GroupAttrs {
			if i == 0 {
				continue
			}
			attrTmp := &dimensions.SelectedMultiDimensionInfo{}
			err = copier.CopyWithOption(attrTmp, attr, copier.Option{DeepCopy: true})
			if err != nil {
				logs.CtxError(ctx, "copier.CopyWithOption err=%v", err)
				return nil, err
			}
			groupDims = append(groupDims, attrTmp.DimInfo)
		}
		getOptimizeItemDetailReq.BaseReq.Dimensions = append(getOptimizeItemDetailReq.BaseReq.Dimensions, groupDims...)
		// 请求优化项
		optimizeDetail, err := GetOptimizeItemDetail(ctx, d, getOptimizeItemDetailReq, optimizeConfigs)
		if err != nil {
			logs.CtxError(ctx, "GetOptimizeItemDetail err=%v", err)
			return nil, err
		}
		if optimizeDetail == nil || optimizeDetail.Data == nil {
			logs.CtxError(ctx, "GetOptimizeItemDetail optimizeDetail is nil")
			return nil, errors.New("GetOptimizeItemDetail optimizeDetail is nil")
		}
		optimizeItemList := optimizeDetail.Data.OptimizeItemDetailList
		dimsXml, err := generateMulDimensionsXML(ctx, nonReachDimensions)
		if err != nil {
			logs.CtxError(ctx, "generateMulDimensionsXML err=%v", err)
			return nil, err
		}
		results.Conclusions.ConclusionFormatText = fmt.Sprintf("%d个，分别是：%s。他们对应的大促商品增量GMV贡献不足。优化后预估整体收益：", len(treeData.NonReachDimensions), dimsXml)
		if treeData.EstimateAccumulateGmv != "" {
			results.Conclusions.ConclusionFormatText += fmt.Sprintf("GMV%s", generateColorValue(treeData.EstimateAccumulateGmv))
		}
		if treeData.EstimateAccumulateGmvBurstRate != "" {
			results.Conclusions.ConclusionFormatText += fmt.Sprintf(" GMV爆发系数%s", generateColorValue(treeData.EstimateAccumulateGmvBurstRate))
		}
		if treeData.EstimateAccumulateIncreaseGmv != "" {
			results.Conclusions.ConclusionFormatText += fmt.Sprintf(" 增量GMV%s", generateColorValue(treeData.EstimateAccumulateIncreaseGmv))
		}
		optimizeItemWithoutOpportunityProd := make([]*great_value_buy.OptimizeItemDetail, 0)
		for _, optimizeInfo := range optimizeItemList {
			if optimizeInfo.OptimizeItem.Code == "opportunity_prod_sign_up" {
				opportunityProdOppptimizeInfo = optimizeInfo
				continue
			}
			optimizeItemWithoutOpportunityProd = append(optimizeItemWithoutOpportunityProd, optimizeInfo)
		}
		if len(optimizeItemWithoutOpportunityProd) > 0 {
			results.Conclusions.ConclusionFormatText += "\n\n建议高优完成以下可优化项：\n\n"
			for _, optimizeInfo := range optimizeItemWithoutOpportunityProd {
				if optimizeInfo.OptimizeItem.Code == "opportunity_prod_sign_up" {
					opportunityProdOppptimizeInfo = optimizeInfo
					continue
				}
				optimizeItemXML, err := generateOptimizeDetailXML(ctx, optimizeInfo, mergeNonReachDimension)
				if err != nil {
					logs.CtxError(ctx, "generateOptimizeDetailXML err=%v", err)
					return nil, err
				}
				results.Conclusions.ConclusionFormatText += optimizeItemXML
			}
		}
		results.Conclusions.Dimensions = []*dimensions.SelectedDimensionInfo{mergeNonReachDimension}
	} else {
		results.Conclusions.ConclusionFormatText = DiagnosisConclusionTypeMap[DiagnosisConclusionType_GMVNonReach].EmptyText
	}
	groupList = append(groupList, results)

	// 2.大促品增量达标的维度
	results = &great_value_buy.GetMultiDimCoreConclusionGroup{
		Name:        DiagnosisConclusionTypeMap[DiagnosisConclusionType_GMVReach].Name,
		Conclusions: &great_value_buy.GetMultiDimCoreConclusion{},
	}
	if len(treeData.ReachDimensions) > 0 {
		mergeReachDimension, reachDimensions, err := transSelectedDimensions(ctx, dimInfo, treeData.ReachDimensions)
		dimsXml, err := generateMulDimensionsXML(ctx, reachDimensions)
		if err != nil {
			logs.CtxError(ctx, "generateMulDimensionsXML err=%v", err)
			return nil, err
		}
		results.Conclusions.ConclusionFormatText = fmt.Sprintf("%d个，分别是：%s。他们对应的大促商品增量GMV贡献达标，超过了大盘。您可以点击具体货盘，诊断可优化项，下发对应优化任务，进一步促进活动商品GMV爆发。", len(treeData.ReachDimensions), dimsXml)
		results.Conclusions.Dimensions = []*dimensions.SelectedDimensionInfo{mergeReachDimension}
	} else {
		results.Conclusions.ConclusionFormatText = DiagnosisConclusionTypeMap[DiagnosisConclusionType_GMVReach].EmptyText
	}
	groupList = append(groupList, results)

	// 3.机会商品
	results = &great_value_buy.GetMultiDimCoreConclusionGroup{
		Name:        DiagnosisConclusionTypeMap[DiagnosisConclusionType_OpportunityProd].Name,
		Conclusions: &great_value_buy.GetMultiDimCoreConclusion{},
	}
	if opportunityProdOppptimizeInfo != nil {
		optimizeItemXML, err := generateOptimizeDetailXML(ctx, opportunityProdOppptimizeInfo, mergeNonReachDimension)
		if err != nil {
			logs.CtxError(ctx, "generateOptimizeDetailXML err=%v", err)
			return nil, err
		}
		results.Conclusions.ConclusionFormatText = fmt.Sprintf("%s，上述问题活动货盘对应的维度下，有%d个品没有报名活动，但在活动期的增量，比大促商品更高，建议下发供给招商引入任务，优化后预估整体收益：GMV%s。", optimizeItemXML, opportunityProdOppptimizeInfo.CanOptimizeProdCnt, generateColorValue(convert.ToString(opportunityProdOppptimizeInfo.GmvRevenue)))
	} else {
		results.Conclusions.ConclusionFormatText = DiagnosisConclusionTypeMap[DiagnosisConclusionType_OpportunityProd].EmptyText
	}
	groupList = append(groupList, results)

	return groupList, nil
}

func (d *GreatValueBuyService) packBigactMultiDimTableToConclusion(
	ctx context.Context,
	req *great_value_buy.GetGreatValueBuyCommonRequest,
	multiTableData *great_value_buy.GetGreatValueBuyMultiDimensionData,
) ([]*great_value_buy.GetMultiDimCoreConclusionGroup, error) {
	if multiTableData == nil {
		logs.CtxError(ctx, "多维分析数据为空")
		return nil, errors.New("多维分析数据为空")
	}

	// 判断大盘大促指标是否包含国补数据
	actProdNeedGov, overallNeedGov := needGovSubsidy(req)

	groupList := make([]*great_value_buy.GetMultiDimCoreConclusionGroup, 0)
	// 处理多维分析结论数据，生成结论数据
	// 1.业务结果
	businessResults := &great_value_buy.GetMultiDimCoreConclusionGroup{
		Name:        DiagnosisConclusionTypeMap[DiagnosisConclusionType_CommonResult].Name,
		Conclusions: &great_value_buy.GetMultiDimCoreConclusion{},
	}
	total := multiTableData.Total
	if total == nil {
		logs.CtxError(ctx, "多维分析整体数据为空")
		return nil, errors.New("多维分析整体数据为空")
	}
	totalTargetMap := make(map[string]*analysis.TargetCardEntity, 0)
	for _, target := range total.TargetList {
		totalTargetMap[target.Name] = target
	}
	if !overallNeedGov {
		businessResults.Conclusions.ConclusionFormatText = fmt.Sprintf("大盘商品-日均GMV %s、大盘商品-GMV爆发系数 %s、大盘商品-日均增量GMV %s\n\n", generateColorValue(totalTargetMap[targetAvgGMV].DisplayValue), generateColorValue(totalTargetMap[targetGMVBurstRate].DisplayValue), generateColorValue(totalTargetMap[targetAvgGMVIncrease].DisplayValue))
	} else {
		businessResults.Conclusions.ConclusionFormatText = fmt.Sprintf("大盘商品-日均GMV %s、大盘商品-GMV爆发系数 %s、大盘商品-日均增量GMV %s\n\n", generateColorValue(totalTargetMap[targetAvgGMV+"_gov"].DisplayValue), generateColorValue(totalTargetMap[targetGMVBurstRate+"_gov"].DisplayValue), generateColorValue(totalTargetMap[targetAvgGMVIncrease+"_gov"].DisplayValue))

	}
	if !actProdNeedGov {
		businessResults.Conclusions.ConclusionFormatText += "\n" + fmt.Sprintf("活动商品-日均GMV %s、活动商品-GMV爆发系数 %s、活动商品-日均增量GMV %s\n\n", generateColorValue(totalTargetMap[targetBigactAvgGMV].DisplayValue), generateColorValue(totalTargetMap[targetBigactGMVBurstRate].DisplayValue), generateColorValue(totalTargetMap[targetBigactAvgGMVIncrease].DisplayValue))
	} else {
		businessResults.Conclusions.ConclusionFormatText += "\n" + fmt.Sprintf("活动商品-日均GMV %s、活动商品-GMV爆发系数 %s、活动商品-日均增量GMV %s\n\n", generateColorValue(totalTargetMap[targetBigactAvgGMV+"_gov"].DisplayValue), generateColorValue(totalTargetMap[targetBigactGMVBurstRate+"_gov"].DisplayValue), generateColorValue(totalTargetMap[targetBigactAvgGMVIncrease+"_gov"].DisplayValue))
	}
	if req.OverallCommonReq != nil && req.OverallCommonReq.IsOpenYoy {
		if !overallNeedGov {
			businessResults.Conclusions.ConclusionFormatText += "\n" + fmt.Sprintf("大盘日均GMV-YOY %s\n\n", generateColorValue(totalTargetMap[targetAvgGMVYOYRate].DisplayValue))
		} else {
			businessResults.Conclusions.ConclusionFormatText += "\n" + fmt.Sprintf("大盘日均GMV-YOY %s\n\n", generateColorValue(totalTargetMap[targetAvgGMVYOYRate+"_gov"].DisplayValue))
		}
	}
	groupList = append(groupList, businessResults)
	// 2.比活动品更好的大盘商品
	betterOverallProducts, err := generateConclusionGroup(
		ctx,
		req,
		multiTableData.Rows,
		DiagnosisConclusionType_GMVIncrease,
		DiagnosisConclusionTypeMap[DiagnosisConclusionType_GMVIncrease].Name,
		DiagnosisConclusionTypeMap[DiagnosisConclusionType_GMVIncrease].EmptyText,
		actProdNeedGov,
		overallNeedGov,
	)
	if err != nil {
		return nil, err
	}
	groupList = append(groupList, betterOverallProducts)

	if req.OverallCommonReq != nil && req.OverallCommonReq.IsOpenYoy {
		// 3.今年GMV增量的位置
		betterGMVYOY, err := generateConclusionGroup(
			ctx,
			req,
			multiTableData.Rows,
			DiagnosisConclusionType_GMVYOY,
			DiagnosisConclusionTypeMap[DiagnosisConclusionType_GMVYOY].Name,
			DiagnosisConclusionTypeMap[DiagnosisConclusionType_GMVYOY].EmptyText,
			actProdNeedGov,
			overallNeedGov,
		)
		if err != nil {
			return nil, err
		}
		groupList = append(groupList, betterGMVYOY)
	}

	return groupList, nil
}

func generateConclusionGroup(
	ctx context.Context,
	req *great_value_buy.GetGreatValueBuyCommonRequest,
	multiTableRows []*great_value_buy.GetGreatValueBuyMultiDimRow,
	calType string,
	groupName string,
	emptyConclusionText string,
	actProdNeedGov bool,
	overallNeedGov bool,
) (*great_value_buy.GetMultiDimCoreConclusionGroup, error) {
	rows, err := filterAndSortBigactMultiDimTable(ctx, multiTableRows, calType, actProdNeedGov, overallNeedGov)
	if err != nil {
		return nil, err
	}

	conclusionGroup := &great_value_buy.GetMultiDimCoreConclusionGroup{
		Name:        groupName,
		Conclusions: &great_value_buy.GetMultiDimCoreConclusion{},
	}

	selectedDimensionsMap := make(map[string]*dimensions.SelectedDimensionInfo, 0)
	selectedEnumMap := make(map[string]map[string]*dimensions.EnumElement, 0)
	conclusionsText, selectedDimList, err := packConclusion(ctx, req, rows, selectedDimensionsMap, selectedEnumMap, calType, 0, "", actProdNeedGov, overallNeedGov)
	if err != nil {
		return nil, err
	}

	if conclusionsText == "" {
		conclusionsText = emptyConclusionText
	}

	conclusionGroup.Conclusions.ConclusionFormatText = conclusionsText
	conclusionGroup.Conclusions.Dimensions = selectedDimList
	return conclusionGroup, nil
}

func filterAndSortBigactMultiDimTable(ctx context.Context, rows []*great_value_buy.GetGreatValueBuyMultiDimRow, calType string, actProdNeedGov bool, overallNeedGov bool) ([]*great_value_buy.GetGreatValueBuyMultiDimRow, error) {
	newRows := make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	err := copier.CopyWithOption(&newRows, &rows, copier.Option{DeepCopy: true})
	if err != nil {
		return nil, err
	}
	return sortRowsByCalType(ctx, newRows, calType, actProdNeedGov, overallNeedGov), nil
}

func sortRowsByCalType(ctx context.Context, rows []*great_value_buy.GetGreatValueBuyMultiDimRow, calType string, actProdNeedGov bool, overallNeedGov bool) []*great_value_buy.GetGreatValueBuyMultiDimRow {
	if len(rows) == 0 {
		return rows
	}
	// 规则过滤
	filteredRows := make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	for _, row := range rows {
		targetMap := make(map[string]*analysis.TargetCardEntity, 0)
		for _, target := range row.TargetList {
			targetMap[target.Name] = target
		}
		if calType == DiagnosisConclusionType_GMVIncrease {
			avgGmvIncreaseValue := 0.0
			var key string
			if overallNeedGov {
				key = targetAvgGMVIncrease + "_gov"
			} else {
				key = targetAvgGMVIncrease
			}
			if target, ok := targetMap[key]; ok {
				avgGmvIncreaseValue = target.Value
			} else {
				continue
			}
			bigactAvgGmvIncreaseValue := 0.0
			var bigactKey string
			if actProdNeedGov {
				bigactKey = targetBigactAvgGMVIncrease + "_gov"
			} else {
				bigactKey = targetBigactAvgGMVIncrease
			}
			if target, ok := targetMap[bigactKey]; ok {
				bigactAvgGmvIncreaseValue = target.Value
			} else {
				continue
			}
			if avgGmvIncreaseValue <= bigactAvgGmvIncreaseValue {
				continue
			}
		} else if calType == DiagnosisConclusionType_GMVYOY {
			avgGmvYoyRateValue := 0.0
			var key string
			if overallNeedGov {
				key = targetAvgGMVYOYRate + "_gov"
			} else {
				key = targetAvgGMVYOYRate
			}
			if target, ok := targetMap[key]; ok {
				avgGmvYoyRateValue = target.Value
			} else {
				continue
			}
			if avgGmvYoyRateValue <= 0 {
				continue
			}
		} else {
			logs.CtxError(ctx, "[sortRowsByCalType] 未找到对应的排序类型: %s", calType)
			break
		}
		filteredRows = append(filteredRows, row)
	}
	// 排序
	sort.SliceStable(filteredRows, func(i, j int) bool {
		iTargetMap := make(map[string]*analysis.TargetCardEntity, 0)
		jTargetMap := make(map[string]*analysis.TargetCardEntity, 0)
		for _, target := range filteredRows[i].TargetList {
			iTargetMap[target.Name] = target
		}
		for _, target := range filteredRows[j].TargetList {
			jTargetMap[target.Name] = target
		}
		switch calType {
		case DiagnosisConclusionType_GMVIncrease:
			var iBigactAvgGmvIncreaseValue float64
			var bigactKey string
			if actProdNeedGov {
				bigactKey = targetBigactAvgGMVIncrease + "_gov"
			} else {
				bigactKey = targetBigactAvgGMVIncrease
			}
			if target, ok := iTargetMap[bigactKey]; ok {
				iBigactAvgGmvIncreaseValue = target.Value
			}
			var jBigactAvgGmvIncreaseValue float64
			if target, ok := jTargetMap[bigactKey]; ok {
				jBigactAvgGmvIncreaseValue = target.Value
			}
			// 确保 avg_gmv_increase 存在，如果不存在，也默认为0或进行错误处理
			iAvgGmvIncreaseValue := 0.0
			var key string
			if overallNeedGov {
				key = targetAvgGMVIncrease + "_gov"
			} else {
				key = targetAvgGMVIncrease
			}
			if target, ok := iTargetMap[key]; ok {
				iAvgGmvIncreaseValue = target.Value
			}
			jAvgGmvIncreaseValue := 0.0
			if target, ok := jTargetMap[key]; ok {
				jAvgGmvIncreaseValue = target.Value
			}
			return (iAvgGmvIncreaseValue - iBigactAvgGmvIncreaseValue) > (jAvgGmvIncreaseValue - jBigactAvgGmvIncreaseValue)
		case DiagnosisConclusionType_GMVYOY:
			iAvgGmvYoyRateValue := 0.0
			var key string
			if overallNeedGov {
				key = targetAvgGMVYOYRate + "_gov"
			} else {
				key = targetAvgGMVYOYRate
			}
			if target, ok := iTargetMap[key]; ok {
				iAvgGmvYoyRateValue = target.Value
			}
			jAvgGmvYoyRateValue := 0.0
			if target, ok := jTargetMap[key]; ok {
				jAvgGmvYoyRateValue = target.Value
			}
			return iAvgGmvYoyRateValue > jAvgGmvYoyRateValue
		default:
			logs.CtxError(ctx, "[sortRowsByCalType] 未找到对应的排序类型: %s", calType)
			return false
		}
	})
	// 数量过滤
	if len(filteredRows) > 3 {
		filteredRows = filteredRows[:3]
	}

	for _, row := range filteredRows {
		row.Children = sortRowsByCalType(ctx, row.Children, calType, actProdNeedGov, overallNeedGov)
	}
	return filteredRows
}

func packConclusion(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, rows []*great_value_buy.GetGreatValueBuyMultiDimRow, selectedDimensionsMap map[string]*dimensions.SelectedDimensionInfo, selectedEnumMap map[string]map[string]*dimensions.EnumElement, calType string, layer int, prefix string, actProdNeedGov, overallNeedGov bool) (string, []*dimensions.SelectedDimensionInfo, error) {
	conclusionTexts := make([]string, 0)
	dimList := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, row := range rows {
		targetMap := make(map[string]*analysis.TargetCardEntity, 0)
		for _, target := range row.TargetList {
			targetMap[target.Name] = target
		}
		dims := make([]*dimensions.SelectedDimensionInfo, 0)
		err := sonic.UnmarshalString(row.ProdTagCode, &dims)
		if err != nil {
			logs.CtxError(ctx, "反序列化prod_tag_code失败,err:"+err.Error())
			continue
		}
		for _, dim := range dims {
			if len(dim.SelectedValues) == 0 {
				continue
			}
			_, exist := selectedEnumMap[dim.Id]
			if !exist {
				selectedEnumMap[dim.Id] = make(map[string]*dimensions.EnumElement, 0)
				selectedEnumMap[dim.Id][dim.SelectedValues[0].Code] = dim.SelectedValues[0]
				selectedDimensionsMap[dim.Id] = dim
			} else {
				_, exist = selectedEnumMap[dim.Id][dim.SelectedValues[0].Code]
				if !exist {
					selectedEnumMap[dim.Id][dim.SelectedValues[0].Code] = dim.SelectedValues[0]
					selectedDimensionsMap[dim.Id].SelectedValues = append(selectedDimensionsMap[dim.Id].SelectedValues, dim.SelectedValues[0])
				}
			}

		}
		var conclusionText string
		dimsXML, err := generateDimensionsXML(ctx, dims)
		if err != nil {
			logs.CtxError(ctx, "生成dimensions_xml失败,err:"+err.Error())
			continue
		}
		switch calType {
		case DiagnosisConclusionType_GMVIncrease:
			avgGmvIncreaseValue := 0.0
			key := targetAvgGMVIncrease
			if overallNeedGov {
				key += "_gov"
			}
			if target, ok := targetMap[key]; ok {
				avgGmvIncreaseValue = target.Value
			}
			bigactAvgGmvIncreaseValue := 0.0
			bigactKey := targetBigactAvgGMVIncrease
			if actProdNeedGov {
				bigactKey += "_gov"
			}
			if target, ok := targetMap[bigactKey]; ok {
				bigactAvgGmvIncreaseValue = target.Value
			}
			value := avgGmvIncreaseValue - bigactAvgGmvIncreaseValue

			displayV, err := framework_udf.GetBriefMetricDisplayValue(value, "double", "元", 2)
			if err != nil {
				logs.CtxError(ctx, "GetBriefMetricDisplayValue Err = %v", err)
				return "", nil, err
			}

			avgGmvIncreaseDisplayValue := ""
			if target, ok := targetMap[key]; ok {
				avgGmvIncreaseDisplayValue = target.DisplayValue
			}
			if layer == 0 {
				conclusionText = fmt.Sprintf("<p>%s<span>的大盘商品-日均增量GMV %s，相较</span>%s<span>的大促商品-日均增量GMV高 %s，该维度大盘比活动品表现更好</span></p>", dimsXML, generateColorValue(avgGmvIncreaseDisplayValue), dimsXML, generateColorValue(displayV))
			} else {
				conclusionText = fmt.Sprintf("%s的大盘商品-日均增量GMV %s，相较%s的大促商品-日均增量GMV高 %s，该维度大盘比活动品表现更好", dimsXML, generateColorValue(avgGmvIncreaseDisplayValue), dimsXML, generateColorValue(displayV))
			}
		case DiagnosisConclusionType_GMVYOY:
			avgGmvYoyRateDisplayValue := ""
			var key string
			if overallNeedGov {
				key = targetAvgGMVYOYRate + "_gov"
			} else {
				key = targetAvgGMVYOYRate
			}
			if target, ok := targetMap[key]; ok {
				avgGmvYoyRateDisplayValue = target.DisplayValue
			}
			if layer == 0 {
				conclusionText = fmt.Sprintf("<p>%s<span>的大盘商品-日均增量GMV YOY %s，今年比去年日均增量GMV更佳</span></p>", dimsXML, generateColorValue(avgGmvYoyRateDisplayValue))
			} else {
				conclusionText = fmt.Sprintf("%s的大盘商品-日均增量GMV YOY %s，今年比去年日均增量GMV更佳", dimsXML, generateColorValue(avgGmvYoyRateDisplayValue))
			}

		default:
			logs.CtxError(ctx, "[packConclusion] 未找到对应的打包类型: %s", calType)
			return "", nil, errors.New("未找到对应的打包类型")
		}
		conclusionText, _, err = packConclusion(ctx, req, row.Children, selectedDimensionsMap, selectedEnumMap, calType, layer+1, conclusionText, actProdNeedGov, overallNeedGov)
		if err != nil {
			logs.CtxError(ctx, "packConclusion Err = %v", err)
			return "", nil, err
		}
		conclusionTexts = append(conclusionTexts, conclusionText)
	}
	var conclusionTextResult string
	if layer > 0 {
		conclusionTextResult += prefix + "\n"
		for _, conclusionText := range conclusionTexts {
			for i := 0; i < layer; i++ {
				conclusionTextResult += "  "
			}
			conclusionTextResult += "- " + conclusionText + "\n"

		}
		for strings.Contains(conclusionTextResult, "\n\n") {
			conclusionTextResult = strings.ReplaceAll(conclusionTextResult, "\n\n", "\n")
		}
	} else {
		for _, conclusionText := range conclusionTexts {
			conclusionTextResult += conclusionText + "\n\n"
		}
		for strings.Contains(conclusionTextResult, "\n\n\n") {
			conclusionTextResult = strings.ReplaceAll(conclusionTextResult, "\n\n\n", "\n\n")
		}
		for _, dim := range selectedDimensionsMap {
			dimList = append(dimList, dim)
		}
	}

	return conclusionTextResult, dimList, nil
}

func generateDimensionsXML(ctx context.Context, dims []*dimensions.SelectedDimensionInfo) (string, error) {
	if dims == nil || len(dims) == 0 {
		logs.CtxError(ctx, "[generateDimensionsXML] dims为空")
		return "", errors.New("[generateDimensionsXML] dims为空")
	}
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	diagnosisConclusionDims := make([]DiagnosisConclusionDim, 0)
	for _, dim := range dims {
		dimInfo, exists := dimMap[convert.ToInt64(dim.Id)]
		if !exists {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", dim.Id)
			return "", errors.New("未查询到维度信息")
		}
		dimGroups := make([]dimensions.DimGroup, 0)
		for _, g := range strings.Split(dimInfo.DimGroups, ",") {
			dimGroups = append(dimGroups, dimensions.DimGroup(convert.ToInt64(g)))
		}
		diagnosisConclusionDim := DiagnosisConclusionDim{
			DimGroups: dimGroups,
			Id:        dim.Id,
			EnumCode:  dim.SelectedValues[0].Code,
		}
		diagnosisConclusionDims = append(diagnosisConclusionDims, diagnosisConclusionDim)
	}
	diagnosisConclusionDimsJSON, err := sonic.MarshalString(diagnosisConclusionDims)
	if err != nil {
		logs.CtxError(ctx, "序列化diagnosis_conclusion_dims失败,err:"+err.Error())
		return "", err
	}
	if len(dims[len(dims)-1].SelectedValues) == 0 || dims[len(dims)-1].SelectedValues[0] == nil || (dims[len(dims)-1].SelectedValues[0].Name == "" && dims[len(dims)-1].SelectedValues[0].Code == "") {
		logs.CtxError(ctx, "[generateDimensionsXML] 未查询到维度枚举值,dims=%s", convert.ToJSONString(dims))
		return "", errors.New("[generateDimensionsXML] 未查询到维度枚举值")
	}
	dimColName := dims[len(dims)-1].SelectedValues[0].Name
	if dims[len(dims)-1].SelectedValues[0].Name == "" {
		dimColName = dims[len(dims)-1].SelectedValues[0].Code
	}
	if dimColName == "未知" || dimColName == "-999" {
		dimColName = dims[len(dims)-1].Name + " × " + dimColName
	}
	diagnosisConclusionDimsXML := fmt.Sprintf("<dimensions infos={%s}>【%s】</dimensions>", diagnosisConclusionDimsJSON, dimColName)
	return diagnosisConclusionDimsXML, nil
}

func generateMulDimensionsXML(ctx context.Context, dims []*dimensions.SelectedDimensionInfo) (string, error) {
	if dims == nil || len(dims) == 0 {
		logs.CtxError(ctx, "[generateDimensionsXML] dims为空")
		return "", errors.New("[generateDimensionsXML] dims为空")
	}
	var diagnosisConclusionDimsXMLList []string
	for _, dim := range dims {
		dimXml, err := generateDimensionsXML(ctx, []*dimensions.SelectedDimensionInfo{dim})
		if err != nil {
			logs.CtxError(ctx, "generateDimensionsXML Err = %v", err)
			return "", err
		}
		diagnosisConclusionDimsXMLList = append(diagnosisConclusionDimsXMLList, dimXml)
	}

	diagnosisConclusionDimsXML := strings.Join(diagnosisConclusionDimsXMLList, "、")
	return diagnosisConclusionDimsXML, nil
}

func generateColorValue(value string) string {
	if value == "" || value == "0" {
		return ""
	} else if value[0] == '-' {
		return fmt.Sprintf("<font color=\"%s\">%s</font>", "#FF3B52", value)
	}
	return fmt.Sprintf("<font color=\"%s\">%s</font>", "#00C87F", value)
}

func transSelectedDimensions(ctx context.Context, dimInfo *dimensions.DimensionInfo, dims []*dimensions.DimensionInfo) (*dimensions.SelectedDimensionInfo, []*dimensions.SelectedDimensionInfo, error) {
	selectedValuesMap := make(map[string]*dimensions.EnumElement, 0)
	for _, selectValue := range dimInfo.Values {
		selectedValuesMap[selectValue.Code] = selectValue
	}
	mulResult := make([]*dimensions.SelectedDimensionInfo, 0)
	totalResult := &dimensions.SelectedDimensionInfo{
		Id:       convert.ToString(dimInfo.Id),
		Name:     dimInfo.ShowName,
		AttrType: dimInfo.DimensionCategory,
	}
	selectedValues := make([]*dimensions.EnumElement, 0)
	for _, dim := range dims {
		selectedValue, exist := selectedValuesMap[dim.ShowName]
		if !exist {
			log.CtxError(ctx, "未查询到维度枚举值,id=%s", dim.Id)
			return nil, nil, errors.New("未查询到维度枚举值")
		}
		result := &dimensions.SelectedDimensionInfo{
			Id:             convert.ToString(dimInfo.Id),
			Name:           dimInfo.ShowName,
			AttrType:       dimInfo.DimensionCategory,
			SelectedValues: []*dimensions.EnumElement{selectedValue},
		}
		mulResult = append(mulResult, result)
		selectedValues = append(selectedValues, selectedValue)
	}
	totalResult.SelectedValues = selectedValues
	return totalResult, mulResult, nil
}

// generateOptimizeDetailXML 生成可优化项的XML字符串
// 格式：<optimizedetail crm_actions={[{code: 'xxx', name: 'xxxx'}]} dimensions={[]}>251839个优化佣金率-CRM佣金优化</optimizedetail>
func generateOptimizeDetailXML(
	ctx context.Context,
	optimizeInfo *great_value_buy.OptimizeItemDetail,
	dimensionInfo *dimensions.SelectedDimensionInfo,
) (string, error) {
	if optimizeInfo == nil || optimizeInfo.CrmTask == nil || optimizeInfo.OptimizeItem == nil {
		return "", errors.New("generateOptimizeDetailXML: optimizeInfo 或其内嵌的 CrmTask/OptimizeItem 为空")
	}

	// 准备 crm_actions
	// 格式为 [{code: 'xxx', name: 'xxxx'}]，即 CrmTask 的数组
	crmActions := []*great_value_buy.CrmTask{optimizeInfo.CrmTask}
	crmActionsJSON, err := sonic.MarshalString(crmActions)
	if err != nil {
		logs.CtxError(ctx, "generateOptimizeDetailXML: 序列化 crmActions 到 JSON 失败: %v", err)
		return "", fmt.Errorf("序列化 crm_actions 失败: %w", err)
	}

	// 准备 dimensions
	// 格式为 []，即 SelectedDimensionInfo 的数组
	var dimensionsJSON string
	if dimensionInfo != nil {
		dimsToMarshal := []*dimensions.SelectedDimensionInfo{dimensionInfo} // 将单个维度信息包裹在切片中
		jsonStr, errMarshal := sonic.MarshalString(dimsToMarshal)
		if errMarshal != nil {
			logs.CtxError(ctx, "generateOptimizeDetailXML: 序列化 dimensionInfo 到 JSON 失败: %v", errMarshal)
			return "", fmt.Errorf("序列化 dimensions 失败: %w", errMarshal)
		}
		dimensionsJSON = jsonStr
	} else {
		dimensionsJSON = "[]" // 如果 dimensionInfo 为空，则默认为空数组 "[]"
	}

	// 准备文本内容
	textContent := fmt.Sprintf(" %d个%s-%s\n",
		optimizeInfo.CanOptimizeProdCnt,
		optimizeInfo.OptimizeItem.Name,
		optimizeInfo.CrmTask.Name+"任务",
	)

	// 构建 XML 字符串
	xmlString := fmt.Sprintf(" - <optimizedetail crm_actions={%s} dimensions={%s}>%s</optimizedetail>\n",
		crmActionsJSON,
		dimensionsJSON,
		textContent,
	)

	return xmlString, nil
}
