package great_value_buy_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"github.com/jinzhu/copier"
	"strings"
)

func (d *GreatValueBuyService) getBigActivityAttributionCoreTreeItems(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (
	total *great_value_buy.GetGreatValueBuyAttributionCoreTreeData, coreTreeItems []*great_value_buy.GetGreatValueBuyAttributionCoreTreeData, err error) {
	total = &great_value_buy.GetGreatValueBuyAttributionCoreTreeData{}

	tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
	if err != nil {
		return nil, nil, err
	}
	logs.CtxInfo(ctx, "clusterSwitchConf tableConf = %v", tableConf)

	coreTreeItems = make([]*great_value_buy.GetGreatValueBuyAttributionCoreTreeData, 0)
	resp := great_value_buy.NewGetGreatValueBuyMultiDimensionData()
	overallTotal := great_value_buy.NewGetGreatValueBuyMultiDimRow()
	overallRows := make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	activityTotal := great_value_buy.NewGetGreatValueBuyMultiDimRow()
	activityRows := make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	var targetMetaMap map[string]*dao.TargetMetaInfo
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	targetMetaMap, err = base_struct_condition.GetTargetMetaInfoMap(ctx, int64(req.BaseReq.BizType), false, nil...)
	if err != nil {
		return nil, nil, err
	}
	curr := make(map[string]interface{})
	if req.OverallCommonReq != nil {
		if req.OverallCommonReq.BaseReq.StartDate == "" && req.OverallCommonReq.BaseReq.EndDate == "" {
			req.OverallCommonReq.BaseReq.StartDate = req.BaseReq.StartDate
			req.OverallCommonReq.BaseReq.EndDate = req.BaseReq.EndDate
		}
		curr, _, _, _, _, err = base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
			BaseStruct: req.OverallCommonReq.BaseReq,
			DimMap:     dimMap,
			DimColMap:  dimColMap,
		})
		if err != nil {
			return nil, nil, err
		}
		req.OverallCommonReq.BaseReq.CompareStartDate = req.BaseReq.CompareStartDate
		req.OverallCommonReq.BaseReq.CompareEndDate = req.BaseReq.CompareEndDate
		req.OverallCommonReq.BaseReq.TargetMetaList = req.BaseReq.TargetMetaList
		req.OverallCommonReq.BaseReq.BizType = req.BaseReq.BizType
	}
	osParams := make(map[string]interface{}, 0)
	isNeedInit, params, err := checkAndInitLastOSParam(ctx, req, dimMap, dimColMap)
	if err != nil {
		return nil, nil, err
	}
	if isNeedInit {
		osParams = params
	}
	ps, _ := genFlowGroupParams(ctx, req, dimMap, dimColMap)
	if len(ps) > 0 {
		for key, value := range ps {
			osParams[key] = value
		}
	}

	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		overallAPi := tableConf.OverallCoreTree
		if req.CoreTreeType != nil && *req.CoreTreeType == great_value_buy.CoreTreeType_FunnelAnalysis {
			overallAPi = tableConf.OverallFunnel
		}
		// 大盘归因树
		osParamsCopy := make(map[string]interface{}, 0)
		err = copier.CopyWithOption(&osParamsCopy, &osParams, copier.Option{DeepCopy: true})
		if err != nil {
			return err
		}
		appendParams := analysis_service.AppendParams{
			OSParams:  osParamsCopy,
			OSApiPath: overallAPi,
		}
		if req.TargetConfigList != nil && req.TargetConfigList.GovTargetConfig != nil && req.TargetConfigList.GovTargetConfig.OverallNeedGov {
			appendParams.OSParams["is_contain_gov_target"] = 1
		}
		if req.OverallCommonReq != nil && req.OverallCommonReq.IsOpenYoy {
			appendParams.OSParams["is_open_yoy"] = 1
			appendParams.OSParams["yoy_start_date"] = curr["compare_start_date"]
			appendParams.OSParams["yoy_end_date"] = curr["compare_end_date"]
			appendParams.OSParams["date_range_yoy"] = curr["date_range_compare"]
		}
		appendParams.IsAllTotal = false
		res, err := d.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
			BaseReq:  req.OverallCommonReq.BaseReq,
			NeedIncr: req.GetNeedCycle(),
		}, appendParams)
		if err != nil {
			return err
		}
		newRes := d.analysisRowToGreatRow(ctx, req, []*analysis.MultiDimFullListRow{res.Total})
		if len(newRes) > 0 {
			overallTotal = newRes[0]
		}
		overallRows = d.analysisRowToGreatRow(ctx, req, res.FullList)
		return nil
	})
	cc.GoV2(func() error {
		//大促数据
		bigActAPi := tableConf.ActCoreTree
		if req.CoreTreeType != nil && *req.CoreTreeType == great_value_buy.CoreTreeType_FunnelAnalysis {
			bigActAPi = tableConf.ActFunnel
		}
		osParamsCopy := make(map[string]interface{}, 0)
		err = copier.CopyWithOption(&osParamsCopy, &osParams, copier.Option{DeepCopy: true})
		if err != nil {
			return err
		}
		appendParams := analysis_service.AppendParams{
			OSParams:  osParamsCopy,
			OSApiPath: bigActAPi,
		}
		if req.TargetConfigList != nil && req.TargetConfigList.GovTargetConfig != nil && req.TargetConfigList.GovTargetConfig.ActNeedGov {
			appendParams.OSParams["is_contain_gov_target"] = 1
		}
		appendParams.IsAllTotal = false
		res, err := d.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
			BaseReq:  req.BaseReq,
			NeedIncr: req.GetNeedCycle(),
		}, appendParams)
		if err != nil {
			return err
		}
		newRes := d.analysisRowToGreatRow(ctx, req, []*analysis.MultiDimFullListRow{res.Total})
		if len(newRes) > 0 {
			activityTotal = newRes[0]
		}
		activityRows = d.analysisRowToGreatRow(ctx, req, res.FullList)
		return nil
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "getTrendMap err=%v", err)
		return nil, nil, err
	}
	resp.Total = mergeTargets(ctx, []*great_value_buy.GetGreatValueBuyMultiDimRow{overallTotal}, []*great_value_buy.GetGreatValueBuyMultiDimRow{activityTotal})[0]
	resp.Rows = mergeTargets(ctx, overallRows, activityRows)

	totalTargetMap := make(map[string]*analysis.TargetCardEntity, 0)
	for _, target := range resp.Total.TargetList {
		totalTargetMap[target.Name] = target
	}
	calRateAndDiffTarget(ctx, req, targetMetaMap, totalTargetMap, resp.Rows)
	calRateAndDiffTarget(ctx, req, targetMetaMap, totalTargetMap, []*great_value_buy.GetGreatValueBuyMultiDimRow{resp.Total})
	totalRes := multiFullToCoreTree(ctx, []*great_value_buy.GetGreatValueBuyMultiDimRow{resp.Total})
	if len(totalRes) > 0 {
		total = totalRes[0]
	}
	coreTreeItems = multiFullToCoreTree(ctx, resp.Rows)
	return total, coreTreeItems, nil
}

func calRateAndDiffTarget(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, targetMetaMap map[string]*dao.TargetMetaInfo, totalTargetMap map[string]*analysis.TargetCardEntity, rows []*great_value_buy.GetGreatValueBuyMultiDimRow) {
	if len(rows) == 0 {
		return
	}
	for _, row := range rows {
		calRateInOverAll(ctx, req, targetMetaMap, totalTargetMap, row)
		calDiffVsOverAll(ctx, req, targetMetaMap, row)
		calRateAndDiffTarget(ctx, req, targetMetaMap, totalTargetMap, row.Children)
		for _, target := range row.TargetList {
			if strings.Contains(target.Extra.AttributeType, "大促") {
				target.Extra.TargetType = analysis.TargetType_BigActivity
			}
			if strings.Contains(target.Extra.AttributeType, "大盘") {
				target.Extra.TargetType = analysis.TargetType_Overall
			}
			if strings.Contains(target.Name, "diff") {
				target.Extra.TargetType = analysis.TargetType_BigActivityVsOverallDiff
			}
		}
	}

}

func calRateInOverAll(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, targetMetaMap map[string]*dao.TargetMetaInfo, totalTargetMap map[string]*analysis.TargetCardEntity, row *great_value_buy.GetGreatValueBuyMultiDimRow) {
	targetListMap := make(map[string]*analysis.TargetCardEntity)
	for _, target := range row.TargetList {
		targetListMap[target.Name] = target
	}

	actProdNeedGov, overallNeedGov := needGovSubsidy(req)

	for targetName, rule := range BigactCoreTreeExtraTargetsRulesWithGovTarget {
		logs.CtxInfo(ctx, "calRateInOverAll target=%s rule=%+v", targetName, rule)
		_, exist := targetListMap[targetName]
		if !exist {
			logs.CtxInfo(ctx, "目标指标不存在， targetValue = %s", targetName)
			continue
		}
		numerator := pickTargetName(ctx, rule.Numerator, actProdNeedGov, overallNeedGov)
		denominator := pickTargetName(ctx, rule.Denominator, actProdNeedGov, overallNeedGov)
		_, exist = targetListMap[numerator]
		if !exist {
			logs.CtxInfo(ctx, "计算指标%s的分子指标%s不存在", targetName, numerator)
			continue
		}
		_, exist = totalTargetMap[denominator]
		if !exist {
			logs.CtxInfo(ctx, "计算指标%s的分母指标%s不存在", targetName, denominator)
			continue
		}
		if totalTargetMap[denominator].Value == 0 {
			logs.CtxInfo(ctx, "计算指标%s的分母指标%s值为0", targetName, denominator)
			continue
		}
		value := targetListMap[numerator].Value / totalTargetMap[denominator].Value

		if targetListMap[targetName].Extra == nil {
			targetListMap[targetName].Extra = &analysis.TargetCardExtraInfo{}
		}
		targetListMap[targetName].Extra.MarketPercent = value
		targetListMap[targetName].Extra.PercentFlag = true

	}
}

func calDiffVsOverAll(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, targetMetaMap map[string]*dao.TargetMetaInfo, row *great_value_buy.GetGreatValueBuyMultiDimRow) {
	targetListMap := make(map[string]*analysis.TargetCardEntity)
	for _, target := range row.TargetList {
		targetListMap[target.Name] = target
	}

	actProdNeedGov, overallNeedGov := needGovSubsidy(req)
	for targetName, rule := range CoreTreeDiffTargetWithGovTarget {
		_, exist := targetMetaMap[targetName]
		if !exist {
			logs.CtxInfo(ctx, "目标Diff指标不存在，targetName = %s", targetName)
			continue
		}
		minuend := pickTargetName(ctx, rule.Minuend, actProdNeedGov, overallNeedGov)
		subtrahend := pickTargetName(ctx, rule.Subtrahend, actProdNeedGov, overallNeedGov)

		_, exist = targetListMap[minuend]
		if !exist {
			logs.CtxInfo(ctx, "计算指标%s的大促指标%s不存在", targetName, minuend)
			continue
		}
		_, exist = targetListMap[subtrahend]
		if !exist {
			logs.CtxInfo(ctx, "计算指标%s的大盘指标%s不存在", targetName, subtrahend)
			continue
		}
		diffValue := targetListMap[minuend].Value - targetListMap[subtrahend].Value
		diffRateValue := targetListMap[minuend].Extra.MarketPercent - targetListMap[subtrahend].Extra.MarketPercent
		newTarget, err := base_struct_condition.GetTargetEntity(ctx, diffValue, targetMetaMap[targetName])
		if err != nil || newTarget == nil {
			logs.CtxWarn(ctx, "GetTargetEntity err=%v", err)
			continue
		}
		if newTarget.Extra == nil {
			newTarget.Extra = &analysis.TargetCardExtraInfo{}
		}
		newTarget.Extra.MarketPercent = diffRateValue
		newTarget.Extra.PercentFlag = true
		row.TargetList = append(row.TargetList, newTarget)

	}
}

func multiFullToCoreTree(ctx context.Context, rows []*great_value_buy.GetGreatValueBuyMultiDimRow) (treeItems []*great_value_buy.GetGreatValueBuyAttributionCoreTreeData) {
	treeItems = make([]*great_value_buy.GetGreatValueBuyAttributionCoreTreeData, 0)
	for _, row := range rows {
		treeItems = append(treeItems, &great_value_buy.GetGreatValueBuyAttributionCoreTreeData{
			Name:        row.DisplayName,
			TargetList:  row.TargetList,
			ProdTagCode: row.ProdTagCode,
			DimKey:      row.DimKey,
			Children:    multiFullToCoreTree(ctx, row.Children),
			Code:        row.EnumValue,
		})
	}
	return treeItems
}

func genFlowGroupParams(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo) (params map[string]interface{}, err error) {
	flowGroupReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	err = copier.CopyWithOption(flowGroupReq, req, copier.Option{DeepCopy: true})
	groupAttrs := make([]*dimensions.SelectedDimensionInfo, 0)
	flowGroupReqParams := make(map[string]interface{}, 0)
	for _, dimI := range req.BaseReq.Dimensions {
		dimInfo, exist := dimMap[convert.ToInt64(dimI.Id)]
		if !exist {
			logs.CtxError(ctx, "dimension attr err")
			return nil, err
		}
		if dimensions.DimensionAttributeType(dimInfo.DimensionCategory) == dimensions.DimensionAttributeType_Product {
			continue
		}
		selectedDim := &dimensions.SelectedDimensionInfo{
			Id:               dimI.Id,
			Name:             dimI.Name,
			AttrType:         dimI.AttrType,
			SelectedOperator: dimI.SelectedOperator,
			SelectedValues:   dimI.SelectedValues,
		}

		groupAttrs = append(groupAttrs, selectedDim)
	}
	for _, attr := range req.BaseReq.GroupAttrs {
		dimInfo, exist := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if !exist {
			logs.CtxError(ctx, "dimension attr err")
			return nil, err
		}
		if dimensions.DimensionAttributeType(dimInfo.DimensionCategory) == dimensions.DimensionAttributeType_Product {
			continue
		}
		groupAttrs = append(groupAttrs, attr.DimInfo)
	}
	flowGroupReq.BaseReq.Dimensions = groupAttrs
	flowGroupReqParams, _, _, _, _, err = base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: flowGroupReq.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	})
	if err != nil {
		logs.CtxError(ctx, "get flowGroupReqParams err=%v", err)
		return nil, err
	}
	params = map[string]interface{}{}
	params["flow_group_filter_param"] = flowGroupReqParams["filter_param"]

	// 3. 构造大促不含报名状态、大促项目的维度
	noSignUpReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	err = copier.CopyWithOption(noSignUpReq, req, copier.Option{DeepCopy: true})
	noSignUpReqDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dim := range req.BaseReq.Dimensions {
		if dim.Id == "10366" || dim.Id == "10372" {
			continue
		}
		noSignUpReqDimensions = append(noSignUpReqDimensions, dim)
	}
	noSignUpReq.BaseReq.Dimensions = noSignUpReqDimensions
	noSignUpReqParams, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: noSignUpReq.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	})
	if err != nil {
		logs.CtxError(ctx, "get noSignUpReqParams err=%v", err)
		return nil, err
	}
	params["no_sign_up_filter_param"] = noSignUpReqParams["filter_param"]
	// 时间周期参数
	currDateExpr, err := GetBigActOSDateExpr(ctx, req.BaseReq.StartDate, req.BaseReq.EndDate)
	if err != nil {
		return nil, err
	}
	compareDateExpr, err := GetBigActOSDateExpr(ctx, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
	if err != nil {
		return nil, err
	}
	if req.OverallCommonReq != nil && req.OverallCommonReq.IsOpenYoy {
		yoyDateExpr, err := GetBigActOSDateExpr(ctx, req.OverallCommonReq.BaseReq.CompareStartDate, req.OverallCommonReq.BaseReq.CompareEndDate)
		if err != nil {
			return nil, err
		}
		params["yoy_date_expr"] = yoyDateExpr
	}
	params["curr_date_expr"] = currDateExpr
	params["compare_date_expr"] = compareDateExpr
	return params, nil
}

// genGroupFilterParams 多维分组参数，最后生成
func genGroupFilterParams(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo) (params map[string]interface{}, err error) {
	flowGroupReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	err = copier.CopyWithOption(flowGroupReq, req, copier.Option{DeepCopy: true})
	groupAttrs := make([]*dimensions.SelectedDimensionInfo, 0)
	flowGroupReqParams := make(map[string]interface{}, 0)
	//group最新限制
	newGroupAttrs := make([]*dimensions.SelectedMultiDimensionInfo, 0)
	newDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	groupExist := make(map[int64]bool, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		dimInfo, exist := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if !exist {
			logs.CtxError(ctx, "dimension attr err")
			return nil, err
		}
		if groupExist[dimInfo.ID] { // 已经存在
			continue
		}
		if dimensions.DimensionAttributeType(dimInfo.DimensionCategory) == dimensions.DimensionAttributeType_User ||
			dimensions.DimensionAttributeType(dimInfo.DimensionCategory) == dimensions.DimensionAttributeType_Place {
			groupExist[dimInfo.ID] = true
			newGroupAttrs = append(newGroupAttrs, attr)
		}
	}
	for _, dimI := range req.BaseReq.Dimensions {
		dimInfo, exist := dimMap[convert.ToInt64(dimI.Id)]
		if !exist {
			logs.CtxError(ctx, "dimension attr err")
			return nil, err
		}
		if groupExist[dimInfo.ID] {
			continue
		}
		newDimensions = append(newDimensions, dimI)
	}

	for _, dimI := range newDimensions {
		_, exist := dimMap[convert.ToInt64(dimI.Id)]
		if !exist {
			logs.CtxError(ctx, "dimension attr err")
			return nil, err
		}
		selectedDim := &dimensions.SelectedDimensionInfo{
			Id:               dimI.Id,
			Name:             dimI.Name,
			AttrType:         dimI.AttrType,
			SelectedOperator: dimI.SelectedOperator,
			SelectedValues:   dimI.SelectedValues,
		}
		groupAttrs = append(groupAttrs, selectedDim)
	}
	for _, attr := range newGroupAttrs {
		_, exist := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if !exist {
			logs.CtxError(ctx, "dimension attr err")
			return nil, err
		}
		groupAttrs = append(groupAttrs, attr.DimInfo)
	}
	flowGroupReq.BaseReq.Dimensions = groupAttrs
	flowGroupReqParams, _, _, _, _, err = base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: flowGroupReq.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	})
	if err != nil {
		logs.CtxError(ctx, "get flowGroupReqParams err=%v", err)
		return nil, err
	}
	params = map[string]interface{}{}
	params["filter_param"] = flowGroupReqParams["filter_param"]
	// 时间周期参数
	currDateExpr, err := GetBigActOSDateExpr(ctx, req.BaseReq.StartDate, req.BaseReq.EndDate)
	if err != nil {
		return nil, err
	}
	compareDateExpr, err := GetBigActOSDateExpr(ctx, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
	if err != nil {
		return nil, err
	}
	if req.OverallCommonReq != nil && req.OverallCommonReq.IsOpenYoy {
		yoyDateExpr, err := GetBigActOSDateExpr(ctx, req.OverallCommonReq.BaseReq.CompareStartDate, req.OverallCommonReq.BaseReq.CompareEndDate)
		if err != nil {
			return nil, err
		}
		params["yoy_date_expr"] = yoyDateExpr
	}
	params["curr_date_expr"] = currDateExpr
	params["compare_date_expr"] = compareDateExpr
	return params, err
}

func pickTargetName(ctx context.Context, t TargetEnum, actProdNeedGov, overallNeedGov bool) string {
	switch t.TargetType {
	case "大盘":
		if overallNeedGov {
			return t.GovTarget
		}
		return t.WithoutGovTarget
	case "大促":
		if actProdNeedGov {
			return t.GovTarget
		}
		return t.WithoutGovTarget
	default:
		logs.CtxError(ctx, "[calAndPackExtraTargetByRow] 不支持的指标类型")
		return ""
	}
}
