package great_value_buy_service

import (
	"context"
	"errors"
	"fmt"

	"sort"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"github.com/thoas/go-funk"
)

func (d *GreatValueBuyService) GetGreatValueBuyMultiDimensionTableDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangruiwen.raven@bytedance.com"
	}

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取分析的维度信息
	groupCols := make([]*dao.DimensionInfo, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		groupCols = append(groupCols, dimInfo)
	}

	var yoyStartDate, yoyEndDate string
	if req.OverallCommonReq != nil && req.OverallCommonReq.BaseReq != nil {
		yoyStartDate = req.OverallCommonReq.BaseReq.CompareStartDate
		yoyEndDate = req.OverallCommonReq.BaseReq.CompareEndDate
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := d.GetGreatValueBuyMultiDimensionTable(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}

	if req.BaseReq.BizType == dimensions.BizType_BigActivityCore {
		table, targetList := getMultiDimFullTableAndHeaderListForBigact(coreRet, groupCols)
		f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genGetMultiDimFullTable, param.SinkTable("core_data"))
		f.ExeCustom([]param.Source{param.SourceTable("core_data"), param.SourceConst(email), param.SourceConst(req),
			param.SourceConst(fmt.Sprintf("%v ~ %v", yoyStartDate, yoyEndDate)),
			param.SourceConst(targetList), param.SourceConst(groupCols)}, doExportGetMultiDimFullBigactData, nil)
	} else {
		table, targetList := getMultiDimFullTableAndHeaderList(coreRet, groupCols)
		if req.CommonSelectList != nil && len(req.CommonSelectList) > 0 {
			totalList := coreRet.Total.TargetList
			targets, isOk := funk.Filter(totalList, func(item *analysis.TargetCardEntity) bool {
				return slices.Contains(req.CommonSelectList, item.Name)
			}).([]*analysis.TargetCardEntity)

			if isOk {

				if mappedList, ok := funk.Map(targets, func(item *analysis.TargetCardEntity) string {
					return item.DisplayName
				}).([]string); ok {
					targetList = mappedList
				}
			}
		}
		f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genGetMultiDimFullTable, param.SinkTable("core_data"))
		f.ExeCustom([]param.Source{param.SourceTable("core_data"), param.SourceConst(email),
			param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
			param.SourceConst(targetList), param.SourceConst(groupCols)}, doExportGetMultiDimFullData, nil)
	}
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, err
}

func appendFullListForBigact(fullList []*great_value_buy.GetGreatValueBuyMultiDimRow, table []map[string]interface{}, groupCols []*dao.DimensionInfo, groupRecord map[string]string) []map[string]interface{} {
	if len(fullList) == 0 {
		return table
	}
	for _, info := range fullList {
		record := make(map[string]interface{})
		dimKeyRecord := make(map[string]string)
		for i, group := range groupCols {
			if groupVal := groupRecord[group.DimColumn]; len(groupVal) > 0 {
				record[group.DimColumn] = groupVal
				dimKeyRecord[group.DimColumn] = groupVal
			} else if len(groupRecord) == i {
				record[group.DimColumn] = info.DisplayName
				dimKeyRecord[group.DimColumn] = info.DisplayName
			} else {
				record[group.DimColumn] = "-"
			}
		}
		if len(info.TargetList) > 0 {
			sort.SliceStable(info.TargetList, func(i, j int) bool {
				return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
			})
			for _, target := range info.TargetList {
				record[fmt.Sprintf("%v - %v", target.Extra.AttributeType, target.DisplayName)] = target.Value
			}
		}
		table = append(table, record)
		table = appendFullListForBigact(info.Children, table, groupCols, dimKeyRecord)
	}
	return table
}

func appendFullList(fullList []*great_value_buy.GetGreatValueBuyMultiDimRow, table []map[string]interface{}, groupCols []*dao.DimensionInfo, groupRecord map[string]string) []map[string]interface{} {
	if len(fullList) == 0 {
		return table
	}

	for _, info := range fullList {
		record := make(map[string]interface{})
		dimKeyRecord := make(map[string]string)
		for i, group := range groupCols {
			if groupVal := groupRecord[group.DimColumn]; len(groupVal) > 0 {
				record[group.DimColumn] = groupVal
				dimKeyRecord[group.DimColumn] = groupVal
			} else if len(groupRecord) == i {
				record[group.DimColumn] = info.DisplayName
				dimKeyRecord[group.DimColumn] = info.DisplayName
			} else {
				record[group.DimColumn] = "-"
			}
		}
		if len(info.TargetList) > 0 {
			for _, target := range info.TargetList {
				record[target.DisplayName] = target.Value
			}
		}
		table = append(table, record)
		table = appendFullList(info.Children, table, groupCols, dimKeyRecord)
	}
	return table
}

func getMultiDimFullTableAndHeaderList(coreData *great_value_buy.GetGreatValueBuyMultiDimensionData, groupCols []*dao.DimensionInfo) ([]map[string]interface{}, []string) {
	table := make([]map[string]interface{}, 0)
	targetList := make([]string, 0)
	recordTotal := make(map[string]interface{})
	for i, c := range groupCols {
		recordTotal[c.DimColumn] = utils.If(i == 0, "整体", "-")
	}
	if coreData != nil && coreData.Total != nil && len(coreData.Total.TargetList) > 0 {
		for _, target := range coreData.Total.TargetList {
			recordTotal[target.DisplayName] = target.Value
			targetList = append(targetList, target.DisplayName)
		}
	}
	table = append(table, recordTotal)
	if coreData != nil {
		table = appendFullList(coreData.Rows, table, groupCols, make(map[string]string))
	}
	return table, targetList
}

func getMultiDimFullTableAndHeaderListForBigact(coreData *great_value_buy.GetGreatValueBuyMultiDimensionData, groupCols []*dao.DimensionInfo) ([]map[string]interface{}, []string) {
	table := make([]map[string]interface{}, 0)
	targetList := make([]string, 0)
	recordTotal := make(map[string]interface{})
	for i, c := range groupCols {
		recordTotal[c.DimColumn] = utils.If(i == 0, "整体", "-")
	}
	if coreData != nil && coreData.Total != nil && len(coreData.Total.TargetList) > 0 {
		sort.SliceStable(coreData.Total.TargetList, func(i, j int) bool {
			return coreData.Total.TargetList[i].DisplayOrder < coreData.Total.TargetList[j].DisplayOrder
		})
		for _, target := range coreData.Total.TargetList {
			recordTotal[fmt.Sprintf("%v - %v", target.Extra.AttributeType, target.DisplayName)] = target.Value
			targetList = append(targetList, fmt.Sprintf("%v - %v", target.Extra.AttributeType, target.DisplayName))
		}
	}
	table = append(table, recordTotal)
	if coreData != nil {
		table = appendFullListForBigact(coreData.Rows, table, groupCols, make(map[string]string))
	}
	return table, targetList
}

func genGetMultiDimFullTable(ctx context.Context, table []map[string]interface{}) (*onetable.Table, error) {
	return onetable.NewTable(table), nil
}

func doExportGetMultiDimFullData(ctx context.Context, table *onetable.Table, email string, analysisRange string, targetList []string, groupCols []*dao.DimensionInfo) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet("指标列表", table)
	sheet.AddHead([][]string{{"分析周期", analysisRange}})

	for _, group := range groupCols {
		sheet.AddColumn(group.ShowName, group.DimColumn)
	}
	for _, t := range targetList {
		sheet.AddColumn(t, t)
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "超值购专项-多维分析数据")
	return nil, formatter.Export(ctx, email, nil, nil)
}

func doExportGetMultiDimFullBigactData(ctx context.Context, table *onetable.Table, email string, req *great_value_buy.GetGreatValueBuyCommonRequest, yoyAnalysisRange string, targetList []string, groupCols []*dao.DimensionInfo) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet("指标列表", table)
	sheet.AddHead([][]string{{"分析周期", fmt.Sprintf("%v ~ %v", req.BaseReq.StartDate, req.BaseReq.EndDate)}})
	sheet.AddHead([][]string{{"对比周期", fmt.Sprintf("%v ~ %v", req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)}})
	if req.OverallCommonReq.IsOpenYoy {
		sheet.AddHead([][]string{{"YOY周期", yoyAnalysisRange}})
	}
	var bigactDims, overallDims string
	for _, dim := range req.BaseReq.Dimensions {
		if len(dim.SelectedValues) == 0 {
			continue
		}
		dimName := dim.Name
		dimId := dim.Id
		dimSelected := ""
		for _, selected := range dim.SelectedValues {
			dimSelected += fmt.Sprintf("%v ", selected.Name)
		}
		dimSelected = "( " + dimSelected + ")"
		bigactDims += fmt.Sprintf("%v %v %v\n", dimName+"("+dimId+")", dim.SelectedOperator.String(), dimSelected)
	}
	for _, dim := range req.OverallCommonReq.BaseReq.Dimensions {
		if len(dim.SelectedValues) == 0 {
			continue
		}
		dimName := dim.Name
		dimId := dim.Id
		dimSelected := ""
		for _, selected := range dim.SelectedValues {
			dimSelected += fmt.Sprintf("%v ", selected.Name)
		}
		dimSelected = "( " + dimSelected + ")"
		overallDims += fmt.Sprintf("%v %v %v\n", dimName+"("+dimId+")", dim.SelectedOperator.String(), dimSelected)
	}
	sheet.AddHead([][]string{{"大促筛选维度", bigactDims}})
	sheet.AddHead([][]string{{"大盘筛选维度", overallDims}})
	sheet.AddHead([][]string{{"国补指标", fmt.Sprintf("大盘是否含国补：%v，大促是否含国补：%v", req.TargetConfigList.GovTargetConfig.OverallNeedGov, req.TargetConfigList.GovTargetConfig.ActNeedGov)}})
	for _, group := range groupCols {
		sheet.AddColumn(group.ShowName, group.DimColumn)
	}
	for _, t := range targetList {
		sheet.AddColumn(t, t)
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "大促视图-多维分析数据")
	return nil, formatter.Export(ctx, email, nil, nil)
}
