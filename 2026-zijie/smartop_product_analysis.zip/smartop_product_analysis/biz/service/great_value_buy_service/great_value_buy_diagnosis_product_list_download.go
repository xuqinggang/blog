package great_value_buy_service

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
)

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisProductListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp bool, err error) {
	if req.CommonSelectList == nil || len(req.CommonSelectList) > 90 {
		return false, errors.New(fmt.Sprintf("导出维度上限为90，当前已选择%d维度", len(req.CommonSelectList)))
	}
	// 1. 补全信息
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zouguoxue@bytedance.com"
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	// 2. 请求数据
	if req.OrderBy == nil || req.OrderBy.ColumnName == nil {
		// 默认按照GMV排序
		req.OrderBy = &base.OrderByInfo{
			IsDesc:     true,
			ColumnName: convert.ToStringPtr("big_link_gmv"),
		}
	}

	orderBy := &base.OrderByInfo{}

	if req.OrderBy != nil {
		orderBy.Field = req.OrderBy.Field
		orderBy.IsDesc = req.OrderBy.IsDesc
		if req.OrderBy.ColumnName != nil {
			// !important 指标名里面有#所以需要使用``进行包裹
			formattedColName := fmt.Sprintf("`%s`", *req.OrderBy.ColumnName)
			orderBy.ColumnName = &formattedColName
		}
	}

	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    orderBy,
	})
	// 由于列的扩充，这里限制2000条
	curr["limit"] = 2000
	curr["offset"] = 0
	if err != nil {
		return false, err
	}

	err = updateSearchParams(ctx, curr, &req.CommonSelectList)
	if err != nil {
		return false, err
	}

	records, err := base_struct_condition.GetRecordsByOS(ctx, curr, consts.Empty, "7483500020516308005")
	if err != nil {
		return false, err
	}
	targetMetaList, _ := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)

	targetNameMetaMap := make(map[string]*dimensions.TargetMetaInfo, 0)
	for _, targetMeta := range targetMetaList {
		targetNameMetaMap[targetMeta.Name] = targetMeta
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()

	f.ExeQueryCustom([]param.Source{param.SourceConst(records)}, genGetGreatValueBuyDiagnosisProductList, param.SinkTable("data"))
	f.ExeCustom([]param.Source{param.SourceTable("data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetCompareStartDate(), req.BaseReq.GetCompareEndDate())),
		param.SourceConst(targetNameMetaMap), param.SourceConst(keyGroupColsSku), param.SourceConst(req.CommonSelectList)}, doExportGetGreatValueBuyDiagnosisProductListData, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, err
}

func genGetGreatValueBuyDiagnosisProductList(ctx context.Context, table []map[string]interface{}) (*onetable.Table, error) {
	return onetable.NewTable(table), nil
}

func doExportGetGreatValueBuyDiagnosisProductListData(ctx context.Context, table *onetable.Table, email string, analysisRange string, compareRange string, targetMetaMap map[string]*dimensions.TargetMetaInfo, groupCols []string, whiteList []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	tableMap := table.ToRawMap()
	targetRawMap := make([]map[string]interface{}, 0)
	for originCol := range tableMap[0] {
		// 对分组的指标进行特殊处理
		col := ""
		group := ""
		isGroup := strings.Contains(originCol, "#")
		if isGroup {
			values := strings.Split(originCol, "#")
			col = values[0]
			group = values[1]
		} else {
			col = originCol
		}

		if !slices.ContainsString(groupCols, col) {
			metaInfo, exist := targetMetaMap[col]
			if exist && slices.Contains(whiteList, originCol) {
				if isGroup {
					targetRawMap = append(targetRawMap, map[string]interface{}{
						"display_order": metaInfo.DisplayOrder,
						"name":          fmt.Sprintf("%s#%s", metaInfo.DisplayName, group),
						"col_name":      fmt.Sprintf("%s#%s", metaInfo.Name, group),
					})
				} else {
					targetRawMap = append(targetRawMap, map[string]interface{}{
						"display_order": metaInfo.DisplayOrder,
						"name":          metaInfo.DisplayName,
						"col_name":      metaInfo.Name,
					})
				}
			}
		}
	}

	sort.Slice(targetRawMap, func(i, j int) bool {
		// 增加排序逻辑
		iName := convert.ToString(targetRawMap[i]["name"])
		jName := convert.ToString(targetRawMap[j]["name"])

		iisGroup := strings.Contains(iName, "#")
		jisGroup := strings.Contains(jName, "#")

		if !iisGroup && jisGroup {
			return true
		}
		if iisGroup && jisGroup {
			return iName < jName
		}

		valueI := convert.ToInt64(targetRawMap[i]["display_order"])
		valueJ := convert.ToInt64(targetRawMap[j]["display_order"])
		return valueI < valueJ
	})

	sheet1 := lark_export.NewLarkDocSheet("当前周期"+analysisRange, table)
	sheet2 := lark_export.NewLarkDocSheet("对比周期"+compareRange, table)
	for _, keyCol := range keyGroupColsSku {
		colName := keyCol
		mappedName, exist := keyGroupColsSkuName[keyCol]
		if exist {
			colName = mappedName
		}

		sheet1.AddColumn(colName, keyCol)
		sheet2.AddColumn(colName, keyCol)
	}
	for _, h := range targetRawMap {
		sheet1.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
		sheet2.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"])+"_compare")
	}
	formatter.AddSheet(sheet1, sheet2)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "超值购专项-聚合链接单品数据")
	return nil, formatter.Export(ctx, email, nil, nil)
}
