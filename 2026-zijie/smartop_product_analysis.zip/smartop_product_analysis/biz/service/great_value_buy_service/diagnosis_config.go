package great_value_buy_service

import (
	"context"
	"errors"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"
)

func GetCategoryOrder(c string, categoryOrder map[string]int) int64 {
	if order, exist := categoryOrder[c]; exist {
		return convert.ToInt64(order)
	}
	return 999
}
func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisConfig(ctx context.Context, req *great_value_buy.GetGreatValueBuyDiagnosisConfigDataRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisConfigData, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	// 获取业务线的维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionList(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionAnalysisBizList]获取map失败，err=%v+", err)
		return nil, err
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	var dimIdList = make([]int64, 0)
	for id := range dimMap {
		dimIdList = append(dimIdList, id)
	}

	object := &dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao), DimensionEnumDao: new(dao.DimensionEnumDao)}
	dimMapIdl, err := object.GetDimensionMapByIDList(ctx, dimIdList)
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionAnalysisBizList]获取IDL版DimMap失败, err:%v", err.Error())
		return nil, err
	}
	ctx = context.WithValue(ctx, consts.CtxDimMapIDLType, dimMapIdl)

	bizInfoList, err := biz_utils.GetAttributionTreeBizInfo(ctx, &req.BizType)
	if err != nil {
		return nil, err
	}
	targetMeteInfo, err := d.AttributeDao.GetTargetMetaInfo(ctx, int64(req.BizType), nil)
	if err != nil {
		return nil, err
	}
	if len(bizInfoList) > 0 {
		result := bizInfoList[0]
		var targetMeteInfoList = make([]*dimensions.TargetMetaInfo, 0)
		for _, targetItem := range targetMeteInfo {
			if result.BillionConfigMeta == nil {
				result.BillionConfigMeta = &great_value_buy.GetGreatValueBuyDiagnosisConfigData{}
			}
			if result.BillionConfigMeta.TargetConfig == nil {
				result.BillionConfigMeta.TargetConfig = &great_value_buy.GetGreatValueBuyTargetConfig{}
			}
			for _, value := range result.BillionConfigMeta.TargetConfig.ShowTargetList {
				if value.Name == targetItem.Name {
					targetMeteInfoList = append(targetMeteInfoList, &dimensions.TargetMetaInfo{
						Name:          targetItem.Name,
						DisplayName:   targetItem.DisplayName,
						Tips:          targetItem.Tips,
						BizType:       bizInfo.BizType,
						IsDefaultShow: targetItem.IsDefaultShow,
						AttributeType: targetItem.AttributeType,
						DisplayOrder:  int64(targetItem.DisplayOrder),
					})
				}
			}
		}

		if result.BillionConfigMeta == nil {
			result.BillionConfigMeta = &great_value_buy.GetGreatValueBuyDiagnosisConfigData{}
		}
		if result.BillionConfigMeta.TargetConfig == nil {
			result.BillionConfigMeta.TargetConfig = &great_value_buy.GetGreatValueBuyTargetConfig{}
		}
		result.BillionConfigMeta.TargetConfig.ShowTargetList = targetMeteInfoList
		var resBizInfo = &great_value_buy.GetGreatValueBuyDiagnosisConfigData{}
		resBizInfo.TopicList = result.BillionConfigMeta.TopicList
		resBizInfo.CommonDiagnosisTargetList = result.BillionConfigMeta.CommonDiagnosisTargetList
		resBizInfo.TargetConfig = result.BillionConfigMeta.TargetConfig
		resBizInfo.TreeDrill = result.BillionConfigMeta.TreeDrill
		resBizInfo.OptimizeActionConfig = result.BillionConfigMeta.OptimizeActionConfig
		resBizInfo.TopicDimList = result.BillionConfigMeta.TopicDimList
		return resBizInfo, nil
	}
	return &great_value_buy.GetGreatValueBuyDiagnosisConfigData{}, nil

}

func (d *GreatValueBuyService) GetGreatValueBuyProdSQL(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp string, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	dimMap, _ := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
				if dimInfo == nil {
					logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
					return "", errors.New("未查询到维度信息")
				}
				groupCol = dimInfo.DimColumn
			}
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
	}
	curSql, _, _, _ := base_struct_condition.GetBaseConditionWithDims(ctx, req.BaseReq, false, dimMap, false, false)
	fromStr := fmt.Sprintf("%v as tt_search", bizInfo.TableName)
	curSql.Select("distinct prod_id as prod_id").From(fromStr)
	dateExp, _, err := base_struct_condition.GetDateExpr(ctx, utils.If(false, req.BaseReq.CompareStartDate, req.BaseReq.StartDate),
		utils.If(false, req.BaseReq.CompareEndDate, req.BaseReq.EndDate))
	if err != nil {
		return "", err
	}
	curSql.AddWhereAndValue(dateExp)

	return curSql.Compile(), nil
}
