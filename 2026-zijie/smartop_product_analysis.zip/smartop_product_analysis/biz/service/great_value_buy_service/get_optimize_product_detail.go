package great_value_buy_service

import (
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"context"
	"sort"
	"strconv"
	"strings"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/jinzhu/copier"
	"golang.org/x/exp/slices"
)

func GetOptimizeProductDetail(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, optimizeConfigs *great_value_buy.OptimizeActionConfig, itemCode2EstimateGmvMap map[string]string) (resp *great_value_buy.GetOptimizeProductDetailResponse, err error) {
	resp = &great_value_buy.GetOptimizeProductDetailResponse{BaseResp: &base.BaseResp{}}
	tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
	if err != nil {
		return nil, err
	}

	// 参数校验
	result, err := checkAndInitParams(req, optimizeConfigs)
	if err != nil {
		logs.CtxError(ctx, "GetOptimizeProductDetail|checkParams err:%s", err.Error())
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		return
	}
	if !result {
		return
	}

	// 过滤不可优化项
	result = checkAndFillterItem(req, itemCode2EstimateGmvMap)
	if !result {
		return
	}

	// 获取业务线的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 构造流量分组维度
	flowGroupReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	copier.Copy(&flowGroupReq, &req)
	dimension := make([]*dimensions.SelectedDimensionInfo, 0)
	var flowGroupReqParams map[string]interface{}
	for _, attr := range req.BaseReq.Dimensions {
		dimInfo, exist := dimMap[convert.ToInt64(attr.Id)]
		if !exist {
			err = errors.New("dimension attr not exist err")
			return
		}
		if dimensions.DimensionAttributeType(dimInfo.DimensionCategory) == dimensions.DimensionAttributeType_Product {
			continue
		}
		dimension = append(dimension, attr)
	}
	flowGroupReq.BaseReq.Dimensions = dimension
	flowGroupReqParams, err = base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: flowGroupReq.BaseReq,
		DimMap:     dimMap,
		UvFlag:     flowGroupReq.BaseReq.UvFlag,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return
	}
	if len(flowGroupReqParams) <= 0 {
		err = errors.New("GetOptimizeItemDetail|flowGroupReqParams len <= 0")
		return
	}

	// 大盘口径需要带报名状态
	baseCurr, err := base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		UvFlag:     req.BaseReq.UvFlag,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return
	}
	baseCurr["flow_group_filter_param"] = flowGroupReqParams["filter_param"]

	// 构建查询参数
	dms := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, v := range req.BaseReq.Dimensions {
		// 报名状态筛选项
		if v == nil || v.Id == "10372" {
			continue
		}
		dms = append(dms, v)
	}
	req.BaseReq.Dimensions = dms
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		UvFlag:     req.BaseReq.UvFlag,
		PageInfo:   req.PageReq,
		OrderBy:    req.OrderBy,
	}, base_struct_condition.SQLCalcType_Curr)
	if len(curr) <= 0 {
		return nil, errors.New("GetOptimizeProductDetail|cur len <= 0")
	}
	currDateExpr, _ := GetBigActOSDateExpr(ctx, req.BaseReq.StartDate, req.BaseReq.EndDate)
	compareDateExpr, _ := GetBigActOSDateExpr(ctx, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
	baseCurr["curr_date_expr"] = currDateExpr
	baseCurr["compare_date_expr"] = compareDateExpr
	curr["curr_date_expr"] = currDateExpr
	curr["compare_date_expr"] = compareDateExpr
	// 查询基础数据
	baseInfo, err := getBaseInfo(ctx, baseCurr, tableConf)
	if err != nil {
		return nil, err
	}
	if baseInfo == nil {
		return nil, errors.New("GetOptimizeItemDetail|BaseInfo is nil")
	}

	// 查询可优化项商品明细
	curr["sign_prod_thresh"] = baseInfo.GoodProdThresh
	curr["optimize_items"] = toOptimizeItems(req.OptimizeItems)
	optimizeItems, cnt, err := getOptimizeProductItems(ctx, req, curr, tableConf)
	if err != nil {
		return nil, err
	}

	// 补充指标-优化后GMV收益
	fillEstimateGmvValue(ctx, optimizeItems, itemCode2EstimateGmvMap)

	// 组装返回结果
	resp.Data = &great_value_buy.GetOptimizeProductDetailData{
		Prods: toGetOptimizeProductDetail(optimizeItems, optimizeConfigs),
		PageInfo: &base.PageResp{
			Total: cnt,
		},
	}
	return resp, nil
}

func fillEstimateGmvValue(ctx context.Context, items []*OptimizeProdItem, itemCode2EstimateGmvMap map[string]string) {
	if len(itemCode2EstimateGmvMap) <= 0 {
		return
	}
	for _, v := range items {
		if v == nil {
			continue
		}
		v.TargetEntity = append(v.TargetEntity, &analysis.TargetCardEntity{
			Name:              "estimate_increase_gmv",
			Value:             0,
			DisplayValue:      itemCode2EstimateGmvMap[v.ActionCode],
			DisplayName:       "优化后GMV收益",
			Tips:              "",
			CycleValue:        0,
			CycleDisplayValue: "",
			CycleChangeRatio:  0,
			Unit:              "",
			TrendData:         nil,
			Extra: &analysis.TargetCardExtraInfo{
				MarketValue:       0,
				DisplayValue:      "",
				PercentFlag:       false,
				MarketPercent:     0,
				IsLargerAdvantage: false,
				DistributionFlag:  false,
				DistributionValue: 0,
				ProdTagCode:       "",
				TargetTag:         "",
				LeafAvgValue:      nil,
				LeafCompareFlag:   nil,
				IsBetterThanLeaf:  nil,
				AttributeType:     "",
				IsDefaultShow:     false,
				TargetType:        0,
				BurstRate:         0,
			},
			DisplayOrder:      0,
			NeedSecondQuery:   false,
			IsUsePp:           false,
			GroupInfo:         nil,
			DiffExtra:         nil,
			SubTargetList:     nil,
			CompareTrendData:  nil,
			ComparePeriodData: nil,
			ValueType:         "string",
			TargetPrecision:   0,
			IsShow:            false,
			TipInfoList:       nil,
		})
	}
}

func getOptimizeProductItems(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, curr map[string]interface{}, tableConf *tcc.BigActTableConfig) ([]*OptimizeProdItem, int64, error) {
	// 查询商品列表
	var prodItems []*OptimizeProdItem
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(curr, tableConf.ItemOptimize, param.SinkTable("prod_items")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeView(param.SourceTable("prod_items"), &prodItems)
	app.Use(f.ToStack(ctx))
	_, err := app.Run(ctx)
	if len(prodItems) <= 0 {
		return prodItems, 0, nil
	}

	cc := co.NewConcurrent(ctx)

	// 查询可优化项总数
	var cnt int64
	var optimizeItemCurr map[string]interface{}
	copier.Copy(&optimizeItemCurr, &curr)
	optimizeItemCurr["limit"] = 0 // group 分组查询
	cc.GoV2(func() error {
		var optimizeItems []*OptimizeItem
		optimizeItems, err = getOptimizeItems(ctx, optimizeItemCurr, tableConf)
		if err != nil {
			return err
		}
		for _, v := range optimizeItems {
			cnt += v.ProdCnt
		}
		return nil
	})

	// 商品指标详情
	prodIDS := toProdIDS(prodItems)
	var targetCurr map[string]interface{}
	copier.Copy(&targetCurr, &curr)
	targetCurr["prod_ids"] = prodIDS
	var currTargetList []*base_struct_condition.KeyColsTargetEntity
	if value, ok := targetCurr["order_by"]; ok {
		if str, ok1 := value.(string); ok1 {
			targetCurr["order_by"] = strings.Replace(str, "prod_id", "a.prod_id", -1)
		}
	}

	cc.GoV2(func() error {
		// 不做字段过滤
		currTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: targetCurr, Sql: consts.Empty, ApiPath: tableConf.ProdDetailOptimize, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{"prod_id"}, TargetMetaEffectModule: []string{"可优化项详情"},
			FilterTarget: false, FilterTargetNames: nil, // req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return err
		}
		return nil
	})

	// 商品图片
	var productInfoList []*basic_info.ProductBasicInfo
	cc.GoV2(func() error {
		productInfoList, err = biz_utils.GetProductInfoByIdListSlice(ctx, prodIDS)
		if err != nil {
			return err
		}
		return nil
	})

	err = cc.WaitV2()

	if err != nil {
		logs.CtxError(ctx, "[GetAttributionCommonCoreOverview]并发对象wait失败, err:"+err.Error())
		return nil, cnt, err
	}
	// 图片信息
	fillBasicInfo(prodItems, productInfoList)
	// 指标信息
	fillDetails(prodItems, currTargetList)
	// 后处理，指标tag
	fillTargetTags(prodItems)
	// 后处理，指标字段过滤
	//filterTarget(prodItems, req.BaseReq.TargetMetaList)
	// 后处理，指标排序
	sortTargets(prodItems)
	return prodItems, cnt, err
}

func sortTargets(items []*OptimizeProdItem) {
	for _, v := range items {
		if v == nil {
			continue
		}
		if len(v.TargetEntity) <= 0 {
			continue
		}
		sort.Slice(v.TargetEntity, func(i, j int) bool {
			return v.TargetEntity[i].DisplayOrder < v.TargetEntity[j].DisplayOrder
		})
	}
}

func filterTarget(items []*OptimizeProdItem, targets []string) {
	// 默认展示全部
	if len(targets) <= 0 {
		return
	}
	for _, v := range items {
		if v == nil {
			continue
		}
		targetEntitys := make([]*analysis.TargetCardEntity, 0)
		for _, vv := range v.TargetEntity {
			if vv == nil {
				continue
			}
			if slices.Contains(targets, vv.Name) {
				targetEntitys = append(targetEntitys, vv)
			}
		}
		v.TargetEntity = targetEntitys
	}
}

func fillTargetTags(items []*OptimizeProdItem) {
	for _, v := range items {
		if v == nil {
			continue
		}

		// 叶子类目数据
		leafShowCnt := -1.0
		leafOrdCnt := -1.0
		leafGmv := -1.0
		leafOpm := -1.0
		leafGpm := -1.0
		for _, vv := range v.TargetEntity {
			if vv.Name == "leaf_show_cnt" {
				leafShowCnt = vv.Value
			}
			if vv.Name == "leaf_ord_cnt" {
				leafOrdCnt = vv.Value
			}
			if vv.Name == "leaf_gmv" {
				leafGmv = vv.Value
			}
			if vv.Name == "leaf_opm" {
				leafOpm = vv.Value
			}
			if vv.Name == "leaf_gpm" {
				leafGpm = vv.Value
			}
		}

		for _, vv := range v.TargetEntity {
			if vv.Name == "optimize_show_cnt" {
				fillTargetTag(vv, leafShowCnt, "高于叶子类目均值", "低于叶子类目均值", GreenColor, RedColor)
			}
			if vv.Name == "optimize_ord_cnt" {
				fillTargetTag(vv, leafOrdCnt, "高于叶子类目均值", "低于叶子类目均值", GreenColor, RedColor)
			}
			if vv.Name == "optimize_gmv" {
				fillTargetTag(vv, leafGmv, "高于叶子类目均值", "低于叶子类目均值", GreenColor, RedColor)
			}
			if vv.Name == "optimize_opm" {
				fillTargetTag(vv, leafOpm, "高于叶子类目均值", "低于叶子类目均值", GreenColor, RedColor)
			}
			if vv.Name == "optimize_gpm" {
				fillTargetTag(vv, leafGpm, "高于叶子类目均值", "低于叶子类目均值", GreenColor, RedColor)
			}
			if vv.Name == "optimize_quality_score" {
				fillTargetTag(vv, 85, "达标", "未达标", GreenColor, RedColor)
			}
		}
	}
}

type Color string

const (
	RedColor   Color = "1"
	GreenColor Color = "2"
)

func fillTargetTag(vv *analysis.TargetCardEntity, value float64, highTag, lowTag string, highColor, lowColor Color) {
	if vv == nil {
		return
	}
	if vv.Extra == nil {
		vv.Extra = &analysis.TargetCardExtraInfo{}
	}
	if value == -1.0 {
		return
	}
	vv.Extra.ProdTagCode = string(utils.If(vv.Value >= value, highColor, lowColor))
	vv.Extra.TargetTag = utils.If(vv.Value >= value, highTag, lowTag)
}

func fillBasicInfo(items []*OptimizeProdItem, prodBasicInfos []*basic_info.ProductBasicInfo) {
	if len(prodBasicInfos) <= 0 {
		return
	}
	prodMap := make(map[string]*basic_info.ProductBasicInfo)
	for _, v := range prodBasicInfos {
		if v == nil {
			continue
		}
		prodMap[v.Id] = v
	}

	for _, v := range items {
		if v == nil {
			continue
		}
		v.BasicInfo = prodMap[strconv.FormatInt(v.ProdID, 10)]
	}
}

func fillDetails(items []*OptimizeProdItem, prods []*base_struct_condition.KeyColsTargetEntity) {
	if len(prods) <= 0 {
		return
	}
	prodMap := make(map[string][]*analysis.TargetCardEntity)
	for _, v := range prods {
		if v == nil {
			continue
		}
		if len(v.KeyColValues) <= 0 {
			continue
		}
		prodMap[convert.ToString(v.KeyColValues[0])] = v.TargetEntity
	}
	for _, v := range items {
		if v == nil {
			continue
		}
		v.TargetEntity = prodMap[strconv.FormatInt(v.ProdID, 10)]
	}
}

func toProdIDS(items []*OptimizeProdItem) []int64 {
	ids := make([]int64, 0)
	for _, item := range items {
		if item == nil {
			continue
		}
		ids = append(ids, item.ProdID)
	}
	return ids
}

func toGetOptimizeProductDetail(items []*OptimizeProdItem, optimizeConfigs *great_value_buy.OptimizeActionConfig) []*great_value_buy.GetOptimizeProductDetail {
	resp := make([]*great_value_buy.GetOptimizeProductDetail, 0)
	item2Name, crm2Name := initMap(optimizeConfigs)
	for _, v := range items {
		if v == nil {
			continue
		}
		resp = append(resp, &great_value_buy.GetOptimizeProductDetail{
			ProductInfo: toProductInfo(v),
			OptimizeItem: &great_value_buy.OptimizeItem{
				Code: v.ActionCode,
				Name: item2Name[v.ActionCode],
			},
			CrmTask: &great_value_buy.CrmTask{
				Code: v.CrmCode,
				Name: crm2Name[v.CrmCode],
			},
			TargetList: v.TargetEntity,
		})
	}
	return resp
}

func toProductInfo(v *OptimizeProdItem) *basic_info.ProductBasicInfo {
	if v == nil {
		return nil
	}
	resp := &basic_info.ProductBasicInfo{
		Id:        strconv.FormatInt(v.ProdID, 10),
		Name:      "",
		Images:    nil,
		MainImage: "",
	}
	if v.BasicInfo != nil {
		resp.Name = v.BasicInfo.Name
		resp.MainImage = v.BasicInfo.MainImage
		resp.Images = v.BasicInfo.Images
	}
	return resp
}
