package great_value_buy_service

import (
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"errors"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/lang/maths"
	"code.byted.org/gopkg/logs"
	"github.com/leekchan/accounting"

	"context"
)

type IGreatValueBuyService interface {
	GetGreatValueBuyDiagnosisConfig(ctx context.Context, req *great_value_buy.GetGreatValueBuyDiagnosisConfigDataRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisConfigData, err error)
	GetGreatValueBuySupplyAnalysis(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuySupplyAnalysisData, err error)
	GetGreatValueBuyProdSQL(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp string, err error)
	GetGreatValueBuyAttributionCoreTree(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyAttributionCoreTreeDataList, err error)
	GetGreatValueBuyDiagnosisMultiDimension(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisMultiDimensionData, err error)
	GetGreatValueBuyDiagnosisCommonCoreOverview(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisCommonCoreOverviewData, err error)
	GetGreatValueBuyMultiDimensionTable(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyMultiDimensionData, err error)
	GetGreatValueBuyMultiDimensionTableDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp bool, err error)
	GetGreatValueBuyDiagnosisProductList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductData, err error)
	GetGreatValueBuyDiagnosisProductListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp bool, err error)
	GetGreatValueBuyMultiDimTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyMultiDimTrendData, err error)
	GetGreatValueBuyDiagnosisProductListTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductListTrendData, err error)
	GetGreatValueBuyDiagnosisQueryList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQueryAnalysisData, err error)
	GetGreatValueBuyDiagnosisQuerySearchWords(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQuerySearchWordsData, err error)
	GetGreatValueBuyDiagnosisQueryListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp bool, err error)
	GetGreatValueBuyDiagnosisQueryProdList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQueryProdAnalysisData, err error)
	GetGreatValueBuyDiagnosisQueryProdListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp bool, err error)
	GetGreatValueBuyDiagnosisQuerySearchCntTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductListTrendData, err error)
	GetGreatValueBuyCommonDiagnosisConclusion(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetMultiDimCoreConclusionData, err error)
	GetOptimizeActionInfo(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.DimensionActionIncomeSummary, err error)
	SendAttributionReport(ctx context.Context, req *great_value_buy.SendAttributionReportRequest) (err error)
}

type GreatValueBuyService struct {
	DimensionListDao      dao.IDimensionListDao
	DimensionEnumDao      dao.IDimensionEnumDao
	AttributeDao          dao.IAttributeDao
	DimensionService      dimension_service.IDimensionService
	DimensionBizListDao   dao.IDimensionBizListDao
	AttributionTreeBizDao dao.IAttributionTreeBizDao
	AnalysisService       analysis_service.IAnalysisService
}

const (
	SubScenarioInfoForKeyInSupply     = 2 // 重点引入供给
	SubScenarioInfoForSuggestInSupply = 3 //建议引入供给
)

const (
	BigLinkSupplyApi = "7482933338576061449"
	SearchSupplyApi  = "7478691003461862426"

	// 搜索三期
	SearchSupplyShowMoreThanLeafTopApi = "7507615930004898825"
	SearchSupplyGPMMoreThanLeafTopApi  = "7507621953935574067"

	BigLinkOverView      = "7482938770782684211"
	SearchOverView       = "7480165970980422708"
	SearchOptimizeAction = "7486388971761665050"

	BigLinkFirstLocationsApi     = "7525719947012572160"
	BigLinkFirstLocationTrendApi = "7524631534767211555"

	SearchQueryListApi                = "7491240015935144970"
	SearchQueryListOverallApi         = "7491445049637504034"
	SearchQueryProdListApi            = "7491244472898946098"
	SearchQuerySearchWordEnumApi      = "7493117906784355355"
	SearchQueryCntCanFilterSearchWord = "7491149096779088905"

	SearchQueryProdListOverallApi = "7491460059218609186"
	SearchQueryTrendApi           = "7491962784352142345"

	SearchTopTopGmvQueryListTotalApi = "7493795423610471463" // 20% 搜索词数量

	SearchTopGmvQueryDetailListApi          = "7493815131349009445"
	SearchTopGmvQueryProdListOverallApi     = "7494240310986376218"
	SearchTopGmvQueryProdDetailListApi      = "7494176774746555418"
	SearchTopGmvSearchWordEnumApi           = "7493802657379894281"
	SearchQueryTopGmvCntCanFilterSearchWord = "7491149397644903434"
	SearchQueryTopGmvTrendApi               = "7493848098008007731"

	BigActActivityApi                        = "7503448967582123008"
	BigActOverallApi                         = "7503797654103622707"
	BigActDimensionSummaryCoreTreeApi        = "7510123747584541722"
	BigActDimensionSummaryOverallCoreTreeApi = "7510126672520266761"
	BigActDimensionFunnelCoreTreeApi         = "7510153713378427913"
	BigActDimensionFunnelOverallCoreTreeApi  = "7510156976811213861"
	BigActivityShowPvDiagnosis               = "7511630394127549466"
	BigActivityGpmQualityDiagnosis           = "7511652452802905126"
	BigActivityGpmContentPvDiagnosis         = "7511652092797371419"
	BigActivityOpportunityProdDiagnosis      = "7511706744536532018"
	BigActivityProdCommissionDiagnosis       = "7511702029060949029"
	DiagnosisDependBigActActivityApi         = "7515316618864395291" //诊断依赖大促指标
	DiagnosisDependBigActOverallApi          = "7515314551324197898" //诊断依赖大盘指标

	// 搜索三期供给表改成雪婷的40w表
	SearchKeyInSupplyProdApi        = "7505011410653512742"
	SearchSuggestInSupplyProdApi    = "7505018792477525019"
	SearchKeyInSupplyProdDetail     = "7505044045333349427"
	SearchSuggestInSupplyProdDetail = "7505244018318525467"

	BigActActivityApiAggre = "7516026524110259226"
	BigActOverallApiAggre  = "7516021505856128037"

	BigActDimensionSummaryCoreTreeApiAgg        = "7516106198882468873"
	BigActDimensionSummaryOverallCoreTreeApiAgg = "7516098609645896755"
	BigActDimensionFunnelCoreTreeApiAgg         = "7516108101716689958"
	BigActDimensionFunnelOverallCoreTreeApiAgg  = "7516098708220560393"
	BigActivityShowPvDiagnosisAgg               = "7516110413424051226"
	BigActivityGpmQualityDiagnosisAgg           = "7516113205115012123"
	BigActivityGpmContentPvDiagnosisAgg         = "7511652092797371419"
	BigActivityOpportunityProdDiagnosisAgg      = "7516115164194817075"
	BigActivityProdCommissionDiagnosisAgg       = "7516114451221726218"
	DiagnosisDependBigActActivityApiAgg         = "7516113683718751283" //诊断依赖大促指标
	DiagnosisDependBigActOverallApiAgg          = "7516110291193693193" //诊断依赖大盘指标

	BigActivityLarkDataApiAggre           = "7517963154022794277"
	BigActivityOverallLarkDataApiAggre    = "7519056915519833115"
	BigActivityQSLarkDataApiAggre         = "7519036520708228105"
	BigActivityCommissionLarkDataApiAggre = "7519062660646847525"

	BigActivityGpmQualityDiagnosisAgg_new_cluster      = "7532359302003147803"
	BigActivityOpportunityProdDiagnosisAgg_new_cluster = "7532359453266510886"
	BigActivityProdCommissionDiagnosisAgg_new_cluster  = "7532359378469422130"
)

var needBurstRateApiList = []string{
	BigActivityGpmQualityDiagnosisAgg,
	BigActivityOpportunityProdDiagnosisAgg,
	BigActivityProdCommissionDiagnosisAgg,
	BigActivityGpmQualityDiagnosisAgg_new_cluster,
	BigActivityOpportunityProdDiagnosisAgg_new_cluster,
	BigActivityProdCommissionDiagnosisAgg_new_cluster,
}

// 可优化项相关api
const (
	OptimizeItemDetailApi      = "7509758688391873546"
	OptimizeItemBaseDataApi    = "7509813671795672074"
	OptimizeProductApi         = "7510171112031011849"
	OptimizeItemDetailAggApi   = "7516475227568718900"
	OptimizeItemBaseDataAggApi = "7516486317581157410"
	OptimizeProductAggApi      = "7516486458291569699"
)

const (
	InvalidCategoryCode = "-999"
)

var searchSupplyApiList = []string{SearchSupplyGPMMoreThanLeafTopApi, SearchSupplyShowMoreThanLeafTopApi, SearchSupplyApi}

const (
	QuerySearchWord           = "subsidy_relation_query_cnt"
	QueryGMVTop20ppSearchWord = "subsidy_gmv_top20_query_cnt"
)

var targetDimensionMap = map[string]int64{
	"billion_prod_cnt":             10038,
	"billion_prod_search_show_cnt": 10298,
	"new_supply_link_cnt":          10345,
	"offline_supply_link_cnt":      10346,
	"no_change_supply_link_cnt":    10347,
}

// k,v 分子，分母
var targetParentTargetMap = map[string]string{
	//"billion_prod_cnt":             "billion_prod_cnt",
	"billion_prod_search_show_cnt": "billion_prod_search_show_cnt",
	"new_supply_link_cnt":          "new_supply_link_cnt",
	"offline_supply_link_cnt":      "offline_supply_link_cnt",
	"no_change_supply_link_cnt":    "no_change_supply_link_cnt",
	"show_more_than_left_cate_20":  "billion_prod_search_show_cnt",
	"gpm_more_than_left_cate_20":   "billion_prod_search_show_cnt",
}

var clusterDimensionMap = map[string]bool{
	"is_ad_flow":      true,
	"is_cross_border": true,
	"content_type":    true,
	"first_location":  true,
	"second_location": true,
	"date":            true,
}

var diagnosisApiMap = map[great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType]string{
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_ClusterDiff:                  "7483296384523797542",
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_ClusterAvgDiff:               "7483312035552445449",
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_WholeDiff:                    "7483308444246705190",
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_CommonScore:                  "7483314390276523034",
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchSupply:                 "7486041508932617250",
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchOptimize:               "7486050842185892916",
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchQueryCnt:               SearchQueryCntCanFilterSearchWord,
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchTopQueryCnt:            SearchQueryTopGmvCntCanFilterSearchWord,
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchKeyInSupplyProdCnt:     "7505011410653512742",
	great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchSuggestInSupplyProdCnt: "7505018792477525019",
}

func getDiagnosisOverviewApi(ctx context.Context, targetType great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType) (string, error) {
	tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
	if err != nil {
		return "", err
	}
	var BigActDiagnosisApiMap = map[great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType]string{
		great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_BigActivityShowPvDiagnosis:          tableConf.NewAndOldProdMultiTable,
		great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_BigActivityGpmQualityDiagnosis:      tableConf.QualityScore85MultiTable,
		great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_BigActivityOpportunityProdDiagnosis: tableConf.OpportunityProdMultiTable,
		great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_BigActivityProdCommissionDiagnosis:  tableConf.CommissionRateMultiTable,
	}
	if api, ok := BigActDiagnosisApiMap[targetType]; ok {
		return api, nil
	}
	return "", errors.New("not found api for target type")
}

var SearchChannelApi = []string{
	"7486041508932617250",                   // 供给
	SearchQueryCntCanFilterSearchWord,       // 搜索词数量
	SearchQueryTopGmvCntCanFilterSearchWord, // 搜索词top20数量
	SearchQueryTrendApi,                     // 搜索词趋势
	SearchQueryTopGmvTrendApi,               // 搜索词top20趋势
	SearchQuerySearchWordEnumApi,            // 搜索词列表
	SearchTopGmvSearchWordEnumApi,           // 搜索词top20列表
	SearchQueryListApi,                      // query列表
	SearchQueryProdListApi,                  // query商品列表
}

var SearchInSupplyChannelApi = []string{
	"7509002604395906060", // 重点引入供给品
	"7509003002515112971", // 建议引入供给品
	"7505011410653512742",
	"7505018792477525019",
}

var TargetGranularityTypeMap = map[great_value_buy.TargetGranularityType][]string{
	great_value_buy.TargetGranularityType_BigLinkCluster: {
		"cluster_show_pv",
		"cluster_gmv",
		"cluster_order_cnt",
		"cluster_opm",
		"cluster_gpm",
	},
	great_value_buy.TargetGranularityType_BigLink: {
		"big_link_show_pv",
		"big_link_gmv",
		"big_link_order_cnt",
		"big_link_opm",
		"big_link_gpm",
		"big_link_in_cluster_show_pv_rate",
		"big_link_in_cluster_gmv_rate",
		"big_link_in_cluster_order_cnt_rate",
	},
}

var diagnosisDrillDimensionMap = map[dimensions.BizType][]string{
	dimensions.BizType_GreatValueBuyBigLink: {"10026", "10027"},
	dimensions.BizType_GreatValueBuySearch:  {"10295", "10027"}, // 暂定超值购搜索可优化商品下钻维度 一级子赛道 二级类目
}

type GovTargetsDivision struct {
	Numerator   TargetEnum
	Denominator TargetEnum
}

type TargetEnum struct {
	TargetType       string
	GovTarget        string
	WithoutGovTarget string
}

var BigactExtraTargetsDivisionRulesWithGovTarget = map[string]GovTargetsDivision{
	"bigact_accumulate_gmv_in_overall": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_gmv_gov", WithoutGovTarget: "bigact_accumulate_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
	},
	"bigact_accumulate_increase_gmv_in_overall": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_increase_gmv_gov", WithoutGovTarget: "bigact_accumulate_increase_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	},
}

var BigactExtraTargetsDivisionTotalRulesWithGovTarget = map[string]GovTargetsDivision{
	"avg_gmv_in_overall_total": {
		Numerator:   TargetEnum{TargetType: "大盘", GovTarget: "avg_gmv_gov", WithoutGovTarget: "avg_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "avg_gmv_gov", WithoutGovTarget: "avg_gmv"},
	}, // 日均GMV占比大盘
	"avg_gmv_increase_in_overall_total": {
		Numerator:   TargetEnum{TargetType: "大盘", GovTarget: "avg_gmv_increase_gov", WithoutGovTarget: "avg_gmv_increase"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "avg_gmv_increase_gov", WithoutGovTarget: "avg_gmv_increase"},
	}, // 日均GMV增量占比大盘增量
	"bigact_avg_gmv_in_overall_total": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_avg_gmv_gov", WithoutGovTarget: "bigact_avg_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "avg_gmv_gov", WithoutGovTarget: "avg_gmv"},
	}, // 大促日均GMV占比大盘
	"bigact_avg_gmv_increase_in_overall_total": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_avg_gmv_increase_gov", WithoutGovTarget: "bigact_avg_gmv_increase"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "avg_gmv_increase_gov", WithoutGovTarget: "avg_gmv_increase"},
	}, // 大促日均GMV增量占比大盘增量
	"score_more_than_85_increase_gmv_rate": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "score_more_than_85_increase_gmv_gov", WithoutGovTarget: "score_more_than_85_increase_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	}, // 85分以上商品占比累计大盘增量
	"commission_reach_increase_gmv_rate": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "commission_reach_increase_gmv_gov", WithoutGovTarget: "commission_reach_increase_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	}, // 佣金达标率增量占比累计大盘增量
}

//// BigactExtraTargetsDivisionRules 新指标：{分子 ：分母}
//var BigactExtraTargetsDivisionRules = map[string]map[string]string{
//	"avg_gmv_in_overall":                       {"avg_gmv": "avg_gmv"},                                                      // 日均GMV占比大盘
//	"avg_gmv_increase_in_overall":              {"avg_gmv_increase": "avg_gmv_increase"},                                    // 日均GMV增量占比大盘增量
//	"bigact_avg_gmv_in_overall":                {"bigact_avg_gmv": "avg_gmv"},                                               // 大促日均GMV占比大盘
//	"bigact_avg_gmv_increase_in_overall":       {"bigact_avg_gmv_increase": "avg_gmv_increase"},                             // 大促日均GMV增量占比大盘增量
//	"avg_gmv_in_overall_gov":                   {"avg_gmv_gov": "avg_gmv_gov"},                                              // 日均GMV占比大盘（包含国补）
//	"avg_gmv_increase_in_overall_gov":          {"avg_gmv_increase_gov": "avg_gmv_increase_gov"},                            // 日均GMV增量占比大盘增量（包含国补）
//	"bigact_avg_gmv_in_overall_gov":            {"bigact_avg_gmv_gov": "avg_gmv_gov"},                                       // 大促日均GMV占比大盘（包含国补）
//	"bigact_avg_gmv_increase_in_overall_gov":   {"bigact_avg_gmv_increase_gov": "avg_gmv_increase_gov"},                     // 大促日均GMV增量占比大盘增量（包含国补）
//	"score_more_than_85_increase_gmv_rate":     {"score_more_than_85_increase_gmv": "accumulate_increase_gmv"},              // 85分以上商品占比累计大盘增量
//	"score_more_than_85_increase_gmv_rate_gov": {"score_more_than_85_increase_gmv_rate_gov": "accumulate_increase_gmv_gov"}, // 85分以上商品占比累计大盘增量 （包含国补）
//	"commission_reach_increase_gmv_rate":       {"commission_reach_increase_gmv": "accumulate_increase_gmv"},                // 佣金达标率增量占比累计大盘增量
//	"commission_reach_increase_gmv_rate_gov":   {"commission_reach_increase_gmv_rate_gov": "accumulate_increase_gmv_gov"},   // 佣金达标率增量占比累计大盘增量 （包含国补）
//}

var BigactCoreTreeExtraTargetsRulesWithGovTarget = map[string]GovTargetsDivision{
	"bigact_accumulate_increase_gmv": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_increase_gmv_gov", WithoutGovTarget: "bigact_accumulate_increase_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	}, // 大促累计增量GMV占比
	"bigact_accumulate_gmv": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_gmv_gov", WithoutGovTarget: "bigact_accumulate_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
	}, // 大促累计GMV占比
	"bigact_accumulate_increase_gmv_gov": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_increase_gmv_gov", WithoutGovTarget: "bigact_accumulate_increase_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	}, // 大促累计增量GMV占比
	"bigact_accumulate_gmv_gov": {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_gmv_gov", WithoutGovTarget: "bigact_accumulate_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
	}, // 大促累计GMV占比
	"accumulate_increase_gmv": {
		Numerator:   TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	}, // 累计增量GMV占比(vs含国补)
	"accumulate_gmv": {
		Numerator:   TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
	}, // 累计GMV占比(vs含国补)
	"accumulate_increase_gmv_gov": {
		Numerator:   TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	}, // 累计增量GMV占比(vs含国补)
	"accumulate_gmv_gov": {
		Numerator:   TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
	}, // 累计GMV占比(vs含国补)
}

// BigactCoreTreeExtraTargetsRules 原指标.market_persent：{分子 ：分母}
var BigactCoreTreeExtraTargetsRules = map[string]map[string]string{
	"bigact_accumulate_increase_gmv": {"bigact_accumulate_increase_gmv": "accumulate_increase_gmv"},
	"bigact_accumulate_gmv":          {"bigact_accumulate_gmv": "accumulate_gmv"},
	//"accumulate_increase_gmv":            {"accumulate_increase_gmv": "accumulate_increase_gmv_gov"},
	//"accumulate_gmv":                     {"accumulate_gmv": "accumulate_gmv_gov"},
	"bigact_accumulate_increase_gmv_gov": {"bigact_accumulate_increase_gmv_gov": "accumulate_increase_gmv_gov"},
	"bigact_accumulate_gmv_gov":          {"bigact_accumulate_gmv_gov": "accumulate_gmv_gov"},
	"accumulate_increase_gmv_gov":        {"accumulate_increase_gmv_gov": "accumulate_increase_gmv_gov"},
	"accumulate_gmv_gov":                 {"accumulate_gmv_gov": "accumulate_gmv_gov"},
}

// BigActDiagnosisExtraTargetsRules 诊断指标增量GMV占比，新指标：{分子 ：分母}
var BigActDiagnosisExtraTargetsRules = map[string]map[string]string{
	"score_more_than_85_increase_gmv_rate":     {"score_more_than_85_increase_gmv": "accumulate_increase_gmv_gov"},
	"commission_reach_increase_gmv_rate":       {"commission_reach_increase_gmv": "accumulate_increase_gmv_gov"},
	"score_more_than_85_increase_gmv_rate_gov": {"score_more_than_85_increase_gmv_gov": "accumulate_increase_gmv_gov"},
	"commission_reach_increase_gmv_rate_gov":   {"commission_reach_increase_gmv_gov": "accumulate_increase_gmv_gov"},
}

var BigActTagDiffRules = map[great_value_buy.BigActIncreaseTagType]GovTargetsDiff{
	great_value_buy.BigActIncreaseTagType_Diff_AccumulateIncreaseGMV: {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_increase_gmv_gov", WithoutGovTarget: "bigact_accumulate_increase_gmv"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	},
	// todo ZGX
	great_value_buy.BigActIncreaseTagType_Diff_ValidProdAvgIncreaseGMV: {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_selling_prod_avg_increase_gmv_gov", WithoutGovTarget: "bigact_selling_prod_avg_increase_gmv"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "selling_prod_avg_increase_gmv_gov", WithoutGovTarget: "selling_prod_avg_increase_gmv"},
	},
}

var BigActTagRatioRules = map[great_value_buy.BigActIncreaseTagType]GovTargetsDivision{
	great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallRate: {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_gmv_gov", WithoutGovTarget: "bigact_accumulate_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
	},
}

var BigActTagRatioTotalRules = map[great_value_buy.BigActIncreaseTagType]GovTargetsDivision{
	great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallTotalRate: {
		Numerator:   TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_gmv_gov", WithoutGovTarget: "bigact_accumulate_gmv"},
		Denominator: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
	},
}

type GovTargetsDiff struct {
	Minuend    TargetEnum
	Subtrahend TargetEnum
}

var CoreTreeDiffTargetWithGovTarget = map[string]GovTargetsDiff{
	"accumulate_increase_gmv_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_increase_gmv_gov", WithoutGovTarget: "bigact_accumulate_increase_gmv"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_increase_gmv_gov", WithoutGovTarget: "accumulate_increase_gmv"},
	},
	"accumulate_gmv_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_gmv_gov", WithoutGovTarget: "bigact_accumulate_gmv"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_gov", WithoutGovTarget: "accumulate_gmv"},
	},
	"accumulate_gmv_burst_rate_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_gmv_burst_rate_gov", WithoutGovTarget: "bigact_accumulate_gmv_burst_rate"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gmv_burst_rate_gov", WithoutGovTarget: "accumulate_gmv_burst_rate"},
	},
	"new_prod_accumulate_gmv_burst_rate_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_new_prod_accumulate_gmv_burst_rate_gov", WithoutGovTarget: "bigact_new_prod_accumulate_gmv_burst_rate"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "new_prod_accumulate_gmv_burst_rate_gov", WithoutGovTarget: "new_prod_accumulate_gmv_burst_rate"},
	},
	"old_prod_accumulate_gmv_burst_rate_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_old_prod_accumulate_gmv_burst_rate_gov", WithoutGovTarget: "bigact_old_prod_accumulate_gmv_burst_rate"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "old_prod_accumulate_gmv_burst_rate_gov", WithoutGovTarget: "old_prod_accumulate_gmv_burst_rate"},
	},
	"accumulate_show_pv_burst_rate_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_show_pv_burst_rate", WithoutGovTarget: "bigact_accumulate_show_pv_burst_rate"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_show_pv_burst_rate", WithoutGovTarget: "accumulate_show_pv_burst_rate"},
	},
	"accumulate_opm_burst_rate_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_opm_burst_rate", WithoutGovTarget: "bigact_accumulate_opm_burst_rate"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_opm_burst_rate", WithoutGovTarget: "accumulate_opm_burst_rate"},
	},
	"accumulate_gpm_burst_rate_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_gpm_burst_rate_gov", WithoutGovTarget: "bigact_accumulate_gpm_burst_rate"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_gpm_burst_rate_gov", WithoutGovTarget: "accumulate_gpm_burst_rate"},
	},
	"accumulate_order_cnt_burst_rate_diff": {
		Minuend:    TargetEnum{TargetType: "大促", GovTarget: "bigact_accumulate_order_cnt_burst_rate_gov", WithoutGovTarget: "bigact_accumulate_order_cnt_burst_rate"},
		Subtrahend: TargetEnum{TargetType: "大盘", GovTarget: "accumulate_order_cnt_burst_rate_gov", WithoutGovTarget: "accumulate_order_cnt_burst_rate"},
	},
}

// CoreTreeDiffTarget 新指标：{被减数 ：减数}
var CoreTreeDiffTarget = map[string]map[string]string{
	"accumulate_increase_gmv_diff":            {"bigact_accumulate_increase_gmv": "accumulate_increase_gmv_gov"},
	"accumulate_gmv_diff":                     {"bigact_accumulate_gmv": "accumulate_gmv_gov"},
	"accumulate_gmv_burst_rate_diff":          {"bigact_accumulate_gmv_burst_rate": "accumulate_gmv_burst_rate_gov"},
	"new_prod_accumulate_gmv_burst_rate_diff": {"bigact_new_prod_accumulate_gmv_burst_rate": "new_prod_accumulate_gmv_burst_rate_gov"},
	"old_prod_accumulate_gmv_burst_rate_diff": {"bigact_old_prod_accumulate_gmv_burst_rate": "old_prod_accumulate_gmv_burst_rate_gov"},
	"accumulate_show_pv_burst_rate_diff":      {"bigact_accumulate_show_pv_burst_rate": "accumulate_show_pv_burst_rate"},
	"accumulate_opm_burst_rate_diff":          {"bigact_accumulate_opm_burst_rate": "accumulate_opm_burst_rate"},
	"accumulate_gpm_burst_rate_diff":          {"bigact_accumulate_gpm_burst_rate": "accumulate_gpm_burst_rate_gov"},
	"accumulate_order_cnt_burst_rate_diff":    {"bigact_accumulate_order_cnt_burst_rate": "accumulate_order_cnt_burst_rate_gov"},

	// 国补
	"accumulate_increase_gmv_gov_diff":            {"bigact_accumulate_increase_gmv_gov": "accumulate_increase_gmv_gov"},
	"accumulate_gmv_gov_diff":                     {"bigact_accumulate_gmv_gov": "accumulate_gmv_gov"},
	"accumulate_gmv_burst_rate_gov_diff":          {"bigact_accumulate_gmv_burst_rate_gov": "accumulate_gmv_burst_rate_gov"},
	"new_prod_accumulate_gmv_burst_rate_gov_diff": {"bigact_new_prod_accumulate_gmv_burst_rate_gov": "new_prod_accumulate_gmv_burst_rate_gov"},
	"old_prod_accumulate_gmv_burst_rate_gov_diff": {"bigact_old_prod_accumulate_gmv_burst_rate_gov": "old_prod_accumulate_gmv_burst_rate_gov"},
	"accumulate_gpm_burst_rate_gov_diff":          {"bigact_accumulate_gpm_burst_rate_gov": "accumulate_gpm_burst_rate_gov"},
	"accumulate_order_cnt_burst_rate_gov_diff":    {"bigact_accumulate_order_cnt_burst_rate_gov": "accumulate_order_cnt_burst_rate_gov"},
}

func DumpLogs(ctx context.Context, key string, targets []*analysis.TargetCardEntity) {
	for _, target := range targets {
		if target == nil {
			continue
		}
		if target.ComparePeriodData == nil {
			target.ComparePeriodData = analysis.NewComparePeriodData()
		}
		if target.DiffExtra == nil {
			target.DiffExtra = analysis.NewDiffExtraInfo()
		}
		logs.CtxInfo(ctx, "key=%v,cur_value=%v\ncom_value=%v,com_diff=%v,com_diff_ratio=%v\n"+
			"cycle_value=%v,cycle_diff=%v,cycle_diff_ratio=%v\n"+
			"sync_value=%v,sync_diff=%v,sync_diff_ratio=%v", key,
			target.Value, target.ComparePeriodData.CompareValue, target.ComparePeriodData.CompareDiff, target.ComparePeriodData.CompareChangeRatio,
			target.CycleValue, target.DiffExtra.Diff, target.CycleChangeRatio,
			target.ComparePeriodData.SyncValue, target.ComparePeriodData.SyncDiff, target.ComparePeriodData.SyncChangeRatio,
		)
	}
}

// TargetUnitOptimize 指标单位优化
func TargetUnitOptimize(targets []*analysis.TargetCardEntity) {
	//thresh := 1e4
	//for _, target := range targets {
	//	if target == nil {
	//		continue
	//	}
	//	ac := &accounting.Accounting{Precision: 2}
	//	if strings.Contains(target.Name, "show_pv") ||
	//		strings.Contains(target.Name, "gmv") ||
	//		strings.Contains(target.Name, "order_cnt") ||
	//		strings.Contains(target.Name, "link_cnt") {
	//		if maths.AbsFloat64(target.Value) > thresh {
	//			target.DisplayValue = framework_udf.DeleteZeroSuffix(ac.FormatMoney(target.Value))
	//		}
	//		if maths.AbsFloat64(target.CycleValue) > thresh {
	//			target.CycleDisplayValue = framework_udf.DeleteZeroSuffix(ac.FormatMoney(target.CycleValue))
	//		}
	//		if target.ComparePeriodData != nil && maths.AbsFloat64(target.ComparePeriodData.CompareValue) > thresh {
	//			target.ComparePeriodData.CompareDisplayValue = framework_udf.DeleteZeroSuffix(ac.FormatMoney(target.ComparePeriodData.CompareValue))
	//		}
	//		if target.ComparePeriodData != nil && maths.AbsFloat64(target.ComparePeriodData.CompareDiff) > thresh {
	//			target.ComparePeriodData.CompareDiffDisplayValue = framework_udf.DeleteZeroSuffix(ac.FormatMoney(target.ComparePeriodData.CompareDiff))
	//		}
	//		if target.ComparePeriodData != nil && maths.AbsFloat64(target.ComparePeriodData.SyncValue) > thresh {
	//			target.ComparePeriodData.SyncDiffDisplayValue = framework_udf.DeleteZeroSuffix(ac.FormatMoney(target.ComparePeriodData.SyncValue))
	//		}
	//		if len(target.TrendData) > 0 {
	//			TrendTargetUnitOptimize(target.TrendData)
	//		}
	//	}
	//}
}

// TrendTargetUnitOptimize 趋势图指标单位优化
func TrendTargetUnitOptimize(targetPoints []*analysis.TargetTrendPoint) {
	thresh := 1e4
	for _, target := range targetPoints {
		if target == nil {
			continue
		}
		ac := &accounting.Accounting{Precision: 2}
		if strings.Contains(target.Name, "show_pv") ||
			strings.Contains(target.Name, "gmv") ||
			strings.Contains(target.Name, "order_cnt") ||
			strings.Contains(target.Name, "link_cnt") {
			if maths.AbsFloat64(target.Value) > thresh {
				target.DisplayValue = framework_udf.DeleteZeroSuffix(ac.FormatMoney(target.Value))
			}
		}
	}
}

const (
	targetAvgGMV                         = "avg_gmv"
	targetGMVBurstRate                   = "gmv_burst_rate"
	targetAvgGMVIncrease                 = "avg_gmv_increase"
	targetBigactAvgGMV                   = "bigact_avg_gmv"
	targetBigactGMVBurstRate             = "bigact_gmv_burst_rate"
	targetBigactAvgGMVIncrease           = "bigact_avg_gmv_increase"
	targetAvgGMVYOYRate                  = "avg_gmv_yoy_rate"
	targetAccumulateGMVIncreaseGov       = "accumulate_increase_gmv_gov"
	targetBigactAccumulateGMVIncrease    = "bigact_accumulate_increase_gmv"
	targetBigactAccumulateGMVIncreaseGov = "bigact_accumulate_increase_gmv_gov"
)

// 判断是否需要国补
func needGovSubsidy(req *great_value_buy.GetGreatValueBuyCommonRequest) (actProdNeedGov, overallNeedGov bool) {
	if req.TargetConfigList != nil && req.TargetConfigList.GovTargetConfig != nil {
		if req.TargetConfigList.GovTargetConfig.ActNeedGov {
			actProdNeedGov = true
		}
		if req.TargetConfigList.GovTargetConfig.OverallNeedGov {
			overallNeedGov = true
		}
	}
	return
}

var GovTargetNameList = []string{
	"avg_gmv_gov",
	"gmv_burst_rate_gov",
	"avg_gmv_in_overall_total_gov",
	"avg_gmv_increase_gov",
	"avg_gmv_increase_in_overall_total_gov",
	"bigact_avg_gmv_gov",
	"bigact_avg_gmv_in_overall_total_gov",
	"bigact_gmv_burst_rate_gov",
	"bigact_avg_gmv_increase_gov",
	"bigact_avg_gmv_increase_in_overall_total_gov",
	"avg_gmv_yoy_rate_gov",
	"avg_gpm_gov",
	"avg_pay_amt_gov",
	"bigact_avg_gpm_gov",
	"bigact_avg_pay_amt_gov",
	"avg_gpm_yoy_rate_gov",
	"avg_pay_amt_yoy_rate_gov",
	"bigact_accumulate_increase_gmv_gov",
	"accumulate_increase_gmv_gov",
	"accumulate_increase_gmv_gov_diff",
	"bigact_accumulate_gmv_gov",
	"accumulate_gmv_gov",
	"accumulate_gmv_gov_diff",
	"bigact_accumulate_gmv_burst_rate_gov",
	"accumulate_gmv_burst_rate_gov",
	"accumulate_gmv_burst_rate_gov_diff",
	"bigact_new_prod_accumulate_gmv_burst_rate_gov",
	"new_prod_accumulate_gmv_burst_rate_gov",
	"new_prod_accumulate_gmv_burst_rate_gov_diff",
	"bigact_old_prod_accumulate_gmv_burst_rate_gov",
	"old_prod_accumulate_gmv_burst_rate_gov",
	"old_prod_accumulate_gmv_burst_rate_gov_diff",
	"bigact_avg_gpm_burst_rate_gov",
	"avg_gpm_burst_rate_gov",
	"bigact_avg_pay_amt_burst_rate_gov",
	"avg_pay_amt_burst_rate_gov",
	"bigact_accumulate_gpm_burst_rate_gov",
	"accumulate_gpm_burst_rate_gov",
	"accumulate_gpm_burst_rate_gov_diff",
	"bigact_accumulate_order_cnt_burst_rate_gov",
	"accumulate_order_cnt_burst_rate_gov",
	"accumulate_order_cnt_burst_rate_gov_diff",
	"opportunity_prod_cnt_gov",
	"score_more_than_85_increase_gmv_gov",
	"commission_reach_increase_gmv_gov",
	"score_more_than_85_increase_gmv_rate_gov",
	"commission_reach_increase_gmv_rate_gov",
	"bigact_selling_prod_avg_gmv_gov",
	"selling_prod_avg_gmv_gov",
	"bigact_selling_prod_avg_increase_gmv_gov",
	"selling_prod_avg_increase_gmv_gov",
	"gmv_burst_rate_income_gov",
	"show_pv_avg_gmv_impact_gov",
	"opm_avg_gmv_impact_gov",
	"avg_amt_avg_gmv_impact_gov",
	"bigact_show_pv_avg_gmv_impact_gov",
	"bigact_opm_avg_gmv_impact_gov",
	"bigact_avg_amt_avg_gmv_impact_gov",
	"show_pv_avg_incr_gmv_impact_gov",
	"opm_avg_incr_gmv_impact_gov",
	"avg_amt_avg_incr_gmv_impact_gov",
	"bigact_show_pv_avg_incr_gmv_impact_gov",
	"bigact_opm_avg_incr_gmv_impact_gov",
	"bigact_avg_amt_avg_incr_gmv_impact_gov",
	"avg_gmv",
	"gmv_burst_rate",
	"avg_gmv_in_overall_total",
	"avg_gmv_increase",
	"avg_gmv_increase_in_overall_total",
	"bigact_avg_gmv",
	"bigact_avg_gmv_in_overall_total",
	"bigact_gmv_burst_rate",
	"bigact_avg_gmv_increase",
	"bigact_avg_gmv_increase_in_overall_total",
	"avg_gmv_yoy_rate",
	"avg_gpm",
	"avg_pay_amt",
	"bigact_avg_gpm",
	"bigact_avg_pay_amt",
	"avg_gpm_yoy_rate",
	"avg_pay_amt_yoy_rate",
	"bigact_accumulate_increase_gmv",
	"accumulate_increase_gmv",
	"accumulate_increase_gmv_diff",
	"bigact_accumulate_gmv",
	"accumulate_gmv",
	"accumulate_gmv_diff",
	"bigact_accumulate_gmv_burst_rate",
	"accumulate_gmv_burst_rate",
	"accumulate_gmv_burst_rate_diff",
	"bigact_new_prod_accumulate_gmv_burst_rate",
	"new_prod_accumulate_gmv_burst_rate",
	"new_prod_accumulate_gmv_burst_rate_diff",
	"bigact_old_prod_accumulate_gmv_burst_rate",
	"old_prod_accumulate_gmv_burst_rate",
	"old_prod_accumulate_gmv_burst_rate_diff",
	"bigact_avg_gpm_burst_rate",
	"avg_gpm_burst_rate",
	"bigact_avg_pay_amt_burst_rate",
	"avg_pay_amt_burst_rate",
	"bigact_accumulate_gpm_burst_rate",
	"accumulate_gpm_burst_rate",
	"accumulate_gpm_burst_rate_diff",
	"bigact_accumulate_order_cnt_burst_rate",
	"accumulate_order_cnt_burst_rate",
	"accumulate_order_cnt_burst_rate_diff",
	"opportunity_prod_cnt",
	"score_more_than_85_increase_gmv",
	"commission_reach_increase_gmv",
	"score_more_than_85_increase_gmv_rate",
	"commission_reach_increase_gmv_rate",
	"bigact_selling_prod_avg_gmv",
	"selling_prod_avg_gmv",
	"bigact_selling_prod_avg_increase_gmv",
	"selling_prod_avg_increase_gmv",
	"gmv_burst_rate_income",
	"show_pv_avg_gmv_impact",
	"opm_avg_gmv_impact",
	"avg_amt_avg_gmv_impact",
	"bigact_show_pv_avg_gmv_impact",
	"bigact_opm_avg_gmv_impact",
	"bigact_avg_amt_avg_gmv_impact",
	"show_pv_avg_incr_gmv_impact",
	"opm_avg_incr_gmv_impact",
	"avg_amt_avg_incr_gmv_impact",
	"bigact_show_pv_avg_incr_gmv_impact",
	"bigact_opm_avg_incr_gmv_impact",
	"bigact_avg_amt_avg_incr_gmv_impact",
	"bigact_avg_gmv_yoy_rate",
	"bigact_avg_gpm_yoy_rate",
	"bigact_avg_pay_amt_yoy_rate",
	"bigact_avg_gmv_yoy_rate_gov",
	"bigact_avg_gpm_yoy_rate_gov",
	"bigact_avg_pay_amt_yoy_rate_gov",
	"bigact_avg_search_gmv",
	"avg_search_gmv",
	"bigact_avg_search_gmv_gov",
	"avg_search_gmv_gov",
}
