package great_value_buy_service

import (
	"context"
	"fmt"
	"sort"
	"strconv"
	"strings"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/dynamic_enum"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/lang/maths"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
)

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisMultiDimension(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisMultiDimensionData, err error) {
	resp = &great_value_buy.GetGreatValueBuyDiagnosisMultiDimensionData{}
	resp.Rows = make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	fullRows := make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	req.BaseReq.GroupAttrs = make([]*dimensions.SelectedMultiDimensionInfo, 0)

	idsGroup := diagnosisDrillDimensionMap[req.BaseReq.BizType]
	if len(req.DiagnosisTargetList) > 0 && req.BaseReq.BizType == dimensions.BizType_GreatValueBuySearch {
		for _, attr := range req.DiagnosisTargetList {
			// 在搜索供给优化建议下，下钻维度是超值购大组行业和二级类目
			if attr.TargetType == great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchKeyInSupplyProdCnt || attr.TargetType == great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchSuggestInSupplyProdCnt {
				idsGroup = []string{"10355", "10027"}
			}
		}
	}

	if len(idsGroup) > 0 {
		ids := idsGroup
		for _, id := range ids {
			idInt64, _ := strconv.ParseInt(id, 10, 64)
			dimInfo, _ := d.DimensionService.GetDimensionByID(ctx, idInt64)
			if dimInfo == nil {
				continue
			}
			attr := &dimensions.SelectedMultiDimensionInfo{
				DimInfo: &dimensions.SelectedDimensionInfo{
					Id:   id,
					Name: dimInfo.ShowName,
				},
			}
			req.BaseReq.GroupAttrs = append(req.BaseReq.GroupAttrs, attr)
		}
	}
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		api := ""
		if len(req.DiagnosisTargetList) > 0 {
			api = diagnosisApiMap[req.DiagnosisTargetList[0].TargetType]
			req.BaseReq.TargetMetaList = []string{req.DiagnosisTargetList[0].TargetName}
		}
		appendParams := analysis_service.AppendParams{
			OSParams:  make(map[string]interface{}, 0),
			OSApiPath: api,
		}
		appendParams.IsAllTotal = false
		_, fullRows, err = d.getGreatValueBuyItems(ctx, req, appendParams)
		if err != nil {
			return err
		}
		return nil
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "getTrendMap err=%v", err)
		return nil, err
	}
	res := &great_value_buy.GetGreatValueBuyMultiDimRow{}
	if len(fullRows) > 0 {
		fullRows = filterInvalidCategory(fullRows)
		sortByDrillType(req, fullRows)
		res = fullRows[0]
	}
	if len(res.Children) > 0 {
		res.Children = filterInvalidCategory(res.Children)
		sortByDrillType(req, res.Children)
	}
	maxLen := 3
	if len(res.Children) < maxLen {
		maxLen = len(res.Children)
	}
	res.Children = res.Children[:maxLen]
	resp.Rows = []*great_value_buy.GetGreatValueBuyMultiDimRow{res}
	return resp, nil
}

func (d *GreatValueBuyService) getGreatValueBuyItems(ctx context.Context, commonReq *great_value_buy.GetGreatValueBuyCommonRequest, appendParams analysis_service.AppendParams) (
	total *great_value_buy.GetGreatValueBuyMultiDimRow, fullRows []*great_value_buy.GetGreatValueBuyMultiDimRow, err error) {
	total = &great_value_buy.GetGreatValueBuyMultiDimRow{}
	needIncr := true
	fullRows = make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, commonReq.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(commonReq))
		return total, fullRows, err
	}
	//if len(appendParams.OSApiPath) > 0 {
	//	adapterSearchReq(appendParams.OSApiPath, req)
	//}
	if len(commonReq.BaseReq.GroupAttrs) == 0 {
		return total, fullRows, errors.New("获取多维分析参数失败")
	}
	//搜索三期，搜索供给优化建议下，下钻维度是超值购大组行业和二级类目
	req, err := d.adapterSearchInSupplyProdReq(ctx, appendParams.OSApiPath, commonReq)

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	var prodCodeTagBaseDims = make([]*dimensions.SelectedDimensionInfo, 0)
	// 获取分析的维度信息
	groupCols := make([]string, 0)
	dimColEnumCodeMap := make(map[string]map[string]string)
	arrGroupColFilters := make([]string, 0)

	dimCodeEnumMap := make(map[string]map[string]string, 0)
	totalName, totalCode := "", ""
	targetMetaList, _ := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
	targetNameMetaMap := make(map[string]*dimensions.TargetMetaInfo, 0)
	for _, targetMeta := range targetMetaList {
		targetNameMetaMap[targetMeta.Name] = targetMeta
	}
	dimInfos := make([]*dimensions.DimensionInfo, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		if !appendParams.IsAllTotal {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}

		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return total, fullRows, errors.New("未查询到维度信息")
		}
		totalName = dimInfo.ShowName
		totalCode = dimInfo.DimColumn
		dInfo, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(attr.DimInfo.Id))
		if err != nil || dInfo == nil {
			logs.CtxError(ctx, "GetDimensionByID err=%v", err)
			return total, fullRows, err
		}
		dInfo.Values = nil
		dimInfos = append(dimInfos, dInfo)
		//codeNameMap := make(map[string]string)
		//for _, item := range dInfo.Values {
		//	codeNameMap[item.Code] = item.Name
		//}
		dimCodeEnumMap[dimInfo.DimColumn] = d.getDimCodeNames(ctx, req, attr)
		groupCols = append(groupCols, dimInfo.DimColumn)
		prodCodeTagBaseDims = append(prodCodeTagBaseDims, attr.DimInfo)
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			enumCodeMap := make(map[string]string)

			enumCodes := make([]string, 0)
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
				enumCodes = append(enumCodes, enum.Code)
			}
			if dimInfo.ProcessType == "数组类型" {
				enumCodes = slices.DistinctString(enumCodes)
				enumFilterStr := fmt.Sprintf("%s_new in ('%s')", dimInfo.DimColumn, strings.Join(enumCodes, "','"))
				if dimInfo.EnumDataType == "long" {
					enumFilterStr = fmt.Sprintf("%s_new in (%s)", dimInfo.DimColumn, strings.Join(enumCodes, ","))
				}
				arrGroupColFilters = append(arrGroupColFilters, enumFilterStr)
			}
			dimColEnumCodeMap[dimInfo.DimColumn] = enumCodeMap
		}
	}

	curr, compare, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: append(groupCols, base_struct_condition.GenerateDimKey(groupCols, consts.Empty)),
	})
	if err != nil {
		return
	}

	subSelect := make([]string, 0)
	clusterSubSelect := make([]string, 0)
	newGroupCols := make([]string, 0)
	clusterNewGroupCols := make([]string, 0)
	if !appendParams.IsAllTotal {
		for _, col := range groupCols {
			dimInfo, exist := dimColMap[col]
			if exist {
				if len(dimInfo.DimExpr) > 0 {
					subSelect = append(subSelect, fmt.Sprintf("cast(%s as String) as %s", dimInfo.DimExpr, col))
					newGroupCols = append(newGroupCols, col)
					continue
				}

				if dimInfo.ProcessType == "数组类型" {
					subSelect = append(subSelect, fmt.Sprintf("arrayJoin(%s) as %s_new", col, col))
					newGroupCols = append(newGroupCols, col+"_new")
					continue
				}
			}

			subSelect = append(subSelect, fmt.Sprintf("cast(%s as String) as %s", col, col))
			if clusterDimensionMap[col] {
				clusterSubSelect = append(clusterSubSelect, fmt.Sprintf("cast(%s as String) as %s", col, col))
				clusterNewGroupCols = append(clusterNewGroupCols, col)
			}
			newGroupCols = append(newGroupCols, col)
		}

		curr["sub_select"] = strings.Join(subSelect, ",")

		curr["sub_select_join_on"] = base_struct_condition.GenerateDimKeyJoinOn(newGroupCols)

		//curr["sub_group"] = strings.Join(newGroupCols, ",")
		curr["export_select"] = strings.Join(append(newGroupCols, base_struct_condition.GenerateDimKey(newGroupCols, "")), ",")
		curr["dimension_rollup"] = strings.Join(newGroupCols, ",")
		if len(arrGroupColFilters) > 0 {
			curr["arr_group_col_filter"] = strings.Join(arrGroupColFilters, " and ")
		}
		//curr["dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(newGroupCols, "str_"), ",")

		compare["sub_select"] = strings.Join(subSelect, ",")

		compare["sub_select_join_on"] = base_struct_condition.GenerateDimKeyJoinOn(newGroupCols)

		//compare["sub_group"] = strings.Join(newGroupCols, ",")
		compare["export_select"] = strings.Join(append(newGroupCols, base_struct_condition.GenerateDimKey(newGroupCols, "")), ",")
		compare["dimension_rollup"] = strings.Join(newGroupCols, ",")
		if len(arrGroupColFilters) > 0 {
			compare["arr_group_col_filter"] = strings.Join(arrGroupColFilters, " and ")
		}
		//compare["dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(newGroupCols, "str_"), ",")
	} else {
		curr["sub_select"] = nil
		compare["sub_select"] = nil
		curr["export_select"] = "'all_total' as dim_key"
		compare["export_select"] = "'all_total' as dim_key"
	}

	if len(appendParams.OSParams) > 0 {
		for k, v := range appendParams.OSParams {
			curr[k] = v
			compare[k] = v
		}
	}

	apiPath := bizMetaInfo.MultiDimApiID
	if len(appendParams.OSApiPath) > 0 {
		apiPath = appendParams.OSApiPath
	}
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, NeedDistribution: true,
		KeyCols: append(newGroupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
	})
	if err != nil {
		return total, fullRows, err
	}

	if len(currTargetList) >= 20000 {
		logs.CtxWarn(ctx, "[GetProductAnalysisMultiDimList]获取的多维组合数量=%v+，超过1w", len(currTargetList))
		return total, fullRows, errors.New("MAX_10000_LIMIT_ERROR")
	}

	if needIncr {
		compareTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compare, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType,
			KeyCols: append(newGroupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return total, fullRows, err
		}
		//currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumn(currTargetList, compareTargetList, nil, nil)
		currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumnByType(currTargetList, compareTargetList, base_struct_condition.CompareTypeCompare)
	}

	//resp = &analysis.GetProductAnalysisMultiDimFullListData{
	//	FullList: make([]*analysis.MultiDimFullListRow, 0),
	//}
	outParentRowMap := make(map[string][]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	for _, keyTargetList := range currTargetList {
		if appendParams.IsAllTotal {
			total = &great_value_buy.GetGreatValueBuyMultiDimRow{
				DisplayName: totalName + "-整体",
				TargetList:  keyTargetList.TargetEntity,
				EnumValue:   totalCode,
			}
			continue
		}

		if len(keyTargetList.KeyColValues) <= len(groupCols) {
			continue
		}

		dimKey := convert.ToString(keyTargetList.KeyColValues[len(groupCols)])
		if len(strings.ReplaceAll(dimKey, "#", "")) == 0 {
			total = &great_value_buy.GetGreatValueBuyMultiDimRow{
				DisplayName: totalName + "-整体",
				TargetList:  keyTargetList.TargetEntity,
				EnumValue:   totalCode,
			}
			continue
		}

		maxLen := base_struct_condition.GetDimKeyMaxLen(dimKey)
		enumCode := convert.ToString(keyTargetList.KeyColValues[maxLen])
		displayName := consts.Empty
		enumCodeMap, exist := dimCodeEnumMap[groupCols[maxLen]]
		if exist {
			displayName = enumCodeMap[enumCode]
		}
		//fullRow := &analysis.MultiDimFullListRow{
		//	EnumValue:   enumCode,
		//	DisplayName: displayName,
		//	TargetList:  keyTargetList.TargetEntity,
		//	DimKey:      dimKey,
		//	ProdTagCode: "",
		//}
		if displayName == consts.Empty {
			displayName = enumCode
		}
		row := &great_value_buy.GetGreatValueBuyMultiDimRow{
			DisplayName: displayName,
			TargetList:  keyTargetList.TargetEntity,
			EnumValue:   enumCode,
			ProdTagCode: "",
			DimKey:      dimKey,
		}
		if maxLen == 0 {
			fullRows = append(fullRows, row)
		} else {
			children, existC := outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)]
			if !existC {
				children = make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
			}
			children = append(children, row)
			outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)] = children
		}
	}
	analysis_service.CalcDistributionRatio(diagnosisToMultiDimFullListRows(ctx, req, []*great_value_buy.GetGreatValueBuyMultiDimRow{total})...)
	//analysis_service.CalcDistributionRatio(resp.AllTotal)
	analysis_service.CalcDistributionRatio(diagnosisToMultiDimFullListRows(ctx, req, fullRows)...)
	for _, fullRow := range fullRows {
		if children, existC := outParentRowMap[fullRow.DimKey]; existC {
			analysis_service.CalcDistributionRatio(diagnosisToMultiDimFullListRows(ctx, req, children)...)
			fullRow.Children = children
		}
		if len(fullRow.Children) > 0 {
			for _, subFullRow := range fullRow.Children {
				if subChildren, existSubC := outParentRowMap[subFullRow.DimKey]; existSubC {
					analysis_service.CalcDistributionRatio(diagnosisToMultiDimFullListRows(ctx, req, subChildren)...)
					subFullRow.Children = subChildren
				}
			}
		}
	}
	// 添加prod_tag_code
	for _, row := range fullRows {
		if len(prodCodeTagBaseDims) > 0 {
			codeStruct := &dimensions.SelectedDimensionInfo{
				Id:               prodCodeTagBaseDims[0].Id,
				Name:             prodCodeTagBaseDims[0].Name,
				AttrType:         prodCodeTagBaseDims[0].AttrType,
				SelectedOperator: prodCodeTagBaseDims[0].SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{{Code: row.EnumValue, Name: row.DisplayName}},
				IsGroup:          false,
			}
			dims := []*dimensions.SelectedDimensionInfo{codeStruct}
			marshalString, err := sonic.MarshalString(dims)
			if err != nil {
				logs.CtxError(ctx, "序列化prod_tag_code失败,err:"+err.Error())
			}
			row.ProdTagCode = marshalString
			// 递归填充children的tagCode
			analysis_service.AddChildrenTagCode(ctx, prodCodeTagBaseDims, dims, 1, diagnosisToMultiDimFullListRows(ctx, req, row.Children))
		}
	}
	// 整体的tag_code
	if total != nil {
		codeStruct := &dimensions.SelectedDimensionInfo{
			Id:             "-1",
			Name:           "不被匹配的整体",
			SelectedValues: []*dimensions.EnumElement{{Code: "不被匹配的整体", Name: "不被匹配的整体"}},
		}
		dims := []*dimensions.SelectedDimensionInfo{codeStruct}
		marshalString, err := sonic.MarshalString(dims)
		if err != nil {
			logs.CtxError(ctx, "序列化prod_tag_code失败,err:"+err.Error())
		}
		total.ProdTagCode = marshalString
	}
	fillDimensionInfo(ctx, 0, dimInfos, fullRows)
	return total, fullRows, nil
}

func diagnosisToMultiDimFullListRows(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, rows []*great_value_buy.GetGreatValueBuyMultiDimRow) []*analysis.MultiDimFullListRow {
	res := make([]*analysis.MultiDimFullListRow, 0)
	for _, row := range rows {
		if req.BaseReq.BizType == dimensions.BizType_GreatValueBuyBigLink {
			TargetUnitOptimize(row.TargetList)
		}
		res = append(res, &analysis.MultiDimFullListRow{
			DisplayName: row.DisplayName,
			TargetList:  row.TargetList,
			EnumValue:   row.EnumValue,
			ProdTagCode: row.ProdTagCode,
			DimKey:      row.DimKey,
			Children:    diagnosisToMultiDimFullListRows(ctx, req, row.Children),
		})
	}
	return res
}

func fillDimensionInfo(ctx context.Context, i int, dims []*dimensions.DimensionInfo, rows []*great_value_buy.GetGreatValueBuyMultiDimRow) {
	for _, row := range rows {
		row.DimensionInfo = dims[i]
		fillDimensionInfo(ctx, i+1, dims, row.Children)
	}
}

func sortByDrillType(req *great_value_buy.GetGreatValueBuyCommonRequest, rows []*great_value_buy.GetGreatValueBuyMultiDimRow) {
	if req.TargetDrillType == great_value_buy.TargetDrillType_DiffValue || req.TargetDrillType == great_value_buy.TargetDrillType_Value {
		sort.Slice(rows, func(i, j int) bool {
			if len(rows[i].TargetList) > 0 && len(rows[j].TargetList) > 0 {
				return maths.AbsFloat64(rows[i].TargetList[0].Value) > maths.AbsFloat64(rows[j].TargetList[0].Value)
			} else if len(rows[i].TargetList) > 0 {
				return true
			} else if len(rows[j].TargetList) > 0 {
				return false
			}
			return true
		})
	} else if req.TargetDrillType == great_value_buy.TargetDrillType_DiffRatio {
		sort.Slice(rows, func(i, j int) bool {
			if len(rows[i].TargetList) > 0 && len(rows[j].TargetList) > 0 {
				if rows[i].TargetList[0].ComparePeriodData == nil || rows[j].TargetList[0].ComparePeriodData == nil {
					return false
				}
				return maths.AbsFloat64(rows[i].TargetList[0].ComparePeriodData.CompareChangeRatio) >
					maths.AbsFloat64(rows[j].TargetList[0].ComparePeriodData.CompareChangeRatio)
			} else if len(rows[i].TargetList) > 0 {
				return true
			} else if len(rows[j].TargetList) > 0 {
				return false
			}
			return true
		})
	}
}

func filterInvalidCategory(rows []*great_value_buy.GetGreatValueBuyMultiDimRow) []*great_value_buy.GetGreatValueBuyMultiDimRow {
	filteredRows := make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	for _, child := range rows {
		if child.EnumValue == InvalidCategoryCode {
			continue
		}
		filteredRows = append(filteredRows, child)
	}
	return filteredRows
}

func (d *GreatValueBuyService) getDimCodeNames(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, groupDimInfo *dimensions.SelectedMultiDimensionInfo) map[string]string {
	dimId, _ := strconv.ParseInt(groupDimInfo.DimInfo.Id, 10, 64)
	dimInfo, _ := d.DimensionService.GetDimensionByID(ctx, dimId)
	dimInfo2, _ := d.DimensionListDao.GetDimensionById(ctx, dimId)
	if dimInfo == nil || dimInfo2 == nil {
		return nil
	}
	codeNameMap := make(map[string]string, 0)
	if dimInfo.EnumType == dimensions.EnumType_DynamicEnum &&
		slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, dimInfo2.DynamicFuncName) { // 动态枚举
		var pageNum, PageSize = int32(1), int32(500)
		for {
			enumList, err := d.DimensionService.GetDimensionPageEnumList(ctx, &dimensions.GetDimensionPageEnumListRequest{
				BizType:     &req.BaseReq.BizType,
				DimensionId: strconv.FormatInt(dimId, 10),
				PageInfo: &base.PageInfo{
					PageNum:  pageNum,
					PageSize: PageSize,
				},
			})
			if enumList == nil || len(enumList.EnumList) == 0 || err != nil {
				break
			}
			for _, enumItem := range enumList.EnumList {
				codeNameMap[enumItem.Code] = enumItem.Name
			}
			pageNum++
		}
	} else {
		for _, valueItem := range dimInfo.Values {
			codeNameMap[valueItem.Code] = valueItem.Name
		}
	}
	return codeNameMap
}
