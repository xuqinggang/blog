package great_value_buy_service

import (
	"context"
	"fmt"
	"sort"

	"code.byted.org/gopkg/lang/slices"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom_search_strategy_insight"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/attribution_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/jinzhu/copier"
)

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisCommonCoreOverview(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisCommonCoreOverviewData, err error) {
	resp = &great_value_buy.GetGreatValueBuyDiagnosisCommonCoreOverviewData{}
	resp.TargetList = make([]*analysis.TargetCardEntity, 0)
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	if bizInfo.EffectModule != "大促视图" {
		req.BaseReq.GroupAttrs = nil
	}
	cc := co.NewConcurrent(ctx)
	if len(req.DiagnosisTargetList) == 0 {
		cc.GoV2(func() error {
			api := BigLinkOverView
			if req.BaseReq.BizType == dimensions.BizType_GreatValueBuySearch {
				api = SearchOverView
			}
			resTargetList, err := d.getCommonCoreOverView(ctx, api, req)
			resp.TargetList = append(resp.TargetList, resTargetList...)
			if err != nil {
				return err
			}
			return nil
		})
	} else {
		targetTypeMap := map[great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType]bool{}
		// 处理指标列表
		targetMetaList := make([]string, 0)
		if len(req.DiagnosisTargetList) > 0 {
			for _, dItem := range req.DiagnosisTargetList {
				targetMetaList = append(targetMetaList, dItem.TargetName)
			}
		}
		req.BaseReq.TargetMetaList = append(req.BaseReq.TargetMetaList, targetMetaList...)
		for _, diagnosis := range req.DiagnosisTargetList {
			if _, ok := targetTypeMap[diagnosis.TargetType]; !ok {
				var api string
				if bizInfo.EffectModule == "大促视图" {
					api, err = getDiagnosisOverviewApi(ctx, diagnosis.TargetType)
					if err != nil {
						logs.CtxError(ctx, "[GetGreatValueBuyDiagnosisCommonCoreOverview] getDiagnosisApi failed, err:%v", err)
						continue
					}
				} else {
					api = diagnosisApiMap[diagnosis.TargetType]
				}
				if diagnosis.TargetType == great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchKeyInSupplyProdCnt {
					api = "7509003002515112971"
				}
				if diagnosis.TargetType == great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchSuggestInSupplyProdCnt {
					api = "7509002604395906060"
				}
				targetName := diagnosis.TargetName
				cc.GoV2(func() error {
					_api := api
					req.NeedCycle = true
					req.NeedSync = true
					resTargetList := make([]*analysis.TargetCardEntity, 0)
					if bizInfo.EffectModule == "大促视图" {
						resTargetList, err = d.getBigActivityCommonCoreOverView(ctx, _api, req)
					} else {
						resTargetList, err = d.getCommonCoreOverView(ctx, _api, req)
					}
					if err != nil {
						return err
					}
					DumpLogs(ctx, targetName+"-"+api, resTargetList)
					resp.TargetList = append(resp.TargetList, resTargetList...)
					return nil
				})
				targetTypeMap[diagnosis.TargetType] = true
			}
		}

	}
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionCommonCoreOverview]并发对象wait失败, err:"+err.Error())
		return nil, err
	}

	sort.SliceStable(resp.TargetList, func(i, j int) bool {
		return resp.TargetList[i].DisplayOrder < resp.TargetList[j].DisplayOrder
	})
	if req.BaseReq.BizType == dimensions.BizType_GreatValueBuyBigLink {
		TargetUnitOptimize(resp.TargetList)
	}

	return resp, nil
}

func (d *GreatValueBuyService) getCommonCoreOverView(ctx context.Context, apiPath string, commonReq *great_value_buy.GetGreatValueBuyCommonRequest) (resTargetList []*analysis.TargetCardEntity, err error) {
	resTargetList = make([]*analysis.TargetCardEntity, 0)
	// isShowCompare := false
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, commonReq.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(commonReq))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	reqTemp, err := d.adapterSearchAllChannelReq(ctx, apiPath, commonReq)
	req, err := d.adapterSearchInSupplyProdReq(ctx, apiPath, reqTemp)
	if err != nil {
		logs.CtxError(ctx, "适配请求体失败, err:"+err.Error())
		return
	}
	bizInfo.TargetCardApiID = apiPath
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	ctx = context.WithValue(ctx, consts.CtxAllDatePoolFlag, "超值购搜索核心指标")
	syncType := analysis.SyncType_NotNeed
	attributionCommonBaseStruct := &analysis.AttributionCommonBaseStruct{
		BizType:          req.BaseReq.BizType,
		StartDate:        req.BaseReq.StartDate,
		EndDate:          req.BaseReq.EndDate,
		CompareStartDate: req.BaseReq.CompareStartDate,
		CompareEndDate:   req.BaseReq.CompareEndDate,
		Dimensions:       req.BaseReq.Dimensions,
		GroupAttrs:       req.BaseReq.GroupAttrs,
		ThresholdAttrs:   req.BaseReq.ThresholdAttrs,
		ThresholdExpr:    req.BaseReq.ThresholdExpr,
		NeedTrend:        &req.NeedTrend,
		SyncType:         &syncType,
	}
	osReq := base_struct_condition.AttributionOsParamsReq{
		BaseStruct: attributionCommonBaseStruct,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	}
	// 获取invoker的入参
	curr, compare, trend, compareTrend, err := base_struct_condition.GetAttributionStructConditionParams(ctx, osReq)

	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	var currTargetList, compareTargetList []*base_struct_condition.KeyColsTargetEntity

	optimizeActionData := make(map[string]string, 0)

	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		currTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
			FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return err
		}
		return nil
	})
	cc.GoV2(func() error {
		compareTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compare, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
			FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return err
		}
		return nil
	})
	if isGetOptimizeActionData(apiPath) {
		cc.GoV2(func() error {
			optimizeActionData, err = d.getOptimizeProductByAction(ctx, req, curr)
			if err != nil {
				return err
			}
			return nil
		})
	}

	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionCommonCoreOverview]并发对象wait失败, err:"+err.Error())
		return nil, err
	}
	//currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumn(currTargetList, compareTargetList, cycleTargetList, syncTargetList)
	currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumnByType(currTargetList, compareTargetList, base_struct_condition.CompareTypeCompare)
	// 是否需要趋势图
	if req.GetNeedTrend() {
		trendCol := "date"
		//if req.BaseReq.BizType == dimensions.BizType_SkuClusterScaleAndMount ||
		//	req.BaseReq.BizType == dimensions.BizType_SkuClusterCoverage ||
		//	req.BaseReq.BizType == dimensions.BizType_SkuClusterStability ||
		//	req.BaseReq.BizType == dimensions.BizType_SkuClusterSupplyQuality {
		//	trendCol = "dimension"
		//}
		trendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: trend, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, KeyCols: []string{}, TrendCol: trendCol, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
			FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return nil, err
		}
		currTargetList = base_struct_condition.AddTargetTrend(currTargetList, trendMap)

		compareTrendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compareTrend, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, KeyCols: []string{}, TrendCol: trendCol, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
			FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return nil, err
		}
		currTargetList = base_struct_condition.AddCompareTargetTrend(currTargetList, compareTrendMap)
	}

	if len(currTargetList) == 0 {
		return resTargetList, nil
	}
	resData := currTargetList[0].TargetEntity
	analysis_service.SortTargetCardEntity(resData)

	targetMeta, err := dao.GetTargetMetaInfo(ctx, int64(req.BaseReq.BizType), false, []string{"指标卡", "商品明细"})
	if err != nil {
		return resTargetList, err
	}
	var targetMetaMap = make(map[string]*dao.TargetMetaInfo)
	for _, info := range targetMeta {
		targetMetaMap[info.Name] = info
	}

	err = attribution_service.AddDiff(ctx, resData, targetMetaMap)
	if err != nil {
		return nil, err
	}
	resTargetList = resData
	targetThrMap, err := biz_info.GetTccAttributionTargetThresholdMap(ctx)
	if err != nil {
		return resTargetList, err
	}
	for _, i := range resTargetList {
		// 读取不到时，默认阈值为20%
		incrThr := int64(20)
		if thr, exist := targetThrMap[i.Name]; exist {
			incrThr = thr
		}
		extr := i.Extra
		if extr == nil {
			continue
		}
		extr.TargetTag = consts.Empty
		tempReq := &analysis.GetAttributionCommonBaseRequest{
			BaseReq: attributionCommonBaseStruct,
		}
		if i.Value == i.CycleValue {
			extr.TargetTag = "hidden"
		} else if attribution_service.AddTargetTag(i.CycleChangeRatio, incrThr, tempReq, extr.IsLargerAdvantage) {
			extr.TargetTag = "focus_on"
		}
	}
	attribution_service.AddTagByBizType(attributionCommonBaseStruct, resTargetList)
	resTargetList = d.generateTips(ctx, req, resTargetList, optimizeActionData)
	return resTargetList, nil
}

func (d *GreatValueBuyService) generateTips(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, resTargetList []*analysis.TargetCardEntity, optimizeActionData map[string]string) []*analysis.TargetCardEntity {
	isNeedTips := false
	for _, diagnosisTarget := range req.DiagnosisTargetList {
		if diagnosisTarget.TargetType == great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchSupply ||
			diagnosisTarget.TargetType == great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchOptimize {
			isNeedTips = true
			break
		}
	}
	if !isNeedTips {
		return resTargetList
	}
	newTargetList := make([]*analysis.TargetCardEntity, 0)
	increaseShowPv := ""
	for _, target := range resTargetList {
		if target.Name == "increase_show_pv" {
			increaseShowPv = target.DisplayValue
			break
		}
	}
	for _, target := range resTargetList {
		if target.Name == "suggest_attention_supply_product_cnt" {
			tip := &analysis.TipInfo{
				Tips: fmt.Sprintf("%s个品建议引入为考虑招商商品数", target.DisplayValue),
				Type: analysis.TipInfoType_Suggestion,
			}
			target.TipInfoList = []*analysis.TipInfo{tip}
			newTargetList = append(newTargetList, target)
		} else if target.Name == "suggest_introduce_key_supply_product_cnt" {
			tip := &analysis.TipInfo{
				Tips: fmt.Sprintf("%s个品建议引入为重点招商商品数", target.DisplayValue),
				Type: analysis.TipInfoType_Suggestion,
			}
			target.TipInfoList = []*analysis.TipInfo{tip}
			newTargetList = append(newTargetList, target)
		} else if target.Name == "suggest_introduce_supply_product_cnt" {
			tip := &analysis.TipInfo{
				Tips: fmt.Sprintf("%s个非超值购品建议引入为超值购供给", target.DisplayValue),
				Type: analysis.TipInfoType_Suggestion,
			}
			target.TipInfoList = []*analysis.TipInfo{tip}
			newTargetList = append(newTargetList, target)
		} else if target.Name == "can_optimize_product_cnt" {
			tip := &analysis.TipInfo{
				Tips: fmt.Sprintf("下列优化动作完成后，预计提升曝光%s", increaseShowPv),
				Type: analysis.TipInfoType_Gain,
			}
			target.TipInfoList = []*analysis.TipInfo{tip}

			sql, _ := d.GetGreatValueBuyProdSQL(ctx, req)
			for actionTag, value := range optimizeActionData {
				actionName := actionTag
				tagToNameMap := ecom_search_strategy_insight.GetSearchOptimizeActionMap(ctx)
				if name, ok := tagToNameMap[actionTag]; ok {
					actionName = name
				}
				tip = &analysis.TipInfo{
					Tips:      fmt.Sprintf("%s个商品可进行 **%s** 动作", value, actionName),
					Type:      analysis.TipInfoType_Suggestion,
					Sql:       sql,
					ActionTag: actionTag,
				}
				target.TipInfoList = append(target.TipInfoList, tip)
			}
			newTargetList = append(newTargetList, target)
		} else if target.Name == "subsidy_relation_query_cnt" || target.Name == "subsidy_gmv_top20_query_cnt" || target.Name ==
			"suggest_attention_supply_product_cnt" || target.Name == "suggest_introduce_key_supply_product_cnt" {
			newTargetList = append(newTargetList, target)
		} else {
			logs.CtxWarn(ctx, "[generateTips] target name not found, name:%s", target.Name)
		}
	}
	return newTargetList
}

func (d *GreatValueBuyService) getOptimizeProductByAction(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, params map[string]interface{}) (res map[string]string, err error) {
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: params, Sql: consts.Empty, ApiPath: SearchOptimizeAction, BizType: req.BaseReq.BizType, NeedDistribution: false,
		KeyCols: []string{"action_tag"}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
	})
	res = make(map[string]string, 0)
	for _, targetItems := range currTargetList {
		if len(targetItems.KeyColValues) > 0 {
			if key, ok := targetItems.KeyColValues[0].(string); ok {
				res[key] = targetItems.TargetEntity[0].DisplayValue
			}
		}
	}
	return res, nil
}

func adapterSearchReq(ctx context.Context, apiPath string, req *great_value_buy.GetGreatValueBuyCommonRequest) (*great_value_buy.GetGreatValueBuyCommonRequest, error) {
	if diagnosisApiMap[great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchSupply] != apiPath {
		logs.CtxInfo(ctx, "apiPath not need adapter, apiPath:%s", apiPath)
		return req, nil
	}
	adapterReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	// 深拷贝，避免并发请求修改初始请求
	err := copier.CopyWithOption(adapterReq, req, copier.Option{DeepCopy: true})
	if err != nil {
		logs.CtxError(ctx, "[adapterSearchReq] copier.CopyWithOption err:%v", err)
		return req, err
	}
	dims := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dim := range req.BaseReq.Dimensions {
		if dim.Id == "10294" || dim.Id == "10351" {
			dims = append(dims, dim)
		}
	}
	adapterReq.BaseReq.Dimensions = dims
	return adapterReq, nil
}

func adapterSearchChannelReq(ctx context.Context, apiPath string, req *great_value_buy.GetGreatValueBuyCommonRequest) (*great_value_buy.GetGreatValueBuyCommonRequest, error) {
	if !slices.ContainsString(SearchChannelApi, apiPath) {
		logs.CtxInfo(ctx, "apiPath not need adapter, apiPath:%s", apiPath)
		return req, nil
	}
	adapterReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	// 深拷贝，避免并发请求修改初始请求
	err := copier.CopyWithOption(adapterReq, req, copier.Option{DeepCopy: true})
	if err != nil {
		logs.CtxError(ctx, "[adapterSearchReq] copier.CopyWithOption err:%v", err)
		return req, err
	}
	dims := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dim := range req.BaseReq.Dimensions {
		if dim.Id == "10294" || dim.Id == "10351" {
			dims = append(dims, dim)
		}
	}
	adapterReq.BaseReq.Dimensions = dims
	return adapterReq, nil
}

func (d *GreatValueBuyService) adapterSearchAllChannelReq(ctx context.Context, apiPath string, req *great_value_buy.GetGreatValueBuyCommonRequest) (*great_value_buy.GetGreatValueBuyCommonRequest, error) {
	if !slices.ContainsString(SearchChannelApi, apiPath) {
		logs.CtxInfo(ctx, "apiPath not need adapter, apiPath:%s", apiPath)
		return req, nil
	}
	adapterReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	// 深拷贝，避免并发请求修改初始请求
	err := copier.CopyWithOption(adapterReq, req, copier.Option{DeepCopy: true})
	if err != nil {
		logs.CtxError(ctx, "[adapterSearchReq] copier.CopyWithOption err:%v", err)
		return req, err
	}
	dims := make([]*dimensions.SelectedDimensionInfo, 0)
	var isLastHasOneChannel = false
	for _, dim := range adapterReq.BaseReq.Dimensions {
		// for 渠道下钻分析，用户至少选了一个渠道下钻
		if dim.Id == "10294" {
			dimInfo, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(dim.Id))
			if err != nil || dimInfo == nil || len(dimInfo.Values) == 0 {
				logs.CtxError(ctx, "[adapterSearchReq] GetDimensionByID err:%v", err)
				return req, err
			}
			if len(dim.SelectedValues) == 1 {
				isLastHasOneChannel = true
			}
		}
		if dim.Id == "10351" {
			dimInfo, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(dim.Id))
			if err != nil || dimInfo == nil || len(dimInfo.Values) == 0 {
				logs.CtxError(ctx, "[adapterSearchReq] GetDimensionByID err:%v", err)
				return req, err
			}
			if len(dim.SelectedValues) == 1 {
				isLastHasOneChannel = true
			}
		}
	}
	for _, dim := range adapterReq.BaseReq.Dimensions {
		if dim.Id == "10294" || dim.Id == "10351" {
			dimInfo, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(dim.Id))
			if err != nil || dimInfo == nil || len(dimInfo.Values) == 0 {
				logs.CtxError(ctx, "[adapterSearchReq] GetDimensionByID err:%v", err)
				return req, err
			}
			if isLastHasOneChannel {
				dims = append(dims, dim)
			} else {
				if len(dim.SelectedValues) == 0 || len(dim.SelectedValues) == len(dimInfo.Values) {
					dim.SelectedValues = []*dimensions.EnumElement{{Code: "all", Name: "all"}}
					dims = append(dims, dim)
				} else {
					dims = append(dims, dim)
				}
			}
		} else {
			logs.CtxInfo(ctx, " dim.Id  not need adapter,  dim.Id :%s", dim.Id)
		}
	}
	adapterReq.BaseReq.Dimensions = dims
	return adapterReq, nil
}

// 待引入供给品的查询 只 一级类目 和 二级类目
func (d *GreatValueBuyService) adapterSearchInSupplyProdReq(ctx context.Context, apiPath string, req *great_value_buy.GetGreatValueBuyCommonRequest) (*great_value_buy.GetGreatValueBuyCommonRequest, error) {
	if !slices.ContainsString(SearchInSupplyChannelApi, apiPath) {
		logs.CtxInfo(ctx, "apiPath not need adapter , apiPath:%s", apiPath)
		return req, nil
	}
	adapterReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	// 深拷贝，避免并发请求修改初始请求
	err := copier.CopyWithOption(adapterReq, req, copier.Option{DeepCopy: true})
	if err != nil {
		logs.CtxError(ctx, "[adapterSearchReq] copier.CopyWithOption err:%v", err)
		return req, err
	}
	dims := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dim := range adapterReq.BaseReq.Dimensions {
		if dim.Id == "10355" || dim.Id == "10027" {
			dims = append(dims, dim)
		}
	}
	adapterReq.BaseReq.Dimensions = dims
	return adapterReq, nil
}
func isGetOptimizeActionData(apiPath string) bool {
	return diagnosisApiMap[great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType_SearchOptimize] == apiPath
}
