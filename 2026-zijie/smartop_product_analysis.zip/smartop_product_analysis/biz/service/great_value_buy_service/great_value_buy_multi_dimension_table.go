package great_value_buy_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/jinzhu/copier"
	"sort"
	"strings"
	"sync"
	"time"
)

// apiResult 用于存储每个下钻接口返回的 Total 和 Rows 数据
type apiResult struct {
	Total *great_value_buy.GetGreatValueBuyMultiDimRow
	Rows  []*great_value_buy.GetGreatValueBuyMultiDimRow
}

// drillDownConfig 定义了每个下钻任务的配置
type drillDownConfig struct {
	key           string
	osApiPath     string
	useOverallReq bool // 标记是否使用 req.OverallCommonReq.BaseReq
}

func (d *GreatValueBuyService) GetGreatValueBuyMultiDimensionTable(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyMultiDimensionData, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	if bizMetaInfo.EffectModule == "大促视图" {
		if req.OverallCommonReq != nil && req.OverallCommonReq.BaseReq != nil {
			req.OverallCommonReq.BaseReq.BizType = req.BaseReq.BizType
		}
		resp, err = d.GetBigactMultiDimensionTable(ctx, req, consts.Empty)
		return resp, err
	}
	resp = great_value_buy.NewGetGreatValueBuyMultiDimensionData()
	resp.Total = great_value_buy.NewGetGreatValueBuyMultiDimRow()
	resp.Rows = make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		appendParams := analysis_service.AppendParams{
			OSParams: make(map[string]interface{}),
		}
		appendParams.IsAllTotal = true
		allTotal, err := d.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
			BaseReq:  req.BaseReq,
			NeedIncr: req.GetNeedCycle(),
		}, appendParams)
		if err != nil {
			return err
		}
		newRes := d.analysisRowToGreatRow(ctx, req, []*analysis.MultiDimFullListRow{allTotal.AllTotal})
		if len(newRes) > 0 {
			resp.Total = newRes[0]
		}
		return nil
	})
	cc.GoV2(func() error {
		appendParams := analysis_service.AppendParams{
			OSParams: make(map[string]interface{}, 0),
		}
		appendParams.IsAllTotal = false
		res, err := d.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
			BaseReq:  req.BaseReq,
			NeedIncr: req.GetNeedCycle(),
		}, appendParams)
		if err != nil {
			return err
		}
		resp.Rows = d.analysisRowToGreatRow(ctx, req, res.FullList)
		return nil
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "getTrendMap err=%v", err)
		return resp, err
	}
	return resp, err
}

const (
	TableSceneDiagnosisConclusion = "diagnosis_conclusion"
	TableSceneBigActivityLarkCard = "big_activity_lark_card"
)

func (d *GreatValueBuyService) GetBigactMultiDimensionTable(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, scene string) (resp *great_value_buy.GetGreatValueBuyMultiDimensionData, err error) {
	resp = great_value_buy.NewGetGreatValueBuyMultiDimensionData()
	// 初始化默认值，以防某些API调用失败或无数据时，后续处理有有效的空对象
	resp.Total = great_value_buy.NewGetGreatValueBuyMultiDimRow()
	resp.Rows = make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)

	tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
	if err != nil {
		return nil, err
	}
	logs.CtxInfo(ctx, "clusterSwitchConf tableConf = %v", tableConf)

	var targetMetaMap map[string]*dao.TargetMetaInfo
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	targetMetaMap, err = base_struct_condition.GetTargetMetaInfoMap(ctx, int64(req.BaseReq.BizType), false, nil...)
	if err != nil {
		return nil, err
	}

	specialParams, err := generateSpecialParams(ctx, req, dimMap, dimColMap)
	if err != nil {
		logs.CtxError(ctx, "generateSpecialParams err=%v", err)
		return nil, err
	}
	// 初始化 req.OverallCommonReq（受到大盘yoy字段复用的影响）
	req.OverallCommonReq.BaseReq.StartDate = req.BaseReq.StartDate
	req.OverallCommonReq.BaseReq.EndDate = req.BaseReq.EndDate
	req.OverallCommonReq.BaseReq.CompareStartDate = req.BaseReq.CompareStartDate
	req.OverallCommonReq.BaseReq.CompareEndDate = req.BaseReq.CompareEndDate
	req.OverallCommonReq.BaseReq.TargetMetaList = req.BaseReq.TargetMetaList

	isNeedInit, lastParams, err := checkAndInitLastOSParam(ctx, req, dimMap, dimColMap)
	if err != nil {
		return nil, err
	}
	if isNeedInit {
		for k, v := range lastParams {
			if _, exist := specialParams[k]; exist {
				logs.CtxWarn(ctx, "specialParams already exist, key = %s", k)
			}
			specialParams[k] = v
		}
	}
	// 定义所有下钻任务的配置
	configs := []drillDownConfig{
		{key: "overall", osApiPath: tableConf.OverallMultiTable, useOverallReq: true},
		{key: "activity", osApiPath: tableConf.ActMultiTable, useOverallReq: false},
		{key: "pairs", osApiPath: "7561806805899183130", useOverallReq: false},
		{key: "newAndOldProd", osApiPath: tableConf.NewAndOldProdMultiTable, useOverallReq: false},
		//{key: "conType", osApiPath: BigActivityGpmContentPvDiagnosis, useOverallReq: false},
		{key: "qualityScore", osApiPath: tableConf.QualityScore85MultiTable, useOverallReq: false},
		{key: "commission", osApiPath: tableConf.CommissionRateMultiTable, useOverallReq: false},
		// {key: "opportunityProdCnt", osApiPath: BigActivityOpportunityProdDiagnosisAgg, useOverallReq: false}, // 暂时下掉机会品
	}
	if scene == TableSceneDiagnosisConclusion {
		configs = []drillDownConfig{
			{key: "overall", osApiPath: tableConf.OverallConclusion, useOverallReq: true},
			{key: "activity", osApiPath: tableConf.ActConclusion, useOverallReq: false},
		}
	}

	if scene == TableSceneBigActivityLarkCard {
		configs = []drillDownConfig{
			{key: "overall", osApiPath: tableConf.OverallLark, useOverallReq: true},
			{key: "activity", osApiPath: tableConf.ActLark, useOverallReq: false},
			{key: "qualityScore", osApiPath: tableConf.QualityScore85Lark, useOverallReq: false},
			{key: "commission", osApiPath: tableConf.CommissionRateLark, useOverallReq: false},
		}
	}
	logs.CtxInfo(ctx, "GetBigactMultiDimensionTable configs = %v", convert.ToJSONString(configs))
	resultsMap := make(map[string]apiResult)
	var mapMutex sync.Mutex

	cc := co.NewConcurrent(ctx)
	for _, config := range configs {
		// 捕获循环变量
		currentConfig := config
		cc.GoV2(func() error {
			baseReqForDrillDown := &dimensions.ProductAnalysisBaseStruct{}
			if currentConfig.useOverallReq && req.OverallCommonReq != nil {
				err = copier.CopyWithOption(baseReqForDrillDown, req.OverallCommonReq.BaseReq, copier.Option{DeepCopy: true})
			} else {
				err = copier.CopyWithOption(baseReqForDrillDown, req.BaseReq, copier.Option{DeepCopy: true})
			}
			if err != nil {
				logs.CtxError(ctx, "copy base req err=%v", err)
				return err
			}
			if baseReqForDrillDown == nil { // 防止 req.OverallCommonReq 为 nil 的情况
				logs.CtxError(ctx, "base req is nil")
				// 可以选择返回错误或跳过
				return errors.New("base req is nil")
			}
			osParamsCopy := make(map[string]interface{}, 0)
			err = copier.CopyWithOption(&osParamsCopy, specialParams, copier.Option{DeepCopy: true})
			if err != nil {
				return err
			}
			appendParams := analysis_service.AppendParams{
				OSParams:   osParamsCopy,
				OSApiPath:  currentConfig.osApiPath,
				IsAllTotal: false, // 所有这些下钻都是 false
			}

			// 特殊处理 "overall" 的 YOY 参数
			if (currentConfig.key == "overall" || currentConfig.key == "activity") && req.OverallCommonReq != nil && req.OverallCommonReq.IsOpenYoy {
				// 确保 OSParams 被正确初始化
				if appendParams.OSParams == nil {
					appendParams.OSParams = make(map[string]interface{})
				}

				appendParams.OSParams["is_open_yoy"] = 1
				if currentConfig.key == "activity" {
					ps, _ := genBigActYOYFilterParams(ctx, baseReqForDrillDown, dimMap, dimColMap)
					appendParams.OSParams["yoy_filter_param"] = ps["filter_param"]
				}
			}

			res, err := d.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
				BaseReq:  baseReqForDrillDown,
				NeedIncr: req.GetNeedCycle(),
			}, appendParams)
			if err != nil {
				logs.CtxError(ctx, "Error fetching data for %s: %v", currentConfig.key, err)
				return err
			}

			currentApiResult := apiResult{
				Total: great_value_buy.NewGetGreatValueBuyMultiDimRow(), // 默认初始化
				Rows:  make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0),
			}

			totalRowInput := []*analysis.MultiDimFullListRow{}
			if res.Total != nil {
				totalRowInput = []*analysis.MultiDimFullListRow{res.Total}
			}
			newTotalRes := d.analysisRowToGreatRow(ctx, req, totalRowInput)
			if len(newTotalRes) > 0 {
				currentApiResult.Total = newTotalRes[0]
			}
			currentApiResult.Rows = d.analysisRowToGreatRow(ctx, req, res.FullList)

			mapMutex.Lock()
			resultsMap[currentConfig.key] = currentApiResult
			mapMutex.Unlock()
			return nil
		})
	}
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "resultsMap err=%v", err)
		return resp, err
	}
	for key, reqResult := range resultsMap {
		resp.Total = mergeTargets(ctx, []*great_value_buy.GetGreatValueBuyMultiDimRow{resp.Total}, []*great_value_buy.GetGreatValueBuyMultiDimRow{reqResult.Total})[0]
		resp.Rows = mergeTargets(ctx, resp.Rows, reqResult.Rows)
		logs.CtxInfo(ctx, "[mergeTargets] key = %s", key)
	}

	totalTargetMap := make(map[string]*analysis.TargetCardEntity, 0)
	for _, target := range resp.Total.TargetList {
		totalTargetMap[target.Name] = target
	}
	calAndPackExtraTarget(ctx, req, targetMetaMap, totalTargetMap, resp.Rows)
	resp.Total.TargetList = calAndPackExtraTargetByRow(ctx, req, targetMetaMap, totalTargetMap, resp.Total.TargetList)
	// 计算 bigact_increase_tag
	calBigactIncreaseTag(ctx, req, resp.Rows, totalTargetMap)
	resp.Total = calBigactIncreaseTagByRow(ctx, req, resp.Total, resp.Total.TargetList, totalTargetMap)
	sortMultiDimTableData(ctx, resp)
	return resp, err
}

func sortMultiDimTableData(ctx context.Context, resp *great_value_buy.GetGreatValueBuyMultiDimensionData) {
	if resp == nil {
		return
	}
	SortRowDataDataTargets(resp.Total)
	for _, row := range resp.Rows {
		SortRowDataDataTargets(row)
	}
	logs.CtxInfo(ctx, "[sortMultiDimTableData] sortMultiDimTableData, resp=%v", resp)
}

// SortRowDataDataTargets 按DisplayOrder排序
func SortRowDataDataTargets(data *great_value_buy.GetGreatValueBuyMultiDimRow) {
	if data == nil {
		return
	}
	if len(data.TargetList) == 0 {
		return
	}
	sort.Slice(data.TargetList, func(i, j int) bool {
		if data.TargetList[i] == nil || data.TargetList[j] == nil {
			return false
		}
		return data.TargetList[i].DisplayOrder < data.TargetList[j].DisplayOrder
	})
	for _, row := range data.Children {
		SortRowDataDataTargets(row)
	}
}

func generateSpecialParams(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo) (map[string]interface{}, error) {
	var err error
	params := make(map[string]interface{})
	// 时间周期参数
	currDateExpr, err := GetBigActOSDateExpr(ctx, req.BaseReq.StartDate, req.BaseReq.EndDate)
	if err != nil {
		return nil, err
	}
	compareDateExpr, err := GetBigActOSDateExpr(ctx, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
	if err != nil {
		return nil, err
	}
	if req.OverallCommonReq != nil && req.OverallCommonReq.IsOpenYoy {
		yoyDateExpr, err := GetBigActOSDateExpr(ctx, req.OverallCommonReq.BaseReq.CompareStartDate, req.OverallCommonReq.BaseReq.CompareEndDate)
		if err != nil {
			return nil, err
		}
		params["yoy_date_expr"] = yoyDateExpr
	}
	params["curr_date_expr"] = currDateExpr
	params["compare_date_expr"] = compareDateExpr

	// 1. yoy 参数
	curr := make(map[string]interface{})
	yoyReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	err = copier.CopyWithOption(yoyReq, req, copier.Option{DeepCopy: true})
	if err != nil {
		logs.CtxError(ctx, "copy req err=%v", err)
		return nil, err
	}
	if yoyReq.OverallCommonReq != nil {
		if yoyReq.OverallCommonReq.BaseReq.StartDate == "" && yoyReq.OverallCommonReq.BaseReq.EndDate == "" {
			yoyReq.OverallCommonReq.BaseReq.StartDate = req.BaseReq.StartDate
			yoyReq.OverallCommonReq.BaseReq.EndDate = req.BaseReq.EndDate
		}
		curr, _, _, _, _, err = base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
			BaseStruct: yoyReq.OverallCommonReq.BaseReq,
			DimMap:     dimMap,
			DimColMap:  dimColMap,
		})
		if err != nil {
			return nil, err
		}
	}
	params["yoy_start_date"] = curr["compare_start_date"]
	params["yoy_end_date"] = curr["compare_end_date"]
	params["date_range_yoy"] = curr["date_range_compare"]

	// 2. 构造流量分组维度
	flowGroupReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	err = copier.CopyWithOption(flowGroupReq, req, copier.Option{DeepCopy: true})
	groupAttrs := make([]*dimensions.SelectedDimensionInfo, 0)
	flowGroupReqParams := make(map[string]interface{}, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		dimInfo, exist := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if !exist {
			logs.CtxError(ctx, "dimension attr err")
			return nil, err
		}
		if dimensions.DimensionAttributeType(dimInfo.DimensionCategory) == dimensions.DimensionAttributeType_User || dimensions.DimensionAttributeType(dimInfo.DimensionCategory) == dimensions.DimensionAttributeType_Place {
			groupAttrs = append(groupAttrs, attr.DimInfo)
		}
	}
	flowGroupReq.BaseReq.Dimensions = groupAttrs
	flowGroupReqParams, _, _, _, _, err = base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: flowGroupReq.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	})
	if err != nil {
		logs.CtxError(ctx, "get flowGroupReqParams err=%v", err)
		return nil, err
	}
	params["flow_group_filter_param"] = flowGroupReqParams["filter_param"]

	// 3. 构造大促不含报名状态、大促项目的维度
	noSignUpReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
	err = copier.CopyWithOption(noSignUpReq, req, copier.Option{DeepCopy: true})
	noSignUpReqDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dim := range req.BaseReq.Dimensions {
		if dim.Id == "10366" || dim.Id == "10372" {
			continue
		}
		noSignUpReqDimensions = append(noSignUpReqDimensions, dim)
	}
	noSignUpReq.BaseReq.Dimensions = noSignUpReqDimensions
	noSignUpReqParams, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: noSignUpReq.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	})
	if err != nil {
		logs.CtxError(ctx, "get noSignUpReqParams err=%v", err)
		return nil, err
	}
	params["no_sign_up_filter_param"] = noSignUpReqParams["filter_param"]
	return params, nil
}

func calBigactIncreaseTag(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, rows []*great_value_buy.GetGreatValueBuyMultiDimRow, totalTargetMap map[string]*analysis.TargetCardEntity) {
	if len(rows) == 0 {
		return
	}
	for _, row := range rows {
		row = calBigactIncreaseTagByRow(ctx, req, row, row.TargetList, totalTargetMap)
		calBigactIncreaseTag(ctx, req, row.Children, totalTargetMap)
	}
}

func calBigactIncreaseTagByRow(ctx context.Context,
	req *great_value_buy.GetGreatValueBuyCommonRequest,
	item *great_value_buy.GetGreatValueBuyMultiDimRow,
	targetList []*analysis.TargetCardEntity,
	totalTargetMap map[string]*analysis.TargetCardEntity,
) *great_value_buy.GetGreatValueBuyMultiDimRow {
	// 计算 bigact_increase_tag
	if item == nil {
		return item
	}
	defer func() {
		if item.BigactIncreaseTag == "" {
			item.BigactIncreaseTag = "无法诊断（商品无相关数据）"
		}
	}()
	if req == nil || req.TargetConfigList == nil || req.TargetConfigList.BigActIncreaseTagConfig == nil {
		logs.CtxError(ctx, "calBigactIncreaseTagByRow BigActIncreaseTagConfig missing")
		return item
	}
	targetListMap := make(map[string]*analysis.TargetCardEntity, 0)
	for _, target := range targetList {
		targetListMap[target.Name] = target
	}

	var actProdNeedGov, overallNeedGov bool
	if req.TargetConfigList != nil && req.TargetConfigList.GovTargetConfig != nil {
		if req.TargetConfigList.GovTargetConfig.ActNeedGov {
			actProdNeedGov = true
		}
		if req.TargetConfigList.GovTargetConfig.OverallNeedGov {
			overallNeedGov = true
		}
	}

	var tag bool
	logs.CtxInfo(ctx, "calTagType %v", req.TargetConfigList.BigActIncreaseTagConfig.BigActIncreaseTagType)
	switch req.TargetConfigList.BigActIncreaseTagConfig.BigActIncreaseTagType {
	case great_value_buy.BigActIncreaseTagType_Diff_AccumulateIncreaseGMV, great_value_buy.BigActIncreaseTagType_Diff_ValidProdAvgIncreaseGMV:
		rule, ok := BigActTagDiffRules[req.TargetConfigList.BigActIncreaseTagConfig.BigActIncreaseTagType]
		if !ok {
			logs.CtxError(ctx, "[calBigactIncreaseTagByRow] BigActTagDiffRules not found")
			return item
		}
		minuend := pickTargetName(ctx, rule.Minuend, actProdNeedGov, overallNeedGov)
		subtrahend := pickTargetName(ctx, rule.Subtrahend, actProdNeedGov, overallNeedGov)

		minuendTarget, exist := targetListMap[minuend]
		if !exist {
			logs.CtxWarn(ctx, fmt.Sprintf("[calBigactIncreaseTagByRow] minuend:%v not found", minuend))
			return item
		}
		subtrahendTarget, exist := targetListMap[subtrahend]
		if !exist {
			logs.CtxWarn(ctx, fmt.Sprintf("[calBigactIncreaseTagByRow] subtrahend:%v not found", subtrahend))
			return item
		}
		tag = minuendTarget.Value > subtrahendTarget.Value
	case great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallRate:
		rule, ok := BigActTagRatioRules[req.TargetConfigList.BigActIncreaseTagConfig.BigActIncreaseTagType]
		if !ok {
			logs.CtxWarn(ctx, "[calBigactIncreaseTagByRow] BigActTagRatioRules not found")
			return item
		}
		numerator := pickTargetName(ctx, rule.Numerator, actProdNeedGov, overallNeedGov)
		denominator := pickTargetName(ctx, rule.Denominator, actProdNeedGov, overallNeedGov)
		numeratorTarget, exist := targetListMap[numerator]
		if !exist {
			logs.CtxWarn(ctx, fmt.Sprintf("[calBigactIncreaseTagByRow] numerator:%v not found", numerator))
			return item
		}
		denominatorTarget, exist := targetListMap[denominator]
		if !exist {
			logs.CtxWarn(ctx, fmt.Sprintf("[calBigactIncreaseTagByRow] denominator:%v not found", denominator))
			return item
		}
		tag = CheckThreshold(ctx, numeratorTarget.Value/denominatorTarget.Value, req.TargetConfigList.BigActIncreaseTagConfig.GetThresholdValue(), req.TargetConfigList.BigActIncreaseTagConfig.GetOperateType())
	case great_value_buy.BigActIncreaseTagType_Ratio_AccumulateGMVInOverallTotalRate:
		rule, ok := BigActTagRatioTotalRules[req.TargetConfigList.BigActIncreaseTagConfig.BigActIncreaseTagType]
		if !ok {
			logs.CtxWarn(ctx, "[calBigactIncreaseTagByRow] BigActTagRatioRules not found")
			return item
		}
		numerator := pickTargetName(ctx, rule.Numerator, actProdNeedGov, overallNeedGov)
		denominator := pickTargetName(ctx, rule.Denominator, actProdNeedGov, overallNeedGov)
		numeratorTarget, exist := targetListMap[numerator]
		if !exist {
			logs.CtxWarn(ctx, fmt.Sprintf("[calBigactIncreaseTagByRow] numerator:%v not found", numerator))
			return item
		}
		denominatorTarget, exist := totalTargetMap[denominator]
		if !exist {
			logs.CtxWarn(ctx, fmt.Sprintf("[calBigactIncreaseTagByRow] denominator:%v not found", denominator))
			return item
		}
		tag = CheckThreshold(ctx, numeratorTarget.Value/denominatorTarget.Value, req.TargetConfigList.BigActIncreaseTagConfig.GetThresholdValue(), req.TargetConfigList.BigActIncreaseTagConfig.GetOperateType())
	default:
		logs.CtxError(ctx, "[calBigactIncreaseTagByRow] BigActIncreaseTagType not support")
	}
	logs.CtxInfo(ctx, "calTagType %v, tag %v", req.TargetConfigList.BigActIncreaseTagConfig.BigActIncreaseTagType, tag)
	if tag {
		item.BigactIncreaseTag = "大促品GMV达标"
	} else {
		item.BigactIncreaseTag = "大促品GMV未达标"
	}

	return item
}

func checkAndInitLastOSParam(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo) (bool, map[string]interface{}, error) {
	if req == nil || req.BaseReq == nil || req.OverallCommonReq == nil || len(req.BaseReq.GroupAttrs) == 0 {
		logs.CtxError(ctx, "[checkAndInitLastOSParam]请求参数错误, req = %s", convert.ToJSONString(req))
		return false, nil, errors.New("[checkAndInitLastOSParam]请求参数错误")
	}
	// 统计下钻的维度中是否有需要联表取最新的下钻数据
	var unLastGroupAttrs, lastGroupAttrs, allGroupAttrs []*dimensions.SelectedDimensionInfo
	for _, attr := range req.BaseReq.GroupAttrs {
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "[checkAndInitLastOSParam]获取维度失败")
			return false, nil, errors.New("[checkAndInitLastOSParam]获取维度失败")
		}
		if dimInfo.IsProdIDAttr == 1 {
			lastGroupAttrs = append(lastGroupAttrs, attr.DimInfo)
		} else {
			unLastGroupAttrs = append(unLastGroupAttrs, attr.DimInfo)
		}
		allGroupAttrs = append(allGroupAttrs, attr.DimInfo)
	}
	if len(lastGroupAttrs) == 0 {
		logs.CtxInfo(ctx, "[checkAndInitLastOSParam]不需要联表取最新的下钻数据")
		return false, nil, nil
	}
	// 生成大促参数
	baseReq := &dimensions.ProductAnalysisBaseStruct{}
	_ = copier.CopyWithOption(baseReq, req.BaseReq, copier.Option{DeepCopy: true})
	baseReq.Dimensions = append(baseReq.Dimensions, allGroupAttrs...)
	unLastParams, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: baseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	})
	if err != nil {
		return false, nil, err
	}
	// 生成大盘参数
	baseReqOverall := &dimensions.ProductAnalysisBaseStruct{}
	_ = copier.CopyWithOption(baseReqOverall, req.OverallCommonReq.BaseReq, copier.Option{DeepCopy: true})
	baseReqOverall.Dimensions = append(baseReqOverall.Dimensions, allGroupAttrs...)
	unLastParamsOverall, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: baseReqOverall,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	})
	if err != nil {
		return false, nil, err
	}

	// 需要联表取最新的下钻数据
	var lastParams []string
	for _, dim := range lastGroupAttrs {
		dimInfo, exist := dimMap[convert.ToInt64(dim.Id)]
		if !exist {
			logs.CtxError(ctx, "[checkAndInitLastOSParam]获取维度失败")
			return false, nil, errors.New("[checkAndInitLastOSParam]获取维度失败")
		}
		selectedCodes := make([]string, 0)
		for _, selectedValue := range dim.SelectedValues {
			selectedCodes = append(selectedCodes, selectedValue.Code)
		}
		selectedCodesTmp := strings.Join(selectedCodes, "','")
		lastParams = append(lastParams, fmt.Sprintf("%s %s ('%s')", dimInfo.DimColumn, dim.SelectedOperator.String(), selectedCodesTmp))
	}
	lastParamsCql := strings.Join(lastParams, " and ")

	var lastSubSelectList, unLastSubSelectList []string
	for _, attr := range lastGroupAttrs {
		dimInfo, exsit := dimMap[convert.ToInt64(attr.Id)]
		if !exsit {
			logs.CtxError(ctx, "[checkAndInitLastOSParam]获取维度失败, attr = %s", convert.ToJSONString(attr))
			return false, nil, errors.New("[checkAndInitLastOSParam]获取维度失败")
		}
		lastSubSelectList = append(lastSubSelectList, dimInfo.DimColumn)
	}
	for _, attr := range unLastGroupAttrs {
		dimInfo, exsit := dimMap[convert.ToInt64(attr.Id)]
		if !exsit {
			logs.CtxError(ctx, "[checkAndInitLastOSParam]获取维度失败, attr = %s", convert.ToJSONString(attr))
			return false, nil, errors.New("[checkAndInitLastOSParam]获取维度失败")
		}
		unLastSubSelectList = append(unLastSubSelectList, dimInfo.DimColumn)
	}

	// 生成查询参数
	curr := make(map[string]interface{}, 0)
	curr["is_join_table_select"] = 1
	if len(unLastSubSelectList) > 0 {
		curr["no_join_table_sub_select"] = strings.Join(unLastSubSelectList, ",")
	}
	if len(lastSubSelectList) > 0 {
		curr["join_table_sub_select"] = strings.Join(lastSubSelectList, ",")
	}
	curr["no_join_table_filter_param"] = unLastParams["filter_param"]
	// 大促YOY参数，main_project_id，需要替换为去年的main_project_id
	if filterParam, ok := unLastParams["filter_param"]; ok {
		if str, ok1 := filterParam.(string); ok1 {
			mainProjectIdMap, _ := biz_info.GetBigPromotionMainProjectMap(ctx)
			for mainProjectId, lastYearMainProjectId := range mainProjectIdMap {
				if strings.Contains(str, mainProjectId) {
					curr["yoy_no_join_table_filter_param"] = strings.Replace(str, mainProjectId, lastYearMainProjectId, 1)
					break
				}
			}
		}
	}

	curr["no_join_table_filter_param_overall"] = unLastParamsOverall["filter_param"]
	curr["join_table_filter_param"] = lastParamsCql
	return true, curr, nil
}

func mergeTargets(ctx context.Context, toRows []*great_value_buy.GetGreatValueBuyMultiDimRow, fromRows []*great_value_buy.GetGreatValueBuyMultiDimRow) []*great_value_buy.GetGreatValueBuyMultiDimRow {
	if len(fromRows) == 0 {
		return toRows
	}
	dimMap := make(map[string]*great_value_buy.GetGreatValueBuyMultiDimRow)
	for _, row := range fromRows {
		dimMap[row.DimKey] = row
	}
	for _, row := range toRows {
		if dimMap[row.DimKey] != nil {
			dimMap[row.DimKey].TargetList = append(dimMap[row.DimKey].TargetList, row.TargetList...)
			// 递归更新children
			dimMap[row.DimKey].Children = mergeTargets(ctx, dimMap[row.DimKey].Children, row.Children)
		} else {
			dimMap[row.DimKey] = row
		}

	}
	res := make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	for _, row := range dimMap {
		res = append(res, row)
	}
	return res
}

func calAndPackExtraTarget(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, targetMetaMap map[string]*dao.TargetMetaInfo, totalTargetMap map[string]*analysis.TargetCardEntity, rows []*great_value_buy.GetGreatValueBuyMultiDimRow) {
	if len(rows) == 0 {
		return
	}
	for _, row := range rows {
		calAndPackExtraTarget(ctx, req, targetMetaMap, totalTargetMap, row.Children)
		row.TargetList = calAndPackExtraTargetByRow(ctx, req, targetMetaMap, totalTargetMap, row.TargetList)
	}
}

func calAndPackExtraTargetByRow(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, targetMetaMap map[string]*dao.TargetMetaInfo, totalTargetMap map[string]*analysis.TargetCardEntity, targetList []*analysis.TargetCardEntity) []*analysis.TargetCardEntity {
	newTargetList := make([]*analysis.TargetCardEntity, 0)
	targetListMap := make(map[string]*analysis.TargetCardEntity)
	for _, target := range targetList {
		targetListMap[target.Name] = target
	}

	// 判断大盘大促指标是否包含国补数据
	var actProdNeedGov, overallNeedGov bool
	if req.TargetConfigList != nil && req.TargetConfigList.GovTargetConfig != nil {
		if req.TargetConfigList.GovTargetConfig.ActNeedGov {
			actProdNeedGov = true
		}
		if req.TargetConfigList.GovTargetConfig.OverallNeedGov {
			overallNeedGov = true
		}
	}
	// 占比大盘整体指标
	for targetValue, rule := range BigactExtraTargetsDivisionTotalRulesWithGovTarget {
		_, exist := targetMetaMap[targetValue]
		if !exist {
			logs.CtxInfo(ctx, "目标指标不存在， targetValue = %s", targetValue)
			continue
		}
		numerator := pickTargetName(ctx, rule.Numerator, actProdNeedGov, overallNeedGov)
		denominator := pickTargetName(ctx, rule.Denominator, actProdNeedGov, overallNeedGov)

		_, exist = targetListMap[numerator]
		if !exist {
			logs.CtxInfo(ctx, "计算指标%s的分子指标%s不存在", targetValue, numerator)
			continue
		}
		_, exist = totalTargetMap[denominator]
		if !exist {
			logs.CtxInfo(ctx, "计算指标%s的分母指标%s不存在", targetValue, denominator)
			continue
		}
		if totalTargetMap[denominator].Value == 0 {
			logs.CtxInfo(ctx, "计算指标%s的分母指标%s值为0", targetValue, denominator)
			continue
		}
		value := targetListMap[numerator].Value / totalTargetMap[denominator].Value
		newTarget, err := base_struct_condition.GetTargetEntity(ctx, value, targetMetaMap[targetValue])
		if err != nil {
			logs.CtxWarn(ctx, "GetTargetEntity err=%v", err)
			continue
		}
		newTargetList = append(newTargetList, newTarget)
	}
	// 占比大盘指标
	for targetValue, rule := range BigactExtraTargetsDivisionRulesWithGovTarget {
		_, exist := targetMetaMap[targetValue]
		if !exist {
			logs.CtxInfo(ctx, "目标指标不存在， targetValue = %s", targetValue)
			continue
		}
		numerator := pickTargetName(ctx, rule.Numerator, actProdNeedGov, overallNeedGov)
		denominator := pickTargetName(ctx, rule.Denominator, actProdNeedGov, overallNeedGov)

		_, exist = targetListMap[numerator]
		if !exist {
			logs.CtxInfo(ctx, "计算指标%s的分子指标%s不存在", targetValue, numerator)
			continue
		}
		_, exist = targetListMap[denominator]
		if !exist {
			logs.CtxInfo(ctx, "计算指标%s的分母指标%s不存在", targetValue, denominator)
			continue
		}
		if targetListMap[denominator].Value == 0 {
			logs.CtxInfo(ctx, "计算指标%s的分母指标%s值为0", targetValue, denominator)
			continue
		}
		value := targetListMap[numerator].Value / targetListMap[denominator].Value
		newTarget, err := base_struct_condition.GetTargetEntity(ctx, value, targetMetaMap[targetValue])
		if err != nil {
			logs.CtxWarn(ctx, "GetTargetEntity err=%v", err)
			continue
		}
		newTargetList = append(newTargetList, newTarget)
	}

	// 国补指标判断
	for _, target := range targetList {
		// 1. 先判断是大盘还是大促
		var needGov bool
		// 仅处理与国补相关的指标
		if slices.ContainsString(GovTargetNameList, target.Name) {
			if strings.Contains(target.Extra.AttributeType, "大盘") {
				needGov = overallNeedGov
			} else if strings.Contains(target.Extra.AttributeType, "大促") {
				needGov = actProdNeedGov
			}

			// 2. 根据指标名是否含 gov 决定保留与否
			hasGov := strings.Contains(target.Name, "gov")
			if hasGov && !needGov {
				continue
			}
			if !hasGov && needGov {
				continue
			}
		}
		newTargetList = append(newTargetList, target)
	}

	return newTargetList
}

func (d *GreatValueBuyService) analysisRowToGreatRow(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, rows []*analysis.MultiDimFullListRow) []*great_value_buy.GetGreatValueBuyMultiDimRow {
	greatRows := make([]*great_value_buy.GetGreatValueBuyMultiDimRow, 0)
	for _, row := range rows {
		if row == nil {
			continue
		}
		greatRow := &great_value_buy.GetGreatValueBuyMultiDimRow{
			DisplayName: row.DisplayName,
			EnumValue:   row.EnumValue,
			TargetList:  row.TargetList,
			Children:    d.analysisRowToGreatRow(ctx, req, row.Children),
			DimKey:      row.DimKey,
			ProdTagCode: row.ProdTagCode,
		}
		if req.BaseReq.BizType == dimensions.BizType_GreatValueBuyBigLink {
			TargetUnitOptimize(greatRow.TargetList)
		}
		greatRows = append(greatRows, greatRow)
	}
	return greatRows
}

func (d *GreatValueBuyService) getClusterSqlStr(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, isTotal, isTrend bool) (string, string, string, error) {
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	filterStrs := make([]string, 0)
	for _, dim := range req.BaseReq.Dimensions {
		dimInfo := dimMap[convert.ToInt64(dim.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", dim.Id)
			return "", "", "", errors.New("未查询到维度信息")
		}
		if clusterDimensionMap[dimInfo.DimColumn] {
			values := make([]string, 0)
			for _, v := range dim.SelectedValues {
				if v.Code == "" {
					continue
				}
				values = append(values, "'"+v.Code+"'")
			}
			if len(values) > 0 && dim.SelectedOperator == base.OperatorType_IN {
				filter := fmt.Sprintf("%s in (%s)", dimInfo.DimColumn, strings.Join(values, ","))
				filterStrs = append(filterStrs, filter)
			}
		}
	}

	// 获取分析的维度信息
	drillGroupCols := make([]string, 0)
	trendGroupCols := make([]string, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return "", "", "", errors.New("未查询到维度信息")
		}
		values := make([]string, 0)
		for _, v := range attr.DimInfo.SelectedValues {
			values = append(values, "'"+v.Code+"'")
		}
		if len(values) > 0 && clusterDimensionMap[dimInfo.DimColumn] {
			if attr.DimInfo.SelectedOperator == base.OperatorType_IN {
				filter := fmt.Sprintf("%s in (%s)", dimInfo.DimColumn, strings.Join(values, ","))
				filterStrs = append(filterStrs, filter)
			}
		}
		if !isTotal {
			drillGroupCols = append(drillGroupCols, dimInfo.DimColumn)
		}
		if isTrend && !attr.NeedDrillDown {
			if len(trendGroupCols) == 0 {
				trendGroupCols = append(trendGroupCols, dimInfo.DimColumn)
			}
		}
	}
	clusterFilterParams := ""
	if len(filterStrs) > 0 {
		clusterFilterParams = strings.Join(filterStrs, " and ")
	}
	if isTotal {
		trendGroupCols = []string{}
	}
	if isTrend {
		trendGroupCols = append(trendGroupCols, "date")
	}
	clusterSubSelect := make([]string, 0)
	clusterNewGroupCols := make([]string, 0)
	groupCols := drillGroupCols
	if isTrend {
		groupCols = trendGroupCols
	}
	for _, col := range groupCols {
		if clusterDimensionMap[col] {
			if col == "date" {
				clusterSubSelect = append(clusterSubSelect, col)
			} else {
				clusterSubSelect = append(clusterSubSelect, fmt.Sprintf("cast(%s as String) as %s", col, col))
			}
			clusterNewGroupCols = append(clusterNewGroupCols, col)
		}
	}
	clusterSubSelectStr, clusterNewGroupColsStr := "", ""
	if len(clusterSubSelect) > 0 {
		clusterSubSelectStr = strings.Join(clusterSubSelect, ",")
	}
	if len(clusterNewGroupCols) > 0 {
		clusterNewGroupColsStr = base_struct_condition.GenerateDimKeyJoinOn(clusterNewGroupCols)
	}
	return clusterSubSelectStr, clusterNewGroupColsStr, clusterFilterParams, nil
}

func GetBigActOSDateExpr(ctx context.Context, startTime, endTime string) (string, error) {
	tccConf, err := tcc.GetClusterSwitchConf(ctx)
	if err != nil || tccConf == nil || tccConf.DiagnosisBigAct == nil {
		return "", err
	}
	logs.CtxInfo(ctx, "GetBigActOSDateExpr clusterSwitchConf tableConf = %v", tccConf)
	var result map[consts.DateType][]*time_utils.DateSplitResult
	if tccConf.DiagnosisBigAct.Switch {
		result, err = time_utils.GetCustomTimeStrSplit(startTime, endTime, []consts.DateType{consts.DateType_DAY, consts.DateType_WEEK})
		if err != nil {
			logs.CtxError(ctx, "GetCustomTimeStrSplit err, startTime=%s, endTime=%s, err=%v", startTime, endTime, err)
			return "", err
		}
	} else {
		startTimeFormat, _ := time.Parse(consts.Fmt_Date, startTime)
		endTimeFormat, _ := time.Parse(consts.Fmt_Date, endTime)
		result = time_utils.GetBigPromotionTimeSplit(startTimeFormat.Unix(), endTimeFormat.Unix())
	}

	dataExpr := &sql_parse.Expression{
		Logic:    sql_parse.OR,
		Children: make([]*sql_parse.Expression, 0),
	}
	for dateType, splitVList := range result {
		if len(splitVList) == 0 {
			continue
		}

		dates := make([]string, 0)
		for _, v := range splitVList {
			dates = append(dates, v.EndDate)
		}
		fmt.Println(dates)

		tmp := sql_parse.NewCQL()
		tmp.AddWhere("date", sql_parse.IN, dates).AddWhere("days_type", sql_parse.EQUAL, string(dateType))
		dataExpr.Children = append(dataExpr.Children, tmp.WhereClause)
	}
	return sql_parse.NewCQL().ParseExpression(dataExpr), nil
}

func CheckThreshold(ctx context.Context, value1, value2 float64, operator great_value_buy.ThresholdOperatorType) bool {
	switch operator {
	case great_value_buy.ThresholdOperatorType_GREATER_EQUAL_THAN:
		return 100*value1 >= value2
	case great_value_buy.ThresholdOperatorType_LESS_EQUAL_THAN:
		return 100*value1 <= value2
	case great_value_buy.ThresholdOperatorType_GREATER_THAN:
		return 100*value1 > value2
	case great_value_buy.ThresholdOperatorType_LESS_THAN:
		return 100*value1 < value2
	default:
		logs.CtxError(ctx, "invalid threshold operator:%v", operator)
	}
	return false
}

func genBigActYOYFilterParams(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo) (map[string]interface{}, error) {

	newBaseReq := &dimensions.ProductAnalysisBaseStruct{}
	_ = copier.CopyWithOption(newBaseReq, req, copier.Option{DeepCopy: true})
	mainProjectIdMap, _ := biz_info.GetBigPromotionMainProjectMap(ctx)
	for _, dim := range newBaseReq.Dimensions {
		if dim.Id == "10366" {
			for _, v := range dim.SelectedValues {
				if res, ok := mainProjectIdMap[v.Code]; ok {
					v.Code = res
				}
			}
		}
	}
	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: newBaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	})
	if err != nil {
		logs.CtxError(ctx, "genBigActYOYFilterParams err: %v", err)
		return nil, err
	}
	return curr, nil
}
