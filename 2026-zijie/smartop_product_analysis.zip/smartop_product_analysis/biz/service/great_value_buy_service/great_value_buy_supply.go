package great_value_buy_service

import (
	"context"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
)

func (d *GreatValueBuyService) GetGreatValueBuySupplyAnalysis(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuySupplyAnalysisData, err error) {
	resp = &great_value_buy.GetGreatValueBuySupplyAnalysisData{}
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	ctx = context.WithValue(ctx, consts.CtxAllDatePoolFlag, "供给分析")
	// 获取分析的维度信息
	var groupCols []string
	//var prodCodeTagBaseDims = make([]*dimensions.SelectedDimensionInfo, 0)
	//for _, attr := range req.BaseReq.GroupAttrs {
	//	prodCodeTagBaseDims = append(prodCodeTagBaseDims, attr.DimInfo)
	//}
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)

		//if len(groupCols) == 0 {
		//	logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
		//	return resp, errors.New("多维分析未传入多维配置")
		//}
	}
	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: append(groupCols, base_struct_condition.GenerateDimKey(groupCols, consts.Empty)),
	})
	curr["diff_start_date"] = req.BaseReq.CompareStartDate
	curr["diff_end_date"] = req.BaseReq.CompareEndDate
	if err != nil {
		return
	}
	apiPath := BigLinkSupplyApi
	if req.BaseReq.BizType == dimensions.BizType_GreatValueBuySearch {
		apiPath = SearchSupplyApi
	}
	cc := co.NewConcurrent(ctx)
	var currTargetList []*base_struct_condition.KeyColsTargetEntity
	if apiPath == BigLinkSupplyApi {
		cc.GoV2(func() error {
			value, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, NeedDistribution: true,
				KeyCols: append(groupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
			})
			if err != nil {
				return err
			}
			currTargetList = append(currTargetList, value...)
			return nil
		})
	} else {
		for _, api := range searchSupplyApiList {
			_api := api
			cc.GoV2(func() error {
				value, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
					Params: curr, Sql: consts.Empty, ApiPath: _api, BizType: req.BaseReq.BizType, NeedDistribution: true,
					KeyCols: append(groupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
				})
				if err != nil {
					return err
				}
				currTargetList = append(currTargetList, value...)
				return nil
			})
		}
	}
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "getTrendMap err=%v", err)
		return resp, err
	}

	if len(currTargetList) >= 10000 {
		logs.CtxWarn(ctx, "[GetProductAnalysisMultiDimList]获取的多维组合数量=%v+，超过1w", len(currTargetList))
		return resp, errors.New("MAX_10000_LIMIT_ERROR")
	}
	resp = &great_value_buy.GetGreatValueBuySupplyAnalysisData{
		TargetList: make([]*great_value_buy.GetGreatValueBuySupplyAnalysisTarget, 0),
	}
	if len(currTargetList) == 0 {
		return resp, nil
	}
	targetMap := make(map[string]float64, 0)
	targetNameMap := make(map[string]*great_value_buy.GetGreatValueBuySupplyAnalysisTarget, 0)
	// 超值购-聚合链接
	if req.BaseReq.BizType == dimensions.BizType_GreatValueBuyBigLink {
		for _, targetEntity := range currTargetList[0].TargetEntity {
			targetMap[targetEntity.Name] = targetEntity.Value
		}
		if req.BaseReq.BizType == dimensions.BizType_GreatValueBuyBigLink {
			TargetUnitOptimize(currTargetList[0].TargetEntity)
		}

		for _, targetEntity := range currTargetList[0].TargetEntity {
			greatEntity := &great_value_buy.GetGreatValueBuySupplyAnalysisTarget{}
			parentValue := targetMap[targetParentTargetMap[targetEntity.Name]]
			if parentValue != 0 {
				parentValue = targetEntity.Value / parentValue
			}
			targetEntity.Extra = &analysis.TargetCardExtraInfo{
				MarketPercent: parentValue,
				PercentFlag:   true,
			}
			dimensionInfo, _ := d.DimensionService.GetDimensionByID(ctx, targetDimensionMap[targetEntity.Name])
			greatEntity.DimensionInfo = dimensionInfo
			greatEntity.Target = targetEntity
			targetNameMap[targetEntity.Name] = greatEntity
		}
		for targetName, targetEntity := range targetNameMap {
			if targetName == targetParentTargetMap[targetName] {
				resp.TargetList = append(resp.TargetList, targetEntity)
			} else {
				if targetNameMap[targetParentTargetMap[targetName]] != nil {
					targetNameMap[targetParentTargetMap[targetName]].ChildrenTargets = append(targetNameMap[targetParentTargetMap[targetName]].ChildrenTargets, targetEntity)
				}
			}
		}
	} else if req.BaseReq.BizType == dimensions.BizType_GreatValueBuySearch {
		// 超值购-搜索
		for _, v := range currTargetList {
			for _, targetEntity := range v.TargetEntity {
				targetMap[targetEntity.Name] = targetEntity.Value
			}
		}
		for _, v := range currTargetList {
			for _, targetEntity := range v.TargetEntity {
				greatEntity := &great_value_buy.GetGreatValueBuySupplyAnalysisTarget{}
				parentValue := targetMap[targetParentTargetMap[targetEntity.Name]]
				if parentValue != 0 {
					parentValue = targetEntity.Value / parentValue
				}
				targetEntity.Extra = &analysis.TargetCardExtraInfo{
					MarketPercent: parentValue,
					PercentFlag:   true,
				}
				dimensionInfo, _ := d.DimensionService.GetDimensionByID(ctx, targetDimensionMap[targetEntity.Name])
				greatEntity.DimensionInfo = dimensionInfo
				greatEntity.Target = targetEntity
				targetNameMap[targetEntity.Name] = greatEntity
			}
		}
		for targetName, targetEntity := range targetNameMap {
			if targetName == targetParentTargetMap[targetName] {
				resp.TargetList = append(resp.TargetList, targetEntity)
			} else {
				if targetNameMap[targetParentTargetMap[targetName]] != nil {
					targetNameMap[targetParentTargetMap[targetName]].ChildrenTargets = append(targetNameMap[targetParentTargetMap[targetName]].ChildrenTargets, targetEntity)
				}
			}
		}
	}
	return resp, nil
}
