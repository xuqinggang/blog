package great_value_buy_service

import (
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"context"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/jinzhu/copier"
)

type BaseInfo struct {
	SignProdCnt    int64   `json:"sign_prod_cnt"`
	GoodProdThresh float64 `json:"sign_prod_thresh"`
}

type OptimizeItem struct {
	ActionCode string `json:"action_code"`
	CrmCode    string `json:"crm_code"`
	ProdCnt    int64  `json:"prod_cnt"`
}

type OptimizeProdItem struct {
	ActionCode   string                       `json:"action_code"`
	CrmCode      string                       `json:"crm_code"`
	ProdID       int64                        `json:"prod_id"`
	TargetEntity []*analysis.TargetCardEntity `json:"target_entity"`
	BasicInfo    *basic_info.ProductBasicInfo `json:"basic_info"`
}

type ProdItem struct {
	ProdID         int64   `json:"prod_id"`
	ProdName       string  `json:"prod_name"`
	ShopId         int64   `json:"shop_id"`
	ShopName       string  `json:"shop_name"`
	LeafCateId     int64   `json:"leaf_cate_id"`
	ShowCnt        int64   `json:"show_cnt"`
	ClkCnt         int64   `json:"clk_cnt"`
	OrdCnt         float64 `json:"ord_cnt"`
	Gmv            float64 `json:"gmv"`
	Opm            float64 `json:"opm"`
	Gpm            float64 `json:"gpm"`
	CompareShowCnt int64   `json:"compare_show_cnt"`
	CompareClkCnt  int64   `json:"compare_clk_cnt"`
	CompareOrdCnt  float64 `json:"compare_ord_cnt"`
	CompareGmv     float64 `json:"compare_gmv"`
	CompareOpm     float64 `json:"compare_opm"`
	CompareGpm     float64 `json:"compare_gpm"`
	QualityScore   float64 `json:"quality_score"`
	// 叶子选择最新日期均值
	LeafShowCnt int64   `json:"leaf_show_cnt"`
	LeafClkCnt  int64   `json:"leaf_clk_cnt"`
	LeafOrdCnt  float64 `json:"leaf_ord_cnt"`
	LeafGmv     float64 `json:"leaf_gmv"`
	LeafOpm     float64 `json:"leaf_opm"`
	LeafGpm     float64 `json:"leaf_gpm"`
}

func GetOptimizeItemDetail(ctx context.Context, service IGreatValueBuyService, req *great_value_buy.GetGreatValueBuyCommonRequest, optimizeConfigs *great_value_buy.OptimizeActionConfig) (resp *great_value_buy.GetOptimizeItemDetailResponse, err error) {
	resp = &great_value_buy.GetOptimizeItemDetailResponse{BaseResp: &base.BaseResp{}}

	// 参数校验
	result, err := checkAndInitParams(req, optimizeConfigs)
	if err != nil {
		logs.CtxError(ctx, "GetOptimizeItemDetail|checkParams err:%s", err.Error())
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		return
	}
	if !result {
		return
	}

	tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
	if err != nil {
		return nil, err
	}

	cc := co.NewConcurrent(ctx)

	// 查询可优化项及GMV收益
	itemCode2EstimateGmvMap := make(map[string]string)
	//cc.GoV2(func() error {
	//	// 查询可优化项及对应GMV收益
	//	itemCode2EstimateGmvMap, err = GetOptimizeItemGmvMap(ctx, service, req)
	//	return err
	//})
	itemCode2EstimateGmvMap, err = GetOptimizeItemGmvMap(ctx, service, req)

	reqCanOptimizeItems := make([]*great_value_buy.OptimizeItem, 0)
	for _, item := range req.OptimizeItems {
		if _, ok := itemCode2EstimateGmvMap[item.Code]; ok {
			reqCanOptimizeItems = append(reqCanOptimizeItems, &great_value_buy.OptimizeItem{
				Code: item.Code,
			})
		}
	}
	// 查询可优化项数据
	var baseInfo *BaseInfo
	var baseCurr map[string]interface{}
	var curr map[string]interface{}
	optimizeItems := make([]*OptimizeItem, 0)
	cc.GoV2(func() error {
		// 获取业务线的维度信息
		dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

		// 2. 构造流量分组维度
		flowGroupReq := &great_value_buy.GetGreatValueBuyCommonRequest{}
		copier.Copy(&flowGroupReq, &req)
		dimension := make([]*dimensions.SelectedDimensionInfo, 0)
		var flowGroupReqParams map[string]interface{}
		for _, attr := range req.BaseReq.Dimensions {
			dimInfo, exist := dimMap[convert.ToInt64(attr.Id)]
			if !exist {
				return errors.New("dimension attr not exist err")
			}
			if dimensions.DimensionAttributeType(dimInfo.DimensionCategory) == dimensions.DimensionAttributeType_Product {
				continue
			}
			dimension = append(dimension, attr)
		}
		flowGroupReq.BaseReq.Dimensions = dimension
		flowGroupReqParams, err = base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
			BaseStruct: flowGroupReq.BaseReq,
			DimMap:     dimMap,
			UvFlag:     flowGroupReq.BaseReq.UvFlag,
		}, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			return err
		}
		if len(flowGroupReqParams) <= 0 {
			return errors.New("GetOptimizeItemDetail|flowGroupReqParams len <= 0")
		}

		// 大盘口径需要带报名状态
		baseCurr, err = base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
			BaseStruct: req.BaseReq,
			DimMap:     dimMap,
			UvFlag:     req.BaseReq.UvFlag,
		}, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			return err
		}
		baseCurr["flow_group_filter_param"] = flowGroupReqParams["filter_param"]

		// 构建查询参数
		dms := make([]*dimensions.SelectedDimensionInfo, 0)
		for _, v := range req.BaseReq.Dimensions {
			// 报名状态筛选项
			if v == nil || v.Id == "10372" {
				continue
			}
			dms = append(dms, v)
		}
		req.BaseReq.Dimensions = dms
		curr, err = base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
			BaseStruct: req.BaseReq,
			DimMap:     dimMap,
			UvFlag:     req.BaseReq.UvFlag,
		}, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			return err
		}
		if len(curr) <= 0 {
			return errors.New("GetOptimizeItemDetail|cur len <= 0")
		}

		currDateExpr, _ := GetBigActOSDateExpr(ctx, req.BaseReq.StartDate, req.BaseReq.EndDate)
		compareDateExpr, _ := GetBigActOSDateExpr(ctx, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
		baseCurr["curr_date_expr"] = currDateExpr
		baseCurr["compare_date_expr"] = compareDateExpr
		curr["curr_date_expr"] = currDateExpr
		curr["compare_date_expr"] = compareDateExpr
		// 查询基础数据
		baseInfo, err = getBaseInfo(ctx, baseCurr, tableConf)
		if err != nil {
			return err
		}
		if baseInfo == nil {
			return errors.New("GetOptimizeItemDetail|BaseInfo is nil")
		}

		// 查询可优化项
		curr["sign_prod_thresh"] = baseInfo.GoodProdThresh
		curr["optimize_items"] = toOptimizeItems(reqCanOptimizeItems)
		curr["limit"] = 0 // group 分组查询
		optimizeItems, err = getOptimizeItems(ctx, curr, tableConf)
		return err
	})

	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "GetOptimizeItemDetail|WaitV2 err:%s", err.Error())
		return resp, err
	}

	// 组装返回结果
	resp.Data = toData(optimizeItems, itemCode2EstimateGmvMap, optimizeConfigs, baseInfo.SignProdCnt)
	return resp, nil
}

func GetOptimizeItemGmvMap(ctx context.Context, service IGreatValueBuyService, req *great_value_buy.GetGreatValueBuyCommonRequest) (map[string]string, error) {
	gmvResp, err := service.GetOptimizeActionInfo(ctx, req)
	if err != nil {
		return nil, err
	}
	if gmvResp == nil {
		return nil, errors.New("GetOptimizeActionInfo return nil")
	}
	itemCode2EstimateGmvMap := toOptimizeItemGmvMap(gmvResp.OptimizeInfos)
	return itemCode2EstimateGmvMap, nil
}

func toOptimizeItemGmvMap(optimizeItems []*great_value_buy.OptimizeActionInfo) map[string]string {
	resp := make(map[string]string, 0)
	for _, v := range optimizeItems {
		if v == nil || v.OptimizeItem == nil {
			continue
		}
		resp[v.OptimizeItem.Code] = v.EstimateIncreaseGmv
	}
	return resp
}

func toOptimizeItems(items []*great_value_buy.OptimizeItem) []string {
	resp := make([]string, 0)
	for _, v := range items {
		resp = append(resp, v.Code)
	}
	return resp
}

func toData(items []*OptimizeItem, gmvMap map[string]string, optimizeConfigs *great_value_buy.OptimizeActionConfig, cnt int64) *great_value_buy.GetOptimizeItemDetailData {
	return &great_value_buy.GetOptimizeItemDetailData{
		OptimizeItemDetailList: toOptimizeItemDetail(items, gmvMap, optimizeConfigs, cnt),
		PageInfo:               &base.PageResp{Total: int64(len(items))},
	}
}

func toOptimizeItemDetail(items []*OptimizeItem, gmvMap map[string]string, optimizeConfigs *great_value_buy.OptimizeActionConfig, cnt int64) []*great_value_buy.OptimizeItemDetail {
	resp := make([]*great_value_buy.OptimizeItemDetail, 0)

	if optimizeConfigs == nil {
		return resp
	}

	item2Name, crm2Name := initMap(optimizeConfigs)

	for _, v := range items {
		if item2Name[v.ActionCode] == "" {
			continue
		}
		// 代表为非可优化项
		if gmvMap[v.ActionCode] == "" {
			continue
		}
		resp = append(resp, &great_value_buy.OptimizeItemDetail{
			OptimizeItem: &great_value_buy.OptimizeItem{
				Code: v.ActionCode,
				Name: item2Name[v.ActionCode],
			},
			CrmTask: &great_value_buy.CrmTask{
				Code: v.CrmCode,
				Name: crm2Name[v.CrmCode],
			},
			CanOptimizeProdCnt: v.ProdCnt,
			BigPromotionRate:   float64(v.ProdCnt) / float64(cnt),
			GmvRevenue:         gmvMap[v.ActionCode],
		})
	}
	return resp
}

func initMap(optimizeConfigs *great_value_buy.OptimizeActionConfig) (map[string]string, map[string]string) {
	// 可优化项到名称映射
	item2Name := make(map[string]string, 0)
	for _, v := range optimizeConfigs.OptimizeItems {
		if v == nil {
			continue
		}
		item2Name[v.Code] = v.Name
	}

	// crm任务code到名称映射
	crm2Name := make(map[string]string, 0)
	for _, v := range optimizeConfigs.CrmActions {
		if v == nil {
			continue
		}
		crm2Name[v.Code] = v.Name
	}
	return item2Name, crm2Name
}

func getOptimizeItems(ctx context.Context, curr map[string]interface{}, tableConf *tcc.BigActTableConfig) ([]*OptimizeItem, error) {
	var optimizeItems []*OptimizeItem
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(curr, tableConf.ItemOptimize, param.SinkTable("optimize_item")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeView(param.SourceTable("optimize_item"), &optimizeItems)
	app.Use(f.ToStack(ctx))
	_, err := app.Run(ctx)
	return optimizeItems, err
}

func getBaseInfo(ctx context.Context, curr map[string]interface{}, tableConf *tcc.BigActTableConfig) (*BaseInfo, error) {
	var baseInfo *BaseInfo
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(curr, tableConf.BaseOptimize, param.SinkTable("base_info")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeView(param.SourceTable("base_info"), &baseInfo)
	app.Use(f.ToStack(ctx))
	_, err := app.Run(ctx)
	return baseInfo, err
}

func checkAndInitParams(req *great_value_buy.GetGreatValueBuyCommonRequest, optimizeConfigs *great_value_buy.OptimizeActionConfig) (bool, error) {
	if req == nil || req.BaseReq == nil {
		return false, errors.New("请求参数为空")
	}

	// 清空筛选项：商品报名状态、大促项目（每种可优化项都有报名状态限制）
	dms := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, v := range req.BaseReq.Dimensions {
		if v == nil {
			continue
		}
		// 大促项目筛选项
		if v.Id == "10366" {
			continue
		}
		dms = append(dms, v)
	}
	req.BaseReq.Dimensions = dms

	if req.OrderBy != nil && (req.OrderBy.ColumnName == nil || *req.OrderBy.ColumnName == "") {
		req.OrderBy = nil
	}

	return checkOptimizeItem(req, optimizeConfigs)
}

func checkOptimizeItem(req *great_value_buy.GetGreatValueBuyCommonRequest, optimizeConfigs *great_value_buy.OptimizeActionConfig) (bool, error) {
	if optimizeConfigs == nil || len(optimizeConfigs.OptimizeItems) <= 0 {
		return false, errors.New("优化项配置为空")
	}

	// 默认，优化项配置
	if len(req.OptimizeItems) <= 0 {
		req.OptimizeItems = optimizeConfigs.OptimizeItems
	}

	// 过滤，不可优化项
	//var items []*great_value_buy.OptimizeItem
	//for _, v := range req.OptimizeItems {
	//	if v == nil {
	//		continue
	//	}
	//	if itemCode2EstimateGmvMap[v.Code] == "" {
	//		continue
	//	}
	//	items = append(items, v)
	//}
	//req.OptimizeItems = items

	// crm任务与优化项映射，可优化项取交集
	if len(req.CrmActions) > 0 {
		optimizeItems := make([]*great_value_buy.OptimizeItem, 0)
		for _, v := range req.CrmActions {
			if v == nil {
				continue
			}
			if v.Code == "crm_sign_up" {
				optimizeItems = append(optimizeItems, []*great_value_buy.OptimizeItem{{
					Code: "new_prod_sign_up",
					Name: "新品追报名",
				}, {
					Code: "old_prod_sign_up",
					Name: "老品追报名",
				}, {
					Code: "opportunity_prod_sign_up",
					Name: "机会品追报名",
				}}...)
			}
			if v.Code == "crm_quality_score_optimize" {
				optimizeItems = append(optimizeItems, []*great_value_buy.OptimizeItem{{
					Code: "optimize_quality_score",
					Name: "优化质量分",
				}}...)
			}
			if v.Code == "crm_commission_optimize" {
				optimizeItems = append(optimizeItems, []*great_value_buy.OptimizeItem{{
					Code: "optimize_commission_rate",
					Name: "优化佣金率",
				}}...)
			}
		}
		req.OptimizeItems = mixItems(req.OptimizeItems, optimizeItems)
	}

	if len(req.OptimizeItems) <= 0 {
		return false, nil
	}

	return true, nil
}

func checkAndFillterItem(req *great_value_buy.GetGreatValueBuyCommonRequest, itemCode2EstimateGmvMap map[string]string) bool {
	if req == nil {
		return false
	}
	var items []*great_value_buy.OptimizeItem
	for _, v := range req.OptimizeItems {
		if v == nil {
			continue
		}
		if itemCode2EstimateGmvMap[v.Code] == "" {
			continue
		}
		items = append(items, v)
	}
	req.OptimizeItems = items
	if len(items) <= 0 {
		return false
	}
	return true
}

func mixItems(base []*great_value_buy.OptimizeItem, items []*great_value_buy.OptimizeItem) []*great_value_buy.OptimizeItem {
	if len(items) <= 0 {
		return base
	}

	resp := make([]*great_value_buy.OptimizeItem, 0)
	for _, v := range base {
		if v == nil {
			continue
		}
		for _, vv := range items {
			if vv == nil {
				continue
			}
			if v.Code != vv.Code {
				continue
			}
			resp = append(resp, &great_value_buy.OptimizeItem{
				Code: v.Code,
				Name: v.Name,
			})
		}
	}
	return resp
}
