package great_value_buy_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"context"
	"reflect"
	"testing"
)

func TestGreatValueBuyService_getGuessCoreTreeItemsV2(t *testing.T) {
	type fields struct {
		DimensionListDao      dao.IDimensionListDao
		DimensionEnumDao      dao.IDimensionEnumDao
		AttributeDao          dao.IAttributeDao
		DimensionService      dimension_service.IDimensionService
		DimensionBizListDao   dao.IDimensionBizListDao
		AttributionTreeBizDao dao.IAttributionTreeBizDao
		AnalysisService       analysis_service.IAnalysisService
	}
	type args struct {
		ctx context.Context
		req *great_value_buy.GetGreatValueBuyCommonRequest
	}
	tests := []struct {
		name              string
		fields            fields
		args              args
		wantTotal         *great_value_buy.GetGreatValueBuyAttributionCoreTreeData
		wantCoreTreeItems []*great_value_buy.GetGreatValueBuyAttributionCoreTreeData
		wantErr           bool
	}{
		{
			name: "<UNK>",
			args: args{
				req: &great_value_buy.GetGreatValueBuyCommonRequest{},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &GreatValueBuyService{
				DimensionListDao:      tt.fields.DimensionListDao,
				DimensionEnumDao:      tt.fields.DimensionEnumDao,
				AttributeDao:          tt.fields.AttributeDao,
				DimensionService:      tt.fields.DimensionService,
				DimensionBizListDao:   tt.fields.DimensionBizListDao,
				AttributionTreeBizDao: tt.fields.AttributionTreeBizDao,
				AnalysisService:       tt.fields.AnalysisService,
			}
			gotTotal, gotCoreTreeItems, err := d.getGuessCoreTreeItemsV2(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("getGuessCoreTreeItemsV2() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotTotal, tt.wantTotal) {
				t.Errorf("getGuessCoreTreeItemsV2() gotTotal = %v, want %v", gotTotal, tt.wantTotal)
			}
			if !reflect.DeepEqual(gotCoreTreeItems, tt.wantCoreTreeItems) {
				t.Errorf("getGuessCoreTreeItemsV2() gotCoreTreeItems = %v, want %v", gotCoreTreeItems, tt.wantCoreTreeItems)
			}
		})
	}
}
