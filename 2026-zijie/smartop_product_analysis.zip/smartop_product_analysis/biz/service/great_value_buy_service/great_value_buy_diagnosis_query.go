package great_value_buy_service

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"

	"code.byted.org/ecom/common/utils/async2"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"github.com/sanity-io/litter"
	"github.com/shopspring/decimal"
	"github.com/spf13/cast"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
)

type ProductInfo struct {
	ProdId     string                       `json:"prod_id"`
	SearchWord string                       `json:"search_word"`
	ProdName   string                       `json:"prod_name"`
	ProdImages []string                     `json:"prod_images"`
	TargetList []*analysis.TargetCardEntity `json:"target_list"`
}

var keyGroupColsQuery = []string{"search_word"}
var keyGroupColsQueryProd = []string{"prod_id"}

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisQueryList(ctx context.Context, commonReq *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQueryAnalysisData, err error) {
	resp = &great_value_buy.GetGreatValueBuyQueryAnalysisData{}
	req, err := d.adapterSearchAllChannelReq(ctx, SearchQueryListApi, commonReq)
	if err != nil {
		logs.CtxError(ctx, "适配请求体失败, err:"+err.Error())
		return
	}
	// 1. 补全信息
	//获取业务线元信息
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	if req.OrderBy == nil || req.OrderBy.ColumnName == nil {
		// 默认按照GMV排序
		req.OrderBy = &base.OrderByInfo{
			IsDesc:     true,
			ColumnName: convert.ToStringPtr("search_pv"),
		}
	}
	if req.PageReq == nil || req.PageReq.PageSize == 0 || req.PageReq.PageNum == 0 {
		req.PageReq = &base.PageInfo{
			PageSize: 10,
			PageNum:  1,
		}
	}

	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
		PageInfo:   req.PageReq,
	})

	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	orderByStr, err := updateCurrOrderBy(req)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if len(orderByStr) > 0 {
		curr["order_by"] = orderByStr
	}

	// 数据集数据做了预分类，在没有限制的情况下，增加默认筛选条件
	curr["fallback_all_filter_param"] = "sub_search_channel in ('all') and query_pool_type = 'all_billion'"

	targetMetaList, _ := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
	targetNameMetaMap := make(map[string]*dimensions.TargetMetaInfo, 0)
	targetMetaListStr := make([]string, 0)
	for _, targetMeta := range targetMetaList {
		targetNameMetaMap[targetMeta.Name] = targetMeta
		targetMetaListStr = append(targetMetaListStr, targetMeta.Name)
	}
	var fullList = make([]*great_value_buy.GetGreatValueBuyQueryAnalysisTarget, 0)
	var pageInfo = &base.PageResp{}

	var apiPath, overallApi string
	if len(req.DiagnosisTargetList) > 0 {
		switch req.DiagnosisTargetList[0].TargetName {
		case QuerySearchWord:
			apiPath = SearchQueryListApi
			overallApi = SearchQueryListOverallApi
		case QueryGMVTop20ppSearchWord:
			apiPath = SearchTopGmvQueryDetailListApi
			overallApi = SearchTopTopGmvQueryListTotalApi
		default:
			logs.CtxError(ctx, "未知的诊断目标")
			return nil, errors.New("未知的诊断目标")
		}
	} else {
		apiPath = SearchQueryListApi
		overallApi = SearchQueryListOverallApi
	}
	// 2. 获取数据
	var queryCnt int64
	var queryCntTargetList, currTargetList []*base_struct_condition.KeyColsTargetEntity
	var getQueryCntErr, getTargetListErr error
	as2 := async2.New(ctx)
	as2.Add(func() {
		queryCntTargetList, getQueryCntErr = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, ApiPath: overallApi, BizType: req.BaseReq.BizType, KeyCols: []string{"query_cnt"}, FilterTargetNames: targetMetaListStr,
		})
		if getQueryCntErr != nil || len(queryCntTargetList) == 0 || len(queryCntTargetList[0].KeyColValues) == 0 {
			logs.CtxError(ctx, "skuCntTargetList err=%v", getQueryCntErr)
			return
		}
		queryCnt = convert.ToInt64(queryCntTargetList[0].KeyColValues[0])
	})
	as2.Add(func() {
		currTargetList, getTargetListErr = getTargetListWithCompareResult(ctx, req.BaseReq.BizType, curr, apiPath, targetMetaListStr, keyGroupColsQuery)
	})
	as2.RunWithRecover()

	if getQueryCntErr != nil {
		resp.PageInfo = pageInfo
		resp.Query = fullList
		return resp, getQueryCntErr
	}
	if getTargetListErr != nil {
		resp.PageInfo = pageInfo
		resp.Query = fullList
		return resp, getTargetListErr
	}
	if len(currTargetList) >= 10000 {
		logs.CtxWarn(ctx, "[GetGreatValueBuyDiagnosisQueryList]获取的多维组合数量=%v+，超过1w", len(currTargetList))
		currTargetList = currTargetList[:10000]
	}

	// 3. 打包数据结果
	for _, keyTargetList := range currTargetList {
		row := &great_value_buy.GetGreatValueBuyQueryAnalysisTarget{
			TargetList: append(keyTargetList.TargetEntity),
			QueryName:  convert.ToString(keyTargetList.KeyColValues[0]),
		}
		analysis_service.SortTargetCardEntity(row.TargetList)
		fullList = append(fullList, row)
	}

	pageInfo = &base.PageResp{
		PageNum:  req.PageReq.PageNum,
		PageSize: req.PageReq.PageSize,
		Total:    queryCnt,
	}
	resp.Query = fullList
	resp.PageInfo = pageInfo
	return resp, nil
}

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisQuerySearchWords(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQuerySearchWordsData, err error) {
	resp = &great_value_buy.GetGreatValueBuyQuerySearchWordsData{}
	var apiPath, overallApi string
	if len(req.DiagnosisTargetList) > 0 {
		switch req.DiagnosisTargetList[0].TargetName {
		case QuerySearchWord:
			apiPath = SearchQuerySearchWordEnumApi
			overallApi = SearchQueryCntCanFilterSearchWord
		case QueryGMVTop20ppSearchWord:
			apiPath = SearchTopGmvSearchWordEnumApi
			overallApi = SearchQueryTopGmvCntCanFilterSearchWord
		default:
			logs.CtxError(ctx, "未知的诊断目标")
			return nil, errors.New("未知的诊断目标")
		}
	} else {
		apiPath = SearchQuerySearchWordEnumApi
		overallApi = SearchQueryCntCanFilterSearchWord
	}
	appendParams := analysis_service.AppendParams{
		OSParams: map[string]interface{}{
			"overall_api": overallApi,
		},
		OSApiPath: apiPath,
	}
	searchWords, totalCnt, err := d.getSearchWordList(ctx, req, appendParams)
	if err != nil {
		logs.CtxError(ctx, "获取搜索词失败, err:"+err.Error())
		return
	}
	resp.SearchWords = searchWords
	resp.PageInfo = &base.PageResp{
		Total:    totalCnt,
		PageNum:  req.PageReq.PageNum,
		PageSize: req.PageReq.PageSize,
	}
	return resp, nil
}

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisQueryListDownload(ctx context.Context, commonReq *great_value_buy.GetGreatValueBuyCommonRequest) (resp bool, err error) {
	req, err := d.adapterSearchAllChannelReq(ctx, SearchQueryListApi, commonReq)
	if err != nil {
		logs.CtxError(ctx, "适配请求体失败, err:"+err.Error())
		return
	}

	// 1. 补全信息
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "chensen.8535@bytedance.com"
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	// 2. 请求数据
	if req.OrderBy == nil || req.OrderBy.ColumnName == nil {
		// 默认按照GMV排序
		req.OrderBy = &base.OrderByInfo{
			IsDesc:     true,
			ColumnName: convert.ToStringPtr("search_pv"),
		}
	}

	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
	})

	// 增加limit, 默认10000条
	curr["limit"] = 10000
	curr["offset"] = 0
	if err != nil {
		return false, err
	}
	orderByStr, err := updateCurrOrderBy(req)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if len(orderByStr) > 0 {
		curr["order_by"] = orderByStr
	}

	curr["fallback_all_filter_param"] = "sub_search_channel in ('all') and query_pool_type = 'all_billion'"

	var apiPath string = SearchQueryListApi
	if len(req.DiagnosisTargetList) > 0 {
		switch req.DiagnosisTargetList[0].TargetName {
		case QuerySearchWord:
			apiPath = SearchQueryListApi
		case QueryGMVTop20ppSearchWord:
			apiPath = SearchTopGmvQueryDetailListApi
		default:
			logs.CtxError(ctx, "未知的诊断目标")
			return false, errors.New("未知的诊断目标")
		}
	}

	records, err := base_struct_condition.GetRecordsByOS(ctx, curr, consts.Empty, apiPath)
	if err != nil {
		return false, err
	}
	targetMetaList, _ := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
	targetNameMetaMap := make(map[string]*dimensions.TargetMetaInfo, 0)
	for _, targetMeta := range targetMetaList {
		targetNameMetaMap[targetMeta.Name] = targetMeta
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()

	f.ExeQueryCustom([]param.Source{param.SourceConst(records)}, genGetGreatValueBuyDiagnosisProductList, param.SinkTable("data"))
	f.ExeCustom([]param.Source{param.SourceTable("data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetCompareStartDate(), req.BaseReq.GetCompareEndDate())),
		param.SourceConst(targetNameMetaMap), param.SourceConst(keyGroupColsQuery)}, doExportGetGreatValueBuyDiagnosisQueryListData, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, err

}

func doExportGetGreatValueBuyDiagnosisQueryListData(ctx context.Context, table *onetable.Table, email string, analysisRange string, compareRange string, targetMetaMap map[string]*dimensions.TargetMetaInfo, groupCols []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	tableMap := table.ToRawMap()
	targetRawMap := make([]map[string]interface{}, 0)
	for col, _ := range tableMap[0] {
		if !slices.ContainsString(groupCols, col) {
			metaInfo, exist := targetMetaMap[col]
			if exist {
				targetRawMap = append(targetRawMap, map[string]interface{}{
					"display_order": metaInfo.DisplayOrder,
					"name":          metaInfo.DisplayName,
					"col_name":      metaInfo.Name,
				})
			}
		}
	}

	sort.Slice(targetRawMap, func(i, j int) bool {
		valueI := convert.ToInt64(targetRawMap[i]["display_order"])
		valueJ := convert.ToInt64(targetRawMap[j]["display_order"])
		return valueI < valueJ
	})

	sheet1 := lark_export.NewLarkDocSheet("当前周期"+analysisRange, table)
	sheet2 := lark_export.NewLarkDocSheet("对比周期"+compareRange, table)
	for _, keyCol := range keyGroupColsQuery {
		sheet1.AddColumn(keyCol, keyCol)
		sheet2.AddColumn(keyCol, keyCol)
	}
	for _, h := range targetRawMap {
		sheet1.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
		sheet2.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"])+"_compare")
	}
	formatter.AddSheet(sheet1, sheet2)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "超值购专项-query列表数据")
	return nil, formatter.Export(ctx, email, nil, nil)
}

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisQueryProdList(ctx context.Context, commonReq *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQueryProdAnalysisData, err error) {
	req, err := d.adapterSearchAllChannelReq(ctx, SearchQueryProdListApi, commonReq)
	if err != nil {
		logs.CtxError(ctx, "适配请求体失败, err:"+err.Error())
		return
	}

	// 2. 请求数据
	if req.OrderBy == nil || req.OrderBy.ColumnName == nil {
		// 默认按照GMV排序
		req.OrderBy = &base.OrderByInfo{
			IsDesc:     true,
			ColumnName: convert.ToStringPtr("show_pv"),
		}
	}
	if req.PageReq == nil || req.PageReq.PageSize == 0 || req.PageReq.PageNum == 0 {
		req.PageReq = &base.PageInfo{
			PageSize: 10,
			PageNum:  1,
		}
	}
	// 1. 补全信息
	//获取业务线元信息
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
		PageInfo:   req.PageReq,
	})

	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	orderByStr, err := updateCurrOrderBy(req)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if len(orderByStr) > 0 {
		curr["order_by"] = orderByStr
	}
	isTopGmvQueryType := false
	if len(req.DiagnosisTargetList) > 0 {
		switch req.DiagnosisTargetList[0].TargetName {
		case QuerySearchWord:
			isTopGmvQueryType = false
		case QueryGMVTop20ppSearchWord:
			isTopGmvQueryType = true
		default:
			logs.CtxError(ctx, "未知的诊断目标")
			return nil, errors.New("未知的诊断目标")
		}
	}

	api := SearchQueryProdListApi               // 超值购相关query 商品明细
	overAllApi := SearchQueryProdListOverallApi // 超值购相关query商品总量

	if len(req.CommonSelectList) > 0 { //存在搜索词
		curr["other_filter_param"] = " search_word in ('" + strings.Join(req.CommonSelectList, "','") + "')"
	} else { //没有搜索词
		//var searchWords []string
		if isTopGmvQueryType {
			// total接口
			topGMVQueryTotal, err := base_struct_condition.GetRecordsByOS(ctx, curr, consts.Empty, SearchTopTopGmvQueryListTotalApi)
			if err != nil {
				return nil, err
			}
			// 从 map 中获取 "query_cnt" 并转换为 int64
			if queryCntValue, ok := topGMVQueryTotal[0]["query_cnt"]; ok {
				curr["totalLimit"] = queryCntValue
			}
		}
	}
	if isTopGmvQueryType {
		curr["is_top_gmv"] = 1
		if len(req.CommonSelectList) > 0 { //有搜索词的时候 other_filter_param
			api = SearchTopGmvQueryProdDetailListApi
			overAllApi = SearchTopGmvQueryProdListOverallApi
		}

	} else {
		// 不做处理
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)

	f := flow.Empty()
	f.ExeQueryInvokerRaw(curr, api, param.SinkTable("product_detail")).SetParallel(true).SetMaxParallelNum(5)
	// 整体信息，商家数, 商品总数
	f.ExeQueryInvokerRaw(curr, overAllApi, param.SinkTable("overview_info")).SetParallel(true).SetMaxParallelNum(5)
	// 输入商品id信息，拿到商品图片信息
	f.ExeProduceCustom([]param.Source{param.SourceTable("product_detail")}, AddProductImage, param.SinkTable("product_images"))

	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("product_detail"), param.SinkTable("target_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"prod_id", "search_word"}))
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{"指标卡", "商品明细"})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeProduceSql(`
		select  prod_id,
		      search_word,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.display_order as display_order
		from    target_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		`, param.SinkTable("target_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})

	f.ExeProduceSql(`
	select  a.prod_id as prod_id,
			a.prod_name as prod_name,
			b.images as prod_images,
			a.search_word as search_word,
			(select * from target_data where target_data.prod_id = product_detail.prod_id and target_data.search_word = product_detail.search_word ) as target_list
	from    product_detail a
	left join
			product_images b
	on      a.prod_id=b.prod_id
`, param.SinkTable("res_data"))

	var productInfoList = make([]*ProductInfo, 0)
	var overviewInfo = make(map[string]int64)
	f.ExeView(param.SourceTable("res_data"), &productInfoList)
	f.ExeView(param.SourceTable("overview_info"), &overviewInfo)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)

	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	logs.CtxInfo(ctx, "productInfoList = "+litter.Sdump(productInfoList))
	resp, err = PackerProductDetail(req.GetPageReq().GetPageNum(), req.GetPageReq().GetPageSize(), overviewInfo, productInfoList, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "打包结果数据失败,err:"+err.Error())
		return nil, err
	}
	return resp, nil
}
func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisQueryProdListDownload(ctx context.Context, commonReq *great_value_buy.GetGreatValueBuyCommonRequest) (resp bool, err error) {
	req, err := d.adapterSearchAllChannelReq(ctx, SearchQueryProdListApi, commonReq)
	if err != nil {
		logs.CtxError(ctx, "适配请求体失败, err:"+err.Error())
		return
	}

	// 1. 补全信息
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "chensen.8535@bytedance.com"
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	// 2. 请求数据
	if req.OrderBy == nil || req.OrderBy.ColumnName == nil {
		// 默认按照GMV排序
		req.OrderBy = &base.OrderByInfo{
			IsDesc:     true,
			ColumnName: convert.ToStringPtr("show_pv"),
		}
	}

	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
	})

	// 增加limit, 默认10000条
	curr["limit"] = 10000
	curr["offset"] = 0
	if err != nil {
		return false, err
	}
	orderByStr, err := updateCurrOrderBy(req)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if len(orderByStr) > 0 {
		curr["order_by"] = orderByStr
	}

	var isTopGmvQueryType bool = false
	if len(req.DiagnosisTargetList) > 0 {
		switch req.DiagnosisTargetList[0].TargetName {
		case QuerySearchWord:
			isTopGmvQueryType = false
		case QueryGMVTop20ppSearchWord:
			isTopGmvQueryType = true
		default:
			logs.CtxError(ctx, "未知的诊断目标")
			return false, errors.New("未知的诊断目标")
		}
	}

	api := SearchQueryProdListApi // 超值购相关query 商品明细
	if len(req.CommonSelectList) > 0 {
		curr["other_filter_param"] = " search_word in ('" + strings.Join(req.CommonSelectList, "','") + "')"
	} else {
		// var searchWords []string
		if isTopGmvQueryType {
			// total接口
			topGMVQueryTotal, err := base_struct_condition.GetRecordsByOS(ctx, curr, consts.Empty, SearchTopTopGmvQueryListTotalApi)
			if err != nil {
				return false, err
			}
			// 从 map 中获取 "query_cnt" 并转换为 int64
			if queryCntValue, ok := topGMVQueryTotal[0]["query_cnt"]; ok {
				curr["totalLimit"] = queryCntValue
			}
		}
	}

	if isTopGmvQueryType {
		curr["is_top_gmv"] = 1
		if len(req.CommonSelectList) > 0 { //有搜索词的时候 other_filter_param
			api = SearchTopGmvQueryProdDetailListApi
		} else { //全量 -top20gmv totallimit
			api = SearchTopGmvQueryProdDetailListApi //商品明细
		}
	} else {
		// 不做处理
	}

	records, err := base_struct_condition.GetRecordsByOS(ctx, curr, consts.Empty, api)
	if err != nil {
		return false, err
	}
	targetMetaList, _ := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
	targetNameMetaMap := make(map[string]*dimensions.TargetMetaInfo, 0)
	for _, targetMeta := range targetMetaList {
		targetNameMetaMap[targetMeta.Name] = targetMeta
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()

	f.ExeQueryCustom([]param.Source{param.SourceConst(records)}, genGetGreatValueBuyDiagnosisProductList, param.SinkTable("data"))
	f.ExeCustom([]param.Source{param.SourceTable("data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetCompareStartDate(), req.BaseReq.GetCompareEndDate())),
		param.SourceConst(targetNameMetaMap), param.SourceConst(keyGroupColsQueryProd)}, doExportGetGreatValueBuyDiagnosisQueryProductListData, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, err
}

func doExportGetGreatValueBuyDiagnosisQueryProductListData(ctx context.Context, table *onetable.Table, email string, analysisRange string, compareRange string, targetMetaMap map[string]*dimensions.TargetMetaInfo, groupCols []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	tableMap := table.ToRawMap()
	targetRawMap := make([]map[string]interface{}, 0)
	for col, _ := range tableMap[0] {
		if !slices.ContainsString(groupCols, col) {
			metaInfo, exist := targetMetaMap[col]
			if exist {
				targetRawMap = append(targetRawMap, map[string]interface{}{
					"display_order": metaInfo.DisplayOrder,
					"name":          metaInfo.DisplayName,
					"col_name":      metaInfo.Name,
				})
			}
		}
	}

	sort.Slice(targetRawMap, func(i, j int) bool {
		valueI := convert.ToInt64(targetRawMap[i]["display_order"])
		valueJ := convert.ToInt64(targetRawMap[j]["display_order"])
		return valueI < valueJ
	})

	sheet1 := lark_export.NewLarkDocSheet("当前周期"+analysisRange, table)

	for _, keyCol := range keyGroupColsQueryProd {
		sheet1.AddColumn(keyCol, keyCol)

	}
	//todo add query name
	sheet1.AddColumn("搜索词", "search_word")
	for _, h := range targetRawMap {
		sheet1.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))

	}

	formatter.AddSheet(sheet1)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "超值购专项-query下商品明细数据")
	return nil, formatter.Export(ctx, email, nil, nil)
}

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisQuerySearchCntTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductListTrendData, err error) {
	resp = &great_value_buy.GetGreatValueBuyDiagnosisProductListTrendData{}
	var apiPath string
	if len(req.DiagnosisTargetList) == 0 {
		logs.CtxError(ctx, "未知的诊断目标")
		return nil, errors.New("未知的诊断目标")
	}
	if len(req.DiagnosisTargetList) > 1 {
		logs.CtxWarn(ctx, "诊断目标列表长度大于1")
	}
	switch req.DiagnosisTargetList[0].TargetName {
	case QuerySearchWord:
		apiPath = SearchQueryTrendApi
	case QueryGMVTop20ppSearchWord:
		apiPath = SearchQueryTopGmvTrendApi
	default:
		logs.CtxError(ctx, "未知的诊断目标")
		return nil, errors.New("未知的诊断目标")
	}
	appendParams := analysis_service.AppendParams{
		OSParams:  make(map[string]interface{}, 0),
		OSApiPath: apiPath,
	}
	trendList, err := d.getSearchCntTrend(ctx, req, appendParams)
	resp.TrendList = trendList
	return resp, nil
}

func (d *GreatValueBuyService) getSearchCntTrend(ctx context.Context, commonReq *great_value_buy.GetGreatValueBuyCommonRequest, appendParams analysis_service.AppendParams) (trendList []*great_value_buy.GetGreatValueBuyMultiDimTrendInfo, err error) {
	trendList = make([]*great_value_buy.GetGreatValueBuyMultiDimTrendInfo, 0)
	apiPath := appendParams.OSApiPath
	req, err := d.adapterSearchAllChannelReq(ctx, apiPath, commonReq)
	if err != nil {
		logs.CtxError(ctx, "适配请求体失败, err:"+err.Error())
		return
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	_, _, trend, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
	})
	if err != nil {
		return nil, err
	}
	if len(req.CommonSelectList) == 0 {
		return nil, errors.New("请选择趋势分析Query词")
	}
	trend["search_words"] = req.GetCommonSelectList()
	// 2. 数据查询
	trendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: trend, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, KeyCols: []string{"search_word"}, TrendCol: "date",
	})
	// 3. 数据处理
	newTrendMap := base_struct_condition.MergeTargetTrendMap(trendMap, nil)
	for key, vMap := range newTrendMap {
		for vKey, trendInfo := range vMap {
			sort.Slice(trendInfo, func(i, j int) bool {
				return trendInfo[i].X < trendInfo[j].X
			})
			trendList = append(trendList, &great_value_buy.GetGreatValueBuyMultiDimTrendInfo{
				TargetList: trendInfo,
				TargetName: vKey,
				EnumValue:  key,
			})
		}
	}
	return trendList, nil
}

func PackerProductDetail(pageNum, pageSize int32, overviewInfo map[string]int64, productInfoList []*ProductInfo, bizType dimensions.BizType) (resp *great_value_buy.GetGreatValueBuyQueryProdAnalysisData, err error) {
	var productCnt int64
	// 校验是否有商家数和商品数
	if _, ok := overviewInfo["product_cnt"]; ok {
		productCnt = overviewInfo["product_cnt"]
	}

	resp = &great_value_buy.GetGreatValueBuyQueryProdAnalysisData{
		Prods: make([]*great_value_buy.GetGreatValueBuyQueryProdsAnalysisTarget, 0),
		PageInfo: &base.PageResp{
			PageNum:  pageNum,
			PageSize: pageSize,
			Total:    productCnt,
		},
	}

	for _, info := range productInfoList {
		// 对target_list进行排序
		if len(info.TargetList) > 0 {
			sort.Slice(info.TargetList, func(i, j int) bool {
				return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
			})
		}
		productInfo := &great_value_buy.GetGreatValueBuyQueryProdsAnalysisTarget{
			ProductInfo: &basic_info.ProductBasicInfo{Id: info.ProdId, Name: info.ProdName, Images: info.ProdImages},
			QueryName:   info.SearchWord,
			TargetList:  info.TargetList,
		}
		resp.Prods = append(resp.Prods, productInfo)
	}
	return
}

func PackerQueryDetail(pageNum, pageSize int32, overviewInfo map[string]int64, productInfoList []*great_value_buy.GetGreatValueBuyQueryAnalysisTarget, bizType dimensions.BizType) (resp *great_value_buy.GetGreatValueBuyQueryAnalysisData, err error) {
	var productCnt int64
	// 校验是否有商家数和商品数
	if _, ok := overviewInfo["query_cnt"]; ok {
		productCnt = overviewInfo["query_cnt"]
	}

	resp = &great_value_buy.GetGreatValueBuyQueryAnalysisData{
		Query: make([]*great_value_buy.GetGreatValueBuyQueryAnalysisTarget, 0),
		PageInfo: &base.PageResp{
			PageNum:  pageNum,
			PageSize: pageSize,
			Total:    productCnt,
		},
	}

	for _, info := range productInfoList {
		// 对target_list进行排序
		if len(info.TargetList) > 0 {
			sort.Slice(info.TargetList, func(i, j int) bool {
				return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
			})
		}
		productInfo := &great_value_buy.GetGreatValueBuyQueryAnalysisTarget{
			QueryName:  info.QueryName,
			TargetList: info.TargetList,
		}

		resp.Query = append(resp.Query, productInfo)
	}
	return
}

func AddProductImage(ctx context.Context, productTable *onetable.Table) (*onetable.Table, error) {
	productIdList := make([]int64, 0)
	for _, m := range productTable.ToRawMap() {
		if id, ok := m["prod_id"]; ok {
			productIdList = append(productIdList, cast.ToInt64(id.(decimal.Decimal).IntPart()))
		}
	}
	productId2ImageList := make([]map[string]interface{}, 0)
	if len(productIdList) == 0 {
		return onetable.NewTable(productId2ImageList), nil
	}
	productInfoList, err := biz_utils.GetProductInfoByIdList(ctx, productIdList)
	if err != nil || len(productInfoList) == 0 {
		if err != nil {
			logs.CtxWarn(ctx, "获取商品信息失败,err:"+err.Error())
		}
		if len(productInfoList) == 0 {
			logs.CtxWarn(ctx, "商品主图获取失败，返回的数据列表长度为0")
		}
		for _, id := range productIdList {
			t := map[string]interface{}{
				"prod_id":    id,
				"name":       "",
				"images":     []string{},
				"main_image": "",
			}
			productId2ImageList = append(productId2ImageList, t)
		}
		return onetable.NewTable(productId2ImageList), nil
	}
	for _, info := range productInfoList {
		if info != nil {
			convertId, _ := strconv.ParseInt(info.Id, 10, 64)
			t := map[string]interface{}{
				"prod_id":    convertId,
				"name":       info.Name,
				"images":     info.Images,
				"main_image": info.MainImage,
			}
			productId2ImageList = append(productId2ImageList, t)
		}
	}

	return onetable.NewTable(productId2ImageList), nil
}

// 搜索词
func (d *GreatValueBuyService) getSearchWordList(ctx context.Context, commonReq *great_value_buy.GetGreatValueBuyCommonRequest, appendParams analysis_service.AppendParams) ([]*dimensions.EnumElement, int64, error) {
	params := make(map[string]interface{})
	dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, commonReq.BaseReq.BizType)
	if err != nil {
		return nil, 0, err
	}
	// 维度过滤（与底表支持的维度相关）
	req, err := d.adapterSearchAllChannelReq(ctx, appendParams.OSApiPath, commonReq)
	if err != nil {
		logs.CtxError(ctx, "适配请求失败，err:"+err.Error())
		return nil, 0, err
	}

	exprDimCql := sql_parse.NewCQL()
	if len(req.BaseReq.Dimensions) > 0 {
		exprDimCql, err = base_struct_condition.GetDimCondition(ctx, req.BaseReq.Dimensions, dimMap, nil)
		if err != nil {
			return nil, 0, err
		}
	}
	if exprDimCql != nil && exprDimCql.WhereClause != nil {
		whereStr := exprDimCql.ParseAllWhereExpression()
		if len(whereStr) > 0 {
			params["filter_param"] = whereStr
		}
	}
	exprSearchWordCql := sql_parse.NewCQL()
	if len(req.CommonSelectList) > 0 && len(req.CommonSelectList[0]) > 0 {
		exprSearchWordCql.AddWhereSearchValue(req.CommonSelectList[0], "search_word")
	}
	if exprSearchWordCql != nil && exprSearchWordCql.WhereClause != nil {
		whereStr := exprSearchWordCql.ParseAllWhereExpression()
		if len(whereStr) > 0 {
			params["search_word_filter"] = whereStr
		}
	}

	// 分页
	if req.PageReq != nil {
		params["limit"] = req.PageReq.PageSize
		params["offset"] = req.PageReq.PageSize * (req.PageReq.PageNum - 1)
	}
	params["start_date"] = req.BaseReq.StartDate
	params["end_date"] = req.BaseReq.EndDate

	apiPath := appendParams.OSApiPath
	overallApiPath, ok := appendParams.OSParams["overall_api"].(string)
	if !ok {
		logs.CtxError(ctx, "overall_api配置错误")
		return nil, 0, errors.New("overall_api配置错误")
	}
	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	fl.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("enum_list")).SetParallel(true).SetMaxParallelNum(5)
	fl.ExeQueryInvokerRaw(params, overallApiPath, param.SinkTable("total_cnt"))
	var ret []*dimensions.EnumElement
	var total map[string]int64
	fl.ExeView(param.SourceTable("enum_list"), &ret)
	fl.ExeView(param.SourceTable("total_cnt"), &total)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GenerateCateEnum]引擎调用失败，err=%v+", err)
		return ret, 0, err
	}

	if len(ret) == 1 && len(ret[0].Code) == 0 {
		return nil, 0, errors.New("获取枚举code错误")
	}
	var queryWordCnt int64
	// 校验是否有商家数和商品数
	for _, cnt := range total {
		queryWordCnt = cnt
		break
	}

	return ret, queryWordCnt, nil
}

func updateCurrOrderBy(req *great_value_buy.GetGreatValueBuyCommonRequest) (string, error) {
	// 分页和排序逻辑
	if req.OrderBy != nil {
		var orderByField, orderType string
		if req.OrderBy.IsDesc {
			orderType = "desc"
		} else {
			orderType = "asc"
		}
		if req.OrderBy.ColumnName != nil {
			orderByField = *req.OrderBy.ColumnName
		} else if req.OrderBy.Field != nil {
			switch *req.OrderBy.Field {
			case base.OrderByField_ShowPv:
				if req.BaseReq.BizType == dimensions.BizType_AttributionCoreGuess {
					orderByField = "guess_show_pv"
				} else {
					orderByField = "show_pv"
				}
			case base.OrderByField_PayOrderNum:
				orderByField = "pay_ord_cnt"
			case base.OrderByField_BrandLevel:
				orderByField = "complex_brand_s_level"
			default:
				orderByField = consts.Empty
			}
		} else {
			return "", errors.New("order by字段传参有问题，请检查")
		}

		return fmt.Sprintf("%v %v", orderByField, orderType), nil
	}
	return " ", nil
}
