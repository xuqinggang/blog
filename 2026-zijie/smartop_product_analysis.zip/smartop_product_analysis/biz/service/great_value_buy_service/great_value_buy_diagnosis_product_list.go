package great_value_buy_service

import (
	"context"
	"fmt"
	"strings"

	"code.byted.org/ecom/common/utils/async2"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
)

var keyGroupColsSku = []string{"sku_id", "sku_name", "quality_score", "out_compare_price_tag", "in_compare_price_tag", "sku_cluster_id", "sku_cluster_name", "cluster_quality_score", "prod_id", "prod_name"}
var keyGroupColsSkuName = map[string]string{
	"sku_id":                "SKU ID",
	"sku_name":              "SKU名称",
	"quality_score":         "质量分",
	"out_compare_price_tag": "站外价格标签",
	"in_compare_price_tag":  "站内价格标签",
	"sku_cluster_id":        "SKU簇ID",
	"sku_cluster_name":      "SKU簇名称",
	"cluster_quality_score": "SKU簇质量分",
	"prod_id":               "商品ID",
	"prod_name":             "商品名称"}

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisProductList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductData, err error) {
	resp = &great_value_buy.GetGreatValueBuyDiagnosisProductData{}
	appendParams := analysis_service.AppendParams{
		OSParams:  make(map[string]interface{}, 0),
		OSApiPath: "7483500020516308005",
	}
	fullList, pageInfo, err := d.getGreatValueBuyProducts(ctx, req, appendParams)

	resp.FullList = fullList
	resp.PageInfo = pageInfo
	return resp, err
}

func (d *GreatValueBuyService) getGreatValueBuyProducts(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, appendParams analysis_service.AppendParams) (
	fullList []*great_value_buy.GreatValueBuyDiagnosisProductData, pageInfo *base.PageResp, err error) {
	fullList = make([]*great_value_buy.GreatValueBuyDiagnosisProductData, 0)
	pageInfo = &base.PageResp{}

	// 1. 补全信息
	//获取业务线元信息
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	if req.OrderBy == nil || req.OrderBy.ColumnName == nil {
		// 默认按照GMV排序
		req.OrderBy = &base.OrderByInfo{
			IsDesc:     true,
			ColumnName: convert.ToStringPtr("big_link_gmv"),
		}
	}

	orderBy := &base.OrderByInfo{}

	if req.OrderBy != nil {
		orderBy.Field = req.OrderBy.Field
		orderBy.IsDesc = req.OrderBy.IsDesc
		if req.OrderBy.ColumnName != nil {
			// !important 指标名里面有#所以需要使用``进行包裹
			formattedColName := fmt.Sprintf("`%s`", *req.OrderBy.ColumnName)
			orderBy.ColumnName = &formattedColName
		}
	}

	if req.PageReq == nil || req.PageReq.PageSize == 0 || req.PageReq.PageNum == 0 {
		req.PageReq = &base.PageInfo{
			PageSize: 10,
			PageNum:  1,
		}
	}
	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    orderBy,
		PageInfo:   req.PageReq,
	})
	if err != nil {
		return nil, nil, err
	}

	if len(appendParams.OSParams) > 0 {
		for k, v := range appendParams.OSParams {
			curr[k] = v
		}
	}

	err = updateSearchParams(ctx, curr, nil)
	if err != nil {
		return
	}

	targetMetaList, _ := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
	targetNameMetaMap := make(map[string]*dimensions.TargetMetaInfo, 0)
	targetMetaListStr := make([]string, 0)
	for _, targetMeta := range targetMetaList {
		targetNameMetaMap[targetMeta.Name] = targetMeta
		targetMetaListStr = append(targetMetaListStr, targetMeta.Name)
	}
	apiPath := appendParams.OSApiPath

	// 2. 获取数据
	var skuCnt int64
	var skuCntTargetList, currTargetList []*base_struct_condition.KeyColsTargetEntity
	var getSkuCntErr, getTargetListErr error
	as2 := async2.New(ctx)
	as2.Add(func() {
		skuCntTargetList, getSkuCntErr = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, ApiPath: "7484240043767268379", BizType: req.BaseReq.BizType, KeyCols: []string{"cnt"}, FilterTargetNames: targetMetaListStr,
		})
		if getSkuCntErr != nil || len(skuCntTargetList) == 0 || len(skuCntTargetList[0].KeyColValues) == 0 {
			logs.CtxError(ctx, "skuCntTargetList err=%v", getSkuCntErr)
			return
		}
		skuCnt = convert.ToInt64(skuCntTargetList[0].KeyColValues[0])
	})
	as2.Add(func() {
		currTargetList, getTargetListErr = getTargetListWithCompareResult(ctx, req.BaseReq.BizType, curr, apiPath, targetMetaListStr, keyGroupColsSku)
	})
	as2.RunWithRecover()
	if getSkuCntErr != nil {
		return fullList, pageInfo, getSkuCntErr
	}
	if getTargetListErr != nil {
		return fullList, pageInfo, getTargetListErr
	}

	if len(currTargetList) >= 10000 {
		logs.CtxWarn(ctx, "[getGreatValueBuyProducts]获取的多维组合数量=%v+，超过1w", len(currTargetList))
		currTargetList = currTargetList[:10000]
	}

	// 3. 打包数据结果
	for _, keyTargetList := range currTargetList {
		row := &great_value_buy.GreatValueBuyDiagnosisProductData{
			TargetList: append(keyTargetList.TargetEntity),
			SkuClusterInfo: &basic_info.SkuClusterInfo{
				SkuId:                  convert.ToString(keyTargetList.KeyColValues[0]),
				SkuName:                convert.ToString(keyTargetList.KeyColValues[1]),
				SkuQualityScore:        convert.ToFloat64(keyTargetList.KeyColValues[2]),
				SkuOutComparePriceTag:  convert.ToString(keyTargetList.KeyColValues[3]),
				SkuInComparePriceTag:   convert.ToString(keyTargetList.KeyColValues[4]),
				SkuClusterId:           convert.ToString(keyTargetList.KeyColValues[5]),
				SkuClusterName:         convert.ToString(keyTargetList.KeyColValues[6]),
				SkuClusterQualityScore: convert.ToFloat64(keyTargetList.KeyColValues[7]),
			},
			ProductInfo: &basic_info.ProductBasicInfo{
				Id:   convert.ToString(keyTargetList.KeyColValues[8]),
				Name: convert.ToString(keyTargetList.KeyColValues[9]),
			},
		}
		analysis_service.SortTargetCardEntity(row.TargetList)
		sortWithGroup(row.TargetList)
		fullList = append(fullList, row)
	}

	// 商品图片信息
	prodIDs := make([]int64, 0)
	for _, info := range fullList {
		prodIDs = append(prodIDs, convert.ToInt64(info.ProductInfo.Id))
	}
	imageProdList, err := biz_utils.GetProductInfoByIdList(ctx, prodIDs)
	if err == nil && len(imageProdList) > 0 {
		prodId2ImageMap := make(map[string][]string)
		for _, i := range imageProdList {
			prodId2ImageMap[i.Id] = i.Images
		}
		for _, info := range fullList {
			info.ProductInfo.Images = prodId2ImageMap[info.ProductInfo.Id]
		}
	}
	pageInfo = &base.PageResp{
		PageNum:  req.PageReq.PageNum,
		PageSize: req.PageReq.PageSize,
		Total:    skuCnt,
	}
	if req.BaseReq.BizType == dimensions.BizType_GreatValueBuyBigLink {
		for _, list := range fullList {
			TargetUnitOptimize(list.TargetList)
		}
	}
	return fullList, pageInfo, nil
}

func getTargetListWithCompareResult(ctx context.Context, bizType dimensions.BizType, curr map[string]interface{}, apiPath string, targetMetaList []string, keyGroupCols []string) ([]*base_struct_condition.KeyColsTargetEntity, error) {
	currTargetRecords, err := base_struct_condition.GetRecordsByOS(ctx, curr, consts.Empty, apiPath)
	if err != nil {
		return nil, err
	}
	targetMetaMap, err := base_struct_condition.GetFilterTargetMetaInfoMap(ctx, int64(bizType), false, true, targetMetaList)
	if err != nil {
		return nil, err
	}
	for key, value := range targetMetaMap {
		targetMetaMap[key+"_compare"] = value
	}

	currKeyTargetList := make([]*base_struct_condition.KeyColsTargetEntity, 0)
	compareKeyTargetList := make([]*base_struct_condition.KeyColsTargetEntity, 0)
	for _, record := range currTargetRecords {
		targets := make([]*analysis.TargetCardEntity, 0)
		compareTargets := make([]*analysis.TargetCardEntity, 0)
		for key, value := range record {

			group := ""
			isGroup := strings.Contains(key, "#")
			if isGroup {
				values := strings.Split(key, "#")
				key = values[0]
				group = values[1]
			}
			if !slices.ContainsString(keyGroupCols, key) {
				targetMetaInfo := targetMetaMap[key]
				if targetMetaInfo == nil {
					continue
				}
				newTarget, err := base_struct_condition.GetTargetEntity(ctx, value, targetMetaMap[key])
				if err != nil {
					return nil, err
				}
				if isGroup && newTarget != nil {
					newTarget.Extra.AttributeType = fmt.Sprintf(`分渠道-%s`, newTarget.DisplayName)
					newTarget.Extra.IsDefaultShow = false
					newTarget.Name = fmt.Sprintf(`%s#%s`, newTarget.Name, group)
					newTarget.DisplayName = group
				}
				if strings.Contains(key, "_compare") {
					compareTargets = append(compareTargets, newTarget)
				} else {
					targets = append(targets, newTarget)
				}

			}
		}

		keyColValues := make([]interface{}, 0)
		for _, keyCol := range keyGroupCols {
			keyColValues = append(keyColValues, record[keyCol])
		}

		currKeyTargetList = append(currKeyTargetList, &base_struct_condition.KeyColsTargetEntity{
			KeyColValues: keyColValues,
			TargetEntity: targets,
		})
		compareKeyTargetList = append(compareKeyTargetList, &base_struct_condition.KeyColsTargetEntity{
			KeyColValues: keyColValues,
			TargetEntity: compareTargets,
		})
	}
	currTargetList := base_struct_condition.GetTargetCycleRatioListWithKeyColumnByType(currKeyTargetList, compareKeyTargetList, base_struct_condition.CompareTypeCycle)
	return currTargetList, nil
}
