package great_value_buy_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/pkg/errors"
	"context"
)

func (d *GreatValueBuyService) getGuessCoreTreeItemsV2(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (
	total *great_value_buy.GetGreatValueBuyAttributionCoreTreeData, coreTreeItems []*great_value_buy.GetGreatValueBuyAttributionCoreTreeData, err error) {

	resp, err := d.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
		BaseReq:  req.BaseReq,
		NeedIncr: true,
	}, analysis_service.AppendParams{IsBuildTargetV2: true})

	if err != nil {
		return nil, nil, err
	}
	if resp == nil {
		return nil, nil, errors.New("多维分析接口返回nil")
	}

	// 补充贡献度数据
	fillDistributionInfo(resp.Total, resp.FullList)

	// 数据构造
	if resp.Total != nil {
		total = toCoreTreeData([]*analysis.MultiDimFullListRow{resp.Total})[0]
	}
	if len(resp.FullList) > 0 {
		coreTreeItems = toCoreTreeData(resp.FullList)
	}
	return total, coreTreeItems, nil
}

func fillDistributionInfo(total *analysis.MultiDimFullListRow, rows []*analysis.MultiDimFullListRow) {
	if total == nil || len(rows) == 0 {
		return
	}
	// 累计值
	curIndexMap := make(map[string]float64)
	compareIndexMap := make(map[string]float64)
	for _, v := range total.TargetList {
		if v == nil {
			continue
		}
		curIndexMap[v.Name] = v.Value
		if v.ComparePeriodData != nil {
			compareIndexMap[v.Name] = v.ComparePeriodData.CompareValue
		}
	}
	// 贡献度
	for _, row := range rows {
		if row == nil {
			continue
		}
		for _, v := range row.TargetList {
			if v == nil {
				continue
			}
			// 分析周期贡献度
			if v.Extra == nil {
				v.Extra = &analysis.TargetCardExtraInfo{}
			}
			if curIndexMap[v.Name] != 0 {
				v.Extra.DistributionValue = v.Value / curIndexMap[v.Name]
			}

			// 对比周期贡献度
			if v.ComparePeriodData == nil {
				v.ComparePeriodData = &analysis.ComparePeriodData{}
			}
			if compareIndexMap[v.Name] != 0 {
				v.ComparePeriodData.DistributionValue = v.ComparePeriodData.CompareValue / compareIndexMap[v.Name]
			}

			// 贡献度aa值
			if v.ComparePeriodData.DistributionValue != 0 {
				v.ComparePeriodData.DistributionValueRatio = v.Extra.DistributionValue/v.ComparePeriodData.DistributionValue - 1
			}
		}
	}
}

func toCoreTreeData(rows []*analysis.MultiDimFullListRow) []*great_value_buy.GetGreatValueBuyAttributionCoreTreeData {
	resp := make([]*great_value_buy.GetGreatValueBuyAttributionCoreTreeData, 0)
	for _, v := range rows {
		if v == nil {
			continue
		}
		resp = append(resp, &great_value_buy.GetGreatValueBuyAttributionCoreTreeData{
			Name:        v.DisplayName,
			TargetList:  v.TargetList,
			ProdTagCode: v.ProdTagCode,
			DimKey:      v.DimKey,
			Children:    toCoreTreeData(v.Children),
			Code:        v.EnumValue,
		})
	}
	return resp
}
