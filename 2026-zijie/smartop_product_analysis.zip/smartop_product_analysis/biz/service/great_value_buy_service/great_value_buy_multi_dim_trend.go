package great_value_buy_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"context"
)

func (d *GreatValueBuyService) GetGreatValueBuyMultiDimTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyMultiDimTrendData, err error) {
	resp = great_value_buy.NewGetGreatValueBuyMultiDimTrendData()
	newTargetList := make([]string, 0)
	for _, targetName := range req.BaseReq.TargetMetaList {
		if len(req.TargetGranularityList) > 0 {
			granularityType := req.TargetGranularityList[0]
			if nameList, ok := TargetGranularityTypeMap[granularityType]; ok {
				if utils.IsInStringSlice(targetName, nameList) {
					newTargetList = append(newTargetList, targetName)
				}
			}
		}
	}
	if len(newTargetList) > 0 {
		req.BaseReq.TargetMetaList = newTargetList
	}
	allTotal, err := d.AnalysisService.GetProductAnalysisMultiDimTrend(ctx, &analysis.GetProductAnalysisBaseRequest{
		BaseReq:   req.BaseReq,
		NeedTrend: true,
		IsTotal:   true,
	})
	if err != nil {
		return resp, err
	}
	res, err := d.AnalysisService.GetProductAnalysisMultiDimTrend(ctx, &analysis.GetProductAnalysisBaseRequest{
		BaseReq:   req.BaseReq,
		NeedTrend: true,
		IsTotal:   false,
	})
	if err != nil {
		return resp, err
	}
	productTrendRes := productTrendToGreatValueBuyTrend(res)
	if len(allTotal) > 0 {
		totals := make([]*great_value_buy.GetGreatValueBuyMultiDimTrendInfo, 0)
		for _, item := range allTotal {
			trendPoint := &great_value_buy.GetGreatValueBuyMultiDimTrendInfo{
				TargetList: item.TargetList,
				EnumValue:  "全量不被匹配的整体",
				TargetName: item.TargetName,
			}
			totals = append(totals, trendPoint)
		}
		resp.TrendList = append(totals, productTrendRes...)
	} else {
		resp.TrendList = productTrendRes
	}
	if req.BaseReq.BizType == dimensions.BizType_GreatValueBuyBigLink {
		for _, trendPoint := range resp.TrendList {
			TrendTargetUnitOptimize(trendPoint.TargetList)
		}
	}
	return resp, nil
}

func productTrendToGreatValueBuyTrend(trendList []*analysis.GetProductAnalysisMultiDimTrendInfo) []*great_value_buy.GetGreatValueBuyMultiDimTrendInfo {
	res := make([]*great_value_buy.GetGreatValueBuyMultiDimTrendInfo, 0)
	for _, trend := range trendList {
		res = append(res, &great_value_buy.GetGreatValueBuyMultiDimTrendInfo{
			TargetList: trend.TargetList,
			EnumValue:  trend.EnumValue,
			TargetName: trend.TargetName,
		})
	}
	return res
}
