package great_value_buy_service

import (
	"context"
	"fmt"
	"sort"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/temai/go_lib/convert"
)

type FirstLocationOptions struct {
	dims             []string
	startDate        string
	endDate          string
	compareStartDate string
	compareEndDate   string
	whiteList        *[]string
}

var queryVariables = []string{
	"big_link_show_pv",
	"big_link_gmv",
	"big_link_order_cnt",
	"big_link_show_pv_compare",
	"big_link_gmv_compare",
	"big_link_order_cnt_compare",
}
var outQueryMap = map[string]string{
	"big_link_opm":         "if(`big_link_show_pv#%s`=0,0,round(`big_link_order_cnt#%s`/`big_link_show_pv#%s`*1000,5)) as `big_link_opm#%s`",
	"big_link_gpm":         "if(`big_link_show_pv#%s`=0,0,round(`big_link_gmv#%s`/`big_link_show_pv#%s`*1000,5)) as `big_link_gpm#%s`",
	"big_link_opm_compare": "if(`big_link_show_pv_compare#%s`=0,0,round(`big_link_order_cnt_compare#%s`/`big_link_show_pv_compare#%s`*1000,5)) as `big_link_opm_compare#%s`",
	"big_link_gpm_compare": "if(`big_link_show_pv_compare#%s`=0,0,round(`big_link_gmv_compare#%s`/`big_link_show_pv_compare#%s`*1000,5)) as `big_link_gpm_compare#%s`",
}

func generateFirstLocationDimQueryStrings(options FirstLocationOptions) (string, string) {
	dims, startDate, endDate, compareStartDate, compareEndDate, whiteList :=
		options.dims, options.startDate, options.endDate, options.compareStartDate, options.compareEndDate, options.whiteList

	var innerQuery []string
	var outQuery []string

	// 内层查询获取所有的必要指标值
	for _, dim := range dims {
		innerQueryArr := []string{
			fmt.Sprintf("sum(if(date between '%s' and '%s' and first_location = '%s',sku_show_pv,0)) AS `big_link_show_pv#%s`", startDate, endDate, dim, dim),
			fmt.Sprintf("sum(if(date between '%s' and '%s' and first_location = '%s',sku_gmv,0)) AS `big_link_gmv#%s`", startDate, endDate, dim, dim),
			fmt.Sprintf("sum(if(date between '%s' and '%s' and first_location = '%s',sku_order_cnt,0)) AS `big_link_order_cnt#%s`", startDate, endDate, dim, dim),
			fmt.Sprintf("sum(if(date between '%s' and '%s' and first_location = '%s',sku_show_pv,0)) AS `big_link_show_pv_compare#%s`", compareStartDate, compareEndDate, dim, dim),
			fmt.Sprintf("sum(if(date between '%s' and '%s' and first_location = '%s',sku_gmv,0)) AS `big_link_gmv_compare#%s`", compareStartDate, compareEndDate, dim, dim),
			fmt.Sprintf("sum(if(date between '%s' and '%s' and first_location = '%s',sku_order_cnt,0)) AS `big_link_order_cnt_compare#%s`", compareStartDate, compareEndDate, dim, dim),
		}
		innerQueryArrStr := strings.Join(innerQueryArr, ",")

		// 查询外层指标的时候，根据白名单情况决定是否对指标进行过滤
		outQueryArr := []string{}

		for _, key := range queryVariables {
			originKey := fmt.Sprintf("%s#%s", key, dim)
			if whiteList != nil && !slices.ContainsString(*whiteList, originKey) {
				continue
			}
			// !important 注意这里在拼接指标名称的时候增加了``
			outQueryArr = append(outQueryArr, fmt.Sprintf("`%s`", originKey))
		}

		for key, template := range outQueryMap {
			originKey := fmt.Sprintf("%s#%s", key, dim)
			if whiteList != nil && !slices.ContainsString(*whiteList, originKey) {
				continue
			}
			outQueryArr = append(outQueryArr,
				fmt.Sprintf(template, dim, dim, dim, dim))
		}

		outQueryValueArrStr := strings.Join(outQueryArr, ",")

		if innerQueryArrStr != "" {
			innerQuery = append(innerQuery, innerQueryArrStr)
		}
		if outQueryValueArrStr != "" {
			outQuery = append(outQuery, outQueryValueArrStr)
		}
	}

	innerQueryStr := strings.Join(innerQuery, ",")
	outQueryStr := strings.Join(outQuery, ",")

	return innerQueryStr, outQueryStr
}

// updateSearchParams 使用一级类目参数，增加查询参数
func updateSearchParams(ctx context.Context, curr map[string]interface{}, whiteList *[]string) (err error) {
	innerSelect := ""
	outSelect := ""
	// 获取一级类目列表
	_, dataList, err := base_struct_condition.GetDataListByOS(ctx, curr, consts.Empty, BigLinkFirstLocationsApi)

	if err != nil {
		return
	}

	list := []string{}
	for _, row := range dataList {
		if len(row) > 0 {
			str, ok2 := row[0].(string)
			if ok2 {
				list = append(list, str)
			}
		}
	}

	if len(list) > 0 {

		startDate, ok0 := curr["start_date"].(string)
		endDate, ok1 := curr["end_date"].(string)
		compareStartDate, ok2 := curr["compare_start_date"].(string)
		compareEndDate, ok3 := curr["compare_end_date"].(string)
		if ok0 && ok1 && ok2 && ok3 {
			innerSelect, outSelect = generateFirstLocationDimQueryStrings(

				FirstLocationOptions{
					list,
					startDate,
					endDate,
					compareStartDate,
					compareEndDate,
					whiteList,
				},
			)
			if innerSelect != "" && outSelect != "" {
				curr["inner_select"] = innerSelect
				curr["out_select"] = outSelect
			}
		}

	}
	return
}

func sortWithGroup(resp []*analysis.TargetCardEntity) {
	sort.SliceStable(resp, func(i, j int) bool {
		iName := convert.ToString(resp[i].Name)
		jName := convert.ToString(resp[j].Name)

		iisGroup := strings.Contains(iName, "#")
		jisGroup := strings.Contains(jName, "#")

		if !iisGroup && jisGroup {
			return true
		}
		if iisGroup && jisGroup {
			return iName < jName
		}

		return false
	})
}
