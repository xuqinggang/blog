package great_value_buy_service

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"strings"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
)

func (d *GreatValueBuyService) GetGreatValueBuyDiagnosisProductListTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductListTrendData, err error) {
	resp = &great_value_buy.GetGreatValueBuyDiagnosisProductListTrendData{}
	appendParams := analysis_service.AppendParams{
		OSParams:  make(map[string]interface{}, 0),
		OSApiPath: "7484205757148202010",
	}
	appendParams.IsAllTotal = false
	fullList, err := d.getGreatValueBuyProductsTrend(ctx, req, appendParams)
	resp.TrendList = fullList
	if req.BaseReq.BizType == dimensions.BizType_GreatValueBuyBigLink {
		for _, trendPoint := range resp.TrendList {
			TrendTargetUnitOptimize(trendPoint.TargetList)
		}
	}
	return resp, err
}

func (d *GreatValueBuyService) getGreatValueBuyProductsTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, appendParams analysis_service.AppendParams) (
	[]*great_value_buy.GetGreatValueBuyMultiDimTrendInfo, error) {
	// 补全参数
	if req.OrderBy == nil || req.OrderBy.ColumnName == nil {
		// 默认按照GMV排序
		req.OrderBy = &base.OrderByInfo{
			IsDesc:     true,
			ColumnName: convert.ToStringPtr("big_link_gmv"),
		}
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	curr, compare, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
	})
	if err != nil {
		return nil, err
	}
	if len(req.SelectSkuIdList) == 0 {
		return nil, errors.New("请选择趋势分析sku单品")
	}
	curr["sku_id"] = req.SelectSkuIdList
	if len(appendParams.OSParams) > 0 {
		for k, v := range appendParams.OSParams {
			curr[k] = v
			compare[k] = v
		}
	}
	apiPath := appendParams.OSApiPath
	// 2. 数据查询

	cc := co.NewConcurrent(ctx)
	trendMap := make(map[string]map[string][]*analysis.TargetTrendPoint)
	trendMap2 := make(map[string]map[string][]*analysis.TargetTrendPoint)
	// 2. 数据查询
	cc.GoV2(func() error {
		trendMap, err = base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, KeyCols: keyGroupColsSku, TrendCol: "date",
		})
		if err != nil {
			return err
		}
		return nil
	})

	// 使用另外的接口并发获取额外维度的趋势数据
	cc.GoV2(func() error {
		keyGroupCols := append(keyGroupColsSku, "first_location")
		trendMap2, err = base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, Sql: consts.Empty, ApiPath: BigLinkFirstLocationTrendApi, BizType: req.BaseReq.BizType, KeyCols: keyGroupCols, TrendCol: "date",
		})
		if err != nil {
			return err
		}
		return nil
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[getGreatValueBuyProductsTrend]并发对象wait失败, err:"+err.Error())
		return nil, err
	}

	// 3. 数据处理
	trendList := make([]*great_value_buy.GetGreatValueBuyMultiDimTrendInfo, 0)
	mergeTrendMap := make(map[string]map[string][]*analysis.TargetTrendPoint)
	for key, vMap := range trendMap {
		keyList := strings.Split(key, "###")
		if len(keyList) < len(keyGroupColsSku) {
			continue
		}
		enumValue := keyList[0] + "," + keyList[5]
		if mergeTrendMap[enumValue] == nil {
			mergeTrendMap[enumValue] = vMap
			continue
		}
		curMap := mergeTrendMap[enumValue]
		for k, v := range vMap {
			if curMap[k] == nil {
				curMap[k] = make([]*analysis.TargetTrendPoint, 0)
			}
			curMap[k] = append(curMap[k], v...)
		}
		mergeTrendMap[enumValue] = curMap
	}

	// 合并两个接口中查询到的数据
	for key, originMap := range trendMap2 {
		keyList := strings.Split(key, "###")
		if len(keyList) < len(keyGroupColsSku) {
			continue
		}
		enumValue := keyList[0] + "," + keyList[5]
		if len(keyList) > 10 {
			firstLocation := keyList[10]
			vMap := map[string][]*analysis.TargetTrendPoint{}
			for k, v := range originMap {
				newKey := fmt.Sprintf(`%s#%s`, k, firstLocation)
				vMap[newKey] = v
			}
			if mergeTrendMap[enumValue] == nil {
				mergeTrendMap[enumValue] = vMap
				continue
			}
			curMap := mergeTrendMap[enumValue]
			for k, v := range vMap {
				if curMap[k] == nil {
					curMap[k] = make([]*analysis.TargetTrendPoint, 0)
				}
				curMap[k] = append(curMap[k], v...)
			}
			mergeTrendMap[enumValue] = curMap
		}
	}

	for key, vMap := range mergeTrendMap {
		for vKey, trendInfo := range vMap {
			sort.Slice(trendInfo, func(i, j int) bool {
				return trendInfo[i].X < trendInfo[j].X
			})
			trendList = append(trendList, &great_value_buy.GetGreatValueBuyMultiDimTrendInfo{
				TargetList: trendInfo,
				TargetName: vKey,
				EnumValue:  key,
			})
		}
	}
	return trendList, nil
}
