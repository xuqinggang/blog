package great_value_buy_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
)

func (s *GreatValueBuyService) getBigActivityCommonCoreOverView(ctx context.Context, apiPath string, req *great_value_buy.GetGreatValueBuyCommonRequest) (resTargetList []*analysis.TargetCardEntity, err error) {
	resTargetList = make([]*analysis.TargetCardEntity, 0)
	// isShowCompare := false
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	bizInfo.TargetCardApiID = apiPath
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	ctx = context.WithValue(ctx, consts.CtxAllDatePoolFlag, "超值购搜索核心指标")
	curr, compare, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(
		ctx, base_struct_condition.OsParamsReq{
			BaseStruct: req.BaseReq,
			DimMap:     dimMap,
			DimColMap:  dimColMap,
		},
	)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	ps, _ := genFlowGroupParams(ctx, req, dimMap, dimColMap)
	for key, value := range ps {
		curr[key] = value
		compare[key] = value
	}
	// 最后生成
	groupParam, _ := genGroupFilterParams(ctx, req, dimMap, dimColMap)
	for key, value := range groupParam {
		curr[key] = value
		compare[key] = value
	}
	var currTargetList, compareTargetList []*base_struct_condition.KeyColsTargetEntity
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		currTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细", "可优化项详情"},
			FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return err
		}
		return nil
	})
	isNeedBurstRate := false // 是否需要计算爆发系数
	if slices.ContainsString(needBurstRateApiList, apiPath) {
		curr["compare_start_date"] = req.BaseReq.CompareStartDate
		curr["compare_end_date"] = req.BaseReq.CompareEndDate
	} else { // 不需要对比周期
		compare["is_compare_data"] = 1
		compare["observe_start_date"] = req.BaseReq.StartDate
		compare["observe_end_date"] = req.BaseReq.EndDate
		isNeedBurstRate = true
		cc.GoV2(func() error {
			compareTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: compare, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
				KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细", "可优化项详情"},
				FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
			})
			if err != nil {
				return err
			}
			return nil
		})
	}
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[getBigActivityCommonCoreOverView]并发对象wait失败, err:"+err.Error())
		return nil, err
	}
	if len(compareTargetList) > 0 {
		currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumnByType(currTargetList, compareTargetList, base_struct_condition.CompareTypeCompare)
	}
	if len(currTargetList) == 0 {
		return resTargetList, nil
	}
	if isNeedBurstRate {
		calBurstRate(currTargetList[0].TargetEntity)
	}

	resTargetList = currTargetList[0].TargetEntity
	if len(currTargetList) == 0 {
		return resTargetList, nil
	}
	resTargetList = s.calOverallRate(ctx, req, resTargetList)
	//s.generateBigActivityTips(ctx, req, resTargetList)
	return resTargetList, nil
}

func (s *GreatValueBuyService) generateBigActivityTips(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, resTargetList []*analysis.TargetCardEntity) {

	bizInfo, ctx, _ := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	bizType := req.BaseReq.BizType
	if bizInfo != nil && bizInfo.DependBizID > 0 {
		bizType = dimensions.BizType(bizInfo.DependBizID)
	}
	configReq := &great_value_buy.GetGreatValueBuyDiagnosisConfigDataRequest{
		BizType: bizType,
	}
	configRes, err := s.GetGreatValueBuyDiagnosisConfig(ctx, configReq)
	if err != nil && configRes == nil {
		logs.CtxError(ctx, "[generateBigActivityTips] GetGreatValueBuyDiagnosisConfig failed, err:%v", err)
		return
	}
	targetNameSuggestMap := make(map[string]string)
	for _, topic := range configRes.TopicList {
		for _, diagnosisTarget := range topic.TargetList {
			targetNameSuggestMap[diagnosisTarget.TargetName] = diagnosisTarget.SuggestAction.ActionName
		}
	}
	for _, target := range resTargetList {
		if actionName, ok := targetNameSuggestMap[target.Name]; ok {
			target.Tips = actionName
		}
	}
}

func calBurstRate(resTargetList []*analysis.TargetCardEntity) {
	for _, target := range resTargetList {
		if target.ComparePeriodData != nil && target.ComparePeriodData.CompareValue != 0 {
			if target.Extra == nil {
				target.Extra = &analysis.TargetCardExtraInfo{}
			}
			target.Extra.BurstRate = target.Value/target.ComparePeriodData.CompareValue - 1
		}
	}
}

func (s *GreatValueBuyService) calOverallRate(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, resTargetList []*analysis.TargetCardEntity) []*analysis.TargetCardEntity {
	overallRateTargets := make([]*analysis.TargetCardEntity, 0)
	dependentTargetMap := make(map[string]*analysis.TargetCardEntity)
	for _, target := range req.DependentTargetList {
		dependentTargetMap[target.Name] = target
	}
	targetMetaMap, _ := base_struct_condition.GetTargetMetaInfoMap(ctx, int64(req.BaseReq.BizType), false, nil...)
	for _, target := range resTargetList {
		for newTargetName, rule := range BigActDiagnosisExtraTargetsRules {
			for numerator, denominator := range rule {
				if target.Name != numerator {
					continue
				}
				denominatorTarget := dependentTargetMap[denominator]
				if denominatorTarget == nil {
					logs.CtxInfo(ctx, "计算指标%s的分母指标%s不存在", newTargetName, denominator)
					continue
				}
				if denominatorTarget.Value == 0 {
					logs.CtxInfo(ctx, "计算指标%s的分母指标%s值为0", newTargetName, denominator)
					continue
				}
				value := target.Value / denominatorTarget.Value
				newTarget, err := base_struct_condition.GetTargetEntity(ctx, value, targetMetaMap[newTargetName])
				if err != nil || newTarget == nil {
					logs.CtxWarn(ctx, "[calOverallRate] GetTargetEntity err=%v", err)
					continue
				}
				newTarget.Tips = fmt.Sprintf("分子: %s(%v),分母：%s(%v)。", target.DisplayName, target.DisplayValue, denominatorTarget.DisplayName, denominatorTarget.DisplayValue)
				overallRateTargets = append(overallRateTargets, newTarget)
			}
		}
	}
	resTargetList = append(resTargetList, overallRateTargets...)
	return resTargetList
}
