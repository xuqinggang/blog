package activity_service

import (
	"code.byted.org/aweme-go/hstruct/cast"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity"
	"code.byted.org/overpass/ecom_mall_boost/kitex_gen/ecom/mall/boost"
)

func packActivityFlowPlanList(planList []*boost.FlowPlan) []*activity.FlowPlan {
	res := make([]*activity.FlowPlan, 0, len(planList))

	for _, plan := range planList {
		if plan == nil {
			continue
		}

		var signal *activity.EquitySignal
		signalList := packActivitySignal([]*boost.EquitySignal{plan.Signal})
		if len(signalList) > 0 {
			signal = signalList[0]
		}
		res = append(res, &activity.FlowPlan{
			Id:         cast.ToString(plan.Id),
			Biz:        plan.Biz,
			BizId:      plan.BizId,
			Strategy:   plan.Strategy,
			Status:     plan.Status,
			StartAt:    plan.StartAt,
			FinishAt:   plan.FinishAt,
			SyncTopic:  plan.SyncTopic,
			Desc:       plan.Desc,
			Name:       plan.Name,
			Cooperator: plan.Cooperator,
			Creator:    plan.Creator,
			CreatedAt:  plan.CreatedAt,
			UpdatedAt:  plan.UpdatedAt,
			Updater:    plan.Updater,
			SignalId:   plan.SignalId,
			BoostValue: plan.BoostValue,
			Signal:     signal,
		})
	}

	return res
}

func packActivitySignal(signalList []*boost.EquitySignal) []*activity.EquitySignal {
	res := make([]*activity.EquitySignal, 0, len(signalList))

	for _, signal := range signalList {
		if signal == nil {
			continue
		}

		res = append(res, &activity.EquitySignal{
			Id:        cast.ToString(signal.Id),
			Name:      signal.Name,
			Libras:    packActivityLibra(signal.Libras),
			CreatedAt: signal.CreatedAt,
			UpdatedAt: signal.UpdatedAt,
			Valid:     activity.Valid(signal.Valid),
			Type:      activity.SignalType(signal.Type),
			Level:     signal.Level,
			TypeName:  signal.TypeName,
		})
	}

	return res
}

func packActivityLibra(libraList []*boost.LibraInfo) []*activity.LibraInfo {
	res := make([]*activity.LibraInfo, 0, len(libraList))

	for _, libra := range libraList {
		if libra == nil {
			continue
		}

		res = append(res, &activity.LibraInfo{
			SignalId:     libra.SignalId,
			PlanId:       libra.PlanId,
			LibraId:      libra.LibraId,
			LibraLayerId: libra.LibraLayerId,
			CreatedAt:    libra.CreatedAt,
			UpdatedAt:    libra.UpdatedAt,
		})
	}

	return res
}
