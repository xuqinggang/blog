package activity_service

import (
	"context"
	"errors"
	"strconv"
	"strings"
	"time"

	"code.byted.org/aweme-go/hstruct/cast"
	utils2 "code.byted.org/ecom/common/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/jsonx"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/overpass/ecom_mall_boost/kitex_gen/ecom/mall/boost"
	"code.byted.org/overpass/ecom_mall_boost/kitex_gen/ecom/mall/supply_common"
	"code.byted.org/overpass/ecom_mall_boost/rpc/ecom_mall_boost"
	"code.byted.org/temai/go_lib/convert"
	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"
)

type IActivityService interface {
	ICreateActivity(ctx context.Context, req *activity.CreateActivityRequest) (*activity.CreateActivityResponse, error)
	IUpdateActivity(ctx context.Context, req *activity.UpdateActivityRequest) (*activity.UpdateActivityResponse, error)
	IGetActivityList(ctx context.Context, req *activity.GetActivityListRequest) (*activity.GetActivityListData, error)
	ITakeOfflineActivity(ctx context.Context, req *activity.TakeOfflineActivityRequest) (*activity.TakeOfflineActivityResponse, error)
	ApprovalActivity(ctx context.Context, req *activity.ApprovalActivityReq) (*activity.ApprovalActivityResp, error)
	ActivityApprovalCallback(ctx context.Context, req *activity.ApprovalCallbackRequest) (*activity.ApprovalCallbackResponse, error)
}

type ActivityService struct {
	ActivityDao         dao.IActivityDao
	ActivityApprovalDao dao.IActivityApprovalDao
}

func (d *ActivityService) ICreateActivity(ctx context.Context, req *activity.CreateActivityRequest) (resp *activity.CreateActivityResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "ICreateActivity Err:%s", err.Error())
		}
	}()

	if req == nil || req.ActivityEntity == nil {
		return nil, errors.New("[CreateActivity] invalid params")
	}

	act := &dao.Activity{
		Name:           req.ActivityEntity.ActivityName,
		Target:         int64(req.ActivityEntity.ActivityTarget),
		Description:    req.ActivityEntity.ActivityDescription,
		Status:         int64(activity.ActivityStatus_Reviewing), // 新建的活动默认待审核状态
		CreatorId:      convert.ToInt64(req.GetOperatorId()),
		HelperIdList:   strings.Join(req.ActivityEntity.ActivityHelperIdList, ","),
		StartTimestamp: req.ActivityEntity.ActivityStartTimestamp,
		EndTimestamp:   req.ActivityEntity.ActivityEndTimestamp,
	}

	err = d.ActivityDao.CreateActivity(ctx, act)
	if err != nil {
		logs.CtxError(ctx, "[CreateActivity] CreateActivity err: %v", err)
		return nil, err
	}

	form := lark_service.ActivityToForm(act, act.ID)
	activityAuditUuid := lark_service.GetActivityAuditUuid(act.ID, convert.ToInt64(req.GetOperatorId()))
	instanceCode, err := lark_service.CreateActivityApprovalInstance(ctx, gptr.Indirect(utils.GetUserInfo(ctx).Email), activityAuditUuid, form)
	if err != nil {
		logs.CtxError(ctx, "[CreatePlan]CreateActivityApprovalInstance failed, err: %v", err)
		return nil, err
	}
	err = d.ActivityApprovalDao.CreateActivityApproval(ctx, &dao.ActivityApproval{
		ActivityID:   act.ID,
		InstanceCode: instanceCode,
		AuditStatus:  lark_service.EventStatusPending,
		RevertStatus: int64(activity.ActivityStatus_Offline),
		TargetStatus: int64(activity.ActivityStatus_Active),
		SubmitUser:   req.GetOperatorId(),
		SubmitTime:   time.Now(),
		AuditTime:    time.Time{},
	})
	if err != nil {
		logs.CtxError(ctx, "[CreateActivityApprovalInstance] CreateActivityApprovalInstance failed, err: %v", err)
		return nil, err
	}

	return &activity.CreateActivityResponse{}, nil
}

func (d *ActivityService) IUpdateActivity(ctx context.Context, req *activity.UpdateActivityRequest) (resp *activity.UpdateActivityResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "IUpdateActivity Err:%s", err.Error())
		}
	}()
	if req == nil || req.ActivityEntity == nil || req.GetActivityId() == "" || req.GetOperatorId() == "" {
		return nil, errors.New("[UpdateActivity] invalid params")
	}

	activityId := convert.ToInt64(req.GetActivityId())
	if activityId <= 0 {
		return nil, errors.New("[UpdateActivity] invalid params")
	}

	if !d.CanOperateActivity(ctx, req.GetOperatorId(), activityId) {
		return nil, errors.New("[UpdateActivity] operator is not creator or helper")
	}

	err = d.ActivityDao.UpdateActivity(ctx, activityId, &dao.Activity{
		Name:           req.ActivityEntity.ActivityName,
		Target:         int64(req.ActivityEntity.ActivityTarget),
		Description:    req.ActivityEntity.ActivityDescription,
		HelperIdList:   strings.Join(req.ActivityEntity.ActivityHelperIdList, ","),
		StartTimestamp: req.ActivityEntity.ActivityStartTimestamp,
		EndTimestamp:   req.ActivityEntity.ActivityEndTimestamp,
	})
	if err != nil {
		logs.CtxError(ctx, "[UpdateActivity] UpdateActivity err: %v", err)
		return nil, err
	}

	return &activity.UpdateActivityResponse{}, nil
}

func (d *ActivityService) IGetActivityList(ctx context.Context, req *activity.GetActivityListRequest) (*activity.GetActivityListData, error) {
	if req == nil {
		return nil, errors.New("[GetActivityList] invalid params")
	}

	creatorIdList := make([]int64, 0, len(req.GetActivityCreatorList()))
	for _, cid := range req.GetActivityCreatorList() {
		id := convert.ToInt64(cid)
		if id > 0 {
			creatorIdList = append(creatorIdList, id)
		}
	}

	statusList := make([]int32, 0, len(req.GetActivityStatus()))

	for _, status := range req.GetActivityStatus() {
		statusList = append(statusList, int32(status))
	}

	var ids []int64
	for _, v := range req.GetActivityIdList() {
		ids = append(ids, cast.ToInt64(v))
	}

	params := &dao.ActivityQueryParams{
		Ids:           ids,
		Name:          req.GetActivityName(),
		StatusList:    statusList,
		CreatorIdList: creatorIdList,
		HelperIdList:  strings.Join(req.GetActivityHelperList(), ","),
		Cursor:        req.GetCursor(),
		Limit:         int(req.GetLimit()),
	}
	// 查sql获取活动列表
	activityList, err := d.ActivityDao.GetActivityList(ctx, params)
	if err != nil {
		logs.CtxError(ctx, "[GetActivityList] GetActivityList err: %v", err)
		return nil, err
	}
	totalCnt, err := d.ActivityDao.GetActivityCount(ctx, params)
	if err != nil {
		logs.CtxError(ctx, "[GetActivityCount] GetActivityCount err: %v", err)
		return nil, err
	}
	activityIds := make([]int64, 0, len(activityList))
	for _, a := range activityList {
		activityIds = append(activityIds, a.ID)
	}

	activityIdToPlan := make(map[int64][]*boost.FlowPlan, len(activityIds))
	activityIdToSignal := make(map[int64][]*boost.EquitySignal, len(activityIds))
	activityIdToLibra := make(map[int64][]*boost.LibraInfo, len(activityIds))

	// 调 ecom.mall.boost聚合调控计划/信号相关信息
	if req.GetNeedDetail() {
		testVal := ProdTestVal
		if env.IsPPE() {
			testVal = PPETestVal
		}
		planResp, err := ecom_mall_boost.RawCall.GetPlanByParams(ctx, &boost.GetPlanByParamsRequest{
			Biz:     convert.ToInt32Ptr(int32(9)),
			BizCode: MallMarketGetPlanBizCode,
			Page: &supply_common.PageInfo{
				Page:     0,
				PageSize: MaxPlanPageSize,
			},
			ActivityIds: activityIds,
			NeedCount:   false,
			NeedSignal:  true,
			Test:        gptr.Of(testVal),
		})
		if err != nil || planResp == nil {
			logs.CtxError(ctx, "[GetActivityList] GetPlanByParams err: %v", err)
			return nil, err
		}

		for _, planDetail := range planResp.Plans {
			if planDetail == nil || planDetail.Plan == nil {
				logs.CtxInfo(ctx, "[GetPlanByParams] planDetail Continue")
				continue
			}

			activityId := planDetail.Plan.ActivityId

			// 调控计划
			if _, ok := activityIdToPlan[activityId]; !ok {
				activityIdToPlan[activityId] = []*boost.FlowPlan{planDetail.Plan}
			} else {
				activityIdToPlan[activityId] = append(activityIdToPlan[activityId], planDetail.Plan)
			}

			// 调控信号
			if planDetail.Plan.Signal != nil {
				if _, ok := activityIdToSignal[activityId]; !ok {
					activityIdToSignal[activityId] = []*boost.EquitySignal{planDetail.Plan.Signal}
				} else {
					activityIdToSignal[activityId] = append(activityIdToSignal[activityId], planDetail.Plan.Signal)
				}
			}

			// 调控实验
			if planDetail.Plan.Signal != nil && len(planDetail.Plan.Signal.Libras) != 0 {
				if _, ok := activityIdToLibra[activityId]; !ok {
					activityIdToLibra[activityId] = planDetail.Plan.Signal.Libras
				} else {
					activityIdToLibra[activityId] = append(activityIdToLibra[activityId], planDetail.Plan.Signal.Libras...)
				}
			}
		}
	}

	logs.CtxInfo(ctx, "IGetActivityList [ActivityIdToPlan]:%s, [ActivityIdToSignal]:%s，[ActivityIdToLibra]:%s", jsonx.ToString(activityIdToPlan), jsonx.ToString(activityIdToSignal), jsonx.ToString(activityIdToLibra))

	userInfo := utils.GetUserInfo(ctx)

	activityEntityList := make([]*activity.ActivityEntity, 0, len(activityList))
	for _, a := range activityList {
		activityHelperIdList := make([]string, 0)
		if a.HelperIdList != "" {
			activityHelperIdList = strings.Split(a.HelperIdList, ",")
		}

		hasEditPermission := userInfo != nil && userInfo.EmployeeId != nil &&
			(*userInfo.EmployeeId == strconv.FormatInt(a.CreatorId, 10) || strings.Contains(a.HelperIdList, *userInfo.EmployeeId))

		activityEntityList = append(activityEntityList, &activity.ActivityEntity{
			ActivityId:              strconv.FormatInt(a.ID, 10),
			ActivityName:            a.Name,
			ActivityTarget:          activity.ActivityTarget(a.Target),
			ActivityDescription:     a.Description,
			ActivityStatus:          activity.ActivityStatus(a.Status),
			ActivityCreatorId:       strconv.FormatInt(a.CreatorId, 10),
			ActivityHelperIdList:    activityHelperIdList,
			ActivityStartTimestamp:  a.StartTimestamp,
			ActivityEndTimestamp:    a.EndTimestamp,
			ActivityCreateTimestamp: a.CreatedAt.Unix(),

			FlowPlanList:   packActivityFlowPlanList(activityIdToPlan[a.ID]),
			FlowSignalList: packActivitySignal(activityIdToSignal[a.ID]),
			FlowLibraList:  packActivityLibra(activityIdToLibra[a.ID]),

			ActivityPermissionInfo: &activity.PermissionInfo{
				HasEditPermission: hasEditPermission,
			},
		})
	}

	return &activity.GetActivityListData{
		ActivityEntityList: activityEntityList,
		TotalCount:         totalCnt,
		PermissionInfo: &activity.PermissionInfo{
			HasWritePermission: true,
		},
	}, nil
}

func (d *ActivityService) ITakeOfflineActivity(ctx context.Context, req *activity.TakeOfflineActivityRequest) (resp *activity.TakeOfflineActivityResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "ITakeOfflineActivity Err:%s", err.Error())
		}
	}()
	if req == nil || req.GetActivityId() == "" || req.GetOperatorId() == "" {
		return nil, errors.New("[TakeOfflineActivity] invalid params")
	}

	activityId := convert.ToInt64(req.GetActivityId())
	if activityId <= 0 {
		return nil, errors.New("[TakeOfflineActivity] invalid params")
	}

	if !d.CanOperateActivity(ctx, req.GetOperatorId(), activityId) {
		return nil, errors.New("[ITakeOfflineActivity] operator is not creator or helper")
	}

	activityList, err := d.ActivityDao.GetActivityList(ctx, &dao.ActivityQueryParams{
		Ids:   []int64{activityId},
		Limit: 1,
	})
	if err != nil {
		logs.CtxError(ctx, "[ITakeOfflineActivity] GetActivityList Err:%s", err.Error())
		return nil, err
	}

	if len(activityList) == 0 {
		return nil, errors.New("[ITakeOfflineActivity] activity not exist")
	}

	act := activityList[0]

	form := lark_service.ActivityToForm(act, activityId)
	activityAuditUuid := lark_service.GetActivityAuditUuid(activityId, convert.ToInt64(req.GetOperatorId()))
	instanceCode, err := lark_service.CreateActivityApprovalInstance(ctx, gptr.Indirect(utils.GetUserInfo(ctx).Email), activityAuditUuid, form)
	if err != nil {
		logs.CtxError(ctx, "[CreatePlan]CreateActivityApprovalInstance failed, err: %v", err)
		return nil, err
	}
	err = d.ActivityApprovalDao.CreateActivityApproval(ctx, &dao.ActivityApproval{
		ActivityID:   activityId,
		InstanceCode: instanceCode,
		AuditStatus:  lark_service.EventStatusPending,
		RevertStatus: act.Status,
		TargetStatus: int64(activity.ActivityStatus_Offline),
		SubmitUser:   req.GetOperatorId(),
		SubmitTime:   time.Now(),
		AuditTime:    time.Time{},
	})
	if err != nil {
		logs.CtxError(ctx, "[ITakeOfflineActivity] CreateActivityApprovalInstance failed, err: %v", err)
		return nil, err
	}

	return &activity.TakeOfflineActivityResponse{}, nil
}

// CanOperateActivity 只有创建人和协作人可以修改活动
func (d *ActivityService) CanOperateActivity(ctx context.Context, operateId string, activityId int64) bool {
	activityList, err := d.ActivityDao.GetActivityList(ctx, &dao.ActivityQueryParams{
		Ids: []int64{activityId},
	})
	if err != nil {
		logs.CtxError(ctx, "[UpdateActivity] GetActivityList err: %v", err)
		return false
	}

	if len(activityList) == 0 {
		return false
	}

	// 只有创建人和协作人可以修改活动
	if operateId == "" || (operateId != strconv.FormatInt(activityList[0].CreatorId, 10) && !strings.Contains(activityList[0].HelperIdList, operateId)) {
		return false
	}

	return true
}

func (d *ActivityService) ApprovalActivity(ctx context.Context, req *activity.ApprovalActivityReq) (*activity.ApprovalActivityResp, error) {
	resp := &activity.ApprovalActivityResp{}

	// 参数校验
	err := checkApprovalActivityReq(req)
	if err != nil {
		return nil, err
	}

	// 查询飞书openID
	larkOpenId := lark_service.GetLarkOpenId(ctx, gptr.Indirect(utils.GetUserInfo(ctx).Email))
	if larkOpenId == "" {
		return resp, errors.New("用户ID找不到")
	}

	// 获取审批单
	activityApproval, err := d.ActivityApprovalDao.GetActivityApproval(ctx, &dao.ActivityApprovalQueryParam{
		ActivityId:  convert.ToInt64(req.ActivityId),
		AuditStatus: lark_service.EventStatusPending,
	})
	if err != nil {
		logs.CtxError(ctx, "[ApprovalActivity] GetActivityApprovalByActivityId err: %v", err)
		return nil, err
	}

	// lark审批实例校验，待审批&&审核人匹配
	instance, err := lark_service.GetInstanceDetail(ctx, activityApproval.InstanceCode)
	if err != nil {
		logs.CtxError(ctx, "[ApprovalActivity] GetInstanceDetail err: %v", err)
		return nil, err
	}

	// 审批单状态校验，待审批状态
	if !d.checkActivityReviewingStatus(ctx, convert.ToInt64(req.ActivityId)) {
		return nil, errors.New("activity is not reviewing status")
	}

	tasks, err := getApprovalTask(instance, larkOpenId)
	if err != nil {
		logs.CtxError(ctx, "[ApprovalActivity] getApprovalTask err: %v", err)
		return nil, err
	}

	if req.Status == lark_service.EventStatusApproved {
		// 审核通过
		err = lark_service.ApproveInstanceTask(ctx, *instance.InstanceCode, tasks, larkOpenId, req.Comment)
	} else if req.Status == lark_service.EventStatusRejected {
		// 审核驳回
		err = lark_service.RejectInstanceTask(ctx, *instance.InstanceCode, tasks, larkOpenId, req.Comment)
	}

	if err != nil {
		logs.CtxError(ctx, "[ApprovalActivity] ApproveInstanceTask or RejectInstanceTask err: %v", err)
		return nil, err
	}

	return resp, nil
}

func (d *ActivityService) ActivityApprovalCallback(ctx context.Context, req *activity.ApprovalCallbackRequest) (resp *activity.ApprovalCallbackResponse, err error) {
	resp = &activity.ApprovalCallbackResponse{
		Challenge: req.Challenge,
	}
	event := req.Event

	logs.CtxInfo(ctx, "[PlanApprovalCallback] event=%s", utils2.JSONF(event))

	// 校验固定字段
	if event == nil || event.GetType() != "approval_instance" ||
		event.GetApprovalCode() != lark_service.MarketOperationApprovalCode || event.GetStatus() == lark_service.EventStatusPending {
		return
	}
	activityId, operatorId := lark_service.ParseActivityUuid(event.GetUuid())
	logs.CtxInfo(ctx, "[PlanApprovalCallback] activityId=%s", utils2.JSONF(activityId))
	if activityId == 0 {
		return
	}

	// 获取审批单
	activityApproval, err := d.ActivityApprovalDao.GetActivityApproval(ctx, &dao.ActivityApprovalQueryParam{
		ActivityId:  activityId,
		AuditStatus: lark_service.EventStatusPending,
	})
	if err != nil {
		logs.CtxError(ctx, "[ApprovalActivity] GetActivityApproval err: %v", err)
		return nil, err
	}

	if activityApproval.RevertStatus == 0 || activityApproval.TargetStatus == 0 {
		logs.CtxError(ctx, "[ApprovalActivity] activityApproval status is abnormal, revert status: %d, target status: %d", activityApproval.RevertStatus, activityApproval.TargetStatus)
		return nil, errors.New("activityApproval status is abnormal")
	}

	eventStatus := event.GetStatus()
	if eventStatus == lark_service.EventStatusApproved { // 审核通过
		if activityApproval.TargetStatus == int64(activity.ActivityStatus_Offline) {
			// 如果是下线操作，先调mall_boost接口下线关联调控计划
			err := d.TakeOfflineMallBoostPlan(ctx, activityId, operatorId)
			if err != nil {
				logs.CtxError(ctx, "[ActivityApprovalCallback] TakeOfflineMallBoostPlan err: %v", err)
				return nil, err
			}
		}

		err := d.ActivityDao.UpdateActivity(ctx, activityId, &dao.Activity{Status: activityApproval.TargetStatus})
		if err != nil {
			logs.CtxError(ctx, "[ActivityApprovalCallback] UpdateActivity err: %v", err)
			return nil, err
		}

	} else if eventStatus == lark_service.EventStatusRejected || eventStatus == lark_service.EventStatusCANCELED { // 拒绝审核
		err := d.ActivityDao.UpdateActivity(ctx, activityId, &dao.Activity{Status: activityApproval.RevertStatus})
		if err != nil {
			logs.CtxError(ctx, "[ActivityApprovalCallback] UpdateActivity err: %v", err)
			return nil, err
		}
	}

	// 更新审批单状态
	err = d.ActivityApprovalDao.UpdateActivityApproval(ctx, activityId, &dao.ActivityApproval{
		AuditStatus: eventStatus,
	})
	if err != nil {
		logs.CtxError(ctx, "[ActivityApprovalCallback] UpdateActivityApproval err: %v", err)
		return nil, err
	}

	return resp, nil
}

func getApprovalTask(instance *larkapproval.GetInstanceRespData, larkOpenId string) ([]*larkapproval.InstanceTask, error) {
	if instance == nil {
		return nil, errors.New("[getApprovalTask] instance is nil")
	}

	// 审批状态校验
	if instance.Status != nil && *instance.Status != lark_service.EventStatusPending {
		return nil, errors.New("[getApprovalTask] instance status is not pending")
	}

	tasks := make([]*larkapproval.InstanceTask, 0)

	// 审核人校验
	for _, task := range instance.TaskList {
		if task == nil {
			continue
		}
		if *task.Status == lark_service.EventStatusPending && *task.OpenId == larkOpenId {
			tasks = append(tasks, task)
		}
	}

	if len(tasks) == 0 {
		return nil, errors.New("操作用户非计划审核人")
	}
	return tasks, nil
}

func (d *ActivityService) checkActivityReviewingStatus(ctx context.Context, activityId int64) bool {
	params := &dao.ActivityQueryParams{
		Ids:        []int64{activityId},
		StatusList: []int32{int32(activity.ActivityStatus_Reviewing)},
		Limit:      1,
	}
	// 查sql获取活动列表
	activityList, err := d.ActivityDao.GetActivityList(ctx, params)
	if err != nil {
		logs.CtxError(ctx, "[checkActivityStatus] GetActivityList err: %v", err)
		return false
	}

	if len(activityList) == 0 {
		return false
	}

	return true
}

func checkApprovalActivityReq(req *activity.ApprovalActivityReq) error {
	if req == nil {
		return errors.New("请求参数为空")
	}
	if req.ActivityId == "" {
		return errors.New("审核活动ID为空")
	}
	if req.Status != "APPROVED" && req.Status != "REJECTED" {
		return errors.New("审批状态参数有误")
	}
	if len(req.Comment) > 100 {
		return errors.New("审批信息不得超过100字节")
	}
	return nil
}

// TakeOfflineMallBoostPlan 下线关联调控计划
func (d *ActivityService) TakeOfflineMallBoostPlan(ctx context.Context, activityId int64, operatorId int64) error {

	// 调ecom.mall.boost查询调控计划相关信息
	planResp, err := ecom_mall_boost.RawCall.GetPlanByParams(ctx, &boost.GetPlanByParamsRequest{
		Biz:     convert.ToInt32Ptr(int32(9)),
		BizCode: MallMarketGetPlanBizCode,
		Page: &supply_common.PageInfo{
			Page:     0,
			PageSize: MaxPlanPageSize,
		},
		ActivityIds: []int64{activityId},
		NeedCount:   true,
		NeedSignal:  true,
	})

	if err != nil || planResp == nil {
		logs.CtxError(ctx, "[TakeOfflineActivity] GetPlanByParams err: %v", err)
		return err
	}

	planIds := make([]int64, 0, len(planResp.Plans))
	for _, planDetail := range planResp.Plans {
		if planDetail == nil || planDetail.Plan == nil {
			continue
		}
		planIds = append(planIds, planDetail.Plan.Id)
	}

	// 先调ecom.mall.boost接口下线活动关联的调控计划
	_, err = ecom_mall_boost.RawCall.UpdatePlanStatus(ctx, &boost.UpdatePlanStatusRequest{
		Ids:     planIds,
		Status:  FlowPlanStatusCancel,
		Updater: operatorId,
	})
	if err != nil {
		logs.CtxError(ctx, "[TakeOfflineActivity] UpdatePlanStatus err: %v", err)
		return err
	}

	return nil
}
