package activity_service

const (
	MaxPlanPageSize = 100

	FlowPlanStatusCancel = 100

	BoostAuditorBizCode = "activity"

	MallMarketGetPlanBizCode = "market"

	PPETestVal  int32 = 1
	ProdTestVal int32 = 0
)
