package ai_conclusion_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/jinzhu/copier"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"code.byted.org/temai/go_lib/convert"
)

// 取数接口
func (d *DynamicGetData) GetMultiDimConclusionData(ctx context.Context, req *ai_analysis.AIConclusionRequest, aiConclusionConfig *dao.AIConclusion) (string, error) {
	if req == nil || aiConclusionConfig == nil {
		return "", errors.New("invalid request or aiConclusionConfig")
	}

	_req := &common_request.CommonAnalysisRequest{
		Base: req.Base,
	}
	err := json.Unmarshal([]byte(req.ReqJson), _req)
	if err != nil {
		return "", err
	}
	logs.CtxInfo(ctx, "GetMultiDimConclusionData req: %v", _req)
	// 调用 mw.CheckBaseStructStreamParams 校验筛选项参数是否合法（PS: 因为需要兼容流式接口，流式接口无法从ctx中获取用户信息，所以需要调用CheckBaseStructStreamParams方法）
	ok, _, msg, ctx := mw.CheckBaseStructStreamParams(ctx, _req.BaseReq, &req.EmployeeId)
	if !ok {
		return "", fmt.Errorf("[GetMultiDimConclusionData] CheckBaseStructStreamParams failed, err=%s", msg)
	}

	if _req.CompareReq != nil {
		ok, _, msg, ctx = mw.CheckBaseStructStreamParams(ctx, _req.CompareReq, &req.EmployeeId)
		if !ok {
			return "", fmt.Errorf("[GetMultiDimConclusionData] CheckBaseStructStreamParams failed, err=%s", msg)
		}
	}

	// 填充动态指标和维度
	if aiConclusionConfig.ExtraConfig != nil {
		extraConfig := &ProdReviewExtraConfig{}
		err := json.Unmarshal([]byte(*aiConclusionConfig.ExtraConfig), extraConfig)
		if err != nil {
			return "", err
		}

		if len(extraConfig.GroupAttrs) > 0 {
			// 判断维度枚举值是否为空，如果为空则填充默认值
			for _, dim := range extraConfig.GroupAttrs {
				if dim != nil && dim.DimInfo != nil && len(dim.DimInfo.SelectedValues) == 0 {
					dimInfo, _err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(dim.DimInfo.Id))
					if _err != nil {
						continue
					}
					// 将dimInfo的维度枚举值填充到dim.DimInfo.SelectedValues
					dim.DimInfo.SelectedValues = dimInfo.Values
				}
			}
		}

		// 填充指标和维度到请求体
		if _req.BaseReq != nil {
			if len(_req.BaseReq.TargetMetaList) == 0 {
				_req.BaseReq.TargetMetaList = extraConfig.TargetMetaList
			}
			if len(_req.BaseReq.GroupAttrs) == 0 {
				_req.BaseReq.GroupAttrs = extraConfig.GroupAttrs
			}
		}

		if _req.CompareReq != nil {
			if len(_req.CompareReq.TargetMetaList) == 0 {
				_req.CompareReq.TargetMetaList = extraConfig.TargetMetaList
			}
			if len(_req.CompareReq.GroupAttrs) == 0 {
				_req.CompareReq.GroupAttrs = extraConfig.GroupAttrs
			}
		}
	}

	switch aiConclusionConfig.AiConclusionId {
	case int64(ai_analysis.AIConclusionModule_ProdAnalysisSubsidyPortrait):
		return d.MultiDimAnalysisConclusion(ctx, _req)
	default:
		return "", errors.New("[GetMultiDimConclusionData] unknown ai_conclusion_id")
	}
}

// 多维分析结论
func (d *DynamicGetData) MultiDimAnalysisConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (string, error) {
	logs.CtxInfo(ctx, "[DynamicGetData] MultiAnalysisConclusion req=%+v", req)
	_req := &common_request.CommonAnalysisRequest{}
	err := copier.Copy(_req, req)
	if err != nil {
		return "", err
	}

	resp, _, err := d.MultiDimTableService.ICommonAnalysisMultiDimTable(ctx, _req)
	if err != nil || resp == nil {
		return "", err
	}

	prodAnalysisRows := make([][]string, 0)
	prodCompareRows := make([][]string, 0)

	maxDepth := 0

	// 标题行
	titleRow := make([]string, 0)
	if req.BaseReq != nil && len(req.BaseReq.GroupAttrs) > 0 {
		maxDepth = len(req.BaseReq.GroupAttrs)
		for i, dim := range req.BaseReq.GroupAttrs {
			if dim != nil && dim.DimInfo != nil {
				titleRow = append(titleRow, dim.DimInfo.Name)
			} else {
				titleRow = append(titleRow, fmt.Sprintf("维度%d", i+1))
			}
		}
	}
	// 添加层数限制
	maxDepth = min(maxDepth, 1)

	// 处理整体数据
	if resp.Total != nil {
		// 补充标题行指标部分
		if len(resp.Total.TargetList) > 0 {
			for _, target := range resp.Total.TargetList {
				titleRow = append(titleRow, fmt.Sprintf("%s（%s）", target.DisplayName, target.Name))
			}
		}
		prodAnalysisRows = append(prodAnalysisRows, titleRow)
		prodCompareRows = append(prodCompareRows, titleRow)

		prodTotalRows, prodCompareTotalRows, _, _, _, _ := processMultiDimsRows([]*common_response.RowData{resp.Total}, maxDepth, []string{}, 1)
		prodAnalysisRows = append(prodAnalysisRows, prodTotalRows...)
		prodCompareRows = append(prodCompareRows, prodCompareTotalRows...)
	}

	// 处理维度数据
	if len(resp.Rows) > 0 {
		prodDimRows, prodCompareDimRows, _, _, _, _ := processMultiDimsRows(resp.Rows, maxDepth, []string{}, 1)
		prodAnalysisRows = append(prodAnalysisRows, prodDimRows...)
		prodCompareRows = append(prodCompareRows, prodCompareDimRows...)
	}

	prodAnalysisTable, _ := utils.ConvertStringArrayToMarkdownTable(prodAnalysisRows)
	prodCompareTable, _ := utils.ConvertStringArrayToMarkdownTable(prodCompareRows)
	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	var targetMetaList []*dimensions.TargetMetaInfo
	if req.BaseReq != nil {
		targetMetaList, err = d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
		if err != nil {
			return "", err
		}
	}

	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 筛选项格式化
	baseReqStr := utils.ConvertBaseReqToMarkdown(req.BaseReq, bizInfoList, dimMap, targetMetaList)

	// 汇总数据
	return fmt.Sprintf("# 分析货盘\n\n## 筛选条件\n\n%s\n\n## 分析周期数据\n\n%s\n\n## 对比周期数据\n\n%s\n\n",
		baseReqStr, prodAnalysisTable, prodCompareTable), nil
}
