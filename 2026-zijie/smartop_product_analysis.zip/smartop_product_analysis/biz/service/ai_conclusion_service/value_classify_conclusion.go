package ai_conclusion_service

import (
	"context"
	"fmt"

	"code.byted.org/gopkg/logs"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"github.com/jinzhu/copier"
)

// SupplyBubbleConclusion 气泡图AI分析数据
func (d *DynamicGetData) ValueClassifyConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (string, error) {
	logs.CtxInfo(ctx, "[DynamicGetData] ValueClassifyConclusion req=%+v", req)
	_req := &common_request.CommonAnalysisRequest{}
	err := copier.Copy(_req, req)
	if err != nil {
		return "", err
	}

	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	var targetMetaList []*dimensions.TargetMetaInfo
	if req.BaseReq != nil {
		targetMetaList, err = d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
		if err != nil {
			return "", err
		}
	}

	// 筛选项格式化
	baseReqStr := utils.ConvertBaseReqToMarkdown(req.BaseReq, bizInfoList, dimMap, targetMetaList)

	resp, err := d.ProductReviewService.ProductValueClassify(ctx, _req)

	if err != nil || resp == nil {
		return "", err
	}

	if resp.ItemDataList == nil || len(resp.ItemDataList) < 1 {
		return "", fmt.Errorf("no data")
	}

	if req.BizExtraInfo == nil || req.BizExtraInfo.ProdReviewParams == nil || req.BizExtraInfo.ProdReviewParams.ProductValueClassifyParams == nil {
		return "", fmt.Errorf("params error, no vaild ProductValueClassifyParams ")
	}

	targetList := resp.ItemDataList[0].TargetList

	if targetList == nil || len(targetList) < 9 {
		return "", fmt.Errorf("no enough target data")
	}

	shortStr := ""
	longStr := ""

	shortValue := req.BizExtraInfo.ProdReviewParams.ProductValueClassifyParams.ShortTermThreshold * 100
	longValue := req.BizExtraInfo.ProdReviewParams.ProductValueClassifyParams.LongTermThreshold * 100

	switch req.BizExtraInfo.ProdReviewParams.ProductValueClassifyParams.DefineType {
	case 3:
		{
			shortStr = fmt.Sprintf("策略分析周期内　日均VS对比周期日均，支付 GMV【AA 增幅】≥%f%%的商品", shortValue)
			longStr = fmt.Sprintf("策略结束后7天　 日均VS策略期日均，支付 GMV【AA 增幅】≥%f%%的商品", longValue)
			break
		}

	case 2:
		{
			shortStr = fmt.Sprintf("策略分析周期内　支付GMV对策略覆盖品整体分位数TOP%f%%的商品", shortValue)
			longStr = fmt.Sprintf("策略结束后7天　 支付GMV对策略覆盖品整体分位数TOP%f%%的商品", longValue)
			break
		}

	default:
		{
			shortStr = fmt.Sprintf("策略分析周期内　支付GMV对策略覆盖品整体支付GMV贡献度≥%f%%的商品", shortValue)
			longStr = fmt.Sprintf("策略结束后7天　 支付GMV对策略覆盖品整体GMV贡献度≥%f%%的商品", longValue)
			break
		}
	}

	dataRows := [][]string{}

	titleRow := []string{"策略阶段", "商品类型", "定义", "商品数", "GMV"}
	dataRows = append(dataRows, titleRow)

	dataRows = append(dataRows, []string{"策略前", "策略底池商品数", "分析周期内策略覆盖的全部商品", fmt.Sprintf("%s(%f)", targetList[0].DisplayValue, targetList[0].Value), "-"})

	dataRows = append(dataRows, []string{"策略中", "策略优势商品", "分析周期日均GMV > 对比周期日均GMV", GetValueStr(targetList[1]), "-"})
	dataRows = append(dataRows, []string{"策略中", "策略劣势商品", "分析周期日均GMV < 对比周期日均GMV", GetValueStr(targetList[2]), "-"})
	dataRows = append(dataRows, []string{"策略中", "策略效果不明显商品", "分析周期日均GMV = 对比周期日均GMV", GetValueStr(targetList[3]), "-"})

	dataRows = append(dataRows, []string{"策略后", "短期有价值品", shortStr, GetValueStr(targetList[4]),
		GetValueStr(targetList[5])})
	dataRows = append(dataRows, []string{"策略后", "长期有价值品", longStr, GetValueStr(targetList[6]),
		GetValueStr(targetList[7])})
	dataRows = append(dataRows, []string{"策略后", "策略无效品", "策略结束后7天日均GMV < 策略期间日均GMV的商品", GetValueStr(targetList[8]),
		"-"})

	dataMarkdown, _ := utils.ConvertStringArrayToMarkdownTable(dataRows)

	reportStr := fmt.Sprintf(`# 筛选条件
%s
---
# 下钻数据
%s
`, baseReqStr, dataMarkdown)

	// 汇总数据
	return reportStr, nil
}
