package ai_conclusion_service

import (
	"context"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	multi_dim_table_service "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_table_domain/service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"
	ai_analysis_tools "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_review_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
)

type IAIConclusionService interface {
	AIConclusion(ctx context.Context, req *ai_analysis.AIConclusionRequest, stream *ai_analysis_service.StreamServer) (string, error)
}

type DynamicGetData struct {
	ProductReviewService product_review_service.IProductReviewService
	DimensionService     dimension_service.IDimensionService
	DimensionBizListDao  dao.IDimensionBizListDao
	MultiDimTableService multi_dim_table_service.IMultiDimTableService
	AIAnalysisService    ai_analysis_service.IAIAnalysisService
	DimensionListDao     dao.IDimensionListDao
	CommonTool           *ai_analysis_tools.CommonTool
}

type AIConclusion struct {
	AIConclusionDao dao.IAIConclusionDao
	DynamicGetData  *DynamicGetData
}

func FillTableData(rows []*common_response.RowData, fillRows [][]string, dims []string, maxDepth int) [][]string {
	for _, row := range rows {
		newDims := append(dims, row.DimensionName)

		tableRow := make([]string, 0, maxDepth)
		tableRow = append(tableRow, newDims...)
		for len(tableRow) < maxDepth {
			tableRow = append(tableRow, "-")
		}
		for _, target := range row.TargetList {
			tableRow = append(tableRow, fmt.Sprintf("%s (%f)", target.DisplayValue, target.Value))
		}
		fillRows = append(fillRows, tableRow)

		if len(row.ChildrenRows) > 0 && len(newDims) < maxDepth {
			fillRows = FillTableData(row.ChildrenRows, fillRows, newDims, maxDepth)
		}
	}
	return fillRows
}

func GetValueStr(target *analysis.TargetCardEntity) string {
	return fmt.Sprintf("%s(%f)", target.DisplayValue, target.Value)
}
