package ai_conclusion_service

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	ai_analysis_tools "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"github.com/jinzhu/copier"
)

// 取数接口
func (d *DynamicGetData) GetAttributionConclusionData(ctx context.Context, req *ai_analysis.AIConclusionRequest, aiConclusionConfig *dao.AIConclusion) (string, error) {
	if req == nil || aiConclusionConfig == nil {
		return "", errors.New("invalid request or aiConclusionConfig")
	}

	attributionReq := &analysis.AttributionCommonBaseStruct{}
	err := json.Unmarshal([]byte(req.ReqJson), attributionReq)
	if err != nil {
		return "", err
	}

	// 参数校验
	ok, _, msg, ctx := mw.CheckAttributionStreamParams(ctx, attributionReq, &req.EmployeeId)
	if !ok {
		return "", fmt.Errorf("[GetAttributionConclusionData] CheckAttributionStreamParams failed, err=%s", msg)
	}

	_req := &ai_analysis_tools.AttributionCommonToolParams{}
	err = copier.Copy(_req, attributionReq)
	if err != nil {
		return "", err
	}

	coreTargetData := ""
	reasonData := ""
	if _req.BizType == dimensions.BizType_AttributionCoreGuess {
		// 猜喜
		cc := co.NewConcurrent(ctx)
		cc.GoV2(func() error {
			var getGuessCoreTargetRes *tools.GetDataToolRes
			guessCoreTargetTool := ai_analysis_tools.NewGuessCoreTargetTool(d.CommonTool)
			getGuessCoreTargetRes, err = guessCoreTargetTool.GetGuessCoreTargetTool(ctx, _req)
			if err != nil {
				return err
			}
			if getGuessCoreTargetRes != nil && getGuessCoreTargetRes.ErrorMsg != "" {
				return errors.New(getGuessCoreTargetRes.ErrorMsg)
			}
			if getGuessCoreTargetRes != nil && len(getGuessCoreTargetRes.Data) > 0 {
				for _, data := range getGuessCoreTargetRes.Data {
					markdown, _err := utils.ConvertArrayToMarkdownTable(data.Data)
					if _err != nil {
						continue
					}
					coreTargetData += fmt.Sprintf("%s\n\n%s\n\n", data.Description, markdown)
				}
			}

			return nil
		})
		cc.GoV2(func() error {
			var getGuessReasonRes *tools.GetDataToolRes
			guessReasonTool := ai_analysis_tools.NewGuessReasonTool(d.CommonTool)
			getGuessReasonRes, err = guessReasonTool.GetGuessReasonTool(ctx, _req)
			if err != nil {
				return err
			}
			if getGuessReasonRes != nil && getGuessReasonRes.ErrorMsg != "" {
				return errors.New(getGuessReasonRes.ErrorMsg)
			}
			if getGuessReasonRes != nil && len(getGuessReasonRes.Data) > 0 {
				for _, data := range getGuessReasonRes.Data {
					markdown, _err := utils.ConvertArrayToMarkdownTable(data.Data)
					if _err != nil {
						continue
					}
					reasonData += fmt.Sprintf("%s\n\n%s\n\n", data.Description, markdown)
				}
			}
			return nil
		})
		err = cc.WaitV2()
		if err != nil {
			return "", err
		}
	} else {
		// 大盘
		cc := co.NewConcurrent(ctx)
		cc.GoV2(func() error {
			var getGrowthCoreTargetRes *tools.GetDataToolRes
			growthCoreTargetTool := ai_analysis_tools.NewGrowthCoreTargetTool(d.CommonTool)
			getGrowthCoreTargetRes, err = growthCoreTargetTool.GetGrowthCoreTargetTool(ctx, _req)
			if err != nil {
				return err
			}
			if getGrowthCoreTargetRes != nil && getGrowthCoreTargetRes.ErrorMsg != "" {
				return errors.New(getGrowthCoreTargetRes.ErrorMsg)
			}
			if getGrowthCoreTargetRes != nil && len(getGrowthCoreTargetRes.Data) > 0 {
				for _, data := range getGrowthCoreTargetRes.Data {
					markdown, _err := utils.ConvertArrayToMarkdownTable(data.Data)
					if _err != nil {
						continue
					}
					coreTargetData += fmt.Sprintf("%s\n\n%s\n\n", data.Description, markdown)
				}
			}

			return nil
		})
		cc.GoV2(func() error {
			var getGrowthReasonRes *tools.GetDataToolRes
			growthReasonTool := ai_analysis_tools.NewGrowthReasonTool(d.CommonTool)
			getGrowthReasonRes, err = growthReasonTool.GetGrowthReasonTool(ctx, _req)
			if err != nil {
				return err
			}
			if getGrowthReasonRes != nil && getGrowthReasonRes.ErrorMsg != "" {
				return errors.New(getGrowthReasonRes.ErrorMsg)
			}
			if getGrowthReasonRes != nil && len(getGrowthReasonRes.Data) > 0 {
				for _, data := range getGrowthReasonRes.Data {
					markdown, _err := utils.ConvertArrayToMarkdownTable(data.Data)
					if _err != nil {
						continue
					}
					reasonData += fmt.Sprintf("%s\n\n%s\n\n", data.Description, markdown)
				}
			}
			return nil
		})
		err = cc.WaitV2()
		if err != nil {
			return "", err
		}
	}

	// 筛选项格式化
	baseReq := &dimensions.ProductAnalysisBaseStruct{}
	var res string
	err = copier.Copy(baseReq, _req)
	if err == nil {
		// 获取所有的维度信息
		dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

		// 获取指标元信息
		targetMetaList, err := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, _req.BizType, false)
		if err != nil {
			return "", err
		}

		// 获取业务线信息
		bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
		if err != nil {
			return "", err
		}

		baseReqStr := utils.ConvertBaseReqToMarkdown(baseReq, bizInfoList, dimMap, targetMetaList)
		res = fmt.Sprintf("## 筛选条件\n\n%s\n\n## 指标数据\n\n%s\n\n%s", baseReqStr, coreTargetData, reasonData)
	} else {
		res = fmt.Sprintf("%s\n%s", coreTargetData, reasonData)
	}

	return res, nil
}
