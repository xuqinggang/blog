package ai_conclusion_service

import (
	"context"
	"errors"
	"fmt"

	"code.byted.org/gopkg/logs"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"github.com/jinzhu/copier"
	"github.com/thoas/go-funk"
)

type ResObj struct {
	funnelData *common_response.ItemDataList
	tableData  *common_response.MultiDimTableData
}

// SupplyBubbleConclusion 气泡图AI分析数据
func (d *DynamicGetData) FunnelAnalysisConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (string, error) {
	logs.CtxInfo(ctx, "[DynamicGetData] SupplyBubbleConclusion req=%+v", req)
	_req := &common_request.CommonAnalysisRequest{}
	err := copier.Copy(_req, req)
	if err != nil {
		return "", err
	}

	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	var targetMetaList []*dimensions.TargetMetaInfo
	if req.BaseReq != nil {
		targetMetaList, err = d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
		if err != nil {
			return "", err
		}
	}

	// 筛选项格式化
	baseReqStr := utils.ConvertBaseReqToMarkdown(req.BaseReq, bizInfoList, dimMap, targetMetaList)

	funnelData, err := d.ProductReviewService.ICommonAnalysisItemData(ctx, _req)
	if err != nil {
		return "", nil
	}
	funnelRows := make([][]string, 0)

	if funnelData == nil || len(funnelData.ItemDataList) == 0 {
		return "", errors.New("empty data")
	}

	{
		funnelData := funnelData
		targetKeys := make([]string, 0)

		titleRow := []string{"漏斗层级"}
		firstData := funnelData.ItemDataList[0]
		for _, target := range firstData.TargetList {
			titleRow = append(titleRow, target.DisplayName)
			targetKeys = append(targetKeys, target.Name)
		}
		funnelRows = append(funnelRows, titleRow)

		for _, itemData := range funnelData.ItemDataList {
			row := []string{itemData.ItemName}

			for _, key := range targetKeys {
				target, isOk := funk.Find(itemData.TargetList, func(t *analysis.TargetCardEntity) bool {
					return t.Name == key
				}).(*analysis.TargetCardEntity)

				if isOk {
					row = append(row, fmt.Sprintf("%s (%f)", target.DisplayValue, target.Value))
				} else {
					row = append(row, "-")
				}
			}
			funnelRows = append(funnelRows, row)
		}
	}
	funnelMarkdown, _ := utils.ConvertStringArrayToMarkdownTable(funnelRows)

	// 下钻数据处理
	firstDrill, isOk := funk.Find(funnelData.ItemDataList, func(itemData *common_response.ItemData) bool {
		return itemData.ExtraInfo.FunnelFloor.FunnelFloorOrder == 1
	}).(*common_response.ItemData)

	if !isOk {
		return "", nil
	}

	// 克隆一个新的请求对象用于修改
	cloneReq := &common_request.CommonAnalysisRequest{}
	if error := copier.Copy(cloneReq, _req); error != nil {
		logs.CtxError(ctx, "[FunnelAnalysisConclusion] copier.Copy failed, err=%v", err)
		return "", error
	}
	switch cloneReq.BizExtraInfo.ProdReviewParams.ModuleName {
	// 商品漏斗
	case prod_review.ModuleName_RecruitProdFunnel:
		if cloneReq.BizExtraInfo.ProdReviewParams.BizProjectId != "" {
			cloneReq.BizExtraInfo.ProdReviewParams.ModuleName = prod_review.ModuleName_FunnelDrillAnalysisFirst
		} else {
			cloneReq.BizExtraInfo.ProdReviewParams.ModuleName = prod_review.ModuleName_SingleStrategyFunnelDrillAnalysisFirst
		}

	case prod_review.ModuleName_AllowanceFunnel:
		cloneReq.BizExtraInfo.ProdReviewParams.ModuleName = prod_review.ModuleName_FunnelDrillAnalysisFirst
	default:
		logs.CtxError(ctx, "[FunnelAnalysisConclusion] unknown prod_review moduleName")
		return "", errors.New("unknown prod_review moduleName")
	}

	cloneReq.BaseReq.Dimensions = append(cloneReq.BaseReq.Dimensions, firstDrill.ExtraInfo.FunnelFloor.DimensionInfos...)
	cloneReq.CompareReq = nil

	tableData, _, err := d.MultiDimTableService.ICommonAnalysisMultiDimTable(ctx, cloneReq)
	if err != nil {
		return "", nil
	}

	tableRows := make([][]string, 0)
	{
		// 处理标题行
		titleRow := []string{}
		for _, groupAttr := range cloneReq.BaseReq.GroupAttrs {
			titleRow = append(titleRow, groupAttr.DimInfo.Name)
		}

		if tableData.Rows != nil && len(tableData.Rows) > 0 {
			firstRow := tableData.Rows[0]
			if firstRow != nil {
				for _, target := range firstRow.TargetList {
					titleRow = append(titleRow, target.DisplayName)
				}

				tableRows = append(tableRows, titleRow)

				// 处理数据行
				tableRows = FillTableData(tableData.Rows, tableRows, []string{}, len(cloneReq.BaseReq.GroupAttrs))
			}
		}
	}

	tableMarkdown, _ := utils.ConvertStringArrayToMarkdownTable(tableRows)

	reportStr := fmt.Sprintf(`# 筛选条件
%s
---
# 漏斗数据
%s

---
# 下钻数据
%s
`, baseReqStr, funnelMarkdown, tableMarkdown)

	// 汇总数据
	return reportStr, nil

}
