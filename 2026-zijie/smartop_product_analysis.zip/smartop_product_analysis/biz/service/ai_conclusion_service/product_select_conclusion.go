package ai_conclusion_service

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_select_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/product_select"
	"code.byted.org/gopkg/jsonx"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
)

func GetFeatureNameList(ctx context.Context, taskIdStr string) []string {
	// 从请求中的task_id获取任务详情，以获取UsedFeatureInfo
	var featureNames []string
	if taskIdStr != "" {
		logs.CtxInfo(ctx, "Trying to get task details for task_id: %s", taskIdStr)

		tx := mysql.DB(ctx).Begin()
		if tx.Error != nil {
			logs.CtxError(ctx, "GetFeatureNameList 获取数据库的事务失败，err=%v+", tx.Error.Error())
			return featureNames
		}
		var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
		taskId, _ := utils.String2Int64(taskIdStr)
		taskInfo, err := ProductSelectTaskDao.GetProductSelectTask(ctx, tx, taskId)
		if err != nil {
			logs.CtxError(ctx, "GetFeatureNameList GetProductSelectTask err: %v", err)
			return featureNames
		}
		tx.Commit()

		if taskInfo != nil && len(taskInfo.Extra) > 0 {
			task := product_select.Extra{}
			if err = sonic.UnmarshalString(taskInfo.Extra, &task); err != nil {
				logs.CtxError(ctx, "GetFeatureNameList UnmarshalString error: %v", err)
			}
			for _, featureInfo := range task.UsedFeatureInfo {
				if featureInfo != nil && featureInfo.FeatureName != "" {
					featureNames = append(featureNames, featureInfo.FeatureName)
				}
			}
			if len(featureNames) > 0 {
				logs.CtxInfo(ctx, "Extracted FeatureNames from task detail: %v", featureNames)
			}
		}
	}

	return featureNames
}

// 选品任务取数接口
func (d *DynamicGetData) GetProductSelectTaskConclusionData(ctx context.Context, req *ai_analysis.AIConclusionRequest, aiConclusionConfig *dao.AIConclusion) (string, error) {
	logs.CtxInfo(ctx, "GetProductSelectTaskConclusionData start, req: %+v, aiConclusionConfig: %+v", req, aiConclusionConfig)
	if req == nil || aiConclusionConfig == nil {
		logs.CtxError(ctx, "GetProductSelectTaskConclusionData: invalid request or aiConclusionConfig")
		return "", errors.New("invalid request or aiConclusionConfig")
	}

	taskReq := make(map[string]interface{})
	err := sonic.UnmarshalString(strings.Replace(req.ReqJson, "\\", "", -1), &taskReq)
	if err != nil {
		logs.CtxError(ctx, "GetProductSelectTaskConclusionData UnmarshalString error: %s, ReqJson: %s", err.Error(), req.ReqJson)
		return "", err
	}
	logs.CtxInfo(ctx, "GetProductSelectTaskConclusionData taskReq: %+v", taskReq)

	taskId := convert.ToString(taskReq["task_id"])
	startDate := convert.ToString(taskReq["start_date"])
	endDate := convert.ToString(taskReq["end_date"])
	productSelectReq := &product_select.GetProductSelectTaskPreviewResultRequest{
		PreviewScene: product_select.PreviewScene_TaskResult,
		StartDate:    &startDate,
		EndDate:      &endDate,
		TaskId:       &taskId,
		PreviewTypes: []product_select.TaskPreviewType{
			product_select.TaskPreviewType_ProductTotal,
			product_select.TaskPreviewType_BrandLevelDistribution,
			product_select.TaskPreviewType_ShopLevelDistribution,
			product_select.TaskPreviewType_IndustryDistribution,
			product_select.TaskPreviewType_ShopTotal,
			product_select.TaskPreviewType_FirstCategoryTotal,
			product_select.TaskPreviewType_LeafCategoryTotal,
			product_select.TaskPreviewType_BrandTotal,
			product_select.TaskPreviewType_OrderTotal,
			product_select.TaskPreviewType_OPGroupDistribution,
		},
	}
	logs.CtxInfo(ctx, "GetProductSelectTaskConclusionData start, productSelectReq: %s", jsonx.ToString(productSelectReq))

	// 调用选品任务预览结果接口获取数据
	productSelectService := &product_select_service.ProductSelectService{}
	resp, err := productSelectService.IGetProductSelectTaskPreviewResult(ctx, productSelectReq)
	if err != nil {
		logs.CtxError(ctx, "GetProductSelectTaskConclusionData: call IGetProductSelectTaskPreviewResult failed, err: %v", err)
		return "", fmt.Errorf("call IGetProductSelectTaskPreviewResult failed, err: %w", err)
	}
	// 获取使用的算法特征信息列表
	featureNameList := GetFeatureNameList(ctx, taskId)
	logs.CtxInfo(ctx, "GetProductSelectTaskConclusionData resp: %+v, featureNameList: %+v", resp, featureNameList)

	// 格式化数据为Markdown
	markdownData, err := d.formatProductSelectTaskDataToMarkdown(ctx, resp)
	if err != nil {
		logs.CtxError(ctx, "GetProductSelectTaskConclusionData: format data failed, err: %v", err)
		return "", err
	}

	// 添加特征名称到Markdown结果中
	if len(featureNameList) > 0 {
		featureSection := "\n## 使用的特征信息\n\n"
		featureSection += "以下是选品任务使用的特征列表：\n\n"
		for _, name := range featureNameList {
			featureSection += fmt.Sprintf("- %s\n", name)
		}
		markdownData += featureSection
	}

	logs.CtxInfo(ctx, "GetProductSelectTaskConclusionData end successfully, %s", jsonx.ToString(markdownData))
	return markdownData, nil
}

// formatProductSelectTaskDataToMarkdown 将选品任务数据格式化为Markdown
func (d *DynamicGetData) formatProductSelectTaskDataToMarkdown(ctx context.Context, resp *product_select.GetProductSelectTaskPreviewResultResponse) (string, error) {
	logs.CtxInfo(ctx, "formatProductSelectTaskDataToMarkdown start, resp: %+v", resp)

	var result string
	result = "# 选品任务数据预览\n\n"

	// 处理字符串类型结果
	if resp.StringResult_ != nil && len(resp.StringResult_) > 0 {
		result += "## 基础统计数据\n\n"
		for previewType, data := range resp.StringResult_ {
			if data == nil {
				continue
			}
			result += fmt.Sprintf("### %s\n\n", getPreviewTypeTitle(previewType))
			result += fmt.Sprintf("- 数值: %s\n\n", data.DisplayValue)
			if data.TrendData != nil && len(data.TrendData) > 0 {
				result += "#### 趋势数据\n\n"
				tableData := [][]interface{}{
					{"日期", "数值"},
				}
				for _, point := range data.TrendData {
					tableData = append(tableData, []interface{}{
						point.X,
						point.DisplayValue,
					})
				}
				markdown, err := utils.ConvertArrayToMarkdownTable(tableData)
				if err != nil {
					logs.CtxError(ctx, "ConvertArrayToMarkdownTable failed, err: %v", err)
					continue
				}
				result += markdown + "\n\n"
			}
		}
	}

	// 处理饼图类型结果
	if resp.PieResult_ != nil && len(resp.PieResult_) > 0 {
		result += "## 分布数据\n\n"
		for _, pieData := range resp.PieResult_ {
			if pieData == nil || len(pieData.Value) == 0 {
				continue
			}
			result += fmt.Sprintf("### %s\n\n", pieData.Name)
			tableData := [][]interface{}{
				{"类别", "商品数量", "占比"},
			}
			for _, item := range pieData.Value {
				tableData = append(tableData, []interface{}{
					item.EnumName,
					item.DisplayValue,
					fmt.Sprintf("%.2f%%", item.Percent*100),
				})
			}
			markdown, err := utils.ConvertArrayToMarkdownTable(tableData)
			if err != nil {
				logs.CtxError(ctx, "ConvertArrayToMarkdownTable failed, err: %v", err)
				continue
			}
			result += markdown + "\n\n"
		}
	}

	// 处理趋势类型结果
	if resp.TrendResult_ != nil && len(resp.TrendResult_) > 0 {
		result += "## 趋势分析\n\n"
		for previewType, trendData := range resp.TrendResult_ {
			if len(trendData) == 0 {
				continue
			}
			result += fmt.Sprintf("### %s\n\n", getPreviewTypeTitle(previewType))
			tableData := [][]interface{}{
				{"日期", "数值"},
			}
			for _, point := range trendData {
				tableData = append(tableData, []interface{}{
					point.X,
					point.DisplayValue,
				})
			}
			markdown, err := utils.ConvertArrayToMarkdownTable(tableData)
			if err != nil {
				logs.CtxError(ctx, "ConvertArrayToMarkdownTable failed, err: %v", err)
				continue
			}
			result += markdown + "\n\n"
		}
	}

	logs.CtxInfo(ctx, "formatProductSelectTaskDataToMarkdown end successfully")
	return result, nil
}

// getPreviewTypeTitle 获取预览类型的中文标题
func getPreviewTypeTitle(previewType product_select.TaskPreviewType) string {
	switch previewType {
	case product_select.TaskPreviewType_ProductTotal:
		return "商品总数"
	case product_select.TaskPreviewType_ShopTotal:
		return "店铺总数"
	case product_select.TaskPreviewType_FirstCategoryTotal:
		return "一级类目总数"
	case product_select.TaskPreviewType_LeafCategoryTotal:
		return "叶子类目总数"
	case product_select.TaskPreviewType_BrandTotal:
		return "品牌总数"
	case product_select.TaskPreviewType_OrderTotal:
		return "订单总数"
	case product_select.TaskPreviewType_BrandLevelDistribution:
		return "品牌等级分布"
	case product_select.TaskPreviewType_ShopLevelDistribution:
		return "店铺类型分布"
	case product_select.TaskPreviewType_IndustryDistribution:
		return "行业分布"
	case product_select.TaskPreviewType_OPGroupDistribution:
		return "运营分组分布"
	default:
		return fmt.Sprintf("预览类型%d", previewType)
	}
}
