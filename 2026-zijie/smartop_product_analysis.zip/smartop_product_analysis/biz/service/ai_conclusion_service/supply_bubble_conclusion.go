package ai_conclusion_service

import (
	"context"
	"errors"
	"fmt"

	"code.byted.org/gopkg/logs"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"github.com/jinzhu/copier"
)

// SupplyBubbleConclusion 气泡图AI分析数据
func (d *DynamicGetData) SupplyBubbleConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (string, error) {
	logs.CtxInfo(ctx, "[DynamicGetData] SupplyBubbleConclusion req=%+v", req)
	_req := &common_request.CommonAnalysisRequest{}
	err := copier.Copy(_req, req)
	if err != nil {
		return "", err
	}

	resp, err := d.ProductReviewService.GetBubbleChart(ctx, _req)

	if err != nil || resp == nil {
		return "", err
	}

	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	var targetMetaList []*dimensions.TargetMetaInfo
	if req.BaseReq != nil {
		targetMetaList, err = d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
		if err != nil {
			return "", err
		}
	}

	// 筛选项格式化
	baseReqStr := utils.ConvertBaseReqToMarkdown(req.BaseReq, bizInfoList, dimMap, targetMetaList)
	// 气泡图配置格式化
	bubbleStr := utils.ConvertSupplyBubbleConfToMarkdown(req.BizExtraInfo.ProdReviewParams.BubbleChartParams, bizInfoList, dimMap, targetMetaList)

	if resp.KeyValueList == nil || len(resp.KeyValueList) == 0 {
		return "", errors.New("no data found")
	}
	resRows := make([][]string, 0)
	// 标题行
	firstRec := resp.KeyValueList[0]
	titleRow := []string{"下钻维度", firstRec["x_display_name"], firstRec["y_display_name"], firstRec["z_display_name"]}

	resRows = append(resRows, titleRow)

	// 指标行
	for _, targetData := range resp.KeyValueList {
		name := targetData["drill_dimension_name"]
		xValue := fmt.Sprintf("%s (%s)", targetData["x"], targetData["x_display_value"])
		yValue := fmt.Sprintf("%s (%s)", targetData["y"], targetData["y_display_value"])
		zValue := fmt.Sprintf("%s (%s)", targetData["z"], targetData["z_display_value"])
		targetRows := []string{name, xValue, yValue, zValue}
		resRows = append(resRows, targetRows)
	}

	divider := req.BizExtraInfo.ProdReviewParams.BubbleChartParams.AxisSegmentation.String()
	xAxisValue := resp.ExtraInfo.BubbleChartInfo.XAxisTargetValue
	yAxisValue := resp.ExtraInfo.BubbleChartInfo.YAxisTargetValue
	divideStr := fmt.Sprintf("象限划分依据：%s\n,X轴数值：%s\n，Y轴数值：%s\n", divider, xAxisValue, yAxisValue)

	// 转化为Markdown表格
	markdownTable, _ := utils.ConvertStringArrayToMarkdownTable(resRows)

	// 汇总数据
	return fmt.Sprintf("# 筛选条件\n\n%s\n\n## 分析配置\n\n%s\n\n## 象限划分\n\n%s\n\n##分析数据 \n\n%s\n\n", baseReqStr, bubbleStr, divideStr, markdownTable), nil
}
