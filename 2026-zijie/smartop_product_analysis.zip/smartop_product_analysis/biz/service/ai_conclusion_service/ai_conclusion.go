package ai_conclusion_service

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"reflect"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/flow/eino-byted-ext/components/prompt/prompthub"
	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino-ext/components/model/ark"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/schema"
	"github.com/volcengine/volcengine-go-sdk/service/arkruntime/model"
)

// Node Key
const (
	AIConclusionTemplateNodeKey = "ai_conclusion_template"
	AIConclusionModelNodeKey    = "ai_conclusion_model"
)

func (d *AIConclusion) GetDataByMethod(ctx context.Context, funcName string, req *ai_analysis.AIConclusionRequest, aiConclusionConfig *dao.AIConclusion) (string, error) {
	if method, hasMethod := reflect.TypeOf(d.DynamicGetData).MethodByName(funcName); hasMethod &&
		method.Type.NumOut() == 2 && method.Type.NumIn() == 4 {
		methodParams := []reflect.Value{reflect.ValueOf(d.DynamicGetData), reflect.ValueOf(ctx), reflect.ValueOf(req), reflect.ValueOf(aiConclusionConfig)}
		results := method.Func.Call(methodParams)

		if len(results) == 2 {
			// 检查错误
			if err, errOk := results[1].Interface().(error); errOk && err != nil {
				logs.CtxError(ctx, "interface to error Fail, err=%v+", err)
				return "", err
			}

			// 获取数据
			if data, ok := results[0].Interface().(string); ok && len(data) > 0 {
				return data, nil
			}
		}
	} else {
		logs.CtxWarn(ctx, "[GetDataByMethod]DynamicGetData DynamicFuncName Fail, name=%s", funcName)
	}

	return "", nil
}

func (d *AIConclusion) AIConclusion(ctx context.Context, req *ai_analysis.AIConclusionRequest, stream *ai_analysis_service.StreamServer) (string, error) {
	logs.CtxInfo(ctx, "AI Conclusion Request %+v", req)
	// 获取用户信息，PS：agw流式协议转换之后无法从ctx中获取用户信息
	user, err := utils.GetEcopUserByEmployeeId(ctx, req.EmployeeId)
	if err != nil {
		logs.CtxError(ctx, "[AIConclusion] GetEcopUserByEmployeeId failed, err=%v", err)
		return "", err
	}

	// 注入userInfo到ctx
	ctx = context.WithValue(ctx, consts.CtxUserInfo, user)

	// 获取fornax client
	fornaxClient := fornax.GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[AIConclusion] GetFornaxClient failed")
		return "", fmt.Errorf("get fornax client failed")
	}

	// 获取方舟配置
	arkConfig, err := biz_info.GetArkConfig(ctx)
	if err != nil || arkConfig == nil {
		logs.CtxError(ctx, "[AIConclusion] GetArkConfig failed, err=%v", err)
		return "", err
	}

	// 获取ai配置
	aiConfig, err := biz_info.GetArtificialIntelligenceConfig(ctx)
	if err != nil || aiConfig == nil {
		logs.CtxError(ctx, "[AIConclusion] GetArtificialIntelligenceConfig failed, err=%v", err)
		return "", err
	}

	// 根据id获取模块配置
	aiConclusionConfig, err := d.AIConclusionDao.GetAIConclusionById(ctx, int64(req.Id))
	if err != nil || aiConclusionConfig == nil {
		logs.CtxError(ctx, "[AIConclusion] GetAIConclusion failed, err=%v", err)
		return "", err
	}

	// 读取Prompt变量配置
	promptVariable := &ai_analysis.PromptVariables{}
	if aiConclusionConfig.PromptVariables != nil && len(*aiConclusionConfig.PromptVariables) > 0 {
		err = json.Unmarshal([]byte(*aiConclusionConfig.PromptVariables), promptVariable)
		if err != nil {
			logs.CtxError(ctx, "[AIConclusion] Unmarshal PromptVariables failed, err=%v", err)
			return "", err
		}
	}

	// 通过反射机制获取数据
	data, err := d.GetDataByMethod(ctx, aiConclusionConfig.GetDataFunction, req, aiConclusionConfig)
	if err != nil {
		logs.CtxError(ctx, "[AIConclusion] GetDataByMethod failed, err=%v", err)
		return "", err
	}

	g := compose.NewGraph[map[string]any, *schema.Message]()

	template, err := prompthub.NewPromptHub(ctx, &prompthub.Config{
		Key:          aiConclusionConfig.PromptKey,
		FornaxClient: fornaxClient,
	})
	if err != nil {
		logs.CtxError(ctx, "[AIConclusion] NewPromptHub failed, err=%v", err)
		return "", err
	}

	temp := float32(0)
	maxToken := int(8192)
	modelKey := "doubao-seed-1.6" // 默认使用豆包1.6的模型
	if aiConfig.Model != nil && len(aiConfig.Model["conclusion_model"]) > 0 {
		modelKey = aiConfig.Model["conclusion_model"]
	}
	model, err := ark.NewChatModel(ctx, &ark.ChatModelConfig{
		APIKey:      arkConfig.ApiKey,
		Model:       arkConfig.Endpoint[modelKey],
		MaxTokens:   &maxToken,
		Temperature: &temp,
		Thinking: &model.Thinking{
			Type: model.ThinkingTypeDisabled, // 禁用思考
		},
	})
	if err != nil {
		logs.CtxError(ctx, "[AIConclusion] NewChatModel failed, err=%v", err)
		return "", err
	}

	// 添加节点和边
	if err = g.AddChatTemplateNode(AIConclusionTemplateNodeKey, template, compose.WithNodeName(AIConclusionTemplateNodeKey)); err != nil {
		logs.CtxError(ctx, "[AIConclusion] AddChatTemplateNode failed, err=%v", err)
		return "", err
	}
	if err = g.AddChatModelNode(AIConclusionModelNodeKey, model, compose.WithNodeName(AIConclusionModelNodeKey)); err != nil {
		logs.CtxError(ctx, "[AIConclusion] AddChatModelNode failed, err=%v", err)
		return "", err
	}
	if err = g.AddEdge(compose.START, AIConclusionTemplateNodeKey); err != nil {
		logs.CtxError(ctx, "[AIConclusion] AddEdge failed, err=%v", err)
		return "", err
	}
	if err = g.AddEdge(AIConclusionTemplateNodeKey, AIConclusionModelNodeKey); err != nil {
		logs.CtxError(ctx, "[AIConclusion] AddEdge failed, err=%v", err)
		return "", err
	}
	if err = g.AddEdge(AIConclusionModelNodeKey, compose.END); err != nil {
		logs.CtxError(ctx, "[AIConclusion] AddEdge failed, err=%v", err)
		return "", err
	}

	// 注入tag到fornax trace
	ctx = fornax.InjectFornaxTrace(ctx, user, "", "")

	// 编译 graph
	r, err := g.Compile(ctx, compose.WithGraphName("ai_conclusion"), compose.WithNodeTriggerMode(compose.AnyPredecessor))
	if err != nil {
		logs.CtxError(ctx, "[AIConclusion] compile graph failed, err=%v", err)
		return "", err
	}

	input := map[string]any{
		"chat_history": []*schema.Message{
			schema.UserMessage(fmt.Sprintf("针对以下数据输出诊断结论。\n\n%s", data)),
		},
	}
	// 将promptVariables合并到input中
	if len(*promptVariable) > 0 {
		for k, v := range *promptVariable {
			input[k] = v
		}
	}

	// 执行 graph
	sr, err := r.Stream(ctx, input)
	if err != nil {
		logs.CtxError(ctx, "[AIConclusion] stream graph failed, err=%v", err)
		return "", err
	}

	defer sr.Close() // remember to close the stream

	// 处理 stream
	chunks := make([]*schema.Message, 0)
	for {
		var chunk *schema.Message
		chunk, err = sr.Recv()
		if errors.Is(err, io.EOF) {
			logs.CtxInfo(ctx, "[AIConclusion] Stream Recv finished")
			break
		}

		if err != nil {
			logs.CtxError(ctx, "[AIConclusion] Stream Recv failed, err=%v", err)
			return "", err
		}

		var s []byte
		s, err = json.Marshal(chunk)
		if err != nil {
			logs.CtxError(ctx, "[AIConclusion] json.Marshal message failed, err=%v", err)
			return "", err
		}
		resp := &ai_analysis.AIStreamResponse{
			Event: "message",
			Data:  string(s),
		}
		if stream != nil {
			if err = (*stream).Send(resp); err != nil {
				logs.CtxError(ctx, "[AIConclusion] stream.Send failed: %s", err)
				return "", err
			}
		}
		chunks = append(chunks, chunk)
	}

	// 合并消息
	assistantMsg, err := schema.ConcatMessages(chunks)
	if err != nil {
		logs.CtxError(ctx, "[AIConclusion] ConcatMessages failed, err=%v", err)
		return "", err
	}

	return assistantMsg.Content, nil
}
