package ai_conclusion_service

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/module_name"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"

	"code.byted.org/gopkg/logs"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"code.byted.org/temai/go_lib/convert"
	"github.com/jinzhu/copier"
)

func processItemList(rows []*common_response.ItemData, maxDepth int, currDepth int) (items map[string][][]string) {
	if len(rows) == 0 || currDepth > maxDepth {
		return
	}
	items = make(map[string][][]string)
	for _, row := range rows {
		item := make([]string, 0)
		// 添加指标值
		if len(row.TargetList) > 0 {
			for _, target := range row.TargetList {
				item = append(item, fmt.Sprintf("%s（%s）", convert.ToString(target.Value), target.DisplayValue))
			}
		}
		if len(items[row.ItemName]) == 0 {
			items[row.ItemName] = make([][]string, 0)
		}
		items[row.ItemName] = append(items[row.ItemName], item)

		// 递归处理子行
		if len(row.Children) > 0 {
			childItems := processItemList(row.Children, maxDepth, currDepth+1)
			for key, value := range childItems {
				if items[key] == nil {
					items[key] = make([][]string, 0)
				}
				items[key] = append(items[key], value...)
			}
		}
	}
	return items
}
func processFourQuadrantCategoryItemList(rows []*common_response.ItemData, maxDepth int, currDepth int) (items map[string][][]string) {
	if len(rows) == 0 || currDepth > maxDepth {
		return
	}
	items = make(map[string][][]string)
	for _, row := range rows {
		item := make([]string, 0)
		// 添加指标值
		if row.ExtraInfo != nil && row.ExtraInfo.QuadrantInfo != nil && len(row.ExtraInfo.QuadrantInfo.MainCategoryName) > 0 {
			item = append(item, fmt.Sprintf("核心类目 ：（%s）", strings.Join(row.ExtraInfo.QuadrantInfo.MainCategoryName, "、")))
		}
		if len(items[row.ItemName]) == 0 {
			items[row.ItemName] = make([][]string, 0)
		}
		items[row.ItemName] = append(items[row.ItemName], item)

		// 递归处理子行
		if len(row.Children) > 0 {
			childItems := processItemList(row.Children, maxDepth, currDepth+1)
			for key, value := range childItems {
				if items[key] == nil {
					items[key] = make([][]string, 0)
				}
				items[key] = append(items[key], value...)
			}
		}
	}
	return items
}

/** 处理多维分析行数据，将其转换为二维字符串数组，分别返回当前货盘分析周期值，当前货盘对比周期值，对比货盘分析周期值，对比货盘对比周期值 */
func processMultiDimsRows(rows []*common_response.RowData, maxDepth int, parentDims []string, currDepth int) (
	prodAnalysisRows [][]string, prodCompareRows [][]string, compareProdAnalysisRows [][]string, compareProdCompareRows [][]string,
	prodABIncreaseAnalysisRows [][]string, compareProdABIncreaseAnalysisRows [][]string) {
	if currDepth > maxDepth {
		return
	}
	for _, row := range rows {
		// 添加维度名称
		currentDims := append(parentDims, row.DimensionName)

		// 创建填充后的维度数组
		paddedDims := make([]string, maxDepth)
		copy(paddedDims, currentDims)
		for i := len(currentDims); i < maxDepth; i++ {
			paddedDims[i] = "-"
		}

		prodAnalysisRow := make([]string, 0)
		prodCompareRow := make([]string, 0)
		compareProdAnalysisRow := make([]string, 0)
		compareProdCompareRow := make([]string, 0)

		// 添加填充后的维度
		prodAnalysisRow = append(prodAnalysisRow, paddedDims...)
		prodCompareRow = append(prodCompareRow, paddedDims...)
		compareProdAnalysisRow = append(compareProdAnalysisRow, paddedDims...)
		compareProdCompareRow = append(compareProdCompareRow, paddedDims...)

		// AB数据
		prodABIncreaseAnalysisRow := make([]string, 0)
		compareProdABIncreaseAnalysisRow := make([]string, 0)
		// 添加AB数据填充后的维度
		prodABIncreaseAnalysisRow = append(prodABIncreaseAnalysisRow, paddedDims...)
		compareProdABIncreaseAnalysisRow = append(compareProdABIncreaseAnalysisRow, paddedDims...)

		// 添加指标值
		if len(row.TargetList) > 0 {
			for _, target := range row.TargetList {
				// 当前货盘
				prodAnalysisRow = append(prodAnalysisRow, fmt.Sprintf("%s（%s）", convert.ToString(target.Value), target.DisplayValue))
				if target.ComparePeriodData != nil {
					prodCompareRow = append(prodCompareRow, fmt.Sprintf("%s（%s）", convert.ToString(target.ComparePeriodData.CompareValue), target.ComparePeriodData.CompareDisplayValue))
				}
				//else {
				//	prodCompareRow = append(prodCompareRow, "-")
				//}
				// AB数据
				if len(target.AbExpData) != 0 && target.AbExpData[0] != nil {
					prodABIncreaseAnalysisRow = append(prodABIncreaseAnalysisRow, fmt.Sprintf("%s（%s）", convert.ToString(target.AbExpData[0].AbDiff), target.AbExpData[0].AbDiffDisplayValue))
				}
				//else {
				//	prodABIncreaseAnalysisRow = append(prodABIncreaseAnalysisRow, "-")
				//}

				if target.CompareProdPoolData != nil && target.CompareProdPoolData.Target != nil {
					// 对比货盘
					compareProdAnalysisRow = append(compareProdAnalysisRow, fmt.Sprintf("%s（%s）", convert.ToString(target.CompareProdPoolData.Target.Value), target.CompareProdPoolData.Target.DisplayValue))
					if target.CompareProdPoolData.Target.ComparePeriodData != nil {
						compareProdCompareRow = append(compareProdCompareRow, fmt.Sprintf("%s（%s）", convert.ToString(target.CompareProdPoolData.Target.ComparePeriodData.CompareValue), target.CompareProdPoolData.Target.ComparePeriodData.CompareDisplayValue))
					}
					//else {
					//	compareProdCompareRow = append(compareProdCompareRow, "-")
					//}
					// AB数据
					if len(target.CompareProdPoolData.Target.AbExpData) != 0 && target.CompareProdPoolData.Target.AbExpData[0] != nil {
						compareProdABIncreaseAnalysisRow = append(compareProdABIncreaseAnalysisRow, fmt.Sprintf("%s（%s）", convert.ToString(target.CompareProdPoolData.Target.AbExpData[0].AbDiff), target.CompareProdPoolData.Target.AbExpData[0].AbDiffDisplayValue))
					}
					//else {
					//	compareProdABIncreaseAnalysisRow = append(compareProdABIncreaseAnalysisRow, "-")
					//}
				}
				//else {
				//	compareProdAnalysisRow = append(compareProdAnalysisRow, "-")
				//	compareProdCompareRow = append(compareProdCompareRow, "-")
				//	compareProdABIncreaseAnalysisRow = append(compareProdABIncreaseAnalysisRow, "-")
				//}
			}
		}

		prodAnalysisRows = append(prodAnalysisRows, prodAnalysisRow)
		prodCompareRows = append(prodCompareRows, prodCompareRow)
		compareProdAnalysisRows = append(compareProdAnalysisRows, compareProdAnalysisRow)
		compareProdCompareRows = append(compareProdCompareRows, compareProdCompareRow)

		prodABIncreaseAnalysisRows = append(prodABIncreaseAnalysisRows, prodABIncreaseAnalysisRow)
		compareProdABIncreaseAnalysisRows = append(compareProdABIncreaseAnalysisRows, compareProdABIncreaseAnalysisRow)

		// 递归处理子行
		if len(row.ChildrenRows) > 0 {
			childProdAnalysisRows, childProdCompareRows, childCompareProdAnalysisRows, childCompareProdCompareRows,
				childProdABIncreaseAnalysisRows, childCompareProdABIncreaseAnalysisRows := processMultiDimsRows(row.ChildrenRows, maxDepth, currentDims, currDepth+1)
			prodAnalysisRows = append(prodAnalysisRows, childProdAnalysisRows...)
			prodCompareRows = append(prodCompareRows, childProdCompareRows...)
			compareProdAnalysisRows = append(compareProdAnalysisRows, childCompareProdAnalysisRows...)
			compareProdCompareRows = append(compareProdCompareRows, childCompareProdCompareRows...)
			prodABIncreaseAnalysisRows = append(prodABIncreaseAnalysisRows, childProdABIncreaseAnalysisRows...)
			compareProdABIncreaseAnalysisRows = append(compareProdABIncreaseAnalysisRows, childCompareProdABIncreaseAnalysisRows...)
		}
	}

	return prodAnalysisRows, prodCompareRows, compareProdAnalysisRows, compareProdCompareRows,
		prodABIncreaseAnalysisRows, compareProdABIncreaseAnalysisRows
}

/** 处理目标分析行数据，将其转换为二维字符串数组 */
func processTargetRows(rows []*common_response.TargetRowData, maxDepth int, parentDims []string, targetName *string) (resRows [][]string) {
	for _, row := range rows {
		currentDims := parentDims
		if targetName == nil {
			// records下面的元素，为子表名称
			target := fmt.Sprintf("%s（%s）", row.Name, row.Code)
			targetName = &target
		} else {
			// 其余子元素，为维度名称
			currentDims = append(currentDims, row.Name)
		}

		// 创建填充后的维度数组
		paddedDims := make([]string, maxDepth)
		copy(paddedDims, currentDims)
		for i := len(currentDims); i < maxDepth; i++ {
			paddedDims[i] = "-"
		}

		resRow := make([]string, 0)
		if targetName != nil {
			resRow = append(resRow, *targetName)
		} else {
			resRow = append(resRow, "-")
		}

		// 添加维度
		resRow = append(resRow, paddedDims...)

		if len(row.IndexList) > 0 {
			for i, subTarget := range row.IndexList {
				// 周期表现（前后值+AA对比）、MTD表现（前后值+AA对比）、MTD完成度（前后值）、MTD目标值（前后值）
				resRow = append(resRow, fmt.Sprintf("%s（%s）", convert.ToString(subTarget.Value), subTarget.DisplayValue))
				if subTarget.ComparePeriodData != nil {
					resRow = append(resRow, fmt.Sprintf("%s（%s）", convert.ToString(subTarget.ComparePeriodData.CompareValue), subTarget.ComparePeriodData.CompareDisplayValue))
				} else {
					resRow = append(resRow, "-")
				}

				if i <= 1 {
					// 周期表现（前后值+AA对比）、MTD表现（前后值+AA对比）需要添加compare_change_ratio的字段
					if subTarget.ComparePeriodData != nil {
						changeRatio := strconv.FormatFloat(subTarget.ComparePeriodData.CompareChangeRatio, 'f', 5, 64)
						if subTarget.ComparePeriodData.CompareChangeRatio == consts.MagicNumber {
							// 处理特殊值
							changeRatio = "-"
						}
						resRow = append(resRow, changeRatio)
					} else {
						resRow = append(resRow, "-")
					}
				}
			}
		}

		resRows = append(resRows, resRow)

		// 递归处理子行
		if len(row.ChildrenTarget) > 0 {
			childResRows := processTargetRows(row.ChildrenTarget, maxDepth, currentDims, targetName)
			resRows = append(resRows, childResRows...)
		}
	}

	return resRows
}

// 目标分析结论
func (d *DynamicGetData) TargetAnalysisConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (string, error) {
	_req := &common_request.CommonAnalysisRequest{}
	err := copier.Copy(_req, req)
	if err != nil {
		return "", err
	}

	resp := d.ProductReviewService.ICommonAnalysisTargetTable(ctx, _req)
	if resp == nil || len(resp.Data) == 0 {
		return "", errors.New(resp.Msg)
	}

	resRows := make([][]string, 0)
	maxDepth := 0

	// 标题行
	titleRow := []string{"指标"}
	if req.BaseReq != nil && len(req.BaseReq.GroupAttrs) > 0 {
		maxDepth = len(req.BaseReq.GroupAttrs)
		for i, dim := range req.BaseReq.GroupAttrs {
			if dim != nil && dim.DimInfo != nil {
				titleRow = append(titleRow, dim.DimInfo.Name)
			} else {
				titleRow = append(titleRow, fmt.Sprintf("维度%d", i+1))
			}
		}
	}
	titleRow = append(titleRow, "当前周期值", "对比周期值", "环比", "本月MTD", "上月MTD", "MTD月环比", "本月目标完成度", "上月目标完成度", "本月目标", "上月目标")
	resRows = append(resRows, titleRow)

	// 指标行
	for _, targetData := range resp.Data {
		if len(targetData.Records) > 0 {
			targetRows := processTargetRows(targetData.Records, maxDepth, []string{}, nil)
			resRows = append(resRows, targetRows...)
		}
	}

	// 转化为Markdown表格
	markdownTable, _ := utils.ConvertStringArrayToMarkdownTable(resRows)

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	var targetMetaList []*dimensions.TargetMetaInfo
	if req.BaseReq != nil {
		targetMetaList, err = d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
		if err != nil {
			return "", err
		}
	}

	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 筛选项格式化
	baseReqStr := utils.ConvertBaseReqToMarkdown(req.BaseReq, bizInfoList, dimMap, targetMetaList)

	// 汇总数据
	return fmt.Sprintf("## 筛选条件\n\n%s\n\n## 指标数据\n\n%s\n\n", baseReqStr, markdownTable), nil
}

// 经分实验- 多维分析结论
func (d *DynamicGetData) LibraMetricMultiAnalysisConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (string, error) {
	logs.CtxInfo(ctx, "[DynamicGetData] LibraMetricMultiAnalysisConclusion req=%+v", req)
	_req := &common_request.CommonAnalysisRequest{}
	err := copier.Copy(_req, req)
	if err != nil {
		return "", err
	}

	resp, _, err := d.MultiDimTableService.ICommonAnalysisMultiDimTable(ctx, _req)
	if err != nil || resp == nil {
		return "", err
	}

	prodAnalysisRows := make([][]string, 0)
	prodABIncreaseAnalysisRows := make([][]string, 0)

	maxDepth := 2

	// 标题行
	titleRow := make([]string, 0)
	titleRow = append(titleRow, []string{"实验组", "实验"}...)
	maxDepth = min(maxDepth, 2)

	// 处理维度数据
	if len(resp.Rows) > 0 {
		prodDimRows, _, _, _, prodABIncreaseDimRows, _ := processMultiDimsRows(resp.Rows, maxDepth, []string{}, 1)
		prodAnalysisRows = append(prodAnalysisRows, prodDimRows...)
		prodABIncreaseAnalysisRows = append(prodABIncreaseAnalysisRows, prodABIncreaseDimRows...)
	}

	prodAnalysisTable, _ := utils.ConvertStringArrayToMarkdownTable(prodAnalysisRows)
	prodABIncreaseAnalysisTable, _ := utils.ConvertStringArrayToMarkdownTable(prodABIncreaseAnalysisRows)

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	var targetMetaList []*dimensions.TargetMetaInfo
	if req.BaseReq != nil {
		targetMetaList, err = d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
		if err != nil {
			return "", err
		}
	}

	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 筛选项格式化
	baseReqStr := utils.ConvertBaseReqToMarkdown(req.BaseReq, bizInfoList, dimMap, targetMetaList)
	//compareReqStr := utils.ConvertBaseReqToMarkdown(req.CompareReq, bizInfoList, dimMap, targetMetaList)

	// 汇总数据
	return fmt.Sprintf("# 分析货盘\n\n## 筛选条件\n\n%s\n\n## 实验数据\n\n%s\n\n## 增量实验数据\n\n%s\n\n##",
		baseReqStr, prodAnalysisTable, prodABIncreaseAnalysisTable), nil
}

// 多维分析结论
func (d *DynamicGetData) MultiAnalysisConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (string, error) {
	logs.CtxInfo(ctx, "[DynamicGetData] MultiAnalysisConclusion req=%+v", req)
	_req := &common_request.CommonAnalysisRequest{}
	err := copier.Copy(_req, req)
	if err != nil {
		return "", err
	}

	resp, _, err := d.MultiDimTableService.ICommonAnalysisMultiDimTable(ctx, _req)
	if err != nil || resp == nil {
		return "", err
	}

	prodAnalysisRows := make([][]string, 0)
	prodCompareRows := make([][]string, 0)
	compareProdAnalysisRows := make([][]string, 0)
	compareProdCompareRows := make([][]string, 0)

	prodABIncreaseAnalysisRows := make([][]string, 0)
	compareProdABIncreaseAnalysisRows := make([][]string, 0)

	maxDepth := 0

	// 标题行
	titleRow := make([]string, 0)
	if req.BaseReq != nil && len(req.BaseReq.GroupAttrs) > 0 {
		maxDepth = len(req.BaseReq.GroupAttrs)
		for i, dim := range req.BaseReq.GroupAttrs {
			if dim != nil && dim.DimInfo != nil {
				titleRow = append(titleRow, dim.DimInfo.Name)
			} else {
				titleRow = append(titleRow, fmt.Sprintf("维度%d", i+1))
			}
		}
	}
	// 添加层数限制
	maxDepth = min(maxDepth, 1)
	//
	if req.BizExtraInfo != nil && req.BizExtraInfo.ProdReviewParams != nil {
		if req.BizExtraInfo.ProdReviewParams.FlowDistributionParams != nil {
			dimInfo, err := d.DimensionListDao.GetDimensionById(ctx, convert.ToInt64(req.BizExtraInfo.ProdReviewParams.FlowDistributionParams.DrillDimensionId))
			if err != nil || dimInfo == nil {
				return "", err
			}
			titleRow = append(titleRow, dimInfo.ShowName)
			maxDepth++
		}
		if req.BizExtraInfo.ProdReviewParams.ModuleName == prod_review.ModuleName_SpecialItemContributionAnalysis {
			maxDepth++
		}
	}

	// 处理整体数据
	if resp.Total != nil {
		// 补充标题行指标部分
		if len(resp.Total.TargetList) > 0 {
			for _, target := range resp.Total.TargetList {
				titleRow = append(titleRow, fmt.Sprintf("%s（%s）", target.DisplayName, target.Name))
			}
		}
		prodAnalysisRows = append(prodAnalysisRows, titleRow)
		prodCompareRows = append(prodCompareRows, titleRow)
		if req.CompareReq != nil {
			compareProdAnalysisRows = append(compareProdAnalysisRows, titleRow)
			compareProdCompareRows = append(compareProdCompareRows, titleRow)
		}

		prodTotalRows, prodCompareTotalRows, compareProdTotalRows, compareProdCompareTotalRows,
			prodABIncreaseDimRows, compareProdABIncreaseDimRows := processMultiDimsRows([]*common_response.RowData{resp.Total}, maxDepth, []string{}, 1)
		prodAnalysisRows = append(prodAnalysisRows, prodTotalRows...)
		prodCompareRows = append(prodCompareRows, prodCompareTotalRows...)
		if req.CompareReq != nil {
			compareProdAnalysisRows = append(compareProdAnalysisRows, compareProdTotalRows...)
			compareProdCompareRows = append(compareProdCompareRows, compareProdCompareTotalRows...)
		}

		prodABIncreaseAnalysisRows = append(prodABIncreaseAnalysisRows, prodABIncreaseDimRows...)
		if req.CompareReq != nil {
			compareProdABIncreaseAnalysisRows = append(compareProdABIncreaseAnalysisRows, compareProdABIncreaseDimRows...)
		}
	}

	// 处理维度数据
	if len(resp.Rows) > 0 {
		prodDimRows, prodCompareDimRows, compareProdDimRows, compareProdCompareDimRows,
			prodABIncreaseDimRows, compareProdABIncreaseDimRows := processMultiDimsRows(resp.Rows, maxDepth, []string{}, 1)
		prodAnalysisRows = append(prodAnalysisRows, prodDimRows...)
		prodCompareRows = append(prodCompareRows, prodCompareDimRows...)
		if req.CompareReq != nil {
			compareProdAnalysisRows = append(compareProdAnalysisRows, compareProdDimRows...)
			compareProdCompareRows = append(compareProdCompareRows, compareProdCompareDimRows...)
		}

		prodABIncreaseAnalysisRows = append(prodABIncreaseAnalysisRows, prodABIncreaseDimRows...)
		if req.CompareReq != nil {
			compareProdABIncreaseAnalysisRows = append(compareProdABIncreaseAnalysisRows, compareProdABIncreaseDimRows...)
		}
	}

	prodAnalysisTable, _ := utils.ConvertStringArrayToMarkdownTable(prodAnalysisRows)
	prodCompareTable, _ := utils.ConvertStringArrayToMarkdownTable(prodCompareRows)

	compareProdAnalysisTable, _ := utils.ConvertStringArrayToMarkdownTable(compareProdAnalysisRows)
	compareProdCompareTable, _ := utils.ConvertStringArrayToMarkdownTable(compareProdCompareRows)

	prodABIncreaseAnalysisTable, _ := utils.ConvertStringArrayToMarkdownTable(prodABIncreaseAnalysisRows)
	compareProdABIncreaseAnalysisTable, _ := utils.ConvertStringArrayToMarkdownTable(compareProdABIncreaseAnalysisRows)

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	var targetMetaList []*dimensions.TargetMetaInfo
	if req.BaseReq != nil {
		targetMetaList, err = d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
		if err != nil {
			return "", err
		}
	}

	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 筛选项格式化
	baseReqStr := utils.ConvertBaseReqToMarkdown(req.BaseReq, bizInfoList, dimMap, targetMetaList)
	compareReqStr := utils.ConvertBaseReqToMarkdown(req.CompareReq, bizInfoList, dimMap, targetMetaList)

	// 汇总数据
	return fmt.Sprintf("# 分析货盘\n\n## 筛选条件\n\n%s\n\n## 分析周期数据\n\n%s\n\n## 分析货盘AB增量数据\n\n%s\n\n## 对比周期数据\n\n%s\n\n# 对比货盘\n\n## 筛选条件\n\n%s\n\n## 分析周期数据\n\n%s\n\n## 对比货盘AB数据\n\n%s\n\n## 对比周期数据\n\n%s\n\n",
		baseReqStr, prodAnalysisTable, prodABIncreaseAnalysisTable, prodCompareTable, compareReqStr, compareProdAnalysisTable, compareProdABIncreaseAnalysisTable, compareProdCompareTable), nil
}

// 多维分析结论
func (d *DynamicGetData) FourQuadrantConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (string, error) {
	logs.CtxInfo(ctx, "[DynamicGetData] FourQuadrantConclusion req=%+v", req)
	_req := &common_request.CommonAnalysisRequest{}
	err := copier.Copy(_req, req)
	if err != nil {
		return "", err
	}

	resp, err := d.ProductReviewService.ProductFourQuadrantAnalysis(ctx, _req)
	if err != nil || resp == nil {
		return "", err
	}
	// 标题行
	titleRow := make([]string, 0)
	firstQuadrantData := make([][]string, 0)
	secondQuadrantData := make([][]string, 0)
	thirdQuadrantData := make([][]string, 0)
	fourthQuadrantData := make([][]string, 0)

	// 标题行

	// 处理整体数据
	if len(resp.ItemDataList) > 0 {
		// 补充标题行指标部分
		if len(resp.ItemDataList[0].TargetList) > 0 {
			for _, target := range resp.ItemDataList[0].TargetList {
				titleRow = append(titleRow, fmt.Sprintf("%s（%s）", target.DisplayName, target.Name))
			}
		}
		firstQuadrantData = append(firstQuadrantData, titleRow)
		secondQuadrantData = append(secondQuadrantData, titleRow)
		thirdQuadrantData = append(thirdQuadrantData, titleRow)
		fourthQuadrantData = append(fourthQuadrantData, titleRow)

		QuadrantData := processItemList(resp.ItemDataList, 10, 0)
		CategoryData := processFourQuadrantCategoryItemList(resp.ItemDataList, 10, 0)
		firstQuadrantData = append(firstQuadrantData, QuadrantData["first_quadrant"]...)
		firstQuadrantData = append(firstQuadrantData, CategoryData["first_quadrant"]...)
		secondQuadrantData = append(secondQuadrantData, QuadrantData["second_quadrant"]...)
		secondQuadrantData = append(secondQuadrantData, CategoryData["second_quadrant"]...)
		thirdQuadrantData = append(thirdQuadrantData, QuadrantData["third_quadrant"]...)
		thirdQuadrantData = append(thirdQuadrantData, CategoryData["third_quadrant"]...)
		fourthQuadrantData = append(fourthQuadrantData, QuadrantData["fourth_quadrant"]...)
		fourthQuadrantData = append(fourthQuadrantData, CategoryData["fourth_quadrant"]...)
	}

	firstQuadrantTable, _ := utils.ConvertStringArrayToMarkdownTable(firstQuadrantData)
	secondQuadrantTable, _ := utils.ConvertStringArrayToMarkdownTable(secondQuadrantData)
	thirdQuadrantTable, _ := utils.ConvertStringArrayToMarkdownTable(thirdQuadrantData)
	fourthQuadrantTable, _ := utils.ConvertStringArrayToMarkdownTable(fourthQuadrantData)

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	var targetMetaList []*dimensions.TargetMetaInfo
	if req.BaseReq != nil {
		targetMetaList, err = d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BaseReq.BizType, false)
		if err != nil {
			return "", err
		}
	}

	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 筛选项格式化
	baseReqStr := utils.ConvertBaseReqToMarkdown(req.BaseReq, bizInfoList, dimMap, targetMetaList)
	// 四象限配置格式化
	fourthQuadrantStr := utils.ConvertFourthQuadrantConfToMarkdown(req.BizExtraInfo.ProdReviewParams.QuadrantPartitionParams, bizInfoList, dimMap, targetMetaList)

	// 汇总数据
	return fmt.Sprintf("# 筛选条件\n\n%s\n\n## 四象限分析配置\n\n%s\n\n## 第一象限数据\n\n%s\n\n## 第二象限数据\n\n%s\n\n## 第三象限数据\n\n%s\n\n## 第四象限数据\n\n%s\n\n", baseReqStr, fourthQuadrantStr, firstQuadrantTable, secondQuadrantTable, thirdQuadrantTable, fourthQuadrantTable), nil
}

type ProdReviewExtraConfig struct {
	TargetMetaList []string                                 `json:"target_meta_list"`
	GroupAttrs     []*dimensions.SelectedMultiDimensionInfo `json:"group_attrs,omitempty"`
}

// 取数接口
func (d *DynamicGetData) GetProdReviewConclusionData(ctx context.Context, req *ai_analysis.AIConclusionRequest, aiConclusionConfig *dao.AIConclusion) (string, error) {
	if req == nil || aiConclusionConfig == nil {
		return "", errors.New("invalid request or aiConclusionConfig")
	}

	_req := &common_request.CommonAnalysisRequest{
		Base: req.Base,
	}
	err := json.Unmarshal([]byte(req.ReqJson), _req)
	if err != nil {
		return "", err
	}
	logs.CtxInfo(ctx, "GetProdReviewConclusionData req: %v", _req)
	// 调用 mw.CheckBaseStructStreamParams 校验筛选项参数是否合法（PS: 因为需要兼容流式接口，流式接口无法从ctx中获取用户信息，所以需要调用CheckBaseStructStreamParams方法）
	ok, _, msg, ctx := mw.CheckBaseStructStreamParams(ctx, _req.BaseReq, &req.EmployeeId)
	if !ok {
		return "", fmt.Errorf("[GetProdReviewConclusionData] CheckBaseStructStreamParams failed, err=%s", msg)
	}

	if _req.CompareReq != nil {
		ok, _, msg, ctx = mw.CheckBaseStructStreamParams(ctx, _req.CompareReq, &req.EmployeeId)
		if !ok {
			return "", fmt.Errorf("[GetProdReviewConclusionData] CheckBaseStructStreamParams failed, err=%s", msg)
		}
	}

	// 填充动态指标和维度
	if aiConclusionConfig.ExtraConfig != nil {
		extraConfig := &ProdReviewExtraConfig{}
		err := json.Unmarshal([]byte(*aiConclusionConfig.ExtraConfig), extraConfig)
		if err != nil {
			return "", err
		}

		if len(extraConfig.GroupAttrs) > 0 {
			// 判断维度枚举值是否为空，如果为空则填充默认值
			for _, dim := range extraConfig.GroupAttrs {
				if dim != nil && dim.DimInfo != nil && len(dim.DimInfo.SelectedValues) == 0 {
					dimInfo, _err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(dim.DimInfo.Id))
					if _err != nil {
						continue
					}
					// 将dimInfo的维度枚举值填充到dim.DimInfo.SelectedValues
					dim.DimInfo.SelectedValues = dimInfo.Values
				}
			}
		}

		// 填充指标和维度到请求体
		if _req.BaseReq != nil {
			if len(_req.BaseReq.TargetMetaList) == 0 {
				_req.BaseReq.TargetMetaList = extraConfig.TargetMetaList
			}
			if len(_req.BaseReq.GroupAttrs) == 0 {
				_req.BaseReq.GroupAttrs = extraConfig.GroupAttrs
			}
		}

		if _req.CompareReq != nil {
			if len(_req.CompareReq.TargetMetaList) == 0 {
				_req.CompareReq.TargetMetaList = extraConfig.TargetMetaList
			}
			if len(_req.CompareReq.GroupAttrs) == 0 {
				_req.CompareReq.GroupAttrs = extraConfig.GroupAttrs
			}
		}
	}

	if _req.BizExtraInfo == nil || (_req.BizExtraInfo.ModuleName != module_name.ModuleName_LibraMetricGroupAnalysis && _req.BizExtraInfo.ProdReviewParams == nil) {
		return "", errors.New("prod_review_params is nil")
	}

	switch aiConclusionConfig.AiConclusionId {
	case int64(ai_analysis.AIConclusionModule_ProdReviewAllowanceTarget):
		// 专项-目标分析
		_req.BizExtraInfo.ProdReviewParams.ModuleName = prod_review.ModuleName_AllowanceTarget
		return d.TargetAnalysisConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewAllowanceSupply):
		// 专项-供给分析
		_req.BizExtraInfo.ProdReviewParams.ModuleName = prod_review.ModuleName_AIDiagnosis
		return d.MultiAnalysisConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewSingleStrategySupply):
		// 单一策略-供给分析
		_req.BizExtraInfo.ProdReviewParams.ModuleName = prod_review.ModuleName_SingleStrategyMultiDimAnalysis
		if _req.BizExtraInfo.ProdReviewParams.ExpConfig == nil {
			_req.BizExtraInfo.ProdReviewParams.ExpConfig = &prod_review.ExpConfig{}
		}
		_req.BizExtraInfo.ProdReviewParams.ExpConfig.SummaryType = prod_review.SummaryType_AbsoluteAgg
		_req.BizExtraInfo.ProdReviewParams.ExpConfig.IsAllVersions = true
		return d.MultiAnalysisConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewSingleStrategyMultiDim),
		int64(ai_analysis.AIConclusionModule_ProdReviewAllowanceMultiDim):
		// 人货场洞察
		return d.MultiAnalysisConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewSingleStrategySupplyQuadrant),
		int64(ai_analysis.AIConclusionModule_ProdReviewAllowanceSupplyQuadrant):
		// 供给-四象限
		return d.FourQuadrantConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewSingleStrategySupplyBubble),
		int64(ai_analysis.AIConclusionModule_ProdReviewAllowanceSupplyBubble),
		int64(ai_analysis.AIConclusionModule_ProdReviewSingleStrategyFlowBubble),
		int64(ai_analysis.AIConclusionModule_ProdReviewAllowanceFlowBubble):
		return d.SupplyBubbleConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewSingleStrategyFlowDistribution),
		int64(ai_analysis.AIConclusionModule_ProdReviewAllowanceFlowDistribution):
		// 流量-分布
		return d.MultiAnalysisConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewSpecialItemContribution):
		// 专项-贡献度分析
		return d.MultiAnalysisConclusion(ctx, _req)

	case int64(ai_analysis.AIConclusionModule_ProdReviewSingleStrategyFunnel),
		int64(ai_analysis.AIConclusionModule_ProdReviewSpecialItemFunnel):
		// 单一策略-漏斗下钻
		return d.FunnelAnalysisConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewSingleStrategyProdClassify):
		// 价值分类
		return d.ValueClassifyConclusion(ctx, _req)
	case int64(ai_analysis.AIConclusionModule_ProdReviewLibraMetricGroupAnalysis):
		// 货盘复盘 - 经分实验
		return d.LibraMetricMultiAnalysisConclusion(ctx, _req)
	default:
		return "", errors.New("unknown ai_conclusion_id")
	}
}
