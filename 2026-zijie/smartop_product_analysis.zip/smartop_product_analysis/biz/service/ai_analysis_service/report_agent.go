package ai_analysis_service

import (
	"context"
	"fmt"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/agent/supervisor"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	ai_analysis_tools "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/flow/eino-byted-ext/components/prompt/prompthub"
	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino-ext/components/model/ark"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"
	"github.com/cloudwego/eino/schema"
	"github.com/volcengine/volcengine-go-sdk/service/arkruntime/model"
)

func (d *AIAnalysisService) addReportAgent(ctx context.Context, bizType dimensions.BizType, arkConfig *ai_analysis.ArkConfig, aiConfig *ai_analysis.ArtificialIntelligenceConfig) (*compose.Graph[[]*schema.Message, *schema.Message], error) {
	// 获取fornax client
	fornaxClient := fornax.GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[addReportAgent] GetFornaxClient failed")
		return nil, fmt.Errorf("get fornax client failed")
	}

	g := compose.NewGraph[[]*schema.Message, *schema.Message]()

	datasetId, err := getDatasetId(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[addSuggestAgent] GetDatasetId failed, err=%v", err)
		return nil, err
	}

	reportInputLambda := compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (map[string]any, error) {
		output := map[string]any{
			"date":         time.Now().Format(consts.Fmt_Date),
			"chat_history": input,
			"knowledge_id": datasetId,
		}
		_ = compose.ProcessState(ctx, func(ctx context.Context, state *supervisor.State) error {
			output["context"] = state.Context
			return nil
		})

		return output, nil
	})
	reportTemplate, err := prompthub.NewPromptHub(ctx, &prompthub.Config{
		Key:          reportPromptKey,
		FornaxClient: fornaxClient,
	})
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] Init prompt service failed, prompt_key=%s, err=%v", reportPromptKey, err)
		return nil, err
	}

	reportTemperature := float32(0.3)
	reportMaxToken := int(16000)
	reasoningEffort := model.ReasoningEffortMedium
	reportModelKey := defaultReportModel
	if aiConfig != nil && aiConfig.Model != nil && len(aiConfig.Model[reportModelNodeKey]) > 0 {
		reportModelKey = aiConfig.Model[reportModelNodeKey]
	}
	reportModel, err := ark.NewChatModel(ctx, &ark.ChatModelConfig{
		APIKey:      arkConfig.ApiKey,
		Model:       arkConfig.Endpoint[reportModelKey],
		Temperature: &reportTemperature,
		MaxTokens:   &reportMaxToken,
		Thinking: &model.Thinking{
			Type: model.ThinkingTypeEnabled, // 启用思考
		},
		ReasoningEffort: &reasoningEffort, // 中等推理 effort
	})
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] Init model service failed, err=%v", err)
		return nil, err
	}

	retrieveKnowledgeTool := ai_analysis_tools.NewRetrieveKnowledgeTool()
	reportReactAgent, err := react.NewAgent(ctx, &react.AgentConfig{
		ToolCallingModel: reportModel,
		MaxStep:          20,
		ToolsConfig: compose.ToolsNodeConfig{
			Tools:               []tool.BaseTool{retrieveKnowledgeTool},
			UnknownToolsHandler: tools.UnknownToolsHandler,
		},
		ModelNodeName:         reportModelNodeKey,
		GraphName:             reportGraphName,
		StreamToolCallChecker: ai_infra_utils.StreamToolCallChecker,
	})
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] new report react agent failed, err=%v", err)
		return nil, err
	}

	reportReactGraph, reportReactGraphOpt := reportReactAgent.ExportGraph()

	// 添加节点
	err = g.AddLambdaNode(reportInputNodeKey, reportInputLambda, compose.WithNodeName(reportInputNodeKey))
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] AddLambdaNode %s failed, err=%v", reportInputNodeKey, err)
		return nil, err
	}
	err = g.AddChatTemplateNode(reportTemplateNodeKey, reportTemplate, compose.WithNodeName(reportTemplateNodeKey))
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] AddChatTemplateNode %s failed, err=%v", reportTemplateNodeKey, err)
		return nil, err
	}
	err = g.AddGraphNode(reportLambdaNodeKey, reportReactGraph, reportReactGraphOpt...)
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] AddGraphNode %s failed, err=%v", reportLambdaNodeKey, err)
		return nil, err
	}

	// 添加边
	err = g.AddEdge(compose.START, reportInputNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] AddEdge %s to %s failed, err=%v", compose.START, reportInputNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(reportInputNodeKey, reportTemplateNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] AddEdge %s to %s failed, err=%v", reportInputNodeKey, reportTemplateNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(reportTemplateNodeKey, reportLambdaNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] AddEdge %s to %s failed, err=%v", reportTemplateNodeKey, reportLambdaNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(reportLambdaNodeKey, compose.END)
	if err != nil {
		logs.CtxError(ctx, "[addReportAgent] AddEdge %s to %s failed, err=%v", reportLambdaNodeKey, compose.END, err)
		return nil, err
	}
	return g, nil
}
