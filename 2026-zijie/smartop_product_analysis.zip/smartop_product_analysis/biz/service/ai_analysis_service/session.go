package ai_analysis_service

import (
	"context"
	"errors"
	"fmt"
	"time"

	"code.byted.org/bytedoc/mongo-go-driver/bson"
	"code.byted.org/bytedoc/mongo-go-driver/mongo"
	"code.byted.org/bytedoc/mongo-go-driver/mongo/options"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/agent/supervisor"
	mongo_util "code.byted.org/ecom/smartop_product_analysis/biz/dal/mongo"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino/schema"
	"github.com/jinzhu/copier"
	"github.com/pborman/uuid"
	"github.com/thoas/go-funk"
)

// 获取会话列表
func (d *AIAnalysisService) GetSessionList(ctx context.Context, req *ai_analysis.GetSessionListRequest) (*ai_analysis.GetSessionListResponseData, error) {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	sessionCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(SessionCollection)

	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.EmployeeId == nil {
		logs.CtxError(ctx, "[GetSessionList] user info is nil")
		return nil, errors.New("user info is nil")
	}

	// 设置默认分页参数
	pageNum := int32(1)
	pageSize := int32(20)

	if req.PageInfo != nil {
		if req.PageInfo.PageNum > 0 {
			pageNum = req.PageInfo.PageNum
		}
		if req.PageInfo.PageSize > 0 {
			pageSize = req.PageInfo.PageSize
		}
	}

	// 计算分页偏移量
	skip := (pageNum - 1) * pageSize

	// 获取总记录数
	total, err := sessionCollection.CountDocuments(ctx, bson.M{
		"creator": *userInfo.EmployeeId,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetSessionList] count documents error, err=%v", err)
		return nil, err
	}

	var sessionInfos []*ai_analysis.SessionInfo
	cursor, err := sessionCollection.Find(ctx, bson.M{
		"creator": *userInfo.EmployeeId,
	}, options.Find().
		SetSort(bson.M{"create_time": -1}).
		SetSkip(int64(skip)).
		SetLimit(int64(pageSize)))
	if err != nil {
		logs.CtxError(ctx, "[GetSessionList] find session error, err=%v", err)
		return nil, err
	}
	defer cursor.Close(ctx)

	if err = cursor.All(ctx, &sessionInfos); err != nil {
		logs.CtxError(ctx, "[GetSessionList] decode session error, err=%v", err)
		return nil, err
	}

	// 构建分页响应
	response := &ai_analysis.GetSessionListResponseData{
		SessionList: sessionInfos,
		PageResp: &base.PageResp{
			PageNum:  pageNum,
			PageSize: pageSize,
			Total:    total,
		},
	}

	return response, nil
}

// 获取会话详情
func (d *AIAnalysisService) GetSessionInfo(ctx context.Context, sessionId string) (*ai_analysis.SessionInfo, error) {
	return getSessionInfo(ctx, sessionId)
}

func getSessionInfo(ctx context.Context, sessionId string) (*ai_analysis.SessionInfo, error) {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	sessionCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(SessionCollection)

	var sessionInfo ai_analysis.SessionInfo
	err := sessionCollection.FindOne(ctx, bson.M{
		"session_id": sessionId,
	}).Decode(&sessionInfo)

	if err != nil {
		// 区分"未找到文档"错误和其他错误
		if err == mongo.ErrNoDocuments {
			// 会话不存在，返回nil和nil错误
			logs.CtxWarn(ctx, "[GetSessionInfo] session not found, sessionId=%s", sessionId)
			return nil, nil
		}
		// 记录真实的系统错误
		logs.CtxError(ctx, "[GetSessionInfo] database error, sessionId=%s, err=%v", sessionId, err)
		return nil, err
	}

	// 会话存在，返回会话信息
	return &sessionInfo, nil
}

func createSession(ctx context.Context, parentSessionId *string, name *string, employeeId *string) (string, error) {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	sessionCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(SessionCollection)

	var _employeeId string
	if employeeId != nil && len(*employeeId) > 0 {
		_employeeId = *employeeId
	} else {
		userInfo := utils.GetUserInfo(ctx)
		if userInfo == nil || userInfo.EmployeeId == nil {
			logs.CtxError(ctx, "[CreateSession] user info is nil")
			return "", errors.New("user info is nil")
		}
		_employeeId = *userInfo.EmployeeId
	}

	sessionId := uuid.NewUUID().String()
	createTime := time.Now().Format(consts.Fmt_DateTime)
	insertValue := bson.M{
		"session_id":  sessionId,
		"creator":     _employeeId,
		"operator":    []string{_employeeId},
		"create_time": createTime,
		"name":        fmt.Sprintf("新会话-%s", sessionId[:8]),
	}
	if name != nil && len(*name) > 0 {
		insertValue["name"] = *name
	}
	if parentSessionId != nil {
		insertValue["parent_session_id"] = *parentSessionId
	}

	_, err := sessionCollection.InsertOne(ctx, insertValue)
	if err != nil {
		logs.CtxError(ctx, "[CreateSession] insert session error, err=%v", err)
		return "", err
	}

	return sessionId, nil
}

// 创建会话
func (d *AIAnalysisService) CreateSession(ctx context.Context, shareSessionId *string, name *string, employeeId *string) (string, error) {
	if shareSessionId != nil && len(*shareSessionId) > 0 {
		// 有共享的会话，基于共享会话拷贝一个新会话
		sessionId, err := d.CloneSession(ctx, *shareSessionId, employeeId)
		if err != nil || sessionId == "" {
			logs.CtxError(ctx, "[CreateSession] clone session failed, err=%v", err)
			return "", err
		}
		return sessionId, nil
	}

	// 创建一个新的会话
	sessionId, err := createSession(ctx, nil, name, employeeId)
	if err != nil || sessionId == "" {
		logs.CtxError(ctx, "[CreateSession] create session failed, err=%v", err)
		return "", err
	}
	return sessionId, nil
}

// 删除会话
func (d *AIAnalysisService) DeleteSession(ctx context.Context, sessionId string) error {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	sessionCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(SessionCollection)
	chatMessageCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(ChatMessageCollection)
	contextMessageCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(MessageCollection)

	// 创建 MongoDB 会话用于事务
	session, err := mongoClient.StartSession()
	if err != nil {
		logs.CtxError(ctx, "[DeleteSession] start session error, err=%v", err)
		return err
	}
	defer session.EndSession(ctx)

	// 定义事务函数
	transactionFunc := func(sessionCtx mongo.SessionContext) (interface{}, error) {
		// 1. 删除会话关联的所有上下文消息
		_, err := contextMessageCollection.DeleteMany(sessionCtx, bson.M{"session_id": sessionId})
		if err != nil {
			logs.CtxError(sessionCtx, "[DeleteSession] delete context messages error, err=%v", err)
			return nil, err
		}

		// 2. 删除会话关联的所有对话消息
		_, err = chatMessageCollection.DeleteMany(sessionCtx, bson.M{"session_id": sessionId})
		if err != nil {
			logs.CtxError(sessionCtx, "[DeleteSession] delete chat messages error, err=%v", err)
			return nil, err
		}

		// 3. 删除会话
		_, err = sessionCollection.DeleteOne(sessionCtx, bson.M{"session_id": sessionId})
		if err != nil {
			logs.CtxError(sessionCtx, "[DeleteSession] delete session error, err=%v", err)
			return nil, err
		}

		logs.CtxInfo(sessionCtx, "[DeleteSession] session deleted successfully, sessionId=%s", sessionId)
		return nil, nil
	}

	// 执行事务
	_, err = session.WithTransaction(ctx, transactionFunc)
	if err != nil {
		logs.CtxError(ctx, "[DeleteSession] transaction failed, err=%v", err)
		return err
	}

	return nil
}

// 克隆会话
func (d *AIAnalysisService) CloneSession(ctx context.Context, sessionId string, employeeId *string) (string, error) {
	// 1. 验证会话是否存在
	session, err := getSessionInfo(ctx, sessionId)
	if err != nil {
		logs.CtxError(ctx, "[CloneSession] get session error, err=%v", err)
		return "", err
	}
	if session == nil {
		return "", errors.New("获取会话失败")
	}

	// 2. 获取用户信息
	var _employeeId string
	if employeeId != nil && len(*employeeId) > 0 {
		_employeeId = *employeeId
	} else {
		userInfo := utils.GetUserInfo(ctx)
		if userInfo == nil || userInfo.EmployeeId == nil {
			logs.CtxError(ctx, "[CloneSession] user info is nil")
			return "", errors.New("user info is nil")
		}
		_employeeId = *userInfo.EmployeeId
	}

	// 3. 创建一个新的会话（使用原会话的名称）
	newSessionId, err := createSession(ctx, &session.SessionId, session.Name, &_employeeId)
	if err != nil {
		logs.CtxError(ctx, "[CloneSession] create session error, err=%v", err)
		return "", err
	}

	// 4. 获取会话中的所有对话消息
	messages, err := d.GetChatMessages(ctx, session.SessionId, false)
	if err != nil {
		logs.CtxError(ctx, "[CloneSession] get messages error, err=%v", err)
		return "", err
	}

	// 5. 复制消息到新会话并更新消息关系
	// 创建原消息ID到新消息ID的映射
	originalToNewID := make(map[string]string)
	// 存储新创建的消息
	newMessages := make([]*ai_analysis.ChatMessage, 0, len(messages))

	// 第一遍：生成新消息并更新父消息ID
	for _, msg := range messages {
		// 创建消息副本（深拷贝）
		newMsg := *msg
		// 生成新的messageId
		newMsgId := uuid.NewUUID().String()
		newMsg.MessageId = newMsgId
		newMsg.SessionId = newSessionId
		// 清空子消息，因为不需要设置 child_messages
		newMsg.ChildMessages = nil

		// 存储原消息ID到新消息ID的映射
		originalToNewID[msg.MessageId] = newMsgId

		newMessages = append(newMessages, &newMsg)
	}

	// 第二遍：更新父子关系
	for _, msg := range newMessages {
		// 更新子消息的parent_message_id
		if msg.ParentMessageId != nil {
			if newParentId, ok := originalToNewID[*msg.ParentMessageId]; ok {
				// 创建新的字符串指针
				newParentIdCopy := newParentId
				msg.ParentMessageId = &newParentIdCopy
			}
		}
	}

	// 6. 批量插入新消息
	err = BatchInsertChatMessages(ctx, newMessages)
	if err != nil {
		logs.CtxError(ctx, "[CloneSession] insert messages error, err=%v", err)
		return "", err
	}

	// 7. 获取会话中的上下文消息
	contextMessages, err := getContextMessages(ctx, session.SessionId)
	if err != nil {
		logs.CtxError(ctx, "[CloneSession] get context messages error, err=%v", err)
		return "", err
	}

	// 8. 复制消息到新会话并更新消息关系
	newContextMessages := make([]*ai_analysis.ContextMessage, 0, len(contextMessages))

	// 生成新消息
	for _, msg := range contextMessages {
		// 创建消息副本（深拷贝）
		newMsg := *msg
		// 生成新的messageId
		newMsgId := uuid.NewUUID().String()
		newMsg.MessageId = newMsgId
		newMsg.SessionId = newSessionId

		newContextMessages = append(newContextMessages, &newMsg)
	}

	// 9. 批量插入新上下文消息
	err = BatchInsertContextMessages(ctx, newContextMessages)
	if err != nil {
		logs.CtxError(ctx, "[CloneSession] insert context messages error, err=%v", err)
		return "", err
	}

	return newSessionId, nil
}

func (d *AIAnalysisService) GetSessionId(ctx context.Context, employeeId string, inputSessionId *string, shareSessionId *string) (sessionId string, err error) {
	if inputSessionId != nil && len(*inputSessionId) > 0 {
		// 从数据库中获取会话
		var session *ai_analysis.SessionInfo
		session, err = getSessionInfo(ctx, *inputSessionId)
		if err != nil || session == nil {
			logs.CtxError(ctx, "[getSessionId] get session failed, err=%v", err)
			return "", err
		}

		sessionId = session.SessionId
		return
	}

	sessionId, err = d.CreateSession(ctx, shareSessionId, nil, &employeeId)
	if err != nil || sessionId == "" {
		logs.CtxError(ctx, "[getSessionId] create session failed, err=%v", err)
		return "", err
	}
	return sessionId, nil
}

// 批量创建对话消息
func BatchCreateChatMessage(ctx context.Context, sessionId string, messages []*ai_analysis.ChatMessage) error {
	if len(messages) == 0 {
		logs.CtxWarn(ctx, "[batchCreateChatMessage] messages is empty")
		return nil
	}

	// 验证会话是否存在
	session, err := getSessionInfo(ctx, sessionId)
	if err != nil {
		logs.CtxError(ctx, "[InsertChatMessage] get session error, err=%v", err)
		return err
	}
	if session == nil {
		return errors.New("获取会话失败")
	}

	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	chatMessageCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(ChatMessageCollection)

	// 补充消息信息
	messageBson := make([]interface{}, 0, len(messages))
	for _, message := range messages {
		message.CreateTime = time.Now().Format(consts.Fmt_DateTime)
		if message.SessionId == "" {
			message.SessionId = sessionId
		}
		if message.MessageId == "" {
			message.MessageId = uuid.NewUUID().String()
		}
		messageBson = append(messageBson, message)
	}

	_, err = chatMessageCollection.InsertMany(ctx, messageBson)
	if err != nil {
		logs.CtxError(ctx, "[batchCreateChatMessage] insert message error, err=%v", err)
		return err
	}
	return nil
}

// 批量插入对话消息
func BatchInsertChatMessages(ctx context.Context, messages []*ai_analysis.ChatMessage) error {
	if len(messages) == 0 {
		logs.CtxWarn(ctx, "[batchInsertChatMessages] messages is empty")
		return nil
	}

	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	chatMessageCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(ChatMessageCollection)

	// 将messages转化为bson.M数组
	messageBson := make([]interface{}, 0, len(messages))
	for _, msg := range messages {
		messageBson = append(messageBson, msg)
	}

	_, err := chatMessageCollection.InsertMany(ctx, messageBson)
	if err != nil {
		logs.CtxError(ctx, "[batchInsertChatMessages] insert messages error, err=%v", err)
		return err
	}
	return nil
}

// 批量创建上下文消息
func BatchCreateContextMessage(ctx context.Context, sessionId string, messages []*schema.Message) error {
	// 过滤掉extra.is_history为true的消息
	filterMsgs, ok := funk.Filter(messages, func(msg *schema.Message) bool {
		return msg.Extra == nil || msg.Extra["is_history"] != true
	}).([]*schema.Message)

	if !ok || len(filterMsgs) == 0 {
		logs.CtxWarn(ctx, "[batchCreateContextMessage] messages is empty")
		return nil
	}

	// 验证会话是否存在
	session, err := getSessionInfo(ctx, sessionId)
	if err != nil {
		logs.CtxError(ctx, "[InsertContextMessage] get session error, err=%v", err)
		return err
	}
	if session == nil {
		return errors.New("获取会话失败")
	}

	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	messageCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(MessageCollection)

	messageBson := make([]interface{}, 0, len(filterMsgs))
	for _, message := range filterMsgs {
		contextMessage := &ai_analysis.ContextMessage{
			SessionId:  sessionId,
			MessageId:  uuid.NewUUID().String(),
			CreateTime: time.Now().Format(consts.Fmt_DateTime),
		}
		if _err := copier.Copy(contextMessage, message); _err != nil {
			logs.CtxError(ctx, "[InsertContextMessage] copy message error, err=%v", _err)
			return _err
		}
		messageBson = append(messageBson, contextMessage)
	}

	_, err = messageCollection.InsertMany(ctx, messageBson)
	if err != nil {
		logs.CtxError(ctx, "[batchCreateContextMessage] insert message error, err=%v", err)
		return err
	}
	return nil
}

// 批量插入上下文消息
func BatchInsertContextMessages(ctx context.Context, messages []*ai_analysis.ContextMessage) error {
	if len(messages) == 0 {
		logs.CtxWarn(ctx, "[batchInsertContextMessages] messages is empty")
		return nil
	}

	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	messageCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(MessageCollection)

	// 将messages转化为bson.M数组
	messageBson := make([]interface{}, 0, len(messages))
	for _, msg := range messages {
		messageBson = append(messageBson, msg)
	}

	_, err := messageCollection.InsertMany(ctx, messageBson)
	if err != nil {
		logs.CtxError(ctx, "[batchInsertContextMessages] insert messages error, err=%v", err)
		return err
	}
	return nil
}

// 获取上下文消息
func getContextMessages(ctx context.Context, sessionId string) ([]*ai_analysis.ContextMessage, error) {
	// 验证会话是否存在
	session, err := getSessionInfo(ctx, sessionId)
	if err != nil {
		logs.CtxError(ctx, "[GetContextMessages] get session error, err=%v", err)
		return nil, err
	}
	if session == nil {
		return nil, errors.New("获取会话失败")
	}

	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	messageCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(MessageCollection)

	var messages []*ai_analysis.ContextMessage
	findOptions := options.Find().SetSort(bson.M{"create_time": 1}) // 按照create_time升序排序
	cursor, err := messageCollection.Find(ctx, bson.M{
		"session_id": sessionId,
	}, findOptions)
	if err != nil {
		logs.CtxError(ctx, "[GetContextMessages] find messages error, err=%v", err)
		return nil, err
	}
	defer cursor.Close(ctx)

	if err = cursor.All(ctx, &messages); err != nil {
		logs.CtxError(ctx, "[GetContextMessages] decode message error, err=%v", err)
		return nil, err
	}

	return messages, nil
}

/*
* 获取会话消息
1. 先查询mongo，筛选出session_id的所有消息，按照create_time升序排序
2. 遍历所有消息，根据parent_message_id和message_id构建消息树，子消息放在父消息的ChildMessages字段中，返回根消息列表
*/
func (d *AIAnalysisService) GetChatMessages(ctx context.Context, sessionId string, needTree bool) ([]*ai_analysis.ChatMessage, error) {
	// 1. 验证会话是否存在
	session, err := getSessionInfo(ctx, sessionId)
	if err != nil {
		logs.CtxError(ctx, "[GetChatMessages] get session error, err=%v", err)
		return nil, err
	}
	if session == nil {
		return nil, errors.New("获取会话失败")
	}

	// 2. 获取MongoDB连接和集合
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	messageCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(ChatMessageCollection)

	// 3. 查询该会话的所有消息，先按照create_time升序排序，再按照order升序排序
	filter := bson.M{"session_id": sessionId}
	findOptions := options.Find().SetSort(bson.D{
		{Key: "create_time", Value: 1},
		{Key: "order", Value: 1},
	}) // 先按照create_time升序排序，再按照order升序排序
	cursor, err := messageCollection.Find(ctx, filter, findOptions)
	if err != nil {
		logs.CtxError(ctx, "[GetChatMessages] query messages error, err=%v", err)
		return nil, err
	}
	defer cursor.Close(ctx)

	var allMessages []*ai_analysis.ChatMessage
	if err = cursor.All(ctx, &allMessages); err != nil {
		logs.CtxError(ctx, "[GetChatMessages] decode messages error, err=%v", err)
		return nil, err
	}

	if !needTree {
		// 4. 不构建消息树，直接返回所有消息
		return allMessages, nil
	}

	// 4. 构建消息树
	messageMap := make(map[string]*ai_analysis.ChatMessage)
	var rootMessages []*ai_analysis.ChatMessage

	// 首先将所有消息存入映射表
	for _, msg := range allMessages {
		// 初始化ChildMessages字段
		msg.ChildMessages = make([]*ai_analysis.ChatMessage, 0)
		messageMap[msg.MessageId] = msg
	}

	// 然后构建父子关系
	for _, msg := range allMessages {
		// 如果parent_message_id为空或不存在，则为根消息
		parentMsgId := ""
		if msg.ParentMessageId != nil {
			parentMsgId = *msg.ParentMessageId
		}

		if parentMsgId == "" || parentMsgId == "0" || parentMsgId == "null" {
			rootMessages = append(rootMessages, msg)
		} else {
			// 找到父消息，将当前消息添加到父消息的ChildMessages中
			if parentMsg, exists := messageMap[parentMsgId]; exists {
				parentMsg.ChildMessages = append(parentMsg.ChildMessages, msg)
			} else {
				// 如果父消息不存在，则作为根消息处理
				logs.CtxWarn(ctx, "[GetChatMessages] parent message not found, message_id=%s, parent_message_id=%s",
					msg.MessageId, parentMsgId)
				rootMessages = append(rootMessages, msg)
			}
		}
	}

	// 5. 返回根消息列表
	return rootMessages, nil
}

func GetHistoryMessage(ctx context.Context, sessionId string) ([]*schema.Message, error) {
	// 获取历史消息
	historyMessages, err := getContextMessages(ctx, sessionId)
	if err != nil {
		logs.CtxError(ctx, "[getHistoryMessage] get history messages failed, err=%v", err)
		return nil, err
	}
	// 将历史消息转换为schema.Message数组
	historyMessagesSchema := make([]*schema.Message, 0, len(historyMessages))
	err = copier.Copy(&historyMessagesSchema, &historyMessages)
	if err != nil {
		logs.CtxError(ctx, "[getHistoryMessage] copy history messages failed, err=%v", err)
		return nil, err
	}

	// 遍历historyMessagesSchema，打上is_history的标记
	for _, msg := range historyMessagesSchema {
		supervisor.AddKeyValueToExtra(msg, "is_history", true)
	}

	return historyMessagesSchema, nil
}

func (d *AIAnalysisService) UpdateSessionName(ctx context.Context, sessionId string, name string) error {
	// 验证会话是否存在
	session, err := getSessionInfo(ctx, sessionId)
	if err != nil {
		logs.CtxError(ctx, "[UpdateSessionName] get session error, err=%v", err)
		return err
	}
	if session == nil {
		return errors.New("获取会话失败")
	}

	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	sessionCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(SessionCollection)

	// 使用更新选项
	opts := options.FindOneAndUpdate().
		SetReturnDocument(options.After). // 返回更新后的文档
		SetUpsert(false)                  // 不自动插入

	result := sessionCollection.FindOneAndUpdate(ctx,
		bson.M{"session_id": sessionId},
		bson.M{"$set": bson.M{
			"name":        name,
			"update_time": time.Now().Format(consts.Fmt_DateTime), // 添加更新时间戳
		}},
		opts,
	)

	if result.Err() != nil {
		if errors.Is(result.Err(), mongo.ErrNoDocuments) {
			logs.CtxWarn(ctx, "[UpdateSessionName] session not found, session_id=%s", sessionId)
			return fmt.Errorf("session not found: %s", sessionId)
		}
		logs.CtxError(ctx, "[UpdateSessionName] update session error, err=%v", result.Err())
		return result.Err()
	}

	return nil
}
