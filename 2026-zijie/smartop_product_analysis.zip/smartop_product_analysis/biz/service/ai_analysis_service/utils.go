package ai_analysis_service

import (
	"context"
	"fmt"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/overpass/dp_sophon_sophon_sandbox/kitex_gen/sophon_sandbox"
	"code.byted.org/overpass/dp_sophon_sophon_sandbox/rpc/dp_sophon_sophon_sandbox"
	"github.com/dop251/goja"
	"github.com/thoas/go-funk"
)

// 【已废弃】在指定超时时间内安全执行 js 代码
func runJsInSandbox(code string, timeout time.Duration) (interface{}, error) {
	vm := goja.New()

	// 创建上下文和取消函数，用于超时控制
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	// 通过 goja 的 Interrupt 机制实现超时中断
	done := make(chan struct{})
	var result goja.Value
	var runErr error

	go func() {
		defer func() {
			if r := recover(); r != nil {
				logs.CtxError(ctx, "[runJsInSandbox] panic in run: %v", r)
			}
		}()

		defer close(done)
		result, runErr = vm.RunString(code)
	}()

	select {
	case <-ctx.Done():
		// 超时，触发中断
		vm.Interrupt("script execution timed out")
		<-done // 等待脚本退出
		return nil, fmt.Errorf("script execution timed out")
	case <-done:
		if runErr != nil {
			return nil, runErr
		}
		return result.Export(), nil
	}
}

type execResult struct {
	result string
	err    error
}

// 【已废弃】在指定超时时间内安全执行 python 代码
func runPyInSandbox(code string, sandboxId string, timeout time.Duration) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	resultCh := make(chan execResult, 1)

	go func() {
		defer func() {
			if r := recover(); r != nil {
				logs.CtxError(ctx, "[runPyInSandbox] panic in abort/kill: %v", r)
			}
		}()

		res, err := dp_sophon_sophon_sandbox.RawCall.CreateExecution(ctx, &sophon_sandbox.CreateExecutionRequest{
			SandboxId: sandboxId,
			Code:      code,
		})

		if err != nil {
			logs.CtxError(ctx, "[runPyInSandbox] create execution failed, sandboxId=%s, err=%v", sandboxId, err)
			resultCh <- execResult{"", err}
			return
		}

		if res.Error != nil {
			err = fmt.Errorf("%s", *res.Error)
			logs.CtxError(ctx, "[runPyInSandbox] execution error, sandboxId=%s, err=%v", sandboxId, err)
			resultCh <- execResult{"", err}
			return
		}

		if res.Stdout == nil {
			err = fmt.Errorf("execution result stdout is nil")
			logs.CtxError(ctx, "[runPyInSandbox] execution result stdout is nil, sandboxId=%s", sandboxId)
			resultCh <- execResult{"", err}
			return
		}

		resultCh <- execResult{*res.Stdout, nil}
	}()

	select {
	case <-ctx.Done():
		// 使用独立上下文调用中断接口，避免因超时上下文不可用
		go func() {
			defer func() {
				if r := recover(); r != nil {
					logs.CtxError(ctx, "[runPyInSandbox] panic in abort/kill: %v", r)
				}
			}()

			// 使用无超时的后台上下文，避免调用因超时上下文取消而失败
			abortCtx := context.Background()

			if _, err := dp_sophon_sophon_sandbox.RawCall.AbortExecution(abortCtx, &sophon_sandbox.AbortExecutionRequest{
				SandboxId: sandboxId,
			}); err != nil {
				logs.CtxError(abortCtx, "[runPyInSandbox] abort execution failed, sandboxId=%s, err=%v", sandboxId, err)
			}

			if _, err := dp_sophon_sophon_sandbox.RawCall.KillSandbox(abortCtx, &sophon_sandbox.KillSandboxRequest{
				SandboxId: sandboxId,
			}); err != nil {
				logs.CtxError(abortCtx, "[runPyInSandbox] kill sandbox failed, sandboxId=%s, err=%v", sandboxId, err)
			}
		}()

		logs.CtxError(ctx, "[runPyInSandbox] code execution timeout, sandboxId=%s", sandboxId)
		return "", fmt.Errorf("code execution timed out")
	case r := <-resultCh:
		if r.err != nil {
			logs.CtxError(ctx, "[runPyInSandbox] execution failed, sandboxId=%s, err=%v", sandboxId, r.err)
		}
		return r.result, r.err
	}
}

// 选择知识库数据集
func getDatasetId(ctx context.Context, bizType dimensions.BizType) (string, error) {
	// 获取ByteRAG配置
	byteRAGConfig, err := biz_info.GetByteRAGConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] GetByteRAGConfig failed, err=%v", err)
		return "", err
	}

	switch bizType {
	case dimensions.BizType_GreatValueBuy:
		return byteRAGConfig.Dataset["great_value_buy"], nil
	default:
		return "", nil
	}
}

// 处理base_req，删除dimensions中selected_values为空的元素，返回新的base_req
func processCommonBaseReq(baseReq *CommonBaseStruct) *CommonBaseStruct {
	if baseReq == nil {
		return nil
	}
	// 创建原始请求的副本
	newBaseReq := *baseReq

	// 处理Dimensions，删除SelectedValues为空的元素
	if len(baseReq.Dimensions) > 0 {
		newDimensions, isOk := funk.Filter(baseReq.Dimensions, func(dim *dimensions.SelectedDimensionInfo) bool {
			return dim != nil && len(dim.SelectedValues) > 0
		}).([]*dimensions.SelectedDimensionInfo)
		if isOk {
			newBaseReq.Dimensions = newDimensions
		}
	}

	return &newBaseReq
}

// 将targetMetaList转换为Markdown表格
func targetMetaListToMarkdownTable(targetMetaList []*dimensions.TargetMetaInfo) (string, error) {
	if len(targetMetaList) == 0 {
		return "", nil
	}

	targetRows := make([][]string, 0)
	targetTitleRow := []string{"指标中文名", "指标英文名", "指标说明"}
	targetRows = append(targetRows, targetTitleRow)
	for _, target := range targetMetaList {
		if target != nil {
			targetRows = append(targetRows, []string{
				target.DisplayName,
				target.Name,
				target.Tips,
			})
		}
	}
	return utils.ConvertStringArrayToMarkdownTable(targetRows)
}
