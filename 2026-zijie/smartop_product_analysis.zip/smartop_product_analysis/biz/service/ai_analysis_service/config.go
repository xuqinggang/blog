package ai_analysis_service

import ai_analysis_tools "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service/tools"

// Mongo Collection Name
const (
	SessionCollection           = "new_session"
	MessageCollection           = "message"
	ChatMessageCollection       = "chat_message"
	FeedbackCollection          = "feedback"
	DatasetCollection           = "ai_dataset"
	AnalysisFrameworkCollection = "ai_analysis_framework"
	KnowledgeCollection         = "ai_knowledge"
)

// Prompt Key
const (
	// supervisor
	supervisorPromptKey = "product_analysis.ai_analysis.supervisor"
	// 数据获取
	getDataPromptKey = "product_analysis.diagnosis.get_data_agent"
	// 数据分析
	analysisPromptKey = "product_analysis.ai_analysis.analysis"
	// 报告撰写
	reportPromptKey = "product_analysis.ai_analysis.report"
	// 会话名称生成
	sessionNamePromptKey = "product_analysis.ai_analysis.session_name"
)

// Graph Name
const (
	aiAnalysisGraphName = "ai_analysis"
	supervisorGraphName = "supervisor_graph"
	getDataGraphName    = "get_data_graph"
	analysisGraphName   = "analysis_graph"
	reportGraphName     = "report_graph"
)

// Node Key
const (
	// supervisor agent
	supervisorModelNodeKey = "supervisor_model"

	// report agent
	reportInputNodeKey    = "report_input"
	reportTemplateNodeKey = "report_template"
	reportModelNodeKey    = "report_model"
	reportLambdaNodeKey   = "report_lambda"

	// get data agent
	getDataInputNodeKey    = "get_data_input"
	getDataTemplateNodeKey = "get_data_template"
	getDataModelNodeKey    = "get_data_model"
	getDataLambdaNodeKey   = "get_data_lambda"

	// analysis agent
	analysisTemplateNodeKey = "analysis_template"
	analysisModelNodeKey    = "analysis_model"
	analysisInputNodeKey    = "analysis_input"
	analysisLambdaNodeKey   = "analysis_lambda"

	// ai_analysis
	preProcessNodeKey = "pre_process"
	endProcessNodeKey = "end_process"
)

// default model
const (
	defaultAnalysisModel   = "deepseek-v3.1"
	defaultReportModel     = "doubao-seed-1.6"
	defaultSupervisorModel = "doubao-seed-1.6-thinking-0715"
	defaultGetDataModel    = "deepseek-v3.1"
)

// sub agent
const (
	getDataAgentName  = "get_data_agent"
	analysisAgentName = "analysis_agent"
	reportAgentName   = "report_agent"
	getDataAgentDesc  = "数据查询工具，严格按照用户提供的业务线、分析/对比周期、分析粒度、维度筛选/下钻等条件进行数据查询，不会对查询结果进行任何处理。如果已提供数据，则不需要调用该工具。"
	analysisAgentDesc = "数据分析工具，同时支持文件数据分析，擅长使用 Python 进行深度数据挖掘、趋势分析和可视化展示。只负责数据分析，不负责报告撰写"
	reportAgentDesc   = "数据分析报告撰写工具，负责根据数据分析结果生成结构严谨、逻辑清晰的数据分析报告"
)

// 取数工具列表
var getDataToolList = []string{
	ai_analysis_tools.AttributionProdDetailToolName,
	ai_analysis_tools.GrowthCoreTargetToolName,
	ai_analysis_tools.GrowthReasonToolName,
	ai_analysis_tools.GuessCoreTargetToolName,
	ai_analysis_tools.GuessReasonToolName,
	ai_analysis_tools.ProductMetricsAnalysisToolName,
	ai_analysis_tools.ProductMultiDimAnalysisToolName,
	ai_analysis_tools.ProductRankToolName,
	ai_analysis_tools.ProductTrendAnalysisToolName,
}
