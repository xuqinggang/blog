package ai_analysis_service

import (
	"context"
	"errors"
	"time"

	"code.byted.org/bytedoc/mongo-go-driver/bson"
	"code.byted.org/bytedoc/mongo-go-driver/mongo"
	mongo_util "code.byted.org/ecom/smartop_product_analysis/biz/dal/mongo"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/gopkg/logs"
	"github.com/pborman/uuid"
	"github.com/thoas/go-funk"
)

func checkFrameworkPermission(ctx context.Context, frameworkCollection *mongo.Collection, frameworkId string, employeeId string) error {
	// 查询当前数据集，检查权限
	var existingFramework ai_analysis.AnalysisFramework
	err := frameworkCollection.FindOne(ctx, bson.M{"framework_id": frameworkId}).Decode(&existingFramework)
	if err != nil {
		logs.CtxError(ctx, "[CheckFrameworkPermission] Find framework failed, err: %v", err)
		return err
	}
	// 检查employeeId是否在owner列表中
	found := false
	for _, owner := range existingFramework.Owner {
		if owner == employeeId {
			found = true
			break
		}
	}
	if !found {
		logs.CtxError(ctx, "[CheckFrameworkPermission] Permission denied, employeeId %s not in owner list", employeeId)
		return errors.New("无权限")
	}
	return nil
}

func (d *AIAnalysisService) CreateFramework(ctx context.Context, req *ai_analysis.CreateAnalysisFrameworkRequest) error {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	frameworkCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(AnalysisFrameworkCollection)

	employeeId, err := utils.GetOperatorEmployeeIdFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "[CreateFramework] Get operator employee id from context failed, err: %v", err)
		return err
	}

	frameworkId := uuid.NewUUID().String()
	createTime := time.Now().Format(consts.Fmt_DateTime)
	insertValue := bson.M{
		"framework_id":      frameworkId,
		"framework_name":    req.FrameworkName,
		"framework_content": req.FrameworkContent,
		"framework_type":    req.FrameworkType,
		"framework_doc_url": req.FrameworkDocUrl,
		"create_time":       createTime,
		"creator":           employeeId,
		"owner":             req.Owner,
	}

	_, err = frameworkCollection.InsertOne(ctx, insertValue)
	if err != nil {
		logs.CtxError(ctx, "[CreateFramework] Insert framework failed, err: %v", err)
		return err
	}

	return nil
}

func (d *AIAnalysisService) GetFramework(ctx context.Context, req *ai_analysis.GetAnalysisFrameworkRequest) ([]*ai_analysis.AnalysisFramework, error) {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	frameworkCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(AnalysisFrameworkCollection)

	// 构建查询调焦
	filter := bson.M{}

	// 根据framework_ids查询
	if len(req.FrameworkIds) > 0 {
		filter["framework_id"] = bson.M{"$in": req.FrameworkIds}
	}

	// 根据keyword进行模糊查询（匹配dataset_name）
	if req.Keyword != nil && *req.Keyword != "" {
		filter["framework_name"] = bson.M{"$regex": *req.Keyword, "$options": "i"}
	}

	// 执行查询
	cursor, err := frameworkCollection.Find(ctx, filter)
	if err != nil {
		logs.CtxError(ctx, "[GetFramework] Find framework failed, err: %v", err)
		return nil, err
	}
	defer cursor.Close(ctx)

	// 解析结果
	var frameworks []*ai_analysis.AnalysisFramework
	if err = cursor.All(ctx, &frameworks); err != nil {
		logs.CtxError(ctx, "[GetFramework] Decode framework failed, err: %v", err)
		return nil, err
	}

	employeeId, err := utils.GetOperatorEmployeeIdFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetFramework] Get operator employee id from context failed, err: %v", err)
		return nil, err
	}

	// 过滤结果，只保留owner字段包含employeeId的数据集
	var filteredFrameworks []*ai_analysis.AnalysisFramework
	for _, framework := range frameworks {
		// 检查employeeId是否在owner列表中
		if found := funk.Find(framework.Owner, func(owner string) bool {
			return owner == employeeId
		}); found != nil {
			filteredFrameworks = append(filteredFrameworks, framework)
		}
	}

	return filteredFrameworks, nil
}

func (d *AIAnalysisService) DeleteFramework(ctx context.Context, req *ai_analysis.DeleteAnalysisFrameworkRequest) error {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	frameworkCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(AnalysisFrameworkCollection)

	// 获取更新人工号
	employeeId, err := utils.GetOperatorEmployeeIdFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "[DeleteFramework] Get operator employee id from context failed, err: %v", err)
		return err
	}

	// 检查权限
	err = checkFrameworkPermission(ctx, frameworkCollection, req.FrameworkId, employeeId)
	if err != nil {
		logs.CtxError(ctx, "[DeleteFramework] Check framework permission failed, err: %v", err)
		return err
	}

	// 执行删除操作
	_, err = frameworkCollection.DeleteOne(ctx, bson.M{"framework_id": req.FrameworkId})
	if err != nil {
		logs.CtxError(ctx, "[DeleteFramework] Delete framework failed, err: %v", err)
		return err
	}

	return nil
}

func (d *AIAnalysisService) UpdateFramework(ctx context.Context, req *ai_analysis.UpdateAnalysisFrameworkRequest) error {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(ctx)
	frameworkCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(AnalysisFrameworkCollection)

	// 获取更新人工号
	employeeId, err := utils.GetOperatorEmployeeIdFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "[UpdateDataset] Get operator employee id from context failed, err: %v", err)
		return err
	}

	// 检查权限
	err = checkFrameworkPermission(ctx, frameworkCollection, req.FrameworkId, employeeId)
	if err != nil {
		logs.CtxError(ctx, "[UpdateDataset] Check framework permission failed, err: %v", err)
		return err
	}

	// 构建更新文档，只包含非 nil 字段
	updateDoc := bson.M{}
	if req.FrameworkName != nil {
		updateDoc["framework_name"] = *req.FrameworkName
	}
	if req.FrameworkContent != nil {
		updateDoc["framework_content"] = *req.FrameworkContent
	}
	if len(req.Owner) > 0 {
		updateDoc["owner"] = req.Owner
	}
	if req.FrameworkDocUrl != nil {
		updateDoc["framework_doc_url"] = *req.FrameworkDocUrl
	}
	if req.FrameworkType != nil {
		updateDoc["framework_type"] = *req.FrameworkType
	}

	if len(updateDoc) == 0 {
		return nil
	}

	updateDoc["update_time"] = time.Now().Format(consts.Fmt_DateTime)
	updateDoc["updater"] = employeeId

	// 执行更新操作
	err = frameworkCollection.FindOneAndUpdate(ctx, bson.M{"framework_id": req.FrameworkId}, bson.M{"$set": updateDoc}).Err()
	if err != nil {
		logs.CtxError(ctx, "[UpdateFramework] Update framework failed, err: %v", err)
		return err
	}

	return nil
}
