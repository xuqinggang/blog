package ai_analysis_service

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/agent/supervisor"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/callback"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tos"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/flow/eino-byted-ext/components/prompt/prompthub"
	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino-ext/components/model/ark"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/schema"
	"github.com/pborman/uuid"
	"github.com/volcengine/volcengine-go-sdk/service/arkruntime/model"
)

func (d *AIAnalysisService) AIAnalysis(ctx context.Context, req *CommonReq, stream *StreamServer) error {
	// 获取用户信息，PS：agw流式协议转换之后无法从ctx中获取用户信息
	user, err := utils.GetEcopUserByEmployeeId(ctx, req.EmployeeId)
	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] GetEcopUserByEmployeeId failed, err=%v", err)
		return err
	}

	// 获取fornax client
	fornaxClient := fornax.GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[AI Analysis] GetFornaxClient failed")
		return fmt.Errorf("get fornax client failed")
	}

	// 获取方舟配置
	arkConfig, err := biz_info.GetArkConfig(ctx)
	if err != nil || arkConfig == nil {
		logs.CtxError(ctx, "[AI Analysis] GetArkConfig failed, err=%v", err)
		return err
	}

	// 获取ai配置
	aiConfig, err := biz_info.GetArtificialIntelligenceConfig(ctx)
	if err != nil || aiConfig == nil {
		logs.CtxError(ctx, "[AI Analysis] GetArtificialIntelligenceConfig failed, err=%v", err)
		return err
	}

	// TODO: baseReq后续不再是必须的
	if req.BaseReq == nil {
		logs.CtxError(ctx, "[AI Analysis] base req is nil")
		return fmt.Errorf("base req is nil")
	}

	// 获取会话id
	sessionId, err := d.GetSessionId(ctx, req.EmployeeId, req.SessionId, req.ShareSessionId)
	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] get session id failed, err=%v", err)
		return err
	}

	g := compose.NewGraph[string, *schema.Message]()
	rootMessageId := uuid.NewUUID().String() // 根节点消息ID

	defer func() {
		// 关闭session
		if _err := tools.CloseSession(ctx, rootMessageId); _err != nil {
			logs.CtxWarn(ctx, "[AI Analysis] CloseSession failed, err=%v", _err)
		}
	}()

	// preProcess lambda
	preProcessLambda := compose.InvokableLambda(func(ctx context.Context, input string) ([]*schema.Message, error) {
		// 创建用户消息，并补充额外的信息
		userMsg := schema.UserMessage(input)
		if req.AnalysisFramework != nil && len(req.AnalysisFramework.FrameworkContent) > 0 {
			// 分析思路
			userMsg.Content += fmt.Sprintf("\n\n## 分析思路\n\n%s", req.AnalysisFramework.FrameworkContent)
		}
		if len(req.Data) > 0 {
			// 数据
			userMsg.Content += "\n\n# 数据"
			// 批量上传数据到tos，获取tos_key
			cc := co.NewConcurrent(ctx)
			for _, data := range req.Data {
				if data.ObjectKey != nil && len(*data.ObjectKey) > 0 {
					continue
				}

				currentData := data
				cc.GoV2(func() error {
					// 上传数据到TOS
					objKey, _err := tos.UploadRecordsAsCSV(ctx, currentData.Data, nil)
					if _err != nil {
						logs.CtxError(ctx, "[AI Analysis] Error uploading data to TOS: %v", _err)
						return _err
					}
					currentData.ObjectKey = &objKey // 上传成功后，将objectKey赋值给currentData.ObjectKey
					return nil
				})
			}
			if _err := cc.WaitV2(); _err != nil {
				logs.CtxError(ctx, "[AI Analysis] upload data to tos failed, err=%v", _err)
				return nil, _err
			}

			dataList := make([]*ai_analysis.DataInfo, 0, len(req.Data))
			for _, data := range req.Data {
				// 不需要将具体的数据传给AI, 只需要传递数据描述和tos_key
				dataList = append(dataList, &ai_analysis.DataInfo{
					Description: data.Description,
					ObjectKey:   data.ObjectKey,
					Data:        nil,
				})
			}
			dataStr, _err := json.Marshal(dataList)
			if _err != nil {
				logs.CtxError(ctx, "[AI Analysis] marshal data failed, err=%v", _err)
				return nil, _err
			}
			userMsg.Content += fmt.Sprintf("\n\n```json\n%s\n```", string(dataStr))
		}
		if len(req.Files) > 0 {
			// 文件
			userMsg.Content += "\n\n# 文件"
			filesStr, _err := json.Marshal(req.Files)
			if _err != nil {
				logs.CtxError(ctx, "[AI Analysis] marshal files failed, err=%v", _err)
				return nil, _err
			}
			userMsg.Content += fmt.Sprintf("\n\n```json\n%s\n```", string(filesStr))
		}

		// 获取历史消息
		historyMessages, _err := GetHistoryMessage(ctx, sessionId)
		if _err != nil {
			logs.CtxError(ctx, "[AI Analysis] get history messages failed, err=%v", _err)
			return nil, _err
		}

		msgs := append(historyMessages, userMsg)
		return msgs, nil
	})
	if err = g.AddLambdaNode(preProcessNodeKey, preProcessLambda, compose.WithNodeName(preProcessNodeKey)); err != nil {
		logs.CtxError(ctx, "AI Analysis] add preProcess node failed, err=%v", err)
		return err
	}
	if err = g.AddEdge(compose.START, preProcessNodeKey); err != nil {
		logs.CtxError(ctx, "AI Analysis] AddEdge %s to %s failed, err=%v", compose.START, preProcessNodeKey, err)
		return err
	}

	// supervisor prompt
	supervisorTemplate, err := prompthub.NewPromptHub(ctx, &prompthub.Config{
		Key:          supervisorPromptKey,
		FornaxClient: fornaxClient,
	})
	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] Init prompt service failed, prompt_key=%s, err=%v", supervisorPromptKey, err)
		return err
	}

	// supervisor model
	supervisorTemp := float32(0)
	supervisorMaxTokens := int(8000)
	supervisorModelKey := defaultSupervisorModel
	if aiConfig.Model != nil && len(aiConfig.Model[supervisorModelNodeKey]) > 0 {
		supervisorModelKey = aiConfig.Model[supervisorModelNodeKey]
	}
	supervisorModel, err := ark.NewChatModel(ctx, &ark.ChatModelConfig{
		APIKey:      arkConfig.ApiKey,
		Model:       arkConfig.Endpoint[supervisorModelKey],
		Temperature: &supervisorTemp,
		MaxTokens:   &supervisorMaxTokens,
		Thinking: &model.Thinking{
			Type: model.ThinkingTypeEnabled, // 启用思考
		},
	})
	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] NewChatModel failed, err=%v", err)
		return err
	}

	// get data agent
	getDataAgent, err := d.addGetDataAgent(ctx, req.BizType, req.BaseReq, arkConfig, aiConfig)
	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] AddGetDataAgent failed, err=%v", err)
		return err
	}

	// analysis agent
	analysisAgent, err := d.addAnalysisAgent(ctx, arkConfig, aiConfig)
	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] AddAnalysisAgent failed, err=%v", err)
		return err
	}

	// report agent
	reportAgent, err := d.addReportAgent(ctx, req.BizType, arkConfig, aiConfig)
	if err != nil {
		logs.CtxError(ctx, "[AI Report] AddReportAgent failed, err=%v", err)
		return err
	}

	// 子Agent配置
	agentNames := []string{getDataAgentName, analysisAgentName, reportAgentName}
	subAgentConfigs := []*supervisor.SubAgentConfig{
		{
			AgentName:  getDataAgentName,
			AgentDesc:  getDataAgentDesc,
			AgentGraph: getDataAgent,
			RunMode:    supervisor.AgentRunModeInvoke,
		},
		{
			AgentName:  analysisAgentName,
			AgentDesc:  analysisAgentDesc,
			AgentGraph: analysisAgent,
			RunMode:    supervisor.AgentRunModeInvoke,
		},
		{
			AgentName:  reportAgentName,
			AgentDesc:  reportAgentDesc,
			AgentGraph: reportAgent,
			RunMode:    supervisor.AgentRunModeStream,
		},
	}

	baseReqStr, err := d.convertFiltersToMarkdown(ctx, req.BaseReq)
	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] convertFiltersToMarkdown failed, err=%v", err)
		return err
	}

	// supervisor 工具
	checkDocPermissionTool := tools.NewCheckDocPermissionTool(d.LarkService)
	getDocContentTool := tools.NewGetDocContentTool(d.LarkService)
	tools := []tool.BaseTool{
		checkDocPermissionTool,
		getDocContentTool,
	}

	supervisorAgent, err := supervisor.NewSupervisorAgent(ctx, &supervisor.AgentConfig{
		Supervisor: supervisor.SupervisorConfig{
			Model:        supervisorModel,
			ChatTemplate: supervisorTemplate,
		},
		State: &supervisor.State{
			Context:    baseReqStr,
			EmployeeId: req.EmployeeId,
		},
		SubAgents: subAgentConfigs,
		PreProcess: compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (map[string]any, error) {
			agentListStr := ""
			for _, subAgent := range subAgentConfigs {
				agentListStr += fmt.Sprintf("- %s: %s\n", subAgent.AgentName, subAgent.AgentDesc)
			}
			output := map[string]any{
				"date":         time.Now().Format(consts.Fmt_Date),
				"agent_list":   agentListStr,
				"chat_history": input,
			}

			_ = compose.ProcessState(ctx, func(ctx context.Context, state *supervisor.State) error {
				output["context"] = state.Context
				return nil
			})

			return output, nil
		}),
		Tools:   tools,
		MaxStep: 100,
		InsertMsgFunc: func(ctx context.Context, msgs []*schema.Message) error {
			return BatchCreateContextMessage(ctx, sessionId, msgs)
		},
	})

	if err != nil || supervisorAgent == nil {
		logs.CtxError(ctx, "[AI Analysis] NewSupervisorAgent failed, err=%v", err)
		return err
	}

	supervisorGraph, supervisorGraphOpt := supervisorAgent.ExportGraph()
	if err = g.AddGraphNode(supervisorGraphName, supervisorGraph, supervisorGraphOpt...); err != nil {
		logs.CtxError(ctx, "[AI Analysis] AddGraphNode failed, graphName=%s, err=%v", supervisorGraphName, err)
		return err
	}

	// end process
	endProcessLambda := compose.InvokableLambda(func(ctx context.Context, input *schema.Message) (*schema.Message, error) {
		return input, nil
	})
	if err = g.AddLambdaNode(endProcessNodeKey, endProcessLambda, compose.WithNodeName(endProcessNodeKey)); err != nil {
		logs.CtxError(ctx, "AI Analysis] add endProcess node failed, err=%v", err)
		return err
	}

	if err = g.AddEdge(preProcessNodeKey, supervisorGraphName); err != nil {
		logs.CtxError(ctx, "[AI Analysis] AddEdge %s to %s failed, err=%v", preProcessNodeKey, supervisorGraphName, err)
		return err
	}
	if err = g.AddEdge(supervisorGraphName, endProcessNodeKey); err != nil {
		logs.CtxError(ctx, "[AI Analysis] AddEdge %s to %s failed, err=%v", supervisorGraphName, compose.END, err)
		return err
	}
	if err = g.AddEdge(endProcessNodeKey, compose.END); err != nil {
		logs.CtxError(ctx, "[AI Analysis] AddEdge %s to %s failed, err=%v", endProcessNodeKey, compose.END, err)
		return err
	}

	syncMap := utils.NewSyncMap()
	syncMap.Set(consts.SyncMapSessionIdKey, rootMessageId)       // 使用rootMessageId作为sessionId
	syncMap.Set(consts.SyncMapParentMessageIdKey, rootMessageId) // 使用rootMessageId作为parentMessageId

	// 注入tag到fornax trace
	ctx = fornax.InjectFornaxTrace(ctx, user, rootMessageId, sessionId)

	// 注入userInfo到ctx
	ctx = context.WithValue(ctx, consts.CtxUserInfo, user)

	// 注入syncMap到ctx，主要用于在不同Graph中共享数据（Eino不同Graph State不互通）
	ctx = context.WithValue(ctx, consts.CtxSyncMap, syncMap)

	r, err := g.Compile(ctx,
		compose.WithGraphName(aiAnalysisGraphName),
		compose.WithNodeTriggerMode(compose.AnyPredecessor),
		compose.WithCheckPointStore(supervisor.NewCheckPoint()), // 将checkpoint与图连接起来
	)

	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] Compile graph diagnosis failed, err=%v", err)
		return err
	}

	checkPointId := rootMessageId
	if req.CheckpointId != nil && len(*req.CheckpointId) > 0 {
		checkPointId = *req.CheckpointId
	}
	var queryId string
	if req.QueryId != nil && len(*req.QueryId) > 0 {
		queryId = *req.QueryId
	}
	// 注册回调函数
	analysisCallback := &AnalysisCallback{
		stream:        stream,
		sessionId:     sessionId,
		rootMessageId: rootMessageId,
		employeeId:    req.EmployeeId,
		queryId:       queryId,
		subAgentNames: agentNames,
		req:           req,
		order:         1,
	}
	analysisHandler := analysisCallback.callbackHandler()
	globalHandler := &callback.GlobalHandler{}
	_, err = r.Stream(ctx, req.Query,
		compose.WithCallbacks(globalHandler),
		compose.WithCallbacks(analysisHandler),
		compose.WithCheckPointID(checkPointId), // interrupt是会把graph状态保存到此id中
		// TODO: 中断后，再次运行前会调用StateModifier修改state
		compose.WithStateModifier(func(ctx context.Context, path compose.NodePath, state any) error {
			logs.CtxInfo(ctx, "[AI Analysis] WithStateModifier path=%v, state=%v\n", path, state)
			return nil
		}),
	)

	// 捕获中断错误，发送用户中断消息
	if info, ok := compose.ExtractInterruptInfo(err); ok {
		// TODO: 创建用户中断消息
		logs.CtxInfo(ctx, "[AI Analysis] ExtractInterruptInfo info=%v\n", info)
	}

	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] Stream graph execution failed, err=%v", err)
		return err
	}

	return nil
}
