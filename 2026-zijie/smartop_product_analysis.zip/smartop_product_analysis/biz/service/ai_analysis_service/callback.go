package ai_analysis_service

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"slices"
	"sync"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/agent/supervisor"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	ai_analysis_tools "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/gopkg/logs/v2"
	"github.com/bytedance/sonic"
	"github.com/cloudwego/eino/callbacks"
	"github.com/cloudwego/eino/components/model"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/schema"
	template "github.com/cloudwego/eino/utils/callbacks"
	"github.com/jinzhu/copier"
	"github.com/pborman/uuid"
)

type AnalysisCallback struct {
	streamMutex   sync.Mutex
	stream        *StreamServer
	sessionId     string
	rootMessageId string
	employeeId    string
	queryId       string
	subAgentNames []string
	req           *CommonReq
	order         int32
}

func (cb *AnalysisCallback) saveChatMessage(ctx context.Context, chatMessage []*ai_analysis.ChatMessage) {
	// 在 goroutine 中保存消息
	go func() {
		defer func() {
			if err := recover(); err != nil {
				logs.CtxError(ctx, "[saveChatMessage] panic err: %v", err)
			}
		}()

		// 保存消息
		if err := BatchCreateChatMessage(ctx, cb.sessionId, chatMessage); err != nil {
			logs.CtxError(ctx, "[saveChatMessage] CreateChatMessage fail, err=%v", err)
			return
		}
	}()
}

func (cb *AnalysisCallback) getParentMessageId(ctx context.Context) (parentMessageId string, err error) {
	syncMap, ok := ctx.Value(consts.CtxSyncMap).(*utils.SyncMap)
	if !ok || syncMap == nil {
		err = fmt.Errorf("syncMap is nil")
		return
	}

	messageId, ok := syncMap.Get(consts.SyncMapParentMessageIdKey)
	if !ok || messageId == "" {
		return
	}

	parentMessageId, _ = messageId.(string)
	return
}

func (cb *AnalysisCallback) setParentMessageId(ctx context.Context, parentMessageId string) error {
	syncMap, ok := ctx.Value(consts.CtxSyncMap).(*utils.SyncMap)
	if !ok || syncMap == nil {
		return fmt.Errorf("syncMap is nil")
	}

	syncMap.Set(consts.SyncMapParentMessageIdKey, parentMessageId)
	return nil
}

func (cb *AnalysisCallback) sendMsgStream(ctx context.Context, chatMessage *ai_analysis.ChatMessage) error {
	if cb.stream != nil {
		chatMessageStr, err := json.Marshal(chatMessage)
		if err != nil {
			logs.CtxError(ctx, "[sendMsgStream] json.Marshal message fail, err=%v", err)
			return err
		}

		resp := &ai_analysis.AIStreamResponse{
			Event: "message",
			Data:  string(chatMessageStr),
		}
		cb.streamMutex.Lock()
		err = (*cb.stream).Send(resp)
		cb.streamMutex.Unlock()
		if err != nil {
			logs.CtxError(ctx, "[sendMsgStream] stream.Send fail: %s", err)
			return err
		}
	}

	return nil
}

func (cb *AnalysisCallback) callbackHandler() callbacks.Handler {
	return template.NewHandlerHelper().
		ChatModel(&template.ModelCallbackHandler{
			OnEnd:                 cb.onModelEnd,
			OnEndWithStreamOutput: cb.onModelEndWithStreamOutput,
		}).
		Tool(&template.ToolCallbackHandler{
			OnStart: cb.onToolStart,
			OnEnd:   cb.onToolEnd,
		}).
		Lambda(callbacks.NewHandlerBuilder().
			OnEndFn(cb.onLambdaEnd).
			Build()).
		Handler()
}

func (cb *AnalysisCallback) onLambdaEnd(ctx context.Context, info *callbacks.RunInfo, output callbacks.CallbackOutput) context.Context {
	fmt.Println("=========[Lambda OnEnd]=========")
	if info == nil || output == nil {
		return ctx
	}

	switch info.Name {
	case preProcessNodeKey:
		if cb.req == nil {
			logs.CtxError(ctx, "[onLambdaEnd] preProcess req is nil")
			return ctx
		}
		userChatMsg := &ai_analysis.ChatMessage{
			MessageId:         cb.queryId,
			SessionId:         cb.sessionId,
			Role:              string(schema.User),
			Content:           cb.req.Query, // 这里保留用户原始的输入
			Type:              ai_analysis.MessageType_User,
			Data:              cb.req.Data,
			Files:             cb.req.Files,
			AnalysisFramework: cb.req.AnalysisFramework,
			Order:             cb.order,
		}
		cb.order++
		assistantChatMsg := &ai_analysis.ChatMessage{
			MessageId: cb.rootMessageId,
			SessionId: cb.sessionId,
			Role:      string(schema.Assistant),
			Content:   "",
			Type:      ai_analysis.MessageType_Assistant,
			Order:     cb.order,
		}
		cb.order++
		// 保存用户聊天消息和助手聊天消息
		cb.saveChatMessage(ctx, []*ai_analysis.ChatMessage{userChatMsg, assistantChatMsg})

		// 发送助手聊天消息
		if err := cb.sendMsgStream(ctx, assistantChatMsg); err != nil {
			logs.CtxError(ctx, "[onLambdaEnd] sendMsgStream fail, err=%v", err)
			return ctx
		}
	case endProcessNodeKey:
		// 重置parentMessageId
		if err := cb.setParentMessageId(ctx, cb.rootMessageId); err != nil {
			logs.CtxError(ctx, "[Lambda OnEnd] setParentMessageId fail, err=%v", err)
			return ctx
		}
	default:
	}

	return ctx
}

func (cb *AnalysisCallback) onModelEnd(ctx context.Context, runInfo *callbacks.RunInfo, output *model.CallbackOutput) context.Context {
	fmt.Println("=========[Model OnEnd]=========")
	if runInfo == nil || output == nil || output.Message == nil {
		return ctx
	}

	parentMessageId, err := cb.getParentMessageId(ctx)
	if err != nil {
		logs.CtxError(ctx, "[Model OnEnd] getParentMessageId fail, err=%v", err)
		return ctx
	}

	toolCalls := []*ai_analysis.ToolCall{}
	if len(output.Message.ToolCalls) > 0 {
		_ = copier.Copy(&toolCalls, output.Message.ToolCalls)
	}

	chatMessage := &ai_analysis.ChatMessage{
		MessageId:        uuid.NewUUID().String(),
		SessionId:        cb.sessionId,
		Role:             string(output.Message.Role),
		Content:          output.Message.Content,
		Type:             ai_analysis.MessageType_LLM,
		Name:             "",
		ParentMessageId:  &parentMessageId,
		ReasoningContent: &output.Message.ReasoningContent,
		ToolCalls:        toolCalls,
		Order:            cb.order,
	}
	cb.order++

	// 保存消息
	cb.saveChatMessage(ctx, []*ai_analysis.ChatMessage{chatMessage})

	// 流式输出
	if err = cb.sendMsgStream(ctx, chatMessage); err != nil {
		logs.CtxError(ctx, "[Model OnEnd] sendMsgStream fail, err=%v", err)
		return ctx
	}

	return ctx
}

func (cb *AnalysisCallback) onModelEndWithStreamOutput(ctx context.Context, runInfo *callbacks.RunInfo, output *schema.StreamReader[*model.CallbackOutput]) context.Context {
	// 创建通道用于 goroutine 和主协程通信
	messageId := uuid.NewUUID().String()
	parentMessageId, err := cb.getParentMessageId(ctx)
	if err != nil {
		logs.CtxError(ctx, "[Model OnEndStream] getParentMessageId fail, err=%v", err)
		return ctx
	}

	chunksChan := make(chan []*schema.Message, 1)
	errorChan := make(chan error, 1)
	order := cb.order
	cb.order++

	go func() {
		defer func() {
			if err := recover(); err != nil {
				logs.CtxError(ctx, "[Model OnEndStream] panic err: %v", err)
				errorChan <- fmt.Errorf("panic: %v", err)
			}
		}()

		defer output.Close() // remember to close the stream in defer

		fmt.Println("=========[Model OnEndStream]=========")

		chunks := make([]*schema.Message, 0)
		for {
			frame, _err := output.Recv()
			if errors.Is(_err, io.EOF) {
				// finish
				logs.CtxInfo(ctx, "[Model OnEndStream] Stream Recv finished")
				break
			}
			if _err != nil {
				logs.CtxError(ctx, "[Model OnEndStream] Stream Recv failed, err=%v", _err)
				errorChan <- _err
				return
			}

			if frame == nil || frame.Message == nil {
				logs.CtxWarn(ctx, "[Model OnEndStream] frame convert type is nil, frame=%v", frame)
				continue
			}

			toolCalls := []*ai_analysis.ToolCall{}
			if len(frame.Message.ToolCalls) > 0 {
				_ = copier.Copy(&toolCalls, frame.Message.ToolCalls)
			}

			chatMessage := &ai_analysis.ChatMessage{
				MessageId:        messageId,
				SessionId:        cb.sessionId,
				Role:             string(frame.Message.Role),
				Content:          frame.Message.Content,
				Type:             ai_analysis.MessageType_LLM,
				Name:             "",
				ParentMessageId:  &parentMessageId,
				ReasoningContent: &frame.Message.ReasoningContent,
				ToolCalls:        toolCalls,
			}

			// 流式输出
			if err := cb.sendMsgStream(ctx, chatMessage); err != nil {
				logs.CtxError(ctx, "[Model OnEndStream] sendMsgStream fail, err=%v", err)
				errorChan <- err
				return
			}

			chunks = append(chunks, frame.Message)
		}

		// 成功完成，发送 chunks 到主协程
		chunksChan <- chunks
	}()

	// 主协程等待结果
	go func() {
		defer func() {
			if err := recover(); err != nil {
				logs.CtxError(ctx, "[Model OnEndStream] panic err: %v", err)
			}
		}()

		select {
		case chunks := <-chunksChan:
			// goroutine 成功完成，组装 message
			if len(chunks) > 0 {
				message, err := schema.ConcatMessages(chunks)
				if err != nil {
					logs.CtxError(ctx, "[Model OnEndStream] concat messages failed, err=%v", err)
				}

				// 保存消息
				toolCalls := []*ai_analysis.ToolCall{}
				if len(message.ToolCalls) > 0 {
					_ = copier.Copy(&toolCalls, message.ToolCalls)
				}
				chatMessage := &ai_analysis.ChatMessage{
					MessageId:        messageId,
					SessionId:        cb.sessionId,
					Role:             string(message.Role),
					Content:          message.Content,
					Type:             ai_analysis.MessageType_LLM,
					Name:             "",
					ParentMessageId:  &parentMessageId,
					ReasoningContent: &message.ReasoningContent,
					ToolCalls:        toolCalls,
					Order:            order,
				}
				if err := BatchCreateChatMessage(ctx, cb.sessionId, []*ai_analysis.ChatMessage{
					chatMessage,
				}); err != nil {
					logs.CtxError(ctx, "[saveChatMessage] CreateChatMessage fail, err=%v", err)
					return
				}
			}
		case err := <-errorChan:
			// goroutine 返回错误，记录错误日志
			logs.CtxError(ctx, "[Model OnEndStream] goroutine failed, err=%v", err)
		}
	}()

	return ctx
}

func (cb *AnalysisCallback) onToolStart(ctx context.Context, info *callbacks.RunInfo, input *tool.CallbackInput) context.Context {
	fmt.Println("=========[Tool OnStart]=========")
	if info == nil || input == nil {
		return ctx
	}

	messageId := uuid.NewUUID().String()
	parentMessageId, err := cb.getParentMessageId(ctx)
	if err != nil {
		logs.CtxError(ctx, "[Tool OnStart] getParentMessageId fail, err=%v", err)
		return ctx
	}
	toolDisplayName, ok := ToolDisplayNameMap[info.Name]
	if !ok {
		toolDisplayName = info.Name
	}
	chatMessage := &ai_analysis.ChatMessage{
		MessageId:       messageId,
		SessionId:       cb.sessionId,
		Role:            string(schema.Tool),
		Type:            ai_analysis.MessageType_ToolStart,
		Name:            toolDisplayName,
		ParentMessageId: &parentMessageId,
		Order:           cb.order,
	}
	cb.order++

	if slices.Contains(cb.subAgentNames, info.Name) {
		// 子Agent调用
		var handoffToolParam *supervisor.HandoffToolParams
		if err = json.Unmarshal([]byte(input.ArgumentsInJSON), &handoffToolParam); err != nil || handoffToolParam == nil {
			logs.CtxError(ctx, "[Tool OnStart] Unmarshal HandoffToolParams fail, err=%v", err)
			return ctx
		}

		chatMessage.ParentMessageId = &cb.rootMessageId
		chatMessage.Name = handoffToolParam.Task
		chatMessage.Type = ai_analysis.MessageType_Task

		// 重置parentMessageId
		if err = cb.setParentMessageId(ctx, messageId); err != nil {
			logs.CtxError(ctx, "[Tool OnEnd] setParentMessageId fail, err=%v", err)
			return ctx
		}
	} else if info.Name == tools.TodoWriteToolName {
		// todo_write工具
		chatMessage.Content, err = getTodoWriteContent(input.ArgumentsInJSON)
		if err != nil {
			logs.CtxError(ctx, "[Tool OnEnd] getTodoWriteContent fail, err=%v", err)
			return ctx
		}
		chatMessage.NoWrap = true
	} else if info.Name == tools.RunScriptToolName {
		// 运行脚本工具
		chatMessage.Content, err = getRunScriptToolParams(input.ArgumentsInJSON)
		if err != nil {
			logs.CtxError(ctx, "[Tool OnEnd] getRunScriptToolParams fail, err=%v", err)
			return ctx
		}
	} else {
		// 其他工具调用
		var out bytes.Buffer
		if err = json.Indent(&out, []byte(input.ArgumentsInJSON), "", "  "); err != nil {
			logs.CtxError(ctx, "[Tool OnEnd] json.Indent fail, err=%v", err)
			return ctx
		}

		chatMessage.Content = fmt.Sprintf("```json\n%s\n```", out.String())
	}

	// 保存消息
	cb.saveChatMessage(ctx, []*ai_analysis.ChatMessage{chatMessage})

	// 流式输出
	if err = cb.sendMsgStream(ctx, chatMessage); err != nil {
		logs.CtxError(ctx, "[Tool OnEnd] sendMsgStream fail, err=%v", err)
		return ctx
	}

	return ctx
}

func (cb *AnalysisCallback) onToolEnd(ctx context.Context, info *callbacks.RunInfo, output *tool.CallbackOutput) context.Context {
	fmt.Println("=========[Tool OnEnd]=========")
	if output == nil || info == nil || info.Name == tools.TodoWriteToolName {
		// 过滤todo_write工具
		return ctx
	}

	if slices.Contains(cb.subAgentNames, info.Name) {
		// 子Agent调用完成，重置parentMessageId
		if err := cb.setParentMessageId(ctx, cb.rootMessageId); err != nil {
			logs.CtxError(ctx, "[Tool OnEnd] setParentMessageId fail, err=%v", err)
			return ctx
		}
		return ctx
	}

	messageId := uuid.NewUUID().String()
	parentMessageId, err := cb.getParentMessageId(ctx)
	if err != nil {
		logs.CtxError(ctx, "[Tool OnEnd] getParentMessageId fail, err=%v", err)
		return ctx
	}
	toolDisplayName, ok := ToolDisplayNameMap[info.Name]
	if !ok {
		toolDisplayName = info.Name
	}
	chatMessage := &ai_analysis.ChatMessage{
		MessageId:       messageId,
		SessionId:       cb.sessionId,
		Role:            string(schema.Tool),
		Type:            ai_analysis.MessageType_ToolEnd,
		Name:            fmt.Sprintf("%s结果", toolDisplayName),
		ParentMessageId: &parentMessageId,
		Order:           cb.order,
	}
	cb.order++

	if info.Name == tools.RunScriptToolName {
		// 运行脚本工具
		chatMessage.Content, err = getRunScriptToolContent(output.Response)
		chatMessage.NoWrap = true
		if err != nil {
			logs.CtxError(ctx, "[Tool OnEnd] getRunScriptToolContent fail, err=%v", err)
			return ctx
		}
	} else if slices.Contains(getDataToolList, info.Name) {
		// 数据查询工具
		chatMessage.Content, err = getDataToolContent(output.Response)
		chatMessage.NoWrap = true
		if err != nil {
			logs.CtxError(ctx, "[Tool OnEnd] getDataToolContent fail, err=%v", err)
			return ctx
		}
	} else {
		// 其他工具默认取Response作为Content，使用json格式包裹
		var out bytes.Buffer
		if err = json.Indent(&out, []byte(output.Response), "", "  "); err != nil {
			logs.CtxError(ctx, "[Tool OnEnd] json.Indent fail, err=%v", err)
			return ctx
		}

		chatMessage.Content = fmt.Sprintf("```json\n%s\n```", out.String())
	}

	// 保存消息
	cb.saveChatMessage(ctx, []*ai_analysis.ChatMessage{chatMessage})

	// 流式输出
	err = cb.sendMsgStream(ctx, chatMessage)
	if err != nil {
		logs.CtxError(ctx, "[Tool OnEnd] sendMsgStream fail, err=%v", err)
		return ctx
	}

	return ctx
}

func getTodoWriteContent(input string) (res string, err error) {
	var toolRes *tools.TodoWriteParams
	if err = sonic.UnmarshalString(input, &toolRes); err != nil || toolRes == nil {
		return
	}

	if len(toolRes.Todos) == 0 {
		res = "暂无待办事项"
		return
	}

	markdownBuilder := "**任务列表**：\n"
	for _, todo := range toolRes.Todos {
		if todo == nil {
			continue
		}

		// 根据状态生成不同的复选框
		checkbox := "- [ ]"
		if todo.Status == tools.TodoStatusCompleted {
			checkbox = "- [x]"
		}

		// // 添加优先级标识
		// priorityIndicator := ""
		// switch todo.Priority {
		// case tools.TodoPriorityHigh:
		// 	priorityIndicator = " 🔴"
		// case tools.TodoPriorityMedium:
		// 	priorityIndicator = " 🟡"
		// case tools.TodoPriorityLow:
		// 	priorityIndicator = " 🟢"
		// }

		// 构建每行内容
		markdownBuilder += fmt.Sprintf("%s %s\n", checkbox, todo.Title)
	}

	res = markdownBuilder
	return
}

func getRunScriptToolParams(input string) (res string, err error) {
	var toolRes *tools.RunScriptParams
	if err = sonic.UnmarshalString(input, &toolRes); err != nil || toolRes == nil {
		return
	}

	res = fmt.Sprintf("```python\n%s\n```", toolRes.Code)
	return
}

func getRunScriptToolContent(input string) (res string, err error) {
	var toolRes *tools.RunScriptRes
	if err = sonic.UnmarshalString(input, &toolRes); err != nil || toolRes == nil {
		return
	}

	if toolRes.Status != "success" || toolRes.Stdout == "" {
		res = "脚本执行失败"
		return
	}

	res = toolRes.Stdout
	return
}

func getDataToolContent(input string) (res string, err error) {
	var toolRes *tools.GetDataToolRes
	if err = sonic.UnmarshalString(input, &toolRes); err != nil || toolRes == nil {
		return
	}

	if toolRes.ErrorMsg != "" {
		res = fmt.Sprintf("查询数据失败，错误信息：%s", toolRes.ErrorMsg)
		return
	}

	if len(toolRes.Data) == 0 {
		res = "暂无数据"
		return
	}

	for _, data := range toolRes.Data {
		var dataPreview string
		if data.DataPreview == nil || *data.DataPreview == "" {
			var _err error
			dataPreview, _err = ai_analysis_tools.GetDefaultPreview(data.Data)
			if _err != nil {
				dataPreview = "数据预览失败"
			}
		} else {
			dataPreview = *data.DataPreview
		}
		res += fmt.Sprintf("\n\n- %s\n\n%s", data.Description, dataPreview)
	}

	return
}
