package ai_analysis_service

import (
	"context"
	"time"

	mongo_util "code.byted.org/ecom/smartop_product_analysis/biz/dal/mongo"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/gopkg/logs/v2"
	"github.com/jinzhu/copier"
	"github.com/pborman/uuid"
)

type Feedback struct {
	FeedbackId string  `json:"feedback_id" bson:"feedback_id"` // 反馈id, 唯一标识一个feedback
	MessageId  string  `json:"message_id" bson:"message_id"`   // 消息id
	SessionId  string  `json:"session_id" bson:"session_id"`   // 会话id
	Creator    string  `json:"creator" bson:"creator"`         // 反馈人employee_id
	CreateTime string  `json:"create_time" bson:"create_time"` // 反馈时间, 格式为"2006-01-02 15:04:05"
	Type       int     `json:"type" bson:"type"`               // 反馈类型，1: 正向反馈，2: 负向反馈
	Content    *string `json:"content" bson:"content"`         // 反馈内容
	Reason     *string `json:"reason" bson:"reason"`           // 反馈原因
}

func (d *AIAnalysisService) CreateFeedback(ctx context.Context, req *ai_analysis.FeedbackRequest) error {
	mongoClient := mongo_util.GetClient()
	defer mongoClient.Disconnect(context.Background())
	feedbackCollection := mongoClient.Database(mongo_util.DB_NAME).Collection(FeedbackCollection)

	feedbackId := uuid.NewUUID().String()
	createTime := time.Now().Format(consts.Fmt_DateTime)
	user := utils.GetUserInfo(ctx)
	feedback := &Feedback{
		FeedbackId: feedbackId,
		Creator:    *user.EmployeeId,
		CreateTime: createTime,
	}

	err := copier.Copy(feedback, &req)
	if err != nil {
		logs.CtxError(ctx, "[CreateFeedback] copy feedback error, err=%v", err)
		return err
	}

	_, err = feedbackCollection.InsertOne(ctx, feedback)
	if err != nil {
		logs.CtxError(ctx, "[CreateFeedback] insert feedback error, err=%v", err)
		return err
	}

	return nil
}
