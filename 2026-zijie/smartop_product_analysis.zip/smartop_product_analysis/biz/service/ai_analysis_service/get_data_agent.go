package ai_analysis_service

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/agent/supervisor"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	ai_tools "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/flow/eino-byted-ext/components/prompt/prompthub"
	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino-ext/components/model/ark"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"
	"github.com/cloudwego/eino/schema"
	"github.com/volcengine/volcengine-go-sdk/service/arkruntime/model"
)

type GetDataAgentMsg struct {
	Conclusion string               `json:"conclusion"`
	Data       []*ai_tools.DataInfo `json:"data"`
}

func (d *AIAnalysisService) addGetDataAgent(ctx context.Context, bizType dimensions.BizType, baseReq *CommonBaseStruct, arkConfig *ai_analysis.ArkConfig, aiConfig *ai_analysis.ArtificialIntelligenceConfig) (*compose.Graph[[]*schema.Message, *schema.Message], error) {
	// 获取fornax client
	fornaxClient := fornax.GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[addGetDataAgent] GetFornaxClient failed")
		return nil, fmt.Errorf("get fornax client failed")
	}

	// 将req转换为json
	baseReqJson, err := json.Marshal(processCommonBaseReq(baseReq))
	if err != nil {
		logs.CtxError(ctx, "[AI Analysis] Marshal base req failed, err=%v", err)
		return nil, err
	}

	targetMetaList, err := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, bizType, false)
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] GetProductAnalysisTargetMetaList failed, err=%v", err)
		return nil, err
	}

	g := compose.NewGraph[[]*schema.Message, *schema.Message]()

	targetsListStr, _ := targetMetaListToMarkdownTable(targetMetaList)
	getDataInputLambda := compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (map[string]any, error) {
		output := map[string]any{
			"date":         time.Now().Format(consts.Fmt_Date),
			"base_req":     string(baseReqJson),
			"chat_history": input,
			"targets_list": targetsListStr,
		}
		_ = compose.ProcessState(ctx, func(ctx context.Context, state *supervisor.State) error {
			output["context"] = state.Context
			return nil
		})

		return output, nil
	})

	getDataTemplate, err := prompthub.NewPromptHub(ctx, &prompthub.Config{
		Key:          getDataPromptKey,
		FornaxClient: fornaxClient,
	})
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] Init prompt service failed, prompt_key=%s, err=%v", getDataPromptKey, err)
		return nil, err
	}

	getDataTemp := float32(0)
	getDataMaxTokens := int(8000)
	getDataModelKey := defaultGetDataModel
	if aiConfig != nil && aiConfig.Model != nil && len(aiConfig.Model[getDataModelNodeKey]) > 0 {
		getDataModelKey = aiConfig.Model[getDataModelNodeKey]
	}
	getDataModel, err := ark.NewChatModel(ctx, &ark.ChatModelConfig{
		APIKey:      arkConfig.ApiKey,
		Model:       arkConfig.Endpoint[getDataModelKey],
		Temperature: &getDataTemp,
		MaxTokens:   &getDataMaxTokens,
		Thinking: &model.Thinking{
			Type: model.ThinkingTypeDisabled, // 禁用思考
		},
	})
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] Init getData model failed, err=%v", err)
		return nil, err
	}

	tools, err := d.getDataAgentTools(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] GetDataAgentTools failed, err=%v", err)
		return nil, err
	}

	// 创建获取数据 react agent
	getDataReactAgent, err := react.NewAgent(ctx, &react.AgentConfig{
		ToolCallingModel: getDataModel,
		MaxStep:          20,
		ToolsConfig: compose.ToolsNodeConfig{
			Tools:               tools,
			UnknownToolsHandler: ai_tools.UnknownToolsHandler,
			ToolCallMiddlewares: []compose.ToolMiddleware{{
				Invokable: ai_tools.ProcessDataMiddleware, // 数据处理中间件
			}},
		},
		StreamToolCallChecker: ai_infra_utils.StreamToolCallChecker,
		GraphName:             getDataGraphName,
		ModelNodeName:         getDataLambdaNodeKey,
	})
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] Create react agent failed, err=%v", err)
		return nil, err
	}

	// 构建lambda节点，在lambda节点中调用react agent，获取react agent的历史消息，组装后传递给下一个节点
	getDataLambda := compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (output *schema.Message, err error) {
		option, _ := react.WithMessageFuture() // 获取消息future
		// 调用react agent
		sr, err := getDataReactAgent.Stream(ctx, input, option)
		if err != nil {
			logs.CtxError(ctx, "[addGetDataAgent] getDataReactAgent.Stream failed, err=%v", err)
			return nil, err
		}
		msg, err := schema.ConcatMessageStream(sr)
		if err != nil {
			logs.CtxError(ctx, "[addGetDataAgent] ConcatMessageStream failed, err=%v", err)
			return nil, err
		}

		// 从syncMap中获取查询的数据信息
		dataList, err := ai_tools.GetDataList(ctx)
		if err != nil {
			logs.CtxError(ctx, "[addGetDataAgent] GetDataList failed, err=%v", err)
			return nil, err
		}
		defer ai_tools.DeleteDataList(ctx) // 删除dataList

		if len(dataList) == 0 {
			// 数据为空
			logs.CtxWarn(ctx, "[addGetDataAgent] dataList is empty")
			return msg, nil
		}
		// 清空data.DataPreview和data.Data（不传递给AI）
		for _, data := range dataList {
			data.DataPreview = nil
			data.Data = nil
		}

		getDataAgentMsg := &GetDataAgentMsg{
			Conclusion: msg.Content,
			Data:       dataList,
		}
		content, err := json.Marshal(getDataAgentMsg)
		if err != nil {
			logs.CtxError(ctx, "[addGetDataAgent] Marshal GetDataAgentMsg failed, err=%v", err)
			return nil, err
		}

		msg = schema.AssistantMessage(fmt.Sprintf("已获取到数据，数据内容为：\n\n```json\n%s\n```", string(content)), nil) // 重写msg
		return msg, nil
	})

	err = g.AddLambdaNode(getDataInputNodeKey, getDataInputLambda, compose.WithNodeName(getDataInputNodeKey))
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] AddLambdaNode %s failed, err=%v", getDataInputNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(compose.START, getDataInputNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] AddEdge %s to %s failed, err=%v", compose.START, getDataInputNodeKey, err)
		return nil, err
	}
	err = g.AddChatTemplateNode(getDataTemplateNodeKey, getDataTemplate, compose.WithNodeName(getDataTemplateNodeKey))
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] AddChatTemplateNode %s failed, err=%v", getDataTemplateNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(getDataInputNodeKey, getDataTemplateNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] AddEdge %s to %s failed, err=%v", getDataInputNodeKey, getDataTemplateNodeKey, err)
		return nil, err
	}
	err = g.AddLambdaNode(getDataLambdaNodeKey, getDataLambda, compose.WithNodeName(getDataLambdaNodeKey))
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] AddLambdaNode %s failed, err=%v", getDataLambdaNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(getDataTemplateNodeKey, getDataLambdaNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] AddEdge %s to %s failed, err=%v", getDataTemplateNodeKey, getDataLambdaNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(getDataLambdaNodeKey, compose.END)
	if err != nil {
		logs.CtxError(ctx, "[addGetDataAgent] AddEdge %s to %s failed, err=%v", getDataLambdaNodeKey, compose.END, err)
		return nil, err
	}

	return g, nil
}
