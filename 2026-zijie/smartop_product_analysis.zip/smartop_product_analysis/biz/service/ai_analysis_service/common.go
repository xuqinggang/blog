package ai_analysis_service

import (
	"context"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	ai_analysis_tools "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"

	"github.com/cloudwego/eino-ext/devops"
	"github.com/jinzhu/copier"

	"github.com/cloudwego/kitex/pkg/streaming"

	"github.com/cloudwego/eino/components/tool"
)

// PS: 开发调试用，上线前需要注释掉
func Init() {
	fmt.Println("=========== init eino dev ==========")
	ctx := context.Background()
	// Init eino devops server
	err := devops.Init(ctx)
	if err != nil {
		logs.Errorf("[eino dev] init failed, err=%v", err)
		return
	}
}

type StreamServer interface {
	streaming.Stream

	Send(*ai_analysis.AIStreamResponse) error
}

// 通用的请求体
type CommonBaseStruct struct {
	BizType          dimensions.BizType                       `thrift:"biz_type,1,required" frugal:"1,required,BizType" json:"biz_type"`
	InsightType      analysis.AttributionInsightType          `thrift:"insight_type,2,required" frugal:"2,required,AttributionInsightType" json:"insight_type"`
	StartDate        string                                   `thrift:"start_date,3,required" frugal:"3,required,string" json:"start_date"`
	EndDate          string                                   `thrift:"end_date,4,required" frugal:"4,required,string" json:"end_date"`
	CompareStartDate string                                   `thrift:"compare_start_date,5,required" frugal:"5,required,string" json:"compare_start_date"`
	CompareEndDate   string                                   `thrift:"compare_end_date,6,required" frugal:"6,required,string" json:"compare_end_date"`
	Dimensions       []*dimensions.SelectedDimensionInfo      `thrift:"dimensions,7,optional" frugal:"7,optional,list<dimensions.SelectedDimensionInfo>" json:"dimensions,omitempty"`
	GroupAttrs       []*dimensions.SelectedMultiDimensionInfo `thrift:"group_attrs,8,optional" frugal:"8,optional,list<dimensions.SelectedMultiDimensionInfo>" json:"group_attrs,omitempty"`
	ThresholdAttrs   []*dimensions.ThresholdAttr              `thrift:"threshold_attrs,9,optional" frugal:"9,optional,list<dimensions.ThresholdAttr>" json:"threshold_attrs,omitempty"`
	ThresholdExpr    *base.LogicalExprType                    `thrift:"threshold_expr,10,optional" frugal:"10,optional,LogicalExprType" json:"threshold_expr,omitempty"`
}

// 通用请求体
type CommonReq struct {
	Query             string                       `json:"query"`
	EmployeeId        string                       `json:"employee_id"`
	BizType           dimensions.BizType           `json:"biz_type"`
	BaseReq           *CommonBaseStruct            `json:"base_req"`
	QueryId           *string                      `json:"query_id,omitempty"`
	SessionId         *string                      `json:"session_id,omitempty"`
	Data              []*ai_analysis.DataInfo      `json:"data,omitempty"`
	ShareSessionId    *string                      `json:"share_session_id,omitempty"`
	CheckpointId      *string                      `json:"checkpoint_id,omitempty"`
	AnalysisFramework *ai_analysis.SimpleFramework `json:"analysis_framework,omitempty"`
	Files             []*ai_analysis.FileInfo      `json:"files,omitempty"`
}

type IAIAnalysisService interface {
	// 接口
	GetSessionList(ctx context.Context, req *ai_analysis.GetSessionListRequest) (*ai_analysis.GetSessionListResponseData, error)
	GetSessionInfo(ctx context.Context, sessionId string) (*ai_analysis.SessionInfo, error)
	CreateSession(ctx context.Context, shareSessionId *string, name *string, employeeId *string) (string, error)
	DeleteSession(ctx context.Context, sessionId string) error
	UpdateSessionName(ctx context.Context, sessionId string, name string) error
	GetChatMessages(ctx context.Context, sessionId string, needTree bool) ([]*ai_analysis.ChatMessage, error)
	AIAnalysis(ctx context.Context, req *CommonReq, stream *StreamServer) error
	CreateFeedback(ctx context.Context, req *ai_analysis.FeedbackRequest) error
	CreateFramework(ctx context.Context, req *ai_analysis.CreateAnalysisFrameworkRequest) error
	GetFramework(ctx context.Context, req *ai_analysis.GetAnalysisFrameworkRequest) ([]*ai_analysis.AnalysisFramework, error)
	DeleteFramework(ctx context.Context, req *ai_analysis.DeleteAnalysisFrameworkRequest) error
	UpdateFramework(ctx context.Context, req *ai_analysis.UpdateAnalysisFrameworkRequest) error
	// 其他
	GetSessionId(ctx context.Context, employeeId string, inputSessionId *string, shareSessionId *string) (sessionId string, err error)
	CloneSession(ctx context.Context, sessionId string, employeeId *string) (string, error)
}

type AIAnalysisService struct {
	DimensionBizListDao dao.IDimensionBizListDao
	DimensionEnumDao    dao.IDimensionEnumDao
	DimensionListDao    dao.IDimensionListDao
	DimensionService    dimension_service.IDimensionService
	AnalysisService     analysis_service.IAnalysisService
	ProdPortraitService prod_portrait.IProdPortraitService
	LarkService         lark_service.ILarkService
	CommonTool          *ai_analysis_tools.CommonTool
}

var ToolDisplayNameMap = map[string]string{
	ai_analysis_tools.AttributionProdDetailToolName:   "查询异动归因商品明细数据",
	ai_analysis_tools.BatchQueryDimensionToolName:     "查询维度信息",
	ai_analysis_tools.GrowthCoreTargetToolName:        "查询大盘异动归因商品核心指标数据",
	ai_analysis_tools.GrowthReasonToolName:            "查询大盘异动归因商品原因指标数据",
	ai_analysis_tools.GuessCoreTargetToolName:         "查询猜喜异动归因商品核心指标数据",
	ai_analysis_tools.GuessReasonToolName:             "查询猜喜异动归因商品原因指标数据",
	ai_analysis_tools.ProductMetricsAnalysisToolName:  "查询货盘的核心指标数据",
	ai_analysis_tools.ProductMultiDimAnalysisToolName: "查询货盘的多维度指标数据",
	ai_analysis_tools.ProductRankToolName:             "查询货盘的商品明细数据",
	ai_analysis_tools.RetrieveKnowledgeToolName:       "知识库检索",
	ai_analysis_tools.ProductTrendAnalysisToolName:    "查询货盘的商品趋势数据",
	tools.GetDocContentToolName:                       "获取飞书云文档内容",
	tools.CheckDocPermissionToolName:                  "校验飞书云文档的权限",
	tools.RunScriptToolName:                           "执行Python脚本",
	tools.TodoWriteToolName:                           "更新任务列表",
}

// 将筛选项转化为Markdown
func (d *AIAnalysisService) convertFiltersToMarkdown(ctx context.Context, baseStruct *CommonBaseStruct) (string, error) {
	// 获取业务线信息
	bizInfoList, err := d.DimensionBizListDao.GetBizList(ctx)
	if err != nil {
		return "", err
	}

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取指标元信息
	targetMetaList, err := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, baseStruct.BizType, false)
	if err != nil {
		return "", err
	}

	baseReq := &dimensions.ProductAnalysisBaseStruct{}
	err = copier.Copy(baseReq, baseStruct)
	if err != nil {
		return "", err
	}
	baseReqStr := utils.ConvertBaseReqToMarkdown(baseReq, bizInfoList, dimMap, targetMetaList)
	return baseReqStr, nil
}

// 取数工具集合
func (d *AIAnalysisService) getDataAgentTools(ctx context.Context, bizType dimensions.BizType) ([]tool.BaseTool, error) {
	batchqueryDimensionTool := ai_analysis_tools.NewBatchQueryDimensionTool(d.DimensionService)
	getGuessReasonTool := ai_analysis_tools.NewGuessReasonTool(d.CommonTool)
	getContentTypeReasonTool := ai_analysis_tools.NewGuessCoreTargetTool(d.CommonTool)
	getGrowthCoreTargetTool := ai_analysis_tools.NewGrowthCoreTargetTool(d.CommonTool)
	getGrowthReasonTool := ai_analysis_tools.NewGrowthReasonTool(d.CommonTool)
	getAttributionProdDetailTool := ai_analysis_tools.NewAttributionProdDetailTool(d.CommonTool)
	multiDimAnalysisTool := ai_analysis_tools.NewProductMultiDimAnalysisTool(d.AnalysisService)
	metricsAnalysisTool := ai_analysis_tools.NewProductMetricsAnalysisTool(d.AnalysisService)
	trendAnalysisTool := ai_analysis_tools.NewTrendAnalysisTool(d.AnalysisService, d.DimensionListDao)
	prodRankTool := ai_analysis_tools.NewProductRankTool(d.ProdPortraitService)

	tools := []tool.BaseTool{
		batchqueryDimensionTool,
	}

	// 区分业务线的工具
	bizTools := []ai_analysis_tools.InvokableBizTool{
		getGuessReasonTool,
		getContentTypeReasonTool,
		getGrowthCoreTargetTool,
		getGrowthReasonTool,
		getAttributionProdDetailTool,
		multiDimAnalysisTool,
		metricsAnalysisTool,
		trendAnalysisTool,
		prodRankTool,
	}

	bizInfo, err := d.DimensionBizListDao.GetBizInfo(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[getDataAgentTools] GetBizInfo failed, err=%v", err)
		return nil, err
	}

	// 过滤出当前业务线支持的工具
	for _, bizTool := range bizTools {
		if bizTool.CheckBiz(bizInfo) {
			tools = append(tools, bizTool)
		}
	}

	return tools, nil
}
