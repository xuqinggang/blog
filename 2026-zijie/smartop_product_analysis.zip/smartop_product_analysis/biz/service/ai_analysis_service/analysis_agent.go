package ai_analysis_service

import (
	"context"
	"fmt"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/agent/supervisor"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/flow/eino-byted-ext/components/prompt/prompthub"
	"code.byted.org/gopkg/logs/v2"
	"github.com/bytedance/sonic"
	"github.com/cloudwego/eino-ext/components/model/ark"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"
	"github.com/cloudwego/eino/schema"
	"github.com/thoas/go-funk"
	"github.com/volcengine/volcengine-go-sdk/service/arkruntime/model"
)

func (d *AIAnalysisService) addAnalysisAgent(ctx context.Context, arkConfig *ai_analysis.ArkConfig, aiConfig *ai_analysis.ArtificialIntelligenceConfig) (*compose.Graph[[]*schema.Message, *schema.Message], error) {
	// 获取fornax client
	fornaxClient := fornax.GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[addAnalysisAgent] GetFornaxClient failed")
		return nil, fmt.Errorf("get fornax client failed")
	}

	g := compose.NewGraph[[]*schema.Message, *schema.Message]()

	analysisInputLambda := compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (map[string]any, error) {
		output := map[string]any{
			"date":         time.Now().Format(consts.Fmt_Date),
			"chat_history": input,
		}
		_ = compose.ProcessState(ctx, func(ctx context.Context, state *supervisor.State) error {
			output["context"] = state.Context
			return nil
		})

		return output, nil
	})
	analysisTemplate, err := prompthub.NewPromptHub(ctx, &prompthub.Config{
		Key:          analysisPromptKey,
		FornaxClient: fornaxClient,
	})
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] Init prompt service failed, prompt_key=%s, err=%v", analysisPromptKey, err)
		return nil, err
	}

	analysisTemp := float32(0.3)
	analysisMaxToken := int(8000)
	reasoningEffort := model.ReasoningEffortMedium
	analysisModelKey := defaultAnalysisModel
	if aiConfig.Model != nil && len(aiConfig.Model[analysisModelNodeKey]) > 0 {
		analysisModelKey = aiConfig.Model[analysisModelNodeKey]
	}
	analysisModel, err := ark.NewChatModel(ctx, &ark.ChatModelConfig{
		APIKey:      arkConfig.ApiKey,
		Model:       arkConfig.Endpoint[analysisModelKey],
		Temperature: &analysisTemp,
		MaxTokens:   &analysisMaxToken,
		Thinking: &model.Thinking{
			Type: model.ThinkingTypeEnabled, // 启用思考
		},
		ReasoningEffort: &reasoningEffort, // 中等推理 effort
	})
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] Init model service failed, err=%v", err)
		return nil, err
	}

	runScriptTool := tools.NewRunScriptTool()
	analysisReactAgent, err := react.NewAgent(ctx, &react.AgentConfig{
		ToolCallingModel: analysisModel,
		MaxStep:          30,
		ToolsConfig: compose.ToolsNodeConfig{
			Tools:               []tool.BaseTool{runScriptTool},
			UnknownToolsHandler: tools.UnknownToolsHandler,
		},
		StreamToolCallChecker: ai_infra_utils.StreamToolCallChecker,
		GraphName:             analysisGraphName,
		ModelNodeName:         analysisLambdaNodeKey,
	})
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] new diagnosis react agent failed, err=%v", err)
		return nil, err
	}

	analysisLambda := compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (output *schema.Message, err error) {
		option, feature := react.WithMessageFuture() // 获取消息future
		// 创建错误通道
		errChan := make(chan error, 1)

		// 在 goroutine 中调用react agent
		go func() {
			defer func() {
				if err := recover(); err != nil {
					logs.CtxError(ctx, "[addAnalysisAgent] analysisReactAgent.Stream panic err: %v", err)
				}
			}()

			_, err := analysisReactAgent.Stream(ctx, input, option)
			if err != nil {
				logs.CtxError(ctx, "[addAnalysisAgent] analysisReactAgent.Stream failed, err=%v", err)
				errChan <- err // 将错误发送到通道
				return
			}

			// 如果执行成功，发送 nil 表示没有错误
			errChan <- nil
		}()

		// 主线程等待 goroutine 完成并获取错误
		if err := <-errChan; err != nil {
			return nil, err
		}

		// 获取react agent历史消息
		ms := feature.GetMessageStreams()
		msgs := make([]*schema.Message, 0)
		for {
			frame, succ, _err := ms.Next()
			if _err != nil {
				logs.CtxError(ctx, "[addAnalysisAgent] ms.Next failed, err=%v", _err)
				return nil, _err
			}
			if !succ {
				break
			}

			msg, _err := schema.ConcatMessageStream(frame)
			if _err != nil {
				logs.CtxError(ctx, "[addAnalysisAgent] ConcatMessageStream failed, err=%v", _err)
				return nil, _err
			}
			msgs = append(msgs, msg)
		}

		if len(msgs) == 0 {
			logs.CtxError(ctx, "[addAnalysisAgent] msgs is empty")
			return nil, fmt.Errorf("analysis agent output msgs is empty")
		}

		var content string
		latestMsg := msgs[len(msgs)-1]
		toolMsgs, isOk := funk.Filter(msgs, func(msg *schema.Message) bool {
			return msg.Role == schema.Tool
		}).([]*schema.Message)
		if isOk && len(toolMsgs) > 0 {
			for _, toolMsg := range toolMsgs {
				var toolRes *tools.RunScriptRes
				if _err := sonic.UnmarshalString(toolMsg.Content, &toolRes); _err != nil || toolRes == nil || toolRes.Status != "success" || toolRes.Stdout == "" {
					continue
				}

				// 将工具调用结果添加到content中
				content += fmt.Sprintf("\n\n%s", toolRes.Stdout)
			}
		}

		content += fmt.Sprintf("\n\n%s", latestMsg.Content)
		msg := schema.AssistantMessage(content, nil)

		return msg, nil
	})

	err = g.AddLambdaNode(analysisInputNodeKey, analysisInputLambda, compose.WithNodeName(analysisInputNodeKey))
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] AddLambdaNode %s failed, err=%v", analysisInputNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(compose.START, analysisInputNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] AddEdge %s to %s failed, err=%v", compose.START, analysisInputNodeKey, err)
		return nil, err
	}
	err = g.AddChatTemplateNode(analysisTemplateNodeKey, analysisTemplate, compose.WithNodeName(analysisTemplateNodeKey))
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] AddChatTemplateNode %s failed, err=%v", analysisTemplateNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(analysisInputNodeKey, analysisTemplateNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] AddEdge %s to %s failed, err=%v", analysisInputNodeKey, analysisTemplateNodeKey)
		return nil, err
	}
	err = g.AddLambdaNode(analysisLambdaNodeKey, analysisLambda, compose.WithNodeName(analysisLambdaNodeKey))
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] AddLambdaNode %s failed, err=%v", analysisLambdaNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(analysisTemplateNodeKey, analysisLambdaNodeKey)
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] AddEdge %s to %s failed, err=%v", analysisTemplateNodeKey, analysisLambdaNodeKey, err)
		return nil, err
	}
	err = g.AddEdge(analysisLambdaNodeKey, compose.END)
	if err != nil {
		logs.CtxError(ctx, "[addAnalysisAgent] AddEdge %s to %s failed, err=%v", analysisLambdaNodeKey, compose.END, err)
		return nil, err
	}
	return g, nil
}
