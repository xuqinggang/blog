package sku_cluster_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/attribution_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	sku_cluster "code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"context"
)

type ISkuClusterService interface {
	GetSkuClusterCommonMultiDimFullList(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterCommonMultiDimData, err error)
	GetSkuClusterCommonMultiDimFullListDownload(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp bool, err error)
	GetSkuClusterCommonCoreOverview(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterCommonCoreOverviewData, err error)
	GetSkuClusterFlowTrend(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterFlowTrendData, err error)
	GetSkuClusterCommonMultiDimTrend(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *analysis.GetProductAnalysisMultiDimTrendData, err error)
	GetSkuClusterStabilityMultiDimFullList(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterStabilityData, err error)
	GetSkuClusterStabilityMultiDimFullListDownload(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp bool, err error)
}

type SkuClusterService struct {
	DimensionListDao   dao.IDimensionListDao
	DimensionEnumDao   dao.IDimensionEnumDao
	AttributeDao       dao.IAttributeDao
	DimensionService   dimension_service.IDimensionService
	AnalysisService    analysis_service.IAnalysisService
	AttributionService attribution_service.IAttributionService
}

const (
	ApiPathSkuClusterFlowTrendCluster = "7461982046185866278"
	ApiPathSkuClusterFlowTrendProduct = "7462366221774636059"
	ApiPathSkuClusterFlowTrendSku     = "7462367529177039910"
)

var overviewApiMap = map[dimensions.BizType]string{
	dimensions.BizType_SkuClusterBasicConstitution: "7469616625587684379", // 基本构成
	dimensions.BizType_SkuClusterSupplyInsight:     "7469616843481760806", // 供给洞察
	dimensions.BizType_SkuClusterFlowInsight:       "7469617109979513906", // 流量与效率
}

type FlowParam struct {
	Name      string
	ApiPath   string
	Dimension string
	FlowType  int64
	SearchStr string
	GroupStr  string
}

type DimensionFlow struct {
	FlowType     int64
	Value        int
	Name         string
	DisplayOrder int
	IsNumerator  bool
	IsRateType   bool
}

var FlowTargetMap = map[sku_cluster.FlowLayerTarget]string{
	sku_cluster.FlowLayerTarget_ShowPv:  "prod_show_pv",
	sku_cluster.FlowLayerTarget_OderCnt: "prod_order_cnt",
	sku_cluster.FlowLayerTarget_Gmv:     "prod_gmv",
}

var FlowParamMap = map[int64]*FlowParam{
	2:  {"全量簇", ApiPathSkuClusterFlowTrendCluster, "", 2, "", ""},
	3:  {"有/无优价sku的簇", ApiPathSkuClusterFlowTrendCluster, "have_good_price_sku", 3, "if(sum(is_good_price_sku)>0,1,0) as have_good_price_sku", ""},
	5:  {"有/无优价商品的簇", ApiPathSkuClusterFlowTrendCluster, "have_good_price_prod", 5, "if(sum(is_good_price_prod)>0,1,0) as have_good_price_prod", ""},
	9:  {"量价模型簇", ApiPathSkuClusterFlowTrendCluster, "is_seed_pool_cluster", 9, "is_seed_pool_cluster", "is_seed_pool_cluster"},
	10: {"有扶持商品的簇", ApiPathSkuClusterFlowTrendCluster, "have_boost_prod", 10, "if(sum(is_boost_prod)>0,1,0) as have_boost_prod", ""},
	14: {"大链接商品簇", ApiPathSkuClusterFlowTrendCluster, "is_agg_link_cluster", 14, "is_agg_link_cluster", "is_agg_link_cluster"},
	18: {"簇内扶持商品流量占比>50%", ApiPathSkuClusterFlowTrendCluster, "is_show_pv_more_than_50", 18, "is_show_pv_more_than_50", "is_show_pv_more_than_50"},

	1:  {"全量商品", ApiPathSkuClusterFlowTrendProduct, "", 1, "", ""},
	6:  {"簇内优价/非优价商品", ApiPathSkuClusterFlowTrendProduct, "is_good_price_prod", 6, "is_good_price_prod", "is_good_price_prod"},
	15: {"簇内扶持/非扶持商品", ApiPathSkuClusterFlowTrendProduct, "is_boost_prod", 15, "is_boost_prod", "is_boost_prod"},

	4: {"簇内优价/非优价sku", ApiPathSkuClusterFlowTrendSku, "is_good_price_sku", 4, "is_good_price_sku", "is_good_price_sku"},
}

var FlowLogicMap = map[string]map[string]*DimensionFlow{
	"GoodPrice":   goodPrice,
	"VolumePrice": volumePrice,
	"BigLink":     bigLink,
}

var goodPrice = map[string]*DimensionFlow{
	"全量商品":       {1, -1, "全量商品", 1, false, false},
	"全量簇":        {2, -1, "全量簇", 2, false, false},
	"有优价sku的簇":   {3, 1, "有优价sku的簇", 3, true, false},
	"无优价sku的簇":   {3, 0, "无优价sku的簇", 3, false, false},
	"有优价sku的簇占比": {3, 100, "有优价sku的簇占比", 3, false, true},

	"簇内优价sku":   {4, 1, "簇内优价sku", 4, true, false},
	"簇内非优价sku":  {4, 0, "簇内非优价sku", 4, false, false},
	"簇内优价sku占比": {4, 100, "簇内优价sku占比", 4, false, true},

	"有优价商品的簇":   {5, 1, "有优价商品的簇", 5, true, false},
	"无优价商品的簇":   {5, 0, "无优价商品的簇", 5, false, false},
	"有优价商品的簇占比": {5, 100, "有优价商品的簇占比", 5, false, true},

	"簇内优价商品":   {6, 1, "簇内优价商品", 7, true, false},
	"簇内非优价商品":  {6, 0, "簇内非优价商品", 7, false, false},
	"簇内优价商品占比": {6, 100, "簇内优价商品占比", 7, false, true},
}

var volumePrice = map[string]*DimensionFlow{
	//"比价池":     {7, 1, "比价池", 1}, 暂不支持
	//"种子池及同款":  {8, 1, "种子池及同款", 2}, 暂不支持
	"量价模型簇":   {9, 1, "量价模型簇", 1, false, false},
	"有扶持商品的簇": {10, 1, "有扶持商品的簇", 2, false, false},
	"簇内商品":    {1, -1, "簇内商品", 3, false, false},
	"簇内优价商品":  {6, 1, "簇内优价商品", 4, false, false},
	"簇内非优价商品": {6, 0, "簇内非优价商品", 5, false, false},
}

var bigLink = map[string]*DimensionFlow{
	"大链接商品簇":         {14, 1, "大链接商品簇", 1, false, false},
	"有扶持商品簇":         {10, 1, "有扶持商品簇", 2, false, false},
	"簇内扶持商品":         {15, 1, "簇内扶持商品", 3, false, false},
	"簇内其他商品":         {15, 0, "簇内其他商品", 4, false, false},
	"簇内扶持商品流量占比>50%": {18, 1, "簇内扶持商品流量占比>50%", 5, false, false},
}
