package sku_cluster_service

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"context"
)

func (s *SkuClusterService) GetSkuClusterCommonMultiDimTrend(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *analysis.GetProductAnalysisMultiDimTrendData, err error) {
	resp = analysis.NewGetProductAnalysisMultiDimTrendData()
	allTotal, err := s.AnalysisService.GetProductAnalysisMultiDimTrend(ctx, &analysis.GetProductAnalysisBaseRequest{
		BaseReq:   req.BaseReq,
		NeedTrend: true,
		IsTotal:   true,
	})
	if err != nil {
		return resp, err
	}
	res, err := s.AnalysisService.GetProductAnalysisMultiDimTrend(ctx, &analysis.GetProductAnalysisBaseRequest{
		BaseReq:   req.BaseReq,
		NeedTrend: true,
		IsTotal:   false,
	})
	if err != nil {
		return resp, err
	}
	if len(allTotal) > 0 {
		totals := make([]*analysis.GetProductAnalysisMultiDimTrendInfo, 0)
		for _, item := range allTotal {
			trendPoint := &analysis.GetProductAnalysisMultiDimTrendInfo{
				TargetList: item.TargetList,
				EnumValue:  "全量不被匹配的整体",
				TargetName: item.TargetName,
			}
			totals = append(totals, trendPoint)
		}
		resp.TrendList = append(totals, res...)
	} else {
		resp.TrendList = res
	}
	return resp, err
}
