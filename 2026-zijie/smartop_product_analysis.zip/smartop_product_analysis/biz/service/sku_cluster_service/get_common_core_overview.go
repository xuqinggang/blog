package sku_cluster_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/attribution_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

func (s *SkuClusterService) GetSkuClusterCommonCoreOverview(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterCommonCoreOverviewData, err error) {
	resp = &sku_cluster.GetSkuClusterCommonCoreOverviewData{}
	resp.TargetList = make([]*analysis.TargetCardEntity, 0)
	isShowCompare := true
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	if apiPath, ok := overviewApiMap[req.BaseReq.BizType]; ok {
		bizInfo.TargetCardApiID = apiPath
	} else {
		err = errors.New("业务线信息填写有误")
		return resp, err
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	ctx = context.WithValue(ctx, consts.CtxAllDatePoolFlag, "异动归因核心指标")
	syncType := analysis.SyncType_NotNeed
	attributionCommonBaseStruct := &analysis.AttributionCommonBaseStruct{
		BizType:          req.BaseReq.BizType,
		StartDate:        req.BaseReq.StartDate,
		EndDate:          req.BaseReq.EndDate,
		CompareStartDate: req.BaseReq.CompareStartDate,
		CompareEndDate:   req.BaseReq.CompareEndDate,
		Dimensions:       req.BaseReq.Dimensions,
		GroupAttrs:       req.BaseReq.GroupAttrs,
		ThresholdAttrs:   req.BaseReq.ThresholdAttrs,
		ThresholdExpr:    req.BaseReq.ThresholdExpr,
		NeedTrend:        req.NeedTrend,
		SyncType:         &syncType,
	}
	osReq := base_struct_condition.AttributionOsParamsReq{
		BaseStruct: attributionCommonBaseStruct,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	}
	// 获取invoker的入参
	curr, compare, trend, compareTrend, err := base_struct_condition.GetAttributionStructConditionParams(ctx, osReq)
	observeDate, _ := time_utils.GetAddDate(req.BaseReq.StartDate, 1)
	compareObserveDate, _ := time_utils.GetAddDate(req.BaseReq.CompareStartDate, 1)
	curr["stat_date"] = req.BaseReq.StartDate
	curr["observe_date"] = observeDate
	compare["stat_date"] = req.BaseReq.CompareStartDate
	compare["observe_date"] = compareObserveDate

	trend["stat_date"] = req.BaseReq.StartDate
	trend["observe_date"] = observeDate
	compareTrend["stat_date"] = req.BaseReq.CompareStartDate
	compareTrend["observe_date"] = compareObserveDate
	compareTrend["is_trend"] = 1
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	var currTargetList, compareTargetList, cycleTargetList, syncTargetList []*base_struct_condition.KeyColsTargetEntity
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		currTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return err
		}
		return nil
	})

	cc.GoV2(func() error {
		compareTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compare, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return err
		}
		return nil
	})

	// 此时对比时间和环比不重叠，需要展示对比周期值
	if isShowCompare {
		cycleStartDate, cycleEndDate, err := time_utils.GetCycleStartEndDate(req.BaseReq.StartDate, req.BaseReq.EndDate)
		if err != nil {
			return nil, err
		}
		cycleOsReq := attribution_service.GenOsReqWithNewDate(osReq, cycleStartDate, cycleEndDate)
		cc.GoV2(func() error {
			cycle, err := base_struct_condition.GetAttributionStructConditionParam(ctx, cycleOsReq, base_struct_condition.SQLCalcType_Curr)
			observeDate, _ := time_utils.GetAddDate(cycleStartDate, 1)
			cycle["stat_date"] = cycleStartDate
			cycle["observe_date"] = observeDate
			if err != nil {
				return err
			}
			cycleTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: cycle, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
				KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
			})
			if err != nil {
				return err
			}
			return nil
		})
	}
	// 同比周期数据
	if attributionCommonBaseStruct.SyncType != nil && *attributionCommonBaseStruct.SyncType != analysis.SyncType_NotNeed {
		syncStartDate, syncEndDate, err := time_utils.GetSyncDate(req.BaseReq.StartDate, req.BaseReq.EndDate, *attributionCommonBaseStruct.SyncType)
		if err != nil {
			return nil, err
		}
		syncOsReq := attribution_service.GenOsReqWithNewDate(osReq, syncStartDate, syncEndDate)
		cc.GoV2(func() error {
			sync, err := base_struct_condition.GetAttributionStructConditionParam(ctx, syncOsReq, base_struct_condition.SQLCalcType_Curr)

			if err != nil {
				return err
			}
			syncTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: sync, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
				KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
			})
			if err != nil {
				return err
			}
			return nil
		})
	}

	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionCommonCoreOverview]并发对象wait失败, err:"+err.Error())
		return nil, err
	}
	currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumn(currTargetList, compareTargetList, cycleTargetList, syncTargetList)

	// 是否需要趋势图
	if req.GetNeedTrend() {
		trendCol := "date"
		//if req.BaseReq.BizType == dimensions.BizType_SkuClusterScaleAndMount ||
		//	req.BaseReq.BizType == dimensions.BizType_SkuClusterCoverage ||
		//	req.BaseReq.BizType == dimensions.BizType_SkuClusterStability ||
		//	req.BaseReq.BizType == dimensions.BizType_SkuClusterSupplyQuality {
		//	trendCol = "dimension"
		//}
		trendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: trend, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, KeyCols: []string{}, TrendCol: trendCol, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return nil, err
		}
		currTargetList = base_struct_condition.AddTargetTrend(currTargetList, trendMap)

		compareTrendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compareTrend, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, KeyCols: []string{}, TrendCol: trendCol, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return nil, err
		}
		currTargetList = base_struct_condition.AddCompareTargetTrend(currTargetList, compareTrendMap)
	}

	if len(currTargetList) == 0 {
		return resp, nil
	}
	resData := currTargetList[0].TargetEntity
	analysis_service.SortTargetCardEntity(resData)

	targetMeta, err := dao.GetTargetMetaInfo(ctx, int64(req.BaseReq.BizType), false, []string{"指标卡", "商品明细"})
	if err != nil {
		return nil, err
	}
	var targetMetaMap = make(map[string]*dao.TargetMetaInfo)
	for _, info := range targetMeta {
		targetMetaMap[info.Name] = info
	}

	err = attribution_service.AddDiff(ctx, resData, targetMetaMap)
	if err != nil {
		return nil, err
	}
	resp.TargetList = resData
	targetThrMap, err := biz_info.GetTccAttributionTargetThresholdMap(ctx)
	if err != nil {
		return nil, err
	}
	for _, i := range resp.TargetList {
		// 读取不到时，默认阈值为20%
		incrThr := int64(20)
		if thr, exist := targetThrMap[i.Name]; exist {
			incrThr = thr
		}
		extr := i.Extra
		if extr == nil {
			continue
		}

		extr.TargetTag = consts.Empty
		tempReq := &analysis.GetAttributionCommonBaseRequest{
			BaseReq: attributionCommonBaseStruct,
		}
		if i.Value == i.CycleValue {
			extr.TargetTag = "hidden"
		} else if attribution_service.AddTargetTag(i.CycleChangeRatio, incrThr, tempReq, extr.IsLargerAdvantage) {
			extr.TargetTag = "focus_on"
		}

		//if len(i.SubTargetList) > 0 {
		//	for _, subT := range i.SubTargetList {
		//		if attribution_service.AddTargetTag(subT.DiffBaseRatio, incrThr, req, extr.IsLargerAdvantage) {
		//			for _, prefix := range SubTargetPrefixMeta {
		//				if strings.HasPrefix(subT.Name, prefix.prefix) {
		//					subT.TargetTag = "focus_on"
		//					break
		//				}
		//			}
		//		}
		//	}
		//}
	}

	attribution_service.AddTagByBizType(attributionCommonBaseStruct, resp.TargetList)
	//}
	return resp, nil
}
