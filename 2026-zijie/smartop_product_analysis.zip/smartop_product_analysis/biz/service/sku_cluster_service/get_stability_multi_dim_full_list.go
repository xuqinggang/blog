package sku_cluster_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"code.byted.org/gopkg/logs"
	"context"
)

func (s *SkuClusterService) GetSkuClusterStabilityMultiDimFullList(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterStabilityData, err error) {
	resp = sku_cluster.NewGetSkuClusterStabilityData()
	resp.ColList = make([]*sku_cluster.GetSkuClusterStabilityPeriodCol, 0)
	if req.StabilityParam != nil && len(req.StabilityParam.StatCycles) > 0 && req.StabilityParam.StatDate != nil {
		cc := co.NewConcurrent(ctx)
		for _, statCycle := range req.StabilityParam.StatCycles {
			_statCycle := statCycle
			cc.GoV2(func() error {
				observeDate := ""
				if _statCycle == sku_cluster.StabilityType_T_1 { // t+1
					observeDate, _ = time_utils.GetAddDate(req.StabilityParam.GetStatDate(), 1)
				} else if _statCycle == sku_cluster.StabilityType_T_7 { // t+7
					observeDate, _ = time_utils.GetAddDate(req.StabilityParam.GetStatDate(), 7)
				} else if _statCycle == sku_cluster.StabilityType_T_14 { // t+14
					observeDate, _ = time_utils.GetAddDate(req.StabilityParam.GetStatDate(), 14)
				} else if _statCycle == sku_cluster.StabilityType_T_30 { // t+30
					observeDate, _ = time_utils.GetAddDate(req.StabilityParam.GetStatDate(), 30)
				}
				resData, err := s.getCommonData(ctx, req, req.StabilityParam.GetStatDate(), observeDate)
				col := &sku_cluster.GetSkuClusterStabilityPeriodCol{
					PeriodName: _statCycle.String(),
					Data:       resData,
				}
				resp.ColList = append(resp.ColList, col)
				return err
			})
		}
		err = cc.WaitV2()
		if err != nil {
			logs.CtxError(ctx, "getTrendMap err=%v", err)
			return nil, err
		}
	}
	return resp, err
}

func (s *SkuClusterService) getCommonData(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest, statDate, observeDate string) (
	*sku_cluster.GetSkuClusterCommonMultiDimData, error) {

	resData := &sku_cluster.GetSkuClusterCommonMultiDimData{}
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		appendParams := analysis_service.AppendParams{
			OSParams: make(map[string]interface{}, 0),
		}
		appendParams.OSParams["stat_date"] = statDate
		appendParams.OSParams["observe_date"] = observeDate
		appendParams.IsAllTotal = true
		allTotal, err := s.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
			BaseReq:  req.BaseReq,
			NeedIncr: req.GetNeedCycle(),
		}, appendParams)
		if err != nil {
			logs.CtxError(ctx, "GetSkuClusterStabilityMultiDimFullList err=%v", err)
			return err
		}
		resData.FullClusterList, err = TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, allTotal.AllTotal.DimKey, allTotal.AllTotal.EnumValue, allTotal.AllTotal.TargetList)
		for _, childRow := range allTotal.AllTotal.Children {
			childRowRes, _ := TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, childRow.DisplayName, childRow.EnumValue, childRow.TargetList)
			resData.FullClusterList.ChildRows = append(resData.FullClusterList.ChildRows, childRowRes)
		}
		if err != nil {
			return err
		}
		return nil
	})
	cc.GoV2(func() error {
		appendParams2 := analysis_service.AppendParams{
			OSParams: make(map[string]interface{}, 0),
		}
		appendParams2.OSParams["stat_date"] = statDate
		appendParams2.OSParams["observe_date"] = observeDate
		appendParams2.IsAllTotal = false
		res, err := s.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
			BaseReq:  req.BaseReq,
			NeedIncr: req.GetNeedCycle(),
		}, appendParams2)
		if err != nil {
			return err
		}
		for _, row := range res.FullList {
			rowRes, _ := TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, row.DisplayName, row.EnumValue, row.TargetList)
			rowRes.ChildRows = make([]*sku_cluster.GetSkuClusterCommonMultiDimRow, 0)
			for _, childRow := range row.Children {
				childRowRes, _ := TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, childRow.DisplayName, childRow.EnumValue, childRow.TargetList)
				for _, ccRow := range childRow.Children {
					ccChild, _ := TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, ccRow.DisplayName, ccRow.EnumValue, ccRow.TargetList)
					childRowRes.ChildRows = append(rowRes.ChildRows, ccChild)
				}
				rowRes.ChildRows = append(rowRes.ChildRows, childRowRes)
			}
			resData.RowList = append(resData.RowList, rowRes)
		}
		return nil
	})
	err := cc.WaitV2()
	if err != nil {
		return resData, err
	}
	return resData, nil
}
