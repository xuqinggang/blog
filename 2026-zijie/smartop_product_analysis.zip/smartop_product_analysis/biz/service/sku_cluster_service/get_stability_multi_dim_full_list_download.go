package sku_cluster_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"strings"
)

func (s *SkuClusterService) GetSkuClusterStabilityMultiDimFullListDownload(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangruiwen.raven@bytedance.com"
	}

	// 获取所有的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取分析的维度信息
	groupCols := make([]*dao.DimensionInfo, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		groupCols = append(groupCols, dimInfo)
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := s.GetSkuClusterStabilityMultiDimFullList(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}

	table, targetList := respToTable(ctx, groupCols, coreRet.ColList)
	f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genGetMultiDimFullTable, param.SinkTable("core_data"))
	f.ExeCustom([]param.Source{param.SourceTable("core_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(targetList), param.SourceConst(groupCols)}, doExportGetMultiDimFullData, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, err
}

func respToTable(ctx context.Context, groupCols []*dao.DimensionInfo, col []*sku_cluster.GetSkuClusterStabilityPeriodCol) ([]map[string]interface{}, []string) {
	excelColNames := make([]string, 0)
	// 获取所有的列名字
	// 维度列
	dimColNames := make([]string, 0)
	for _, groupCol := range groupCols {
		//excelColNames = append(excelColNames, groupCol.DimColumn)
		dimColNames = append(dimColNames, groupCol.DimColumn)
	}
	// 指标列
	table := make([]map[string]interface{}, 0)
	// 更新指标名
	updateTargetDisplayName(ctx, col)
	// 整体数据
	for _, colData := range col {
		_, _, targets := getAllTargetsFromRow(ctx, colData.Data.FullClusterList)
		for _, target := range targets {
			excelColNames = append(excelColNames, target.GetDisplayName())
		}
	}
	rows := make([][]*sku_cluster.GetSkuClusterCommonMultiDimRow, 0)
	for _, colData := range col {
		allRows := []*sku_cluster.GetSkuClusterCommonMultiDimRow{colData.Data.FullClusterList}
		allRows = append(allRows, colData.Data.RowList...)
		rows = append(rows, allRows) //colData.Data.RowList)
	}
	resRows := appendRowData(ctx, rows)
	for _, row := range resRows {
		table = append(table, fillTableCol(ctx, dimColNames, nil, row)...)
	}
	return table, excelColNames
}
func fillTableCol(ctx context.Context, dimColNames []string, existGroupRecord map[string]string, row *sku_cluster.GetSkuClusterCommonMultiDimRow) []map[string]interface{} {
	dimensionName, enumValue, targets := getAllTargetsFromRow(ctx, row)
	if strings.Contains(enumValue, "整体") {
		dimensionName = "全部簇"
	}
	table := make([]map[string]interface{}, 0)
	record := map[string]interface{}{}
	newDimRecord := make(map[string]string)
	for i, dimColName := range dimColNames {
		if val, ok := existGroupRecord[dimColName]; ok {
			record[dimColName] = val
			newDimRecord[dimColName] = val
		} else if len(existGroupRecord) == i {
			record[dimColName] = dimensionName
			newDimRecord[dimColName] = dimensionName
		} else {
			record[dimColName] = "-"
		}
	}
	for _, target := range targets {
		record[target.GetDisplayName()] = target.GetDisplayValue()
	}
	table = append(table, record)
	for _, childRow := range row.ChildRows {
		table = append(table, fillTableCol(ctx, dimColNames, newDimRecord, childRow)...)
	}
	return table
}

func appendRowData(ctx context.Context, rows [][]*sku_cluster.GetSkuClusterCommonMultiDimRow) []*sku_cluster.GetSkuClusterCommonMultiDimRow {
	// 总行数
	rowNumber := 0
	if len(rows) > 0 && len(rows[0]) != 0 {
		rowNumber = len(rows[0])
	}
	resRows := make([]*sku_cluster.GetSkuClusterCommonMultiDimRow, rowNumber)
	for i := 0; i < rowNumber; i++ {
		resRows[i] = &sku_cluster.GetSkuClusterCommonMultiDimRow{
			DimensionName: "",
			FullGroupList: make([]*sku_cluster.GetSkuClusterCommonTargetGroup, 0),
			ChildRows:     make([]*sku_cluster.GetSkuClusterCommonMultiDimRow, 0),
			EnumValue:     "",
		}
		childRows := make([][]*sku_cluster.GetSkuClusterCommonMultiDimRow, 0)
		for _, colData := range rows {
			resRows[i].DimensionName = colData[i].DimensionName
			resRows[i].EnumValue = colData[i].EnumValue
			resRows[i].FullGroupList = append(resRows[i].FullGroupList, colData[i].FullGroupList...)
			if len(colData[i].ChildRows) > 0 {
				childRows = append(childRows, colData[i].ChildRows)
			}
		}
		if len(childRows) > 0 {
			resRows[i].ChildRows = appendRowData(ctx, childRows)
		}
	}
	return resRows
}

func getAllTargetsFromRow(ctx context.Context, row *sku_cluster.GetSkuClusterCommonMultiDimRow) (
	dimensionName, enumValue string, targets []*analysis.TargetCardEntity) {
	targets = make([]*analysis.TargetCardEntity, 0)
	for _, targetGroup := range row.FullGroupList {
		for _, target := range targetGroup.TargetList {
			targets = append(targets, target)
		}
	}
	return row.DimensionName, row.EnumValue, targets
}

func updateTargetDisplayName(ctx context.Context, col []*sku_cluster.GetSkuClusterStabilityPeriodCol) {
	for _, colData := range col {
		prefixName := colData.PeriodName
		updateAllTargetsFromRow(ctx, prefixName, []*sku_cluster.GetSkuClusterCommonMultiDimRow{colData.Data.FullClusterList})
		updateAllTargetsFromRow(ctx, prefixName, colData.Data.RowList)
	}
}

func updateAllTargetsFromRow(ctx context.Context, prefixName string, rows []*sku_cluster.GetSkuClusterCommonMultiDimRow) {
	for _, row := range rows {
		for _, targetGroup := range row.FullGroupList {
			for _, target := range targetGroup.TargetList {
				// 变更下指标名
				target.DisplayName = prefixName + "_" + target.DisplayName
			}
		}
		updateAllTargetsFromRow(ctx, prefixName, row.ChildRows)
	}
}
