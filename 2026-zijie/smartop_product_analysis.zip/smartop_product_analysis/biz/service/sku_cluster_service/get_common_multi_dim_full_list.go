package sku_cluster_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"code.byted.org/gopkg/logs"
	"context"
)

func (s *SkuClusterService) GetSkuClusterCommonMultiDimFullList(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterCommonMultiDimData, err error) {

	resp = sku_cluster.NewGetSkuClusterCommonMultiDimData()
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		appendParams := analysis_service.AppendParams{
			OSParams: make(map[string]interface{}, 0),
		}
		appendParams.IsAllTotal = true
		allTotal, err := s.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
			BaseReq:  req.BaseReq,
			NeedIncr: req.GetNeedCycle(),
		}, appendParams)
		if err != nil {
			return err
		}
		resp.FullClusterList, err = TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, allTotal.AllTotal.DimKey, allTotal.AllTotal.EnumValue, allTotal.AllTotal.TargetList)
		for _, childRow := range allTotal.AllTotal.Children {
			childRowRes, _ := TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, childRow.DisplayName, childRow.EnumValue, childRow.TargetList)
			resp.FullClusterList.ChildRows = append(resp.FullClusterList.ChildRows, childRowRes)
		}
		if err != nil {
			return err
		}
		return nil
	})
	cc.GoV2(func() error {
		appendParams := analysis_service.AppendParams{
			OSParams: make(map[string]interface{}, 0),
		}
		appendParams.IsAllTotal = false
		res, err := s.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
			BaseReq:  req.BaseReq,
			NeedIncr: req.GetNeedCycle(),
		}, appendParams)
		if err != nil {
			return err
		}
		for _, row := range res.FullList {
			rowRes, _ := TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, row.DisplayName, row.EnumValue, row.TargetList)
			rowRes.ChildRows = make([]*sku_cluster.GetSkuClusterCommonMultiDimRow, 0)
			for _, childRow := range row.Children {
				childRowRes, _ := TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, childRow.DisplayName, childRow.EnumValue, childRow.TargetList)
				childRowRes.ChildRows = make([]*sku_cluster.GetSkuClusterCommonMultiDimRow, 0)
				for _, ccRow := range childRow.Children {
					ccr, _ := TargetGroupToMultiDimRow(ctx, req.BaseReq.BizType, ccRow.DisplayName, ccRow.EnumValue, ccRow.TargetList)
					childRowRes.ChildRows = append(childRowRes.ChildRows, ccr)
				}
				rowRes.ChildRows = append(rowRes.ChildRows, childRowRes)
			}
			resp.RowList = append(resp.RowList, rowRes)
		}
		return nil
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "getTrendMap err=%v", err)
		return nil, err
	}
	return resp, err
}

// TargetGroupToMultiDimRow 指标分组
func TargetGroupToMultiDimRow(ctx context.Context, bizType dimensions.BizType, dimensionName, enumValue string, midTargets []*analysis.TargetCardEntity) (multiDimRow *sku_cluster.GetSkuClusterCommonMultiDimRow, err error) {
	targetMetaMap, err := base_struct_condition.GetTargetMetaInfoMap(ctx, int64(bizType), false)
	if err != nil {
	}
	multiDimRow = sku_cluster.NewGetSkuClusterCommonMultiDimRow()
	multiDimRow.DimensionName = dimensionName
	multiDimRow.EnumValue = enumValue
	multiDimRow.FullGroupList = make([]*sku_cluster.GetSkuClusterCommonTargetGroup, 0)
	midTargetMap := make(map[string][]*analysis.TargetCardEntity, 0)
	for _, target := range midTargets {
		if targetInfo, ok := targetMetaMap[target.Name]; ok { // 指标分组
			if _, ok1 := midTargetMap[targetInfo.AttributeType]; ok1 {
				midTargetMap[targetInfo.AttributeType] = append(midTargetMap[targetInfo.AttributeType], target)
			} else {
				midTargetMap[targetInfo.AttributeType] = []*analysis.TargetCardEntity{target}
			}
		}
	}
	for key, targetList := range midTargetMap {
		targetGroup := sku_cluster.NewGetSkuClusterCommonTargetGroup()
		targetGroup.GroupName = key
		targetGroup.TargetList = targetList
		multiDimRow.FullGroupList = append(multiDimRow.FullGroupList, targetGroup)
	}
	return multiDimRow, nil
}
