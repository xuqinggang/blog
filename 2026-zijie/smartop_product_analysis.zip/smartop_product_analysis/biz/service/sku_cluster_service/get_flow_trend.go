package sku_cluster_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/mohae/deepcopy"
	"strconv"
)

func (s *SkuClusterService) GetSkuClusterFlowTrend(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterFlowTrendData, err error) {
	resp = sku_cluster.NewGetSkuClusterFlowTrendData()
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	//if len(req.BaseReq.GroupAttrs) == 0 {
	//	return nil, errors.New("获取多维分析参数失败")
	//}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	// 获取分析的维度信息
	var groupCol string
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		if attr.NeedDrillDown {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
			}
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
	}
	//if len(groupCol) == 0 {
	//	logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
	//	return resp, errors.New("多维分析未传入多维配置")
	//}

	groupCols := utils.If(false, []string{}, []string{groupCol})
	osReq := base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: groupCols,
	}

	_, _, trend, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	if err != nil {
		return
	}
	if req.FlowParam == nil || req.FlowParam.FlowLayer == nil {
		return nil, errors.New("未传入流量分层参数")
	}
	layerMap := FlowLogicMap[req.FlowParam.FlowLayer.String()]
	flowTypeMap := make(map[int64]*FlowParam, 0)

	flowTypeResult := make(map[int64]map[string]map[string][]*analysis.TargetTrendPoint, 0)
	for _, config := range layerMap {
		if flowP, ok := FlowParamMap[config.FlowType]; ok {
			flowTypeMap[config.FlowType] = flowP
		}
	}
	cc := co.NewConcurrent(ctx)
	for _, flowP := range flowTypeMap {
		_flowP := flowP
		cc.GoV2(func() error {
			trendMap, err := getTrendMap(ctx, trend, _flowP, req.BaseReq.BizType)
			flowTypeResult[_flowP.FlowType] = trendMap
			return err
		})
	}
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "getTrendMap err=%v", err)
		return nil, err
	}
	target := FlowTargetMap[*req.FlowParam.FlowLayerTarget]
	resp, err = dealResult(ctx, target, layerMap, flowTypeResult)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func getTrendMap(ctx context.Context, trendP map[string]interface{}, flowP *FlowParam, bizType dimensions.BizType) (
	trendMap map[string]map[string][]*analysis.TargetTrendPoint, err error) {
	tempParam := deepcopy.Copy(trendP).(map[string]interface{})
	groupCols := make([]string, 0)
	if flowP.Dimension != "" {
		tempParam["dimension"] = flowP.Dimension
		groupCols = []string{flowP.Dimension}
	} else {
		delete(tempParam, "dimension")
	}
	if flowP.SearchStr != "" {
		tempParam["search_str"] = flowP.SearchStr
	}
	if flowP.GroupStr != "" {
		tempParam["group_str"] = flowP.GroupStr
	}
	tempParam["flow_type"] = flowP.FlowType
	trendMap, err = base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: tempParam, Sql: consts.Empty, ApiPath: flowP.ApiPath, BizType: bizType, KeyCols: groupCols, TrendCol: "date",
	})
	return trendMap, err
}

func dealResult(ctx context.Context, targetName string, layer map[string]*DimensionFlow, result map[int64]map[string]map[string][]*analysis.TargetTrendPoint) (data *sku_cluster.GetSkuClusterFlowTrendData, err error) {
	res := make(map[int64][]*analysis.TargetCardEntity, 0)
	fenziMap := make(map[int64]*analysis.TargetCardEntity, 0)
	data = &sku_cluster.GetSkuClusterFlowTrendData{}
	for dimensionName, info := range layer {
		flowP := FlowParamMap[info.FlowType]
		flowRes := result[flowP.FlowType]
		targetCardEntity := &analysis.TargetCardEntity{}
		targetMap := make(map[string][]*analysis.TargetTrendPoint, 0)
		if info.Value != -1 {
			targetMap = flowRes[strconv.FormatInt(int64(info.Value), 10)]
		} else {
			for _, v := range flowRes {
				targetMap = v
				break
			}
		}
		if len(targetMap) == 0 { // 类型数据单独处理
			continue
		}
		if trend, ok := targetMap[targetName]; ok {
			targetCardEntity.Name = dimensionName
			targetCardEntity.DisplayName = dimensionName
			targetCardEntity.TrendData = trend
		}
		if info.IsNumerator {
			fenziMap[flowP.FlowType] = targetCardEntity
		}
		if _, ok := res[flowP.FlowType]; ok {
			res[flowP.FlowType] = append(res[flowP.FlowType], targetCardEntity)
		} else {
			res[flowP.FlowType] = []*analysis.TargetCardEntity{targetCardEntity}
		}
	}
	// 处理占比指标
	for _, info := range layer {
		if !info.IsRateType {
			continue
		}
		if len(res[info.FlowType]) != 2 {
			continue
		}
		fenzi := fenziMap[info.FlowType]
		pointMap := make(map[string]*analysis.TargetTrendPoint, 0)
		for _, point := range fenzi.TrendData {
			pointMap[point.X] = point
		}
		trendData1, trendData2 := res[info.FlowType][0].TrendData, res[info.FlowType][1].TrendData
		trendPoints := make([]*analysis.TargetTrendPoint, 0)
		for _, point := range trendData1 {
			tempPoint := deepcopy.Copy(point).(*analysis.TargetTrendPoint)
			for _, point2 := range trendData2 {
				if point.X == point2.X {
					if point2.Value+point.Value == 0 {
						tempPoint.Value = 0
						tempPoint.DisplayValue = "0"
						tempPoint.Percent = 0
						tempPoint.DisplayName = fmt.Sprintf("%s-占比", tempPoint.DisplayName)
					} else {
						value := pointMap[point.X].Value / (point2.Value + point.Value)
						tempPoint.Value = value
						tempPoint.DisplayValue = fmt.Sprintf("%.2f%%", value*100)
						tempPoint.Percent = value
						tempPoint.DisplayName = fmt.Sprintf("%s-占比", tempPoint.DisplayName)
					}
				}
			}
			trendPoints = append(trendPoints, tempPoint)
		}
		targetCardEntity := &analysis.TargetCardEntity{}
		targetCardEntity.Name = info.Name
		targetCardEntity.DisplayName = info.Name
		targetCardEntity.TrendData = trendPoints
		extra := analysis.TargetCardExtraInfo{}
		extra.PercentFlag = true
		targetCardEntity.Extra = &extra
		res[info.FlowType] = append(res[info.FlowType], targetCardEntity)
	}
	sortList := make([]int64, len(layer)+1)
	for _, info := range layer {
		sortList[info.DisplayOrder] = info.FlowType
	}
	for _, flowType := range sortList {
		if flowType == 0 {
			continue
		}
		dimension := sku_cluster.GetSkuClusterFlowDimension{}
		dimension.DimensionName = FlowParamMap[flowType].Name
		dimension.TargetList = res[flowType]
		data.DimensionTrends = append(data.DimensionTrends, &dimension)
	}
	return data, err
}
