package template_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"context"
)

func (t *TemplateService) CreateTemplate(ctx context.Context, req *dimensions.CreateOrUpdateTemplateRequest) (resp *dimensions.CreateOrUpdateTemplateResponse, err error) {
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, errors.New("获取数据库的事务失败")
	}
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		tx.Rollback()
		return nil, err
	}
	templateId, st, err := dao.CreateTemplate(ctx, tx, req, email)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, err.Error())
		if st != stcodes.StatusCodeDefaultError {
			return &dimensions.CreateOrUpdateTemplateResponse{BaseResp: &base.BaseResp{
				StatusMessage: err.Error(),
				StatusCode:    int32(st),
			}}, err
		}
		return nil, err
	}
	tx.Commit()
	return &dimensions.CreateOrUpdateTemplateResponse{
		Data: templateId,
	}, nil
}

func (t *TemplateService) UpdateTemplate(ctx context.Context, req *dimensions.CreateOrUpdateTemplateRequest) (resp *dimensions.CreateOrUpdateTemplateResponse, err error) {
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, errors.New("获取数据库的事务失败")
	}
	st, err := dao.UpdateTemplate(ctx, tx, req)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, err.Error())
		if st != stcodes.StatusCodeDefaultError {
			return &dimensions.CreateOrUpdateTemplateResponse{BaseResp: &base.BaseResp{
				StatusMessage: err.Error(),
				StatusCode:    int32(st),
			}}, err
		}
		return nil, err
	}
	tx.Commit()
	return &dimensions.CreateOrUpdateTemplateResponse{Data: req.TemplateId}, nil
}

func (t *TemplateService) DeleteTemplate(ctx context.Context, req *dimensions.DeleteTemplateRequest) (resp bool, err error) {
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return false, errors.New("获取数据库的事务失败")
	}
	err = dao.DeleteTemplate(ctx, tx, req.TemplateId)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	tx.Commit()
	return true, nil
}

func (t *TemplateService) GetTemplateList(ctx context.Context, req *dimensions.GetTemplateListRequest) (resp *dimensions.GetTemplateListData, err error) {
	resp = &dimensions.GetTemplateListData{}

	// ModuleEnum不传时，默认是主模块
	if req.ModuleEnum == nil {
		temp := dimensions.TemplateModule_MainModule
		req.ModuleEnum = &temp
	}
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return resp, errors.New("获取数据库的事务失败")
	}
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		tx.Rollback()
		return resp, err
	}
	selfList, commonList, recentlyUsedList, hotList, err := dao.GetTemplateList(ctx, tx, email, req.BizType, req.Keyword, *req.ModuleEnum)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		tx.Rollback()
		return resp, err
	}
	tx.Commit()

	resp = &dimensions.GetTemplateListData{
		SelfList:         selfList,
		CommonList:       commonList,
		RecentlyUsedList: recentlyUsedList,
		HotCommonList:    hotList,
	}
	return resp, nil
}

func (t *TemplateService) GetTemplateDetail(ctx context.Context, req *dimensions.GetTemplateDetailRequest) (resp *dimensions.GetTemplateDetailData, err error) {
	resp = &dimensions.GetTemplateDetailData{}

	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, errors.New("获取数据库的事务失败")
	}
	data, err := dao.GetTemplateDetail(ctx, tx, req.TemplateId)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		tx.Rollback()
		return nil, err
	}
	tx.Commit()

	resp = data
	return resp, nil
}

func (t *TemplateService) GenreateTemplateCache(ctx context.Context) (resp *base.BaseResponse, err error) {
	return resp, nil
}
