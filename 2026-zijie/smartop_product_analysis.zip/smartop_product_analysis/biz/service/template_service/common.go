package template_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"context"
)

type ITemplateService interface {
	CreateTemplate(ctx context.Context, req *dimensions.CreateOrUpdateTemplateRequest) (resp *dimensions.CreateOrUpdateTemplateResponse, err error)
	UpdateTemplate(ctx context.Context, req *dimensions.CreateOrUpdateTemplateRequest) (resp *dimensions.CreateOrUpdateTemplateResponse, err error)
	DeleteTemplate(ctx context.Context, req *dimensions.DeleteTemplateRequest) (resp bool, err error)
	GetTemplateList(ctx context.Context, req *dimensions.GetTemplateListRequest) (resp *dimensions.GetTemplateListData, err error)
	GetTemplateDetail(ctx context.Context, req *dimensions.GetTemplateDetailRequest) (resp *dimensions.GetTemplateDetailData, err error)
	GenreateTemplateCache(ctx context.Context) (resp *base.BaseResponse, err error)
}

type TemplateService struct {
	AnalysisService analysis_service.IAnalysisService
}
