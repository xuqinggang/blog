package cronjob

import (
	"context"
	"fmt"
	"time"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/gdp/env"
	"code.byted.org/gopkg/ctxvalues"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs/v2"
	_ "code.byted.org/inf/go-byteddoris"
	"github.com/henrylee2cn/goutil/calendar/cron"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

const (
	dbName = "product_analysis"
)

var dorisEmbeddingRedisKey = "doris_embedding_redis_key"

func buildEmbeddingSqlList(ctx context.Context) ([]string, error) {
	arkConfig, err := biz_info.GetArkConfig(ctx)
	if err != nil || arkConfig == nil {
		logs.CtxError(ctx, "[buildEmbeddingSqlList] GetArkConfig failed, err=%v", err)
		return nil, err
	}

	ep := arkConfig.Endpoint["doubao-embedding-vision"]
	if ep == "" {
		logs.CtxError(ctx, "[buildEmbeddingSqlList] ark endpoint is empty")
		return nil, fmt.Errorf("ark endpoint is empty")
	}
	apiKey := arkConfig.ApiKey

	return []string{
		fmt.Sprintf(`UPDATE  product_analysis.dimension_list
									SET     show_name_embedding = CASE WHEN show_name_embedding IS NULL THEN text_embedding(
																	"volcark/%s",
																	LEFT(show_name, 5000),
																	'{"api_key":"%s","null_on_failure":false,"tpm":1200000,"api_version":"vision"}'
															)
															ELSE show_name_embedding
													END,
													dim_column_embedding = CASE WHEN dim_column_embedding IS NULL THEN text_embedding(
																	"volcark/%s",
																	LEFT(dim_column, 5000),
																	'{"api_key":"%s","null_on_failure":false,"tpm":1200000,"api_version":"vision"}'
															)
															ELSE dim_column_embedding
													END
									WHERE   (show_name_embedding IS NULL OR dim_column_embedding IS NULL)`, ep, apiKey, ep, apiKey), // 维度表
		fmt.Sprintf(`UPDATE  product_analysis.target_list
									SET     show_name_embedding = CASE WHEN show_name_embedding IS NULL THEN text_embedding(
																	"volcark/%s",
																	LEFT(show_name, 5000),
																	'{"api_key":"%s","null_on_failure":false,"tpm":1200000,"api_version":"vision"}'
															)
															ELSE show_name_embedding
													END,
													name_embedding = CASE WHEN name_embedding IS NULL THEN text_embedding(
																	"volcark/%s",
																	LEFT(name, 5000),
																	'{"api_key":"%s","null_on_failure":false,"tpm":1200000,"api_version":"vision"}'
															)
															ELSE name_embedding
													END,
													description_embedding = CASE WHEN description_embedding IS NULL THEN text_embedding(
																	"volcark/%s",
																	LEFT(description, 5000),
																	'{"api_key":"%s","null_on_failure":false,"tpm":1200000,"api_version":"vision"}'
															)
															ELSE description_embedding
													END
									WHERE   (
															show_name_embedding IS NULL
															OR name_embedding IS NULL
															OR description_embedding IS NULL
													)`, ep, apiKey, ep, apiKey, ep, apiKey), // 指标表
		fmt.Sprintf(`UPDATE  product_analysis.dimension_enum_list
									SET     name_embedding = CASE WHEN name_embedding IS NULL THEN text_embedding(
																	"volcark/%s",
																	LEFT(name, 5000),
																	'{"api_key":"%s","null_on_failure":false,"tpm":1200000,"api_version":"vision"}'
															)
															ELSE name_embedding
													END,
													code_embedding = CASE WHEN code_embedding IS NULL THEN text_embedding(
																	"volcark/%s",
																	LEFT(code, 5000),
																	'{"api_key":"%s","null_on_failure":false,"tpm":1200000,"api_version":"vision"}'
															)
															ELSE code_embedding
													END
									WHERE   (name_embedding IS NULL OR code_embedding IS NULL)`, ep, apiKey, ep, apiKey), // 维度枚举值表
	}, nil
}

func executeDorisEmbeddingTask(ctx context.Context) (err error) {
	// 获取Doris配置信息
	dorisConfig, err := tcc.GetDorisConfig(ctx)
	if err != nil || dorisConfig == nil {
		logs.CtxError(ctx, "[executeDorisEmbeddingTask] GetDorisConfig failed, err=%v", err)
		return
	}

	// 连接Doris：https://bytedance.larkoffice.com/wiki/wikcn0FDidb1Eg8Ohdewarsn1Uh
	db, err := gorm.Open(mysql.New(mysql.Config{
		DriverName: "byteddoris",
		DSN:        fmt.Sprintf("%s:%s@sd(%s)/%s?use_gdpr_auth=true&interpolateParams=true", dorisConfig.User, dorisConfig.Password, dorisConfig.Psm, dbName),
	}))
	if err != nil {
		logs.CtxError(ctx, "[executeDorisEmbeddingTask] Connect Doris failed, err=%v", err)
		return
	}

	// 获取embedding sql list
	embeddingSqlList, err := buildEmbeddingSqlList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[executeDorisEmbeddingTask] buildEmbeddingSqlList failed, err=%v", err)
		return
	}
	if len(embeddingSqlList) == 0 {
		err = fmt.Errorf("embeddingSqlList is empty")
		logs.CtxError(ctx, "[executeDorisEmbeddingTask] embeddingSqlList is empty")
		return
	}

	// 并发执行embedding
	// 设置30分钟超时
	ctxWithTimeout, cancel := context.WithTimeout(ctx, 30*time.Minute)
	defer cancel()

	cc := co.NewConcurrent(ctxWithTimeout)
	for _, sql := range embeddingSqlList {
		currentSql := sql
		cc.GoV2(func() error {
			if _err := db.WithContext(ctxWithTimeout).Exec(currentSql).Error; _err != nil {
				logs.CtxError(ctxWithTimeout, "[executeDorisEmbeddingTask] Exec failed, err=%v", _err)
				return _err
			}
			return nil
		})
	}
	if err = cc.WaitV2(); err != nil {
		logs.CtxError(ctx, "[executeDorisEmbeddingTask] Concurrent exec failed, err=%v", err)
		return
	}

	return
}

func StartDorisEmbeddingCronJob() {
	ctx := context.Background()
	if env.IsBoe() {
		// BOE环境不执行
		return
	}

	c := cron.New()
	// 每天的凌晨1:00执行定时任务 TODO：后面改成Dorado的webhook
	cronExp := "0 0 1 * * ?"

	c.AddFunc(cronExp, func() {
		ctx = ctxvalues.SetLogID(ctx, logid.GenLogID())

		defer func() {
			p := recover()
			if p != nil {
				logs.CtxWarn(ctx, "[StartDorisEmbeddingCronJob] cronJob出现panic错误，请检查：%v", p)
			}
		}()

		logs.CtxInfo(ctx, "[StartDorisEmbeddingCronJob] 尝试执行cron任务")

		// ppe和线上不共用一个redis_key
		var key = dorisEmbeddingRedisKey
		if env.IsPPE() {
			key = dorisEmbeddingRedisKey + "_ppe"
		}

		if !TryToLockCronKey(ctx, key) {
			logs.CtxInfo(ctx, "[StartDorisEmbeddingCronJob] 未获取到锁，跳过执行")
			return
		}

		logs.CtxInfo(ctx, "[StartDorisEmbeddingCronJob] 成功获取锁，开始执行")

		// 执行embedding任务
		if err := executeDorisEmbeddingTask(ctx); err != nil {
			logs.CtxError(ctx, "[StartDorisEmbeddingCronJob] 任务执行失败, err=%v", err)
			return
		}

		logs.CtxInfo(ctx, "[StartDorisEmbeddingCronJob] 任务执行成功")
	})

	c.Start()
}
