package cronjob

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"
	analysis_pool_product_service "code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_dump_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/gopkg/ctxvalues"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/com_commop_product360/rpc/com_commop_product360"
	"context"
	"github.com/henrylee2cn/goutil/calendar/cron"
	"github.com/sanity-io/litter"
	"time"
)

var apiId = "7427043792449963058"
var redisKey = "pool_sync_redis_key"

func StartPoolSyncCronJob() {
	ctx := context.Background()
	if env.IsBoe() {
		// 非调试BOE环境不执行
		return
	}
	c := cron.New()
	// 每小时的30分执行定时任务
	cronExp := "0 30 * * * ?"
	c.AddFunc(cronExp, func() {
		defer func() {
			p := recover()
			if p != nil {
				logs.CtxWarn(ctx, "cronJob出现panic错误，请检查：%v", p)
			}
		}()
		logs.CtxInfo(ctx, "尝试执行cron任务")
		// ppe和线上不共用一个redis_key
		var key = redisKey
		if env.IsPPE() {
			key = redisKey + "_ppe"
		}
		if TryToLockCronKey(ctx, key) {
			logs.CtxInfo(ctx, "成功抢到同步锁，开始执行cron任务")
			// 说明抢到同步锁了，开始执行商品池状态更新
			err := StartPoolSyncExecute(ctx)
			if err != nil {
				logs.CtxWarn(ctx, "CronExecutePoolSync failed, err: %v", err)
				return
			}

			poolDumpService := &analysis_pool_product_service.AnalysisPoolDumpService{PoolDumpStatusDao: &dao.PoolDumpStatusDao{}}
			err = poolDumpService.CheckOSDumpStatus(ctx)
			if err != nil {
				logs.CtxWarn(ctx, "poolDumpService.CheckOSDumpStatus(ctx) failed, err: %v", err)
			}
			err = poolDumpService.SubmitDoradoTask(ctx)
			if err != nil {
				logs.CtxWarn(ctx, "poolDumpService.SubmitDoradoTask(ctx) failed, err: %v", err)
			}
			if env.IsPPE() {
				logs.CtxInfo(ctx, "[StartPoolSyncCronJob]ppe环境,执行cron完成")
			} else {
				logs.CtxInfo(ctx, "[StartPoolSyncCronJob]线上环境,执行cron完成")
			}
		}
	})
	c.Start()
}

// StartPoolSyncExecute 添加商品包元信息（单次or周期商品包，是否完成校验等）
func StartPoolSyncExecute(ctx context.Context) (err error) {
	ctx = ctxvalues.SetLogID(ctx, logid.GenLogID())
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return errors.New("获取数据库的事务失败")
	}
	// 后置处理 panic或error，恢复mysql表的字段为初始值
	defer func() {
		p := recover()
		if p != nil {
			tx.Rollback()
			panic(p)
		} else if err != nil {
			if err != nil {
				logs.CtxWarn(ctx, err.Error())
				tx.Rollback()
			}
		}
	}()
	// 获取选品中心最新一天需要校验的商品池
	poolList, err := dao.GetPoolMaxDt(ctx, tx, consts.PoolSourceProductSelectCenter)
	if err != nil {
		logs.CtxError(ctx, "[GetPoolMaxDt]获取选品中心商品包RDS数据失败,err:"+err.Error())
		tx.Rollback()
		return err
	}
	var poolIdList = make([]int64, 0)
	var poolMap = make(map[int64][]*dao.PoolMetaInfo)
	for _, pool := range poolList {
		// 2代表尚未校验
		if pool.JudgeRes == 2 {
			poolIdList = append(poolIdList, pool.PoolId)
		}
		if _, ok := poolMap[pool.PoolId]; ok {
			poolMap[pool.PoolId] = append(poolMap[pool.PoolId], pool)
		} else {
			poolMap[pool.PoolId] = []*dao.PoolMetaInfo{pool}
		}
	}
	// 没有未校验商品包时，直接返回
	if len(poolIdList) == 0 {
		logs.CtxInfo(ctx, "最新一天的商品池都已完成校验，无需再次校验")
		tx.Commit()
		return nil
	}
	poolIdInfo, err := com_commop_product360.QueryProductPoolByIds(ctx, poolIdList)
	if err != nil {
		logs.CtxError(ctx, "获取选品中心商品包元数据失败,err:"+err.Error())
		tx.Rollback()
		return err
	}
	logs.CtxInfo(ctx, "获取选品中心商品包元数据成功,meta info:"+litter.Sdump(poolIdInfo))
	if poolIdInfo != nil {
		for _, poolMeta := range poolIdInfo.TProductPools {
			if _, ok := poolMap[poolMeta.Id]; ok {
				for _, pool := range poolMap[poolMeta.Id] {
					pool.JudgeRes = 0
					pool.PoolCreator = poolMeta.CreatorUserId
					pool.PoolProduceType = int64(poolMeta.TPoolProduceType)
					pool.PoolStatusXuanpin = int64(poolMeta.Status)
				}
			} else {
				for _, pool := range poolMap[poolMeta.Id] {
					pool.JudgeRes = 1
				}
			}
		}
	}
	// 读取ck表，把ck商品池可选状态更新到mysql表中
	var readyPoolIdList = make([]int64, 0)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(make(map[string]interface{}), apiId, param.SinkTable("pool_id")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeView(param.SourceTable("pool_id"), &readyPoolIdList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "读取ck获取已就绪商品包失败,err:"+err.Error())
		tx.Rollback()
		return err
	}
	// 修改同步状态为已同步
	for _, poolId := range readyPoolIdList {
		if _, ok := poolMap[poolId]; ok {
			for _, pool := range poolMap[poolId] {
				pool.OurPoolStatus = 0
			}
		}
	}
	// 将map值写入mysql表
	err = dao.UpdatePoolStatus(ctx, tx, poolMap)
	if err != nil {
		tx.Rollback()
		return err
	}
	tx.Commit()
	return nil
}

func TryToLockCronKey(ctx context.Context, keyName string) bool {
	// 查询redis的这个string类型的key的值
	logs.CtxInfo(ctx, "准备写入redis,key="+keyName+",value="+"0")
	flag, err := redis.SetNx(ctx, keyName, "0", 120*time.Second)
	logs.CtxInfo(ctx, "写入redis完成")
	if err != nil {
		logs.CtxError(ctx, " query redis db failed :"+err.Error())
		return false
	}
	return flag
}
