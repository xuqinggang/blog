package cronjob

import (
	"context"
	"fmt"
	"strings"
	"sync"

	"code.byted.org/aweme-go/hstruct/cast"
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/dal/db/model"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"github.com/goccy/go-json"
	"github.com/henrylee2cn/goutil/calendar/cron"
	larkim "github.com/larksuite/oapi-sdk-go/v3/service/im/v1"
	"github.com/pborman/uuid"
)

// syncRedisKey: cronjob 分布式锁的 redis key 前缀（会根据环境追加 _ppe）
var syncRedisKey = "dimensions_sync_redis_key"

// messageCardID: 飞书消息卡片模版 ID（template card）
var messageCardID = "AAqvXGjV5zUhK"

type TaskType string

const (
	TaskType_Prod TaskType = "prod"
	TaskType_User TaskType = "user"
)

// partitionMap: 不同维度类型在外部查询（OS/一表）里对应的分区/类型字符串
// 用于拼接 query_params，让外部系统能定位到对应的实体记录。
var partitionMap = map[dimensions.RegisterDimensionType]string{
	dimensions.RegisterDimensionType_InvestmentSelectProd: "investment_prod_new",
	dimensions.RegisterDimensionType_SelectProd360:        "select_prod_360",
	dimensions.RegisterDimensionType_CrowdPackage:         "crowd_package",
	dimensions.RegisterDimensionType_RecruitProd:          "recruit_prod",
}

// StartDimensionsSyncCronJob 注册同步用户维度数据计划任务
//
// 触发频率：每小时 30 分
// 执行前置：通过 redis 分布式锁避免多实例重复执行
func StartDimensionsSyncCronJob() {
	ctx := context.Background()
	if env.IsBoe() {
		// 非调试BOE环境不执行
		return
	}
	c := cron.New()
	// 每小时的30分执行定时任务
	cronExp := "0 30 * * * ?"
	c.AddFunc(cronExp, func() {
		defer func() {
			p := recover()
			if p != nil {
				logs.CtxWarn(ctx, "用户维度同步cronJob出现panic错误，请检查：%v", p)
			}
		}()
		logs.CtxInfo(ctx, "尝试执行用户维度同步cron任务")
		// ppe和线上不共用一个redis_key
		var key = syncRedisKey
		if env.IsPPE() {
			key = syncRedisKey + "_ppe"
		}
		if TryToLockCronKey(ctx, key) {
			logs.CtxInfo(ctx, "成功抢到同步锁，开始执行用户维度同步cron任务")
			// 说明抢到同步锁了，开始执行用户维度数据同步
			err := BatchSyncDimendionsStatus(ctx)
			if err != nil {
				logs.CtxWarn(ctx, "用户维度同步任务失败, err: %v", err)
				return
			}
		}
	})
	c.Start()
}

// BatchSyncDimendionsStatus 添加商品包元信息（单次or周期商品包，是否完成校验等）
func BatchSyncDimendionsStatus(ctx context.Context) (err error) {
	taskID := "prod_sync_" + uuid.NewUUID().String() // 根节点消息ID

	logs.CtxInfo(ctx, "[prod_sync_taskId=%s] 开始执行用户维度同步任务", taskID)

	// 事务：避免读取过程中数据被修改导致结果不一致；同时保证连接正确释放（Commit/Rollback）
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[prod_sync_taskId=%s] 获取数据库的事务失败, err=%v", taskID, tx.Error)
		return errors.New("获取数据库的事务失败")
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	// 1) 查询待同步维度列表
	dimDao := &dao.NeedDumpDimensionDao{}

	res, total, err := dimDao.GetNeedDumpDimensionList(ctx, tx, &dao.NeedDumpDimensionQueryParams{
		// 每次执行任务需要扫描所有记录
		// AnalysisStatus: []int32{int32(dimensions.AnalysisStatus_DumpIng)},
	})
	if err != nil {
		logs.CtxError(ctx, "[prod_sync_taskId=%s] 用户维度同步任务，查询待同步维度列表失败, err=%v", taskID, err)
		return err
	}
	logs.CtxInfo(ctx, "[prod_sync_taskId=%s] 用户维度同步任务，查询到需要同步的维度总数：list=%d, total=%d", taskID, len(res), total)

	// 2) 并发处理每个维度：调用外部系统判断该维度是否已经同步完成
	// 注意：
	// - range 变量必须捕获（task := t），否则 goroutine 可能读到同一个循环变量
	// - 汇总 slice(toUpdate) 的 append 需要加锁，避免数据竞争
	cc := co.NewConcurrent(ctx)
	var mu sync.Mutex
	toUpdate := make([]*model.NeedDumpProdUserDimension, 0)

	prodTasks := make([]*model.NeedDumpProdUserDimension, 0, len(res))
	userTasks := make([]*model.NeedDumpProdUserDimension, 0, len(res))
	for _, t := range res {
		if t == nil {
			continue
		}
		switch dimensions.RegisterDimensionType(t.DimensionType) {
		case dimensions.RegisterDimensionType_InvestmentSelectProd,
			dimensions.RegisterDimensionType_SelectProd360,
			dimensions.RegisterDimensionType_RecruitProd:
			prodTasks = append(prodTasks, t)
		case dimensions.RegisterDimensionType_CrowdPackage:
			userTasks = append(userTasks, t)
		default:
		}
	}

	cc.GoV2(func() error {
		update, e := SyncProdDimendionsStatus(ctx, taskID, TaskType_Prod, prodTasks)
		if e != nil {
			return e
		}
		if len(update) == 0 {
			return nil
		}
		mu.Lock()
		toUpdate = append(toUpdate, update...)
		mu.Unlock()
		return nil
	})
	cc.GoV2(func() error {
		update, e := SyncProdDimendionsStatus(ctx, taskID, TaskType_User, userTasks)
		if e != nil {
			return e
		}
		if len(update) == 0 {
			return nil
		}
		mu.Lock()
		toUpdate = append(toUpdate, update...)
		mu.Unlock()
		return nil
	})

	if err = cc.WaitV2(); err != nil {
		logs.CtxWarn(ctx, "[prod_sync_taskId=%s] 用户维度同步任务，存在执行失败的任务, err=%v", taskID, err)
	}

	logs.CtxInfo(ctx, "[prod_sync_taskId=%s] 用户维度同步任务，本轮判定已完成同步的维度数=%d", taskID, len(toUpdate))
	if len(toUpdate) == 0 {
		logs.CtxWarn(ctx, "[prod_sync_taskId=%s] 用户维度同步任务结束，但没有需要通知/更新的维度", taskID)
		return
	}

	if err = dimDao.BatchUpdateNeedDumpDimensions(ctx, tx, toUpdate); err != nil {
		logs.CtxError(ctx, "[prod_sync_taskId=%s] NeedDumpDimension batch update err=%v", taskID, err)
		return err
	}

	// 事务结束
	if err = tx.Commit().Error; err != nil {
		logs.CtxWarn(ctx, "[prod_sync_taskId=%s] 用户维度同步任务，事务提交失败, err=%v", taskID, err)
		return err
	}

	// 3) 按 creator 聚合：creator -> DimensionSyncMap（飞书卡片模板使用）
	notifyMap := make(map[string]*dimensions.DimensionSyncMap)
	for _, item := range toUpdate {
		if item == nil || item.Creator == "" {
			continue
		}
		if notifyMap[item.Creator] == nil {
			notifyMap[item.Creator] = &dimensions.DimensionSyncMap{}
		}

		// 不同维度类型写入到不同的列表字段，便于卡片分组展示
		switch dimensions.RegisterDimensionType(item.DimensionType) {
		case dimensions.RegisterDimensionType_InvestmentSelectProd:
			notifyMap[item.Creator].InvestmentSelectProd = append(notifyMap[item.Creator].InvestmentSelectProd, item.EntityName)
		case dimensions.RegisterDimensionType_SelectProd360:
			notifyMap[item.Creator].SelectProd360 = append(notifyMap[item.Creator].SelectProd360, item.EntityName)
		case dimensions.RegisterDimensionType_CrowdPackage:
			notifyMap[item.Creator].CrowdPackage = append(notifyMap[item.Creator].CrowdPackage, item.EntityName)
		case dimensions.RegisterDimensionType_RecruitProd:
			notifyMap[item.Creator].RecruitProd = append(notifyMap[item.Creator].RecruitProd, item.EntityName)
		default:
			// 未知类型直接跳过，避免写错字段
		}
	}

	client := lark_service.GetInstance(1000)
	if client == nil {
		logs.CtxError(ctx, "[prod_sync_taskId=%s] [BatchSyncDimendionsStatus] client is nil", taskID)
		return errors.New("[BatchSyncDimendionsStatus] client is nil")
	}
	// 遍历notifyMap中的数据，发送通知
	for creator, dimMap := range notifyMap {

		logs.CtxInfo(ctx, "[prod_sync_taskId=%s] send notification to creator: %s, dimMap: %v", taskID, creator, dimMap)
		// 调用通知服务，发送通知
		msg, err := createCard(ctx, dimMap)

		if err != nil {
			logs.CtxError(ctx, "[prod_sync_taskId=%s] 创建用户维度同步通知失败, creator: %s, err: %v", taskID, creator, err)
		} else {
			larkReq := larkim.NewCreateMessageReqBuilder().
				ReceiveIdType(`email`).
				Body(larkim.NewCreateMessageReqBodyBuilder().
					ReceiveId(creator).
					MsgType("interactive").
					Content(string(msg)).
					Build()).
				Build()
			_, err := client.Im.V1.Message.Create(ctx, larkReq)
			if err != nil {
				logs.CtxError(ctx, "[prod_sync_taskId=%s] 发送用户维度同步通知失败, creator: %s, err: %v", taskID, creator, err)
			}
		}
	}
	return
}

// SyncProdDimendionsStatus 同步用户维度数据（单条）
//
// 这里的“同步”含义：调用外部系统查询该实体的已同步日期列表，
// 如果包含本条记录的创建日期，则认为该维度已完成同步。
//
// 返回值：
// - update != nil 表示该条应当进入“完成同步(FinishDump)”待更新/待通知集合
// - update == nil 表示本条尚未同步完成或查询无结果
func SyncProdDimendionsStatus(ctx context.Context, taskID string, taskType TaskType, tasks []*model.NeedDumpProdUserDimension) (update []*model.NeedDumpProdUserDimension, err error) {
	// 入参保护：避免空指针
	if tasks == nil || len(tasks) == 0 {
		return nil, nil
	}

	queryStrs := []string{}

	taskMap := make(map[string]*model.NeedDumpProdUserDimension)

	for _, task := range tasks {
		typeName := partitionMap[dimensions.RegisterDimensionType(task.DimensionType)]

		queryStrs = append(queryStrs,
			fmt.Sprintf(`dimension_type='%s' AND entity_id='%s' `, typeName, task.EntityID))
		uniqueID := fmt.Sprintf("%s_%s", typeName, task.EntityID)
		taskMap[uniqueID] = task
	}

	// 1) 构造外部系统查询参数
	// query_params 的语义：指定维度类型 + 实体 ID，用于定位外部系统记录
	params := make(map[string]interface{})
	params["query_params"] = strings.Join(queryStrs, " OR ")
	params["task_type"] = string(taskType)

	// 2) 调用外部系统查询记录（本函数不直接更新 DB，仅用于判断同步状态）
	records, err := base_struct_condition.GetRecordsByOS(ctx, params, "", "7596976713003746314")
	if err != nil {
		return nil, err
	}
	if len(records) == 0 {
		// 外部系统无记录：认为未同步完成
		return nil, nil
	}

	relationDao := &dao.DumpDimensionDateRelationDao{}

	for _, record := range records {

		dates, err := cast.ToStringSliceE(record["dates"])

		if err != nil {
			logs.CtxError(ctx, "[prod_sync_taskId=%s] SyncProdDimendionsStatus: ToStringSliceE err=%v", taskID, err.Error())
			continue
		}

		uniqueID := fmt.Sprintf("%s_%s", record["dimension_type"].(string), record["entity_id"].(string))
		task := taskMap[uniqueID]
		if task == nil {
			logs.CtxError(ctx, "[prod_sync_taskId=%s] SyncProdDimendionsStatus: Got nil task for uniqueID=%s", taskID, uniqueID)
			continue
		}

		tx := mysql.DB(ctx).Begin()
		if tx.Error != nil {
			logs.CtxError(ctx, "[prod_sync_taskId=%s] SyncProdDimendionsStatus: Begin tx failed, err=%v", taskID, tx.Error.Error())
			continue
		}
		defer func() {
			if err != nil {
				_ = tx.Rollback()
			}
		}()
		list := make([]*model.DumpDimensionDateRelation, 0, len(dates))

		for _, date := range dates {
			list = append(list, &model.DumpDimensionDateRelation{
				DumpDimensionID: task.DumpDimensionID,
				Date:            date,
			})
		}

		relationDao.BatchCreate(ctx, tx, list)
		// 事务结束：当前实现主要读取，不更新 DB，也需要 Commit 释放连接
		if err = tx.Commit().Error; err != nil {
			logs.CtxError(ctx, "[prod_sync_taskId=%s] SyncProdDimendionsStatus: Commit tx failed, err=%v", taskID, err)
		} else {
			//targetDate := task.CreateTime.Format(consts.Fmt_Date)
			passed := len(dates) > 0

			if passed && task.AnalysisStatus != int32(dimensions.AnalysisStatus_FinishDump) {
				task.AnalysisStatus = int32(dimensions.AnalysisStatus_FinishDump)
				update = append(update, task)
			}
		}
	}

	return
}

// createCard 构造飞书「模板消息卡片」的 content（interactive message）
//
// 说明：
// - 这里 SyncInfo 会作为模板变量注入到卡片模板中；模板里通常以 markdown/plain text 展示
// - contentStr 使用 "\n" 拼接换行（注意不要用反引号 raw string，否则 \n 不会生效）
// - 列表格式：
//   - 一级："- 分组名"
//   - 二级："\n   - 条目"（缩进放到换行后，保证下一行才缩进）
func createCard(ctx context.Context, dimMap *dimensions.DimensionSyncMap) (jsonStr []byte, err error) {
	type MessageCardVarible struct {
		SyncInfo string `json:"sync_info"`
	}

	contentStr := ""
	if len(dimMap.InvestmentSelectProd) > 0 {
		contentStr += "- 招商选品包"
		contentStr += fmt.Sprintf("\n   - %s", strings.Join(dimMap.InvestmentSelectProd, "\n   - "))
	}
	if len(dimMap.SelectProd360) > 0 {
		contentStr += "\n- 商品360选品包"
		contentStr += fmt.Sprintf("\n   - %s", strings.Join(dimMap.SelectProd360, "\n   - "))
	}
	if len(dimMap.CrowdPackage) > 0 {
		contentStr += "\n- 人群包"
		contentStr += fmt.Sprintf("\n   - %s", strings.Join(dimMap.CrowdPackage, "\n   - "))
	}
	if len(dimMap.RecruitProd) > 0 {
		contentStr += "\n- 招募策略商品包"
		contentStr += fmt.Sprintf("\n   - %s", strings.Join(dimMap.RecruitProd, "\n   - "))
	}

	msgParam := lark_service.MessageCardRequestData[MessageCardVarible]{
		Type: "template",
		Data: lark_service.MessageCardData[MessageCardVarible]{
			TemplateID: messageCardID,
			TemplateVariable: MessageCardVarible{
				SyncInfo: contentStr,
			},
		},
	}
	jsonStr, err = json.Marshal(msgParam)

	return
}
