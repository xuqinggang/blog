package cronjob

import (
	"context"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_select_service"
	"code.byted.org/gopkg/ctxvalues"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logid"
	"code.byted.org/gopkg/logs/v2"
	"github.com/henrylee2cn/goutil/calendar/cron"
)

var productSelectTaskRedisKey = "product_select_task_redis_key"

func StartProductSelectTaskCronJob() {
	ctx := context.Background()
	ctx = logs.CtxAddKVs(ctx, "handler", "StartProductSelectTaskCronJob")

	if env.IsBoe() {
		// 非调试BOE环境不执行
		return
	}
	c := cron.New()
	// 每小时的30分执行定时任务
	cronExp := "0 */30 * * * ?"
	if env.IsPPE() {
		// ppe 每1分钟执行定时任务
		cronExp = "0 */5 * * * ?"
		if !biz_info.IsEnableUpdateProductSelectTask(ctx) {
			return
		}
	}
	c.AddFunc(cronExp, func() {
		ctx = ctxvalues.SetLogID(ctx, logid.GenLogID())

		defer func() {
			p := recover()
			if p != nil {
				logs.CtxWarn(ctx, "cronJob出现panic错误，请检查：%v", p)
			}
		}()
		logs.CtxInfo(ctx, "尝试执行cron任务")
		// ppe和线上不共用一个redis_key
		var key = productSelectTaskRedisKey
		if env.IsPPE() {
			key = productSelectTaskRedisKey + "_ppe"
		}
		if TryToLockCronKey(ctx, key) {
			logs.CtxInfo(ctx, "成功抢到同步锁，开始执行cron任务")
			// 说明抢到同步锁了，开始执行商品池状态更新
			err := StartPoolSelectTaskExecute(ctx)
			if err != nil {
				logs.CtxWarn(ctx, "CronExecutePoolSync failed, err: %v", err)
				return
			}
		}
	})
	c.Start()
}

func StartPoolSelectTaskExecute(ctx context.Context) (err error) {
	timeStart := time.Now()
	// 后置处理 panic或error，恢复mysql表的字段为初始值
	defer func() {
		logs.CtxInfo(ctx, "StartPoolSelectTaskExecute end, timeCost: %dms", time.Since(timeStart)/time.Millisecond)
		p := recover()
		if p != nil {
			panic(p)
		}
	}()

	// 1. 获取所有需要执行的选品任务
	var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
	pageSize := 20
	taskList, count, err := ProductSelectTaskDao.GetProductSelectTaskList(ctx, &dao.ProductSelectTaskQueryParams{
		IsDeleted: 0,
		PageNum:   int(0),
		PageSize:  pageSize,
	})
	if err != nil {
		logs.CtxWarn(ctx, "StartPoolSelectTaskExecute, GetProductSelectTaskList failed, err: %s, PageNum: 0, PageSize: %d", err, pageSize)
		return
	}

	logs.CtxNotice(ctx, "GetProductSelectTaskList total_count: %d, current_count:%d", count, len(taskList))

	maxPageNum := int(count-1) / pageSize
	for pageNum := 1; pageNum <= maxPageNum; pageNum++ {
		taskListTmp, _, err := ProductSelectTaskDao.GetProductSelectTaskList(ctx, &dao.ProductSelectTaskQueryParams{
			IsDeleted: 0,
			PageNum:   pageNum,
			PageSize:  pageSize,
		})
		if err != nil {
			logs.CtxWarn(ctx, "StartPoolSelectTaskExecute, GetProductSelectTaskList failed, err: %s, PageNum: %d, PageSize: %d", err, pageNum, pageSize)
			continue
		}
		taskList = append(taskList, taskListTmp...)

		logs.CtxNotice(ctx, "GetProductSelectTaskList total_count: %d, current_count: %d, PageNum: %d, PageSize: %d",
			count, len(taskList), pageNum, pageSize)
	}

	// 2. 循环执行选品任务
	for _, task := range taskList {
		product_select_service.ProductSelectTaskWorker(ctx, task, false)
		product_select_service.UpdateDimensionSQL(ctx, task)
	}
	return nil
}
