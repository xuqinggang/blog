package analysis_pool_service

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_dump_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_product_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tqs"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_product"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dorado_task"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/product_select"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/metainfo"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_smartop_guard/kitex_gen/ecom/smartop/guard"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
)

type IAnalysisPoolService interface {
	QueryAnalysisPoolList(ctx context.Context, req *analysis_pool.QueryAnalysisPoolListReq) (resp *analysis_pool.QueryAnalysisPoolListData, err error)
	CreateAnalysisPool(ctx context.Context, req *analysis_pool.CreateAnalysisPoolReq) (pool_id string, err error)
	CreateAnalysisPoolApplicationRecord(ctx context.Context, req *analysis_pool.CreateAnalysisPoolApplicationRecordReq) (record_id string, err error)
	UpdateAnalysisPool(ctx context.Context, req *analysis_pool.UpdateAnalysisPoolReq) (pool_id string, err error)
	DeleteAnalysisPool(ctx context.Context, req *analysis_pool.DeleteAnalysisPoolReq) (is_delete bool, err error)
	QueryAnalysisPoolDetail(ctx context.Context, req *analysis_pool.QueryAnalysisPoolDetailReq) (resp *analysis_pool.QueryAnalysisPoolDetailData, err error)
	GetDoradoAnalysisPoolApplicationHiveCallBack(ctx context.Context, req *dorado_task.GetDoradoTaskRunningCallBackRequest) (err error)
}

type AnalysisPoolService struct {
	DimensionService        dimension_service.IDimensionService
	AnalysisPoolDumpService analysis_pool_dump_service.IAnalysisPoolDumpService
}

const (
	PRODUCT_POOL_TYPE    = 0
	RULE_POOL_COUNT      = 1
	apiPathProdOverall   = "7400375325433021491"
	apiPathProdOverallV2 = "7503889345452000283" // 第一个逻辑表达到30个上限
	ProdSelectBrain      = "92002"
)

// 定义Tqs查询返回的ApplicationRecordStatusInfo
type ApplicationRecordStatusInfo struct {
	ApplicationRecordId  string `json:"application_record_id"`
	ApplicationStatus    string `json:"application_status"`
	ApplicationErrorInfo string `json:"application_error_info"`
}

func (t *AnalysisPoolService) CreateAnalysisPool(ctx context.Context, req *analysis_pool.CreateAnalysisPoolReq) (pool_id string, err error) {
	// pool_type=0 校验pid_list
	if req.PoolType == analysis_pool.AnalysisPoolType_FixedProd && (req.PidList == nil || *req.PidList == "") {
		return "", errors.New("商品货盘创建失败，请录入商品ID")
	}
	if req.PoolType == analysis_pool.AnalysisPoolType_FixedProd {
		// 格式校验
		productIdStrs := strings.Split(*req.PidList, ",")
		productIds := utils.SliceString2Int64(productIdStrs)
		for productIdIndex, productId := range productIds {
			if productId < 100000000000000000 {
				return "", errors.New(fmt.Sprintf("存在商品ID格式错误,问题商品ID为: %v", productIdStrs[productIdIndex]))
			}
		}
	}
	if req.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		if req.FeatureTaskId == nil {
			return "", errors.New("货盘创建失败，请输入特征圈品任务ID")
		}
		if req.PoolName == "" {
			return "", errors.New("货盘创建失败，请输入货盘名称")
		}
	}

	productSelectTaskDao := new(dao.ProductSelectTaskDao)

	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[CreateAnalysisPool]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return "", errors.New("获取数据库的事务失败")
	}

	// 创建算法特征圈品货盘需要通过特征圈品任务ID查询任务上的货盘pool_rule
	if req.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature && req.FeatureTaskId != nil {
		taskId, err := strconv.ParseInt(*req.FeatureTaskId, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[CreateAnalysisPool]ParseInt失败，err=%v+", err)
			tx.Rollback()
			return "", err
		}
		task, err := productSelectTaskDao.GetProductSelectTask(ctx, tx, taskId)
		if err != nil {
			logs.CtxError(ctx, "[CreateAnalysisPool]GetProductSelectTask失败，err=%v+", err)
			tx.Rollback()
			return "", err
		}

		var poolRule *dimensions.ProductAnalysisBaseStruct
		if task.PoolRule != "" {
			err = json.Unmarshal([]byte(task.PoolRule), &poolRule)
			if err != nil {
				logs.CtxError(ctx, "[CreateAnalysisPool]GetProductSelectTask失败，err=%v, poolRule:%v", err, task.PoolRule)
				tx.Rollback()
				return "", err
			}
		}
		req.BaseStruct = poolRule
	}

	var employeeId string
	ecopCurrentUser, exist := metainfo.GetPersistentValue(ctx, "ECOP_CURRENT_USER")
	if exist {
		var ecopUser guard.OpUser
		castErr := json.Unmarshal([]byte(ecopCurrentUser), &ecopUser)
		if castErr == nil {
			employeeId = ecopUser.EmployeeId
		}
	}
	if employeeId == "" {
		employeeId, err = utils.GetOperatorEmployeeIdFromContext(ctx)
	}
	if err != nil {
		logs.CtxError(ctx, "[CreateAnalysisPool]获取操作用户userID失败，err=%v+", err)
		tx.Rollback()
		return "", err
	}
	// 创建货盘
	poolId, err := dao.CreateAnalysisPool(ctx, tx, req, employeeId)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "[CreateAnalysisPool]调用创建货盘sql失败，err=%v+", err)
		return "", err
	}
	// 创建货盘货品
	if req.GetPoolType() == analysis_pool.AnalysisPoolType_FixedProd {
		err = dao.BatchCreateAnalysisPoolProduct(ctx, tx, poolId, strings.Split(*req.PidList, ","))
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "[CreateAnalysisPool]调用批量创建货盘货品sql失败，err=%v+", err)
			return "", err
		}
	}

	// 如果创建规则货盘时，规则包含选品大脑的货盘，则需要触发规则货盘落hive表的任务，回传给选品大脑侧
	if req.PoolType == analysis_pool.AnalysisPoolType_DynamicRule && req.BaseStruct != nil {
		for _, dim := range req.BaseStruct.Dimensions {
			// 校验baseStruct是否包含选品大脑货盘筛选项
			if dim.Id == ProdSelectBrain {
				var bizMetaInfo *biz_utils.BizMetaInfo
				// 生成os入参params
				bizMetaInfo, ctx, err = biz_utils.GetBizMetaInfo(ctx, req.BaseStruct.BizType)
				if err != nil || bizMetaInfo == nil {
					logs.CtxError(ctx, "[CreateAnalysisPool]创建选品大脑货盘dump任务失败,业务线未发现元信息, req = %s", convert.ToJSONString(req))
					tx.Rollback()
					return "", err
				}
				// 获取业务线的维度信息
				dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
				var curr map[string]interface{}
				curr, err = base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
					BaseStruct: req.BaseStruct,
					DimMap:     dimMap,
					UvFlag:     req.BaseStruct.UvFlag,
				}, base_struct_condition.SQLCalcType_Curr)
				if err != nil {
					logs.CtxError(ctx, "[CreateAnalysisPool]创建选品大脑货盘dump任务失败,生成invoker sql api入参失败,err:"+err.Error())
					return "", err
				}
				err = t.AnalysisPoolDumpService.SubmitMatchingBrainDumpTask(ctx, curr, poolId)
				if err != nil {
					logs.CtxError(ctx, "[CreateAnalysisPool]创建选品大脑货盘dump任务失败,提交选品大脑dump任务失败,err:%v", err.Error())
					tx.Rollback()
					return "", err
				}
				// todo 等商品包来源上线后，需要补充选品大脑的货盘来源
				break
			}
		}
	}

	// 算法特征圈选货盘 需要将货盘id存到算法特征任务上
	if req.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature && req.FeatureTaskId != nil {
		taskId, err := strconv.ParseInt(*req.FeatureTaskId, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[CreateAnalysisPool]ParseInt失败，err=%v+", err)
			tx.Rollback()
			return "", err
		}
		err = productSelectTaskDao.UpdateProductSelectTaskPoolInfo(ctx, tx, taskId, poolId)
		if err != nil {
			logs.CtxError(ctx, "[CreateAnalysisPool]UpdateProductSelectTaskPoolInfo失败，err=%v+", err)
			tx.Rollback()
			return "", err
		}
	}

	// 提交事务
	tx.Commit()

	return poolId, nil
}

func (t *AnalysisPoolService) DeleteAnalysisPool(ctx context.Context, req *analysis_pool.DeleteAnalysisPoolReq) (is_delete bool, err error) {
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[DeleteAnalysisPool]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return false, errors.New("获取数据库的事务失败")
	}
	employeeId, err := utils.GetOperatorEmployeeIdFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "[DeleteAnalysisPool]获取操作用户userID失败，err=%v+", err)
		tx.Rollback()
		return false, err
	}
	// 删除货盘
	err = dao.DeleteAnalysisPool(ctx, tx, req.PoolId, employeeId)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "[DeleteAnalysisPool]调用删除货盘sql失败，err=%v+", err)
		return false, err
	}
	// 删除货盘货品
	err = dao.BatchDeleteProductWithPoolId(ctx, tx, req.PoolId)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "[DeleteAnalysisPool]调用删除货盘货品sql失败，err=%v+", err)
		return false, err
	}
	// 删除货盘关联的监控任务
	err = dao.DeleteProductPoolRelationRules(ctx, tx, req.PoolId)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "[DeleteAnalysisPool]删除货盘关联监控失败，err=%v", err)
		return false, err
	}
	// 提交事务
	tx.Commit()
	return true, nil
}

func (t *AnalysisPoolService) UpdateAnalysisPool(ctx context.Context, req *analysis_pool.UpdateAnalysisPoolReq) (pool_id string, err error) {
	pool_id = ""

	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[UpdateAnalysisPool]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return pool_id, errors.New("获取数据库的事务失败")
	}
	employeeId, err := utils.GetOperatorEmployeeIdFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "[UpdateAnalysisPool]获取操作用户userID失败，err=%v+", err)
		tx.Rollback()
		return pool_id, err
	}
	// 更新货盘
	pool_id, err = dao.UpdateAnalysisPool(ctx, tx, req, employeeId)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "[UpdateAnalysisPool]调用更新货盘sql失败，err=%v+", err)
		return pool_id, err
	}
	// 提交事务
	tx.Commit()
	return pool_id, nil
}

func (t *AnalysisPoolService) UpdateAnalysisPoolRule(ctx context.Context, req *analysis_pool.UpdateAnalysisPoolReq) (pool_id string, err error) {
	if req.GetPoolRule() == "" {
		logs.CtxError(ctx, "[UpdateAnalysisPool]更新规则为空")
		return pool_id, errors.New("更新规则为空")
	}

	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[UpdateAnalysisPool]获取数据库的事务失败，err=%s", tx.Error.Error())
		return pool_id, errors.New("获取数据库的事务失败")
	}
	// 更新货盘
	err = dao.UpdateAnalysisPoolRule(ctx, tx, req.PoolId, req.GetPoolRule())
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "[UpdateAnalysisPool]调用更新货盘sql失败，err=%s", err)
		return pool_id, err
	}
	// 提交事务
	tx.Commit()
	return pool_id, nil
}

func (t *AnalysisPoolService) QueryAnalysisPoolList(ctx context.Context, req *analysis_pool.QueryAnalysisPoolListReq) (resp *analysis_pool.QueryAnalysisPoolListData, err error) {
	resp = &analysis_pool.QueryAnalysisPoolListData{}
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolList]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return resp, errors.New("获取数据库的事务失败")
	}
	analysisPoolList, total, err := dao.QueryAnalysisPoolList(ctx, tx, req)
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolList]调用查询货盘sql失败，err=%v+", err)
		tx.Rollback()
		return resp, err
	}
	enhanceAnalysisPoolList := make([]*analysis_pool.AnalysisPool, 0, len(analysisPoolList))
	for _, pool := range analysisPoolList {
		enhancePool := pool
		applicationRecordList, err := dao.GetAnalysisPoolApplicationRecordList(ctx, tx, pool.GetPoolId())
		if err != nil {
			logs.CtxError(ctx, "[QueryAnalysisPoolList]调用查询货盘关联应用sql失败，err=%v+", err)
			tx.Rollback()
			return resp, err
		}
		enhancePool.ApplicationRecordList = applicationRecordList
		enhanceAnalysisPoolList = append(enhanceAnalysisPoolList, enhancePool)
	}

	// 提交事务
	tx.Commit()

	resp = &analysis_pool.QueryAnalysisPoolListData{
		PageInfo: &base.PageResp{
			PageNum:  req.PageReq.PageNum,
			PageSize: req.PageReq.PageSize,
			Total:    total,
		},
		List: enhanceAnalysisPoolList,
	}

	return resp, nil
}

func (t *AnalysisPoolService) QueryAnalysisPoolDetail(ctx context.Context, req *analysis_pool.QueryAnalysisPoolDetailReq) (resp *analysis_pool.QueryAnalysisPoolDetailData, err error) {
	resp = &analysis_pool.QueryAnalysisPoolDetailData{}
	// 创建动态货盘，获取商品数量
	if req.PoolId == "" && req.BaseStruct != nil {
		prodCnt, err := QueryRulePoolDetail(ctx, req)
		if err != nil {
			return resp, err
		}
		resp.Info = &analysis_pool.AnalysisPool{
			PoolType:   analysis_pool.AnalysisPoolType_DynamicRule,
			BaseStruct: req.BaseStruct,
		}
		resp.ProdCnt_1d = prodCnt
		return resp, nil
	}
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolDetail]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return resp, errors.New("获取数据库的事务失败")
	}
	analysisPool, err := dao.GetAnalysisPool(ctx, tx, req.GetPoolId())
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolDetail]调用查询货盘sql失败，err=%v+", err)
		tx.Rollback()
		return resp, err
	}
	applicationRecordList, err := dao.GetAnalysisPoolApplicationRecordList(ctx, tx, analysisPool.GetPoolId())
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolDetail]调用查询货盘关联应用sql失败，err=%v+", err)
		tx.Rollback()
		return resp, err
	}
	analysisPool.ApplicationRecordList = applicationRecordList

	resp = &analysis_pool.QueryAnalysisPoolDetailData{
		Info: analysisPool,
	}
	bizType := dimensions.BizType_GrowthProductStrategy
	if analysisPool.PoolType == analysis_pool.AnalysisPoolType_FixedProd {
		_, total, err := dao.GetAnalysisPoolPidList(ctx, tx, analysisPool.GetPoolId())
		if err != nil {
			logs.CtxError(ctx, "[GetPoolAndPidList]调用查询货盘商品sql失败，err=%v+", err)
			tx.Rollback()
			return resp, err
		}
		resp.ProdCnt_1d = total
	} else {
		bizType = utils.If(analysisPool.BaseStruct.BizType == dimensions.BizType_GreatValueBuy, dimensions.BizType_GreatValueBuy, dimensions.BizType_GrowthProductStrategy)
		if analysisPool.BaseStruct.BizType == dimensions.BizType_BrandTrial {
			bizType = dimensions.BizType_BrandTrial
		}
		readyTime, err := t.DimensionService.GetReadyTime(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "[QueryAnalysisPoolDetail]GetReadyTime失败，err=%v+", err)
			tx.Rollback()
			return resp, err
		}
		productListInfo, err := (&analysis_pool_product_service.AnalysisPoolProductService{DimensionListDao: new(dao.DimensionListDao)}).
			QueryAnalysisPoolProductList(ctx, &analysis_pool_product.QueryAnalysisPoolProductListReq{
				PageReq:   &base.PageInfo{PageSize: 1, PageNum: 1},
				PoolId:    req.PoolId,
				StartDate: &readyTime.NewestPartition_,
				EndDate:   &readyTime.NewestPartition_,
			})
		if err != nil {
			logs.CtxError(ctx, "[QueryAnalysisPoolDetail]QueryAnalysisPoolProductList失败，err=%v+", err)
			tx.Rollback()
			return resp, err
		}
		if productListInfo != nil && productListInfo.PageInfo != nil {
			resp.ProdCnt_1d = productListInfo.PageInfo.Total
		}
	}

	if analysisPool.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		// 将算法特征任务信息补充到货盘详情上
		poolSelectDao := new(dao.ProductSelectTaskDao)
		task, err := poolSelectDao.GetProductSelectTaskWithPoolId(ctx, tx, analysisPool.GetPoolId())
		if err != nil {
			logs.CtxError(ctx, "[QueryAnalysisPoolDetail]调用查询货盘关联调控活动sql失败，err=%v+", err)
			tx.Rollback()
			return resp, err
		}

		tmpTask := &product_select.ProductSelectTask{
			TaskId:       strconv.FormatInt(task.TaskId, 10),
			TaskName:     task.TaskName,
			BizType:      dimensions.BizType(task.BizType),
			TargetAmount: task.TargetAmount,
			CreateUserId: task.CreateUserId,
			UpdateUserId: task.UpdateUserId,
			CreateTime:   task.CreateTime.Unix(),
			UpdateTime:   task.UpdateTime.Unix(),
			IsDel:        int32(task.IsDelete),
			PoolId:       task.PoolId,
		}
		if task.Extra != "" {
			extra := &product_select.Extra{}
			err := sonic.UnmarshalString(task.Extra, extra)
			if err != nil {
				logs.CtxError(ctx, "[QueryAnalysisPoolDetail]sonic.UnmarshalString failed, err: %s", err)
				tx.Rollback()
				return resp, err
			}
			tmpTask.Extra = extra
		}
		resp.FeatureRuleInfo = tmpTask
	}

	resp.ProdTagCode = fmt.Sprintf("%d###%s", int64(bizType), req.PoolId)

	// 提交事务
	tx.Commit()

	return resp, nil
}

// QueryRulePoolDetail 查询规则货盘商品数量
func QueryRulePoolDetail(ctx context.Context, req *analysis_pool.QueryAnalysisPoolDetailReq) (int64, error) {
	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseStruct.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "[QueryRulePoolDetail]业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return 0, err
	}
	bizType := req.BaseStruct.BizType
	dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[QueryRulePoolDetail]获取map失败，err=%v+", err)
		return 0, err
	}
	var orderField = base.OrderByField_ShowPv
	osReq := base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseStruct,
		DimMap:     dimMap,
		PageInfo:   &base.PageInfo{PageNum: 1, PageSize: 20},
		OrderBy: &base.OrderByInfo{
			Field:  &orderField,
			IsDesc: true,
		},
	}
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成oneService api 入参失败,err:"+err.Error())
		return 0, err
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()

	// api准备
	apiOverall := apiPathProdOverall
	if bizType == dimensions.BizType_GuessBoostData {
		curr["select_type"] = "overview_info"
		if biz_utils.ApiPathMap[bizType] != nil {
			apiOverall = biz_utils.ApiPathMap[bizType].ProdOverallPath
		}
	}
	if bizInfo.EffectModule == "大促视图" { // 第一个api逻辑表已经达到上限30个
		apiOverall = apiPathProdOverallV2
	}

	// 整体信息，商家数, 商品总数
	f.ExeQueryInvokerRaw(curr, apiOverall, param.SinkTable("overview_info")).SetParallel(true).SetMaxParallelNum(5)
	var overviewInfo = make(map[string]int64)
	f.ExeView(param.SourceTable("overview_info"), &overviewInfo)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return 0, err
	}
	if _, ok := overviewInfo["product_cnt"]; ok {
		return overviewInfo["product_cnt"], nil
	}
	return 0, nil
}

// CreateAnalysisPoolApplicationRecord 创建货盘下游应用记录
func (s *AnalysisPoolService) CreateAnalysisPoolApplicationRecord(ctx context.Context, req *analysis_pool.CreateAnalysisPoolApplicationRecordReq) (record_id string, err error) {
	if req.PoolId == "" {
		return "", errors.New("货盘应用记录创建失败，请输入货盘ID")
	}
	if req.ApplicationVector == analysis_pool.ApplicationVector_Hive {
		if req.UpdateFrequency == nil {
			return "", errors.New("货盘应用记录创建失败，请输入更新频率")
		}
		if req.TargetHiveWarehouseName == nil || *req.TargetHiveWarehouseName == "" {
			return "", errors.New("货盘应用记录创建失败，请输入目标HIVE表库名")
		}
		if req.TargetHiveTableName == nil || *req.TargetHiveTableName == "" {
			return "", errors.New("货盘应用记录创建失败，请输入目标HIVE表名")
		}
		if req.TargetHiveProdAlias == nil || *req.TargetHiveProdAlias == "" {
			return "", errors.New("货盘应用记录创建失败，请输入商品id别名")
		}
	}

	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[CreateAnalysisPoolApplicationRecord]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return "", errors.New("获取数据库的事务失败")
	}

	var employeeId string
	ecopCurrentUser, exist := metainfo.GetPersistentValue(ctx, "ECOP_CURRENT_USER")
	if exist {
		var ecopUser guard.OpUser
		castErr := json.Unmarshal([]byte(ecopCurrentUser), &ecopUser)
		if castErr == nil {
			employeeId = ecopUser.EmployeeId
		}
	}
	if employeeId == "" {
		employeeId, err = utils.GetOperatorEmployeeIdFromContext(ctx)
	}
	if err != nil {
		logs.CtxError(ctx, "[CreateAnalysisPoolApplicationRecord]获取操作用户userID失败，err=%v+", err)
		tx.Rollback()
		return "", err
	}

	record_id, err = dao.CreateAnalysisPoolApplicationRecord(ctx, tx, &analysis_pool.CreateAnalysisPoolApplicationRecordReq{
		PoolId:                  req.PoolId,
		ApplicationScene:        req.ApplicationScene,
		ApplicationVector:       req.ApplicationVector,
		UpdateFrequency:         req.UpdateFrequency,
		TargetHiveWarehouseName: req.TargetHiveWarehouseName,
		TargetHiveTableName:     req.TargetHiveTableName,
		TargetHiveProdAlias:     req.TargetHiveProdAlias,
	}, employeeId)
	if err != nil {
		logs.CtxError(ctx, "[CreateAnalysisPoolApplicationRecord]CreateAnalysisPoolApplicationRecord失败，err=%v+", err)
		tx.Rollback()
		return "", err
	}

	// 提交事务
	tx.Commit()

	return record_id, nil
}

// GetDoradoAnalysisPoolApplicationHiveCallBack 货盘应用hive任务回调
func (s *AnalysisPoolService) GetDoradoAnalysisPoolApplicationHiveCallBack(ctx context.Context, req *dorado_task.GetDoradoTaskRunningCallBackRequest) (err error) {
	applicationRecords, err := getApplicationHiveSqlRes(ctx)
	if err != nil {
		logs.CtxInfo(ctx, "[GetDoradoAnalysisPoolApplicationHiveCallBack]getApplicationHiveSqlRes err=%v, req=%v", err, req)
		return err
	}
	if len(applicationRecords) == 0 {
		logs.CtxInfo(ctx, "[GetDoradoAnalysisPoolApplicationHiveCallBack]applicationRecords is empty, req=%v", req)
		return nil
	}
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[GetDoradoAnalysisPoolApplicationHiveCallBack]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return errors.New("获取数据库的事务失败")
	}
	// 根据applicationRecords 批量修改application_record_status_info表
	for _, applicationRecord := range applicationRecords {
		applicationStatus, err := strconv.ParseInt(applicationRecord.ApplicationStatus, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[GetDoradoAnalysisPoolApplicationHiveCallBack]ParseInt err=%v, req=%v", err, req)
			tx.Rollback()
			return err
		}
		err = dao.UpdateApplicationRecordStatusInfo(ctx, tx, dao.BatchUpdateApplicationRecordStatusInfoReq{
			ApplicationRecordId:  applicationRecord.ApplicationRecordId,
			ApplicationStatus:    applicationStatus,
			ApplicationErrorInfo: applicationRecord.ApplicationErrorInfo,
		})
		if err != nil {
			logs.CtxError(ctx, "[GetDoradoAnalysisPoolApplicationHiveCallBack]UpdateApplicationRecordStatusInfo err=%v, req=%v record=%v", err, req, applicationRecord)
			tx.Rollback()
			return err
		}
	}
	// 提交事务
	tx.Commit()

	return nil
}

// 转换函数：将[][]string转换为[]ApplicationRecordStatusInfo
func convertToApplicationRecordStatusInfo(tqsRes [][]string) ([]ApplicationRecordStatusInfo, error) {
	// 检查输入是否有效
	if len(tqsRes) == 0 {
		return nil, fmt.Errorf("输入数据为空")
	}
	// 检查表头是否符合预期
	header := tqsRes[0]
	if len(header) < 3 ||
		header[0] != "application_record_id" ||
		header[1] != "application_status" ||
		header[2] != "application_error_info" {
		return nil, fmt.Errorf("表头不符合预期")
	}

	// 如果只有表头没有数据
	if len(tqsRes) == 1 {
		return []ApplicationRecordStatusInfo{}, nil
	}

	// 转换数据行
	var result []ApplicationRecordStatusInfo
	for i, row := range tqsRes[1:] { // 从索引1开始，跳过表头
		// 确保每行至少有3个元素
		if len(row) < 3 {
			return nil, fmt.Errorf("第%d行数据不足3个字段", i+2) // +2是因为行号从1开始，且跳过了表头
		}

		record := ApplicationRecordStatusInfo{
			ApplicationRecordId:  row[0],
			ApplicationStatus:    row[1],
			ApplicationErrorInfo: row[2],
		}
		result = append(result, record)
	}

	return result, nil
}

func getApplicationHiveSqlRes(ctx context.Context) ([]ApplicationRecordStatusInfo, error) {
	res := []ApplicationRecordStatusInfo{}
	querySql := "SELECT application_record_id, application_status, application_error_info FROM ecom_data.smartop_product_analysis_pool_application_record_status_info WHERE date = max_pt('ecom_data.smartop_product_analysis_pool_application_record_status_info')"

	logs.CtxInfo(ctx, "[getHiveSqlTplRes]tqs.QuerySync start, querySql=%s", querySql)
	queryRes, err := tqs.QuerySync(ctx, querySql, true)
	if err != nil {
		return res, err
	}
	if queryRes == nil || len(queryRes.Result) < 2 {
		logs.CtxInfo(ctx, "[getHiveSqlTplRes]queryRes is nil, querySql=%s", querySql)
		return res, fmt.Errorf("当前querySql查不出结果，请检查%s", querySql)
	}
	tqsRes := queryRes.Result
	logs.CtxInfo(ctx, "[getHiveSqlTplRes]tqs.QuerySync end, res=%s", tqsRes)
	applicationRecords, err := convertToApplicationRecordStatusInfo(tqsRes)
	if err != nil {
		logs.CtxInfo(ctx, "[getHiveSqlTplRes]convertToApplicationRecordStatusInfo err=%v, tqsRes=%s", err, tqsRes)
		return res, err
	}
	res = applicationRecords

	return res, nil
}
