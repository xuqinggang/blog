package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"strings"
)

const ReversalFlightId = "3241866" // 大反转实验的实验ID

func (v *VolumePriceService) GetReversalExperimentCoreData(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.ReversalExperimentCoreDataItem, err error) {
	resp = &volume_price.ReversalExperimentCoreDataItem{
		ObjectList:  make([]*volume_price.ReversalExperimentCoreDataRow, 0),
		TwoSideList: make([]*volume_price.ReversalExperimentCoreDataRow, 0),
	}

	twoSideList, uvClusterProdCnt, osParams, err := v.GetReversalExperimentDetail(ctx, req, false)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	if twoSideList != nil {
		resp.TwoSideList = twoSideList.Rows
	}
	// 打包计算显著性的入参
	var targetMap = make(map[string]map[string]*analysis.TargetCardEntity)
	for _, row := range resp.TwoSideList {
		if _, ok := targetMap[row.Code]; !ok {
			targetMap[row.Code] = make(map[string]*analysis.TargetCardEntity)
		}
		for _, entity := range row.TargetList {
			targetMap[row.Code][entity.Name] = entity
		}
	}
	// 生成簇数量和人和品数量的入参
	var uvMap, clusterMap, prodMap = make(map[string]float64), make(map[string]float64), make(map[string]float64)
	for _, row := range uvClusterProdCnt {
		uvMap[row.CellCode] = row.Uv
		clusterMap[row.CellCode] = row.ClusterCnt
		prodMap[row.CellCode] = row.GroupProdCnt
	}
	// 显著性方法的入参
	significantParams := ExperimentSignificantParams{
		CombinationTargetMap:      targetMap,
		ExperimentCombinationList: req.Combination,
		ClusterCntMap:             clusterMap,
		UserCntMap:                uvMap,
		ProdCntMap:                prodMap,
		BizType:                   req.BaseReq.BizType,
		OSParam:                   osParams,
	}
	// 获取评估对象实验组和对照组相比的显著性
	significantAllTargets, significantTargets, err := v.GetCombinationExperimentSignificantTargetList(ctx, significantParams)
	if err != nil {
		return nil, err
	}

	var fid string
	if req.FlightId != nil {
		fid = *req.FlightId
	} else {
		fid = ReversalFlightId
	}
	configMetaInfo, err := v.VolumePriceDao.GetExperimentConfigMetaInfo(ctx, fid)
	if err != nil {
		logs.CtxError(ctx, "GetVolumePriceBilateralLibra failed, %v+", err)
		return nil, err
	}
	var confMap = make(map[string]*dao.ExprConfigMetaInfo)
	for _, info := range configMetaInfo {
		confMap[info.ObjectCode] = info
	}

	// 拼接分析对象DIFF指标卡
	for _, object := range req.Combination {
		if exprTargetMap, ok := targetMap[object.ExprGroupId]; ok {
			row := &volume_price.ReversalExperimentCoreDataRow{
				Code:      object.Code,
				GroupName: object.Name,
				RowType:   "object",
			}
			if _, ok2 := confMap[object.ExprGroupId]; ok2 {
				if _, ok3 := confMap[object.CompareGroupId]; ok3 {
					suffix := fmt.Sprintf("(%s-%s)", confMap[object.ExprGroupId].ObjectName, confMap[object.CompareGroupId].ObjectName)
					if !strings.HasSuffix(row.GroupName, suffix) {
						row.GroupName = row.GroupName + suffix
					}
				}
			}
			var targetList = make([]*analysis.TargetCardEntity, 0)
			for targetName, entity := range exprTargetMap {
				if compareMap, ok2 := targetMap[object.CompareGroupId]; ok2 {
					if compareCard, ok3 := compareMap[targetName]; ok3 {
						card := &analysis.TargetCardEntity{
							Name:        entity.Name,
							DisplayName: entity.DisplayName,
							Tips:        entity.Tips,
							Unit:        entity.Unit,
							Extra: &analysis.TargetCardExtraInfo{
								AttributeType:     entity.Extra.AttributeType,
								DistributionFlag:  entity.Extra.DistributionFlag,
								IsDefaultShow:     entity.Extra.IsDefaultShow,
								IsLargerAdvantage: entity.Extra.IsLargerAdvantage,
								PercentFlag:       entity.Extra.PercentFlag,
							},
							DisplayOrder:    entity.DisplayOrder,
							NeedSecondQuery: entity.NeedSecondQuery,
							IsUsePp:         entity.IsUsePp,
							ValueType:       entity.ValueType,
							TargetPrecision: entity.TargetPrecision,
							IsShow:          entity.IsShow,
						}
						card.Value = entity.Value - compareCard.Value
						card.DisplayValue = framework_udf.GetBriefMetricDisplayValueNoErr(card.Value, card.ValueType, card.Unit, int(card.TargetPrecision))
						card.DiffExtra = &analysis.DiffExtraInfo{
							Diff:         card.Value,
							DisplayValue: card.DisplayValue,
						}
						if compareCard.Value == 0 {
							card.DiffExtra.DiffRatio = 0
						} else {
							card.DiffExtra.DiffRatio = card.DiffExtra.Diff / compareCard.Value
						}
						if targetNameList, ok4 := significantTargets[object.Code]; ok4 {
							if slices.ContainsString(targetNameList, card.Name) {
								card.Extra.TargetTag = "显著"
							} else if slices.ContainsString(significantAllTargets, card.Name) {
								card.Extra.TargetTag = "不显著"
							}
						}
						targetList = append(targetList, card)
					}
				}
			}
			row.TargetList = targetList
			resp.ObjectList = append(resp.ObjectList, row)
		}
	}
	for _, row := range resp.TwoSideList {
		row.TargetList = FilterNotShowTarget(row.TargetList)
	}
	for _, row := range resp.ObjectList {
		row.TargetList = FilterNotShowTarget(row.TargetList)
	}

	for _, row := range resp.ObjectList {
		biz_utils.SortTargetList(row.TargetList)
	}
	return resp, nil
}

func (v *VolumePriceService) GetReversalExperimentDetail(ctx context.Context, req *volume_price.GetReversalExperimentRequest, needAllObject bool) (resp *volume_price.GetReversalExperimentDetailItem, uvClusterProdCnt []*UvClusterProdCellCnt, osParams map[string]interface{}, err error) {
	resp = &volume_price.GetReversalExperimentDetailItem{
		Rows: make([]*volume_price.ReversalExperimentCoreDataRow, 0),
	}
	uvClusterProdCnt = make([]*UvClusterProdCellCnt, 0)
	var fid string
	if req.FlightId == nil {
		fid = ReversalFlightId
		req.FlightId = &fid
	}
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, nil, nil, err
	}
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	// 这里固定对b侧和c侧实验下钻
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return nil, nil, nil, err
	}
	// 生成select 的case when条件和where条件
	var selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition string
	if needAllObject {
		selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition, err = v.GenExprConditionByFid(ctx, convert.ToInt64(*req.FlightId), []int64{convert.ToInt64(volume_price.ExprObjectType_BCTwoSide)})
	} else {
		selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition, err = v.GenExprConditionByObjectList(ctx, req.Combination)
	}
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, nil, nil, err
	}
	// 添加必选的载体参数
	var contentType string
	switch req.ContentType {
	case volume_price.ContentType_All:
		contentType = "all"
	case volume_price.ContentType_Video:
		contentType = "video"
	case volume_price.ContentType_Live:
		contentType = "live"
	case volume_price.ContentType_ProductCard:
		contentType = "product_card"
	case volume_price.ContentType_HardAdVideo:
		contentType = "hard_ad_video"
	default:
		contentType = "all"
	}
	curr["content_type"] = contentType
	curr["select_express"] = selectExpress
	curr["where_condition"] = whereCondition
	curr["uv_select_express"] = uvSelectExpress
	curr["uv_where_condition"] = uvWhereCondition
	curr["cluster_cnt_select_express"] = clusterCntSelectExpress
	curr["cluster_cnt_where_condition"] = clusterCntWhereCondition
	curr["flight_id"] = *req.FlightId
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst(true), param.SourceConst([]string{})}, dao.GetTargetMetaInfoWithNotShow, param.SinkTable("target_meta"))
	f.ExeQueryInvokerRaw(curr, apiPathBothSideExprTarget, param.SinkTable("target_card")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeProduceSql(`select cell_code, cluster_cnt, uv, group_prod_cnt from target_card`, param.SinkTable("uv_cluster_prod_cnt"))
	// 指标值行转列, cell_code是实验组单元格的code，每个实验组有一组指标
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"cell_code"}))
	marketSubSql := `
				(
				select  
						a.attribute_type as attribute_type,
						a.is_compute_percent as percent_flag,
						a.is_larger_advantage as is_larger_advantage,
						is_distribution as distribution_flag,
						a.is_default_show as is_default_show
				)`
	f.ExeProduceSql(fmt.Sprintf(`
		select  
				cell_code,
				a.name as name,
				b.target_value as value,
				get_display_value(b.target_value, a.value_type, a.value_unit,a.target_precision) as display_value,
				a.display_name as display_name,
				a.tips as tips,
				a.value_unit as unit,
				a.attribute_type as category_name,
				%v as extra,
				a.display_order as display_order,
				a.need_second_query as need_second_query,
				a.is_use_pp as is_use_pp,
				a.value_type as value_type,
				a.target_precision as target_precision,
				a.is_show as is_show
		from    target_meta a
		inner join
				target_card b
		on      a.name=b.target_name
		order by a.display_order asc
	`, marketSubSql), param.SinkTable("card_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	// 获取实验组元信息，存到一张表中
	if needAllObject {
		f.ExeQueryCustom([]param.Source{param.SourceConst(convert.ToInt64(*req.FlightId)), param.SourceConst([]int64{convert.ToInt64(volume_price.ExprObjectType_BCTwoSide)})}, v.VolumePriceDao.GetRelatedExperimentConfigByFid, param.SinkTable("cell_code_table"))
	} else {
		f.ExeQueryCustom([]param.Source{param.SourceConst(req.Combination)}, v.VolumePriceDao.GetRelatedExprList, param.SinkTable("cell_code_table"))
	}
	//f.ExeProduceSql(`select cell_code from card_data group by cell_code`, param.SinkTable("cell_code_table"))
	// 打包实验组单元格数据
	f.ExeProduceSql(`
		select  expr_group_id as code,
				case 
					when expr_group_desc = '' then expr_group_name 
					else concat(expr_group_name,'：',expr_group_desc) 
				end as group_name,
				v_type as row_type,
				(
					select  name,
							value,
							display_value,
							display_name,
							tips,
							unit,
							category_name,
							extra,
							need_second_query,
							display_order,
							is_use_pp,
							value_type,
							target_precision,
							is_show
					from    card_data a
					where   a.cell_code = cell_code_table.expr_group_id
				) as target_list
		from    cell_code_table`, param.SinkTable("res_data"))
	f.ExeView(param.SourceTable("res_data"), &resp.Rows)
	f.ExeView(param.SourceTable("uv_cluster_prod_cnt"), &uvClusterProdCnt)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, nil, nil, err
	}
	for _, row := range resp.Rows {
		biz_utils.SortTargetList(row.TargetList)
	}
	return resp, uvClusterProdCnt, curr, nil
}

func FilterNotShowTarget(targetList []*analysis.TargetCardEntity) []*analysis.TargetCardEntity {
	var res = make([]*analysis.TargetCardEntity, 0)
	for _, target := range targetList {
		if target.IsShow {
			res = append(res, target)
		}
	}
	return res
}
