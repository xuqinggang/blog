package volume_price_service

import (
	"code.byted.org/ecom/smartop_growth_analysis_rpc/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/henrylee2cn/ameda"
	"sort"
	"strconv"
	"strings"
)

type LibraTargetData struct {
	FlightInfo    *basic_info.LibraBasicInfo
	VersionInfo   *basic_info.LibraVersionBasicInfo
	Scenarios     volume_price.AnalyzeScenarios
	ScenariosName string
	TargetMap     map[string]*analysis.TargetCardEntity
}

var ABDiffAttributeType = "扶持商品"
var ProdCntPercentMap = map[string]string{
	"ab_ord_recalculate_diff_prod_cnt": "show_boost_prod_cnt",
	"ab_gmv_recalculate_diff_prod_cnt": "show_boost_prod_cnt",
	"show_boost_prod_cnt":              "show_prod_cnt",
}
var ControlNotShowTargetList = []string{
	"ab_gmv_recalculate_diff_prod_cnt", "ab_ord_recalculate_diff_prod_cnt", "show_pv_abdiff", "show_pv_abdiff_ratio", "click_pv_abdiff", "click_pv_abdiff_ratio", "pay_amt_abdiff", "pay_amt_abdiff_ratio", "pay_ord_cnt_abdiff", "pay_ord_cnt_abdiff_ratio", "opm_abdiff", "opm_abdiff_ratio", "gpm_abdiff", "gpm_abdiff_ratio", "prod_day_avg_show_pv_abdiff", "prod_day_avg_show_pv_abdiff_ratio", "prod_day_avg_click_pv_abdiff", "prod_day_avg_click_pv_abdiff_ratio", "prod_day_avg_pay_amt_abdiff", "prod_day_avg_pay_amt_abdiff_ratio", "prod_day_avg_pay_ord_cnt_abdiff", "prod_day_avg_pay_ord_cnt_abdiff_ratio", "prod_day_avg_opm_abdiff", "prod_day_avg_opm_abdiff_ratio", "prod_day_avg_gpm_abdiff", "prod_day_avg_gpm_abdiff_ratio", "ab_show_pv_diff_ratio_30_prod_cnt", "ab_ord_cnt_diff_ratio_20_prod_cnt", "ab_gmv_diff_ratio_20_prod_cnt", "roi_1_ord_diff_val",
}

func GetSceneKeyById(scenarios volume_price.AnalyzeScenarios, id string) string {
	return id + consts.Sep + convert.ToString(convert.ToInt64(scenarios))
}

func (v *VolumePriceService) GetVolumePriceLibraInfoMap(ctx context.Context, startDate, endDate string) (retMap map[string]LibraTargetData, err error) {
	libraList, err := v.GetVolumePriceLibraList(ctx, &volume_price.GetVolumePriceLibraListRequest{
		StartDate: startDate,
		EndDate:   endDate,
	}, nil)
	if err != nil {
		return nil, err
	}
	retMap = make(map[string]LibraTargetData)
	for _, info := range libraList {
		if len(info.VersionList) > 0 {
			for _, vInfo := range info.VersionList {
				retMap[GetSceneKeyById(info.Scenarios, vInfo.VersionId)] = LibraTargetData{
					FlightInfo:    info.FlightInfo,
					VersionInfo:   vInfo,
					Scenarios:     info.Scenarios,
					ScenariosName: info.ScenariosName,
				}
			}
		}
	}
	return retMap, nil
}

func (v *VolumePriceService) GetVolumePriceLibraVersionList(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp []*volume_price.LibraFlightInfoData, err error) {
	if len(req.LibraParam.FlightIds) == 0 && len(req.LibraParam.FlightParamList) == 0 {
		return resp, errors.New("未选择实验ID筛选项")
	}
	dateDiff := time_utils.DateDiffAbs(req.BaseReq.StartDate, req.BaseReq.EndDate)
	if dateDiff > 30 && len(req.LibraParam.FlightParamList) > 3 {
		return resp, errors.New("查询日期超过30天，最多选三个实验")
	}
	// 获取业务线的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	// 获取invoker的入参
	curr, err := base_struct_condition.GetVolumePriceConditionSimpleParam(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return
	}

	if len(req.LibraParam.FlightParamList) > 0 {
		fParamFilter := make([]string, 0)
		for _, fParam := range req.LibraParam.FlightParamList {
			fParamFilter = append(fParamFilter, fmt.Sprintf("(flight_id = %s and scenarios = %d)", fParam.FlightId, convert.ToInt64(fParam.Scenarios)))
		}
		curr["flight_param_filter"] = fmt.Sprintf("(%s)", strings.Join(fParamFilter, " or "))
	} else {
		curr["flight_ids"], err = ameda.StringsToInt64s(req.LibraParam.FlightIds)
		if err != nil {
			logs.CtxWarn(ctx, "传入非法实验ID，err = %s", err)
			return resp, errors.New("传入非法实验ID")
		}
	}
	libraVIdMap, err := v.GetVolumePriceLibraInfoMap(ctx, req.BaseReq.StartDate, req.BaseReq.EndDate)
	if err != nil {
		return resp, err
	}

	vids := make([]int64, 0)
	for vid, _ := range libraVIdMap {
		vids = append(vids, convert.ToInt64(strings.Split(vid, consts.Sep)[0]))
	}
	curr["version_ids"] = vids

	targetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty,
		ApiPath: apiPathLibraVersionTargetList,
		BizType: req.BaseReq.BizType, NeedDistribution: true,
		KeyCols:                []string{"version_id", "scenarios"},
		TargetMetaEffectModule: []string{"核心汇总"},
	})
	if err != nil {
		return resp, err
	}

	targetMetaMap, err := base_struct_condition.GetFilterTargetMetaInfoMap(ctx, int64(req.BaseReq.BizType), false, false, nil, "核心汇总")
	if err != nil {
		return resp, err
	}

	// 将查询的实验组分组
	libraFidMap := make(map[string][]LibraTargetData)
	flightControlGroupTargetMap := make(map[string]map[string]*analysis.TargetCardEntity)
	for _, info := range targetList {
		if len(info.KeyColValues) >= 2 {
			versionSceneKey := convert.ToString(info.KeyColValues[0]) + consts.Sep + convert.ToString(info.KeyColValues[1])
			if libraInfo, exist := libraVIdMap[versionSceneKey]; exist && libraInfo.FlightInfo != nil && libraInfo.VersionInfo != nil {
				flightSceneKey := GetSceneKeyById(libraInfo.Scenarios, libraInfo.FlightInfo.FlightId)

				libraTargetData := LibraTargetData{
					FlightInfo:    libraInfo.FlightInfo,
					VersionInfo:   libraInfo.VersionInfo,
					Scenarios:     libraInfo.Scenarios,
					ScenariosName: libraInfo.ScenariosName,
					TargetMap:     make(map[string]*analysis.TargetCardEntity),
				}
				for _, t := range info.TargetEntity {
					libraTargetData.TargetMap[t.Name] = t
				}

				if libraTargetData.VersionInfo.VersionType == basic_info.LibraVersionType_ControlGroup {
					controlGroupTargetMap := flightControlGroupTargetMap[flightSceneKey]
					if controlGroupTargetMap == nil {
						controlGroupTargetMap = make(map[string]*analysis.TargetCardEntity)
					}
					for _, t := range info.TargetEntity {
						controlGroupTargetMap[t.Name] = t
					}
					flightControlGroupTargetMap[flightSceneKey] = controlGroupTargetMap
				}

				versionArr := libraFidMap[flightSceneKey]
				if len(versionArr) == 0 {
					versionArr = make([]LibraTargetData, 0)
				}
				versionArr = append(versionArr, libraTargetData)
				libraFidMap[flightSceneKey] = versionArr
			}
		}
	}

	// 分别计算AB DIFF
	resp = make([]*volume_price.LibraFlightInfoData, 0)
	for _, infoArr := range libraFidMap {
		if len(infoArr) == 0 {
			continue
		}

		flightInfo := &volume_price.LibraFlightInfoData{
			FlightInfo:    infoArr[0].FlightInfo,
			VersionList:   make([]*volume_price.LibraVersionListRow, 0),
			Scenarios:     infoArr[0].Scenarios,
			ScenariosName: infoArr[0].ScenariosName,
		}
		for _, info := range infoArr {
			newTargetList := make([]*analysis.TargetCardEntity, 0)
			for _, target := range info.TargetMap {
				// 补充指标占比数据
				if info.VersionInfo.VersionType == basic_info.LibraVersionType_ControlGroup && slices.ContainsString(ControlNotShowTargetList, target.Name) {
					target.DisplayValue = "-"
					newTargetList = append(newTargetList, target)
					continue
				}

				if baseTargetName := ProdCntPercentMap[target.Name]; len(baseTargetName) > 0 {
					if baseTarget := info.TargetMap[baseTargetName]; baseTarget != nil {
						target.Extra.PercentFlag = true
						if baseTarget.Value != 0 {
							target.Extra.MarketPercent = target.Value / baseTarget.Value
						}
					}
				}

				newTargetList = append(newTargetList, target)

				// 补充AB DIFF 指标
				if target.Extra.AttributeType == ABDiffAttributeType {
					controlGroupTargetMap := flightControlGroupTargetMap[GetSceneKeyById(info.Scenarios, info.FlightInfo.FlightId)]
					if controlGroupTargetMap != nil {
						if controlTarget, exist := controlGroupTargetMap[target.Name]; exist {
							abDiffV := target.Value - controlTarget.Value
							abDiff := convert.ToFloat64(strconv.FormatFloat(abDiffV, 'f', 5, 64))
							abDiffTarget, err := base_struct_condition.GetTargetEntity(ctx, abDiff, targetMetaMap[target.Name+"_abdiff"])
							if err != nil {
								return nil, err
							}
							if abDiffTarget == nil {
								continue
							}
							if info.VersionInfo.VersionType == basic_info.LibraVersionType_ControlGroup {
								abDiffTarget.DisplayValue = "-"
							}
							var abDiffRatioV float64
							if controlTarget.Value != 0 {
								abDiffRatioV = abDiffV / controlTarget.Value
							}
							abDiffRatio := convert.ToFloat64(strconv.FormatFloat(abDiffRatioV, 'f', 5, 64))
							abDiffRatioTarget, err := base_struct_condition.GetTargetEntity(ctx, abDiffRatio, targetMetaMap[target.Name+"_abdiff_ratio"])
							if err != nil {
								return nil, err
							}
							if abDiffRatioTarget == nil {
								continue
							}
							if info.VersionInfo.VersionType == basic_info.LibraVersionType_ControlGroup {
								abDiffRatioTarget.DisplayValue = "-"
							}

							newTargetList = append(newTargetList, abDiffTarget)
							newTargetList = append(newTargetList, abDiffRatioTarget)

							if target.Name == "pay_ord_cnt" { // 订单增幅时，补充ROI1指标
								var roiPayDiffVal float64
								if abDiffRatioV != -1 {
									// (discount * x) / ((1-discount)*(1+x)) discount = 0.9  x = AB订单diff增幅
									roiPayDiffVal = (0.9 * abDiffRatioV) / (0.1 * (1 + abDiffRatioV))
								}
								roiPayDiff := convert.ToFloat64(strconv.FormatFloat(roiPayDiffVal, 'f', 5, 64))
								roiPayDiffTarget, err := base_struct_condition.GetTargetEntity(ctx, roiPayDiff, targetMetaMap["roi_1_ord_diff_val"])
								if err != nil {
									return nil, err
								}
								if roiPayDiffTarget != nil {
									if info.VersionInfo.VersionType == basic_info.LibraVersionType_ControlGroup {
										roiPayDiffTarget.DisplayValue = "-"
									}
									newTargetList = append(newTargetList, roiPayDiffTarget)
								}
							}
						}
					}
				}
			}

			analysis_service.SortTargetCardEntity(newTargetList)
			versionListRow := &volume_price.LibraVersionListRow{
				VersionBasicInfo: info.VersionInfo,
				TargetList:       newTargetList,
			}
			flightInfo.VersionList = append(flightInfo.VersionList, versionListRow)
		}

		// 实验组排序
		sort.Slice(flightInfo.VersionList, func(i, j int) bool {
			iVersion := flightInfo.VersionList[i].VersionBasicInfo
			jVersion := flightInfo.VersionList[j].VersionBasicInfo
			x := utils.If(iVersion == nil || iVersion.VersionType == basic_info.LibraVersionType_ControlGroup,
				0, iVersion.VersionSort)
			y := utils.If(jVersion == nil || jVersion.VersionType == basic_info.LibraVersionType_ControlGroup,
				0, jVersion.VersionSort)
			return x < y
		})
		resp = append(resp, flightInfo)
	}

	// 实验排序
	sort.Slice(resp, func(i, j int) bool {
		if resp[i].Scenarios == resp[j].Scenarios {
			return resp[i].FlightInfo.FlightStartTime > resp[j].FlightInfo.FlightStartTime
		}
		return resp[i].Scenarios < resp[j].Scenarios
	})
	return
}
