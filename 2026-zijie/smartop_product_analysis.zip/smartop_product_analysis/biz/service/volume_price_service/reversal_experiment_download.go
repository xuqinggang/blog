package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"context"
)

func (v *VolumePriceService) GetReversalExperimentDetailDownload(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangjunrui.1998@bytedance.com"
	}
	data, _, _, err := v.GetReversalExperimentDetail(ctx, req, true)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	for _, row := range data.Rows {
		row.TargetList = FilterNotShowTarget(row.TargetList)
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryCustom([]param.Source{param.SourceConst(data.Rows)}, genExprTable, param.SinkTable("target_data"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data"), param.SourceConst(email),
		param.SourceConst(data.Rows)}, doExportExprTargetCard, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func genExprTable(ctx context.Context, data []*volume_price.ReversalExperimentCoreDataRow) (*onetable.Table, error) {
	table := make([]map[string]interface{}, 0)
	for _, d := range data {
		row := make(map[string]interface{})
		row["group_name"] = d.GroupName
		for _, entity := range d.TargetList {
			row[entity.Name] = entity.Value
		}
		table = append(table, row)
	}
	return onetable.NewTable(table), nil
}

func doExportExprTargetCard(ctx context.Context, table *onetable.Table, email string, data []*volume_price.ReversalExperimentCoreDataRow) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	// 指标过多时，飞书表格的列会达到上限报错，这里按照指标分组分成多个sheet
	var sheetMap = make(map[string]*lark_export.LarkDocSheet)
	if len(data) > 0 {
		for _, entity := range data[0].TargetList {
			if entity.Extra != nil {
				if _, ok := sheetMap[entity.Extra.AttributeType]; !ok {
					sheetMap[entity.Extra.AttributeType] = lark_export.NewLarkDocSheet(entity.Extra.AttributeType, table)
					sheetMap[entity.Extra.AttributeType].AddColumn("实验组名称", "group_name")
				}
				sheetMap[entity.Extra.AttributeType].AddColumn(entity.DisplayName, entity.Name)
			}
		}
	}
	for _, sheet := range sheetMap {
		formatter.AddSheet(sheet)
	}
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "双边实验组明细数据")
	return nil, formatter.Export(ctx, email, nil, nil)
}

func (v *VolumePriceService) GetReversalExperimentCoreDataDownload(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangjunrui.1998@bytedance.com"
	}
	data, err := v.GetReversalExperimentCoreData(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	var rows = make([]*volume_price.ReversalExperimentCoreDataRow, 0)
	rows = append(rows, data.ObjectList...)
	rows = append(rows, data.TwoSideList...)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryCustom([]param.Source{param.SourceConst(rows)}, genExprTable, param.SinkTable("target_data"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data"), param.SourceConst(email),
		param.SourceConst(rows)}, doExportExprTargetCard, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}
