package volume_price_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

func (v *VolumePriceService) GetVolumePriceMultiDimFullList(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisMultiDimFullListData, err error) {
	if req.LibraParam == nil || len(req.LibraParam.ControlGroupVersionId) == 0 || len(req.LibraParam.ExperimentalGroupVersionId) == 0 || (len(req.LibraParam.FlightIds) == 0 && len(req.LibraParam.FlightParamList) == 0) {
		logs.CtxWarn(ctx, "[GetVolumePriceMultiDimFullList]入参无实验数据，req=%s", convert.ToJSONString(req))
		return nil, errors.New("未填入实验数据的参数")
	}
	appendParams := analysis_service.AppendParams{
		OSParams:  make(map[string]interface{}, 0),
		OSApiPath: apiPathMultiDimList,
	}

	if len(req.LibraParam.FlightParamList) > 0 {
		appendParams.OSParams["flight_id"] = convert.ToInt64(req.LibraParam.FlightParamList[0].FlightId)
		appendParams.OSParams["scenarios"] = []int64{convert.ToInt64(req.LibraParam.FlightParamList[0].Scenarios)}
	} else {
		appendParams.OSParams["flight_id"] = convert.ToInt64(req.LibraParam.FlightIds[0])
	}
	appendParams.OSParams["version_ids"] = []int64{convert.ToInt64(req.LibraParam.ExperimentalGroupVersionId), convert.ToInt64(req.LibraParam.ControlGroupVersionId)}
	appendParams.OSParams["experimental_group_version_id"] = []int64{convert.ToInt64(req.LibraParam.ExperimentalGroupVersionId)}
	appendParams.OSParams["control_group_version_id"] = []int64{convert.ToInt64(req.LibraParam.ControlGroupVersionId)}

	appendParams.IsAllTotal = true
	allTotal, err := v.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
		BaseReq: req.BaseReq,
	}, appendParams)
	if err != nil {
		return resp, err
	}

	appendParams.IsAllTotal = false
	resp, err = v.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, &analysis.GetProductAnalysisMultiDimFullListRequest{
		BaseReq: req.BaseReq,
	}, appendParams)
	if err != nil {
		return resp, err
	}

	if resp != nil && resp.Total != nil && allTotal != nil && allTotal.AllTotal != nil {
		resp.Total.TargetList = allTotal.AllTotal.TargetList
		//resp.Total.ProdTagCode = consts.Empty
	}
	return resp, nil
}
