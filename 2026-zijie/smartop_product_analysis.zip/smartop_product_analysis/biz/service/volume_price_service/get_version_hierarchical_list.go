package volume_price_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/henrylee2cn/ameda"
	"sort"
	"strconv"
	"strings"
)

var OperatorMap = map[base.OperatorType]string{
	base.OperatorType_GREATER_EQUAL_THAN: ">=",
	base.OperatorType_LESS_EQUAL_THAN:    "<=",
	base.OperatorType_GREATER_THAN:       ">",
	base.OperatorType_LESS_THAN:          "<",
	base.OperatorType_EQUAL:              "=",
}

var DefaultOperatorMap = map[volume_price.TargetType][]*volume_price.OperatorInfo{
	volume_price.TargetType_PayCnt: {
		{"(-∞,-100)", []*volume_price.OperatorValue{{-100, base.OperatorType_LESS_THAN}}},
		{"[-100, -50)", []*volume_price.OperatorValue{{-100, base.OperatorType_GREATER_EQUAL_THAN}, {-50, base.OperatorType_LESS_THAN}}},
		{"[-50~0)", []*volume_price.OperatorValue{{-50, base.OperatorType_GREATER_EQUAL_THAN}, {0, base.OperatorType_LESS_THAN}}},
		{"[0]", []*volume_price.OperatorValue{{0, base.OperatorType_EQUAL}}},
		{"(0-50)", []*volume_price.OperatorValue{{0, base.OperatorType_GREATER_THAN}, {50, base.OperatorType_LESS_THAN}}},
		{"[50-100)", []*volume_price.OperatorValue{{50, base.OperatorType_GREATER_EQUAL_THAN}, {100, base.OperatorType_LESS_THAN}}},
		{"[100-500)", []*volume_price.OperatorValue{{100, base.OperatorType_GREATER_EQUAL_THAN}, {500, base.OperatorType_LESS_THAN}}},
		{"[500,+∞)", []*volume_price.OperatorValue{{500, base.OperatorType_GREATER_EQUAL_THAN}}},
	},
	volume_price.TargetType_ShowCnt: {
		{"(-∞,10w)", []*volume_price.OperatorValue{{-100000, base.OperatorType_LESS_THAN}}},
		{"[-10w, -5w)", []*volume_price.OperatorValue{{-100000, base.OperatorType_GREATER_EQUAL_THAN}, {-50000, base.OperatorType_LESS_THAN}}},
		{"[-5w, -1w)", []*volume_price.OperatorValue{{-50000, base.OperatorType_GREATER_EQUAL_THAN}, {-10000, base.OperatorType_LESS_THAN}}},
		{"[-1w,0)", []*volume_price.OperatorValue{{-10000, base.OperatorType_GREATER_EQUAL_THAN}, {0, base.OperatorType_LESS_THAN}}},
		{"[0]", []*volume_price.OperatorValue{{0, base.OperatorType_EQUAL}}},
		{"(0~1w)", []*volume_price.OperatorValue{{0, base.OperatorType_GREATER_THAN}, {10000, base.OperatorType_LESS_THAN}}},
		{"[1w~5w)", []*volume_price.OperatorValue{{10000, base.OperatorType_GREATER_EQUAL_THAN}, {50000, base.OperatorType_LESS_THAN}}},
		{"[5w~10w)", []*volume_price.OperatorValue{{50000, base.OperatorType_GREATER_EQUAL_THAN}, {100000, base.OperatorType_LESS_THAN}}},
		{"[10w~100w)", []*volume_price.OperatorValue{{100000, base.OperatorType_GREATER_EQUAL_THAN}, {1000000, base.OperatorType_LESS_THAN}}},
		{"[100w,+∞)", []*volume_price.OperatorValue{{1000000, base.OperatorType_GREATER_EQUAL_THAN}}},
	},
	volume_price.TargetType_PayAmt: {
		{"(-∞,10w)", []*volume_price.OperatorValue{{-100000, base.OperatorType_LESS_THAN}}},
		{"[-10w, -5w)", []*volume_price.OperatorValue{{-100000, base.OperatorType_GREATER_EQUAL_THAN}, {-50000, base.OperatorType_LESS_THAN}}},
		{"[-5w, -1w)", []*volume_price.OperatorValue{{-50000, base.OperatorType_GREATER_EQUAL_THAN}, {-10000, base.OperatorType_LESS_THAN}}},
		{"[-1w,0)", []*volume_price.OperatorValue{{-10000, base.OperatorType_GREATER_EQUAL_THAN}, {0, base.OperatorType_LESS_THAN}}},
		{"[0]", []*volume_price.OperatorValue{{0, base.OperatorType_EQUAL}}},
		{"(0~1w)", []*volume_price.OperatorValue{{0, base.OperatorType_GREATER_THAN}, {10000, base.OperatorType_LESS_THAN}}},
		{"[1w~5w)", []*volume_price.OperatorValue{{10000, base.OperatorType_GREATER_EQUAL_THAN}, {50000, base.OperatorType_LESS_THAN}}},
		{"[5w~10w)", []*volume_price.OperatorValue{{50000, base.OperatorType_GREATER_EQUAL_THAN}, {100000, base.OperatorType_LESS_THAN}}},
		{"[10w~100w)", []*volume_price.OperatorValue{{100000, base.OperatorType_GREATER_EQUAL_THAN}, {1000000, base.OperatorType_LESS_THAN}}},
		{"[100w,+∞)", []*volume_price.OperatorValue{{1000000, base.OperatorType_GREATER_EQUAL_THAN}}},
	},
}

func (v *VolumePriceService) GetVolumePriceVersionHierarchicalList(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalListRequest) (resp []*volume_price.LibraFlightInfoData, err error) {
	if len(req.LibraParam.FlightIds) == 0 && len(req.LibraParam.FlightParamList) == 0 {
		return resp, errors.New("未选择实验ID筛选项")
	}
	dateDiff := time_utils.DateDiffAbs(req.BaseReq.StartDate, req.BaseReq.EndDate)
	if dateDiff > 30 && len(req.LibraParam.FlightParamList) > 3 {
		return resp, errors.New("查询日期超过30天，最多选三个实验")
	}
	// 获取业务线的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	// 获取invoker的入参
	curr, err := base_struct_condition.GetVolumePriceConditionSimpleParam(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return
	}

	if len(req.LibraParam.FlightParamList) > 0 {
		fParamFilter := make([]string, 0)
		for _, fParam := range req.LibraParam.FlightParamList {
			fParamFilter = append(fParamFilter, fmt.Sprintf("(flight_id = %s and scenarios = %d)", fParam.FlightId, convert.ToInt64(fParam.Scenarios)))
		}
		curr["flight_param_filter"] = fmt.Sprintf("(%s)", strings.Join(fParamFilter, " or "))
	} else {
		curr["flight_ids"], err = ameda.StringsToInt64s(req.LibraParam.FlightIds)
		if err != nil {
			logs.CtxWarn(ctx, "传入非法实验ID，err = %s", err)
			return resp, errors.New("传入非法实验ID")
		}
	}
	libraVIdMap, err := v.GetVolumePriceLibraInfoMap(ctx, req.BaseReq.StartDate, req.BaseReq.EndDate)
	if err != nil {
		return resp, err
	}

	vids := make([]int64, 0)
	for vid, info := range libraVIdMap {
		if info.VersionInfo != nil && info.VersionInfo.VersionType == basic_info.LibraVersionType_ControlGroup {
			continue
		}
		vids = append(vids, convert.ToInt64(strings.Split(vid, consts.Sep)[0]))
	}
	curr["version_ids"] = vids

	if len(req.OperatorList) == 0 {
		req.OperatorList = DefaultOperatorMap[req.TargetType]
		if len(req.OperatorList) == 0 {
			logs.CtxWarn(ctx, "req.TargetType not find，= %s", convert.ToString(req.TargetType))
			return resp, errors.New("指标类型未发现默认的分层逻辑")
		}
	}

	attributeName, tableTargetCol := GetNameByTargetType(ctx, req.TargetType)
	if len(attributeName) == 0 || len(tableTargetCol) == 0 {
		return resp, errors.New("传入分层指标类型未知")
	}

	targetMetaMap := make(map[string]*dao.TargetMetaInfo)
	hierarchicalOperatorList := make([]string, 0)
	for i, operator := range req.OperatorList {
		if len(operator.OperatorValue) == 0 {
			logs.CtxWarn(ctx, "[GetVolumePriceVersionHierarchicalList]传入分层表达式存在空表达式")
			return resp, errors.New("传入分层表达式存在空表达式")
		}

		operatorList := make([]string, 0)
		for _, oValue := range operator.OperatorValue {
			op := OperatorMap[oValue.Operator]
			if len(op) == 0 {
				logs.CtxWarn(ctx, "[GetVolumePriceVersionHierarchicalList]传入分层表达式字符未知=%s", convert.ToString(oValue.Operator))
				return resp, errors.New("传入分层表达式字符未知")
			}
			operatorList = append(operatorList, fmt.Sprintf("%s %s %d", tableTargetCol, op, oValue.Value))
		}

		targetName := fmt.Sprintf("case_%d", i)
		targetMetaMap[targetName] = &dao.TargetMetaInfo{
			Name:            targetName,
			DisplayName:     operator.Label,
			DisplayOrder:    i,
			TargetPrecision: 1,
			ValueType:       "int",
			AttributeType:   fmt.Sprintf("7日-AB %s增量（绝对值）", attributeName),
			IsDefaultShow:   true,
		}
		targetMetaMap[targetName+"_percent"] = &dao.TargetMetaInfo{
			Name:            targetName + "_percent",
			DisplayName:     operator.Label,
			DisplayOrder:    1000 + i,
			ValueType:       "double",
			ValueUnit:       "%",
			TargetPrecision: 2,
			AttributeType:   fmt.Sprintf("7日-AB %s增量（占比）", attributeName),
			IsDefaultShow:   true,
		}
		hierarchicalOperatorList = append(hierarchicalOperatorList, fmt.Sprintf("count(distinct if(%s,prod_id,null)) as %s", strings.Join(operatorList, " and "), targetName))
	}
	curr["hierarchical_operator_col_list"] = strings.Join(hierarchicalOperatorList, ",")
	targetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty,
		ApiPath: apiPathHierarchicalList,
		BizType: req.BaseReq.BizType, NeedDistribution: true,
		KeyCols:       []string{"version_id", "scenarios"},
		TargetMetaMap: targetMetaMap,
	})
	if err != nil {
		return resp, err
	}

	// 将查询的实验组分组
	libraFidMap := make(map[string][]LibraTargetData)
	for _, info := range targetList {
		if len(info.KeyColValues) >= 2 {
			versionSceneKey := convert.ToString(info.KeyColValues[0]) + consts.Sep + convert.ToString(info.KeyColValues[1])
			if libraInfo, exist := libraVIdMap[versionSceneKey]; exist && libraInfo.FlightInfo != nil && libraInfo.VersionInfo != nil {
				flightSceneKey := GetSceneKeyById(libraInfo.Scenarios, libraInfo.FlightInfo.FlightId)
				libraTargetData := LibraTargetData{
					FlightInfo:    libraInfo.FlightInfo,
					VersionInfo:   libraInfo.VersionInfo,
					Scenarios:     libraInfo.Scenarios,
					ScenariosName: libraInfo.ScenariosName,
					TargetMap:     make(map[string]*analysis.TargetCardEntity),
				}

				var totalCnt float64
				for _, t := range info.TargetEntity {
					totalCnt += t.Value
				}

				for _, t := range info.TargetEntity {
					libraTargetData.TargetMap[t.Name] = t
					var percentRate float64
					if totalCnt != 0 {
						percentRate = t.Value / totalCnt
					}
					percent := convert.ToFloat64(strconv.FormatFloat(percentRate, 'f', 5, 64))
					percentTarget, err := base_struct_condition.GetTargetEntity(ctx, percent, targetMetaMap[t.Name+"_percent"])
					if err != nil {
						return resp, err
					}
					if percentTarget != nil {
						libraTargetData.TargetMap[t.Name+"_percent"] = percentTarget
					}
				}

				versionArr := libraFidMap[flightSceneKey]
				if len(versionArr) == 0 {
					versionArr = make([]LibraTargetData, 0)
				}
				versionArr = append(versionArr, libraTargetData)
				libraFidMap[flightSceneKey] = versionArr
			}
		}
	}

	resp = make([]*volume_price.LibraFlightInfoData, 0)
	for _, infoArr := range libraFidMap {
		if len(infoArr) == 0 {
			continue
		}

		flightInfo := &volume_price.LibraFlightInfoData{
			FlightInfo:    infoArr[0].FlightInfo,
			VersionList:   make([]*volume_price.LibraVersionListRow, 0),
			Scenarios:     infoArr[0].Scenarios,
			ScenariosName: infoArr[0].ScenariosName,
		}
		for _, info := range infoArr {
			newTargetList := make([]*analysis.TargetCardEntity, 0)
			for _, target := range info.TargetMap {
				newTargetList = append(newTargetList, target)
			}

			analysis_service.SortTargetCardEntity(newTargetList)
			versionListRow := &volume_price.LibraVersionListRow{
				VersionBasicInfo: info.VersionInfo,
				TargetList:       newTargetList,
			}
			flightInfo.VersionList = append(flightInfo.VersionList, versionListRow)
		}

		// 实验组排序
		sort.Slice(flightInfo.VersionList, func(i, j int) bool {
			iVersion := flightInfo.VersionList[i].VersionBasicInfo
			jVersion := flightInfo.VersionList[j].VersionBasicInfo
			x := utils.If(iVersion == nil || iVersion.VersionType == basic_info.LibraVersionType_ControlGroup,
				0, iVersion.VersionSort)
			y := utils.If(jVersion == nil || jVersion.VersionType == basic_info.LibraVersionType_ControlGroup,
				0, jVersion.VersionSort)
			return x < y
		})
		resp = append(resp, flightInfo)
	}

	// 实验排序
	sort.Slice(resp, func(i, j int) bool {
		if resp[i].Scenarios == resp[j].Scenarios {
			return resp[i].FlightInfo.FlightStartTime > resp[j].FlightInfo.FlightStartTime
		}
		return resp[i].Scenarios < resp[j].Scenarios
	})
	return
}

func GetNameByTargetType(ctx context.Context, targetType volume_price.TargetType) (attributeName string, tableTargetCol string) {
	switch targetType {
	case volume_price.TargetType_PayCnt:
		attributeName = "订单"
		tableTargetCol = "ab_prod_card_pay_cnt_recalculate_diff"
	case volume_price.TargetType_PayAmt:
		attributeName = "GMV"
		tableTargetCol = "ab_prod_card_pay_amt_recalculate_diff"
	case volume_price.TargetType_ShowCnt:
		attributeName = "曝光PV"
		tableTargetCol = "ab_prod_card_prod_show_cnt_recalculate_diff"
	default:
		logs.CtxWarn(ctx, "[GetVolumePriceVersionHierarchicalList]传入分层指标类型未知, targetType = %s", convert.ToString(targetType))
		return consts.Empty, consts.Empty
	}
	return attributeName, tableTargetCol
}
