package volume_price_service

//func TestGenCondition(t *testing.T) {
//	//db.Init()
//	ctx := context.Background()
//	p, err := new(VolumePriceDao).genExprWhereCondition(ctx, req)
//	if err != nil {
//		t.Error(err)
//	}
//	t.Log(litter.Sdump(resp))
//}
