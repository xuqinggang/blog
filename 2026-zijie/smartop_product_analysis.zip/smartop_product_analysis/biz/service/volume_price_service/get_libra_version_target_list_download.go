package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
	"strconv"
	"strings"
)

func (v *VolumePriceService) GetVolumePriceLibraVersionListDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := v.GetVolumePriceLibraVersionList(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	table, targetList := getLibraVersionTableAndTargetList(coreRet)
	f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genGetLibraVersionListTable, param.SinkTable("core_data"))
	f.ExeCustom([]param.Source{param.SourceTable("core_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(targetList)}, doExportGetLibraVersionListData, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func getLibraVersionTableAndTargetList(coreData []*volume_price.LibraFlightInfoData) ([]map[string]interface{}, []string) {
	table := make([]map[string]interface{}, 0)
	targetList := make([]string, 0)
	if len(coreData) > 0 {
		if len(coreData[0].VersionList) > 0 && len(coreData[0].VersionList[0].TargetList) > 0 {
			for _, target := range coreData[0].VersionList[0].TargetList {
				targetList = append(targetList, target.DisplayName)
				if target.Extra != nil && target.Extra.PercentFlag {
					targetList = append(targetList, target.DisplayName+"占比")
				}
			}
		}
		for _, data := range coreData {
			if len(data.VersionList) > 0 {
				for _, version := range data.VersionList {
					record := make(map[string]interface{})
					record["scenarios"] = data.ScenariosName
					record["flight_id"] = data.FlightInfo.FlightId
					record["flight_name"] = data.FlightInfo.FlightName
					record["version_id"] = version.VersionBasicInfo.VersionId
					record["version_name"] = version.VersionBasicInfo.VersionName
					switch version.VersionBasicInfo.VersionType {
					case basic_info.LibraVersionType_ControlGroup:
						record["version_type"] = "对照组"
					case basic_info.LibraVersionType_ExperimentalGroup:
						record["version_type"] = "实验组"
					default:
						record["version_type"] = "-"
					}
					if len(version.TargetList) > 0 {
						for _, target := range version.TargetList {
							if target.DisplayValue == "-" {
								record[target.DisplayName] = target.DisplayValue
							} else if strings.HasSuffix(target.Name, "_ab_diff_ratio") {
								record[target.DisplayName] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(target.Value*100, 'f', 5, 64)) + "%"
							} else {
								record[target.DisplayName] = target.Value
							}
							if target.Extra != nil && target.Extra.PercentFlag {
								record[target.DisplayName+"占比"] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(target.Extra.MarketPercent*100, 'f', 5, 64)) + "%"
							}
						}
					}
					table = append(table, record)
				}
			}
		}
	}
	return table, targetList
}

func genGetLibraVersionListTable(ctx context.Context, table []map[string]interface{}) (*onetable.Table, error) {
	return onetable.NewTable(table), nil
}

func doExportGetLibraVersionListData(ctx context.Context, table *onetable.Table, email string, analysisRange string, targetList []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet("指标列表", table)
	sheet.AddHead([][]string{{"分析周期", analysisRange}})

	sheet.AddColumn("实验场域", "scenarios").
		AddColumn("实验ID", "flight_id").
		AddColumn("实验名称", "flight_name").
		AddColumn("实验组ID", "version_id").
		AddColumn("实验组名称", "version_name").
		AddColumn("实验组类型", "version_type")
	for _, t := range targetList {
		sheet.AddColumn(t, t)
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "量价模型-核心数据汇总")
	return nil, formatter.Export(ctx, email, nil, nil)
}
