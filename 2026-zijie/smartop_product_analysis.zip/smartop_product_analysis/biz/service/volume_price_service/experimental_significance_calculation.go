package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"math"
	"strings"
)

type CombinationExperiment struct {
	ControlGroup      interface{}
	ExperimentalGroup interface{}
}

const (
	SifgnificanceGranularity_Cluster        = "簇"
	SifgnificanceGranularity_Prod           = "品"
	SifgnificanceGranularity_ClusterAndUser = "簇*用户"

	SifgnificanceType_DoubleSample_T = "双样本studnet-T检验"
	SifgnificanceType_Delta_T        = "Delta Method-T检验"
	SifgnificanceType_Z              = "Z检验"

	SufNumE2    = "num_e2"
	SufDenomE2  = "denom_e2"
	SufNumDenom = "num_denom"
)

var GranularityOSMap = map[string]string{
	SifgnificanceGranularity_Cluster:        "7457844238286406693",
	SifgnificanceGranularity_Prod:           "7473342563345253402",
	SifgnificanceGranularity_ClusterAndUser: "7457835415584769062",
}

type ExperimentSignificantParams struct {
	CombinationTargetMap      map[string]map[string]*analysis.TargetCardEntity // key 分组ID（G22），第二个key是指标名(show_pv)，value是指标卡
	ExperimentCombinationList []*volume_price.ExperimentCombination            // key 分析对象ID（G22-G10）, 这个分析对象的元信息
	ClusterCntMap             map[string]float64
	UserCntMap                map[string]float64
	ProdCntMap                map[string]float64
	BizType                   dimensions.BizType
	OSParam                   map[string]interface{}
}

// GetCombinationExperimentSignificantTargetList 判断每个评估对象的实验是否有显著差异
func (v *VolumePriceService) GetCombinationExperimentSignificantTargetList(ctx context.Context, req ExperimentSignificantParams) (allTargetList []string, ret map[string][]string, err error) {
	allTargetList = make([]string, 0)
	ret = make(map[string][]string)
	// 优先计算需要计算的显著性的指标的依赖数据内容

	// 获取需要计算的显著性指标信息
	targetSignificanceList, err := v.VolumePriceDao.GetExperimentSignificanceInfo(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetCombinationExperimentSignificantTargetList] GetExperimentSignificanceInfo err, %v+", err)
		return nil, nil, err
	}
	if len(targetSignificanceList) == 0 {
		return allTargetList, ret, nil
	}

	combinationTargetMap, err := GetCombinationTargetMap(ctx, targetSignificanceList, req)
	if err != nil {
		logs.CtxError(ctx, "[GetCombinationTargetList] GetCombinationTargetMap err, %v+", err)
		return nil, nil, err
	}

	ret = make(map[string][]string)
	for _, combinationInfo := range req.ExperimentCombinationList {
		exprTargetMap := req.CombinationTargetMap[combinationInfo.ExprGroupId]
		compareTargetMap := req.CombinationTargetMap[combinationInfo.CompareGroupId]
		if len(exprTargetMap) == 0 || len(compareTargetMap) == 0 {
			logs.CtxWarn(ctx, "[GetCombinationTargetList] exprTargetMap or compareTargetMap is empty, %s", convert.ToJSONString(combinationInfo))
			continue
		}

		combinationATargetMap := combinationTargetMap[combinationInfo.ExprGroupId]
		combinationBTargetMap := combinationTargetMap[combinationInfo.CompareGroupId]
		if len(combinationATargetMap) == 0 || len(combinationBTargetMap) == 0 {
			logs.CtxWarn(ctx, "[GetCombinationTargetList] combinationATargetMap or combinationBTargetMap is empty, %s", convert.ToJSONString(combinationTargetMap))
			continue
		}

		signiTargetList := make([]string, 0)
		for _, targetSigni := range targetSignificanceList {
			allTargetList = append(allTargetList, targetSigni.TargetName)
			isSignificance := false

			// 获取指标值
			targetA := exprTargetMap[targetSigni.TargetName]
			targetB := compareTargetMap[targetSigni.TargetName]
			if targetA == nil || targetB == nil {
				logs.CtxWarn(ctx, "[GetCombinationTargetList] targetA or targetB is empty, %s", convert.ToJSONString(targetSigni))
				continue
			}

			// 计算样本量
			var sampleSizeA, sampleSizeB float64
			switch targetSigni.Granularity {
			case SifgnificanceGranularity_Prod:
				// 品
				sampleSizeA = req.ProdCntMap[combinationInfo.ExprGroupId]
				sampleSizeB = req.ProdCntMap[combinationInfo.CompareGroupId]
			case SifgnificanceGranularity_Cluster:
				// 簇
				sampleSizeA = req.ClusterCntMap[combinationInfo.ExprGroupId]
				sampleSizeB = req.ClusterCntMap[combinationInfo.CompareGroupId]
			case SifgnificanceGranularity_ClusterAndUser:
				// 簇*用户
				sampleSizeA = req.ClusterCntMap[combinationInfo.ExprGroupId] * req.UserCntMap[combinationInfo.ExprGroupId]
				sampleSizeB = req.ClusterCntMap[combinationInfo.CompareGroupId] * req.UserCntMap[combinationInfo.CompareGroupId]
			default:
				continue
			}
			if sampleSizeA <= 1 || sampleSizeB <= 1 {
				logs.CtxWarn(ctx, "[GetCombinationTargetList] sampleSizeA or sampleSizeB <= 1, sampleSizeA = %d sampleSizeB = %d", sampleSizeA, sampleSizeB)
				continue
			}

			switch targetSigni.SignificanceType {
			case SifgnificanceType_DoubleSample_T:
				varA := GetVarByE2Formula(sampleSizeA, targetA.Value, combinationATargetMap, targetSigni.TargetName, false)
				varB := GetVarByE2Formula(sampleSizeB, targetB.Value, combinationBTargetMap, targetSigni.TargetName, false)
				score := SignificanceTypeTCheck(targetA.Value, targetB.Value, varA, varB, sampleSizeA, sampleSizeB)
				logs.CtxInfo(ctx, "[GetCombinationTargetList] SignificanceTypeTCheck, targetA = %s targetB = %s score = %f combinationInfo = %s", convert.ToJSONString(targetA), convert.ToJSONString(targetB), score, convert.ToJSONString(combinationInfo))
				isSignificance = score > targetSigni.Threshold
			case SifgnificanceType_Delta_T:
				meanA, varA := GetDeltaVarPop(ctx, exprTargetMap, targetSigni, sampleSizeA, combinationATargetMap)
				meanB, varB := GetDeltaVarPop(ctx, compareTargetMap, targetSigni, sampleSizeB, combinationBTargetMap)
				score := SignificanceTypeTCheck(meanA, meanB, varA, varB, sampleSizeA, sampleSizeB)
				logs.CtxInfo(ctx, "[GetCombinationTargetList] SignificanceTypeTCheck, targetA = %s targetB = %s score = %f combinationInfo = %s", convert.ToJSONString(targetA), convert.ToJSONString(targetB), score, convert.ToJSONString(combinationInfo))
				isSignificance = score > targetSigni.Threshold
			case SifgnificanceType_Z:
				score := SignificanceTypeZCheck(targetA.Value, targetB.Value, sampleSizeA, sampleSizeB)
				logs.CtxInfo(ctx, "[GetCombinationTargetList] SignificanceTypeZCheck, targetA = %s targetB = %s score = %f combinationInfo = %s", convert.ToJSONString(targetA), convert.ToJSONString(targetB), score, convert.ToJSONString(combinationInfo))
				isSignificance = score > targetSigni.Threshold
			default:
				continue
			}
			if isSignificance {
				signiTargetList = append(signiTargetList, targetSigni.TargetName)
			}
		}
		if len(signiTargetList) > 0 {
			ret[combinationInfo.Code] = signiTargetList
		}
	}

	return allTargetList, ret, nil
}

func GetDeltaVarPop(ctx context.Context, targetMap map[string]*analysis.TargetCardEntity, targetSigni *dao.ExperimentSignificanceInfo, size float64, combinationTargetMap map[string]float64) (mean, varPop float64) {
	numTargetV := targetMap[targetSigni.NumberTargetName]
	if numTargetV == nil {
		logs.CtxWarn(ctx, "[GetDeltaVarPop] numTargetV is nil, target name = %s", targetSigni.NumberTargetName)
		return
	}
	denomTargetV := targetMap[targetSigni.DenomTargetName]
	if denomTargetV == nil {
		logs.CtxWarn(ctx, "[GetDeltaVarPop] denomTargetV is nil, target name = %s", targetSigni.DenomTargetName)
		return
	}
	avgX := numTargetV.Value / size
	avgY := denomTargetV.Value / size
	covXY := combinationTargetMap[fmt.Sprintf("%s_%s", targetSigni.TargetName, SufNumDenom)]/size - (avgX * avgY)
	covBar := covXY
	barX := GetVarByE2Formula(size, avgX, combinationTargetMap, targetSigni.TargetName, false)
	barY := GetVarByE2Formula(size, avgY, combinationTargetMap, targetSigni.TargetName, true)
	return numTargetV.Value / denomTargetV.Value, (barX / math.Pow(avgY, 2)) + (barY * math.Pow(avgX, 2) / math.Pow(avgY, 4)) - (2 * covBar * avgX / math.Pow(avgY, 3))
}

func GetVarByE2Formula(size, targetValue float64, e2TargetMap map[string]float64, targetName string, isDenom bool) float64 {
	e2Value := e2TargetMap[fmt.Sprintf("%s_%s", targetName, utils.If(isDenom, SufDenomE2, SufNumE2))]
	if size <= 1 {
		return 0
	}
	return size / (size - 1) * ((e2Value / size) - math.Pow(targetValue, 2))
}

type selectQueryInfo struct {
	subSelect  []string
	baseSelect []string
}

type combinationTargetInfo struct {
	CellCode string  `json:"cell_code"`
	Name     string  `json:"name"`
	Value    float64 `json:"value"`
}

func GetCombinationTargetMap(ctx context.Context, targetSignificanceList []*dao.ExperimentSignificanceInfo, req ExperimentSignificantParams) (combinationTargetMap map[string]map[string]float64, err error) {
	// 按照粒度划分查询信息
	granularitySelectMap := make(map[string]selectQueryInfo, 0)
	formulaMap := make(map[string]string)
	for _, targetSigni := range targetSignificanceList {
		selectInfo, exist := granularitySelectMap[targetSigni.Granularity]
		if !exist {
			selectInfo = selectQueryInfo{
				subSelect:  make([]string, 0),
				baseSelect: make([]string, 0),
			}
		}
		switch targetSigni.SignificanceType {
		case SifgnificanceType_DoubleSample_T:
			aliasTargetName := fmt.Sprintf("%s_num", targetSigni.TargetName)
			formulaAlias, existF := formulaMap[targetSigni.NumberFormula]
			if !existF {
				formulaAlias = targetSigni.NumberFormula
				formulaMap[targetSigni.NumberFormula] = aliasTargetName
			}
			selectInfo.subSelect = append(selectInfo.subSelect, fmt.Sprintf(" %s as %s ", formulaAlias, aliasTargetName))
			selectInfo.baseSelect = append(selectInfo.baseSelect, fmt.Sprintf(" sum(%s*%s) as %s_%s", aliasTargetName, aliasTargetName, targetSigni.TargetName, SufNumE2))
		case SifgnificanceType_Delta_T:
			aliasXTargetName := fmt.Sprintf("%s_num", targetSigni.TargetName)
			aliasYTargetName := fmt.Sprintf("%s_denom", targetSigni.TargetName)
			formulaXAlias, existF := formulaMap[targetSigni.NumberFormula]
			if !existF {
				formulaXAlias = targetSigni.NumberFormula
				formulaMap[targetSigni.NumberFormula] = aliasXTargetName
			}
			formulaYAlias, existF := formulaMap[targetSigni.DenomFormula]
			if !existF {
				formulaYAlias = targetSigni.DenomFormula
				formulaMap[targetSigni.DenomFormula] = aliasYTargetName
			}
			selectInfo.subSelect = append(selectInfo.subSelect, fmt.Sprintf(" %s as %s ", formulaXAlias, aliasXTargetName))
			selectInfo.subSelect = append(selectInfo.subSelect, fmt.Sprintf(" %s as %s ", formulaYAlias, aliasYTargetName))
			selectInfo.baseSelect = append(selectInfo.baseSelect, fmt.Sprintf(" sum(%s*%s) as %s_%s", aliasXTargetName, aliasYTargetName, targetSigni.TargetName, SufNumDenom))
			selectInfo.baseSelect = append(selectInfo.baseSelect, fmt.Sprintf(" sum(%s*%s) as %s_%s", aliasXTargetName, aliasXTargetName, targetSigni.TargetName, SufNumE2))
			selectInfo.baseSelect = append(selectInfo.baseSelect, fmt.Sprintf(" sum(%s*%s) as %s_%s", aliasYTargetName, aliasYTargetName, targetSigni.TargetName, SufDenomE2))
		default:
			continue
		}
		granularitySelectMap[targetSigni.Granularity] = selectInfo
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	unionStrSql := make([]string, 0)
	var index int
	for granularity, selectInfo := range granularitySelectMap {
		req.OSParam["sub_select"] = strings.Join(selectInfo.subSelect, ",")
		req.OSParam["base_select"] = strings.Join(selectInfo.baseSelect, ",")
		// 请求invoker，获取数据
		targetTableName := fmt.Sprintf("target_card_%d", index)
		f.ExeQueryInvokerRaw(req.OSParam, GranularityOSMap[granularity], param.SinkTable(targetTableName)).SetParallel(true).SetMaxParallelNum(10)
		// 指标值行转列
		f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable(targetTableName), param.SinkTable(targetTableName)).
			SetValueColumn("value").
			SetTargetNameColumn("name").SetDimColumns([]string{"cell_code"}))
		unionStrSql = append(unionStrSql, fmt.Sprintf("select * from %s", targetTableName))
		index++
	}
	f.ExeProduceSql(strings.Join(unionStrSql, " union all "), param.SinkTable("target_card_new"))
	combinationTargetList := make([]*combinationTargetInfo, 0)
	f.ExeView(param.SourceTable("target_card_new"), &combinationTargetList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	combinationTargetMap = make(map[string]map[string]float64, 0)
	for _, combinationTarget := range combinationTargetList {
		targetMap := combinationTargetMap[combinationTarget.CellCode]
		if targetMap == nil {
			targetMap = make(map[string]float64, 0)
		}
		targetMap[combinationTarget.Name] = combinationTarget.Value
		combinationTargetMap[combinationTarget.CellCode] = targetMap
	}
	return combinationTargetMap, nil
}

func SignificanceTypeTCheck(meanA, meanB, varA, varB, sizeA, sizeB float64) float64 {
	if sizeA == 0 || sizeB == 0 {
		return 0
	}
	denom := math.Sqrt((varA / sizeA) + (varB / sizeB))
	if denom == 0 {
		return 0
	}
	return math.Abs(meanA-meanB) / denom
}

func SignificanceTypeZCheck(meanA, meanB, sizeA, sizeB float64) float64 {
	if sizeA == 0 || sizeB == 0 {
		return 0
	}
	denom := math.Sqrt(((meanA * (1 - meanA)) / sizeA) + ((meanB * (1 - meanB)) / sizeB))
	if denom == 0 {
		return 0
	}
	return math.Abs(meanA-meanB) / denom
}
