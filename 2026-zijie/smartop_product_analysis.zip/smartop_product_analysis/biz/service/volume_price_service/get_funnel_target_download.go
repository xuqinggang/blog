package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
	"sort"
	"strconv"
)

func (v *VolumePriceService) GetVolumePriceMarketFunnelTargetDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := v.GetVolumePriceMarketFunnelTarget(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	table, dateList := getFunnelTableAndDateList(coreRet)

	f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genGetFunnelCoreTable, param.SinkTable("core_data"))
	f.ExeCustom([]param.Source{param.SourceTable("core_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(dateList)}, doExportGetFunnelCoreData, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func getFunnelTableAndDateList(targets []*analysis.TargetCardEntity) ([]map[string]interface{}, []string) {
	table := make([]map[string]interface{}, 0)
	dateList := make([]string, 0)
	if len(targets) > 0 {
		upTargetV := targets[0].Value
		for _, target := range targets {
			record := make(map[string]interface{})
			record["name"] = target.DisplayName
			record["value"] = target.Value
			if upTargetV == 0 {
				record["ratio"] = "-"
			} else {
				record["ratio"] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(target.Value/upTargetV*100, 'f', 5, 64)) + "%"
			}
			upTargetV = target.Value

			if len(target.TrendData) > 0 {
				for _, trend := range target.TrendData {
					record[trend.X] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(trend.Value, 'f', 5, 64))
					dateList = append(dateList, trend.X)
				}
			}
			table = append(table, record)
		}
	}
	dateList = slices.DistinctString(dateList)
	sort.Strings(dateList)
	return table, dateList
}

func genGetFunnelCoreTable(ctx context.Context, table []map[string]interface{}) (*onetable.Table, error) {
	return onetable.NewTable(table), nil
}

func doExportGetFunnelCoreData(ctx context.Context, table *onetable.Table, email string, analysisRange string, dateList []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet("指标列表", table)
	sheet.AddHead([][]string{{"分析周期", analysisRange}})

	sheet.AddColumn("指标", "name").
		AddColumn("汇总", "value").
		AddColumn("转化率", "ratio")

	for _, d := range dateList {
		sheet.AddColumn(d, d)
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "量价模型-商品供给漏斗")
	return nil, formatter.Export(ctx, email, nil, nil)
}
