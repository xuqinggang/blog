package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/version_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"sort"
	"strings"
)

type IVolumePriceService interface {
	GetVolumePriceLibraList(ctx context.Context, req *volume_price.GetVolumePriceLibraListRequest, flightID *string) (resp []*volume_price.LibraFlightInfo, err error)
	GetVolumePriceMarketFunnelTarget(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp []*analysis.TargetCardEntity, err error)
	GetVolumePriceLibraVersionList(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp []*volume_price.LibraFlightInfoData, err error)
	GetVolumePriceMultiDimFullList(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisMultiDimFullListData, err error)
	GetVolumePriceMarketFunnelTargetDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp bool, err error)
	GetVolumePriceLibraVersionListDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp bool, err error)
	GetVolumePriceMultiDimFullListDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp bool, err error)
	GetVolumePriceVersionHierarchicalList(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalListRequest) (resp []*volume_price.LibraFlightInfoData, err error)
	GetVolumePriceVersionHierarchicalListDownload(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalListRequest) (resp bool, err error)
	GetExperimentCombination(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.GetExperimentCombinationItem, err error)
	GetVolumePriceBilateralLibra(ctx context.Context, req *volume_price.GetVolumePriceBilateralLibraRequest) (resp *volume_price.VolumePriceBilateralLibraInfo, err error)
	SaveVolumePriceBilateralLibra(ctx context.Context, req *volume_price.SaveVolumePriceBilateralLibraRequest) (resp bool, err error)
	GenExprConditionByObjectList(ctx context.Context, objectList []*volume_price.ExperimentCombination) (selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition string, err error)
	GenExprConditionByFid(ctx context.Context, fid int64, objectType []int64) (selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition string, err error)
	GetReversalExperimentCoreData(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.ReversalExperimentCoreDataItem, err error)
	GetReversalExperimentDetail(ctx context.Context, req *volume_price.GetReversalExperimentRequest, needAllObject bool) (resp *volume_price.GetReversalExperimentDetailItem, uvClusterCnt []*UvClusterProdCellCnt, osParams map[string]interface{}, err error)
	SaveExprObject(ctx context.Context, req *volume_price.SaveExprObjectRequest) (resp bool, err error)
	GetReversalExperimentCoreDataDownload(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp bool, err error)
	GetReversalExperimentDetailDownload(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp bool, err error)
}
type VolumePriceService struct {
	DimensionListDao dao.IDimensionListDao
	DimensionEnumDao dao.IDimensionEnumDao
	AttributeDao     dao.IAttributeDao
	VolumePriceDao   dao.IVolumePriceDao
	DimensionService dimension_service.IDimensionService
	AnalysisService  analysis_service.IAnalysisService
}

const (
	apiPathLibraList              = "7439998632016741402"
	apiPathFunnelTarget           = "7439916531649152027"
	apiPathLibraVersionTargetList = "7441085388086625289"
	apiPathMultiDimList           = "7441095520635995145"
	apiPathHierarchicalList       = "7441559546054657074"
	apiPathBothSideExprTarget     = "7457363701251736586" // 双边实验指标卡
)

type LibraMetaInfo struct {
	FLightID      int64                         `json:"flight_id"`
	FLightName    string                        `json:"flight_name"`
	VersionID     int64                         `json:"version_id"`
	VersionName   string                        `json:"version_name"`
	VersionSort   int64                         `json:"version_sort"`
	VersionType   basic_info.LibraVersionType   `json:"version_type"`
	Scenarios     volume_price.AnalyzeScenarios `json:"scenarios"`
	ScenariosName string                        `json:"scenarios_name"`
}

type UvClusterProdCellCnt struct {
	CellCode     string  `json:"cell_code"`
	ClusterCnt   float64 `json:"cluster_cnt"`
	Uv           float64 `json:"uv"`
	GroupProdCnt float64 `json:"group_prod_cnt"`
}

func (v *VolumePriceService) GetVolumePriceLibraList(ctx context.Context, req *volume_price.GetVolumePriceLibraListRequest, flightID *string) (resp []*volume_price.LibraFlightInfo, err error) {
	if req.LibraType != nil && *req.LibraType == volume_price.LibraType_LibraTypeCluster {
		return GetVolumePriceBSideList(ctx)
	}

	params := make(map[string]interface{})
	params["start_date"] = req.StartDate
	params["end_date"] = req.EndDate

	newest, err := utils.GetNewestDay(ctx, "7441467361414136882")
	if err != nil {
		logs.CtxError(ctx, "[GetVolumePriceLibraList]获取最新配置表信息时间失败")
		return resp, errors.New("获取最新配置表信息时间失败")
	}
	params["date"] = newest

	isBCSide := req.LibraType != nil && *req.LibraType == volume_price.LibraType_LibraTypeCombination
	if isBCSide {
		params["filter_combination"] = "true"
	}

	if flightID != nil && len(*flightID) > 0 {
		params["flight_id"] = *flightID
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(params, apiPathLibraList, param.SinkTable("libra_list"))
	libraMetaList := make([]*LibraMetaInfo, 0)
	f.ExeView(param.SourceTable("libra_list"), &libraMetaList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	if len(libraMetaList) == 0 {
		logs.CtxInfo(ctx, "[GetVolumePriceLibraList]未查询到实验信息")
		return resp, nil
	}

	flightIDs := make([]int64, 0)
	flightNameMap := make(map[int64]string)
	fMetaMap := make(map[string]*volume_price.LibraFlightInfo)
	for _, record := range libraMetaList {
		flightIDs = append(flightIDs, record.FLightID)
		flightNameMap[record.FLightID] = record.FLightName
		fSceneKey := GetSceneKeyById(record.Scenarios, convert.ToString(record.FLightID))
		libraFlightInfo := fMetaMap[fSceneKey]
		if libraFlightInfo == nil || len(libraFlightInfo.VersionList) == 0 {
			libraFlightInfo = &volume_price.LibraFlightInfo{
				VersionList: make([]*basic_info.LibraVersionBasicInfo, 0),
			}
		}
		vName := record.VersionName
		if record.VersionType == basic_info.LibraVersionType_ControlGroup || record.VersionSort > 0 {
			vName = fmt.Sprintf("V%d: ", record.VersionSort) + record.VersionName
		}
		libraFlightInfo.VersionList = append(libraFlightInfo.VersionList, &basic_info.LibraVersionBasicInfo{
			VersionId:   convert.ToString(record.VersionID),
			VersionName: vName,
			VersionType: record.VersionType,
			VersionSort: record.VersionSort,
		})
		libraFlightInfo.Scenarios = record.Scenarios
		libraFlightInfo.ScenariosName = record.ScenariosName
		fMetaMap[fSceneKey] = libraFlightInfo
	}
	if len(flightIDs) == 0 {
		logs.CtxInfo(ctx, "[GetVolumePriceLibraList]未查询到实验信息")
		return resp, nil
	}
	flightIDs = slices.DistinctInt64(flightIDs)
	flightInfoMap := version_info.GetLibraBasicInfo(ctx, flightIDs...)
	resp = make([]*volume_price.LibraFlightInfo, 0)
	for fSceneKey, libraFlightInfo := range fMetaMap {
		id := convert.ToInt64(strings.Split(fSceneKey, consts.Sep)[0])
		// 实验组排序
		sort.Slice(libraFlightInfo.VersionList, func(i, j int) bool {
			iVersion := libraFlightInfo.VersionList[i]
			jVersion := libraFlightInfo.VersionList[j]
			x := utils.If(iVersion == nil || iVersion.VersionType == basic_info.LibraVersionType_ControlGroup,
				0, iVersion.VersionSort)
			y := utils.If(jVersion == nil || jVersion.VersionType == basic_info.LibraVersionType_ControlGroup,
				0, jVersion.VersionSort)
			return x < y
		})

		flightInfo := flightInfoMap[id]
		if flightInfo == nil {
			flightInfo = &basic_info.LibraBasicInfo{
				FlightId:     convert.ToString(id),
				FlightName:   flightNameMap[id],
				FlightStatus: "已过期",
				FlightLink:   "https://data.bytedance.net/libra/flight/" + convert.ToString(id) + "/edit",
			}
		}
		resp = append(resp, &volume_price.LibraFlightInfo{
			FlightInfo:    flightInfo,
			VersionList:   libraFlightInfo.VersionList,
			Scenarios:     libraFlightInfo.Scenarios,
			ScenariosName: utils.If(isBCSide, consts.Empty, libraFlightInfo.ScenariosName),
		})
	}
	// 实验排序
	sort.Slice(resp, func(i, j int) bool {
		return resp[i].FlightInfo.FlightStartTime > resp[j].FlightInfo.FlightStartTime
	})
	return resp, nil
}

func (v *VolumePriceService) GetExperimentCombination(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.GetExperimentCombinationItem, err error) {
	resp = &volume_price.GetExperimentCombinationItem{
		Combinations: make([]*volume_price.ExperimentCombination, 0),
	}
	var fid string
	if req.FlightId == nil {
		fid = ReversalFlightId
	} else {
		fid = *req.FlightId
	}
	combinationList, err := v.VolumePriceDao.GetReversalExperimentCombination(ctx, fid)
	if err != nil {
		logs.CtxError(ctx, "[GetExperimentCombination]RDS查询combinationList失败,err:%v", err.Error())
		return nil, err
	}
	for _, combination := range combinationList {
		resp.Combinations = append(resp.Combinations, &volume_price.ExperimentCombination{
			Name:           combination.ObjectName,
			Code:           combination.ObjectCode,
			IsDefault:      combination.IsDefault,
			ExprGroupId:    combination.ExprGroupId,
			CompareGroupId: combination.CompareGroupId,
			ObjectType:     combination.ObjectType,
			BSideLibraId:   combination.BSideLibraId,
			CSideLibraId:   combination.CSideLibraId,
		})
	}
	return resp, nil
}

func (v *VolumePriceService) GenExprConditionByObjectList(ctx context.Context, objectList []*volume_price.ExperimentCombination) (selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition string, err error) {
	exprList, err := v.VolumePriceDao.GetRelatedExprList(ctx, objectList)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return "", "", "", "", "", "", err
	}
	selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition = genCondition(exprList)
	return selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition, nil
}

func (v *VolumePriceService) GenExprConditionByFid(ctx context.Context, fid int64, objectType []int64) (selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition string, err error) {
	exprList, err := v.VolumePriceDao.GetRelatedExperimentConfigByFid(ctx, fid, objectType)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return "", "", "", "", "", "", err
	}
	selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition = genCondition(exprList)
	return selectExpress, whereCondition, uvSelectExpress, uvWhereCondition, clusterCntSelectExpress, clusterCntWhereCondition, nil
}

func genCondition(exprList []*dao.ExprConfigMeta) (string, string, string, string, string, string) {
	var whereCondition, uvWhereCondition, clusterCntWhereCondition string
	var sb, uvSb, clusterSb strings.Builder
	var index int
	for _, expr := range exprList {
		// 当B侧和C侧vid都是空时，跳过此次拼接
		if expr.BSideVid == "" && expr.CSideVid == "" {
			continue
		}
		if index > 0 {
			uvSb.WriteString(",")
			clusterSb.WriteString(",")
			sb.WriteString(" or ")
		}
		clusterSb.WriteString(expr.BSideVid)
		uvSb.WriteString(expr.CSideVid)
		sb.WriteString("(")
		if expr.BSideVid != "" {
			sb.WriteString(fmt.Sprintf("group_id = %s", expr.BSideVid))
		}
		if expr.CSideVid != "" {
			if expr.BSideVid != "" {
				sb.WriteString(" and ")
			}
			sb.WriteString(fmt.Sprintf("v_id = %s", expr.CSideVid))
		}
		sb.WriteString(")")
		index++
	}
	// 如果选择的分析对象结果长度大于0，需要在外层套一层括号
	if index > 0 {
		clusterCntWhereCondition = "group_id in (" + clusterSb.String() + ")"
		uvWhereCondition = " v_id in (" + uvSb.String() + ")"
		whereCondition = "(" + sb.String() + ")"
	}

	// 拼接select的case when语句,uv指标只有C侧实验（存在多个评估对象的UV相同的情况），且需要explode展开
	var sb2, uvSb2, clusterSb2 strings.Builder
	var index2 int
	sb2.WriteString("case ")
	uvSb2.WriteString(" v_id, ")
	clusterSb2.WriteString(" group_id, ")
	for _, expr := range exprList {
		// 当B侧和C侧vid都是空时，跳过此次拼接
		if expr.BSideVid == "" && expr.CSideVid == "" {
			continue
		}
		sb2.WriteString(" when ")
		if expr.BSideVid != "" {
			sb2.WriteString(fmt.Sprintf("group_id = %s", expr.BSideVid))
		}
		if expr.CSideVid != "" {
			if expr.BSideVid != "" {
				sb2.WriteString(fmt.Sprintf(" and "))
			}
			sb2.WriteString(fmt.Sprintf("v_id = %s", expr.CSideVid))
			uvSb2.WriteString(fmt.Sprintf(" if(v_id = %s, ['%s'],[]) as cell_code_%d, ", expr.CSideVid, expr.ExprGroupId, index2))
			clusterSb2.WriteString(fmt.Sprintf(" if(group_id = %s, ['%s'], []) as cell_code_%d, ", expr.BSideVid, expr.ExprGroupId, index2))
			index2++
		}
		sb2.WriteString(fmt.Sprintf(" then '%v'", expr.ExprGroupId))
	}
	uvSb2.WriteString("arrayConcat(")
	clusterSb2.WriteString("arrayConcat(")
	for i := 0; i < index2; i++ {
		if i > 0 {
			uvSb2.WriteString(",")
			clusterSb2.WriteString(",")
		}
		uvSb2.WriteString(fmt.Sprintf("cell_code_%d", i))
		clusterSb2.WriteString(fmt.Sprintf("cell_code_%d", i))
	}
	uvSb2.WriteString(") ")
	clusterSb2.WriteString(") ")
	sb2.WriteString(" end ")
	return sb2.String(), whereCondition, uvSb2.String(), uvWhereCondition, clusterSb2.String(), clusterCntWhereCondition
}
