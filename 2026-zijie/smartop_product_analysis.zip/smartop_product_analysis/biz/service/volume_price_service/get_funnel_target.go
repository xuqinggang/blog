package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
)

func (v *VolumePriceService) GetVolumePriceMarketFunnelTarget(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp []*analysis.TargetCardEntity, err error) {
	// 获取业务线元信息
	//bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	//if err != nil || bizMetaInfo == nil {
	//	logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
	//	return resp, err
	//}
	req.BaseReq = &dimensions.ProductAnalysisBaseStruct{
		BizType:   req.BaseReq.BizType,
		StartDate: req.BaseReq.StartDate,
		EndDate:   req.BaseReq.EndDate,
	}

	// 获取业务线的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	// 获取invoker的入参
	curr, trend, err := base_struct_condition.GetVolumePriceBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{"核心汇总"})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, apiPathFunnelTarget, param.SinkTable("target_card")).SetParallel(true).SetMaxParallelNum(10)
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("value").
		SetTargetNameColumn("name"))
	var trendSubSql string
	// 趋势图
	f.ExeQueryInvokerRaw(trend, apiPathFunnelTarget, param.SinkTable("trend_data")).SetParallel(true).SetMaxParallelNum(10)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"date"}))
	// 趋势图加工sql
	trendSubSql = `
		(select date as x,
				target_name as name,
				m.display_name as display_name,
				target_value as value,
				get_display_value(target_value, m.value_type, m.value_unit,m.target_precision) as display_value
		from    trend_data t
		inner join target_meta m
		on t.target_name = m.name
		where   t.target_name=target_card.name
		order by x asc)
	`
	// 关联指标元信息, 处理额外信息
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.name as name,
				b.value as value,
				get_display_value(b.value, a.value_type, a.value_unit,a.target_precision) as display_value,
				%v as trend_data,
				a.display_name as display_name,
				a.tips as tips,
				a.value_unit as unit,
				a.attribute_type as category_name,
				a.display_order as display_order,
				a.need_second_query as need_second_query,
				a.is_use_pp as is_use_pp
		from    target_meta a
		inner join
				target_card b
		on      a.name=b.name
		order by a.display_order asc
	`, trendSubSql), param.SinkTable("card_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		// "custom_date":       onetable.NormalFunc(framework_udf.CustomDate),
	})
	resp = make([]*analysis.TargetCardEntity, 0)
	f.ExeView(param.SourceTable("card_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	analysis_service.SortTargetCardEntity(resp)
	return resp, nil
}
