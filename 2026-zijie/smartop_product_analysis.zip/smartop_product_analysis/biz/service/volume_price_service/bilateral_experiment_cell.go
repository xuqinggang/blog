package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/jinzhu/copier"
)

func CheckUserAuth(ctx context.Context) (bool, error) {
	if env.IsBoe() {
		return true, nil
	}
	userDimensionMap, err := utils.GetUserDimensionMap(ctx)
	if err != nil {
		return false, errors.New("获取数据权限失败")
	}
	return utils.CheckUserDimension(userDimensionMap, "Dm12501080000001"), nil
}

func (v *VolumePriceService) GetVolumePriceBilateralLibra(ctx context.Context, req *volume_price.GetVolumePriceBilateralLibraRequest) (resp *volume_price.VolumePriceBilateralLibraInfo, err error) {
	// 校验权限
	resp = &volume_price.VolumePriceBilateralLibraInfo{
		BcSideList: make([]*volume_price.BilateralLibraCell, 0),
	}
	resp.HasAuth, err = CheckUserAuth(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetVolumePriceBilateralLibra failed, %v+", err)
		return nil, err
	}
	if !resp.HasAuth {
		return resp, nil
	}
	configMetaInfo, err := v.VolumePriceDao.GetExperimentConfigMetaInfo(ctx, req.FlightId)
	if err != nil {
		logs.CtxError(ctx, "GetVolumePriceBilateralLibra failed, %v+", err)
		return nil, err
	}
	configMetaMap := make(map[volume_price.ExprObjectType]map[string]*dao.ExprConfigMetaInfo)
	for _, meta := range configMetaInfo {
		if _, ok := configMetaMap[meta.ObjectType]; !ok {
			configMetaMap[meta.ObjectType] = make(map[string]*dao.ExprConfigMetaInfo)
		}
		configMetaMap[meta.ObjectType][meta.ObjectCode] = meta
	}

	// 获取C端
	libraTypeCombination := volume_price.LibraType_LibraTypeCombination
	flightMeta, err := v.GetVolumePriceLibraList(ctx, &volume_price.GetVolumePriceLibraListRequest{
		StartDate: req.GetStartDate(),
		EndDate:   req.GetEndDate(),
		LibraType: &libraTypeCombination,
	}, &req.FlightId)
	if err != nil || len(flightMeta) == 0 || flightMeta[0].FlightInfo == nil {
		logs.CtxError(ctx, "GetVolumePriceBilateralLibra failed or empty,req=%s err=%v+", convert.ToJSONString(req), err)
		return nil, err
	}
	resp.CSideList = GetSingleSideList(ctx, flightMeta[0].FlightInfo.FlightId, flightMeta[0].VersionList, configMetaMap, volume_price.ExprObjectType_CSide)
	// 获取B端
	libraTypeCombination = volume_price.LibraType_LibraTypeCluster
	flightMeta, err = v.GetVolumePriceLibraList(ctx, &volume_price.GetVolumePriceLibraListRequest{
		StartDate: req.GetStartDate(),
		EndDate:   req.GetEndDate(),
		LibraType: &libraTypeCombination,
	}, &req.FlightId)
	if err != nil || len(flightMeta) == 0 || flightMeta[0].FlightInfo == nil {
		logs.CtxError(ctx, "GetVolumePriceBilateralLibra failed or empty,req=%s err=%v+", convert.ToJSONString(req), err)
		return nil, err
	}
	resp.BSideList = GetSingleSideList(ctx, flightMeta[0].FlightInfo.FlightId, flightMeta[0].VersionList, configMetaMap, volume_price.ExprObjectType_BSide)
	// 获取格子
	var index int
	for _, cSide := range resp.CSideList {
		for _, bSide := range resp.BSideList {
			cellInfo := &volume_price.BilateralLibraCell{
				ObjectType: volume_price.ExprObjectType_BCTwoSide,
				ObjectCode: fmt.Sprintf("%s_%s", cSide.CSideVid, bSide.BSideVid),
				ObjectName: fmt.Sprintf("G%d", index),
				CSideFid:   cSide.CSideFid,
				CSideVid:   cSide.CSideVid,
				CSideVName: cSide.CSideVName,
				BSideFid:   bSide.BSideFid,
				BSideVid:   bSide.BSideVid,
				BSideVName: bSide.BSideVName,
			}
			if configMetaMap != nil &&
				configMetaMap[volume_price.ExprObjectType_BCTwoSide] != nil {
				metaInfo := configMetaMap[volume_price.ExprObjectType_BCTwoSide][cellInfo.ObjectCode]
				if metaInfo != nil {
					cellInfo.ObjectCode = metaInfo.ObjectCode
					cellInfo.ObjectName = metaInfo.ObjectName
					cellInfo.ObjectDesc = metaInfo.ObjectDesc
				}
			}
			index++
			resp.BcSideList = append(resp.BcSideList, cellInfo)
		}
	}
	return
}

func GetSingleSideList(ctx context.Context, fid string, vList []*basic_info.LibraVersionBasicInfo, configMetaMap map[volume_price.ExprObjectType]map[string]*dao.ExprConfigMetaInfo, objType volume_price.ExprObjectType) []*volume_price.BilateralLibraCell {
	ret := make([]*volume_price.BilateralLibraCell, 0)
	for _, vInfo := range vList {
		if vInfo == nil {
			logs.CtxWarn(ctx, "GetSingleSideList failed, vInfo is nil")
			continue
		}
		bilateralLibraCell := &volume_price.BilateralLibraCell{}
		metaMap := configMetaMap[objType]
		if metaMap != nil && metaMap[vInfo.VersionId] != nil {
			metaInfo := metaMap[vInfo.VersionId]
			bilateralLibraCell = &volume_price.BilateralLibraCell{
				ObjectCode: metaInfo.ObjectCode,
				ObjectName: metaInfo.ObjectName,
				ObjectDesc: metaInfo.ObjectDesc,
			}
		} else {
			bilateralLibraCell = &volume_price.BilateralLibraCell{
				ObjectCode: vInfo.VersionId,
				ObjectName: fmt.Sprintf("%s%d", utils.If(objType == volume_price.ExprObjectType_CSide, "U", "B"), vInfo.VersionSort),
			}
		}

		if objType == volume_price.ExprObjectType_CSide {
			bilateralLibraCell.CSideFid = fid
			bilateralLibraCell.CSideVid = vInfo.VersionId
			bilateralLibraCell.CSideVName = vInfo.VersionName
		} else {
			bilateralLibraCell.BSideFid = fid
			bilateralLibraCell.BSideVid = vInfo.VersionId
			bilateralLibraCell.BSideVName = vInfo.VersionName
		}
		bilateralLibraCell.ObjectType = objType
		ret = append(ret, bilateralLibraCell)
	}
	return ret
}

func GetVolumePriceBSideList(ctx context.Context) (resp []*volume_price.LibraFlightInfo, err error) {
	params := make(map[string]interface{})
	newest, err := utils.GetNewestDay(ctx, "7457440529832248347")
	if err != nil {
		logs.CtxError(ctx, "[GetVolumePriceLibraList]获取最新配置表信息时间失败")
		return resp, errors.New("获取最新配置表信息时间失败")
	}
	params["date"] = newest
	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(params, "7457811298462532635", param.SinkTable("libra_list"))
	libraMetaList := make([]*LibraMetaInfo, 0)
	f.ExeView(param.SourceTable("libra_list"), &libraMetaList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	if len(libraMetaList) == 0 {
		logs.CtxInfo(ctx, "[GetVolumePriceLibraList]未查询到实验信息")
		return resp, nil
	}

	fMetaMap := make(map[int64][]*basic_info.LibraVersionBasicInfo)
	for _, record := range libraMetaList {
		vList := fMetaMap[record.FLightID]
		if len(vList) == 0 {
			vList = make([]*basic_info.LibraVersionBasicInfo, 0)
		}
		vName := record.VersionName
		if record.VersionType == basic_info.LibraVersionType_ControlGroup || record.VersionSort > 0 {
			vName = fmt.Sprintf("V%d: ", record.VersionSort) + record.VersionName
		}
		vList = append(vList, &basic_info.LibraVersionBasicInfo{
			VersionId:   convert.ToString(record.VersionID),
			VersionName: vName,
			VersionType: record.VersionType,
			VersionSort: record.VersionSort,
		})
		fMetaMap[record.FLightID] = vList
	}

	resp = make([]*volume_price.LibraFlightInfo, 0)
	for fid, vList := range fMetaMap {
		resp = append(resp, &volume_price.LibraFlightInfo{
			FlightInfo: &basic_info.LibraBasicInfo{
				FlightId: convert.ToString(fid),
			},
			VersionList: vList,
		})
	}
	return
}

func (v *VolumePriceService) SaveVolumePriceBilateralLibra(ctx context.Context, req *volume_price.SaveVolumePriceBilateralLibraRequest) (resp bool, err error) {
	if req.Info == nil || len(req.Info.BcSideList) == 0 || len(req.Info.CSideList) == 0 || len(req.Info.BSideList) == 0 {
		logs.CtxWarn(ctx, "[SaveVolumePriceBilateralLibra]配置的实验信息为空, req = %s", convert.ToJSONString(req))
		return false, errors.New("配置的实验信息为空")
	}
	if len(req.Info.BcSideList) != len(req.Info.CSideList)*len(req.Info.BSideList) {
		logs.CtxWarn(ctx, "[SaveVolumePriceBilateralLibra]配置的实验格子与单边实验数量不匹配, req = %s", convert.ToJSONString(req))
		return false, errors.New("配置的实验格子与单边实验数量不匹配")
	}
	hasAuth, err := CheckUserAuth(ctx)
	if err != nil {
		logs.CtxError(ctx, "SaveVolumePriceBilateralLibra failed, %v+", err)
		return false, err
	}
	if !hasAuth {
		return false, errors.New("无权限提交实验配置信息")
	}

	// 保存实验配置信息
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[SaveVolumePriceBilateralLibra]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return false, errors.New("获取数据库的事务失败")
	}

	// 软删除旧的实验配置信息 expr_config_meta_info
	err = v.VolumePriceDao.DeleteExprConfigMetaInfo(ctx, tx, req.FlightId)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "VolumePriceDao.UpdateDimensionBizInfo Error: %s", err.Error())
		return false, err
	}

	// 插入实验配置信息
	insertList := make([]*dao.ExprConfigMetaInfo, 0)
	for _, cell := range append(append(req.Info.BcSideList, req.Info.CSideList...), req.Info.BSideList...) {
		newInsert := &dao.ExprConfigMetaInfo{}
		err = copier.Copy(newInsert, &cell)
		if err != nil {
			return false, err
		}
		newInsert.FlightID = req.FlightId
		insertList = append(insertList, newInsert)
	}
	err = v.VolumePriceDao.InsertExprConfigMetaInfo(ctx, tx, insertList)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "VolumePriceDao.InsertExprConfigMetaInfo Error: %s", err.Error())
		return false, err
	}
	tx.Commit()
	return true, nil
}
