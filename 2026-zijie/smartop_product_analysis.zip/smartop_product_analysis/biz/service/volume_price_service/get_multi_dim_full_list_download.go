package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
)

func (v *VolumePriceService) GetVolumePriceMultiDimFullListDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}

	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 获取分析的维度信息
	groupCols := make([]*dao.DimensionInfo, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		groupCols = append(groupCols, dimInfo)
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := v.GetVolumePriceMultiDimFullList(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}

	table, targetList := getMultiDimFullTableAndHeaderList(coreRet, groupCols)
	f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genGetMultiDimFullTable, param.SinkTable("core_data"))
	f.ExeCustom([]param.Source{param.SourceTable("core_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(targetList), param.SourceConst(groupCols)}, doExportGetMultiDimFullData, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func appendFullList(fullList []*analysis.MultiDimFullListRow, table []map[string]interface{}, groupCols []*dao.DimensionInfo, groupRecord map[string]string) []map[string]interface{} {
	if len(fullList) == 0 {
		return table
	}

	for _, info := range fullList {
		record := make(map[string]interface{})
		dimKeyRecord := make(map[string]string)
		for i, group := range groupCols {
			if groupVal := groupRecord[group.DimColumn]; len(groupVal) > 0 {
				record[group.DimColumn] = groupVal
				dimKeyRecord[group.DimColumn] = groupVal
			} else if len(groupRecord) == i {
				record[group.DimColumn] = info.DisplayName
				dimKeyRecord[group.DimColumn] = info.DisplayName
			} else {
				record[group.DimColumn] = "-"
			}
		}
		if len(info.TargetList) > 0 {
			for _, target := range info.TargetList {
				record[target.DisplayName] = target.Value
			}
		}
		table = append(table, record)
		table = appendFullList(info.Children, table, groupCols, dimKeyRecord)
	}
	return table
}

func getMultiDimFullTableAndHeaderList(coreData *analysis.GetProductAnalysisMultiDimFullListData, groupCols []*dao.DimensionInfo) ([]map[string]interface{}, []string) {
	table := make([]map[string]interface{}, 0)
	targetList := make([]string, 0)
	recordTotal := make(map[string]interface{})
	for i, c := range groupCols {
		recordTotal[c.DimColumn] = utils.If(i == 0, "整体", "-")
	}
	if coreData != nil && coreData.Total != nil && len(coreData.Total.TargetList) > 0 {
		for _, target := range coreData.Total.TargetList {
			recordTotal[target.DisplayName] = target.Value
			targetList = append(targetList, target.DisplayName)
		}
	}
	table = append(table, recordTotal)
	if coreData != nil {
		table = appendFullList(coreData.FullList, table, groupCols, make(map[string]string))
	}
	return table, targetList
}

func genGetMultiDimFullTable(ctx context.Context, table []map[string]interface{}) (*onetable.Table, error) {
	return onetable.NewTable(table), nil
}

func doExportGetMultiDimFullData(ctx context.Context, table *onetable.Table, email string, analysisRange string, targetList []string, groupCols []*dao.DimensionInfo) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet("指标列表", table)
	sheet.AddHead([][]string{{"分析周期", analysisRange}})

	for _, group := range groupCols {
		sheet.AddColumn(group.ShowName, group.DimColumn)
	}
	for _, t := range targetList {
		sheet.AddColumn(t, t)
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "量价模型-多维分析数据")
	return nil, formatter.Export(ctx, email, nil, nil)
}
