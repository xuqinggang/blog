package volume_price_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/dal/db/model"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

func (v *VolumePriceService) SaveExprObject(ctx context.Context, req *volume_price.SaveExprObjectRequest) (resp bool, err error) {
	// 校验参数，不允许实验组和对照组ID相同
	for _, object := range req.ExprObjects {
		if object.ExprGroupId == object.CompareGroupId {
			err = errors.New("存在实验组和对照组的评估对象，请修改配置后重试")
			logs.CtxWarn(ctx, "存在实验组和对照组的评估对象，请修改配置后重试")
			return false, err
		}
	}
	var fid string
	if req.CommonReq != nil && req.CommonReq.FlightId != nil {
		fid = *req.CommonReq.FlightId
	} else {
		fid = ReversalFlightId
	}
	//configMetaInfo, err := v.VolumePriceDao.GetExperimentConfigMetaInfo(ctx, fid)
	//if err != nil {
	//	logs.CtxError(ctx, "GetVolumePriceBilateralLibra failed, %v+", err)
	//	return false, err
	//}
	//var confMap = make(map[string]*dao.ExprConfigMetaInfo)
	//for _, info := range configMetaInfo {
	//	confMap[info.ObjectCode] = info
	//}
	//// 自动生成名称尾缀，例如评估对象名称是"超值购",实验组是G7,对照组是G0，自动在后面拼接（G7-G0）
	//for _, object := range req.ExprObjects {
	//	if _, ok := confMap[object.ExprGroupId]; ok {
	//		if _, ok2 := confMap[object.CompareGroupId]; ok2 {
	//			suffix := fmt.Sprintf("(%s-%s)", confMap[object.ExprGroupId].ObjectName, confMap[object.CompareGroupId].ObjectName)
	//			if !strings.HasSuffix(object.Name, suffix) {
	//				object.Name = object.Name + suffix
	//			}
	//		}
	//	}
	//}
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	var exprList = make([]*model.TwoSideExperimentObjectConfig, 0)
	for _, object := range req.ExprObjects {
		var isDefault int32
		var code int64
		if object.IsDefault {
			isDefault = 1
		}
		if object.Code != "" {
			code = convert.ToInt64(object.Code)
		}
		exprObject := &model.TwoSideExperimentObjectConfig{
			BSideLibraID:   object.BSideLibraId,
			CSideLibraID:   fid,
			ObjectName:     object.Name,
			ObjectType:     int32(object.ObjectType),
			ExprGroupID:    object.ExprGroupId,
			CompareGroupID: object.CompareGroupId,
			IsDefault:      isDefault,
			Creator:        email,
		}
		if code != 0 {
			exprObject.ID = code
		}
		exprList = append(exprList, exprObject)
	}
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return false, errors.New("获取数据库的事务失败")
	}
	err = v.VolumePriceDao.BatchInsertExprObject(ctx, tx, exprList)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	tx.Commit()
	return true, nil
}
