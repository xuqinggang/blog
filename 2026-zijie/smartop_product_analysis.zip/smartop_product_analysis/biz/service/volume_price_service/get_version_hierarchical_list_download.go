package volume_price_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
	"strconv"
	"strings"
)

func (v *VolumePriceService) GetVolumePriceVersionHierarchicalListDownload(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalListRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := v.GetVolumePriceVersionHierarchicalList(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	table, targetList := getVersionHierarchicalTableAndTargetList(coreRet)

	targetName, _ := GetNameByTargetType(ctx, req.TargetType)
	f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genGetLibraVersionListTable, param.SinkTable("core_data"))
	f.ExeCustom([]param.Source{param.SourceTable("core_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(targetList), param.SourceConst(targetName)}, doExportGetVersionHierarchicalListData, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func getVersionHierarchicalTableAndTargetList(coreData []*volume_price.LibraFlightInfoData) ([]map[string]interface{}, []string) {
	table := make([]map[string]interface{}, 0)
	targetList := make([]string, 0)
	if len(coreData) > 0 {
		if len(coreData[0].VersionList) > 0 && len(coreData[0].VersionList[0].TargetList) > 0 {
			for _, target := range coreData[0].VersionList[0].TargetList {
				if !strings.HasSuffix(target.Name, "_percent") {
					targetList = append(targetList, target.DisplayName)
				}
			}
		}
		for _, data := range coreData {
			if len(data.VersionList) > 0 {
				for _, version := range data.VersionList {
					record := make(map[string]interface{})
					record["scenarios"] = data.ScenariosName
					record["flight_id"] = data.FlightInfo.FlightId
					record["flight_name"] = data.FlightInfo.FlightName
					record["version_id"] = version.VersionBasicInfo.VersionId
					record["version_name"] = version.VersionBasicInfo.VersionName
					switch version.VersionBasicInfo.VersionType {
					case basic_info.LibraVersionType_ControlGroup:
						record["version_type"] = "对照组"
					case basic_info.LibraVersionType_ExperimentalGroup:
						record["version_type"] = "实验组"
					default:
						record["version_type"] = "-"
					}

					var vAttrTargetMap = make(map[string]map[string]interface{})
					if len(version.TargetList) > 0 {
						for _, target := range version.TargetList {
							attrRecord := vAttrTargetMap[target.Extra.AttributeType]
							if len(attrRecord) == 0 {
								attrRecord = make(map[string]interface{})
							}
							attrRecord["attribute_type"] = target.Extra.AttributeType
							if strings.HasSuffix(target.Extra.AttributeType, "(占比)") {
								attrRecord[target.DisplayName] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(target.Value*100, 'f', 5, 64)) + "%"
							} else {
								attrRecord[target.DisplayName] = target.Value
							}
							vAttrTargetMap[target.Extra.AttributeType] = attrRecord
						}
					}

					for _, attrRecord := range vAttrTargetMap {
						table = append(table, MergeRecord(record, attrRecord))
					}
				}
			}
		}
	}
	return table, targetList
}

func MergeRecord(record, appendRecord map[string]interface{}) map[string]interface{} {
	ret := make(map[string]interface{})
	for k, v := range record {
		ret[k] = v
	}
	for k, v := range appendRecord {
		ret[k] = v
	}
	return ret
}

func doExportGetVersionHierarchicalListData(ctx context.Context, table *onetable.Table, email string, analysisRange string, targetList []string, targetName string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet("指标列表", table)
	sheet.AddHead([][]string{{"分析周期", analysisRange}})

	sheet.AddColumn("实验场域", "scenarios").
		AddColumn("实验ID", "flight_id").
		AddColumn("实验名称", "flight_name").
		AddColumn("实验组ID", "version_id").
		AddColumn("实验组名称", "version_name").
		AddColumn("实验组类型", "version_type").
		AddColumn("指标类型", "attribute_type")
	for _, t := range targetList {
		sheet.AddColumn(t, t)
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, fmt.Sprintf("量价模型-实验增量%s分布", targetName))
	return nil, formatter.Export(ctx, email, nil, nil)
}
