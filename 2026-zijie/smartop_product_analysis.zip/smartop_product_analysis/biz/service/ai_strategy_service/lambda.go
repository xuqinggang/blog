package ai_strategy_service

import (
	"context"
	"fmt"

	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"
	"github.com/cloudwego/eino/schema"
)

const InValidMsg = "输出的 JSON 字符串类型不正确或不合法，请检查后重新输出"

func buildValidateLambda[T any]() *compose.Lambda {
	return compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) ([]*schema.Message, error) {
		// 校验输入是否符合要求
		if len(input) == 0 {
			logs.CtxError(ctx, "[Validate Lambda] validate input message empty")
			return nil, fmt.Errorf("validate input message empty")
		}

		lastMsg := input[len(input)-1]
		// 有时候模型会在ReasoningContent中输出，需要兼容该场景
		if lastMsg.Content == "" {
			lastMsg.Content = lastMsg.ReasoningContent
		}

		outputType, _, _ := validateOutput[T](lastMsg.Content)
		if outputType == OutputValidateFailed {
			logs.CtxWarn(ctx, "[Validate Lambda] validate output message failed, output=%s", lastMsg.Content)
			return []*schema.Message{schema.UserMessage(InValidMsg)}, nil
		}

		return input, nil
	})
}

func buildReActLambda(agent *react.Agent) *compose.Lambda {
	return compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (output []*schema.Message, err error) {
		option, feature := react.WithMessageFuture() // 获取消息future
		// 创建错误通道
		errChan := make(chan error, 1)

		// 在 goroutine 中调用react agent
		go func() {
			defer func() {
				if err := recover(); err != nil {
					logs.CtxError(ctx, "[ReAct Lambda] panic err: %v", err)
				}
			}()

			_, err = agent.Generate(ctx, input, option) // 通过invoke的方式调用react agent
			if err != nil {
				logs.CtxError(ctx, "[ReAct Lambda] agent.Generate failed, err=%v", err)
				errChan <- err // 将错误发送到通道
				return
			}

			// 如果执行成功，发送 nil 表示没有错误
			errChan <- nil
		}()

		// 主线程等待 goroutine 完成并获取错误
		if err := <-errChan; err != nil {
			return nil, err
		}

		// 获取react agent历史消息
		ms := feature.GetMessages() // ms是一个迭代器，用于获取react agent的历史消息
		for {
			frame, succ, _err := ms.Next()
			if _err != nil {
				logs.CtxError(ctx, "[ReAct Lambda] ms.Next failed, err=%v", _err)
				return nil, _err
			}
			if !succ {
				break
			}
			output = append(output, frame)
		}

		return
	})
}
