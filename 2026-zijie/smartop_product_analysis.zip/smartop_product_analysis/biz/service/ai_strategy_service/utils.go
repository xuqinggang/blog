package ai_strategy_service

import (
	"bytes"
	"context"
	"fmt"
	"strings"
	"text/template"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"github.com/bytedance/sonic"
)

// TemplateData 用于传递给模板的数据结构
type TemplateData struct {
	Date          string
	FlightID      int64
	MetricGroupID int64
	MetricIDList  string
	Dimensions    []*ai_analysis.Dimension
	DimKeys       string
	DimValueKeys  string
	HasDimension  bool
}

// generateSQL 根据输入的 date 和 metricGroup 生成 SQL 字符串
func generateSQL(ctx context.Context, date string, flightID int64, metricGroup *ai_analysis.MetricGroup) (string, error) {
	flowStrategyConfig, err := biz_info.GetFlowStrategyConfig(ctx)
	if err != nil {
		return "", fmt.Errorf("获取流量效率策略配置失败: %w", err)
	}
	sqlTemplate := flowStrategyConfig.FlightMetricSqlTemplate

	tmpl, err := template.New("sql").Parse(sqlTemplate)
	if err != nil {
		return "", fmt.Errorf("解析SQL模板失败: %w", err)
	}

	if metricGroup == nil {
		return "", fmt.Errorf("指标组不能为空")
	}

	// 处理 metric_id_list
	if len(metricGroup.MetricIdList) == 0 {
		return "", fmt.Errorf("指标组的metric_id_list不能为空")
	}

	var metricIDs []string
	for _, mid := range metricGroup.MetricIdList {
		metricIDs = append(metricIDs, fmt.Sprintf("%d", mid))
	}

	if len(metricIDs) == 0 {
		return "", fmt.Errorf("指标组没有有效的指标ID")
	}

	data := TemplateData{
		Date:          date,
		FlightID:      flightID,
		MetricGroupID: metricGroup.MetricGroupId,
		MetricIDList:  strings.Join(metricIDs, ", "),
		Dimensions:    metricGroup.Dimensions,
		HasDimension:  len(metricGroup.Dimensions) > 0,
	}

	if data.HasDimension {
		// 处理维度键名
		var dimKeys []string
		var allValueKeys []string

		for _, dim := range metricGroup.Dimensions {
			if dim != nil {
				// 维度键名用双引号包裹
				dimKeys = append(dimKeys, fmt.Sprintf("\"%s\"", strings.ReplaceAll(dim.DimKey, "\"", "\"\"")))

				// 处理维度值
				for _, dv := range dim.DimValues {
					allValueKeys = append(allValueKeys, fmt.Sprintf("\"%s\"", strings.ReplaceAll(dv.ValueKey, "\"", "\"\"")))
				}
			}
		}

		if len(dimKeys) > 0 {
			data.DimKeys = strings.Join(dimKeys, ", ")
		}

		if len(allValueKeys) > 0 {
			data.DimValueKeys = strings.Join(allValueKeys, ", ")
		}
	}

	var buf bytes.Buffer
	if err := tmpl.Execute(&buf, data); err != nil {
		return "", fmt.Errorf("执行模板失败(指标组%d): %w", metricGroup.MetricGroupId, err)
	}

	return strings.TrimSpace(buf.String()), nil
}

type OutputType int32

const (
	// 校验不通过
	OutputValidateFailed OutputType = iota
	// 错误信息
	OutputErrorMsg
	// 正常信息
	OutputNormalMsg
)

func validateOutput[T any](input string) (outputType OutputType, errorOutput *ErrorOutput, output T) {
	if err := sonic.UnmarshalString(input, &output); err != nil {
		if err := sonic.UnmarshalString(input, &errorOutput); err != nil {
			outputType = OutputValidateFailed
			return
		}
		outputType = OutputErrorMsg
		return
	}

	outputType = OutputNormalMsg
	return
}
