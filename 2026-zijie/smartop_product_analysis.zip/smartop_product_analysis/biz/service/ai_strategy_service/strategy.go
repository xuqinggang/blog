package ai_strategy_service

import (
	"context"
	"encoding/json"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/idgenerator"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/gopkg/logs/v2"
)

func (d *AIStrategyService) CreateStrategy(ctx context.Context, req *ai_analysis.CreateStrategyRequest) error {
	err := d.AIStrategyDao.CreateStrategy(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[CreateStrategy] create strategy failed, err: %v", err)
		return err
	}
	return nil
}

func (d *AIStrategyService) UpdateStrategy(ctx context.Context, req *ai_analysis.UpdateStrategyRequest) error {
	err := d.AIStrategyDao.UpdateStrategy(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[UpdateStrategy] update strategy failed, err: %v", err)
		return err
	}
	return nil
}

func (d *AIStrategyService) GetStrategyDetail(ctx context.Context, req *ai_analysis.GetStrategyDetailRequest) (*ai_analysis.StrategyDetail, error) {
	strategyDetail, err := d.AIStrategyDao.GetStrategyDetailByKey(ctx, req.StrategyKey)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyDetail] get strategy detail failed, err: %v", err)
		return nil, err
	}
	return strategyDetail, nil
}

func (d *AIStrategyService) CreateStrategyConfig(ctx context.Context, req *ai_analysis.CreateStrategyConfigRequest) error {
	strategyConfigs := make([]*dao.StrategyConfig, 0, len(req.StrategyConfigs))
	for _, strategyConfig := range req.StrategyConfigs {
		strategyConfigId, err := idgenerator.GenerateIdString(ctx)
		if err != nil {
			logs.CtxError(ctx, "[CreateStrategyConfig] generate id failed, err: %v", err)
			return err
		}

		_strategyConfig := &dao.StrategyConfig{
			StrategyConfigId: strategyConfigId,
			StrategyKey:      strategyConfig.StrategyKey,
			Description:      strategyConfig.Description,
			IsAdopt:          strategyConfig.IsAdopt,
			RejectReason:     strategyConfig.RejectReason,
		}

		if strategyConfig.Score != nil && len(*strategyConfig.Score) > 0 {
			_strategyConfig.Score = *strategyConfig.Score
		}

		if strategyConfig.Reason != nil && len(*strategyConfig.Reason) > 0 {
			_strategyConfig.Reason = *strategyConfig.Reason
		}

		if len(strategyConfig.Config) > 0 {
			if err := json.Unmarshal([]byte(strategyConfig.Config), &_strategyConfig.Config); err != nil {
				logs.CtxError(ctx, "[CreateStrategyConfig] unmarshal config failed, err: %v, config: %s", err, strategyConfig.Config)
				return err
			}
		}

		if strategyConfig.EvaluateResult_ != nil && len(*strategyConfig.EvaluateResult_) > 0 {
			if err := json.Unmarshal([]byte(*strategyConfig.EvaluateResult_), &_strategyConfig.EvaluateResult); err != nil {
				logs.CtxError(ctx, "[CreateStrategyConfig] unmarshal evaluate result failed, err: %v, evaluate result: %s", err, *strategyConfig.EvaluateResult_)
				return err
			}
		}

		strategyConfigs = append(strategyConfigs, _strategyConfig)
	}

	if err := d.AIStrategyDao.BatchCreateStrategyConfig(ctx, strategyConfigs); err != nil {
		logs.CtxError(ctx, "[CreateStrategyConfig] create strategy configs failed, err: %v", err)
		return err
	}

	return nil
}

func (d *AIStrategyService) CreateStrategyConfigFlightRelation(ctx context.Context, req *ai_analysis.CreateStrategyConfigFlightRelationRequest) error {
	err := d.AIStrategyDao.BatchCreateStrategyConfigFlightRelation(ctx, req.StrategyRelations)
	if err != nil {
		logs.CtxError(ctx, "[CreateStrategyConfigFlightRelation] create strategy config flight relation failed, err: %v", err)
		return err
	}
	return nil
}

func (d *AIStrategyService) RejectStrategyConfig(ctx context.Context, req *ai_analysis.RejectStrategyConfigRequest) error {
	err := d.AIStrategyDao.BatchRejectStrategyConfig(ctx, req.StrategyConfigIds, req.RejectReason)
	if err != nil {
		logs.CtxError(ctx, "[RejectStrategyConfig] reject strategy config failed, err: %v", err)
		return err
	}
	return nil
}
