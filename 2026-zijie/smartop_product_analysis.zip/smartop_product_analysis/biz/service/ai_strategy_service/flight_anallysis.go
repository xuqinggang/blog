package ai_strategy_service

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"
	"time"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/callback"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/libra"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tos"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tqs"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/lark"
	"code.byted.org/flow/eino-byted-ext/components/prompt/prompthub"
	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino-ext/components/model/ark"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"
	"github.com/cloudwego/eino/schema"
	"github.com/pborman/uuid"
	"github.com/thoas/go-funk"
	"github.com/volcengine/volcengine-go-sdk/service/arkruntime/model"
)

type VersionInfo struct {
	BaseUser     int64                        `json:"base_user"`               // 实验进组人数
	StrategyList []*dao.VersionStrategyConfig `json:"strategy_list,omitempty"` // 策略配置列表，每个策略配置包含策略的唯一标识和具体的策略配置ID
	libra.Version
}

type MetricGroupDetail struct {
	ObjKey string `json:"obj_key,omitempty"` // 实验指标查询结果在TOS中的key
	libra.MetricGroupDetailData
}

type FlightInfo struct {
	ID           int64                `json:"id"`            // 实验id
	InheritType  int                  `json:"inherit_type"`  // 分流类型，0:uid, 1:did, 2:rid, 3:union, 4:uuid, 5:cdid, 6:ssid, 7:webid, 8:pkid, 9:纯uid分流
	Status       int                  `json:"status"`        // 实验状态，0:已结束, 1:进行中, 2:待调度, 3:调试中, 4:已暂停, 91同0
	Name         string               `json:"name"`          // 实验名称
	Description  string               `json:"description"`   // 实验描述
	Background   string               `json:"background"`    // 实验背景
	StartTime    string               `json:"start_time"`    // 实验开始时间，格式为yyyy-MM-dd HH:mm:ss
	EndTime      string               `json:"end_time"`      // 实验结束时间，格式为yyyy-MM-dd HH:mm:ss
	Expectation  string               `json:"expectation"`   // 实验目标
	SumBaseUser  int64                `json:"sum_baseuser"`  // 实验进组人数总和
	Versions     []*VersionInfo       `json:"versions"`      // 实验分组
	MetricGroups []*MetricGroupDetail `json:"metric_groups"` // 实验核心指标组详情
}

type FlightAnalysisResult struct {
	StrategyKey       string `json:"strategy_key"`       // 策略key
	StrategyConfigID  string `json:"strategy_config_id"` // 策略配置id
	FlightID          int64  `json:"flight_id"`          // 实验id
	VersionID         int64  `json:"version_id"`         // 实验分组id
	DisplayOrder      int64  `json:"display_order"`      // 策略在实验组配置的排序，数值越小越先执行
	FlightConclusion  string `json:"flight_conclusion"`  // 实验结论，Markdown 格式，字数不超过400字
	ReflectionContent string `json:"reflection_content"` // 实验反思结论和迭代建议，Markdown 格式，字数不超过400字
}

type FlightAnalysisOutput = []*FlightAnalysisResult

func (d *AIStrategyService) FlightAnalysis(ctx context.Context, req *ai_analysis.FlightAnalysisRequest) (string, error) {
	// 获取用户信息，PS：agw流式协议转换之后无法从ctx中获取用户信息
	user, err := utils.GetEcopUserByEmployeeId(ctx, req.EmployeeId)
	if err != nil {
		logs.CtxError(ctx, "[Flight Analysis] GetEcopUserByEmployeeId failed, err=%v", err)
		return "", err
	}

	// 获取fornax client
	fornaxClient := fornax.GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[Flight Analysis] GetFornaxClient failed")
		return "", fmt.Errorf("get fornax client failed")
	}

	// 获取方舟配置
	arkConfig, err := biz_info.GetArkConfig(ctx)
	if err != nil || arkConfig == nil {
		logs.CtxError(ctx, "[Flight Analysis] GetArkConfig failed, err=%v", err)
		return "", err
	}

	// 获取流量效率配置
	flowStrategyConfig, err := biz_info.GetFlowStrategyConfig(ctx)
	if err != nil || flowStrategyConfig == nil {
		logs.CtxError(ctx, "[Flight Analysis] GetFlowStrategyConfig failed, err=%v", err)
		return "", err
	}

	// 实验核心指标，优先取请求中的，否则取tcc配置中的
	coreMetricGroups := flowStrategyConfig.FlightCoreMetrics
	if len(req.Config.CoreMetrics) > 0 {
		coreMetricGroups = req.Config.CoreMetrics
	}

	// 获取ai配置
	aiConfig, err := biz_info.GetArtificialIntelligenceConfig(ctx)
	if err != nil || aiConfig == nil {
		logs.CtxError(ctx, "[Flight Analysis] GetArtificialIntelligenceConfig failed, err=%v", err)
		return "", err
	}

	// 获取会话id
	sessionId, err := d.AIAnalysisService.GetSessionId(ctx, req.EmployeeId, req.SessionId, nil)
	if err != nil || sessionId == "" {
		logs.CtxError(ctx, "[Flight Analysis] get session id failed, err=%v", err)
		return "", err
	}

	g := compose.NewGraph[string, *schema.Message](compose.WithGenLocalState(func(ctx context.Context) *State {
		return &State{}
	}))
	taskId := uuid.NewUUID().String() // 本轮任务ID
	var flightName string
	var output *schema.Message

	// 关闭session
	defer func() {
		_err := tools.CloseSession(ctx, taskId)
		if _err != nil {
			logs.CtxWarn(ctx, "[Flight Analysis] close session failed, session_id=%s, err=%v", taskId, _err)
		}
	}()

	// 发送飞书通知
	defer func() {
		if user.Email == nil || *user.Email == "" {
			return
		}

		// 根据是否有错误/输出内容来设置策略配置文案
		var flightAnalysisOutput string
		if err != nil {
			flightAnalysisOutput = fmt.Sprintf("invoke failed: %s", err.Error())
		} else if output != nil {
			flightAnalysisOutput = output.Content
		}

		if _err := lark_service.SendCardMsg(ctx, *user.Email, &lark_service.CardData{
			TemplateId: FlightAnalysisCardTemplateID,
			TemplateVariable: map[string]interface{}{
				"session_id":      sessionId,
				"flight_id":       req.Config.FlightId,
				"flight_name":     flightName,
				"flight_analysis": flightAnalysisOutput,
			},
		}); _err != nil {
			logs.CtxError(ctx, "[Flight Analysis] SendCardMsg failed, err=%v", _err)
		}
	}()

	// 前置处理节点：获取前置信息、历史消息
	preprocessLambda := compose.InvokableLambda(func(ctx context.Context, input string) (map[string]any, error) {
		syncMap, ok := ctx.Value(consts.CtxSyncMap).(*utils.SyncMap)
		if !ok || syncMap == nil {
			return nil, fmt.Errorf("sync map not found in context")
		}

		// 1. 获取实验基础信息
		flightResp, _err := libra.GetFlightDetail(ctx, req.Config.FlightId)
		if _err != nil || flightResp == nil || flightResp.Code != 0 || flightResp.Data == nil {
			logs.CtxError(ctx, "[Flight Analysis] GetFlightDetail failed, err=%v", _err)
			return nil, _err
		}
		flightName = flightResp.Data.Flight.Name
		flightInfo := &FlightInfo{
			ID:           flightResp.Data.Flight.ID,
			InheritType:  flightResp.Data.Flight.InheritType,
			Status:       flightResp.Data.Flight.Status,
			Name:         flightResp.Data.Flight.Name,
			Description:  flightResp.Data.Flight.Description,
			StartTime:    flightResp.Data.Flight.StartTime,
			EndTime:      flightResp.Data.Flight.EndTime,
			Expectation:  flightResp.Data.Flight.Expectation,
			Versions:     make([]*VersionInfo, 0, len(flightResp.Data.Flight.Versions)),
			MetricGroups: make([]*MetricGroupDetail, 0, len(coreMetricGroups)),
		}
		for _, version := range flightResp.Data.Flight.Versions {
			flightInfo.Versions = append(flightInfo.Versions, &VersionInfo{
				Version: version,
			})
		}

		// 2. 获取实验进组人数
		baseUserResp, _err := libra.GetFlightBaseUser(ctx, req.Config.FlightId)
		if _err != nil || baseUserResp == nil || baseUserResp.Code != 0 || baseUserResp.Data == nil {
			logs.CtxError(ctx, "[Flight Analysis] GetFlightBaseUser failed, err=%v", _err)
			return nil, _err
		}
		flightInfo.SumBaseUser = baseUserResp.Data.SumBaseuser
		for _, version := range flightInfo.Versions {
			_version, ok := funk.Find(baseUserResp.Data.Baseuser, func(baseuser libra.Baseuser) bool {
				return baseuser.Vid == version.ID
			}).(libra.Baseuser)
			if ok {
				version.BaseUser = _version.Baseuser
			}
		}

		// 3. 获取实验背景信息
		if req.Config.ReferenceDoc != nil && *req.Config.ReferenceDoc != "" {
			// 校验文档权限
			var checkDocResp *lark.CheckDocPermissionResponseData
			checkDocResp, _err = d.LarkService.CheckDocPermission(ctx, *req.Config.ReferenceDoc, &req.EmployeeId)
			if _err != nil {
				logs.CtxError(ctx, "[Flight Analysis] CheckDocPermission failed, err=%v", _err)
				return nil, _err
			}
			if checkDocResp.HasPermission {
				// 获取文档内容
				var docContent string
				docContent, _err = d.LarkService.GetDocContent(ctx, *req.Config.ReferenceDoc, &req.EmployeeId)
				if _err != nil {
					logs.CtxError(ctx, "[Flight Analysis] GetDocContent failed, err=%v", _err)
					return nil, _err
				}
				flightInfo.Background += fmt.Sprintf("%s\n\n", docContent)
			}
		}
		if req.Config.ReferenceInfo != nil && *req.Config.ReferenceInfo != "" {
			flightInfo.Background += *req.Config.ReferenceInfo
		}

		// 4. 获取实验策略信息
		cc := co.NewConcurrent(ctx)
		for _, version := range flightInfo.Versions {
			currentVersion := version

			// 并发根据flight_id和version_id获取策略列表详情
			cc.GoV2(func() error {
				strategyList, strategyConfigErr := d.AIStrategyDao.GetVersionStrategyConfig(ctx, flightInfo.ID, currentVersion.ID)
				if strategyConfigErr != nil {
					return strategyConfigErr
				}
				currentVersion.StrategyList = strategyList
				return nil
			})
		}
		_err = cc.WaitV2()
		if _err != nil {
			logs.CtxError(ctx, "[Flight Analysis] GetVersionStrategyConfig failed, err=%v", _err)
			return nil, _err
		}

		// 4. 并发获取指标组详情
		cc2 := co.NewConcurrent(ctx)
		mu := sync.Mutex{}
		for _, metric := range coreMetricGroups {
			currentMetric := metric

			// 并发根据flight_id和version_id获取指标组详情
			cc2.GoV2(func() error {
				metricGroupResp, metricGroupErr := libra.GetMetricGroupDetail(ctx, req.Config.AppId, currentMetric.MetricGroupId)
				if metricGroupErr != nil || metricGroupResp == nil || metricGroupResp.Code != 0 || metricGroupResp.Data == nil {
					return metricGroupErr
				}

				// 过滤出config中配置的指标
				metricGroup := &MetricGroupDetail{
					MetricGroupDetailData: *metricGroupResp.Data,
				}
				metricGroup.MetricGroupDetailData.Dimensions = nil // 指标组维度信息置为空
				metricGroup.MetricGroupDetailData.Metrics, _ = funk.Filter(metricGroup.MetricGroupDetailData.Metrics, func(metric libra.Metric) bool {
					return funk.Contains(currentMetric.MetricIdList, metric.ID)
				}).([]libra.Metric)
				mu.Lock()
				flightInfo.MetricGroups = append(flightInfo.MetricGroups, metricGroup)
				mu.Unlock()
				return nil
			})
		}
		_err = cc2.WaitV2()
		if _err != nil {
			logs.CtxError(ctx, "[Flight Analysis] GetMetricGroupDetail failed, err=%v", _err)
			return nil, _err
		}

		// 5. 查询实验指标
		// 查询日期选择min(当天，实验结束日期) - 1天
		flightEndTime, _err := time.Parse(consts.Fmt_DateTime, flightInfo.EndTime)
		if _err != nil {
			logs.CtxError(ctx, "[Flight Analysis] Parse flight end time failed, err=%v", _err)
			return nil, _err
		}
		currentTime := time.Now()
		if currentTime.After(flightEndTime) {
			currentTime = flightEndTime
		}
		date := currentTime.AddDate(0, 0, -1).Format(consts.Fmt_date) // T-1天，格式为yyyyMMdd

		// 并发查询指标数据
		cc3 := co.NewConcurrent(ctx)
		for _, metricGroup := range coreMetricGroups {
			currentMetricGroup := metricGroup

			cc3.GoV2(func() error {
				// 生成sql
				sql, sqlErr := generateSQL(ctx, date, flightInfo.ID, currentMetricGroup)
				if sqlErr != nil {
					logs.CtxError(ctx, "[Flight Analysis] Generate SQL failed, err=%v", sqlErr)
					return sqlErr
				}
				// tqs查询
				tqsResp, tqsErr := tqs.QuerySync(ctx, sql, false)
				if tqsErr != nil || tqsResp == nil || len(tqsResp.Result) == 0 {
					logs.CtxError(ctx, "[Flight Analysis] QuerySync failed, err=%v", tqsErr)
					return tqsErr
				}
				// 上传结果到TOS
				objKey, uploadErr := tos.UploadRecordsAsCSV(ctx, tqsResp.Result, nil)
				if uploadErr != nil {
					logs.CtxError(ctx, "[Flight Analysis] UploadRecordsAsCSV failed, err=%v", uploadErr)
					return uploadErr
				}

				flightMetricGroup, ok := funk.Find(flightInfo.MetricGroups, func(metricGroup *MetricGroupDetail) bool {
					return metricGroup.MetricGroupDetailData.ID == currentMetricGroup.MetricGroupId
				}).(*MetricGroupDetail)
				if ok {
					// 保存指标组查询结果在TOS中的key
					flightMetricGroup.ObjKey = objKey
				}

				return nil
			})
		}
		_err = cc3.WaitV2()
		if _err != nil {
			logs.CtxError(ctx, "[Flight Analysis] GetMetricGroupDetail failed, err=%v", _err)
			return nil, _err
		}

		// 6. 格式化flightInfo的数据
		flightInfoJson, _err := json.Marshal(flightInfo)
		if _err != nil {
			logs.CtxError(ctx, "[Flight Analysis] Marshal FlightAnalysisInfo failed, err=%v", _err)
			return nil, _err
		}

		// 7. 将flightInfo保存到syncMap
		syncMap.Set(consts.SyncMapFlightInfoKey, flightInfo)

		// 8. 获取历史消息
		historyMessages, _err := ai_analysis_service.GetHistoryMessage(ctx, sessionId)
		if _err != nil {
			logs.CtxError(ctx, "[Flight Analysis] get history messages failed, err=%v", _err)
			return nil, _err
		}
		msgs := append(historyMessages, schema.UserMessage(input))

		return map[string]any{
			"chat_history": msgs,
			"flight_info":  string(flightInfoJson),
			"date":         time.Now().Format(consts.Fmt_Date),
		}, nil
	})

	flightAnalysisTemplate, err := prompthub.NewPromptHub(ctx, &prompthub.Config{
		Key:          "ecom.flow_efficiency.flight_analysis",
		FornaxClient: fornaxClient,
	})
	if err != nil {
		logs.CtxError(ctx, "[Flight Analysis] Init prompt service failed, prompt_key=%s, err=%v", "ecom.flow_efficiency.flight_analysis", err)
		return "", err
	}

	flightAnalysisTemp := float32(0.3)
	flightAnalysisMaxToken := int(4096)
	flightAnalysisModelKey := "deepseek-v3.1"
	if aiConfig.Model != nil && aiConfig.Model["flight_analysis_model"] != "" {
		flightAnalysisModelKey = aiConfig.Model["flight_analysis_model"]
	}
	flightAnalysisModel, err := ark.NewChatModel(ctx, &ark.ChatModelConfig{
		APIKey:      arkConfig.ApiKey,
		Model:       arkConfig.Endpoint[flightAnalysisModelKey],
		Temperature: &flightAnalysisTemp,
		MaxTokens:   &flightAnalysisMaxToken,
		Thinking: &model.Thinking{
			Type: model.ThinkingTypeEnabled, // 启用思考
		},
		ResponseFormat: &ark.ResponseFormat{
			Type: model.ResponseFormatJsonObject,
		},
	})
	if err != nil {
		logs.CtxError(ctx, "[Flight Analysis] Init model failed, model_key=%s, err=%v", flightAnalysisModelKey, err)
		return "", err
	}

	runScriptTool := tools.NewRunScriptTool()
	flightAnalysisReactAgent, err := react.NewAgent(ctx, &react.AgentConfig{
		ToolCallingModel: flightAnalysisModel,
		MaxStep:          50,
		ToolsConfig: compose.ToolsNodeConfig{
			Tools: []tool.BaseTool{
				runScriptTool,
			},
			UnknownToolsHandler: tools.UnknownToolsHandler,
		},
	})
	if err != nil {
		logs.CtxError(ctx, "[Flight Analysis] Init flight analysis react agent failed, err=%v", err)
		return "", err
	}

	// 构建Lambda节点，在Lambda中调用React Agent，获取React Agent的过程消息保存到State中，并将最后一条消息传给下一个节点
	flightAnalysisLambda := buildReActLambda(flightAnalysisReactAgent)

	// 校验节点
	validateLambda := buildValidateLambda[FlightAnalysisOutput]()

	// 后置处理节点：更新任务、存储策略配置、存储历史消息
	endProcessLambda := compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (*schema.Message, error) {
		if len(input) == 0 {
			logs.CtxError(ctx, "[Flight Analysis] endProcessLambda input message empty")
			return nil, fmt.Errorf("endProcessLambda input message empty")
		}

		lastMsg := input[len(input)-1]
		// 有时候模型会在ReasoningContent中输出，需要兼容该场景
		if lastMsg.Content == "" {
			lastMsg.Content = lastMsg.ReasoningContent
		}
		outputType, errorOutput, flightAnalysisOutput := validateOutput[FlightAnalysisOutput](lastMsg.Content)
		if outputType == OutputValidateFailed {
			// 消息格式有误，直接报错
			logs.CtxError(ctx, "[Flight Analysis] validate output message failed, output=%s", lastMsg.Content)
			return nil, fmt.Errorf("validate output message failed")
		} else if outputType == OutputErrorMsg && errorOutput != nil {
			// 输出错误消息
			logs.CtxWarn(ctx, "[Flight Analysis] Flight Analysis output error message, err message=%s", errorOutput.ErrorMessage)

			// 更新任务状态为失败
			if _err := d.AIStrategyTaskDao.UpdateFlightAnalysisTask(ctx, taskId, dao.TaskStatusFailed, &errorOutput.ErrorMessage); _err != nil {
				logs.CtxError(ctx, "[Flight Analysis] UpdateFlightAnalysisTask failed, err=%v", _err)
				return nil, _err
			}

			return lastMsg, nil
		} else if outputType == OutputNormalMsg && len(flightAnalysisOutput) > 0 {
			// 输出正常消息
			logs.CtxInfo(ctx, "[Flight Analysis] Flight Analysis output normal, output=%s", lastMsg.Content)

			// 将实验分析结论写入数据库
			flightAnalysisList := make([]*dao.FlightAnalysisConclusion, 0, len(flightAnalysisOutput))
			for _, v := range flightAnalysisOutput {
				flightAnalysisList = append(flightAnalysisList, &dao.FlightAnalysisConclusion{
					StrategyKey:          v.StrategyKey,
					StrategyConfigID:     v.StrategyConfigID,
					FlightID:             v.FlightID,
					VersionID:            v.VersionID,
					DisplayOrder:         v.DisplayOrder,
					FlightConclusion:     v.FlightConclusion,
					ReflectionContent:    v.ReflectionContent,
					FlightAnalysisTaskId: taskId,
				})
			}
			if _err := d.FlightAnalysisDao.BatchCreateFlightAnalysis(ctx, flightAnalysisList); _err != nil {
				logs.CtxError(ctx, "[Flight Analysis] BatchCreateFlightAnalysis failed, err=%v", _err)
				return nil, _err
			}

			// 更新任务状态为成功
			if _err := d.AIStrategyTaskDao.UpdateFlightAnalysisTask(ctx, taskId, dao.TaskStatusSuccess, nil); _err != nil {
				logs.CtxError(ctx, "[Flight Analysis] UpdateFlightAnalysisTask failed, err=%v", _err)
				return nil, _err
			}

			return lastMsg, nil
		}

		// 其余情况直接返回错误
		logs.CtxError(ctx, "[Flight Analysis] Flight Analysis output unknown, output=%s", lastMsg.Content)
		return nil, fmt.Errorf("unknown output type")
	})

	handler := &Handler{
		SessionId: sessionId,
	}

	// 添加节点
	if err = g.AddLambdaNode(PreProcessNodeName, preprocessLambda, compose.WithNodeName(PreProcessNodeName)); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddLambdaNode %s failed, err=%v", PreProcessNodeName, err)
		return "", err
	}
	if err = g.AddLambdaNode(EndProcessNodeName, endProcessLambda, compose.WithNodeName(EndProcessNodeName)); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddLambdaNode %s failed, err=%v", EndProcessNodeName, err)
		return "", err
	}
	if err = g.AddLambdaNode(ValidateNodeName, validateLambda, compose.WithNodeName(ValidateNodeName)); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddLambdaNode %s failed, err=%v", ValidateNodeName, err)
		return "", err
	}
	if err = g.AddChatTemplateNode(FlightAnalysisTemplateNodeName, flightAnalysisTemplate, compose.WithNodeName(FlightAnalysisTemplateNodeName)); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddChatTemplateNode %s failed, err=%v", FlightAnalysisTemplateNodeName, err)
		return "", err
	}
	if err = g.AddLambdaNode(FlightAnalysisReactGraphNodeName, flightAnalysisLambda, compose.WithNodeName(FlightAnalysisReactGraphNodeName), compose.WithStatePreHandler(handler.reActPreHandler()), compose.WithStatePostHandler(handler.reActPostHandler())); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddLambdaNode %s failed, err=%v", FlightAnalysisReactGraphNodeName, err)
		return "", err
	}

	// 校验判断分支
	validateBranch := compose.NewGraphBranch(func(ctx context.Context, input []*schema.Message) (endNode string, err error) {
		if len(input) == 0 {
			return EndProcessNodeName, nil
		}

		return FlightAnalysisReactGraphNodeName, nil
	}, map[string]bool{
		EndProcessNodeName:               true,
		FlightAnalysisReactGraphNodeName: true,
	})

	// 添加边连接众节点
	if err = g.AddEdge(compose.START, PreProcessNodeName); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddEdge %s -> %s failed, err=%v", compose.START, PreProcessNodeName, err)
		return "", err
	}
	if err = g.AddEdge(PreProcessNodeName, FlightAnalysisTemplateNodeName); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddEdge %s -> %s failed, err=%v", PreProcessNodeName, FlightAnalysisTemplateNodeName, err)
		return "", err
	}
	if err = g.AddEdge(FlightAnalysisTemplateNodeName, FlightAnalysisReactGraphNodeName); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddEdge %s -> %s failed, err=%v", FlightAnalysisTemplateNodeName, FlightAnalysisReactGraphNodeName, err)
		return "", err
	}
	if err = g.AddEdge(FlightAnalysisReactGraphNodeName, ValidateNodeName); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddEdge %s -> %s failed, err=%v", FlightAnalysisReactGraphNodeName, ValidateNodeName, err)
		return "", err
	}
	if err = g.AddBranch(ValidateNodeName, validateBranch); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddBranch %s failed, err=%v", ValidateNodeName, err)
		return "", err
	}
	if err = g.AddEdge(EndProcessNodeName, compose.END); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] AddEdge %s -> %s failed, err=%v", EndProcessNodeName, compose.END, err)
		return "", err
	}

	syncMap := utils.NewSyncMap()
	syncMap.Set(consts.SyncMapSessionIdKey, taskId)

	// 注入tag到fornax trace
	ctx = fornax.InjectFornaxTrace(ctx, user, "", sessionId)

	// 注入userInfo到ctx
	ctx = context.WithValue(ctx, consts.CtxUserInfo, user)

	// 注入syncMap到ctx，主要用于在不同Graph中共享数据（Eino不同Graph State不互通）
	ctx = context.WithValue(ctx, consts.CtxSyncMap, syncMap)

	// 编译graph
	r, err := g.Compile(ctx, compose.WithGraphName("flight_analysis"), compose.WithNodeTriggerMode(compose.AnyPredecessor))
	if err != nil {
		logs.CtxError(ctx, "[Flight Analysis] compile graph failed, err=%v", err)
		return "", err
	}

	// 创建实验分析任务
	taskName := fmt.Sprintf("实验分析任务-%s", taskId)
	if req.TaskName != nil {
		taskName = *req.TaskName
	}
	taskInfo := &dao.FlightAnalysisTask{
		TaskId:     taskId,
		FlightId:   req.Config.FlightId,
		AppId:      req.Config.AppId,
		TaskName:   taskName,
		EmployeeId: req.EmployeeId,
		Status:     dao.TaskStatusRunning,
	}
	if err = d.AIStrategyTaskDao.CreateFlightAnalysisTask(ctx, taskInfo); err != nil {
		logs.CtxError(ctx, "[Flight Analysis] create flight analysis task failed, err=%v", err)
		return "", err
	}

	// 以非流式方式执行graph
	query := "基于实验信息、策略配置和实验数据，分析实验和策略的效果，并根据要求输出 JSON 数据。**注意**：JSON 数据不要使用 ```json 包裹。"
	if req.Query != nil {
		query = *req.Query
	}

	output, err = r.Invoke(ctx, query, compose.WithCallbacks(&callback.GlobalHandler{}))
	if err != nil {
		logs.CtxError(ctx, "[Flight Analysis] invoke graph failed, err=%v", err)
		// 更新任务状态为失败
		errorMsg := fmt.Sprintf("实验分析任务失败，err=%s", err.Error())
		if _err := d.AIStrategyTaskDao.UpdateFlightAnalysisTask(ctx, taskId, dao.TaskStatusFailed, &errorMsg); _err != nil {
			logs.CtxError(ctx, "[Flight Analysis] UpdateFlightAnalysisTask failed, err=%v", _err)
			return "", _err
		}
		return "", err
	}

	return output.Content, nil
}
