package ai_strategy_service

import (
	"context"
	"fmt"
	"time"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/byte_rag"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/gopkg/logs/v2"
	"github.com/bytedance/sonic"
)

func (d *AIStrategyService) ImportFlightConclusion(ctx context.Context, req *ai_analysis.ImportFlightConclusionRequest) error {
	// 查询实验分析结果
	flightAnalysisConclusions, err := d.FlightAnalysisDao.BatchQueryFlightAnalysis(ctx, req.FlightAnalysisIds)
	if err != nil {
		logs.CtxError(ctx, "[ImportFlightConclusion] BatchQueryFlightAnalysis err: %v", err)
		return err
	}

	if len(flightAnalysisConclusions) == 0 {
		logs.CtxWarn(ctx, "[ImportFlightConclusion] flightAnalysisConclusions is empty")
		return nil
	}

	cc := co.NewConcurrent(ctx)
	for _, flightAnalysisConclusion := range flightAnalysisConclusions {
		analysisConclusion := flightAnalysisConclusion
		if analysisConclusion == nil {
			continue
		}

		cc.GoV2(func() error {
			// 查询策略详情
			strategyDetail, _err := d.AIStrategyDao.GetStrategyDetailByKey(ctx, analysisConclusion.StrategyKey)
			if _err != nil {
				logs.CtxError(ctx, "[ImportFlightConclusion] GetStrategyDetail err: %v", _err)
				return _err
			}
			if strategyDetail == nil {
				logs.CtxError(ctx, "[ImportFlightConclusion] strategy detail is nil, strategy key: %s", analysisConclusion.StrategyKey)
				return fmt.Errorf("strategy detail is nil, strategy key: %s", analysisConclusion.StrategyKey)
			}

			// 查询策略配置详情
			strategyConfigDetail, _err := d.AIStrategyDao.GetStrategyConfigDetail(ctx, analysisConclusion.StrategyConfigID)
			if _err != nil {
				logs.CtxError(ctx, "[ImportFlightConclusion] GetStrategyConfigDetail err: %v", _err)
				return _err
			}
			if strategyConfigDetail == nil {
				logs.CtxError(ctx, "[ImportFlightConclusion] strategy config detail is nil, strategy config id: %s", analysisConclusion.StrategyConfigID)
				return fmt.Errorf("strategy config detail is nil, strategy config id: %s", analysisConclusion.StrategyConfigID)
			}

			strategyConfigJson, _err := sonic.MarshalString(strategyConfigDetail.Config)
			if _err != nil {
				logs.CtxError(ctx, "[ImportFlightConclusion] marshal strategy config detail failed, err: %v", _err)
				return _err
			}

			// 导入到ByteRAG
			byteRagData := map[string]any{
				"flight_conclusion":    analysisConclusion.FlightConclusion,  // 实验结论
				"strategy_reflection":  analysisConclusion.ReflectionContent, // 策略反思
				"strategy_config_desc": strategyConfigDetail.Description,     // 策略配置描述
				"strategy_desc":        strategyDetail.StrategyDesc,          // 策略描述
				"display_order":        analysisConclusion.DisplayOrder,      // 策略配置生效顺序
				"strategy_key":         analysisConclusion.StrategyKey,       // 策略key
				"strategy_config_id":   analysisConclusion.StrategyConfigID,  // 策略配置id
				"strategy_config":      strategyConfigJson,                   // 策略配置json
				"flight_id":            analysisConclusion.FlightID,          // 实验id
				"version_id":           analysisConclusion.VersionID,         // 版本id
				"last_update_time":     time.Now().Unix(),                    // 最后更新时间
			}
			if len(strategyDetail.Tags) > 0 {
				byteRagData["tags"] = strategyDetail.Tags
			}
			param := &byte_rag.DocumentParam{
				Key:  byte_rag.FlightAnalysisConclusion,
				Data: byteRagData,
			}

			// TODO：使用MQ接受文档导入状态
			docMeta, _err := byte_rag.DoDocumentAction(ctx, byte_rag.KnowledgeOpCreate, param)
			if _err != nil {
				logs.CtxError(ctx, "[ImportFlightConclusion] DoDocumentAction err: %v", _err)
				return _err
			}
			if docMeta == nil || docMeta.DocId == nil || *docMeta.DocId == "" {
				logs.CtxError(ctx, "[ImportFlightConclusion] DoDocumentAction failed, docMeta is nil or docId is empty")
				return fmt.Errorf("create byte_rag document failed, docMeta is nil or docId is empty")
			}

			// 将docId关联到flight_analysis_conclusion表中
			if _err = d.FlightAnalysisDao.UpdateDocID(ctx, analysisConclusion.ID, *docMeta.DocId); _err != nil {
				logs.CtxError(ctx, "[ImportFlightConclusion] UpdateDocID err: %v", _err)
				return _err
			}

			return nil
		})
	}

	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[ImportFlightConclusion] Concurrent import flight analysis conclusions err: %v", err)
		return err
	}

	return nil
}
