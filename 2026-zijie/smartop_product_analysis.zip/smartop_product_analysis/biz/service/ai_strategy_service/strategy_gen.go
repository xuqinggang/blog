package ai_strategy_service

import (
	"context"
	"fmt"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/callback"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"
	ai_strategy_tools "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_strategy_service/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/lark"
	"code.byted.org/flow/eino-byted-ext/components/prompt/prompthub"
	"code.byted.org/gopkg/logs/v2"
	"github.com/bytedance/sonic"
	"github.com/cloudwego/eino-ext/components/model/ark"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"
	"github.com/cloudwego/eino/schema"
	"github.com/pborman/uuid"
	"github.com/volcengine/volcengine-go-sdk/service/arkruntime/model"
	// eino_utils "github.com/cloudwego/eino/components/tool/utils"
)

type StrategyConfig struct {
	StrategyConfigId string                               `json:"strategy_config_id" jsonschema:"required,description=策略配置ID"`
	Config           ai_strategy_tools.StrategyItemConfig `json:"config" jsonschema:"required,description=策略配置参数，key为维度名，value为维度取值"`
	Description      string                               `json:"description" jsonschema:"required,description=策略配置的描述"`
	Score            string                               `json:"score" jsonschema:"required,description=策略配置的综合评估得分，1分为满分，用于横向对比所有候选策略配置"`
	Reason           string                               `json:"reason" jsonschema:"required,description=详细解释选取该策略配置的原因，需要解释综合评估得分的原因，用于解释该策略配置的综合评估逻辑"`
	EvaluateResult   [][]any                              `json:"evaluate_result" jsonschema:"required,description=策略配置的评估结果，是一个二维数组，需要包含指标名和指标数值，指标名和指标数值需要与评估的sql执行结果一致"`
}

type StrategyOutput struct {
	StrategyKey        string           `json:"strategy_key" jsonschema:"required,description=策略的唯一标识"`        // 策略的唯一标识
	StrategyConfigList []StrategyConfig `json:"strategy_config_list" jsonschema:"required,description=策略配置列表"` // 策略配置列表
}

func (d *AIStrategyService) AIStrategyGen(ctx context.Context, req *ai_analysis.AIStrategyGenRequest) (string, error) {
	// 获取用户信息，PS：agw流式协议转换之后无法从ctx中获取用户信息
	user, err := utils.GetEcopUserByEmployeeId(ctx, req.EmployeeId)
	if err != nil {
		logs.CtxError(ctx, "[Strategy Gen] GetEcopUserByEmployeeId failed, err=%v", err)
		return "", err
	}

	// 获取fornax client
	fornaxClient := fornax.GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[Strategy Gen] GetFornaxClient failed")
		return "", fmt.Errorf("get fornax client failed")
	}

	// 获取方舟配置
	arkConfig, err := biz_info.GetArkConfig(ctx)
	if err != nil || arkConfig == nil {
		logs.CtxError(ctx, "[Strategy Gen] GetArkConfig failed, err=%v", err)
		return "", err
	}

	// 获取ai配置
	aiConfig, err := biz_info.GetArtificialIntelligenceConfig(ctx)
	if err != nil || aiConfig == nil {
		logs.CtxError(ctx, "[Strategy Gen] GetArtificialIntelligenceConfig failed, err=%v", err)
		return "", err
	}

	// 获取会话id
	sessionId, err := d.AIAnalysisService.GetSessionId(ctx, req.EmployeeId, req.SessionId, nil)
	if err != nil || sessionId == "" {
		logs.CtxError(ctx, "[Strategy Gen] get session id failed, err=%v", err)
		return "", err
	}

	g := compose.NewGraph[string, *schema.Message](compose.WithGenLocalState(func(ctx context.Context) *State {
		return &State{}
	}))
	taskId := uuid.NewUUID().String() // 本次任务ID
	var strategyDesc string
	var output *schema.Message

	// 关闭session
	defer func() {
		_err := tools.CloseSession(ctx, taskId)
		if _err != nil {
			logs.CtxWarn(ctx, "[Strategy Gen] close session failed, session_id=%s, err=%v", taskId, _err)
		}
	}()

	// 发送飞书通知
	defer func() {
		if user.Email == nil || *user.Email == "" {
			return
		}

		// 根据是否有错误/输出内容来设置策略配置文案
		var strategyConfig string
		if err != nil {
			strategyConfig = fmt.Sprintf("invoke failed: %s", err.Error())
		} else if output != nil {
			strategyConfig = output.Content
		}

		if _err := lark_service.SendCardMsg(ctx, *user.Email, &lark_service.CardData{
			TemplateId: StrategyGenCardTemplateID,
			TemplateVariable: map[string]interface{}{
				"session_id":      sessionId,
				"strategy_key":    req.StrategyKey,
				"strategy_desc":   strategyDesc,
				"strategy_config": strategyConfig,
			},
		}); _err != nil {
			logs.CtxError(ctx, "[Strategy Gen] SendCardMsg failed, err=%v", _err)
		}
	}()

	preProcessLambda := compose.InvokableLambda(func(ctx context.Context, input string) (map[string]any, error) {
		syncMap, ok := ctx.Value(consts.CtxSyncMap).(*utils.SyncMap)
		if !ok || syncMap == nil {
			return nil, fmt.Errorf("sync map not found in context")
		}

		// 1. 获取策略详情
		strategyDetail, _err := d.AIStrategyDao.GetStrategyDetailByKey(ctx, req.StrategyKey)
		if _err != nil || strategyDetail == nil {
			logs.CtxError(ctx, "[Strategy Gen] GetStrategyDetail failed, err=%v", _err)
			return nil, _err
		}
		strategyDesc = strategyDetail.StrategyDesc

		// 将strategyDetail存到syncMap中
		syncMap.Set(consts.SyncMapStrategyDetailKey, strategyDetail)

		strategyDetailJson, _err := sonic.MarshalString(strategyDetail)
		if _err != nil {
			logs.CtxError(ctx, "[Strategy Gen] Marshal strategyDetail failed, err=%v", _err)
			return nil, _err
		}

		// 2. 获取策略信息
		var strategyInfo string
		if strategyDetail.ReferenceDoc != nil && *strategyDetail.ReferenceDoc != "" {
			var checkDocResp *lark.CheckDocPermissionResponseData
			checkDocResp, _err = d.LarkService.CheckDocPermission(ctx, *strategyDetail.ReferenceDoc, &req.EmployeeId)
			if _err != nil {
				logs.CtxError(ctx, "[Strategy Gen] CheckDocPermission failed, err=%v", _err)
				return nil, _err
			}
			if checkDocResp.HasPermission {
				// 获取文档内容
				var docContent string
				docContent, _err = d.LarkService.GetDocContent(ctx, *strategyDetail.ReferenceDoc, &req.EmployeeId)
				if _err != nil {
					logs.CtxError(ctx, "[Strategy Gen] GetDocContent failed, err=%v", _err)
					return nil, _err
				}
				strategyInfo += fmt.Sprintf("%s\n\n", docContent)
			}
		}
		if strategyDetail.ReferenceInfo != nil && *strategyDetail.ReferenceInfo != "" {
			strategyInfo += fmt.Sprintf("%s\n\n", *strategyDetail.ReferenceInfo)
		}

		// 3. 获取历史的策略配置投放情况（后续长期记忆召回使用）
		strategyConfigList, _err := d.AIStrategyDao.GetEnabledStrategyConfig(ctx, req.StrategyKey)
		if _err != nil {
			logs.CtxError(ctx, "[Strategy Gen] GetEnabledStrategyConfig failed, err=%v", _err)
			return nil, _err
		}

		var strategyConfigListJson string
		if len(strategyConfigList) > 0 {
			// 将strategyConfigList存到syncMap中
			syncMap.Set(consts.SyncMapStrategyConfigListKey, strategyConfigList)
			strategyConfigListJson, _err = sonic.MarshalString(strategyConfigList)
			if _err != nil {
				logs.CtxError(ctx, "[Strategy Gen] Marshal strategyConfigList failed, err=%v", _err)
				return nil, _err
			}
		}

		// 获取历史消息
		historyMessages, _err := ai_analysis_service.GetHistoryMessage(ctx, sessionId)
		if _err != nil {
			logs.CtxError(ctx, "[Strategy Gen] get history messages failed, err=%v", _err)
			return nil, _err
		}
		msgs := append(historyMessages, schema.UserMessage(input))

		return map[string]any{
			"chat_history":               msgs,
			"strategy_info":              strategyInfo,
			"strategy_detail":            strategyDetailJson,
			"strategy_config":            strategyConfigListJson,
			"max_candidate_strategy_cnt": 20, // 最多生成20个候选策略配置
			"date":                       time.Now().Format(consts.Fmt_Date),
		}, nil
	})

	strategyGenTemplate, err := prompthub.NewPromptHub(ctx, &prompthub.Config{
		Key:          "ecom.flow_efficiency.strategy_gen",
		FornaxClient: fornaxClient,
	})
	if err != nil {
		logs.CtxError(ctx, "[Strategy Gen] Init prompt service failed, prompt_key=%s, err=%v", "ecom.flow_efficiency.strategy_gen", err)
		return "", err
	}

	// 约束大模型输出的格式
	// responseFormatType := model.ResponseFormatJsonObject // 默认使用json_object格式
	// var responseJsonSchema *model.ResponseFormatJSONSchemaJSONSchemaParam
	// outputParams, paramsErr := eino_utils.GoStruct2ParamsOneOf[StrategyOutput]()
	// if paramsErr != nil || outputParams == nil {
	// 	// json schema解析失败
	// 	logs.CtxWarn(ctx, "[Strategy Gen] GoStruct2ParamsOneOf failed, err=%v", paramsErr)
	// } else {
	// 	jsonSchema, schemaErr := outputParams.ToJSONSchema() // 转化成jsonSchema
	// 	if schemaErr != nil || jsonSchema == nil {
	// 		// json schema解析失败
	// 		logs.CtxWarn(ctx, "[Strategy Gen] ToJSONSchema failed, err=%v", schemaErr)
	// 	} else {
	// 		responseFormatType = model.ResponseFormatJSONSchema
	// 		responseJsonSchema = &model.ResponseFormatJSONSchemaJSONSchemaParam{
	// 			Name:        "strategy_output",
	// 			Description: "策略输出",
	// 			Strict:      true,
	// 			Schema:      jsonSchema,
	// 		}
	// 	}
	// }

	strategyTemp := float32(0.3)
	strategyMaxToken := int(4096)
	strategyModelKey := "deepseek-v3.1"
	if aiConfig.Model != nil && aiConfig.Model["strategy_gen_model"] != "" {
		strategyModelKey = aiConfig.Model["strategy_gen_model"]
	}
	strategyGenModel, err := ark.NewChatModel(ctx, &ark.ChatModelConfig{
		APIKey:      arkConfig.ApiKey,
		Model:       arkConfig.Endpoint[strategyModelKey],
		Temperature: &strategyTemp,
		MaxTokens:   &strategyMaxToken,
		Thinking: &model.Thinking{
			Type: model.ThinkingTypeEnabled, // 启用思考
		},
		// TODO：结构化输出暂时不使用：https://cloud.bytedance.net/docs/ark/docs/664afad9e16ff302cb5c0706/682bfcaebcd01f0508f0cb72?source=search&from=search_bytecloud&x-resource-account=public&x-bc-region-id=bytedance
		ResponseFormat: &ark.ResponseFormat{
			Type: model.ResponseFormatJsonObject,
			// JSONSchema: responseJsonSchema,
		},
	})
	if err != nil {
		logs.CtxError(ctx, "[Strategy Gen] Init strategy model failed, model_key=%s, err=%v", strategyModelKey, err)
		return "", err
	}

	// 工具集合
	runScriptTool := tools.NewRunScriptTool()
	queryHiveDDLTool := tools.NewQueryHiveDDLTool()
	queryHivePartitionTool := tools.NewQueryHivePartitionsTool()
	updateCandidateStrategyTool := ai_strategy_tools.NewUpdateCandidateStrategyTool()
	evaluateStrategyTool := ai_strategy_tools.NewEvaluateStrategyTool()
	retrieveHistoryTool := ai_strategy_tools.NewRetrieveHistoryTool()

	strategyReactAgent, err := react.NewAgent(ctx, &react.AgentConfig{
		ToolCallingModel: strategyGenModel,
		MaxStep:          50,
		ToolsConfig: compose.ToolsNodeConfig{
			Tools: []tool.BaseTool{
				runScriptTool,
				queryHiveDDLTool,
				queryHivePartitionTool,
				updateCandidateStrategyTool,
				evaluateStrategyTool,
				retrieveHistoryTool,
			},
			UnknownToolsHandler: tools.UnknownToolsHandler,
			// ToolCallMiddlewares: []compose.ToolMiddleware{{
			// 	Invokable: remindToolMiddleware,
			// }},
		},
	})
	if err != nil {
		logs.CtxError(ctx, "[Strategy Gen] Init strategy react agent failed, err=%v", err)
		return "", err
	}

	// 构建Lambda节点，在Lambda中调用React Agent，获取React Agent的过程消息保存到State中，并将最后一条消息传给下一个节点
	strategyGenLambda := buildReActLambda(strategyReactAgent)

	// 校验节点
	validateLambda := buildValidateLambda[*StrategyOutput]()

	// 后置处理节点：更新任务、存储策略配置、存储历史消息
	endProcessLambda := compose.InvokableLambda(func(ctx context.Context, input []*schema.Message) (*schema.Message, error) {
		if len(input) == 0 {
			logs.CtxError(ctx, "[Strategy Gen] endProcessLambda input message empty")
			return nil, fmt.Errorf("endProcessLambda input message empty")
		}

		lastMsg := input[len(input)-1]
		// 有时候模型会在ReasoningContent中输出，需要兼容该场景
		if lastMsg.Content == "" {
			lastMsg.Content = lastMsg.ReasoningContent
		}
		outputType, errorOutput, strategyOutput := validateOutput[*StrategyOutput](lastMsg.Content)
		if outputType == OutputValidateFailed {
			// 消息格式有误，直接报错
			logs.CtxError(ctx, "[Strategy Gen] validate output message failed, output=%s", lastMsg.Content)
			return nil, fmt.Errorf("validate output message failed")
		} else if outputType == OutputErrorMsg && errorOutput != nil {
			// 输出错误消息
			logs.CtxWarn(ctx, "[Strategy Gen] Strategy Gen output error message, err message=%s", errorOutput.ErrorMessage)

			// 更新任务状态为失败
			if _err := d.AIStrategyTaskDao.UpdateStrategyGenTask(ctx, taskId, dao.TaskStatusFailed, &errorOutput.ErrorMessage); _err != nil {
				logs.CtxError(ctx, "[Strategy Gen] UpdateStrategyGenTask failed, err=%v", _err)
				return nil, _err
			}

			return lastMsg, nil
		} else if outputType == OutputNormalMsg && strategyOutput != nil {
			// 输出正常消息
			logs.CtxInfo(ctx, "[Strategy Gen] Strategy Gen output normal, output=%s", lastMsg.Content)

			// 将策略配置写入数据库
			strategyConfigList := make([]*dao.StrategyConfig, 0, len(strategyOutput.StrategyConfigList))
			for _, strategyConfig := range strategyOutput.StrategyConfigList {
				strategyConfigList = append(strategyConfigList, &dao.StrategyConfig{
					StrategyConfigId:  strategyConfig.StrategyConfigId,
					StrategyKey:       req.StrategyKey,
					Description:       strategyConfig.Description,
					Score:             strategyConfig.Score,
					Reason:            strategyConfig.Reason,
					Config:            strategyConfig.Config,
					EvaluateResult:    strategyConfig.EvaluateResult,
					StrategyGenTaskId: taskId,
				})
			}
			if _err := d.AIStrategyDao.BatchCreateStrategyConfig(ctx, strategyConfigList); _err != nil {
				logs.CtxError(ctx, "[Strategy Gen] BatchCreateStrategyConfig failed, err=%v", _err)
				return nil, _err
			}

			// 更新任务状态为成功
			if _err := d.AIStrategyTaskDao.UpdateStrategyGenTask(ctx, taskId, dao.TaskStatusSuccess, nil); _err != nil {
				logs.CtxError(ctx, "[Strategy Gen] UpdateStrategyGenTask failed, err=%v", _err)
				return nil, _err
			}

			return lastMsg, nil
		}

		// 其余情况直接返回错误
		logs.CtxError(ctx, "[Strategy Gen] Strategy Gen output unknown, output=%s", lastMsg.Content)
		return nil, fmt.Errorf("unknown output type")
	})

	handler := &Handler{
		SessionId: sessionId,
	}

	// 添加节点
	if err = g.AddLambdaNode(PreProcessNodeName, preProcessLambda, compose.WithNodeName(PreProcessNodeName)); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddLambdaNode %s failed, err=%v", PreProcessNodeName, err)
		return "", err
	}
	if err = g.AddLambdaNode(EndProcessNodeName, endProcessLambda, compose.WithNodeName(EndProcessNodeName)); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddLambdaNode %s failed, err=%v", EndProcessNodeName, err)
		return "", err
	}
	if err = g.AddLambdaNode(ValidateNodeName, validateLambda, compose.WithNodeName(ValidateNodeName)); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddLambdaNode %s failed, err=%v", ValidateNodeName, err)
		return "", err
	}
	if err = g.AddChatTemplateNode(StrategyGenTemplateNodeName, strategyGenTemplate, compose.WithNodeName(StrategyGenTemplateNodeName)); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddChatTemplateNode %s failed, err=%v", StrategyGenTemplateNodeName, err)
		return "", err
	}
	if err = g.AddLambdaNode(StrategyReactGraphNodeName, strategyGenLambda, compose.WithNodeName(StrategyReactGraphNodeName), compose.WithStatePreHandler(handler.reActPreHandler()), compose.WithStatePostHandler(handler.reActPostHandler())); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddLambdaNode %s failed, err=%v", StrategyReactGraphNodeName, err)
		return "", err
	}

	// 校验判断分支
	validateBranch := compose.NewGraphBranch(func(ctx context.Context, input []*schema.Message) (endNode string, err error) {
		if len(input) == 0 {
			logs.CtxError(ctx, "[Strategy Gen] validateBranch input message empty")
			err = fmt.Errorf("validateBranch input message empty")
			return
		}

		lastMsg := input[len(input)-1]
		if lastMsg.Role == schema.User && lastMsg.Content == InValidMsg {
			return StrategyReactGraphNodeName, nil
		}

		return EndProcessNodeName, nil
	}, map[string]bool{
		EndProcessNodeName:         true,
		StrategyReactGraphNodeName: true,
	})

	// 添加边连接众节点
	if err = g.AddEdge(compose.START, PreProcessNodeName); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddEdge %s -> %s failed, err=%v", compose.START, PreProcessNodeName, err)
		return "", err
	}
	if err = g.AddEdge(PreProcessNodeName, StrategyGenTemplateNodeName); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddEdge %s -> %s failed, err=%v", PreProcessNodeName, StrategyGenTemplateNodeName, err)
		return "", err
	}
	if err = g.AddEdge(StrategyGenTemplateNodeName, StrategyReactGraphNodeName); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddEdge %s -> %s failed, err=%v", StrategyGenTemplateNodeName, StrategyReactGraphNodeName, err)
		return "", err
	}
	if err = g.AddEdge(StrategyReactGraphNodeName, ValidateNodeName); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddEdge %s -> %s failed, err=%v", StrategyReactGraphNodeName, ValidateNodeName, err)
		return "", err
	}
	if err = g.AddBranch(ValidateNodeName, validateBranch); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddBranch %s failed, err=%v", ValidateNodeName, err)
		return "", err
	}
	if err = g.AddEdge(EndProcessNodeName, compose.END); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] AddEdge %s -> %s failed, err=%v", EndProcessNodeName, compose.END, err)
		return "", err
	}

	syncMap := utils.NewSyncMap()
	syncMap.Set(consts.SyncMapSessionIdKey, taskId)

	// 注入tag到fornax trace
	ctx = fornax.InjectFornaxTrace(ctx, user, "", sessionId)

	// 注入userInfo到ctx
	ctx = context.WithValue(ctx, consts.CtxUserInfo, user)

	// 注入syncMap到ctx，主要用于在不同Graph中共享数据（Eino不同Graph State不互通）
	ctx = context.WithValue(ctx, consts.CtxSyncMap, syncMap)

	// 编译graph
	r, err := g.Compile(ctx, compose.WithGraphName("ai_strategy_gen"), compose.WithNodeTriggerMode(compose.AnyPredecessor))
	if err != nil {
		logs.CtxError(ctx, "[Strategy Gen] compile graph failed, err=%v", err)
		return "", err
	}

	// 创建策略生成任务
	taskName := fmt.Sprintf("策略生成任务-%s", taskId)
	if req.TaskName != nil {
		taskName = *req.TaskName
	}
	taskInfo := &dao.StrategyGenTask{
		TaskId:      taskId,
		StrategyKey: req.StrategyKey,
		TaskName:    taskName,
		EmployeeId:  req.EmployeeId,
		Status:      dao.TaskStatusRunning,
	}
	if err = d.AIStrategyTaskDao.CreateStrategyGenTask(ctx, taskInfo); err != nil {
		logs.CtxError(ctx, "[Strategy Gen] create strategy gen task failed, err=%v", err)
		return "", err
	}

	// 以非流式方式执行graph
	query := "基于策略详情、策略相关资料、历史策略实验结论和策略反思，挖掘出最具潜力的策略配置，并根据要求输出 JSON 数据。**注意**：JSON 数据不要使用 ```json 包裹。"
	if req.Query != nil {
		query = *req.Query
	}

	output, err = r.Invoke(ctx, query, compose.WithCallbacks(&callback.GlobalHandler{}))
	if err != nil {
		logs.CtxError(ctx, "[Strategy Gen] invoke graph failed, err=%v", err)
		// 更新任务状态为失败
		errorMsg := fmt.Sprintf("策略生成任务失败，err=%s", err.Error())
		if _err := d.AIStrategyTaskDao.UpdateStrategyGenTask(ctx, taskId, dao.TaskStatusFailed, &errorMsg); _err != nil {
			logs.CtxError(ctx, "[Strategy Gen] UpdateStrategyGenTask failed, err=%v", _err)
			return "", _err
		}
		return "", err
	}

	return output.Content, nil
}
