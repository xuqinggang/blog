package ai_strategy_service

import (
	"context"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/schema"
	"github.com/thoas/go-funk"
)

type Handler struct {
	SessionId string
}

func (h *Handler) reActPreHandler() compose.StatePreHandler[[]*schema.Message, *State] {
	return func(ctx context.Context, input []*schema.Message, state *State) ([]*schema.Message, error) {
		if len(input) == 0 {
			return nil, fmt.Errorf("reAct agent input message empty")
		}
		state.Msgs = append(state.Msgs, input...)

		// 保存过程消息（去除系统消息）
		contextMsgs, ok := funk.Filter(input, func(msg *schema.Message) bool {
			return msg.Role != schema.System
		}).([]*schema.Message)
		if !ok || len(contextMsgs) == 0 {
			return nil, fmt.Errorf("reAct agent input context message is empty")
		}
		if err := ai_analysis_service.BatchCreateContextMessage(ctx, h.SessionId, contextMsgs); err != nil {
			return nil, err
		}

		return state.Msgs, nil
	}
}

func (h *Handler) reActPostHandler() compose.StatePostHandler[[]*schema.Message, *State] {
	return func(ctx context.Context, output []*schema.Message, state *State) ([]*schema.Message, error) {
		if len(output) == 0 {
			return nil, fmt.Errorf("reAct agent output message empty")
		}
		state.Msgs = append(state.Msgs, output...)

		// 保存过程消息（去除系统消息）
		contextMsgs, ok := funk.Filter(output, func(msg *schema.Message) bool {
			return msg.Role != schema.System
		}).([]*schema.Message)
		if !ok || len(contextMsgs) == 0 {
			return nil, fmt.Errorf("reAct agent output context message is empty")
		}
		if err := ai_analysis_service.BatchCreateContextMessage(ctx, h.SessionId, contextMsgs); err != nil {
			return nil, err
		}

		return state.Msgs, nil
	}
}
