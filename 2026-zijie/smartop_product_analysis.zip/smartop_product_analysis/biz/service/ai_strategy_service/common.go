package ai_strategy_service

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"github.com/cloudwego/eino/schema"
)

const (
	PreProcessNodeName               = "pre_process"
	EndProcessNodeName               = "end_process"
	ValidateNodeName                 = "validate"
	StrategyGenTemplateNodeName      = "strategy_gen_template"
	StrategyReactGraphNodeName       = "strategy_gen_react_graph"
	FlightAnalysisTemplateNodeName   = "flight_analysis_template"
	FlightAnalysisReactGraphNodeName = "flight_analysis_react_graph"
)

// 消息卡片ID
const (
	StrategyGenCardTemplateID    = "AAqhZqCPL9dKu"
	FlightAnalysisCardTemplateID = "AAqXFnn7d7ovJ"
)

type State struct {
	Msgs []*schema.Message
}

type ErrorOutput struct {
	ErrorMessage string `json:"error_message"`
}

type AIStrategyService struct {
	LarkService       lark_service.ILarkService
	AIAnalysisService ai_analysis_service.IAIAnalysisService
	AIStrategyDao     dao.IAIStrategyDao
	AIStrategyTaskDao dao.IAIStrategyTaskDao
	FlightAnalysisDao dao.IFlightAnalysisDao
}

type IAIStrategyService interface {
	AIStrategyGen(ctx context.Context, req *ai_analysis.AIStrategyGenRequest) (string, error)
	FlightAnalysis(ctx context.Context, req *ai_analysis.FlightAnalysisRequest) (string, error)
	CreateStrategy(ctx context.Context, req *ai_analysis.CreateStrategyRequest) error
	UpdateStrategy(ctx context.Context, req *ai_analysis.UpdateStrategyRequest) error
	GetStrategyDetail(ctx context.Context, req *ai_analysis.GetStrategyDetailRequest) (*ai_analysis.StrategyDetail, error)
	ImportFlightConclusion(ctx context.Context, req *ai_analysis.ImportFlightConclusionRequest) error
	CreateStrategyConfig(ctx context.Context, req *ai_analysis.CreateStrategyConfigRequest) error
	CreateStrategyConfigFlightRelation(ctx context.Context, req *ai_analysis.CreateStrategyConfigFlightRelationRequest) error
	RejectStrategyConfig(ctx context.Context, req *ai_analysis.RejectStrategyConfigRequest) error
}
