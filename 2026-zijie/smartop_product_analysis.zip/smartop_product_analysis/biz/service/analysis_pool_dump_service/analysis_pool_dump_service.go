package analysis_pool_dump_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/dorado_task_tool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dorado_task"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"errors"
	"time"
)

type IAnalysisPoolDumpService interface {
	SubmitMatchingBrainDumpTask(ctx context.Context, params map[string]interface{}, poolID string) error
	InitPoolDumpStatus(ctx context.Context, req *dao.AnalysisPoolDumpStatus) (err error)
	CheckOSDumpStatus(ctx context.Context) error
	SubmitDoradoTask(ctx context.Context) error
	UpdateDoradoTaskStatus(ctx context.Context, req *dorado_task.GetDoradoTaskRunningCallBackRequest) error
}

type AnalysisPoolDumpService struct {
	PoolDumpStatusDao dao.IPoolDumpStatusDao
}

var GetProdIDsApiPath = "7430710249558000677"
var MatchingBrainSource = "matching_brain"

func (a *AnalysisPoolDumpService) InitPoolDumpStatus(ctx context.Context, req *dao.AnalysisPoolDumpStatus) (err error) {
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[InitPoolDumpStatus]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return errors.New("获取数据库的事务失败")
	}
	// 创建货盘
	err = a.PoolDumpStatusDao.InitPoolDumpStatus(ctx, tx, req)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "[InitPoolDumpStatus]调用货盘Dump sql失败，err=%v+", err)
		return err
	}
	// 提交事务
	tx.Commit()
	return nil
}

func (a *AnalysisPoolDumpService) SubmitMatchingBrainDumpTask(ctx context.Context, params map[string]interface{}, poolID string) error {
	updateTime := convert.ToString(time.Now().Unix())
	taskId, err := base_struct_condition.QueryWithParamsDump(ctx, params, GetProdIDsApiPath, MatchingBrainSource, poolID+"_"+updateTime+"_csv.gz")
	if err != nil {
		return err
	}

	err = a.InitPoolDumpStatus(ctx, &dao.AnalysisPoolDumpStatus{
		PoolID:       poolID,
		PoolSource:   MatchingBrainSource,
		OSDumpTaskID: taskId,
		OSDumpTime:   updateTime,
	})
	if err != nil {
		return err
	}
	return nil
}

func (a *AnalysisPoolDumpService) CheckOSDumpStatus(ctx context.Context) error {
	osDumpList, err := a.PoolDumpStatusDao.GetNotFinalOSDumpList(ctx)
	if err != nil {
		return err
	}

	taskIDs := make([]int64, 0)
	for _, osDumpInfo := range osDumpList {
		taskIDs = append(taskIDs, osDumpInfo.OSDumpTaskID)
	}

	// 获取未完成的os dump的最新状态
	taskIDStatusMap, err := base_struct_condition.QueryDumpStatus(ctx, taskIDs...)
	if err != nil {
		return err
	}

	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[CheckOSDumpStatus]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return errors.New("获取数据库的事务失败")
	}
	// 更新os dump最新状态
	for id, status := range taskIDStatusMap {
		err = a.PoolDumpStatusDao.UpdateOSDumpStatus(ctx, tx, dao.OSDumpStatusType(status), id)
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "[CheckOSDumpStatus]调用货盘Dump sql失败，err=%v+", err)
			return err
		}
	}
	// 提交事务
	tx.Commit()
	return nil
}

func (a *AnalysisPoolDumpService) SubmitDoradoTask(ctx context.Context) error {
	// 获取未提交的dorado任务列表
	doradoList, err := a.PoolDumpStatusDao.GetNotSubmitDoradoList(ctx)
	if err != nil {
		return err
	}

	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[SubmitDoradoTask]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return errors.New("获取数据库的事务失败")
	}

	for _, doradoInfo := range doradoList {
		instanceID, err := dorado_task_tool.TriggerRun(ctx, 116948708, map[string]interface{}{
			"pool_source": doradoInfo.PoolSource,
			"pool_id":     doradoInfo.PoolID,
			"update_time": doradoInfo.OSDumpTime,
		})
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "[SubmitDoradoTask]提交dorado失败，err=%v+", err)
			return err
		}
		err = a.PoolDumpStatusDao.UpdateDoradoInstanceID(ctx, tx, instanceID, doradoInfo.ID)
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "[SubmitDoradoTask]更新dorado任务信息失败，err=%v+", err)
			return err
		}
	}

	// 提交事务
	tx.Commit()
	return nil
}

func (a *AnalysisPoolDumpService) UpdateDoradoTaskStatus(ctx context.Context, req *dorado_task.GetDoradoTaskRunningCallBackRequest) error {
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[UpdateDoradoTaskStatus]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return errors.New("获取数据库的事务失败")
	}

	err := a.PoolDumpStatusDao.UpdateDoradoInstanceStatus(ctx, tx, int(req.InstanceStatus), req.InstanceId)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "[UpdateDoradoTaskStatus]UpdateDoradoInstanceStatus失败，err=%v+", err)
		return err
	}
	return nil
}
