package analysis_pool_product_service

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"math/rand"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	biz_info "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom_product_pack_platform"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom_seller_merchant_dc"
	export_service "code.byted.org/ecom/smartop_product_analysis/biz/service/export_data/common"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/summary_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tos"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	alert_rule "code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_alert_rule"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_product"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/product_select"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/jsonx"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_product_pack_platform/kitex_gen/ecom/product/pack_platform"
	"code.byted.org/overpass/ecom_seller_merchant_dc/kitex_gen/ecom/seller/merchant_dc"
	"code.byted.org/overpass/ecom_smartop_ads_growth_cockpit/kitex_gen/ecom/smartop/ads_growth_cockpit"
	"code.byted.org/overpass/ecom_smartop_ads_growth_cockpit/rpc/ecom_smartop_ads_growth_cockpit"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
	"github.com/mohae/deepcopy"
	"github.com/shopspring/decimal"
	"github.com/thoas/go-funk"
	"golang.org/x/sync/semaphore"
)

type multiHeaderStruct struct {
	Name    string `json:"name"`
	ColName string `json:"col_name"`
}

type queryAnalysisPoolProductCommonReq struct {
	PoolId      string            `thrift:"pool_id,2,required" frugal:"2,required,string" json:"pool_id"`
	AlertMsgId  *string           `thrift:"alert_msg_id,3,optional" frugal:"3,optional,string" json:"alert_msg_id,omitempty"`
	ProductId   *string           `thrift:"product_id,4,optional" frugal:"4,optional,string" json:"product_id,omitempty"`
	ProductName *string           `thrift:"product_name,5,optional" frugal:"5,optional,string" json:"product_name,omitempty"`
	StartDate   *string           `thrift:"start_date,6,optional" frugal:"6,optional,string" json:"start_date,omitempty"`
	EndDate     *string           `thrift:"end_date,7,optional" frugal:"7,optional,string" json:"end_date,omitempty"`
	OrderBy     *base.OrderByInfo `thrift:"order_by,8,optional" frugal:"8,optional,base.OrderByInfo" json:"order_by,omitempty"`
}

type ProductInfo struct {
	ProdId              string                       `json:"prod_id"`
	ProdName            string                       `json:"prod_name"`
	MaxShowModule       string                       `json:"max_show_module"`
	ShopId              string                       `json:"shop_id"`
	ShopName            string                       `json:"shop_name"`
	BrandName           string                       `json:"brand_name"`
	BrandLevel          string                       `json:"brand_level"`
	IndustryName        string                       `json:"industry_name"`
	FirstLevelCateName  string                       `json:"first_level_cate_name"`
	SecondLevelCateName string                       `json:"second_level_cate_name"`
	LeafCateId          string                       `json:"leaf_cate_id"`
	LeafCateName        string                       `json:"leaf_cate_name"`
	TargetList          []*analysis.TargetCardEntity `json:"target_list"`
}

type DownloadProductDetail struct {
	ProdId               *string `json:"prod_id"`
	ProdName             *string `json:"prod_name"`
	IsAllowanceProduct   *string `json:"is_allowance_product"`
	IsBrandTrialProduct  *string `json:"is_brand_trial_product"`
	IsSeckillProduct     *string `json:"is_seckill_product"`
	PurchaseStatus       *string `json:"purchase_status"`
	PurchaseStatusReason *string `json:"purchase_status_reason"`
	CampaignStockNumSum  *int64  `json:"campaign_stock_num_sum"`
	NormalStockNumSum    *int64  `json:"normal_stock_num_sum"`
	MaxShowModule        *string `json:"max_show_module"`
	IndustryName         *string `json:"industry_name"`
	FirstLevelCateName   *string `json:"first_level_cate_name"`
	SecondLevelCateName  *string `json:"second_level_cate_name"`
	LeafCateId           *string `json:"leaf_cate_id"`
	LeafCateName         *string `json:"leaf_cate_name"`
	BrandName            *string `json:"brand_name"`
	ComplexBrandSLevel   *string `json:"complex_brand_s_level"`
	ShopId               *string `json:"shop_id"`
	ShopName             *string `json:"shop_name"`
	ShowPv               *string `json:"show_pv"`
	ClickPv              *string `json:"click_pv"`
	PayOrdCnt            *string `json:"pay_ord_cnt"`
	PayGmv               *string `json:"pay_gmv"`
	Opm                  *string `json:"opm"`
	Gpm                  *string `json:"gpm"`
	Ctr                  *string `json:"ctr"`
	Cvr                  *string `json:"cvr"`
	Pvr                  *string `json:"pvr"`
	AvgOrderGmv          *string `json:"avg_order_gmv"`
}

type IAnalysisPoolProductService interface {
	GetAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.GetAnalysisPoolProductListReq) (resp *analysis_pool_product.GetAnalysisPoolProductListData, err error)
	GetDataAvailableDateRange(ctx context.Context, req *analysis_pool_product.GetDataAvailableDateRangeReq) (resp *analysis_pool_product.AvailableDateRange, err error)
	QueryAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.QueryAnalysisPoolProductListReq) (resp *analysis_pool_product.QueryAnalysisPoolProductListData, err error)
	OpAnalysisPoolProduct(ctx context.Context, req *analysis_pool_product.OpAnalysisPoolProductReq) (isOk bool, err error)
	GetProductMultiDim(ctx context.Context, req *analysis_pool_product.GetProductMultiDimReq) (DimListData []*analysis.MultiDimListRow, ProductData *analysis_pool_product.AnalysisPoolProduct, err error)
	DownloadProductMultiDim(ctx context.Context, req *analysis_pool_product.DownloadProductMultiDimReq) (isOk bool, err error)
	DownloadAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.DownloadAnalysisPoolProductListReq) (isOk bool, err error)
	GetPoolProductTrend(ctx context.Context, req *analysis_pool_product.GetPoolProductTrendReq) (resp *analysis_pool_product.GetPoolProductTrendData, err error)
	GetProductSelectTaskByPoolId(ctx context.Context, poolId string) (*dao.ProductSelectTask, error)
}

type AnalysisPoolProductService struct {
	DimensionListDao dao.IDimensionListDao
}

func (t *AnalysisPoolProductService) GetAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.GetAnalysisPoolProductListReq) (resp *analysis_pool_product.GetAnalysisPoolProductListData, err error) {
	resp = &analysis_pool_product.GetAnalysisPoolProductListData{}
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolList]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return resp, errors.New("获取数据库的事务失败")
	}
	pidList, _, err := dao.GetAnalysisPoolPidList(ctx, tx, req.PoolId)
	// analysisPoolList, total, err := dao.QueryAnalysisPoolList(ctx, tx, req)
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolList]调用查询货盘sql失败，err=%v+", err)
		tx.Rollback()
		return resp, err
	}
	// 提交事务
	tx.Commit()

	resp = &analysis_pool_product.GetAnalysisPoolProductListData{
		PidList: pidList,
	}

	return resp, nil
}

func (t *AnalysisPoolProductService) GetPoolProductTrend(ctx context.Context, req *analysis_pool_product.GetPoolProductTrendReq) (resp *analysis_pool_product.GetPoolProductTrendData, err error) {
	resp = &analysis_pool_product.GetPoolProductTrendData{}
	dimMap := map[int64]*dao.DimensionInfo{}
	bizType := dimensions.BizType_GreatValueBuy

	// 获取用户信息
	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.EmployeeId == nil {
		logs.CtxError(ctx, "[GetPoolProductTrend] failed, userInfo is nil")
		return resp, errors.New("[GetPoolProductTrend] userInfo is nil")
	}

	pidList, _, poolInfo, err := GetPoolAndPidList(ctx, req.PoolId, nil)
	if err != nil {
		logs.CtxError(ctx, "[GetPoolProductTrend]查询货盘商品失败，err=%v+", err)
		return resp, err
	}
	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd {
		bizType = dimensions.BizType_GrowthProductStrategy
	} else if poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule {
		bizType = utils.If(poolInfo.BaseStruct.BizType == dimensions.BizType_GreatValueBuy, dimensions.BizType_GreatValueBuy, dimensions.BizType_GrowthProductStrategy)
		if poolInfo.BaseStruct.BizType == dimensions.BizType_BrandTrial {
			bizType = dimensions.BizType_BrandTrial
		}
		if poolInfo.BaseStruct.BizType == dimensions.BizType_ProdSeckill {
			bizType = dimensions.BizType_ProdSeckill
		}
	} else if poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		bizType = poolInfo.BaseStruct.BizType
	}

	// 权限检查：获取用户权限角色
	role, err := getUserPermissionRole(ctx, *userInfo.EmployeeId, bizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPoolProductTrend] getUserPermissionRole error, err: %s", err.Error())
		return resp, err
	}
	if role == "" {
		return resp, errors.New("[GetPoolProductTrend] permission denied")
	}

	// 根据货盘规则中bizType获取dimMap
	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule || poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		dimMap, err = t.DimensionListDao.GetDimensionMap(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "[GetPoolProductTrend]获取map失败，err=%v+", err)
			return resp, err
		}
	}

	// 组装查询参数
	// 需要根据货盘创建的类型区分参数组装逻辑
	params, err := getAnalysisPoolProductTrendOsParams(ctx, bizType, &queryAnalysisPoolProductCommonReq{
		PoolId:    req.PoolId,
		StartDate: req.StartDate,
		EndDate:   req.EndDate,
	}, poolInfo, pidList, dimMap)

	if err != nil {
		logs.CtxError(ctx, "[GetPoolProductTrend]获取查询商品明细os params失败，err=%v+", err)
		return resp, err
	}

	logs.CtxInfo(ctx, "[GetPoolProductTrend]查询os api params=%v", params)

	// 查询OneService 货品行为数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, apiPathPoolTrend, param.SinkTable("pool_product_trend")).SetParallel(true).SetMaxParallelNum(5)

	f.Call(
		indexCardCom.FlowSplitMetricsToRow(param.SourceTable("pool_product_trend"), param.SinkTable("target_data")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").
			SetDimColumns([]string{"date"}),
	)
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(bizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeProduceSql(`
		select  date,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.display_order as display_order
		from    target_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		`, param.SinkTable("target_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeProduceSql(`
	select  date,
			(select * from target_data where target_data.date = pool_product_trend.date) as target_list
	from    pool_product_trend
`, param.SinkTable("res_data"))

	f.ExeView(param.SourceTable("res_data"), &resp.TrendDataList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetPoolProductTrend]调用OneService失败，err=%v+", err)
		return nil, err
	}

	return resp, nil
}

func GenerateTOSPath(ctx context.Context) string {
	userEmail, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "GenerateTOSPath error, %s", err.Error())
		return ""
	}

	userName := utils.ExtractUsernameFromEmail(userEmail)
	filename := fmt.Sprintf("%s_ret.csv", userName)
	timestamp := time.Now().Format("20060102150405")
	rand.NewSource(time.Now().UnixNano())
	key := fmt.Sprintf("analysis_pool_product/%d%s_%s", rand.Intn(10000), timestamp, filename)

	return key
}

func (t *AnalysisPoolProductService) DownloadAnalysisPoolProductList(ctx context.Context,
	req *analysis_pool_product.DownloadAnalysisPoolProductListReq) (bool, error) {
	dimMap := map[int64]*dao.DimensionInfo{}
	bizType := dimensions.BizType_GreatValueBuy

	pidList, _, poolInfo, err := GetPoolAndPidList(ctx, req.PoolId, req.AlertMsgId)
	if err != nil {
		logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]查询货盘商品失败，err=%v+", err)
		return false, err
	}

	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd {
		bizType = dimensions.BizType_GrowthProductStrategy
	} else if poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule {
		bizType = utils.If(poolInfo.BaseStruct.BizType == dimensions.BizType_GreatValueBuy, dimensions.BizType_GreatValueBuy, dimensions.BizType_GrowthProductStrategy)
		if poolInfo.BaseStruct.BizType == dimensions.BizType_BrandTrial {
			bizType = dimensions.BizType_BrandTrial
		}
		if poolInfo.BaseStruct.BizType == dimensions.BizType_ProdSeckill {
			bizType = dimensions.BizType_ProdSeckill
		}
	} else if poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		bizType = poolInfo.BaseStruct.BizType
	}

	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd || (req.AlertMsgId != nil && *req.AlertMsgId != "") {
		if len(pidList) == 0 {
			logs.CtxInfo(ctx, "[DownloadAnalysisPoolProductList]货盘中没有商品，pidList=%", pidList)
			return false, errors.New("货盘中没有商品")
		}

		// 当查询参数有商品id，并且不在货盘中时，返回空数组
		if req.ProductId != nil && *req.ProductId != "" && !slices.ContainsString(pidList, *req.ProductId) {
			logs.CtxInfo(ctx, "[DownloadAnalysisPoolProductList]查询参数中商品id不在货盘中，pidList=%v，ProductId=%v", pidList, req.ProductId)
			return false, errors.New("查询参数中商品id不在货盘中")
		}
	}

	// 查询参数中没有时间范围时返回空数组
	if req.StartDate == nil || req.EndDate == nil || len(*req.StartDate) == 0 || len(*req.StartDate) == 0 {
		return false, errors.New("查询参数中没有时间范围")
	}

	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule || poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		dimMap, err = t.DimensionListDao.GetDimensionMap(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]获取map失败，err=%v+", err)
			return false, err
		}
	}
	targetMetaMap, err := base_struct_condition.GetTargetMetaInfoMap(ctx, int64(bizType), false)
	if err != nil {
		logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]查询GetTargetMetaInfoMap失败，err=%v+", err)
		return false, err
	}

	selectedModuleConfig := make(map[product_select.PageModuleType]*product_select.SelectedPageModuleConfig)
	subSql := generateSubSQL(ctx, poolInfo.BaseStruct, dimMap)
	if bizType == dimensions.BizType_ProdSelectNavigation {
		// 从product_select_task表中读取指定pool_id的task，获取SelectedPageModuleConfig
		task, err := t.GetProductSelectTaskByPoolId(ctx, req.PoolId)
		if err != nil {
			logs.CtxWarn(ctx, "[DownloadAnalysisPoolProductList]获取任务失败，err=%v+, poolId=%v", err, req.PoolId)
			// 任务获取失败不影响主流程，继续执行
		} else {
			// 解析任务的extra字段，获取SelectedPageModuleConfig
			if task.Extra != "" {
				extra := &product_select.Extra{}
				err = sonic.UnmarshalString(task.Extra, extra)
				if err != nil {
					logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]解析extra失败，err=%v+, extra=%v", err, task.Extra)
				} else {
					unmarshalErr := sonic.UnmarshalString(extra.SelectedPageModuleConfig, &selectedModuleConfig)
					if unmarshalErr != nil {
						logs.CtxError(ctx, "[IGetProductSelectTaskDetail] UnmarshalString err: %s", unmarshalErr.Error())
					}
					logs.CtxInfo(ctx, "[DownloadAnalysisPoolProductList]获取SelectedPageModuleConfig成功，config=%v", selectedModuleConfig)
				}
			}
		}
		if task == nil || task.TaskId == 0 {
			return false, errors.New("未找到对应的选品任务")
		}
	} else {
		if poolInfo.BaseStruct != nil && isProductSelectBizType(ctx, poolInfo.BaseStruct.BizType) {
			poolInfo.BaseStruct.Dimensions = nil
		}
	}

	// 组装查询参数
	// 需要根据货盘创建的类型区分参数组装逻辑
	params, err := getQueryAnalysisPoolProductOsParams(ctx, bizType, &queryAnalysisPoolProductCommonReq{
		PoolId:      req.PoolId,
		AlertMsgId:  req.AlertMsgId,
		ProductId:   req.ProductId,
		ProductName: req.ProductName,
		StartDate:   req.StartDate,
		EndDate:     req.EndDate,
		OrderBy:     req.OrderBy,
	}, poolInfo, pidList, dimMap)
	if err != nil {
		logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]获取查询商品明细os params失败，err=%v+", err)
		return false, err
	}

	// 拼装子查询
	if len(subSql) > 0 {
		params["prod_sub_sql"] = subSql
	}

	logs.CtxInfo(ctx, "[DownloadAnalysisPoolProductList]查询os api params=%v", params)

	// 查询OneService 货品行为数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()

	// 判断是否需要CSV格式导出
	isCSVExport := false
	apiPath := apiPathProductDerail

	// 获取email
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]GetOperatorEmailFromContext，err=%v+", err)
		return false, err
	}

	if bizType == dimensions.BizType_ProdSelectNavigation {
		poolRule := poolInfo.BaseStruct
		params["date"] = poolRule.EndDate
		rawDimensions := deepcopy.Copy(poolRule.Dimensions).([]*dimensions.SelectedDimensionInfo)

		// 赛道
		filterDimensionsInit := deepcopy.Copy(rawDimensions)
		filterDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
		for _, d := range filterDimensionsInit.([]*dimensions.SelectedDimensionInfo) {
			if d.Id == "10520" || d.Id == "10521" || d.Id == "10522" || d.Id == "10523" {
				filterDimensions = append(filterDimensions, d)
			}
		}
		poolRule.Dimensions = filterDimensions
		vblineParams, _ := base_struct_condition.GetBaseStructConditionParam(ctx,
			base_struct_condition.OsParamsReq{
				BaseStruct: poolRule,
				DimMap:     dimMap,
			},
			base_struct_condition.SQLCalcType_Curr,
		)
		params["vbline_filter_param"] = vblineParams["filter_param"]

		// 热销
		navigationDimensions := deepcopy.Copy(rawDimensions).([]*dimensions.SelectedDimensionInfo)
		navigationDimensions = append(navigationDimensions, selectedModuleConfig[product_select.PageModuleType_HotSale].Dimensions...)
		poolRule.Dimensions = navigationDimensions
		if len(selectedModuleConfig[product_select.PageModuleType_HotSale].ThresholdAttrs) == 0 {
			logs.CtxError(ctx, "DownloadAnalysisPoolProductList ThresholdAttrs is nil")
			return false, err
		}
		navigationAttr := selectedModuleConfig[product_select.PageModuleType_HotSale].ThresholdAttrs[0]

		navigationStartDate, navigationEndDate, err := utils.GetStartDateAndEndDate(ctx, poolRule.EndDate, navigationAttr.DateRule)
		if err != nil {
			logs.CtxError(ctx, "DownloadAnalysisPoolProductList GetStartDateAndEndDate error, %s", err.Error())
			return false, err
		}
		params["navigation_start_date"] = navigationStartDate
		params["navigation_end_date"] = navigationEndDate
		params["gmv_threshold"] = navigationAttr.AccThreshold.GetThreshold()

		navigationParams, _ := base_struct_condition.GetBaseStructConditionParam(ctx,
			base_struct_condition.OsParamsReq{
				BaseStruct: poolRule,
				DimMap:     dimMap,
			},
			base_struct_condition.SQLCalcType_Curr,
		)
		params["navigation_filter_param"] = navigationParams["filter_param"]

		// 补品
		if additionConfig, exist := selectedModuleConfig[product_select.PageModuleType_Addition]; exist && additionConfig != nil && len(additionConfig.Dimensions) > 0 && len(additionConfig.ThresholdAttrs) > 0 {
			supplyDimensions := deepcopy.Copy(rawDimensions).([]*dimensions.SelectedDimensionInfo)
			supplyDimensions = append(supplyDimensions, selectedModuleConfig[product_select.PageModuleType_Addition].Dimensions...)
			poolRule.Dimensions = supplyDimensions
			supplyParams, _ := base_struct_condition.GetBaseStructConditionParam(ctx,
				base_struct_condition.OsParamsReq{
					BaseStruct: poolRule,
					DimMap:     dimMap,
				},
				base_struct_condition.SQLCalcType_Curr,
			)
			params["supply_filter_param"] = supplyParams["filter_param"]

			supplyAttr := selectedModuleConfig[product_select.PageModuleType_Addition].ThresholdAttrs[0]
			supplyStartDate, supplyEndDate, err := utils.GetStartDateAndEndDate(ctx, poolRule.EndDate, supplyAttr.DateRule)
			if err != nil {
				logs.CtxError(ctx, "GetStartDateAndEndDate error, %s", err.Error())
				return false, err
			}
			params["supply_start_date"] = supplyStartDate
			params["supply_end_date"] = supplyEndDate
			params["top_threshold"] = supplyAttr.GetTopN()
		}

		logs.CtxInfo(ctx, "DownloadAnalysisPoolProductList navigation_filter_param, %s", jsonx.ToString(params))

		path := utils.GenerateTOSPath(ctx)
		if len(path) == 0 {
			logs.CtxError(ctx, "DownloadAnalysisPoolProductList GenerateTOSPath is nil")
			return false, errors.New("GenerateTOSPath is nil")
		}
		paramsStr, _ := sonic.MarshalString(params)
		apiPathId := "7599491980669830190"
		tosURL, err := tos.UploadDumpRowToTOS(ctx, paramsStr, path, apiPathId)
		if err != nil {
			logs.CtxError(ctx, "DownloadAnalysisPoolProductList UploadDumpRowToTOS，err=%v+", err)
			return false, err
		}
		logs.CtxInfo(ctx, "DownloadAnalysisPoolProductList tosURL %s", tosURL)

		// 飞书通知
		err = export_service.SendLarkMsg(ctx, email, strings.Join([]string{tosURL}, " "))
		if err != nil {
			logs.CtxError(ctx, "DownloadAnalysisPoolProductList SendLarkMsg，err=%v+", err)
			return false, err
		}

		return true, nil
	}

	if isProductSelectBizType(ctx, bizType) {
		apiPath = "7574446444745163803" // todo 更换
		isCSVExport = true

		// 获取用户信息
		userInfo := utils.GetUserInfo(ctx)
		if userInfo == nil || userInfo.EmployeeId == nil {
			logs.CtxError(ctx, "[DownloadAnalysisPoolProductList] failed, userInfo is nil")
			return false, errors.New("[DownloadAnalysisPoolProductList] userInfo is nil")
		}

		// 权限检查：获取用户权限角色
		role, err := getUserPermissionRole(ctx, *userInfo.EmployeeId, bizType)
		if err != nil {
			logs.CtxError(ctx, "[DownloadAnalysisPoolProductList] getUserPermissionRole error, err: %s", err.Error())
			return false, err
		}
		if role == "" {
			return false, errors.New("[DownloadAnalysisPoolProductList] permission denied")
		}

	} else {
		// 导出接口的limit 暂时写死
		params["limit"] = 80000
		params["offset"] = 0
	}

	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("product_bhv_data")).SetParallel(true).SetMaxParallelNum(5)

	if isCSVExport { // 执行CSV导出
		tosUrlList := make([]string, 0)

		// 导出CSV1
		path := utils.GenerateTOSPath(ctx)
		if len(path) == 0 {
			logs.CtxError(ctx, "DownloadAnalysisPoolProductList GenerateTOSPath is nil")
			return false, errors.New("GenerateTOSPath is nil")
		}
		paramsStr, _ := sonic.MarshalString(params)
		apiPathId := "7576647297522467867"
		tosURL, err := tos.UploadDumpRowToTOS(ctx, paramsStr, path, apiPathId)
		if err != nil {
			logs.CtxError(ctx, "DownloadAnalysisPoolProductList UploadDumpRowToTOS，err=%v+", err)
			return false, err
		}
		tosUrlList = append(tosUrlList, tosURL)

		// 飞书通知
		err = export_service.SendLarkMsg(ctx, email, strings.Join(tosUrlList, " "))
		if err != nil {
			logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]SendLarkMsg，err=%v+", err)
			return false, err
		}

		return true, nil

	} else {
		f.ExeQueryCustom([]param.Source{param.SourceTable("product_bhv_data"), param.SourceConst(true)}, getProductInfoMergeBhv, param.SinkTable("product_export_data"))
		// 执行默认的飞书导出
		if env.IsBoe() {
			email = "yuwenbin.yutou@bytedance.com"
		}

		f.ExeCustom([]param.Source{param.SourceTable("product_export_data"), param.SourceConst(email), param.SourceConst(targetMetaMap)}, doAnalysisPoolProductDownloadExport, nil)
		app.Use(f.ToStack(ctx))
		_, err = app.Run(ctx)
		if err != nil {
			logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]导出到飞书表格失败，err=%v+", err)
			return false, err
		}
	}

	return true, nil
}

func (t *AnalysisPoolProductService) DownloadProductMultiDim(ctx context.Context, req *analysis_pool_product.DownloadProductMultiDimReq) (isOk bool, err error) {
	bizType := dimensions.BizType_GreatValueBuy
	dimensionsList := make([]*dimensions.SelectedDimensionInfo, 0)

	_, _, poolInfo, err := GetPoolAndPidList(ctx, req.PoolId, nil)
	if err != nil {
		logs.CtxError(ctx, "[DownloadProductMultiDim]查询货盘商品失败，err=%v+", err)
		return false, err
	}
	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd {
		bizType = dimensions.BizType_GrowthProductStrategy
	} else if poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule {
		bizType = utils.If(poolInfo.BaseStruct.BizType == dimensions.BizType_GreatValueBuy, dimensions.BizType_GreatValueBuy, dimensions.BizType_GrowthProductStrategy)
		if poolInfo.BaseStruct.BizType == dimensions.BizType_BrandTrial {
			bizType = dimensions.BizType_BrandTrial
		}
		if poolInfo.BaseStruct.BizType == dimensions.BizType_ProdSeckill {
			bizType = dimensions.BizType_ProdSeckill
		}
	} else if poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		bizType = poolInfo.BaseStruct.BizType
	}

	if len(req.GroupAttrs) == 0 {
		return false, errors.New("获取多维分析参数失败")
	}
	dimMap, err := t.DimensionListDao.GetDimensionMap(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[DownloadProductMultiDim]获取map失败，err=%v+", err)
		return false, err
	}

	dimColMap, err := t.DimensionListDao.GetDimensionColMap(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[DownloadProductMultiDim]获取col map失败，err=%v+", err)
		return false, err
	}

	// 获取分析的维度信息
	groupCols := make([]string, 0)
	dimColEnumCodeMap := make(map[string]map[string]string)
	for _, attr := range req.GroupAttrs {
		dimensionsList = append(dimensionsList, attr.DimInfo)

		// 获取维度的查询字段名
		if attr.DimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,DimInfo为空")
			return false, errors.New("未查询到维度信息,DimInfo为空")
		}
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息")
			return false, errors.New("未查询到维度信息")
		}
		groupCols = append(groupCols, dimInfo.DimColumn)

		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			enumCodeMap := make(map[string]string)
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
			dimColEnumCodeMap[dimInfo.DimColumn] = enumCodeMap
		}
	}

	baseStruct := &dimensions.ProductAnalysisBaseStruct{
		BizType:    bizType,
		StartDate:  *req.StartDate,
		EndDate:    *req.EndDate,
		Dimensions: dimensionsList,
		GroupAttrs: req.GroupAttrs,
	}

	currTotalMap, err := getProductMultiDimMergeRecord(ctx, &base_struct_condition.OsParamsReq{
		BaseStruct:     baseStruct,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: groupCols,
	}, req.ProductId)
	if err != nil {
		logs.CtxError(ctx, "[DownloadProductMultiDim]调用OneService查询单品数据失败，err=%v+", err)
		return false, err
	}

	currTotalMap[groupCols[0]] = "不分任何维度的整体数据"

	targetMetaMap, err := base_struct_condition.GetTargetMetaInfoMap(ctx, int64(bizType), false)
	if err != nil {
		logs.CtxError(ctx, "[DownloadProductMultiDim]查询GetTargetMetaInfoMap失败，err=%v+", err)
		return false, err
	}

	params, err := getProductMultiDimParams(ctx, &base_struct_condition.OsParamsReq{
		BaseStruct:     baseStruct,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: groupCols,
	}, req.ProductId)

	if err != nil || params == nil {
		logs.CtxError(ctx, "[DownloadProductMultiDim]获取查询OneService参数失败，err=%v+", err)
		return false, err
	}
	params["export_select"] = strings.Join(append(groupCols, base_struct_condition.GenerateDimKey(groupCols, "")), ",")

	apiPath := apiPathInsightBillProductMultiDim
	if bizType == dimensions.BizType_GreatValueBuy {
		apiPath = apiPathInsightBillProductMultiDim
	} else if biz_utils.IsUseGrowthProductStrategyTable(bizType) {
		apiPath = apiPathInsightScenarioProductMultiDim
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(bizType), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryCustom([]param.Source{param.SourceConst(req.GroupAttrs), param.SourceConst(dimMap)}, getMultiDimDocHeader, param.SinkTable("doc_header"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("multi_dim_data"))
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "[DownloadProductMultiDim]查oneService获取数据失败，err=%v+", err)
		return false, err
	}

	if env.IsBoe() {
		email = "yuwenbin.yutou@bytedance.com"
	}

	f.ExeQueryCustom([]param.Source{param.SourceConst(dimColEnumCodeMap), param.SourceConst(groupCols), param.SourceTable("multi_dim_data"), param.SourceConst(currTotalMap)}, getMultiDimDownloadData, param.SinkTable("multi_dim_export_data"))
	f.ExeCustom([]param.Source{param.SourceTable("multi_dim_export_data"), param.SourceConst(email), param.SourceTable("doc_header"), param.SourceConst(targetMetaMap), param.SourceConst(groupCols), param.SourceConst(req)}, doMultiDimDownloadExport, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[DownloadProductMultiDim]导出到飞书表格失败，err=%v+", err)
		return false, err
	}

	return true, nil
}

func (t *AnalysisPoolProductService) GetProductMultiDim(ctx context.Context, req *analysis_pool_product.GetProductMultiDimReq) (DimListData []*analysis.MultiDimListRow, ProductData *analysis_pool_product.AnalysisPoolProduct, err error) {
	DimListData = make([]*analysis.MultiDimListRow, 0)
	ProductData = &analysis_pool_product.AnalysisPoolProduct{}
	dimensionsList := make([]*dimensions.SelectedDimensionInfo, 0)
	bizType := dimensions.BizType_GreatValueBuy
	_, _, poolInfo, err := GetPoolAndPidList(ctx, req.PoolId, nil)
	if err != nil {
		logs.CtxError(ctx, "[GetProductMultiDim]查询货盘商品失败，err=%v+", err)
		return nil, nil, err
	}
	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd {
		bizType = dimensions.BizType_GrowthProductStrategy
	} else if poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule {
		bizType = utils.If(poolInfo.BaseStruct.BizType == dimensions.BizType_GreatValueBuy, dimensions.BizType_GreatValueBuy, dimensions.BizType_GrowthProductStrategy)
		if poolInfo.BaseStruct.BizType == dimensions.BizType_BrandTrial {
			bizType = dimensions.BizType_BrandTrial
		}
		if poolInfo.BaseStruct.BizType == dimensions.BizType_ProdSeckill {
			bizType = dimensions.BizType_ProdSeckill
		}
	} else if poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		bizType = poolInfo.BaseStruct.BizType
	}

	if len(req.GroupAttrs) == 0 {
		return nil, nil, errors.New("获取多维分析参数失败")
	}
	// 前置通过pool_id获取biz_type，人工录入默认为超值购底池

	dimMap, err := t.DimensionListDao.GetDimensionMap(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductMultiDim]获取map失败，err=%v+", err)
		return nil, nil, err
	}

	dimColMap, err := t.DimensionListDao.GetDimensionColMap(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductMultiDim]获取col map失败，err=%v+", err)
		return nil, nil, err
	}

	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.GroupAttrs {
		// 获取维度的查询字段名
		if attr.DimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,DimInfo为空")
			return nil, nil, errors.New("未查询到维度信息,DimInfo为空")
		}
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息")
			return nil, nil, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			dimensionsList = append(dimensionsList, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
			}
			dimensionsList = append(dimensionsList, attr.DimInfo)
		}
	}
	if len(groupCol) == 0 {
		logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
		return nil, nil, errors.New("多维分析未传入多维配置")
	}
	baseStruct := &dimensions.ProductAnalysisBaseStruct{
		BizType:    bizType,
		StartDate:  *req.StartDate,
		EndDate:    *req.EndDate,
		Dimensions: dimensionsList,
		GroupAttrs: req.GroupAttrs,
	}

	params, err := getProductMultiDimParams(ctx, &base_struct_condition.OsParamsReq{
		BaseStruct:     baseStruct,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
	}, req.ProductId)

	if err != nil {
		logs.CtxError(ctx, "[GetProductMultiDim]获取多维查询参数失败，err=%v+", err)
		return nil, nil, err
	}

	apiPath := apiPathInsightBillProductMultiDim
	if bizType == dimensions.BizType_GreatValueBuy {
		apiPath = apiPathInsightBillProductMultiDim
	} else if biz_utils.IsUseGrowthProductStrategyTable(bizType) {
		apiPath = apiPathInsightScenarioProductMultiDim
	}

	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: params, Sql: consts.Empty, ApiPath: apiPath, BizType: baseStruct.BizType, KeyCols: []string{groupCol}, NeedDistribution: true,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetProductMultiDim]调用OneService查询单品多维数据失败，err=%v+", err)
		return nil, nil, err
	}

	for _, info := range currTargetList {
		if len(info.KeyColValues) > 0 {
			DimListData = append(DimListData, &analysis.MultiDimListRow{
				EnumValue:  convert.ToString(info.KeyColValues[0]),
				TargetList: info.TargetEntity,
			})
		}
	}
	sumMap := make(map[string]float64)
	for _, info := range DimListData {
		sort.Slice(info.TargetList, func(i, j int) bool {
			return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
		})

		for _, i := range info.TargetList {
			if i.Extra.DistributionFlag {
				sumMap[i.Name] += i.Value
			}
		}
		info.DisplayName = enumCodeMap[info.EnumValue]
	}
	for _, info := range DimListData {
		for _, i := range info.TargetList {
			if i.Extra.DistributionFlag {
				if v, exist := sumMap[i.Name]; exist && v > 0 {
					i.Extra.DistributionValue = i.Value / sumMap[i.Name]
					continue
				}
			}
			i.Extra.DistributionValue = 0
		}
	}

	ProductData, err = getProductMultiDimMergeData(ctx, &base_struct_condition.OsParamsReq{
		BaseStruct:     baseStruct,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
	}, req.ProductId)
	if err != nil {
		logs.CtxError(ctx, "[GetProductMultiDim]调用OneService查询单品数据失败，err=%v+", err)
		return nil, nil, err
	}

	// 调用Summary查下商品信息
	productHash, err := ecom_product_pack_platform.RPCMGetProduct(ctx, []int64{convert.ToInt64(req.ProductId)})
	if err != nil {
		logs.CtxError(ctx, "[GetProductMultiDim]调用summary查询单品数据失败，err=%v+", err)
		return nil, nil, err
	}
	ProductData.ProdBgUrl = summary_utils.GetProductBgUrl(convert.ToInt64(req.ProductId), map[int64]*pack_platform.ProductItem{
		convert.ToInt64(req.ProductId): productHash[convert.ToInt64(req.ProductId)],
	})
	ProductData.IsAllowanceProduct = summary_utils.GetIsAllowanceProduct(convert.ToInt64(req.ProductId), map[int64]*pack_platform.ProductItem{
		convert.ToInt64(req.ProductId): productHash[convert.ToInt64(req.ProductId)],
	})
	ProductData.PurchaseStatus = summary_utils.GetPurchaseStatus(convert.ToInt64(req.ProductId), map[int64]*pack_platform.ProductItem{
		convert.ToInt64(req.ProductId): productHash[convert.ToInt64(req.ProductId)],
	})
	ProductData.CampaignStockNumSum = summary_utils.GetCampaignStock(convert.ToInt64(req.ProductId), map[int64]*pack_platform.ProductItem{
		convert.ToInt64(req.ProductId): productHash[convert.ToInt64(req.ProductId)],
	})

	return DimListData, ProductData, nil
}

func (t *AnalysisPoolProductService) OpAnalysisPoolProduct(ctx context.Context, req *analysis_pool_product.OpAnalysisPoolProductReq) (isOk bool, err error) {
	switch req.OpType {
	case analysis_pool_product.PoolProductOperateType_Add:
		// 创建事务
		tx := mysql.DB(ctx).Begin()
		if tx.Error != nil {
			logs.CtxError(ctx, "[OpAnalysisPoolProduct] add 获取数据库的事务失败，err=%v+", tx.Error.Error())
			return false, errors.New("获取数据库的事务失败")
		}
		analysisPool, err := dao.GetAnalysisPool(ctx, tx, req.PoolId)
		if err != nil {
			logs.CtxError(ctx, "[GetPoolAndPidList]查询货盘信息失败，err=%v+", err)
			tx.Rollback()
			return false, err
		}
		if analysisPool.PoolType != 0 {
			return false, errors.New("当前货盘类型不支持该操作")
		}
		// 调用dao层创建货盘商品
		err = dao.BatchCreateAnalysisPoolProduct(ctx, tx, req.PoolId, append(make([]string, 0), req.ProductIdList...))
		if err != nil {
			logs.CtxError(ctx, "[OpAnalysisPoolProduct] add 创建货盘商品失败，err=%v+", err)
			tx.Rollback()
			return false, err
		}
		// 提交事务
		tx.Commit()
		return true, nil
	case analysis_pool_product.PoolProductOperateType_Delete:
		// 创建事务
		tx := mysql.DB(ctx).Begin()
		if tx.Error != nil {
			logs.CtxError(ctx, "[OpAnalysisPoolProduct] delete 获取数据库的事务失败，err=%v+", tx.Error.Error())
			return false, errors.New("获取数据库的事务失败")
		}
		analysisPool, err := dao.GetAnalysisPool(ctx, tx, req.PoolId)
		if err != nil {
			logs.CtxError(ctx, "[GetPoolAndPidList]查询货盘信息失败，err=%v+", err)
			tx.Rollback()
			return false, err
		}
		if analysisPool.PoolType != 0 {
			return false, errors.New("当前货盘类型不支持该操作")
		}
		// 调用dao层删除货盘商品
		err = dao.BatchDeleteProduct(ctx, tx, req.PoolId, append(make([]string, 0), req.ProductIdList...))
		if err != nil {
			logs.CtxError(ctx, "[OpAnalysisPoolProduct] delete 删除货盘商品失败，err=%v+", err)
			tx.Rollback()
			return false, err
		}
		// 提交事务
		tx.Commit()
		return true, nil
	default:
		return false, errors.New("[OpAnalysisPoolProduct]操作类型错误")
	}
}

func (t *AnalysisPoolProductService) GetDataAvailableDateRange(ctx context.Context, req *analysis_pool_product.GetDataAvailableDateRangeReq) (resp *analysis_pool_product.AvailableDateRange, err error) {
	logicTableNames := []string{consts.LogicTableBillion, consts.LogicTableUserGrowth}
	rangeDate := 31
	if req.PoolId != nil {
		analysisPoolDoList := make([]dao.AnalysisPoolDo, 0)
		tx := mysql.DB(ctx)
		err := tx.Table("analysis_pool").Where("is_delete", 0).Where("pool_id = ?", req.GetPoolId()).Find(&analysisPoolDoList).Error
		if err != nil {
			logs.CtxError(ctx, "[GetDataAvailableDateRange]查询货盘信息失败，err=%v+", err)

		}
		if len(analysisPoolDoList) == 0 {
			logs.CtxWarn(ctx, "[GetDataAvailableDateRange]未查询到相关货盘，is_ppe=%v,pool_id=%v", env.IsPPE(), req.GetPoolId())
		}
		if len(analysisPoolDoList) > 0 {
			customProductPool := analysisPoolDoList[0]
			// 规则货盘
			if customProductPool.PoolType == int64(analysis_pool.AnalysisPoolType_DynamicRule) {
				var poolRule *dimensions.ProductAnalysisBaseStruct
				err = json.Unmarshal([]byte(customProductPool.PoolRule), &poolRule)
				if err != nil {
					logs.CtxError(ctx, "[GetDataAvailableDateRange] json decode error:%v", err)
				} else {
					bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, poolRule.BizType)
					if err != nil {
						logs.CtxError(ctx, "[GetProductPoolExpr] GetBizMetaInfo error:%v", err)
					}
					if bizMetaInfo != nil && bizMetaInfo.EffectModule == "大促视图" {
						tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
						if err != nil {
							logs.CtxError(ctx, "获取大促视图逻辑表配置失败, err=%v", err)
							return nil, err
						}
						logicTableNames = []string{tableConf.LogicTableProdBase}
						rangeDate = 730
					}
				}

			}
		}
	}
	oldest, newest, err := utils.GetOldestAndNewestDate(ctx, logicTableNames, rangeDate)
	if err != nil {
		logs.CtxError(ctx, "[GetDataAvailableDateRange]查询时间区间信息失败，err=%v+", err)
		return nil, err
	}
	resp = &analysis_pool_product.AvailableDateRange{
		MinDate: oldest,
		MaxDate: newest,
	}

	return resp, nil
}

func (t *AnalysisPoolProductService) GetProductSelectTaskByPoolId(ctx context.Context, poolId string) (*dao.ProductSelectTask, error) {
	tx := mysql.DB(ctx)
	taskDao := &dao.ProductSelectTaskDao{}
	task, err := taskDao.GetProductSelectTaskWithPoolId(ctx, tx, poolId)
	if err != nil {
		logs.CtxError(ctx, "[GetProductSelectTaskByPoolId]通过pool_id查询任务失败，err=%v+, poolId=%v", err, poolId)
		return nil, err
	}

	logs.CtxInfo(ctx, "GetProductSelectTaskByPoolId GetProductSelectTaskWithPoolId %s", jsonx.ToString(task))
	return task, nil
}

// mergeUserPermissionDimensions 将用户权限角色对应的维度列表合并到poolRule.Dimensions中
func mergeUserPermissionDimensions(ctx context.Context, poolRule *dimensions.ProductAnalysisBaseStruct) {
	if poolRule == nil {
		return
	}

	// 获取用户信息
	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.EmployeeId == nil {
		logs.CtxError(ctx, "mergeUserPermissionDimensions failed, userInfo is invalid")
		return
	}
	bizType := poolRule.BizType

	// 获取用户权限角色
	role, err := getUserPermissionRole(ctx, *userInfo.EmployeeId, bizType)
	if err != nil {
		logs.CtxError(ctx, "mergeUserPermissionDimensions getUserPermissionRole error, err: %s", err.Error())
		// 不返回错误，继续执行，使用空角色
		role = ""
	}

	// 获取角色对应的维度列表
	var userDimensions []*dimensions.SelectedDimensionInfo
	if role != "" {
		roleDimensionConfig, err := biz_info.GetProductSelectRoleDimensionConfig(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "mergeUserPermissionDimensions GetProductSelectRoleDimensionConfig error, err: %s", err.Error())
			// 不返回错误，继续执行，使用空列表
		} else {
			userDimensions = roleDimensionConfig[role]
		}
	}

	if len(userDimensions) == 0 {
		return
	}

	// 将用户维度合并到poolRule.Dimensions中
	if poolRule.Dimensions == nil {
		poolRule.Dimensions = userDimensions
		return
	}

	// 创建一个map用于快速查找相同ID的维度
	dimMap := make(map[string]*dimensions.SelectedDimensionInfo)
	for _, dim := range poolRule.Dimensions {
		dimMap[dim.Id] = dim
		// 确保SelectedValues不为nil
		if dim.SelectedValues == nil {
			dim.SelectedValues = []*dimensions.EnumElement{}
		}
	}

	// 合并用户维度到poolRule.Dimensions中
	for _, userDim := range userDimensions {
		if existingDim, exists := dimMap[userDim.Id]; exists {
			// 维度ID已存在，合并SelectedValues
			if userDim.SelectedValues != nil && len(userDim.SelectedValues) > 0 {
				// 创建一个map用于快速查找已存在的SelectedValue
				valueMap := make(map[string]bool)
				for _, value := range existingDim.SelectedValues {
					valueMap[value.Code] = true
				}

				// 添加新的SelectedValue
				for _, value := range userDim.SelectedValues {
					if !valueMap[value.Code] {
						existingDim.SelectedValues = append(existingDim.SelectedValues, value)
						valueMap[value.Code] = true
					}
				}
			}
		} else {
			// 维度ID不存在，直接添加
			// 确保SelectedValues不为nil
			if userDim.SelectedValues == nil {
				userDim.SelectedValues = []*dimensions.EnumElement{}
			}
			poolRule.Dimensions = append(poolRule.Dimensions, userDim)
			dimMap[userDim.Id] = userDim
		}
	}
}

// getUserPermissionRole 获取用户的权限角色
func getUserPermissionRole(ctx context.Context, employeeId string, bizType dimensions.BizType) (string, error) {
	// 如果GetDimensionsByUser失败或未找到权限，调用GetUserDimension
	userDimensionResp, err := utils.GetUserDimensionWithCache(ctx, employeeId)
	if err != nil {
		logs.CtxError(ctx, "getUserPermissionRole GetUserDimension error, err: %s", err.Error())
		return "", err
	}
	logs.CtxInfo(ctx, "getUserPermissionRole GetUserDimension, %s", jsonx.ToString(userDimensionResp))
	if userDimensionResp == nil {
		return "", errors.New("response is nil")
	}
	userDimensionCodeMap := make(map[string]bool)
	for _, dimension := range userDimensionResp.Dimension.Values {
		userDimensionCodeMap[dimension.Code] = true
	}

	targetCode := ""
	// 从TCC获取bizType对应的维度列表
	dimensionsList, err := biz_info.GetProductSelectBizTypeSecondaryIdList(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "getUserPermissionRole GetProductSelectBizTypeDimensionsConfig error, err: %s", err.Error())
		// 不返回错误，继续执行
		dimensionsList = []string{}
	}

	// 遍历维度列表，查找用户拥有的维度
	for _, dimension := range dimensionsList {
		if userDimensionCodeMap[dimension] {
			targetCode = dimension
			break
		}
	}

	return targetCode, nil
}

func isProductSelectBizType(ctx context.Context, bizType dimensions.BizType) bool {
	// 调用GetProductSelectBizTypeApiConfig获取配置
	apiConfig, err := biz_info.GetProductSelectBizTypeApiConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, "isProductSelectBizType: failed to get product select biz type api config, err: %v", err)
		return false
	}

	// 检查bizType是否在配置的BizType2Api映射中
	bizTypeStr := strconv.FormatInt(int64(bizType), 10)
	_, exists := apiConfig.BizType2Api[bizTypeStr]

	return exists
}

func generateSubSQL(ctx context.Context,
	poolRule *dimensions.ProductAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo) string {
	// 合并用户权限维度到poolRule.Dimensions中
	mergeUserPermissionDimensions(ctx, poolRule)

	subSql := ""
	if poolRule == nil {
		return subSql
	}

	if isProductSelectBizType(ctx, poolRule.BizType) {
		algParams, algErr := base_struct_condition.GetBaseStructConditionParam(ctx,
			base_struct_condition.OsParamsReq{
				BaseStruct: poolRule,
				DimMap:     dimMap,
			},
			base_struct_condition.SQLCalcType_Curr,
		)
		if algErr != nil {
			logs.CtxError(ctx, "QueryAnalysisPoolProductList GetBaseStructConditionParams error, %s", algErr.Error())
			return ""
		}
		logs.CtxInfo(ctx, "QueryAnalysisPoolProductList params: %s", jsonx.ToString(algParams))
		dateExpr := algParams["date_expr"]
		if slices.ContainsString(consts.NoDaysTypeTable, convert.ToString(algParams["table_name"])) {
			dateExpr = algParams["date_expr_no_days_type"]
		}
		var filterParams string
		if _, ok := algParams["filter_param"]; ok {
			filterParams = fmt.Sprintf("and %v", algParams["filter_param"])
		} else {
			filterParams = ""
		}

		subSql = fmt.Sprintf(`
			select distinct prod_id
			from %s as t_alias
			where %s %s`, algParams["table_name"], dateExpr, filterParams)
		logs.CtxInfo(ctx, "QueryAnalysisPoolProductList subSql: %s", subSql)
	}
	return subSql
}

func (t *AnalysisPoolProductService) QueryAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.QueryAnalysisPoolProductListReq) (resp *analysis_pool_product.QueryAnalysisPoolProductListData, err error) {
	resp = &analysis_pool_product.QueryAnalysisPoolProductListData{}
	dimMap := map[int64]*dao.DimensionInfo{}
	bizType := dimensions.BizType_GreatValueBuy
	overviewInfo := map[string]int64{}
	productInfoList := make([]*ProductInfo, 0)
	weighted := semaphore.NewWeighted(50)

	pidList, _, poolInfo, err := GetPoolAndPidList(ctx, req.PoolId, req.AlertMsgId)
	if poolInfo == nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolProductList]查询货盘商品失败，poolInfo is nil")
		return nil, errors.New("poolInfo is nil")
	}
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolProductList]查询货盘商品失败，err=%v+", err)
		return nil, err
	}

	var bizMataInfo *biz_utils.BizMetaInfo
	if poolInfo != nil && poolInfo.BaseStruct != nil {
		bizMataInfo, ctx, err = biz_utils.GetBizMetaInfo(ctx, poolInfo.BaseStruct.BizType)
	}
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolProductList]查询业务线元信息失败，err=%v+", err)
		return nil, err
	}
	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd {
		bizType = dimensions.BizType_GrowthProductStrategy
	} else if poolInfo.BaseStruct != nil && poolInfo.BaseStruct.BizType == dimensions.BizType_GuessBoostData {
		bizType = dimensions.BizType_GuessBoostData
	} else if bizMataInfo != nil && bizMataInfo.EffectModule == "大促视图" {
		bizType = bizMataInfo.BizType
	} else if poolInfo.BaseStruct != nil && poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule {
		bizType = utils.If(poolInfo.BaseStruct.BizType == dimensions.BizType_GreatValueBuy, dimensions.BizType_GreatValueBuy, dimensions.BizType_GrowthProductStrategy)
		if poolInfo.BaseStruct.BizType == dimensions.BizType_BrandTrial {
			bizType = dimensions.BizType_BrandTrial
		}
		if poolInfo.BaseStruct.BizType == dimensions.BizType_ProdSeckill {
			bizType = dimensions.BizType_ProdSeckill
		}
	} else if poolInfo.BaseStruct != nil && poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		bizType = poolInfo.BaseStruct.BizType
	}

	// poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule 根据货盘规则中bizType获取dimMap
	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule || poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		dimMap, err = t.DimensionListDao.GetDimensionMap(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "[QueryAnalysisPoolProductList]获取map失败，err=%v+", err)
			return nil, err
		}
	}

	resp = &analysis_pool_product.QueryAnalysisPoolProductListData{
		PageInfo: &base.PageResp{
			PageNum:  req.PageReq.PageNum,
			PageSize: req.PageReq.PageSize,
			Total:    0,
		},
		PoolInfo: poolInfo,
		List:     make([]*analysis_pool_product.AnalysisPoolProduct, 0),
	}

	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd || (req.AlertMsgId != nil && *req.AlertMsgId != "") {
		if len(pidList) == 0 {
			logs.CtxInfo(ctx, "[QueryAnalysisPoolProductList]货盘中没有商品，pidList=%v", pidList)
			return resp, nil
		}

		// 当查询参数有商品id，并且不在货盘中时，返回空数组
		if req.ProductId != nil && *req.ProductId != "" && !slices.ContainsString(pidList, *req.ProductId) {
			logs.CtxInfo(ctx, "[QueryAnalysisPoolProductList]查询参数中商品id不在货盘中，pidList=%v，ProductId=%v", pidList, req.ProductId)
			return resp, nil
		}
	}

	// 查询参数中没有时间范围时返回空数组
	if req.StartDate == nil || req.EndDate == nil || len(*req.StartDate) == 0 || len(*req.StartDate) == 0 {
		return resp, errors.New("查询参数中没有时间范围")
	}

	subSql := generateSubSQL(ctx, poolInfo.BaseStruct, dimMap)
	if poolInfo.BaseStruct != nil && isProductSelectBizType(ctx, poolInfo.BaseStruct.BizType) {
		poolInfo.BaseStruct.Dimensions = nil
	}

	// 组装查询参数
	// 需要根据货盘创建的类型区分参数组装逻辑
	params, err := getQueryAnalysisPoolProductOsParams(ctx, bizType, &queryAnalysisPoolProductCommonReq{
		PoolId:      req.PoolId,
		AlertMsgId:  req.AlertMsgId,
		ProductId:   req.ProductId,
		ProductName: req.ProductName,
		StartDate:   req.StartDate,
		EndDate:     req.EndDate,
		OrderBy:     req.OrderBy,
	}, poolInfo, pidList, dimMap)
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolProductList]获取查询商品明细os params失败，err=%v+", err)
		return nil, err
	}

	// 拼装子查询
	if len(subSql) > 0 {
		params["prod_sub_sql"] = subSql
	}
	// 使用这个优化参数，会导致错误的查询结果
	params["not_distributed_perfect_shard"] = 1

	apiDetail := apiPathProductDerail
	apiOverall := apiPathProductOverall

	if bizType == dimensions.BizType_GuessBoostData {
		params["start_date"] = *req.StartDate
		params["end_date"] = *req.EndDate
		params["select_type"] = "from_good_manager" // 货盘管理来源

		if biz_utils.ApiPathMap[bizType] != nil {
			apiDetail = biz_utils.ApiPathMap[bizType].ProdDetailPath
			apiOverall = biz_utils.ApiPathMap[bizType].ProdOverallPath
		}
	} else if isProductSelectBizType(ctx, bizType) {
		apiDetail = "7574446444745163803" // todo 更换
		apiOverall = "7574455148173444147"
	}

	if bizMataInfo != nil && bizMataInfo.EffectModule == "大促视图" {
		params["is_big_activity"] = 1
	}

	if req.PageReq.PageSize > 0 && req.PageReq.PageNum > 0 {
		offset := (req.PageReq.PageNum - 1) * req.PageReq.PageSize
		limit := req.PageReq.PageSize
		params["offset"] = offset
		params["limit"] = limit
	}

	logs.CtxInfo(ctx, "[QueryAnalysisPoolProductList]查询 os api params=%v", params)

	// 查询OneService 货品行为数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, apiDetail, param.SinkTable("product_detail")).SetParallel(true).SetMaxParallelNum(5)
	// 整体信息, 商品总数
	if len(params) > 0 {
		params["select_type"] = "overview_info"
	}
	f.ExeQueryInvokerRaw(params, apiOverall, param.SinkTable("overview_info")).SetParallel(true).SetMaxParallelNum(5)
	f.Call(
		indexCardCom.FlowSplitMetricsToRow(param.SourceTable("product_detail"), param.SinkTable("target_data")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").
			SetDimColumns([]string{"prod_id"}),
	)
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(bizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeProduceSql(`
		select  prod_id,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.display_order as display_order
		from    target_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		`, param.SinkTable("target_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeProduceSql(`
	select  prod_id,
			prod_name,
			shop_id,
			shop_name,
			brand_name,
			complex_brand_s_level as brand_level,
			show_pv,
			pay_ord_cnt as order_num,
			industry_name,
			first_level_cate_name,
			second_level_cate_name,
			leaf_cate_name,
			leaf_cate_id,
			max_show_module,
			(select * from target_data where target_data.prod_id = product_detail.prod_id) as target_list
	from    product_detail
`, param.SinkTable("res_data"))
	f.ExeView(param.SourceTable("res_data"), &productInfoList)
	f.ExeView(param.SourceTable("overview_info"), &overviewInfo)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolProductList]调用OneService失败，err=%v+", err)
		return nil, err
	}

	if _, ok := overviewInfo["product_cnt"]; ok {
		resp.PageInfo.Total = overviewInfo["product_cnt"]
	}
	if shopCnt, ok := overviewInfo["shop_cnt"]; ok {
		resp.ShopCnt = &shopCnt
	}

	if productInfoList == nil || len(productInfoList) == 0 {
		logs.CtxError(ctx, "当前查询条件查询不到商品")
		return resp, nil
	}

	staySearchProductIdStrList := make([]string, 0)
	for _, prodV := range productInfoList {
		staySearchProductIdStrList = append(staySearchProductIdStrList, prodV.ProdId)
	}
	staySearchProductIdList := utils.SliceString2Int64(staySearchProductIdStrList)
	// // staySearchProductIdList长度大于1000截断
	// if len(staySearchProductIdList) > 1000 {
	// 	staySearchProductIdList = staySearchProductIdList[:1000]
	// }
	logs.CtxInfo(ctx, "[QueryAnalysisPoolProductList]调用summary查商品状态 staySearchProductIdList=%v", staySearchProductIdList)

	// 获取商品的信息
	callerInstance := utils.Result[map[int64]*pack_platform.ProductItem](nil)
	productPackInfo := make(map[int64]*pack_platform.ProductItem, 0)
	mutex := new(sync.Mutex)
	asyncCaller := utils.AsyncCaller(func(v any) (map[int64]*pack_platform.ProductItem, error) {
		ids := v.([]int64)
		productHash, err := ecom_product_pack_platform.RPCMGetProduct(ctx, ids)

		if err != nil {
			logs.CtxError(ctx, "[QueryAnalysisPoolProductList]调用ecom_product_pack_platform.RPCMGetProduct失败 ids=%v err=%v", ids, err)
			return nil, err
		}
		mutex.Lock()
		defer mutex.Unlock()
		for key, value := range productHash {
			productPackInfo[key] = value
		}
		return productPackInfo, nil
	}).SetSemaphore(weighted)

	// 获取商品投放状态
	asyncProductOnlineCallerInstance := utils.Result[map[string]bool](nil)
	productOnlineMap := make(map[string]bool, 0)
	mutex2 := new(sync.Mutex)
	asyncProductOnlineCaller := utils.AsyncCaller(func(v any) (map[string]bool, error) {
		ids := v.([]int64)

		// if poolInfo.PoolSource != 0 {
		targets := ConstBusinessMapTarget[convert.ToString(poolInfo.PoolSource)]
		productOnlineReq := &ads_growth_cockpit.ProductOnlineReq{
			ProductIds: utils.TransformIntArrToStringArr(&ids), // rpc参数需要商品id为字符串数组
			Targets:    targets,
		}

		productsOnlineResp, _ := ecom_smartop_ads_growth_cockpit.RawCall.ProductOnline(ctx, productOnlineReq)

		mutex2.Lock()
		defer mutex2.Unlock()
		if len(productsOnlineResp.Data) > 0 {
			for _, productOnlineItem := range productsOnlineResp.Data {
				productOnlineMap[productOnlineItem.ProductId] = productOnlineItem.Online
			}
		}

		if err != nil {
			logs.CtxError(ctx, "[QueryAnalysisPoolProductList]ecom_smartop_ads_growth_cockpit.ProductOnline失败 ids=%v err=%v", ids, err)
			return nil, err
		}
		return productOnlineMap, nil
	}).SetSemaphore(weighted)

	for _, ids := range utils.CutSLice(staySearchProductIdList, 20) {
		callerInstance = asyncCaller.Call(ids)
		asyncProductOnlineCallerInstance = asyncProductOnlineCaller.Call(ids)
	}
	if callerInstance == nil {
		logs.CtxInfo(ctx, "[QueryAnalysisPoolProductList]调用ecom_product_pack_platform.RPCMGetProduct失败 callerInstance为空 ids=%v", staySearchProductIdList)
		return nil, errors.New("调用ecom_product_pack_platform.RPCMGetProduct失败")
	}
	if asyncProductOnlineCallerInstance == nil {
		logs.CtxInfo(ctx, "[QueryAnalysisPoolProductList]调用ecom_smartop_ads_growth_cockpit.ProductOnline失败 callerInstance为空 ids=%v", staySearchProductIdList)
		return nil, errors.New("调用ecom_smartop_ads_growth_cockpit.ProductOnline失败")
	}
	productPackInfo = callerInstance.Value()
	logs.CtxInfo(ctx, "[QueryAnalysisPoolProductList]调用summary查询成功 productPackInfo=%v", productPackInfo)
	productOnlineMap = asyncProductOnlineCallerInstance.Value()
	logs.CtxInfo(ctx, "[QueryAnalysisPoolProductList]调用ecom_smartop_ads_growth_cockpit.ProductOnline查询成功 productOnlineMap=%v", productOnlineMap)

	sellerMerchantProdInfo, err := getPoolRuleSellerMerchantProdInfo(ctx, *poolInfo.PoolId, pidList)
	if err != nil {
		logs.CtxError(ctx, "[QueryAnalysisPoolProductList]getPoolRuleSellerMerchantProdInfo失败，err=%v+", err)
		return nil, err
	}

	// 将Summary信息赋给返回值
	for _, prodV := range productInfoList {
		productId, err := strconv.ParseInt(prodV.ProdId, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[QueryAnalysisPoolProductList]商品ID string转int64失败，err=%v+", err)
			return nil, err
		}
		// 对target_list进行排序
		if len(prodV.TargetList) > 0 {
			sort.Slice(prodV.TargetList, func(i, j int) bool {
				return prodV.TargetList[i].DisplayOrder < prodV.TargetList[j].DisplayOrder
			})
		}

		// 商品是否在线投放
		isDeliveryProduct := productOnlineMap[prodV.ProdId]
		sellerMerchantProdInfoItem := ecom_seller_merchant_dc.SellerMerchantProdInfo{}
		isOk := true
		if len(sellerMerchantProdInfo) > 0 {
			sellerMerchantProdInfoItemInterface := funk.Find(sellerMerchantProdInfo, func(foo ecom_seller_merchant_dc.SellerMerchantProdInfo) bool {
				return foo.ProductId == prodV.ProdId
			})
			if sellerMerchantProdInfoItemInterface != nil {
				sellerMerchantProdInfoItem, isOk = sellerMerchantProdInfoItemInterface.(ecom_seller_merchant_dc.SellerMerchantProdInfo)
				if !isOk {
					sellerMerchantProdInfoItem = ecom_seller_merchant_dc.SellerMerchantProdInfo{}
				}
			}
		}

		resp.List = append(resp.List, &analysis_pool_product.AnalysisPoolProduct{
			ProdId:                    &prodV.ProdId,
			ProdName:                  summary_utils.GetProductName(productId, productPackInfo),
			ProdBgUrl:                 summary_utils.GetProductBgUrl(productId, productPackInfo),
			IsAllowanceProduct:        summary_utils.GetIsAllowanceProduct(productId, productPackInfo),
			IsBrandTrialProduct:       summary_utils.GetIsBrandTrialProduct(productId, productPackInfo),
			IsSeckillProduct:          summary_utils.GetIsSeckillProduct(productId, productPackInfo),
			PurchaseStatus:            summary_utils.GetPurchaseStatus(productId, productPackInfo),
			PurchaseStatusReason:      summary_utils.GetPurchaseStatusReasonDetail(productId, productPackInfo),
			CampaignStockNumSum:       summary_utils.GetCampaignStock(productId, productPackInfo),
			NormalStockNumSum:         summary_utils.GetNormalStock(productId, productPackInfo),
			LeafCateId:                &prodV.LeafCateId,
			LeafCateName:              &prodV.LeafCateName,
			FirstLevelCateName:        &prodV.FirstLevelCateName,
			SecondLevelCateName:       &prodV.SecondLevelCateName,
			IndustryName:              &prodV.IndustryName,
			MaxShowModule:             &prodV.MaxShowModule,
			PoolInfo:                  poolInfo,
			ShopInfo:                  &basic_info.ShopBasicInfo{Id: prodV.ShopId, Name: prodV.ShopName},
			BrandInfo:                 &basic_info.BrandBasicInfo{Name: prodV.BrandName, Level: prodV.BrandLevel},
			TargetList:                prodV.TargetList,
			IsDeliveryProduct:         &isDeliveryProduct,
			SpuEstimatePriceOnlineTag: &sellerMerchantProdInfoItem.SpuEstimatePriceOnlineTag,
		})
	}

	return resp, nil
}

func getPoolRuleSellerMerchantProdInfo(ctx context.Context, pool_id string, pid_list []string) (sellerMerchantProdInfo []ecom_seller_merchant_dc.SellerMerchantProdInfo, err error) {
	analysisPoolAlertRuleDoList := make([]*dao.AnalysisPoolAlertRuleDo, 0)
	sellerMerchantProdInfo = make([]ecom_seller_merchant_dc.SellerMerchantProdInfo, 0)
	activity_ids := make([]string, 0)
	temp_activity_ids := make([]string, 0)
	isOk := true

	err = mysql.DB(ctx).Raw(`
		select alert_rule_id, pool_id, is_analyze_product_status, alert_product_status_rule from analysis_pool_alert_rule where pool_id = ? and is_delete = 0 and is_analyze_product_status = 1
	`, pool_id).Scan(&analysisPoolAlertRuleDoList).Error
	if err != nil {
		return sellerMerchantProdInfo, err
	}

	if len(analysisPoolAlertRuleDoList) == 0 {
		return sellerMerchantProdInfo, nil
	}

	temp_activity_ids, isOk = funk.Reduce(analysisPoolAlertRuleDoList, func(cur []string, rule *dao.AnalysisPoolAlertRuleDo) []string {
		alertProductStatusRule := &alert_rule.AlertProductStatusRule{}
		if rule.AlertProductStatusRule != "" {
			err = json.Unmarshal([]byte(rule.AlertProductStatusRule), &alertProductStatusRule)
			// err = json.Unmarshal([]byte(poolRuleString), &poolRule)
			if err != nil {
				logs.CtxInfo(ctx, "[getPoolRuleSellerMerchantProdInfo] json decode error:%v", err)
			}
		}
		if alertProductStatusRule != nil && alertProductStatusRule.Rules != nil && len(alertProductStatusRule.Rules) > 0 {
			ruleConfig, exist := funk.Find(alertProductStatusRule.Rules, func(ruleConfig *alert_rule.AlertProductStatusRuleItem) bool {
				return ruleConfig.Indicator != nil && *ruleConfig.Indicator == "spu_estimate_use_activity_id"
			}).(*alert_rule.AlertProductStatusRuleItem)
			if exist && ruleConfig != nil {
				cur = append(cur, ruleConfig.Value...)
			}
		}
		return cur
	}, temp_activity_ids).([]string)
	if !isOk {
		temp_activity_ids = make([]string, 0)
	}

	for _, v := range temp_activity_ids {
		if !slices.ContainsString(activity_ids, v) {
			activity_ids = append(activity_ids, v)
		}
	}
	if len(activity_ids) == 0 {
		return sellerMerchantProdInfo, nil
	}

	prodSellerMerchantApplyRecordList, err := ecom_seller_merchant_dc.RPCGetSellerMerchantApplyRecordList(ctx, activity_ids, pid_list)
	if err != nil || len(prodSellerMerchantApplyRecordList) == 0 {
		logs.CtxInfo(ctx, "[getPoolRuleSellerMerchantProdInfo]调用ecom_seller_merchant_dc.RPCGetSellerMerchantApplyRecordList失败, err=%v", err)
		return sellerMerchantProdInfo, err
	}
	logs.CtxInfo(ctx, "[getPoolRuleSellerMerchantProdInfo]调用ecom_seller_merchant_dc.RPCGetSellerMerchantApplyRecordList结果, v=%v", convert.ToJSONString(prodSellerMerchantApplyRecordList))
	sellerMerchantProdInfo, isOk = funk.Reduce(prodSellerMerchantApplyRecordList, func(cur []ecom_seller_merchant_dc.SellerMerchantProdInfo, record *merchant_dc.ApplyRecord) []ecom_seller_merchant_dc.SellerMerchantProdInfo {
		priceTag, exist := record.IndicatorList["price_cmp_result.spu_estimate_price_online_tag"]
		if !exist || priceTag == nil {
			priceTag = &merchant_dc.BriefIndicator{}
		}
		itemId, exist := record.IndicatorList["item_id"]
		if !exist || itemId == nil {
			itemId = &merchant_dc.BriefIndicator{}
		}
		isContainProd := funk.Contains(cur, func(foo ecom_seller_merchant_dc.SellerMerchantProdInfo) bool {
			return itemId != nil && foo.ProductId == itemId.DisplayVal
		})
		if !isContainProd && itemId.Val != nil && priceTag.Val != nil && itemId.Val.StrVal != nil && priceTag.Val.StrVal != nil {
			cur = append(cur, ecom_seller_merchant_dc.SellerMerchantProdInfo{
				ProductId:                 *itemId.Val.StrVal,
				SpuEstimatePriceOnlineTag: *priceTag.Val.StrVal,
			})
		}
		return cur
	}, sellerMerchantProdInfo).([]ecom_seller_merchant_dc.SellerMerchantProdInfo)
	if !isOk {
		sellerMerchantProdInfo = make([]ecom_seller_merchant_dc.SellerMerchantProdInfo, 0)
	}

	return sellerMerchantProdInfo, nil
}

func GetPoolAndPidList(ctx context.Context, pool_id string, alert_msg_id *string) (pidList []string, total int64, poolInfo *analysis_pool.AnalysisPool, err error) {
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[GetPoolAndPidList]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return make([]string, 0), 0, nil, errors.New("获取数据库的事务失败")
	}

	analysisPool, err := dao.GetAnalysisPool(ctx, tx, pool_id)
	if err != nil {
		logs.CtxError(ctx, "[GetPoolAndPidList]查询货盘信息失败，err=%v+", err)
		tx.Rollback()
		return make([]string, 0), 0, analysisPool, err
	}

	if alert_msg_id != nil && *alert_msg_id != "" {
		alertMsgPidList, total, err := dao.GetPidListByAlertMsgId(ctx, tx, *alert_msg_id)
		if err != nil {
			logs.CtxError(ctx, "[GetPoolAndPidList]调用查询预警消息关联商品sql失败，err=%v+", err)
			tx.Rollback()
			return make([]string, 0), 0, analysisPool, err
		}
		// 提交事务
		tx.Commit()
		return alertMsgPidList, total, analysisPool, nil
	} else {
		analysisPoolPidList, total, err := dao.GetAnalysisPoolPidList(ctx, tx, pool_id)
		if err != nil {
			logs.CtxError(ctx, "[GetPoolAndPidList]调用查询货盘商品sql失败，err=%v+", err)
			tx.Rollback()
			return make([]string, 0), 0, analysisPool, err
		}
		// 提交事务
		tx.Commit()
		return analysisPoolPidList, total, analysisPool, nil
	}
}

func getAnalysisPoolProductTrendOsParams(ctx context.Context, bizType dimensions.BizType, queryReq *queryAnalysisPoolProductCommonReq, poolInfo *analysis_pool.AnalysisPool, pidList []string, dimMap map[int64]*dao.DimensionInfo) (params map[string]interface{}, err error) {
	params = make(map[string]interface{})

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "[getAnalysisPoolProductTrendOsParams]业务线未发现元信息, queryReq = %s", convert.ToJSONString(queryReq))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return nil, err
	}
	params["biz_type"] = int64(bizType)
	params["table_name"] = bizInfo.TableName

	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd {
		// 货盘类型是人工录入商品id列表
		cql := sql_parse.NewCQL()
		cql.AddWhere("prod_id", sql_parse.IN, pidList)

		params["filter_param"] = cql.ParseWhereClause()

		dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, *queryReq.StartDate, *queryReq.EndDate)
		if err != nil {
			return nil, err
		}
		params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
		return params, nil
	}
	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule {
		// 货盘类型是货品流量洞察多维分析规则
		dimensionsList := make([]*dimensions.SelectedDimensionInfo, 0)

		// if len(poolInfo.BaseStruct.GroupAttrs) == 0 {
		// 	return nil, errors.New("获取多维分析参数失败")
		// }

		dimensionsList = append(dimensionsList, poolInfo.BaseStruct.Dimensions...)

		// 获取分析的维度信息
		var groupCol string
		enumCodeMap := make(map[string]string)
		for _, attr := range poolInfo.BaseStruct.GroupAttrs {
			// 获取维度的查询字段名
			if attr.DimInfo == nil {
				logs.CtxError(ctx, "未查询到维度信息,DimInfo为空")
				return nil, errors.New("未查询到维度信息,DimInfo为空")
			}
			dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
			if dimInfo == nil {
				logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
				return nil, errors.New("未查询到维度信息")
			}
			// 查询该维度的枚举值
			if len(attr.DimInfo.SelectedValues) > 0 {
				for _, enum := range attr.DimInfo.SelectedValues {
					enumCodeMap[enum.Code] = enum.Name
				}
			}
			if attr.NeedDrillDown {
				dimensionsList = append(dimensionsList, &dimensions.SelectedDimensionInfo{
					Id:               attr.DimInfo.Id,
					Name:             attr.DimInfo.Name,
					AttrType:         attr.DimInfo.AttrType,
					SelectedOperator: attr.DimInfo.SelectedOperator,
					SelectedValues:   []*dimensions.EnumElement{attr.Value},
					IsGroup:          true,
				})
			} else {
				if len(groupCol) == 0 {
					groupCol = dimInfo.DimColumn
				}
				dimensionsList = append(dimensionsList, attr.DimInfo)
			}
		}
		baseStruct := &dimensions.ProductAnalysisBaseStruct{
			BizType:    bizType,
			StartDate:  *queryReq.StartDate,
			EndDate:    *queryReq.EndDate,
			Dimensions: dimensionsList,
			GroupAttrs: poolInfo.BaseStruct.GroupAttrs,
		}

		dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, baseStruct.StartDate, baseStruct.EndDate)
		if err != nil {
			return nil, err
		}
		params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)

		exprCql, _, _, err := base_struct_condition.GetBaseConditionWithDims(ctx, baseStruct, false, dimMap, false, false)
		if err != nil {
			return nil, err
		}
		if exprCql == nil {
			exprCql = sql_parse.NewCQL()
		}

		if exprCql != nil && exprCql.WhereClause != nil {
			whereStr := sql_parse.NewCQL().ParseExpression(exprCql.WhereClause)
			if len(exprCql.RawWhereClause) > 0 {
				whereStr = whereStr + " " + sql_parse.NewCQL().ParseRawExpression(exprCql.RawWhereClause)
			}
			if len(whereStr) > 0 {
				params["filter_param"] = whereStr
			}
		}

		return params, nil
	}
	return params, nil
}

func getQueryAnalysisPoolProductOsParams(ctx context.Context, bizType dimensions.BizType, queryReq *queryAnalysisPoolProductCommonReq, poolInfo *analysis_pool.AnalysisPool, pidList []string, dimMap map[int64]*dao.DimensionInfo) (params map[string]interface{}, err error) {
	params = make(map[string]interface{})
	bizTypeGrowthProductStrategy := dimensions.BizType_GrowthProductStrategy
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "[getQueryAnalysisPoolProductOsParams]业务线未发现元信息, queryReq = %s", convert.ToJSONString(queryReq))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return nil, err
	}

	// 获取大盘表业务线元信息
	bizInfoGrowthProductStrategy, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizTypeGrowthProductStrategy)
	if err != nil || bizInfoGrowthProductStrategy == nil {
		logs.CtxError(ctx, "[getQueryAnalysisPoolProductOsParams]业务线未发现元信息, queryReq = %s", convert.ToJSONString(queryReq))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return nil, err
	}
	params["biz_type"] = int64(bizType)
	params["table_name"] = bizInfo.TableName
	// 算法特征圈品使用大盘表去查商品信息
	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
		params["table_name"] = bizInfoGrowthProductStrategy.TableName
		params["biz_type"] = int64(bizTypeGrowthProductStrategy)
	}

	// 排序逻辑 不传排序参数 默认订单降序排
	orderByField := "pay_ord_cnt"
	orderType := "desc"
	if queryReq.OrderBy != nil {
		if queryReq.OrderBy.IsDesc {
			orderType = "desc"
		} else {
			orderType = "asc"
		}
		if queryReq.OrderBy.ColumnName != nil {
			orderByField = *queryReq.OrderBy.ColumnName
		} else if queryReq.OrderBy.Field != nil {
			switch *queryReq.OrderBy.Field {
			case base.OrderByField_ShowPv:
				orderByField = "show_pv"
			case base.OrderByField_PayOrderNum:
				orderByField = "pay_ord_cnt"
			case base.OrderByField_BrandLevel:
				orderByField = "complex_brand_s_level"
			default:
				orderByField = consts.Empty
			}
		} else {
			return nil, errors.New("order by字段传参有问题，请检查")
		}
	}
	params["order_by"] = fmt.Sprintf("%v %v,prod_id", orderByField, orderType)

	if poolInfo.PoolType == analysis_pool.AnalysisPoolType_FixedProd || (queryReq.AlertMsgId != nil && *queryReq.AlertMsgId != "") {
		// 货盘类型是人工录入商品id列表 或 直接查异常商品id
		cql := sql_parse.NewCQL()
		// todo 查询商品名称 传_会查全部
		if queryReq.ProductName != nil && *queryReq.ProductName != "" {
			cql.AddWhere("prod_name", sql_parse.LIKE, "%"+*queryReq.ProductName+"%")
		}

		if queryReq.ProductId != nil && *queryReq.ProductId != "" && slices.ContainsString(pidList, *queryReq.ProductId) {
			cql.AddWhere("prod_id", sql_parse.IN, []string{*queryReq.ProductId})
		} else {
			cql.AddWhere("prod_id", sql_parse.IN, pidList)
		}

		params["filter_param"] = cql.ParseWhereClause()

		dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, *queryReq.StartDate, *queryReq.EndDate)
		if err != nil {
			return nil, err
		}
		params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
		return params, nil
	}
	if (poolInfo.PoolType == analysis_pool.AnalysisPoolType_DynamicRule || poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature) && !(queryReq.AlertMsgId != nil && *queryReq.AlertMsgId != "") {
		// 货盘类型是货品流量洞察多维分析规则
		dimensionsList := make([]*dimensions.SelectedDimensionInfo, 0)

		// if len(poolInfo.BaseStruct.GroupAttrs) == 0 {
		// 	return nil, errors.New("获取多维分析参数失败")
		// }

		dimensionsList = append(dimensionsList, poolInfo.BaseStruct.Dimensions...)

		// 获取分析的维度信息
		var groupCol string
		enumCodeMap := make(map[string]string)
		for _, attr := range poolInfo.BaseStruct.GroupAttrs {
			// if poolInfo.PoolType == analysis_pool.AnalysisPoolType_AlgorithmFeature {
			// 	break
			// }
			// 获取维度的查询字段名
			if attr.DimInfo == nil {
				logs.CtxError(ctx, "未查询到维度信息,DimInfo为空")
				return nil, errors.New("未查询到维度信息,DimInfo为空")
			}
			dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
			if dimInfo == nil {
				logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
				return nil, errors.New("未查询到维度信息")
			}
			// 查询该维度的枚举值
			if len(attr.DimInfo.SelectedValues) > 0 {
				for _, enum := range attr.DimInfo.SelectedValues {
					enumCodeMap[enum.Code] = enum.Name
				}
			}
			if attr.NeedDrillDown {
				dimensionsList = append(dimensionsList, &dimensions.SelectedDimensionInfo{
					Id:               attr.DimInfo.Id,
					Name:             attr.DimInfo.Name,
					AttrType:         attr.DimInfo.AttrType,
					SelectedOperator: attr.DimInfo.SelectedOperator,
					SelectedValues:   []*dimensions.EnumElement{attr.Value},
					IsGroup:          true,
				})
			} else {
				if len(groupCol) == 0 {
					groupCol = dimInfo.DimColumn
				}
				dimensionsList = append(dimensionsList, attr.DimInfo)
			}
		}

		baseStruct := &dimensions.ProductAnalysisBaseStruct{
			BizType:        bizType,
			StartDate:      *queryReq.StartDate,
			EndDate:        *queryReq.EndDate,
			Dimensions:     dimensionsList,
			GroupAttrs:     poolInfo.BaseStruct.GroupAttrs,
			ThresholdAttrs: poolInfo.BaseStruct.ThresholdAttrs,
		}

		dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, baseStruct.StartDate, baseStruct.EndDate)
		if err != nil {
			return nil, err
		}
		params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)

		exprCql, _, lastVCql, err := base_struct_condition.GetBaseConditionWithDims(ctx, baseStruct, false, dimMap, false, false)
		if err != nil {
			return nil, err
		}

		addLastV := true
		//needShard := true
		// 解析指标阈值信息
		if len(baseStruct.ThresholdAttrs) > 0 {
			thrSelectCql, thrWhereCql, ok := base_struct_condition.GetThresholdAttrs(ctx, baseStruct)
			if ok {
				newWhereCql, _, _, err := base_struct_condition.GetBaseConditionWithDims(ctx, base_struct_condition.GetBaseReqWithoutGroupAttrs(baseStruct),
					//req.IsCompare, req.DimMap, false, req.IsAlertRule
					false, dimMap, false, false,
				)

				if err != nil {
					return nil, err
				}
				if newWhereCql == nil {
					newWhereCql = sql_parse.NewCQL()
				}
				switch baseStruct.ThresholdAttrs[0].Type {
				case dimensions.ThresholdType_ACC_THRESHOLD:
					//subCql.SelectClause = append(subCql.SelectClause, thrSelectCql.SelectClause...)
					//baseCql.AddWhereAndValue(thrWhereCql.WhereClause)
					addLastV = false
					exprCql, err = base_struct_condition.AppendAccGlobalInCql(ctx, thrSelectCql, thrWhereCql, newWhereCql,
						exprCql, lastVCql,
						//startDate, endDate, req.BaseStruct.BizType
						*queryReq.StartDate, *queryReq.EndDate, baseStruct.BizType,
					)
					if err != nil {
						return nil, err
					}
				case dimensions.ThresholdType_TOP_THRESHOLD:
					addLastV = false
					//needShard = false
					exprCql, err = base_struct_condition.AppendTopGlobalInCql(ctx, thrSelectCql, newWhereCql,
						//subExprCql, lastVCql, startDate, endDate
						exprCql, lastVCql, *queryReq.StartDate, *queryReq.EndDate,
					)
					if err != nil {
						return nil, err
					}
				case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
					addLastV = false
					//subExprCql, err = AppendGlobalInCql(ctx, thrSelectCql, thrWhereCql, subExprCql, lastVCql, startDate, endDate)
					//if err != nil {
					//	return nil, err
					//}
				case dimensions.ThresholdType_BIGSALE_HOT_SCORE_THRESHOLD:
					exprCql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, thrSelectCql)
				default:
					logs.CtxError(ctx, "[GetBaseStructConditionCql]ThresholdAttrs empty: %s", convert.ToJSONString(baseStruct))
				}
			}
		}

		if addLastV && lastVCql != nil {
			exprCql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, lastVCql)
		}

		if exprCql == nil {
			exprCql = sql_parse.NewCQL()
		}

		if queryReq.ProductName != nil && *queryReq.ProductName != "" {
			exprCql.AddWhere("prod_name", sql_parse.LIKE, "%"+*queryReq.ProductName+"%")
		}
		if queryReq.ProductId != nil && *queryReq.ProductId != "" {
			exprCql.AddWhere("prod_id", sql_parse.IN, []string{*queryReq.ProductId})
		}

		if exprCql != nil && exprCql.WhereClause != nil {
			whereStr := exprCql.ParseAllWhereExpression()
			//whereStr := sql_parse.NewCQL().ParseExpression(exprCql.WhereClause)
			//if len(exprCql.RawWhereClause) > 0 {
			//	whereStr = whereStr + " " + sql_parse.NewCQL().ParseRawExpression(exprCql.RawWhereClause)
			//}
			if len(whereStr) > 0 {
				bizMetaInfo := biz_utils.GetBizMetaInfoFromContext(ctx)
				if bizMetaInfo != nil && bizMetaInfo.EffectModule == "大促视图" {
					for _, replaceKey := range base_struct_condition.BigactSignStatusReplaceList {
						replaceValue, exist := base_struct_condition.BigactSignStatusReplaceMap[replaceKey]
						if !exist {
							logs.CtxError(ctx, "未找到大促报名状态替换值，key=%s", replaceKey)
							continue
						}
						whereStr = strings.ReplaceAll(whereStr, replaceKey, replaceValue)
					}
				}
				params["filter_param"] = whereStr
			}
		}

		return params, nil
	}
	return params, nil
}

func getProductMultiDimParams(ctx context.Context, osParamsReq *base_struct_condition.OsParamsReq, prodId string) (params map[string]interface{}, err error) {
	params = make(map[string]interface{})

	dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, osParamsReq.BaseStruct.StartDate, osParamsReq.BaseStruct.EndDate)
	if err != nil {
		return nil, err
	}
	params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)

	exprCql, _, _, err := base_struct_condition.GetBaseConditionWithDims(ctx, osParamsReq.BaseStruct, false, osParamsReq.DimMap, false, false)
	if err != nil {
		return nil, err
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}
	// 仅查询单品
	exprCql.AddWhere(consts.ProductID, sql_parse.EQUAL, prodId)
	if exprCql != nil && exprCql.WhereClause != nil {
		whereStr := sql_parse.NewCQL().ParseExpression(exprCql.WhereClause)
		if len(exprCql.RawWhereClause) > 0 {
			whereStr = whereStr + " " + sql_parse.NewCQL().ParseRawExpression(exprCql.RawWhereClause)
		}
		if len(whereStr) > 0 {
			params["filter_param"] = whereStr
		}
	}
	params["dimension"] = strings.Join(osParamsReq.MultiDimension, ",")

	return params, nil
}

func getProductMultiDimMergeData(ctx context.Context, osParamsReq *base_struct_condition.OsParamsReq, prodId string) (record *analysis_pool_product.AnalysisPoolProduct, err error) {
	params := make(map[string]interface{})
	records := make([]*analysis_pool_product.AnalysisPoolProduct, 0)

	dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, osParamsReq.BaseStruct.StartDate, osParamsReq.BaseStruct.EndDate)
	if err != nil {
		return nil, err
	}
	params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)

	cql := sql_parse.NewCQL()
	// 仅查询单品
	cql.AddWhere(consts.ProductID, sql_parse.EQUAL, prodId)
	params["filter_param"] = cql.ParseWhereClause()
	var apiPath string
	if osParamsReq.BaseStruct.BizType == dimensions.BizType_GreatValueBuy {
		apiPath = apiPathInsightBillProductMultiDim
	} else if biz_utils.IsUseGrowthProductStrategyTable(osParamsReq.BaseStruct.BizType) {
		apiPath = apiPathInsightScenarioProductMultiDim
	}

	// 查询OneService 货品行为数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// apiPath需要根据货盘的bizType区分
	f.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("product_bhv_di"))
	f.ExeView(param.SourceTable("product_bhv_di"), &records)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[getProductMultiDimMergeData]调用OneService查询单品数据失败，err=%v+", err)
		return nil, err
	}

	if len(records) == 0 {
		return &analysis_pool_product.AnalysisPoolProduct{}, nil
	}

	return records[0], nil
}

func getProductMultiDimMergeRecord(ctx context.Context, osParamsReq *base_struct_condition.OsParamsReq, prodId string) (record map[string]interface{}, err error) {
	params := make(map[string]interface{})
	records := make([]map[string]interface{}, 0)
	dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, osParamsReq.BaseStruct.StartDate, osParamsReq.BaseStruct.EndDate)
	if err != nil {
		return nil, err
	}
	params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)

	cql := sql_parse.NewCQL()
	// 仅查询单品
	cql.AddWhere(consts.ProductID, sql_parse.EQUAL, prodId)
	params["filter_param"] = cql.ParseWhereClause()

	var apiPath string

	if osParamsReq.BaseStruct.BizType == dimensions.BizType_GreatValueBuy {
		apiPath = apiPathInsightBillProductMultiDim
	} else if biz_utils.IsUseGrowthProductStrategyTable(osParamsReq.BaseStruct.BizType) {
		apiPath = apiPathInsightScenarioProductMultiDim
	}

	records, err = base_struct_condition.GetRecordsByOS(ctx, params, consts.Empty, apiPath)
	if err != nil {
		return nil, err
	}

	if len(records) == 0 {
		return make(map[string]interface{}), nil
	}
	return records[0], nil
}

func getMultiDimDocHeader(ctx context.Context, groupAttrs []*dimensions.SelectedMultiDimensionInfo, dimMap map[int64]*dao.DimensionInfo) ([]*multiHeaderStruct, error) {
	docHeader := make([]*multiHeaderStruct, 0) // 文档表头
	for _, attr := range groupAttrs {
		// 获取维度的查询字段名
		if attr.DimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,DimInfo为空")
			return docHeader, errors.New("未查询到维度信息,DimInfo为空")
		}
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return docHeader, errors.New("未查询到维度信息")
		}
		docHeader = append(docHeader, &multiHeaderStruct{
			Name:    dimInfo.ShowName,
			ColName: dimInfo.DimColumn,
		})
	}

	return docHeader, nil
}

func getMultiDimDownloadData(ctx context.Context, dimColEnumCodeMap map[string]map[string]string, groupCols []string, table *onetable.Table, totalTargetMap map[string]interface{}) (*onetable.Table, error) {
	if len(table.ToRawMap()) > 10000 {
		return nil, errors.New("MAX_10000_LIMIT_ERROR")
	}
	outMap := make(map[string]map[string]interface{}, 0)
	dimKeyList := make([]string, 0)
	for _, infoMap := range table.ToRawMap() {
		dimKey := convert.ToString(infoMap["dim_key"])
		if len(strings.ReplaceAll(dimKey, "#", "")) == 0 {
			continue
		}

		dimKeyList = append(dimKeyList, dimKey)
		outV, exist := outMap[dimKey]
		if !exist {
			outV = make(map[string]interface{})
		}
		for _, c := range groupCols {
			enumCode := convert.ToString(infoMap[c])
			enumMap, existEnumMap := dimColEnumCodeMap[c]
			if !existEnumMap {
				outV[c] = "-"
			} else if enumValue, existEnumV := enumMap[enumCode]; existEnumV {
				outV[c] = enumValue
			} else {
				outV[c] = "-"
			}
		}

		for col, value := range infoMap {
			if !slices.ContainsString(groupCols, col) && col != "dim_key" {
				outV[convert.ToString(col)] = value
			}
		}
		outMap[dimKey] = outV
	}

	dimKeyList = slices.DistinctString(dimKeyList)
	sort.Strings(dimKeyList)
	out := make([]map[string]interface{}, 0)
	out = append(out, totalTargetMap)
	for _, dimKey := range dimKeyList {
		out = append(out, outMap[dimKey])
	}
	return onetable.NewTable(out), nil
}

func getProductInfoMergeBhv(ctx context.Context, productBhvData *onetable.Table, needSummary bool) ([]DownloadProductDetail, error) {
	weighted := semaphore.NewWeighted(50)
	productDataList := make([]DownloadProductDetail, 0)
	productBhvDataMap := productBhvData.ToRawMap()
	staySearchProductIdStrList := make([]string, 0)
	for _, prodV := range productBhvDataMap {
		prodId := prodV["prod_id"]
		prodIdDecimal, isOk := prodId.(decimal.Decimal)
		if !isOk {
			continue
		}
		staySearchProductIdStrList = append(staySearchProductIdStrList, fmt.Sprintf("%v", prodIdDecimal))
	}
	staySearchProductIdList := utils.SliceString2Int64(staySearchProductIdStrList)
	// // staySearchProductIdList长度大于1000截断
	// if len(staySearchProductIdList) > 1000 {
	// 	staySearchProductIdList = staySearchProductIdList[:1000]
	// }
	// 获取商品的信息
	productPackInfo := make(map[int64]*pack_platform.ProductItem, 0)
	if needSummary {
		callerInstance := utils.Result[map[int64]*pack_platform.ProductItem](nil)
		mutex := new(sync.Mutex)
		asyncCaller := utils.AsyncCaller(func(v any) (map[int64]*pack_platform.ProductItem, error) {
			ids, isOk := v.([]int64)
			if !isOk {
				logs.CtxError(ctx, "[getProductInfoMergeBhv]调用ecom_product_pack_platform.RPCMGetProduct失败前数据转换失败 v=%v", v)
				return nil, errors.New("数据转换失败")
			}
			productHash, err := ecom_product_pack_platform.RPCMGetProduct(ctx, ids)
			if err != nil {
				logs.CtxError(ctx, "[getProductInfoMergeBhv]调用ecom_product_pack_platform.RPCMGetProduct失败 ids=%v err=%v", ids, err)
				return nil, err
			}
			mutex.Lock()
			defer mutex.Unlock()
			for key, value := range productHash {
				productPackInfo[key] = value
			}
			return productPackInfo, nil
		}).SetSemaphore(weighted)
		for _, ids := range utils.CutSLice(staySearchProductIdList, 20) {
			callerInstance = asyncCaller.Call(ids)
		}
		if callerInstance == nil {
			logs.CtxInfo(ctx, "[getProductInfoMergeBhv]调用ecom_product_pack_platform.RPCMGetProduct失败 callerInstance为空 ids=%v", staySearchProductIdList)
			return nil, errors.New("调用ecom_product_pack_platform.RPCMGetProduct失败")
		}
		productPackInfo = callerInstance.Value()
	}
	logs.CtxInfo(ctx, "[getProductInfoMergeBhv]调用summary查询成功 productPackInfo=%v", productPackInfo)

	// 将Summary信息赋给返回值
	for _, prodV := range productBhvDataMap {
		productIdStr := fmt.Sprintf("%v", prodV["prod_id"])
		maxShowModule := fmt.Sprintf("%v", prodV["max_show_module"])
		productId, err := strconv.ParseInt(productIdStr, 10, 64)
		if err != nil {
			logs.CtxInfo(ctx, "[getProductInfoMergeBhv]调用ecom_product_pack_platform.RPCMGetProduct失败 productId转换失败 productIdStr=%v", productIdStr)
			return nil, errors.New("调用ecom_product_pack_platform.RPCMGetProduct失败")
		}
		showPvStr := fmt.Sprintf("%v", prodV["show_pv"])
		clickPvStr := fmt.Sprintf("%v", prodV["click_pv"])
		payOrdCntStr := fmt.Sprintf("%v", prodV["pay_ord_cnt"])
		payGmvStr := fmt.Sprintf("%v", prodV["pay_gmv"])
		opmStr := fmt.Sprintf("%v", prodV["opm"])
		gpmStr := fmt.Sprintf("%v", prodV["gpm"])
		ctrStr := fmt.Sprintf("%v", prodV["ctr"])
		cvrStr := fmt.Sprintf("%v", prodV["cvr"])
		pvrStr := fmt.Sprintf("%v", prodV["pvr"])
		avgOrderGmvStr := fmt.Sprintf("%v", prodV["avg_order_gmv"])
		industryNameStr := fmt.Sprintf("%v", prodV["industry_name"])
		firstLevelCateNameStr := fmt.Sprintf("%v", prodV["first_level_cate_name"])
		secondLevelCateNameStr := fmt.Sprintf("%v", prodV["second_level_cate_name"])
		leafCateNameStr := fmt.Sprintf("%v", prodV["leaf_cate_name"])
		shopNameStr := fmt.Sprintf("%v", prodV["shop_name"])
		brandNameStr := fmt.Sprintf("%v", prodV["brand_name"])
		brandLevelStr := fmt.Sprintf("%v", prodV["complex_brand_s_level"])
		isAllowanceProduct := summary_utils.GetIsAllowanceProduct(productId, productPackInfo)
		isAllowanceProductString := utils.TransformBoolToString(isAllowanceProduct)
		isBrandTrialProduct := summary_utils.GetIsBrandTrialProduct(productId, productPackInfo)
		isBrandTrialProductString := utils.TransformBoolToString(isBrandTrialProduct)
		isSeckillProduct := summary_utils.GetIsSeckillProduct(productId, productPackInfo)
		isSeckillProductString := utils.TransformBoolToString(isSeckillProduct)
		purchaseStatus := summary_utils.GetPurchaseStatus(productId, productPackInfo)
		purchaseStatusString := utils.TransformBoolToString(purchaseStatus)
		productDataList = append(productDataList, DownloadProductDetail{
			ProdId:               &productIdStr,
			ProdName:             summary_utils.GetProductName(productId, productPackInfo),
			IsAllowanceProduct:   &isAllowanceProductString,
			IsBrandTrialProduct:  &isBrandTrialProductString,
			IsSeckillProduct:     &isSeckillProductString,
			PurchaseStatus:       &purchaseStatusString,
			PurchaseStatusReason: summary_utils.GetPurchaseStatusReasonDetail(productId, productPackInfo),
			CampaignStockNumSum:  summary_utils.GetCampaignStock(productId, productPackInfo),
			NormalStockNumSum:    summary_utils.GetNormalStock(productId, productPackInfo),
			IndustryName:         &industryNameStr,
			FirstLevelCateName:   &firstLevelCateNameStr,
			SecondLevelCateName:  &secondLevelCateNameStr,
			LeafCateName:         &leafCateNameStr,
			ShopName:             &shopNameStr,
			BrandName:            &brandNameStr,
			ComplexBrandSLevel:   &brandLevelStr,
			ShowPv:               &showPvStr,
			MaxShowModule:        &maxShowModule,
			ClickPv:              &clickPvStr,
			PayOrdCnt:            &payOrdCntStr,
			PayGmv:               &payGmvStr,
			Opm:                  &opmStr,
			Gpm:                  &gpmStr,
			Ctr:                  &ctrStr,
			Cvr:                  &cvrStr,
			Pvr:                  &pvrStr,
			AvgOrderGmv:          &avgOrderGmvStr,
		})
		if err != nil {
			return nil, err
		}
	}

	return productDataList, nil
}

func doMultiDimDownloadExport(ctx context.Context, table *onetable.Table, email string, docHeader *onetable.Table, targetMetaMap map[string]*dao.TargetMetaInfo, groupCols []string, req *analysis_pool_product.DownloadProductMultiDimReq) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	if docHeader == nil || len(docHeader.ToRawMap()) == 0 || table == nil || len(table.ToRawMap()) == 0 {
		return nil, formatter.Export(ctx, email, nil, nil)
	}

	tableMap := table.ToRawMap()
	targetRawMap := make([]map[string]interface{}, 0)
	for col, _ := range tableMap[0] {
		if !slices.ContainsString(groupCols, col) {
			metaInfo, exist := targetMetaMap[col]
			if exist {
				targetRawMap = append(targetRawMap, map[string]interface{}{
					"display_order": metaInfo.DisplayOrder,
					"name":          metaInfo.DisplayName,
					"col_name":      metaInfo.Name,
				})
			}
		}
	}

	sort.Slice(targetRawMap, func(i, j int) bool {
		valueI := convert.ToInt64(targetRawMap[i]["display_order"])
		valueJ := convert.ToInt64(targetRawMap[j]["display_order"])
		return valueI < valueJ
	})

	sheet := lark_export.NewLarkDocSheet("单品多维分析", table)
	sheet.AddHead([][]string{{"统计周期", fmt.Sprintf("%s 00:00:00 - %s 23:59:59", *req.StartDate, *req.EndDate)}, {"商品ID", req.ProductId}})
	for _, h := range docHeader.ToRawMap() {
		sheet.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
	}
	for _, h := range targetRawMap {
		sheet.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "单品多维分析")
	return nil, formatter.Export(ctx, email, nil, nil)
}

func doAnalysisPoolProductDownloadExport(ctx context.Context, productExportData *onetable.Table, email string, targetMetaMap map[string]*dao.TargetMetaInfo) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	if productExportData == nil || len(productExportData.ToRawMap()) == 0 {
		return nil, formatter.Export(ctx, email, nil, nil)
	}

	productExportDataMap := productExportData.ToRawMap()
	targetRawMap := make([]map[string]interface{}, 0)
	for col, _ := range productExportDataMap[0] {
		metaInfo, exist := targetMetaMap[col]
		if exist {
			targetRawMap = append(targetRawMap, map[string]interface{}{
				"display_order": metaInfo.DisplayOrder,
				"name":          metaInfo.DisplayName,
				"col_name":      metaInfo.Name,
			})
		}
	}

	sort.Slice(targetRawMap, func(i, j int) bool {
		valueI := convert.ToInt64(targetRawMap[i]["display_order"])
		valueJ := convert.ToInt64(targetRawMap[j]["display_order"])
		return valueI < valueJ
	})

	sheet := lark_export.NewLarkDocSheet("监控商品明细", productExportData)
	sheet.AddColumn("商品ID", "prod_id")
	sheet.AddColumn("商品名称", "prod_name")
	sheet.AddColumn("曝光集中", "max_show_module")
	sheet.AddColumn("当前活动库存", "campaign_stock_num_sum")
	sheet.AddColumn("当前普通库存", "normal_stock_num_sum")
	sheet.AddColumn("当前是否可售", "purchase_status")
	sheet.AddColumn("当前不可售原因", "purchase_status_reason")
	sheet.AddColumn("当前是否参加超值购", "is_allowance_product")
	sheet.AddColumn("当前是否参加大牌试用", "is_brand_trial_product")
	sheet.AddColumn("当前是否参加秒杀", "is_seckill_product")
	for _, h := range targetRawMap {
		sheet.AddColumn(convert.ToString(h["name"]), convert.ToString(h["col_name"]))
	}
	sheet.AddColumn("垂类", "industry_name").
		AddColumn("一级类目", "first_level_cate_name").
		AddColumn("二级类目", "second_level_cate_name").
		AddColumn("叶子类目", "leaf_cate_name").
		AddColumn("所属商家", "shop_name").
		AddColumn("所属品牌", "brand_name").
		AddColumn("品牌等级", "complex_brand_s_level")
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "监控商品明细")
	return nil, formatter.Export(ctx, email, nil, nil)
}

// generateAnalysisPoolProductCSVData 生成分析池商品的CSV格式数据
func generateAnalysisPoolProductCSVData(ctx context.Context, productExportData *onetable.Table, targetMetaMap map[string]*dao.TargetMetaInfo) ([]byte, error) {
	// 参数校验
	if productExportData == nil || len(productExportData.ToRawMap()) == 0 {
		logs.CtxWarn(ctx, "[generateAnalysisPoolProductCSVData] 没有数据可导出")
		return nil, errors.New("没有数据可导出")
	}

	// 初始化CSV生成环境
	// 创建内存缓冲区
	buf := &bytes.Buffer{}
	// 写入UTF-8 BOM以确保Excel正确识别中文
	buf.WriteString("\xEF\xBB\xBF")
	// 创建CSV写入器
	writer := csv.NewWriter(buf)
	defer writer.Flush()

	// 获取数据并准备处理
	productExportDataMap := productExportData.ToRawMap()

	// 准备列名映射（中文表头 -> 字段名）
	columnMap := map[string]string{
		"商品ID":               "prod_id",
		"商品名称":             "prod_name",
		"曝光集中":             "max_show_module",
		"当前活动库存":         "campaign_stock_num_sum",
		"当前普通库存":         "normal_stock_num_sum",
		"当前是否可售":         "purchase_status",
		"当前不可售原因":       "purchase_status_reason",
		"当前是否参加超值购":   "is_allowance_product",
		"当前是否参加大牌试用": "is_brand_trial_product",
		"当前是否参加秒杀":     "is_seckill_product",
		"垂类":                 "industry_name",
		"一级类目":             "first_level_cate_name",
		"二级类目":             "second_level_cate_name",
		"叶子类目":             "leaf_cate_name",
		"所属商家":             "shop_name",
		"所属品牌":             "brand_name",
		"品牌等级":             "complex_brand_s_level",
	}

	// 获取并处理指标列
	targetRawMap := make([]map[string]interface{}, 0)
	// 遍历第一行数据的列，找到所有指标列
	if len(productExportDataMap) > 0 {
		for col := range productExportDataMap[0] {
			metaInfo, exist := targetMetaMap[col]
			if exist {
				targetRawMap = append(targetRawMap, map[string]interface{}{
					"display_order": metaInfo.DisplayOrder,
					"name":          metaInfo.DisplayName,
					"col_name":      metaInfo.Name,
				})
			}
		}
	}

	// 按显示顺序排序指标列
	sort.Slice(targetRawMap, func(i, j int) bool {
		valueI := convert.ToInt64(targetRawMap[i]["display_order"])
		valueJ := convert.ToInt64(targetRawMap[j]["display_order"])
		return valueI < valueJ
	})

	// 构建表头和字段名列表
	var headers []string    // 存储CSV表头（中文）
	var fieldNames []string // 存储对应的字段名

	// 添加固定列（基本信息列）
	for header, fieldName := range columnMap {
		headers = append(headers, header)
		fieldNames = append(fieldNames, fieldName)
	}

	// 添加指标列
	for _, h := range targetRawMap {
		headers = append(headers, convert.ToString(h["name"]))
		fieldNames = append(fieldNames, convert.ToString(h["col_name"]))
	}

	// 写入表头
	if err := writer.Write(headers); err != nil {
		logs.CtxError(ctx, "[generateAnalysisPoolProductCSVData] 写入CSV表头失败: %v", err)
		return nil, fmt.Errorf("写入CSV表头失败: %v", err)
	}

	// 写入数据行
	totalRows := len(productExportDataMap)
	for index, row := range productExportDataMap {
		// 每10000行记录一次进度，避免日志过多
		if index%10000 == 0 {
			logs.CtxInfo(ctx, "[generateAnalysisPoolProductCSVData] 处理进度: %d/%d", index, totalRows)
		}

		// 构建一行CSV数据
		var csvRow []string
		for _, fieldName := range fieldNames {
			// 获取字段值并转换为字符串
			if val, ok := row[fieldName]; ok {
				csvRow = append(csvRow, convert.ToString(val))
			} else {
				// 字段不存在时，使用空字符串
				csvRow = append(csvRow, "")
			}
		}

		// 写入一行数据
		if err := writer.Write(csvRow); err != nil {
			logs.CtxError(ctx, "[generateAnalysisPoolProductCSVData] 写入CSV数据行失败，行索引: %d, 错误: %v", index, err)
			return nil, fmt.Errorf("写入CSV数据行失败，行索引: %d, 错误: %v", index, err)
		}
	}

	// 确保所有数据都被写入缓冲区
	writer.Flush()
	if err := writer.Error(); err != nil {
		logs.CtxError(ctx, "[generateAnalysisPoolProductCSVData] 刷新CSV写入器失败: %v", err)
		return nil, fmt.Errorf("刷新CSV写入器失败: %v", err)
	}

	return buf.Bytes(), nil
}
