package analysis_pool_product_service

// oneService注册的sqlApiPath
const (
	// 超值购底表-监控商品明细行为数据查询（废弃）
	apiPathBillionProductList = "7376621906763596850"
	// 超值购底表-可用数据时间查询（废弃）
	apiPathAvailableDateRange = "7379545544370209818"
	// 货品流量洞察-超值购用增底表-监控商品明细行为数据查询（废弃）
	apiPathInsightBillionProductList = "7394412605709796362"
	// 货品流量洞察-超值购用增底表-单品多维分析
	apiPathInsightBillProductMultiDim = "7394610901023867914"
	// 货品流量洞察-大盘用增底表-监控商品明细行为数据查询（废弃）
	apiPathInsightScenarioProductList = "7394414074454475786"
	// 货品流量洞察-大盘用增底表-单品多维分析
	apiPathInsightScenarioProductMultiDim = "7397009886149624882"
	// 监控商品明细总体数据
	apiPathProductOverall = "7372153638862537754"
	// 监控商品明细数据（目前在用）
	apiPathProductDerail = "7405128960100549670"
	// 监控货盘趋势数据
	apiPathPoolTrend = "7408770732970345482"
)

var ConstBusinessMapTarget = map[string][]int64 { 
	"1": { 4002, 4006, 4011 }, // 秒杀频道对应target
	"2": { 4001, 4008, 4010 }, // 超值购频道对应target
 }