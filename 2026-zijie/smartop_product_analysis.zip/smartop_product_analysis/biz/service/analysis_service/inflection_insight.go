package analysis_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"errors"
	"fmt"
	"math"
	"sort"
	"strconv"
)

func (d *AnalysisService) InflectionPointInsight(ctx context.Context, req *analysis.InflectionPointInsightRequest) (resp *analysis.InflectionPointInsightData, err error) {
	// 校验参数
	resp = &analysis.InflectionPointInsightData{}

	inflectionPointInsightList, err := GetInflectionPointInsight(ctx, req.ProductLabels, req.TopDimensions)
	if err != nil {
		return nil, err
	}

	if req.PageReq == nil || req.PageReq.PageNum <= 0 || req.PageReq.PageSize <= 0 {
		req.PageReq = &base.PageInfo{
			PageNum:  1,
			PageSize: 10,
		}
	}
	resList, _ := slices.PageInplace(inflectionPointInsightList, int(req.PageReq.PageNum), int(req.PageReq.PageSize))
	fullList, ok := resList.([]*analysis.MultiDimFullListRow)
	if !ok {
		return nil, errors.New("分页失败")
	}
	resp.FullList = fullList
	resp.PageInfo = &base.PageResp{
		PageNum:  req.PageReq.PageNum,
		PageSize: req.PageReq.PageSize,
		Total:    int64(len(inflectionPointInsightList)),
	}
	return
}

func (d *AnalysisService) InflectionPointInsightDownload(ctx context.Context, req *analysis.InflectionPointInsightDownloadRequest) (hasSend bool, err error) {
	inflectionPointInsightList, err := GetInflectionPointInsight(ctx, req.ProductLabels, req.TopDimensions)
	if err != nil {
		return false, err
	}

	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}

	if env.IsBoe() {
		email = "zouguoxue@bytedance.com"
	}

	// 数据转换
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryCustom([]param.Source{param.SourceConst(inflectionPointInsightList), param.SourceConst(req.DownloadDimensionName)}, getInflectionPointInsightData, param.SinkTable("inflection_point_insight_data"))
	f.ExeCustom([]param.Source{param.SourceTable("inflection_point_insight_data"), param.SourceConst(email)}, doInflectionPointInsightExport, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}

	logs.CtxInfo(ctx, "inflectionPointInsightList download complete!")
	return true, nil

}

func doInflectionPointInsightExport(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("拐点洞察", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("维度", "维度").
		AddColumn("拐点位置", "拐点位置").
		AddColumn("拐点区分的正向品比例", "拐点区分的正向品比例").
		AddColumn("拐点明显度得分（KS值）", "拐点明显度得分（KS值）")

	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}

func GetInflectionPointInsight(ctx context.Context, productLabels []*analysis.ProductLabel, topDimensions int64) ([]*analysis.MultiDimFullListRow, error) {
	if len(productLabels) == 0 {
		return nil, errors.New("拐点洞察失败，请录入商品ID和商品标签")
	}
	productIds := make([]int64, 0)
	productLabelsMap := make(map[string]int64, 0)
	for _, productInfo := range productLabels {
		productId, err := utils.String2Int64(productInfo.ProductId)
		if err != nil || productId < 100000000000000000 {
			logs.CtxWarn(ctx, "存在商品ID格式错误,问题商品ID为: %s", productInfo.ProductId)
			return nil, errors.New(fmt.Sprintf("存在商品ID格式错误,问题商品ID为: %s", productInfo.ProductId))
		}
		if productInfo.Label != 0 && productInfo.Label != 1 {
			logs.CtxWarn(ctx, "存在商品标签格式错误,问题商品ID为: %v, label为: %v", productInfo.ProductId, productInfo.Label)
			return nil, errors.New("存在商品标签格式错误")
		}
		productIds = append(productIds, productId)
		productLabelsMap[productInfo.ProductId] = int64(productInfo.Label)
	}
	tableConf, err := tcc.GetInflectionPointTableConfig(ctx)

	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	if tableConf == nil {
		logs.CtxError(ctx, "GetInflectionPointTableConfig Error, cluster_switch_conf")
		return nil, errors.New("GetInflectionPointTableConfig Error, cluster_switch_conf")
	}
	ApiInflectionPointInsight := tableConf.Api

	params := map[string]interface{}{
		"prod_ids": productIds,
	}
	inflectData := make([]map[string]interface{}, 0)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, ApiInflectionPointInsight, param.SinkTable("inflection")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeView(param.SourceTable("inflection"), &inflectData)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	for _, respItem := range inflectData {
		productId := convert.ToString(respItem["prod_id"])
		if label, ok := productLabelsMap[productId]; ok {
			respItem["label"] = label
		}
	}
	logs.CtxInfo(ctx, "inflectionPointInsight data get complete!")
	// 3. 组装结果
	topDimList, err := calcKSValue(ctx, inflectData, topDimensions)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return topDimList, nil
}

func getInflectionPointInsightData(ctx context.Context, inflectionPointInsightList []*analysis.MultiDimFullListRow, targetDimName string) (*onetable.Table, error) {
	table := make([]map[string]interface{}, 0)
	for _, info := range inflectionPointInsightList {
		if targetDimName != "" && info.EnumValue != targetDimName {
			continue
		}
		row := make(map[string]interface{})
		row["维度"] = info.DisplayName
		for _, target := range info.Children {
			if target.DisplayName == "拐点位置" {
				row["拐点位置"] = target.EnumValue
			}
			if target.DisplayName == "拐点区分的正向品比例" {
				row["拐点区分的正向品比例"] = target.EnumValue
			}
			if target.DisplayName == "拐点明显度得分（KS值）" {
				row["拐点明显度得分（KS值）"] = target.EnumValue
			}
		}
		table = append(table, row)
	}
	return onetable.NewTable(table), nil
}

func calcKSValue(ctx context.Context, productInfo []map[string]interface{}, limit int64) ([]*analysis.MultiDimFullListRow, error) {
	// 计算ks值
	var err error
	// 获取业务线的维度信息
	_, dimColMap, err := biz_utils.GetDimMapAndColMapByBiz(ctx, dimensions.BizType_InflectionInsight)
	if err != nil {
		return nil, err
	}

	// 1. 拆分维度数据
	productInfoMap := make(map[string][]map[string]interface{})
	for _, item := range productInfo {
		for k, v := range item {
			if k == "prod_id" || k == "label" {
				continue
			}
			if _, ok := dimColMap[k]; !ok {
				logs.CtxError(ctx, "拐点分析维度错误，: %s", convert.ToJSONString(k))
				continue
			}
			itemTemp := map[string]interface{}{}
			itemTemp["type"] = k
			itemTemp["name"] = dimColMap[k].ShowName
			itemTemp["value"] = v
			itemTemp["prod_id"] = item["prod_id"]
			itemTemp["label"] = item["label"]
			productInfoMap[k] = append(productInfoMap[k], itemTemp)
		}
	}
	// 2. 计算最大ks值
	ksMAxValueMaxMap := map[string]map[string]interface{}{}
	for k, v := range productInfoMap {
		ksMAxValueMaxMap[k], err = calcKSValueMax(ctx, v)
		if err != nil {
			return nil, err
		}
	}
	logs.CtxInfo(ctx, "KS值计算完成！")
	// 3. 排序
	ksValueMaxList := make([]map[string]interface{}, 0)
	for _, v := range ksMAxValueMaxMap {
		ksValueMaxList = append(ksValueMaxList, v)
	}
	sort.SliceStable(ksValueMaxList, func(i, j int) bool {
		if ksValueMaxList[i]["ks_value"].(float64) == ksValueMaxList[j]["ks_value"].(float64) {
			return ksValueMaxList[i]["name"].(string) > ksValueMaxList[j]["name"].(string)
		}
		return ksValueMaxList[i]["ks_value"].(float64) > ksValueMaxList[j]["ks_value"].(float64)
	})
	// 4. 截取
	if limit <= int64(len(ksValueMaxList)) {
		ksValueMaxList = ksValueMaxList[:limit]
	}
	resp := make([]*analysis.MultiDimFullListRow, 0)
	var inflectionLocationFormat string
	for _, v := range ksValueMaxList {
		if _, ok := dimColMap[v["type"].(string)]; !ok {
			logs.CtxError(ctx, "拐点分析维度错误，: %v", convert.ToJSONString(v))
			continue
		}
		switch dimColMap[v["type"].(string)].ProcessType {
		case SimilarProductDimType_asc_layer:
			inflectionLocationFormat = InflectionLocationFormatAsc
		case SimilarProductDimType_desc_layer:
			inflectionLocationFormat = InflectionLocationFormatDesc
		case SimilarProductDimType_bool:
			inflectionLocationFormat = InflectionLocationFormatBool
		default:
			logs.CtxError(ctx, "拐点分析维度类型错误: %v", convert.ToJSONString(v))
			continue
		}
		resp = append(resp, &analysis.MultiDimFullListRow{
			DisplayName: convert.ToString(v["name"]),
			EnumValue:   convert.ToString(v["type"]),
			Children: []*analysis.MultiDimFullListRow{
				{
					DisplayName: "拐点位置",
					EnumValue:   fmt.Sprintf(inflectionLocationFormat, formatSimilarValueStr(v["value"]), formatSimilarValueStr(v["value"])),
				},
				{
					DisplayName: "拐点区分的正向品比例",
					EnumValue:   fmt.Sprintf("%.2f", v["positive_rate"]),
				},
				{
					DisplayName: "拐点明显度得分（KS值）",
					EnumValue:   fmt.Sprintf("%.3f", v["ks_value"]),
				},
			},
		})
	}
	return resp, nil
}

func calcKSValueMax(ctx context.Context, ksInfo []map[string]interface{}) (map[string]interface{}, error) {
	// 计算ks值
	if len(ksInfo) == 0 {
		logs.CtxWarn(ctx, "拐点分析失败，数据为空")
		return nil, errors.New("拐点分析失败，数据为空")
	}
	// 1. 排序
	sort.SliceStable(ksInfo, func(i, j int) bool {
		if convert.ToString(ksInfo[i]["value"]) == convert.ToString(ksInfo[j]["value"]) {
			return compareSimilarValue(ksInfo[i]["prod_id"], ksInfo[j]["prod_id"])
		}
		return !compareSimilarValue(ksInfo[i]["value"], ksInfo[j]["value"])
	})
	// 2.计算正负向数量
	positiveTotal := 0
	negativeTotal := 0
	for _, v := range ksInfo {
		if v["label"].(int64) == 1 {
			positiveTotal++
		} else {
			negativeTotal++
		}
	}
	if positiveTotal == 0 || negativeTotal == 0 {
		logs.CtxWarn(ctx, "拐点分析失败，正/负向商品数量为0")
		return nil, errors.New("拐点分析失败，正/负向商品数量为0")
	}
	// 3.计算累计正负向比例
	positiveNum := 0
	negativeNum := 0
	for i, v := range ksInfo {
		if v["label"].(int64) == 1 {
			positiveNum++
		} else {
			negativeNum++
		}
		positiveRate := float64(positiveNum) / float64(positiveTotal)
		negativeRate := float64(negativeNum) / float64(negativeTotal)
		ksInfo[i]["positive_rate"] = positiveRate
		ksInfo[i]["negative_rate"] = negativeRate
		ksInfo[i]["ks_value"] = math.Abs(positiveRate - negativeRate)
	}
	// 4. 排序
	sort.SliceStable(ksInfo, func(i, j int) bool {
		// 比较 ks_value 字段
		return ksInfo[i]["ks_value"].(float64) > ksInfo[j]["ks_value"].(float64)
	})
	return ksInfo[0], nil
}

func formatSimilarValueStr(v interface{}) string {
	s := convert.ToString(v)
	f, err := strconv.ParseFloat(s, 64)
	if err == nil {
		if float64(int(f)) == f {
			return fmt.Sprintf("%d", int(f))
		} else {
			return fmt.Sprintf("%.2f", f)
		}
	} else {
		return s
	}
}

func compareSimilarValue(v1, v2 interface{}) bool {
	// 目前只支持数字、浮点数、字符串
	s1 := convert.ToString(v1)
	s2 := convert.ToString(v2)
	num1, err1 := strconv.ParseFloat(s1, 64)
	num2, err2 := strconv.ParseFloat(s2, 64)
	if err1 == nil && err2 == nil {
		return num1 > num2
	}

	int1, err1 := strconv.Atoi(s1)
	int2, err2 := strconv.Atoi(s2)
	if err1 == nil && err2 == nil {
		return int1 > int2
	}

	return s1 > s2
}
