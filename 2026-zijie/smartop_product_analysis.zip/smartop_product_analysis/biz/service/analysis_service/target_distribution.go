package analysis_service

import (
	"code.byted.org/aweme-go/hstruct/cast"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/leekchan/accounting"
	"github.com/shopspring/decimal"
	"sort"
	"strconv"
)

func GetDistributionDim(bizType dimensions.BizType) []string {
	if bizType == dimensions.BizType_DouyineMallCommerce || bizType == dimensions.BizType_DouyineCommerce || bizType == dimensions.BizType_BrandTrial || bizType == dimensions.BizType_MatchingBrain {
		return []string{"pay_ord_cnt_belt", "show_pv_belt"}
	} else {
		return []string{"product_price_belt", "pay_ord_cnt_belt", "show_pv_belt"}
	}
}

type unitMetaInfo struct {
	TargetName string `json:"target_name"`
	Unit       string `json:"unit"`
	Precision  int    `json:"precision"` // 小数位数
}

var DistributionUnitMap = map[string]unitMetaInfo{
	"show_pv":            {Unit: "万", Precision: 1},
	"pay_prod_cnt":       {Unit: "万", Precision: 1},
	"prod_avg_ord_cnt":   {Unit: "单", Precision: 1},
	"pay_ord_cnt":        {Unit: "万", Precision: 1},
	"opm":                {Unit: "单", Precision: 2},
	"prod_pay_show_rate": {Unit: "%", Precision: 1},
}

var less10kUnitMap = map[string]string{
	"show_pv":      "次",
	"pay_prod_cnt": "个",
	"pay_ord_cnt":  "单",
}

func GetDistributionDisplayValue(value interface{}, targetName string) (string, error) {
	if value == nil {
		return "0", nil
	}
	// 开发框架数据的类型为decimal.Decimal，没法用cast直接转型，这里尝试把value转为Float64
	if temp, ok := value.(decimal.Decimal); ok {
		value, _ = temp.Float64()
	}
	var unit string
	var precision int
	if _, ok := DistributionUnitMap[targetName]; ok {
		unit = DistributionUnitMap[targetName].Unit
		precision = DistributionUnitMap[targetName].Precision
	} else {
		return "", errors.New("未找到匹配的指标元信息")
	}
	ac := &accounting.Accounting{Precision: precision} // Precision 小数精度
	if targetName == "show_pv" || targetName == "pay_prod_cnt" || targetName == "pay_ord_cnt" {
		if cast.ToFloat64(value) >= 10000 {
			return framework_udf.DeleteZeroSuffix(ac.FormatMoney(cast.ToFloat64(value) / 10000)), nil
		} else {
			return framework_udf.DeleteZeroSuffix(ac.FormatMoney(value)), nil
		}
	} else if targetName == "prod_avg_ord_cnt" || targetName == "opm" {
		return framework_udf.DeleteZeroSuffix(ac.FormatMoney(value)), nil
	} else {
		return framework_udf.DeleteZeroSuffix(strconv.FormatFloat(cast.ToFloat64(value)*100, 'f', precision, 64)) + unit, nil
	}
}

func addUnit(resp []*analysis.GetProductAnalysisCoreHierarchicalInfo) {
	for _, info := range resp {
		if _, ok := DistributionUnitMap[info.Name]; ok {
			if info.Name == "show_pv" || info.Name == "pay_prod_cnt" || info.Name == "pay_ord_cnt" {
				info.Unit = DistributionUnitMap[info.Name].Unit
				var less10kUnit string
				if _, ok2 := less10kUnitMap[info.Name]; ok2 {
					less10kUnit = less10kUnitMap[info.Name]
				}
				for _, dimEntity := range info.DimHierarchical {
					for _, entity := range dimEntity.Hierarchical {
						if entity.Value < 10000 {
							info.Unit = less10kUnit
							break
						}
					}
				}
				if info.Unit == "万" {
					continue
				}
				// 展示值因为有部分单元格 value 小于10000时，单位改为"次"，此时需要在大于10000的单元格后补 万 的单位
				for _, dimEntity := range info.DimHierarchical {
					for _, entity := range dimEntity.Hierarchical {
						if entity.Value >= 10000 {
							entity.DisplayValue += "万"
						}
					}
				}
				// 大盘的展示值也需要按这个逻辑处理
				if info.Value >= 10000 {
					info.DisplayValue += "万"
				}
			} else {
				info.Unit = DistributionUnitMap[info.Name].Unit
			}
		}
	}
}

func (d *AnalysisService) GetProductAnalysisCoreHierarchical(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp []*analysis.GetProductAnalysisCoreHierarchicalInfo, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreHierarchical]获取map失败，err=%v+", err)
		return nil, err
	}
	// 获取invoker的入参
	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	priceRageDim, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(consts.PriceRangeDim))
	if err != nil {
		return
	}

	priceNameMap := make(map[string]string)
	if priceRageDim != nil && len(priceRageDim.Values) > 0 {
		for _, v := range priceRageDim.Values {
			priceNameMap[v.Code] = v.Name
		}
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(req.BizType), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 不做group by的大盘数据(此大盘指不带group by，并不是剔除所有筛选条件)
	curr["dimension"] = nil
	f.ExeQueryInvokerRaw(curr, ApiPathDistribution, param.SinkTable("whole_target")).SetParallel(true).SetMaxParallelNum(10)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("whole_target"), param.SinkTable("whole_target")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	distributionDim := GetDistributionDim(req.BizType)
	for _, dim := range distributionDim {
		// group by的维度替换为dim, 单数分层和曝光pv分层需要在sql中处理，并不是底表已有维度
		if dim == "product_price_belt" || dim == "price_range" {
			curr["dimension"] = dim
			curr["distribution"] = nil
		} else {
			curr["dimension"] = nil
			curr["distribution"] = dim
		}
		f.ExeQueryInvokerRaw(curr, ApiPathDistribution, param.SinkTable(dim+"_table")).SetParallel(true).SetMaxParallelNum(10)
		// 行转列
		f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable(dim+"_table"), param.SinkTable(dim+"_table")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").
			SetDimColumns([]string{"dimension"}))
		// 拼接维度名
		f.ExeProduceSql(fmt.Sprintf(`select *, '%v' as dimension_name from %v`, dim, dim+"_table"), param.SinkTable(dim+"_table"))
	}
	var sql string
	for i, dim := range distributionDim {
		if i > 0 {
			sql += " union all "
		}
		sql += fmt.Sprintf(`select * from %v`, dim+"_table")
	}
	f.ExeProduceSql(sql, param.SinkTable("union_table"))
	// 关联指标元信息表和大盘指标表
	f.ExeProduceSql(`
		select  a.target_name as target_name,
				a.target_value as value,
				c.target_value as whole_value,
				get_display_value(c.target_value, b.name) as whole_display_value,
				case when b.is_compute_percent = true then a.target_value/c.target_value else 0 end as ratio,
				get_display_value(a.target_value, b.name) as display_value,
				dimension,
				dimension_name,
				b.display_name as display_name,
				b.is_compute_percent as show_percent_flag
		from    union_table a
		inner join target_meta b
		on a.target_name = b.name
		inner join whole_target c
		on a.target_name = c.target_name
		`, param.SinkTable("union_table")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(GetDistributionDisplayValue), // 格式化展示值
	})
	// 获取所有指标类型，存到一张表中
	f.ExeProduceSql(`select target_name, dimension_name from union_table group by target_name, dimension_name`, param.SinkTable("target_dim_meta"))
	f.ExeProduceSql(`
		select  target_name,
				display_name,
				show_percent_flag,
				max(whole_value) as value,
				get_max_row(whole_display_value) as display_value
		from    union_table
		group by target_name,display_name,show_percent_flag`, param.SinkTable("target_info_meta")).SetUdfs(
		map[string]*onetable.UdfFunction{
			"get_max_row": onetable.AggregateFunc(framework_udf.GetMaxStr),
		})
	f.ExeProduceSql(`
		select  target_name,
				dimension_name,
				(
					select  dimension as name,
							value,
							display_value,
							ratio
					from    union_table a
					where   a.target_name = target_dim_meta.target_name
					and     a.dimension_name = target_dim_meta.dimension_name
				) as hierarchical
		from    target_dim_meta`, param.SinkTable("target_dim_data"))
	f.ExeProduceSql(`
		select  target_name as name,
				display_name,
				show_percent_flag,
				value,
				display_value,
				(
					select  dimension_name as name,
							get_dimension_display_name(dimension_name) as display_name,
							hierarchical
					from	target_dim_data a
					where 	a.target_name = target_info_meta.target_name
				) as dim_hierarchical
		from    target_info_meta`, param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_dimension_display_name": onetable.NormalFunc(framework_udf.GetDimensionDisplayName), // 格式化展示值
	})
	resp = make([]*analysis.GetProductAnalysisCoreHierarchicalInfo, 0)
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	sortDistribution(resp, priceNameMap)
	addUnit(resp)
	return resp, nil
}

func sortDistribution(resp []*analysis.GetProductAnalysisCoreHierarchicalInfo, priceNameMap map[string]string) {
	// 指定顺序
	targetOrder := map[string]int{"show_pv": 1, "show_prod_cnt": 2, "pay_prod_cnt": 3, "prod_avg_ord_cnt": 4, "pay_ord_cnt": 5}
	dimensionOrder := map[string]int{"product_price_belt": 1, "pay_ord_cnt_belt": 2, "show_pv_belt": 3, "price_range": 4}

	// 绝对值价格带需要做一下字段名映射
	for _, targetInfo := range resp {
		sort.Slice(targetInfo.DimHierarchical, func(i, j int) bool {
			// 获取每个元素的排序权重，使用order映射
			// 如果元素不在order中，给一个默认高值保证它排在最后
			rankI, okI := dimensionOrder[targetInfo.DimHierarchical[i].Name]
			if !okI {
				rankI = len(dimensionOrder) + 1
			}
			rankJ, okJ := dimensionOrder[targetInfo.DimHierarchical[j].Name]
			if !okJ {
				rankJ = len(dimensionOrder) + 1
			}
			return rankI < rankJ
		})

		for _, entity := range targetInfo.DimHierarchical {
			if entity.Name == "price_range" {
				entity.IsShow = false // 绝对值价格带不展示
				for _, dimEnum := range entity.Hierarchical {
					if _, ok := priceNameMap[dimEnum.Name]; ok {
						dimEnum.Name = priceNameMap[dimEnum.Name]
					}
				}
				sort.Slice(entity.Hierarchical, func(i, j int) bool {
					return entity.Hierarchical[i].Value > entity.Hierarchical[j].Value
				})
			} else {
				entity.IsShow = true // 其余分层需要展示数据
			}
		}
	}
	sort.Slice(resp, func(i, j int) bool {
		// 获取每个元素的排序权重，使用order映射
		// 如果元素不在order中，给一个默认高值保证它排在最后
		rankI, okI := targetOrder[resp[i].Name]
		if !okI {
			rankI = len(targetOrder) + 1
		}
		rankJ, okJ := targetOrder[resp[j].Name]
		if !okJ {
			rankJ = len(targetOrder) + 1
		}
		return rankI < rankJ
	})
}
