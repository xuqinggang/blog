package analysis_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_product_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/facility/set"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/jinzhu/copier"
	"sort"
	"strings"
)

func (d *AnalysisService) GetSimilarProduct(ctx context.Context, req *analysis.GetSimilarProductRequest) (resp *analysis.GetSimilarProductResponseItem, err error) {
	// 校验参数
	resp = &analysis.GetSimilarProductResponseItem{}
	var seedPoolId, similarPoolId string
	if len(req.SeedPoolIds) > 0 && req.SeedPoolIds[0] != "" {
		seedPoolId = req.SeedPoolIds[0]
	}
	if len(req.SimilarPoolIds) > 0 && req.SimilarPoolIds[0] != "" {
		similarPoolId = req.SimilarPoolIds[0]
	}
	similarProductList, passSeedIds, noPassSeedIds, _, _, _, err := GetSimilarProductDomain(ctx, &GetSimilarProductCommonReq{
		BaseReq:                 req.BaseReq,
		SeedProdIds:             req.SeedProdIds,
		SeedPoolId:              seedPoolId,
		SimilarProdIds:          req.SimilarProdIds,
		SimilarPoolId:           similarPoolId,
		SeedFilterDimensions:    req.SeedFilterDimensions,
		SimilarFilterDimensions: req.SimilarFilterDimensions,
		SimilarCountLimit:       req.SimilarCountLimit,
	})
	if err != nil {
		return
	}
	// 分页
	if req.PageReq == nil || req.PageReq.PageNum <= 0 || req.PageReq.PageSize <= 0 {
		req.PageReq = &base.PageInfo{
			PageNum:  1,
			PageSize: 10,
		}
	}
	similarProductListLimit, _ := slices.PageInplace(similarProductList, int(req.PageReq.PageNum), int(req.PageReq.PageSize))
	similarProductPageList, ok := similarProductListLimit.([]*analysis.GetSimilarProductItem)
	if !ok {
		return nil, errors.New("分页失败")
	}
	resp.SimilarProductList = similarProductPageList
	resp.PassSeedCnt = passSeedIds
	resp.NoPassSeedCnt = noPassSeedIds

	resp.PageInfo = &base.PageResp{
		PageNum:  req.PageReq.PageNum,
		PageSize: req.PageReq.PageSize,
		Total:    int64(len(similarProductList)),
	}
	return
}

func (d *AnalysisService) GetSimilarProductDownload(ctx context.Context, req *analysis.GetSimilarProductDownloadRequest) (hasSend bool, err error) {
	var seedPoolId, similarPoolId string
	if len(req.SeedPoolIds) > 0 && req.SeedPoolIds[0] != "" {
		seedPoolId = req.SeedPoolIds[0]
	}
	if len(req.SimilarPoolIds) > 0 && req.SimilarPoolIds[0] != "" {
		similarPoolId = req.SimilarPoolIds[0]
	}
	similarProductList, _, _, _, _, filteredSeedProdIdInfo, err := GetSimilarProductDomain(ctx, &GetSimilarProductCommonReq{
		BaseReq:                 req.BaseReq,
		SeedProdIds:             req.SeedProdIds,
		SeedPoolId:              seedPoolId,
		SimilarProdIds:          req.SimilarProdIds,
		SimilarPoolId:           similarPoolId,
		SeedFilterDimensions:    req.SeedFilterDimensions,
		SimilarFilterDimensions: req.SimilarFilterDimensions,
		SimilarCountLimit:       req.SimilarCountLimit,
	})
	if err != nil {
		return false, err
	}
	logs.CtxInfo(ctx, "获取种子商品过滤结果成功，开始导出")
	// 导出
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "获取用户邮箱失败")
		return false, err
	}

	if env.IsBoe() {
		email = "zouguoxue@bytedance.com"
	}

	// 数据转换
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryCustom([]param.Source{param.SourceConst(similarProductList), param.SourceConst(filteredSeedProdIdInfo), param.SourceConst(req.IsDownloadSeedFilteredDetail)}, getSimilarExportData, param.SinkTable("similar_data"))
	f.ExeCustom([]param.Source{param.SourceTable("similar_data"), param.SourceConst(email), param.SourceConst(req.IsDownloadSeedFilteredDetail)}, doGetSimilarProductExport, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	logs.CtxInfo(ctx, "导出成功")
	return true, nil
}

func (d *AnalysisService) CreateGetSimilarProductPool(ctx context.Context, req *analysis.CreateGetSimilarProductPoolRequest) (poolId string, err error) {
	var seedPoolId, similarPoolId string
	if len(req.SeedPoolIds) > 0 && req.SeedPoolIds[0] != "" {
		seedPoolId = req.SeedPoolIds[0]
	}
	if len(req.SimilarPoolIds) > 0 && req.SimilarPoolIds[0] != "" {
		similarPoolId = req.SimilarPoolIds[0]
	}

	_, _, _, validSeedIds, validSimilarIds, _, err := GetSimilarProductDomain(ctx, &GetSimilarProductCommonReq{
		BaseReq:                 req.BaseReq,
		SeedProdIds:             req.SeedProdIds,
		SeedPoolId:              seedPoolId,
		SimilarProdIds:          req.SimilarProdIds,
		SimilarPoolId:           similarPoolId,
		SeedFilterDimensions:    req.SeedFilterDimensions,
		SimilarFilterDimensions: req.SimilarFilterDimensions,
		SimilarCountLimit:       req.SimilarCountLimit,
	})
	if err != nil {
		return "", err
	}
	logs.CtxInfo(ctx, "获取种子商品过滤结果成功，开始创建货盘")
	var pidList string
	switch req.CreateType {
	case 1:
		// 创建种子商品池
		pidList = strings.Join(validSeedIds, ",")
	case 2:
		// 创建相似商品池
		pidList = strings.Join(validSimilarIds, ",")
	default:
		return "", errors.New("创建类型错误")
	}
	if len(pidList) == 0 {
		return "", errors.New("创建货盘失败，种子品/相似品为空")
	}
	createPoolReq := &analysis_pool.CreateAnalysisPoolReq{
		PoolName:   req.PoolName,
		PoolSource: analysis_pool.PoolSource_SimilarProduct,
		PoolType:   analysis_pool_service.PRODUCT_POOL_TYPE,
		PidList:    &pidList,
	}
	poolId, err = new(analysis_pool_service.AnalysisPoolService).CreateAnalysisPool(ctx, createPoolReq)
	if err != nil {
		return "", err
	}
	logs.CtxInfo(ctx, "创建货盘成功，poolId=%v", poolId)
	return poolId, nil
}

func GetSeedProdIdsAndDetail(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, prodIds []string, poolId string) ([]string, map[string]*analysis.MultiDimProductInfo, []string, error) {
	if len(prodIds) > 0 && prodIds[0] != "" {
		for _, seedProdId := range prodIds {
			pid, err := utils.String2Int64(seedProdId)
			if err != nil || pid < 100000000000000000 {
				logs.CtxWarn(ctx, "存在商品ID格式错误,问题商品ID为: %v", seedProdId)
				return nil, nil, nil, errors.New(fmt.Sprintf("存在商品ID格式错误,问题商品ID为: %v", seedProdId))
			}
		}
		prodDetailMap, prodDetailIds, err := GetProdDetail(ctx, prodIds, nil, req)
		return prodIds, prodDetailMap, prodDetailIds, err
	}

	if len(poolId) > 0 && poolId != "" {
		pidList, _, poolInfo, err := analysis_pool_product_service.GetPoolAndPidList(ctx, poolId, nil)
		if err != nil {
			return nil, nil, nil, err
		}
		prodDetailMap, prodDetailIds, err := GetProdDetail(ctx, pidList, poolInfo, req)
		return pidList, prodDetailMap, prodDetailIds, err
	}
	logs.CtxError(ctx, "获取种子商品参数错误, 参数为：%v", convert.ToJSONString(req))
	return nil, nil, nil, errors.New("获取种子商品参数错误")
}

func GetProdDetail(ctx context.Context, productIds []string, poolInfo *analysis_pool.AnalysisPool, req *dimensions.ProductAnalysisBaseStruct) (productDetailMap map[string]*analysis.MultiDimProductInfo, pids []string, err error) {
	productDetailMap = make(map[string]*analysis.MultiDimProductInfo)
	pids = make([]string, 0)
	if len(productIds) == 0 && poolInfo == nil {
		return
	}
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return nil, nil, err
	}
	// 相似品的维度信息可能包含货盘的维度，需要将这些维度信息也加入到dimMap中
	dimMap, _, err := biz_utils.GetDimMapAndColMapByBiz(ctx, req.BizType)
	if err != nil {
		return nil, nil, err
	}

	// 补全参数
	params := make(map[string]interface{})
	params["table_name"] = bizInfo.TableName
	params["biz_type"] = int64(req.BizType)
	params["start_date"] = req.StartDate
	params["end_date"] = req.EndDate

	dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, req.StartDate, req.EndDate)
	if err != nil {
		return nil, nil, err
	}
	params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
	//params["limit"] = 1000
	//params["offset"] = 0

	// 货盘维度信息
	if poolInfo != nil && poolInfo.PoolType == 1 {
		poolFilter := []*dimensions.SelectedDimensionInfo{
			{
				Id:               consts.CustomProductPool,
				AttrType:         dimensions.DimensionAttributeType_Product,
				SelectedOperator: base.OperatorType_IN,
				SelectedValues:   []*dimensions.EnumElement{{Code: poolInfo.GetPoolId()}},
			},
		}
		req.Dimensions = append(req.Dimensions, poolFilter...)
	}
	exprCql, _, _, err := base_struct_condition.GetBaseConditionWithDims(ctx, req, false, dimMap, false, false)
	if err != nil {
		return nil, nil, err
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}

	// 额外的商品ID信息
	if len(productIds) > 0 {
		exprCql.AddWhere("prod_id", sql_parse.IN, productIds)
	}

	if exprCql != nil && exprCql.WhereClause != nil {
		whereStr := exprCql.ParseAllWhereExpression()
		if len(whereStr) > 0 {
			params["filter_param"] = whereStr
		}
	}
	logs.CtxInfo(ctx, "获取商品明细参数成功，params = %s", convert.ToJSONString(params))
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, ApiPathProductDetail, param.SinkTable("product_detail")).SetParallel(true).SetMaxParallelNum(5)
	// 输入商品id信息，拿到商品图片信息
	f.ExeProduceCustom([]param.Source{param.SourceTable("product_detail")}, AddProductImage, param.SinkTable("product_images"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("product_detail"), param.SinkTable("target_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"prod_id"}))
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{"指标卡", "商品明细"})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeProduceSql(`
		select  prod_id,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.display_order as display_order
		from    target_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		`, param.SinkTable("target_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeProduceSql(`
		select  a.prod_id as prod_id,
				a.prod_name as prod_name,
				b.images as prod_images,
				shop_id,
				shop_name,
				brand_name,
				complex_brand_s_level as brand_level,
				show_pv,
				pay_ord_cnt as order_num,
				industry_name,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name,
				(select * from target_data where target_data.prod_id = product_detail.prod_id) as target_list
		from    product_detail a
		left join
				product_images b
		on      a.prod_id=b.prod_id
	`, param.SinkTable("res_data"))
	var productInfoList = make([]*ProductInfo, 0)
	f.ExeView(param.SourceTable("res_data"), &productInfoList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, nil, err
	}

	for _, productInfo := range productInfoList {
		sort.SliceStable(productInfo.TargetList, func(i, j int) bool {
			return productInfo.TargetList[i].DisplayName < productInfo.TargetList[j].DisplayName
		})
		multiDimProductInfo := &analysis.MultiDimProductInfo{
			ProductInfo: &basic_info.ProductBasicInfo{
				Id:     productInfo.ProdId,
				Name:   productInfo.ProdName,
				Images: productInfo.ProdImages,
			},
			ShowPv:              productInfo.ShowPv,
			FirstLevelCateName:  productInfo.FirstLevelCateName,
			SecondLevelCateName: productInfo.SecondLevelCateName,
			TargetList:          productInfo.TargetList,
		}
		pids = append(pids, productInfo.ProdId)
		productDetailMap[productInfo.ProdId] = multiDimProductInfo
	}
	pids = slices.DistinctString(pids)
	return
}

func GetSimilarProductDomain(ctx context.Context, req *GetSimilarProductCommonReq) ([]*analysis.GetSimilarProductItem, int64, int64, []string, []string, map[string]string, error) {
	// 参数校验
	if req == nil {
		return nil, 0, 0, nil, nil, nil, errors.New("请求参数为空")
	}
	if len(req.SeedProdIds) == 0 && req.SeedPoolId == "" {
		return nil, 0, 0, nil, nil, nil, errors.New("种子商品查询失败，请录入种子商品ID或种子商品池ID")
	}

	if req.SimilarCountLimit == 0 || req.SimilarCountLimit > 5 {
		// 默认返回5个相似品
		req.SimilarCountLimit = 5
	}

	filteredSeedProd := make(map[string]string)
	// 1. 提取种子商品和相似商品ID
	seedProdBaseReq := &dimensions.ProductAnalysisBaseStruct{}
	_ = copier.CopyWithOption(&seedProdBaseReq, req.BaseReq, copier.Option{DeepCopy: true})
	_ = copier.CopyWithOption(&seedProdBaseReq.Dimensions, req.SeedFilterDimensions, copier.Option{DeepCopy: true})
	reqSeedProdIds, seedProdDetailMap, _, err := GetSeedProdIdsAndDetail(ctx, seedProdBaseReq, req.SeedProdIds, req.SeedPoolId)
	if err != nil {
		return nil, 0, 0, nil, nil, nil, err
	}

	var similarProdMatchType GetSimilarProdMatchType
	reqSimilarProdIds, similarPoolInfo, err := extractProductIdsAndPoolInfo(ctx, req.SimilarProdIds, req.SimilarPoolId)
	if err != nil {
		return nil, 0, 0, nil, nil, nil, err
	}
	if len(reqSimilarProdIds) > 0 {
		similarProdMatchType = GetSimilarProdMatchType_SimProdIds
	}

	if len(reqSeedProdIds) == 0 {
		logs.CtxError(ctx, "相似商品查询失败,种子商品ID为空")
		return nil, 0, 0, nil, nil, nil, errors.New("相似商品查询失败,种子商品ID为空")
	}
	//logs.CtxInfo(ctx, "种子商品池ID和相似商品池ID转商品ID后,种子商品ID为: %v,相似商品ID为: %v", convert.ToJSONString(reqSeedProdIds), convert.ToJSONString(reqSimilarProdIds))

	// 种子商品ID和相似商品ID去重&构造set
	reqSeedProdIds = slices.DistinctString(reqSeedProdIds)
	reqSimilarProdIds = slices.DistinctString(reqSimilarProdIds)

	seedProdIdSet := set.NewStringSet()
	similarProdIdSet := set.NewStringSet()
	for _, seedProdId := range reqSeedProdIds {
		seedProdIdSet.Add(seedProdId)
	}
	for _, similarProdId := range reqSimilarProdIds {
		similarProdIdSet.Add(similarProdId)
	}
	tableConf, err := tcc.GetSimilarProductTableConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, 0, 0, nil, nil, nil, err
	}
	if tableConf == nil || tableConf.Api == "" {
		logs.CtxError(ctx, "similar_product table config is nil or api is empty")
		return nil, 0, 0, nil, nil, nil, errors.New("similar_product table config is nil or api is empty")
	}
	ApiGetSimilarProduct := tableConf.Api
	// 获取种子商品的相似商品
	// 2. 获取种子商品的相似商品id
	params := map[string]interface{}{
		"prod_ids": reqSeedProdIds,
	}
	res := make([]*SimilarProductsData, 0)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, ApiGetSimilarProduct, param.SinkTable("similar_product")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeView(param.SourceTable("similar_product"), &res)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, 0, 0, nil, nil, nil, err
	}

	for _, info := range res {
		similarProdList := make([]*SimilarProductInfo, 0)
		similarProductsStr := info.SimilarProductsStr
		// 解析相似商品id
		err = json.Unmarshal([]byte(similarProductsStr), &similarProdList)
		info.SimilarProducts = similarProdList
	}

	// 种子品的相似商品id过滤（过滤掉种子商品和不在相似商品池的商品）
	filteredRes := make([]*SimilarProductsData, 0)
	passPayUVFilterSeedIdSet := set.NewStringSet()
	passInputIdFilterSimilarIdSet := set.NewStringSet()
	passSeedIds := make([]string, 0)
	passSimilarIds := make([]string, 0)
	for _, seedSimilarRelation := range res {
		passPayUVFilterSeedIdSet.Add(seedSimilarRelation.SeedProductId)
		similarProdListTemp := make([]*SimilarProductInfo, 0)
		similarProductsRelation := seedSimilarRelation.SimilarProducts
		sort.SliceStable(similarProductsRelation, func(i, j int) bool {
			return similarProductsRelation[i].SimilarScore > similarProductsRelation[j].SimilarScore
		})
		for _, similarProdInfo := range similarProductsRelation {
			if !seedProdIdSet.Contains(convert.ToString(similarProdInfo.ProductId)) && (similarProdMatchType != GetSimilarProdMatchType_SimProdIds || similarProdIdSet.Contains(convert.ToString(similarProdInfo.ProductId))) {
				similarProdListTemp = append(similarProdListTemp, similarProdInfo)
				passInputIdFilterSimilarIdSet.Add(convert.ToString(similarProdInfo.ProductId))
				passSimilarIds = append(passSimilarIds, convert.ToString(similarProdInfo.ProductId))
			}
			if len(similarProdListTemp) >= int(req.SimilarCountLimit) {
				break
			}
		}
		if len(similarProdListTemp) > 0 {
			filteredRes = append(filteredRes, &SimilarProductsData{
				SeedProductId:   seedSimilarRelation.SeedProductId,
				SimilarProducts: similarProdListTemp,
			})
			passSeedIds = append(passSeedIds, seedSimilarRelation.SeedProductId)
		}
	}
	if len(reqSimilarProdIds) > 0 && len(passSimilarIds) == 0 {
		logs.CtxError(ctx, "相似商品查询失败,相似品池ID下没有通过筛选的相似品")
		return nil, 0, 0, nil, nil, nil, errors.New("相似商品查询失败,相似品池ID下没有通过筛选的相似品")
	}
	passSimilarIds = slices.DistinctString(passSimilarIds)
	// 3. 获取相似商品的属性
	similarProdReq := &dimensions.ProductAnalysisBaseStruct{}
	_ = copier.CopyWithOption(&similarProdReq, req.BaseReq, copier.Option{DeepCopy: true})
	_ = copier.CopyWithOption(&similarProdReq.Dimensions, req.SimilarFilterDimensions, copier.Option{DeepCopy: true})
	similarProdDetailMap, _, similarDetailErr := GetProdDetail(ctx, passSimilarIds, similarPoolInfo, similarProdReq)

	if similarDetailErr != nil || similarProdDetailMap == nil {
		logs.CtxError(ctx, "获取相似品详情失败，err: %v", similarDetailErr)
		return nil, 0, 0, nil, nil, nil, similarDetailErr
	}
	logs.CtxInfo(ctx, "获取相似品详情成功!")
	// 4. 打包结果
	similarProductList, validSeedIds, validSimilarIds, err := PackSimilarResponseData(ctx, filteredRes, seedProdDetailMap, similarProdDetailMap, req.SimilarCountLimit)
	if err != nil {
		logs.CtxError(ctx, "打包相似品详情失败，err: %v", err)
		return nil, 0, 0, nil, nil, nil, err
	}
	logs.CtxInfo(ctx, "打包相似品详情成功!")
	// 打包未通过GMV过滤的种子商品
	for _, id := range reqSeedProdIds {
		if !passPayUVFilterSeedIdSet.Contains(id) {
			filteredSeedProd[id] = "未通过近30天支付UV>200过滤"
			continue
		}
		if !slices.ContainsString(passSeedIds, id) {
			filteredSeedProd[id] = "相似品在种子品池中被过滤"
			continue
		}
		if _, ok := seedProdDetailMap[id]; !ok {
			filteredSeedProd[id] = "种子品详情获取失败/被筛选条件过滤"
			continue
		}
		if !slices.ContainsString(validSeedIds, id) {
			filteredSeedProd[id] = "相似度前N个相似品获取详情失败/被筛选条件过滤"
			continue
		}
	}
	passSeedCnt := int64(len(passSeedIds))
	noPassSeedCnt := int64(len(reqSeedProdIds)) - int64(len(passSeedIds))
	return similarProductList, passSeedCnt, noPassSeedCnt, validSeedIds, validSimilarIds, filteredSeedProd, nil
}

func PackSimilarResponseData(ctx context.Context, similarInfos []*SimilarProductsData, seedProdDetailMap map[string]*analysis.MultiDimProductInfo, similarProdDetailMap map[string]*analysis.MultiDimProductInfo, similarCountLimit int64) ([]*analysis.GetSimilarProductItem, []string, []string, error) {
	similarProductList := make([]*analysis.GetSimilarProductItem, 0)
	validSeedIds := make([]string, 0)
	validSimilarIds := make([]string, 0)
	for _, similarInfo := range similarInfos {
		if len(similarInfo.SimilarProducts) == 0 {
			continue
		}
		if _, ok := seedProdDetailMap[similarInfo.SeedProductId]; !ok {
			continue
		}
		similarProductTmpList := make([]*analysis.GetSimilarProductItem, 0)
		for _, similarProd := range similarInfo.SimilarProducts {
			similarProduct, ok := similarProdDetailMap[convert.ToString(similarProd.ProductId)]
			if ok {
				similarProductTmpList = append(similarProductTmpList, &analysis.GetSimilarProductItem{
					SeedProduct:    seedProdDetailMap[similarInfo.SeedProductId],
					SimilarProduct: similarProduct,
					SimilarScore:   similarProd.SimilarScore,
				})
				validSimilarIds = append(validSimilarIds, convert.ToString(similarProd.ProductId))
			}
			if int64(len(similarProductTmpList)) >= similarCountLimit {
				break
			}
		}
		if len(similarProductTmpList) > 0 {
			sort.SliceStable(similarProductTmpList, func(i, j int) bool {
				if similarProductTmpList[i].SimilarScore == similarProductTmpList[j].SimilarScore {
					return similarProductTmpList[i].SimilarProduct.ProductInfo.Id > similarProductTmpList[j].SimilarProduct.ProductInfo.Id
				}
				return similarProductTmpList[i].SimilarScore > similarProductTmpList[j].SimilarScore
			})
			similarProductList = append(similarProductList, similarProductTmpList...)
			validSeedIds = append(validSeedIds, similarInfo.SeedProductId)
		}
	}
	validSeedIds = slices.DistinctString(validSeedIds)
	validSimilarIds = slices.DistinctString(validSimilarIds)
	return similarProductList, validSeedIds, validSimilarIds, nil
}

func extractProductIdsAndPoolInfo(ctx context.Context, prodIds []string, poolId string) ([]string, *analysis_pool.AnalysisPool, error) {
	// 提取请求中的商品ID和货盘ID
	if len(prodIds) > 0 && prodIds[0] != "" {
		for _, seedProdId := range prodIds {
			pid, err := utils.String2Int64(seedProdId)
			if err != nil || pid < 100000000000000000 {
				logs.CtxWarn(ctx, "存在商品ID格式错误,问题商品ID为: %v", seedProdId)
				return nil, nil, errors.New(fmt.Sprintf("存在商品ID格式错误,问题商品ID为: %v", seedProdId))
			}
		}
		return prodIds, nil, nil
	}

	if len(poolId) > 0 && poolId != "" {
		pidList, _, poolInfo, err := analysis_pool_product_service.GetPoolAndPidList(ctx, poolId, nil)
		if err != nil {
			return nil, nil, err
		}
		return pidList, poolInfo, nil
	}
	logs.CtxInfo(ctx, "未传商品ID和货盘ID")
	return nil, nil, nil
}

func getSimilarExportData(ctx context.Context, similarProductList []*analysis.GetSimilarProductItem, filteredSeedProdIdInfo map[string]string, isExportFilteredData bool) (*onetable.Table, error) {
	table := make([]map[string]interface{}, 0)
	if isExportFilteredData {
		for seedProdId, reason := range filteredSeedProdIdInfo {
			row := make(map[string]interface{})
			row["seed_id"] = seedProdId
			row["reason"] = reason
			table = append(table, row)
		}
	} else {
		for _, similarProduct := range similarProductList {
			row := make(map[string]interface{})
			logs.CtxInfo(ctx, "getSimilarExportData similarProduct: %v", convert.ToJSONString(similarProduct))
			row["seed_id"] = similarProduct.SeedProduct.ProductInfo.Id
			for _, target := range similarProduct.SeedProduct.TargetList {
				row["种子品"+target.DisplayName] = target.DisplayValue
			}
			row["similar_id"] = similarProduct.SimilarProduct.ProductInfo.Id
			for _, target := range similarProduct.SimilarProduct.TargetList {
				row["相似品"+target.DisplayName] = target.DisplayValue
			}
			row["similar_score"] = similarProduct.SimilarScore
			table = append(table, row)
		}
	}
	return onetable.NewTable(table), nil
}

func doGetSimilarProductExport(ctx context.Context, table *onetable.Table, email string, isExportFilteredSeedData bool) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	var sheet1 *lark_export.LarkDocSheet
	if isExportFilteredSeedData {
		sheet1 = lark_export.NewLarkDocSheet("未通过筛选种子商品", table)
		sheet1.AddColumn("种子商品ID", "seed_id").
			AddColumn("未通过原因", "reason")
	} else {
		for _, row := range table.ToRawMap() {
			sheet1 = lark_export.NewLarkDocSheet("相似商品", table)
			sheet1.AddColumn("种子商品ID", "seed_id")
			for k, _ := range row {
				if strings.Contains(k, "种子品") {
					sheet1.AddColumn(k, k)
				}
			}
			sheet1.AddColumn("相似商品ID", "similar_id")
			for k, _ := range row {
				if strings.Contains(k, "相似品") {
					sheet1.AddColumn(k, k)
				}
			}
			sheet1.AddColumn("相似分", "similar_score")

		}
	}
	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}
