package analysis_service

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
)

func GetPlanBoostCoreOverview(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, apiPath string) (resp []*analysis.TargetCategoryList, err error) {
	// 获取业务线的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	// 查询指标卡并完成组装
	resp, err = GetTargetCard(ctx, req, true, dimMap, apiPath, apiPath)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreOverview]获取指标卡数据失败，err=%v", err)
		return nil, err
	}
	SortTargetCard(ctx, resp)
	return resp, nil
}
