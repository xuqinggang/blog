package analysis_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/jinzhu/copier"
	"math"
	"sort"
	"strings"
)

type ConclusionDimReq struct {
	DimId       string
	DimCol      string
	DimName     string
	EnumCodeCol string
	EnumNameCol string
	DimMap      map[int64]*dao.DimensionInfo
}

// GetCateByCnt 计算类目的数量
func GetCateByCnt(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, dim ConclusionDimReq) (ret []*analysis.ConclusionProdDimCntInfo, err error) {
	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)

	tableName := "ConclusionProdDimCntInfo"

	cql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
		BaseStruct:       req,
		NotSyncBaseMulti: true,
		NeedProdID:       false,
		CKSettingType:    base_struct_condition.CKSettingSub,
		MultiDimColumns:  []string{"industry_id", "first_level_cate_id", "second_level_cate_id", "leaf_cate_id"},
		BaseSelectList: []string{
			"count(distinct if(industry_id > 0, industry_id, null)) as industry_cnt",
			"count(distinct if(industry_id > 0, first_level_cate_id, null)) as first_cnt",
			"count(distinct if(industry_id > 0, second_level_cate_id, null)) as second_cnt",
			"count(distinct if(industry_id > 0, leaf_cate_id, null)) as leaf_cnt",
		},
		DimMap: dim.DimMap,
	})
	if err != nil {
		return
	}
	cql.FromClause.TemporaryTable.AddWhere(consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType), sql_parse.GREATER_THAN, 0)
	fl.ExeQueryInvokerSql(biz_info.GetCtxBizInfoApiID(ctx), cql.Compile(), param.SinkTable(tableName))
	fl.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable(tableName), param.SinkTable(tableName)).
		SetValueColumn("dim_cnt").
		SetTargetNameColumn("dim_name"))
	fl.ExeProduceSql(fmt.Sprintf(`
		select case 
				when dim_name = 'industry_cnt' then '行业大类' 
				when dim_name = 'first_cnt' then '一级类目'
				when dim_name = 'second_cnt' then '二级类目'
				when dim_name = 'leaf_cnt' then '叶子类目'
			end as dim_name,
			dim_cnt
		from %s
	`, tableName), param.SinkTable(tableName))
	fl.ExeView(param.SourceTable(tableName), &ret)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetCateByCnt]引擎调用失败，err=%v+", err)
		return ret, err
	}

	sort.Slice(ret, func(i, j int) bool {
		return cateOrderMap[ret[i].DimName] < cateOrderMap[ret[j].DimName]
	})
	return
}

var cateOrderMap = map[string]int{
	"行业大类": 1, "一级类目": 2, "二级类目": 3, "叶子类目": 4,
}

// GetDimContributionInfo 下钻维度探查
func GetDimContributionInfo(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, dim ConclusionDimReq, totalPayCnt int64) (ret *analysis.ConclusionProdDimContributionInfo, err error) {
	useReq := &dimensions.ProductAnalysisBaseStruct{}
	copier.CopyWithOption(useReq, *req, copier.Option{DeepCopy: true})

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()

	// 下钻探查
	dimContributionSubCql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
		BaseStruct:       useReq,
		MultiDimColumns:  []string{dim.EnumCodeCol, dim.EnumNameCol},
		NeedProdID:       false,
		NotSyncBaseMulti: true,
		CKSettingType:    base_struct_condition.CKSettingSub,
		SubSelectList: []string{
			fmt.Sprintf("sum(%s) as %s", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType), consts.AttrNamePayOrdCnt),
		},
		BaseSelectList: []string{
			dim.EnumCodeCol,
			fmt.Sprintf("max(%s) as name", dim.EnumNameCol),
			fmt.Sprintf("sum(%s) as %s", consts.AttrNamePayOrdCnt, consts.AttrNamePayOrdCnt),
			fmt.Sprintf("sum(%s) over (order by %s desc rows between unbounded preceding and 1 preceding) as top_sum_%s",
				consts.AttrNamePayOrdCnt, consts.AttrNamePayOrdCnt, consts.AttrNamePayOrdCnt),
		},
		DimMap: dim.DimMap,
	})
	dimContributionSubCql.GroupBy(dim.EnumCodeCol).AddWhere(dim.EnumCodeCol, sql_parse.GREATER_THAN, 0)
	dimContributionCql := sql_parse.NewCQL().Select("*").FromCql(dimContributionSubCql).AddWhere(consts.AttrNamePayOrdCnt, sql_parse.GREATER_THAN, 0)
	dimContributionCql.AddWhereRawCond("top_sum_pay_ord_cnt / ? <= 0.3", totalPayCnt).Limit(21)
	fl.ExeQueryInvokerSql(biz_info.GetCtxBizInfoApiID(ctx), dimContributionCql.Compile(), param.SinkTable("os_data"))

	var enums []*dimensions.EnumElement
	fl.ExeProduceSql(fmt.Sprintf(`
		select %s as code, name from os_data where str_len(code) > 0
	`, dim.EnumCodeCol), param.SinkTable("enum_list"))
	fl.ExeView(param.SourceTable("enum_list"), &enums)

	var result *analysis.ConclusionProdDimContributionInfo
	fl.ExeProduceSql(fmt.Sprintf(`
		select
			max(top_sum_pay_ord_cnt) / %d as contribution,
			'支付订单数' as order_target_name
		from os_data
	`, totalPayCnt), param.SinkTable("contribution_data"))
	fl.ExeView(param.SourceTable("contribution_data"), &result)

	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[DimContributionInfo]引擎调用失败，err=%v+", err)
		return ret, err
	}
	if result == nil {
		logs.CtxWarn(ctx, "[GetDimContributionInfo]result nil")
		return nil, nil
	}

	// 枚举大于20则不返回
	if len(enums) == 0 || len(enums) > 20 {
		return nil, nil
	}

	dimInfo, exist := dim.DimMap[convert.ToInt64(dim.DimId)]
	if !exist {
		logs.CtxError(ctx, "未发现类目信息, dim_id=%s", dim.DimId)
		return nil, errors.New("未发现类目信息")
	}

	selectedDimensionInfo := &dimensions.SelectedDimensionInfo{
		Id:               dim.DimId,
		Name:             dimInfo.ShowName,
		AttrType:         dimensions.DimensionAttributeType(dimInfo.DimensionCategory),
		SelectedOperator: base.OperatorType_IN,
		SelectedValues:   enums,
	}

	ret = result
	ret.DimInfo = []*dimensions.SelectedDimensionInfo{
		selectedDimensionInfo,
	}

	// 补充共贡献了多少
	docNew := document.NewEmptyDoc()
	appNew := application.NewApp(docNew)
	flNew := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	useReq.Dimensions = append(useReq.Dimensions, selectedDimensionInfo)
	dimContributionNewCql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
		BaseStruct:    useReq,
		NeedProdID:    true,
		CKSettingType: base_struct_condition.CKSettingSub,
		SubSelectList: []string{
			fmt.Sprintf("sum(%s) as pay_ord_cnt", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
			//fmt.Sprintf("hllSketchUnion(%s) as pay_uv_sketch", consts.GetTableCol(consts.AttrNamePayUV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		},
		BaseSelectList: []string{
			"count(1) as pay_prod_cnt",
			"sum(pay_ord_cnt) as pay_ord_cnt",
			//"cast(coalesce(hllSketchEstimate(12,1)(pay_uv_sketch),0) as Int64) as pay_uv",
		},
		DimMap: dim.DimMap,
	})
	if err != nil {
		return
	}
	if dimContributionNewCql == nil {
		return ret, errors.New("dimContributionNewCql empty")
	}
	flNew.ExeQueryInvokerSql(biz_info.GetCtxBizInfoApiID(ctx), dimContributionNewCql.Compile(), param.SinkTable("new_data"))
	flNew.ExeQueryCustom([]param.Source{param.SourceConst(int64(useReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 指标值行转列
	flNew.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("new_data"), param.SinkTable("new_data")).
		SetValueColumn("value").
		SetTargetNameColumn("name"))
	flNew.ExeProduceSql(`
		select  a.name as name,
				a.value as value,
				get_display_value(a.value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order
		from    new_data a
		inner join
				target_meta b
		on      a.name=b.name order by b.display_order asc
	`, param.SinkTable("target_list")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	var targetCardEntity []*analysis.TargetCardEntity
	flNew.ExeView(param.SourceTable("target_list"), &targetCardEntity)
	appNew.Use(flNew.ToStack(ctx))
	_, err = appNew.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[DimContributionInfo]引擎调用失败，err=%v+", err)
		return ret, err
	}

	sort.Slice(targetCardEntity, func(i, j int) bool {
		return targetCardEntity[i].DisplayOrder < targetCardEntity[j].DisplayOrder
	})
	ret.TargetEntity = targetCardEntity
	return ret, nil
}

func GetProdPayCntHierarchicalCql(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo, isCompare bool) (cql *sql_parse.CQL, err error) {
	// GetProdPayCntHierarchical 货品效率-单量分层
	var ProdPayCntHierarchicalBaseSelect = []string{"pay_cnt_type", "count(1) as pay_prod_cnt", "sum(pay_ord_cnt) as pay_ord_cnt"}
	var ProdPayCntHierarchicalSubSelect = []string{
		fmt.Sprintf("sum(%s) as pay_ord_cnt", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		`case when pay_ord_cnt >= 2 and pay_ord_cnt <= 10 then '2-10单品' when pay_ord_cnt >= 11 and pay_ord_cnt <= 100 then '11-100单品' when pay_ord_cnt >= 101 and pay_ord_cnt <= 1000 then '101-1000单品' when pay_ord_cnt > 1000 then '1000单+品' else '其他' end as pay_cnt_type`,
	}

	// 分析时间
	//startDate := utils.If(isCompare, req.CompareStartDate, req.StartDate)
	endDate := utils.If(isCompare, req.CompareEndDate, req.EndDate)
	last30Date := time_utils.AddDateTimeFormat(endDate, consts.FmtDateSlash, -29)

	finalCql := sql_parse.NewCQL()
	if true {
		finalCql, _, err = base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
			BaseStruct:       req,
			IsCompare:        isCompare,
			NotSyncBaseMulti: true,
			CKSettingType:    base_struct_condition.CKSettingSub,
			NeedProdID:       true,
			SubSelectList:    ProdPayCntHierarchicalSubSelect,
			BaseSelectList:   ProdPayCntHierarchicalBaseSelect,
			DimMap:           dimMap,
		})
		finalCql.GroupBy("pay_cnt_type")
	} else { // 暂时不通过近30天计算
		firstCql := sql_parse.NewCQL().From(biz_info.GetCtxBizInfoTableName(ctx)).Select(append(ProdPayCntHierarchicalSubSelect, consts.ProductID)...).GroupBy(consts.ProductID)
		globalInCql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
			BaseStruct:       req,
			IsCompare:        isCompare,
			NotSyncBaseMulti: true,
			//NotCkSettings:    true,
			NeedProdID: true,
			SubSelectList: []string{
				fmt.Sprintf("sum(%s) as pay_ord_cnt", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
			},
			BaseSelectList: []string{
				consts.ProductID,
			},
			DimMap: dimMap,
		})
		if err != nil {
			return cql, err
		}
		globalInCql.AddWhere("pay_ord_cnt", sql_parse.GREATER_EQUAL_THAN, 2)
		if len(globalInCql.FromClause.Table) > 0 {
			globalInCql.FromClause.Table = utils.AddTableNameAlias(globalInCql.FromClause.Table, "base_outer")
		} else if globalInCql.FromClause.TemporaryTable != nil {
			globalInCql.FromClause.TemporaryTable.FromClause.Table = utils.AddTableNameAlias(globalInCql.FromClause.TemporaryTable.FromClause.Table, "base_outer")
		}
		firstCql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, globalInCql)
		// 解析所选维度过滤信息
		_, baseExprCql, _, err := base_struct_condition.GetBaseConditionWithDims(ctx, req, isCompare, dimMap, true, false)
		if err != nil {
			return nil, err
		}
		//firstCql.AddWhereRawCond("date between ? and ?", last30Date, endDate)
		firstCql, err = base_struct_condition.TransformCqlAppendDateExpr(ctx, firstCql, last30Date, endDate)
		if err != nil {
			return nil, err
		}
		if baseExprCql != nil {
			firstCql.AddWhereAndValue(baseExprCql.WhereClause).AddRawWhereAndValue(baseExprCql.RawWhereClause...)
		}
		finalCql.Select(ProdPayCntHierarchicalBaseSelect...).FromCql(firstCql).GroupBy("pay_cnt_type")
	}
	finalCql.AddWhere("pay_cnt_type", sql_parse.NOT_EQUALS, "其他")
	//finalCql.AddClickHouseSettings("distributed_product_mode = 'local'", "distributed_perfect_shard = 1")
	return finalCql, nil
}
func GetProdPayCntHierarchical(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo) (ret []*analysis.HierarchicalInfo, err error) {
	currCql, err := GetProdPayCntHierarchicalCql(ctx, req, dimMap, false)
	if err != nil {
		return
	}
	currCql.AddClickHouseSettings("distributed_product_mode = 'local', distributed_perfect_shard = 1")
	compareCql, err := GetProdPayCntHierarchicalCql(ctx, req, dimMap, true)
	if err != nil {
		return
	}
	compareCql.AddClickHouseSettings("distributed_product_mode = 'local', distributed_perfect_shard = 1")

	// 兜底补全默认空数据
	unionDefaultStr := " union all select '' as pay_cnt_type, 0 as pay_prod_cnt, 0 as pay_ord_cnt"

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	fl.ExeQueryInvokerSql(biz_info.GetCtxBizInfoApiID(ctx), currCql.Compile()+unionDefaultStr, param.SinkTable("curr_table"))
	fl.ExeQueryInvokerSql(biz_info.GetCtxBizInfoApiID(ctx), compareCql.Compile()+unionDefaultStr, param.SinkTable("compare_table"))
	fl.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 指标值行转列
	fl.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("curr_table"), param.SinkTable("curr_table")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"pay_cnt_type"}))
	fl.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("compare_table"), param.SinkTable("compare_table")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"pay_cnt_type"}))
	// 计算环比
	fl.ExeProduceSql(`
		select
			a.pay_cnt_type as pay_cnt_type,
			a.target_name as name,
			a.target_value as value,
			b.target_value as cycle_value,
			(a.target_value-b.target_value) / b.target_value as cycle_change_ratio
		from curr_table a 
		left join compare_table b
		on a.target_name = b.target_name and a.pay_cnt_type = b.pay_cnt_type
		where pay_cnt_type != ''
	`, param.SinkTable("curr_table_new"))
	// 关联指标元信息, 处理额外信息
	fl.ExeProduceSql(`
		select  a.pay_cnt_type as pay_cnt_type,
				a.name as name,
				a.value as value,
				get_display_value(a.value, b.value_type, b.value_unit, b.target_precision) as display_value,
				a.cycle_value as cycle_value,
				get_display_value(a.cycle_value, b.value_type, b.value_unit, b.target_precision) as cycle_display_value,
				a.cycle_change_ratio as cycle_change_ratio,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				(select b.is_larger_advantage as is_larger_advantage) as extra
		from    curr_table_new a
		inner join
				target_meta b
		on      a.name=b.name order by b.display_order asc
	`, param.SinkTable("curr_table_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	// 获取所有指标类型，存到一张表中
	fl.ExeProduceSql(`select pay_cnt_type from curr_table_data group by pay_cnt_type`, param.SinkTable("type_table"))
	// 根据指标类型，提取指标卡信息
	fl.ExeProduceSql(`
		select  pay_cnt_type as col_name,
				(
					select  name,
							value,
							display_value,
							cycle_value,
							cycle_display_value,
							cycle_change_ratio,
							display_name,
							tips,
							unit,
							extra
					from    curr_table_data a
					where   a.pay_cnt_type = type_table.pay_cnt_type
				) as target_name
		from    type_table`, param.SinkTable("res_data"))
	fl.ExeView(param.SourceTable("res_data"), &ret)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	return ret, nil
}

type MultiDimEnumMap struct {
	dimColumns    []string
	dimMap        map[string]*dimensions.SelectedDimensionInfo
	dimDimSortIds []string
}

func GetMultiDimEnumMap(ctx context.Context, groupAttrs []*dimensions.SelectedMultiDimensionInfo, dimMap map[int64]*dao.DimensionInfo) (multiDimEnumMap *MultiDimEnumMap, err error) {
	multiDimEnumMap = &MultiDimEnumMap{
		dimColumns:    make([]string, 0),
		dimMap:        make(map[string]*dimensions.SelectedDimensionInfo, 0),
		dimDimSortIds: make([]string, 0),
	}
	for _, reqDim := range groupAttrs {
		dimInfo, exist := dimMap[convert.ToInt64(reqDim.DimInfo.Id)]
		if !exist {
			logs.CtxError(ctx, "未发现维度信息, reqDim=%s", convert.ToJSONString(reqDim))
			return nil, errors.New("未发现维度信息")
		}

		multiDimEnumMap.dimColumns = append(multiDimEnumMap.dimColumns, dimInfo.DimColumn)
		multiDimEnumMap.dimMap[dimInfo.DimColumn] = reqDim.DimInfo
		multiDimEnumMap.dimDimSortIds = append(multiDimEnumMap.dimDimSortIds, convert.ToString(dimInfo.ID))
	}
	return
}

func GetEnumByDim(enumCode string, dim *dimensions.SelectedDimensionInfo) *dimensions.EnumElement {
	if dim == nil || len(dim.SelectedValues) == 0 {
		return &dimensions.EnumElement{}
	}
	for _, e := range dim.SelectedValues {
		if e.Code == enumCode {
			return e
		}
	}

	return &dimensions.EnumElement{}
}

type MultiDimFlowTransContributionInfo struct {
	DimInfo         []*dimensions.SelectedDimensionInfo `json:"dim_info"`
	TargetEntity    []*analysis.TargetCardEntity        `json:"target_entity"`
	Contribution    float64                             `json:"contribution"`
	OrderTargetName string                              `json:"order_target_name"`
	OrderInt        int                                 `json:"order_int"`
	DimKey          string                              `json:"dim_key"`
}

// GetMultiDimFlowTrans 获取流量转换结论
func GetMultiDimFlowTrans(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, filterDimCat dimensions.FilterDimCategory, dimMap map[int64]*dao.DimensionInfo,
	dimColMap map[string]*dao.DimensionInfo, marketOpmDimkeyTargetMap map[string]*analysis.TargetCardEntity) (ret []*analysis.ConclusionProdDimContributionInfo, err error) {
	dimEnumInfoMap, err := GetMultiDimEnumMap(ctx, req.GroupAttrs, dimMap)
	if err != nil {
		return
	}

	basicGroupCol := dimEnumInfoMap.dimColumns[0]
	assistantGroupCol := make([]string, 0)
	if len(dimEnumInfoMap.dimColumns) > 1 {
		assistantGroupCol = dimEnumInfoMap.dimColumns[1:]
	}

	assistantCase := "when length(dim_key) > 0 then -1"
	if len(assistantGroupCol) > 0 {
		assistantCql := sql_parse.NewCQL()
		for _, c := range assistantGroupCol {
			assistantCql.AddWhere(fmt.Sprintf("length(%s)", c), sql_parse.EQUAL, 0)
		}
		assistantCase = fmt.Sprintf("when %s then -1", assistantCql.ParseWhereClause())
	}

	cql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
		BaseStruct:       req,
		MultiDimColumns:  dimEnumInfoMap.dimColumns,
		CKSettingType:    base_struct_condition.CKSettingSub,
		NotSyncBaseMulti: true,
		SubSelectList: append(base_struct_condition.GenerateCastString(dimEnumInfoMap.dimColumns, "str_"),
			fmt.Sprintf("sum(%s) as pay_ord_cnt", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
			fmt.Sprintf("sum(%s) as show_pv", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		),
		BaseSelectList: append(base_struct_condition.AppendPrefixSelf(dimEnumInfoMap.dimColumns, "str_"),
			[]string{
				base_struct_condition.GenerateDimKey(dimEnumInfoMap.dimColumns, "str_"),
				"case " + assistantCase + " when endsWith(dim_key, '###') then 1 when dim_key like '%######%' then 2 else 3 end as cate_type",
				"sum(pay_ord_cnt) as pay_ord_cnt",
				"sum(show_pv) as show_pv",
				"pay_ord_cnt/show_pv*1000 as opm",
			}...),
		DimMap:    dimMap,
		DimColMap: dimColMap,
	})
	if err != nil {
		return
	}

	sortCol := "opm"
	var targetCondition string
	if filterDimCat == dimensions.FilterDimCategory_PotentialUsers {
		sortCol = "show_pv"
		targetCondition = "and b.display_name != 'opm'"
	}

	cql.AddHavingValueWithOperator("0", sql_parse.GREATER_THAN, sql_parse.LONG, "length(replace(dim_key, '#',''))").
		AddHavingValueWithOperator("0", sql_parse.GREATER_THAN, sql_parse.LONG, fmt.Sprintf("length(%s)", basicGroupCol)).
		AddHavingValueWithOperator("0", sql_parse.GREATER_THAN, sql_parse.LONG, consts.AttrNameShowPV).
		AddHavingValueWithOperator("0", sql_parse.GREATER_THAN, sql_parse.LONG, consts.AttrNamePayOrdCnt).
		OrderBy(sql_parse.DESC, sortCol).GroupBy(base_struct_condition.AppendPrefix(dimEnumInfoMap.dimColumns, "str_")...).WithCube()

	baseSelects := append(dimEnumInfoMap.dimColumns, "dim_key", "pay_ord_cnt", "show_pv", "opm")
	groupArraySelect := make([]string, 0)
	for _, s := range baseSelects {
		groupArraySelect = append(groupArraySelect, fmt.Sprintf("groupArray(1)(%s) as %s", s, s))
	}

	newFinalCql := sql_parse.NewCQL().
		Select(append([]string{"cate_type"}, baseSelects...)...).
		FromCql(sql_parse.NewCQL().Select(append([]string{"cate_type"}, groupArraySelect...)...).FromCql(cql).GroupBy("cate_type"))
	sqlStr := newFinalCql.Compile() + " array join " + strings.Join(baseSelects, ",")
	logs.CtxInfo(ctx, "[GetMultiDimFlowTrans]sqlStr=%s", sqlStr)

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	fl.ExeQueryInvokerSql(biz_info.GetCtxBizInfoApiID(ctx), sqlStr, param.SinkTable("os_table_info"))
	fl.ExeQueryCustom([]param.Source{param.SourceConst(req.BizType), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	fl.ExeProduceSql(`
		select 
			dim_key,
			show_pv,
			opm
		from os_table_info
	`, param.SinkTable("target_info"))
	// 指标值行转列
	fl.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_info"), param.SinkTable("target_info")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"dim_key"}))
	fl.ExeProduceSql(`
		select  a.dim_key as dim_key,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				(select b.is_larger_advantage as is_larger_advantage) as extra
		from    target_info a
		inner join
				target_meta b
		on      a.target_name=b.name order by b.display_order desc
	`, param.SinkTable("target_info")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})

	fl.ExeProduceSql(fmt.Sprintf(`
		select 
			dim_key,
			%s
		from os_table_info
	`, strings.Join(dimEnumInfoMap.dimColumns, ",")), param.SinkTable("dim_info"))
	// 指标值行转列
	fl.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("dim_info"), param.SinkTable("dim_info")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"dim_key"}))

	fl.ExeProduceSql(`
		select 
			dim_key,
			cate_type
		from os_table_info 
		group by dim_key,cate_type
	`, param.SinkTable("dim_key_info"))

	attrMap, err := new(dao.AttributeDao).GetTargetMetaMap(ctx, int64(req.BizType))
	if err != nil {
		return nil, err
	}
	attrInfo, exist := attrMap[sortCol]
	showOrderName := "OPM"
	if exist {
		showOrderName = attrInfo.DisplayName
	}
	fl.ExeProduceSql(fmt.Sprintf(`
		select 
			(
				select  target_name as id,
						target_value as name
				from    dim_info a
				where   a.dim_key = dim_key_info.dim_key  and str_len(a.target_value) > 0
			) as dim_info,
			(
				select  name,
						value,
						display_value,
						display_name,
						extra
				from    target_info b
				where   b.dim_key = dim_key_info.dim_key %s
			) as target_entity,
			'%s' as order_target_name,
			cate_type as order_int,
			dim_key as dim_key
		from dim_key_info order by cate_type asc
	`, targetCondition, showOrderName), param.SinkTable("res_data"))

	var result []*MultiDimFlowTransContributionInfo
	fl.ExeView(param.SourceTable("res_data"), &result)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetMultiDimFlowTrans]引擎调用失败，err=%v+", err)
		return nil, err
	}

	if len(result) == 0 {
		return nil, nil
	}
	sort.Slice(result, func(i, j int) bool {
		return result[i].OrderInt < result[j].OrderInt
	})
	ret = make([]*analysis.ConclusionProdDimContributionInfo, 0)
	for _, r := range result {
		if len(r.TargetEntity) > 0 {
			sort.Slice(r.TargetEntity, func(i, j int) bool {
				if r.TargetEntity[i].Name == sortCol {
					return true
				}
				return r.TargetEntity[i].DisplayOrder < r.TargetEntity[j].DisplayOrder
			})
		}
		if len(r.DimInfo) > 0 {
			contributionInfo := &analysis.ConclusionProdDimContributionInfo{
				DimInfo:         make([]*dimensions.SelectedDimensionInfo, 0),
				TargetEntity:    r.TargetEntity,
				Contribution:    r.Contribution,
				OrderTargetName: &r.OrderTargetName,
				IsTotal:         convert.ToBoolPtr(r.OrderInt < 0),
			}

			for _, d := range r.DimInfo {
				if reqDim, existT := dimEnumInfoMap.dimMap[d.Id]; existT {
					enum := GetEnumByDim(d.Name, reqDim)
					contributionInfo.DimInfo = append(contributionInfo.DimInfo, &dimensions.SelectedDimensionInfo{
						Id:               reqDim.Id,
						Name:             reqDim.Name,
						AttrType:         reqDim.AttrType,
						SelectedOperator: reqDim.SelectedOperator,
						SelectedValues:   []*dimensions.EnumElement{enum},
					})
				}
			}

			var marketKey string
			if strings.Contains(r.DimKey, "#") {
				kLen := strings.Index(r.DimKey, "#") + 3
				if kLen < len(r.DimKey) {
					marketKey = r.DimKey[kLen:]
				}
			}
			if marketValue, existMarket := marketOpmDimkeyTargetMap[marketKey]; existMarket {
				for _, t := range r.TargetEntity {
					if t.Name == consts.AttrNameOPM {
						contributionInfo.MarketDiff = convert.ToFloat64Ptr(t.Value - marketValue.Value)
						break
					}
				}
			}

			if len(contributionInfo.DimInfo) > 0 {
				sort.Slice(contributionInfo.DimInfo, func(i, j int) bool {
					var valI, valJ int
					if dimEnumInfoMap != nil && len(dimEnumInfoMap.dimDimSortIds) > 0 {
						for index, d := range dimEnumInfoMap.dimDimSortIds {
							if contributionInfo.DimInfo[i].Id == d {
								valI = index
							}
							if contributionInfo.DimInfo[j].Id == d {
								valJ = index
							}
						}
					}
					return valI < valJ
				})
			}
			ret = append(ret, contributionInfo)
		}
	}

	return
}

// GetMultiDimAbnormal 获取异动分析结论
type dimsTargetEntity struct {
	DimKey       string                              `json:"dim_key"`
	DimInfo      []*dimensions.SelectedDimensionInfo `thrift:"dim_info,1" frugal:"1,default,list<dimensions.SelectedDimensionInfo>" json:"dim_info"`
	TargetEntity []*analysis.TargetCardEntity        `thrift:"target_entity,2" frugal:"2,default,list<TargetCardEntity>" json:"target_entity"`
}

type dimKeyTargetEntity struct {
	DimKey       string                       `json:"dim_key"`
	TargetEntity []*analysis.TargetCardEntity `thrift:"target_entity,2" frugal:"2,default,list<TargetCardEntity>" json:"target_entity"`
}

func (d *AnalysisService) GetMultiDimAbnormalInfo(ctx context.Context,
	req *dimensions.ProductAnalysisBaseStruct,
	targetInfo *analysis.TargetCardEntity,
	dimColMap map[string]*dimensions.SelectedDimensionInfo,
	daoDimColMap map[string]*dao.DimensionInfo,
	dimMap map[int64]*dao.DimensionInfo, multiAbnormalInfo *analysis.MultiDimConclusionAbnormalInfo) (err error) {
	if multiAbnormalInfo == nil || multiAbnormalInfo.DimInfo == nil || targetInfo == nil {
		logs.CtxWarn(ctx, "下钻维度信息为空，multiAbnormalInfo=%s", convert.ToJSONString(multiAbnormalInfo))
		return
	}

	useReq := &dimensions.ProductAnalysisBaseStruct{}
	copier.CopyWithOption(useReq, *req, copier.Option{DeepCopy: true})

	dimInfo, exist := dimMap[convert.ToInt64(multiAbnormalInfo.DimInfo.Id)]
	if !exist {
		logs.CtxError(ctx, "未发现维度信息, selectDimInfo=%s", convert.ToJSONString(multiAbnormalInfo.DimInfo))
		return errors.New("未发现维度信息")
	}

	dimKey := fmt.Sprintf("%s as dim_key", dimInfo.DimColumn)

	var abnormalSubSelectList []string
	var abnormalBaseSelectList []string
	switch targetInfo.Name {
	case consts.AttrNameShowPV:
		abnormalSubSelectList = []string{
			fmt.Sprintf("sum(%s) as show_pv", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey, "show_pv",
		}
	case consts.AttrNamePayOrdCnt:
		abnormalSubSelectList = []string{
			fmt.Sprintf("sum(%s) as pay_ord_cnt", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey,
			"pay_ord_cnt",
		}
	case consts.AttrNameShowProdCnt:
		abnormalSubSelectList = []string{
			fmt.Sprintf("count(distinct if(%s > 0, prod_id, null)) as show_prod_cnt", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey, "show_prod_cnt",
		}
	case consts.AttrNameProdPayShowRate:
		abnormalSubSelectList = []string{
			fmt.Sprintf("count(distinct if(%s > 0, prod_id, null)) as show_prod_cnt", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
			fmt.Sprintf("count(distinct if(%s > 0, prod_id, null)) as pay_prod_cnt", consts.GetTableCol(consts.AttrNamePayGMV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey,
			"round(pay_prod_cnt / show_prod_cnt, 5) as prod_pay_show_rate",
		}
	case consts.AttrNamePayProdAvgOrdCnt:
		abnormalSubSelectList = []string{
			fmt.Sprintf("sum(%s) as pay_ord_cnt", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
			fmt.Sprintf("count(distinct if(%s > 0, prod_id, null)) as show_prod_cnt", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey,
			"round(pay_ord_cnt / show_prod_cnt, 5) as prod_avg_ord_cnt",
		}
	default:
		return
	}

	currCql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
		BaseStruct:       req,
		MultiDimColumns:  []string{dimInfo.DimColumn},
		CKSettingType:    base_struct_condition.CKSettingSub,
		NeedProdID:       false,
		SubSelectList:    abnormalSubSelectList,
		BaseSelectList:   abnormalBaseSelectList,
		DimMap:           dimMap,
		DimColMap:        daoDimColMap,
		NotSyncBaseMulti: true,
	})
	if err != nil {
		return
	}

	compareCql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
		BaseStruct:       req,
		MultiDimColumns:  []string{dimInfo.DimColumn},
		IsCompare:        true,
		CKSettingType:    base_struct_condition.CKSettingSub,
		NeedProdID:       false,
		SubSelectList:    abnormalSubSelectList,
		BaseSelectList:   abnormalBaseSelectList,
		DimMap:           dimMap,
		DimColMap:        daoDimColMap,
		NotSyncBaseMulti: true,
	})
	if err != nil {
		return
	}

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)

	fl.ExeQueryInvokerSql(biz_info.GetCtxBizInfoApiID(ctx), currCql.Compile(), param.SinkTable("curr_os_data"))
	fl.ExeQueryInvokerSql(biz_info.GetCtxBizInfoApiID(ctx), compareCql.Compile(), param.SinkTable("compare_os_data"))
	// 指标值行转列
	fl.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("curr_os_data"), param.SinkTable("curr_target_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{dimInfo.DimColumn, "dim_key"}))
	fl.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("compare_os_data"), param.SinkTable("compare_target_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{dimInfo.DimColumn, "dim_key"}))
	fl.ExeProduceSql(`
		select a.dim_key as dim_key,
			a.target_name as name,
			a.target_value as value,
			b.target_value as cycle_value,
			(a.target_value-b.target_value) / b.target_value as cycle_change_ratio,
			a.target_value-b.target_value as cycle_change_pp
		from curr_target_data a join compare_target_data b on a.dim_key = b.dim_key and a.target_name = b.target_name
	`, param.SinkTable("target_data"))
	fl.ExeQueryCustom([]param.Source{param.SourceConst(req.BizType), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	fl.ExeProduceSql(`
		select  a.dim_key as dim_key,
				a.name as name,
				a.value as value,
				get_display_value(a.value, b.value_type, b.value_unit, b.target_precision) as display_value,
				a.cycle_value as cycle_value,
				get_display_value(a.cycle_value, b.value_type, b.value_unit, b.target_precision) as cycle_display_value,
				case 
					when b.is_use_pp = true then a.cycle_change_pp 
					else a.cycle_change_ratio 
				end as cycle_change_ratio,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				(select b.is_larger_advantage as is_larger_advantage) as extra,
				b.is_use_pp as is_use_pp
		from    target_data a
		inner join
				target_meta b
		on      a.name=b.name
		order by b.display_order asc
	`, param.SinkTable("target_data_new")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})

	fl.ExeProduceSql("select dim_key from curr_os_data group by dim_key", param.SinkTable("dim_key_data"))
	fl.ExeProduceSql(`
		select 
			dim_key,
			(
			 	select name,value,display_value,cycle_value,cycle_display_value,cycle_change_ratio,display_name,tips,unit,category_name,extra,is_use_pp
				from target_data_new b where b.dim_key = dim_key_data.dim_key 
			) as target_entity
		from dim_key_data
	`, param.SinkTable("res_data"))
	var dimTargets []*dimKeyTargetEntity
	fl.ExeView(param.SourceTable("res_data"), &dimTargets)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetMultiDimFlowTrans]引擎调用失败，err=%v+", err)
		return
	}

	if len(dimTargets) > 0 {
		for _, dt := range dimTargets {
			enumV := GetEnumByDim(dt.DimKey, dimColMap[dimInfo.DimColumn])
			if len(enumV.Code) == 0 {
				continue
			}
			abDimInfo := &dimensions.SelectedDimensionInfo{
				Id:               multiAbnormalInfo.DimInfo.Id,
				Name:             multiAbnormalInfo.DimInfo.Name,
				AttrType:         multiAbnormalInfo.DimInfo.AttrType,
				SelectedOperator: multiAbnormalInfo.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{enumV},
			}
			for _, t := range dt.TargetEntity { // 每个维度组合下，遍历所有指标信息
				if t.Name == targetInfo.Name {
					if multiAbnormalInfo.TargetEntity == nil {
						multiAbnormalInfo.DimInfo = abDimInfo
						multiAbnormalInfo.TargetEntity = t
					} else {
						tVal := (t.Value - t.CycleValue) * targetInfo.CycleChangeRatio
						currVal := (multiAbnormalInfo.TargetEntity.Value - multiAbnormalInfo.TargetEntity.CycleValue) * targetInfo.CycleChangeRatio
						if tVal > currVal {
							multiAbnormalInfo.DimInfo = abDimInfo
							multiAbnormalInfo.TargetEntity = t
						}
					}
				}
			}
		}
	}

	threshold, err := biz_info.GetAbnormalThreshold(ctx)
	if err != nil {
		return
	}
	if multiAbnormalInfo.TargetEntity != nil && len(multiAbnormalInfo.DimInfo.SelectedValues) > 0 &&
		math.Abs(multiAbnormalInfo.TargetEntity.CycleChangeRatio)*100 >= threshold {
		useReq.Dimensions = append(useReq.Dimensions, &dimensions.SelectedDimensionInfo{
			Id:               multiAbnormalInfo.DimInfo.Id,
			Name:             multiAbnormalInfo.DimInfo.Name,
			AttrType:         multiAbnormalInfo.DimInfo.AttrType,
			SelectedOperator: multiAbnormalInfo.DimInfo.SelectedOperator,
			SelectedValues:   []*dimensions.EnumElement{multiAbnormalInfo.DimInfo.SelectedValues[0]},
		})
		err = d.GetMultiDimAbnormalInfo(ctx, useReq, targetInfo, dimColMap, daoDimColMap, dimMap, multiAbnormalInfo.SubDimInfo)
		if err != nil {
			return
		}
	} else {
		multiAbnormalInfo.SubDimInfo = nil
	}

	return
}

var BizRetTargetNameList = []string{consts.AttrNamePayOrdCnt, consts.AttrNamePayGMV}
var BizRetTargetMetaMap = map[string]*dao.TargetMetaInfo{
	consts.AttrNamePayOrdCnt: {
		Name:            consts.AttrNamePayOrdCnt,
		DisplayName:     "支付订单数",
		TargetPrecision: 1,
		ValueType:       "int",
	}, consts.AttrNamePayGMV: {
		Name:            consts.AttrNamePayGMV,
		DisplayName:     "支付GMV",
		TargetPrecision: 1,
		ValueType:       "double",
	},
}

type MultiBizRetConclusionTmp struct {
	multiContributionInfo *analysis.ConclusionMultiContributionInfo
	dimkey                string
}

// GetMultiBizRetConclusion 获取多维分析结果
func GetMultiBizRetConclusion(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, dimColMap map[string]*dimensions.SelectedDimensionInfo, daoDimColMap map[string]*dao.DimensionInfo, dimMap map[int64]*dao.DimensionInfo) (resp *analysis.ConclusionMultiBizRetInfo, marketOpmDimkeyTargetMap map[string]*analysis.TargetCardEntity, err error) {
	resp = &analysis.ConclusionMultiBizRetInfo{
		TotalInfo: make([]*analysis.ConclusionMultiBizTotalInfo, 0),
		ListInfo:  make([]*analysis.ConclusionMultiBizListInfo, 0),
	}
	currTotalMap, currLevelDimTargetMap, err := GetBizInfoMultiRollupListV2(ctx, false, req, dimColMap, daoDimColMap, dimMap)
	if err != nil {
		return nil, nil, err
	}

	marketTotalMap, marketLevelDimTargetMap, err := GetBizInfoMultiRollupListV2(ctx, true, req, dimColMap, daoDimColMap, dimMap)
	if err != nil {
		return nil, nil, err
	}

	firstDimTargetMap, exist := currLevelDimTargetMap[1]
	if !exist {
		return
	}
	totalTargetMap := make(map[string][]*MultiBizRetConclusionTmp)
	for dimKey, targetMap := range firstDimTargetMap {
		for _, tName := range BizRetTargetNameList {
			multiContriList, existM := totalTargetMap[tName]
			if !existM {
				multiContriList = make([]*MultiBizRetConclusionTmp, 0)
			}
			if multiInfo, existT := targetMap[tName]; existT {
				multiContriList = append(multiContriList, &MultiBizRetConclusionTmp{
					multiContributionInfo: multiInfo,
					dimkey:                dimKey,
				})
			}
			totalTargetMap[tName] = multiContriList
		}
	}

	for _, tName := range BizRetTargetNameList {
		totalInfo := &analysis.ConclusionMultiBizTotalInfo{
			TotalTarget: currTotalMap[tName],
		}
		targetList, existT := totalTargetMap[tName]
		if existT {
			sort.Slice(targetList, func(i, j int) bool {
				return targetList[i].multiContributionInfo.TargetEntity.Value > targetList[j].multiContributionInfo.TargetEntity.Value
			})
			if len(targetList) > 0 {
				totalInfo.MultiContributionInfo = []*analysis.ConclusionMultiContributionInfo{
					targetList[0].multiContributionInfo,
				}
			}
		}
		resp.TotalInfo = append(resp.TotalInfo, totalInfo)
	}

	payOrdList, existP := totalTargetMap[consts.AttrNamePayOrdCnt]
	if !existP {
		logs.CtxWarn(ctx, "未发现有效的成交订单数据")
		return
	}

	// 按照支付订单数倒序
	sort.Slice(payOrdList, func(i, j int) bool {
		return payOrdList[i].multiContributionInfo.TargetEntity.Value > payOrdList[j].multiContributionInfo.TargetEntity.Value
	})

	for i, p := range payOrdList {
		if i >= 3 {
			break
		}

		dataInfo := &analysis.ConclusionMultiBizListInfo{
			TitleDim:   p.multiContributionInfo,
			SubDimTree: make([]*analysis.ConclusionMultiContributionInfo, 0),
		}
		for _, tName := range BizRetTargetNameList {
			dimTargetValMap, existB := currLevelDimTargetMap[2]
			if !existB {
				continue
			}

			tmp := make([]*MultiBizRetConclusionTmp, 0)
			for dimKey, targetMap := range dimTargetValMap {
				if base_struct_condition.GetDimKeyParent(dimKey) == p.dimkey {
					multiInfo, existT := targetMap[tName]
					if !existT {
						continue
					}
					multiInfo.MarketPercent = GetMarketPercent(marketLevelDimTargetMap[1], dimKey, tName)
					tmp = append(tmp, &MultiBizRetConclusionTmp{
						multiContributionInfo: multiInfo,
						dimkey:                dimKey,
					})
				}
			}

			if len(tmp) > 0 {
				sort.Slice(tmp, func(i, j int) bool {
					return math.Abs(tmp[i].multiContributionInfo.Contribution-tmp[i].multiContributionInfo.MarketPercent) >
						math.Abs(tmp[j].multiContributionInfo.Contribution-tmp[j].multiContributionInfo.MarketPercent)
				})

				cDimTargetValMap, existC := currLevelDimTargetMap[3]
				if existC {
					cTmp := make([]*analysis.ConclusionMultiContributionInfo, 0)
					for cDimKey, cTargetMap := range cDimTargetValMap {
						if base_struct_condition.GetDimKeyParent(cDimKey) == tmp[0].dimkey {
							cMultiInfo, existCT := cTargetMap[tName]
							if !existCT {
								continue
							}
							cMultiInfo.MarketPercent = GetMarketPercent(marketLevelDimTargetMap[2], cDimKey, tName)
							cTmp = append(cTmp, cMultiInfo)
						}
					}
					sort.Slice(cTmp, func(i, j int) bool {
						return cTmp[i].TargetEntity.Value > cTmp[j].TargetEntity.Value
					})
					tmp[0].multiContributionInfo.SubInfo = cTmp[0]
				}
				dataInfo.SubDimTree = append(dataInfo.SubDimTree, tmp[0].multiContributionInfo)
			}
		}

		resp.ListInfo = append(resp.ListInfo, dataInfo)
	}

	// 加工OPM的大盘指标信息
	marketOpmDimkeyTargetMap = make(map[string]*analysis.TargetCardEntity)
	dimArr := make([]string, len(req.GroupAttrs)-1)
	marketOpmDimkeyTargetMap[strings.Join(dimArr, "###")] = marketTotalMap[consts.AttrNameOPM]
	for _, dimTargetMap := range marketLevelDimTargetMap {
		for dimKey, targetMap := range dimTargetMap {
			if targetEntity, existT := targetMap[consts.AttrNameOPM]; existT && targetEntity != nil {
				marketOpmDimkeyTargetMap[dimKey] = targetEntity.TargetEntity
			}
		}
	}
	fmt.Println(marketOpmDimkeyTargetMap)
	return
}

// GetMarketPercent 获取业务结果的大盘占比
func GetMarketPercent(marketDimTargetMap map[string]map[string]*analysis.ConclusionMultiContributionInfo, dimKey string, tName string) (out float64) {
	if marketDimTargetMap != nil {
		kLen := strings.Index(dimKey, "#") + 3
		if kLen < len(dimKey) {
			marketTargetMap, existMarketD := marketDimTargetMap[dimKey[kLen:]]
			if existMarketD {
				marketMultiInfo, existMarketT := marketTargetMap[tName]
				if existMarketT {
					return marketMultiInfo.Contribution
				}
			}
		}
	}
	return out
}

// GetBizInfoMultiRollupList 多维分析业务结果获取多维列表
func GetBizInfoMultiRollupList(ctx context.Context, isMarket bool, req *dimensions.ProductAnalysisBaseStruct, dimColMap map[string]*dimensions.SelectedDimensionInfo, daoDimColMap map[string]*dao.DimensionInfo, dimMap map[int64]*dao.DimensionInfo) (totalMap map[string]*analysis.TargetCardEntity, levelDimTargetMap map[int]map[string]map[string]*analysis.ConclusionMultiContributionInfo, err error) {
	useReq := &dimensions.ProductAnalysisBaseStruct{}
	copier.CopyWithOption(useReq, *req, copier.Option{DeepCopy: true})
	if isMarket {
		useReq.Dimensions = nil
	}

	// 获取分析的维度信息
	groupCols := make([]string, 0)
	filterMultiExpr := sql_parse.NewCQL()
	for i, attr := range req.GroupAttrs {
		if attr.DimInfo == nil {
			continue
		}
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return nil, nil, errors.New("未查询到维度信息")
		}

		// 查询该维度的枚举值
		if i != 0 || !isMarket {
			groupCols = append(groupCols, dimInfo.DimColumn)

			filterMultiValues := make([]string, 0)
			if attr.DimInfo != nil && len(attr.DimInfo.SelectedValues) > 0 {
				for _, v := range attr.DimInfo.SelectedValues {
					filterMultiValues = append(filterMultiValues, convert.ToString(v.Code))
				}
			}

			if len(filterMultiValues) > 0 {
				filterMultiValues = append(filterMultiValues, consts.Empty)
				filterMultiExpr.AddWhere(dimInfo.DimColumn, sql_parse.IN, filterMultiValues)
			}
		}

	}

	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     useReq,
		DimMap:         dimMap,
		DimColMap:      daoDimColMap,
		MultiDimension: groupCols,
	})
	if err != nil {
		return
	}
	if len(groupCols) > 0 {
		curr["to_str_dimension"] = strings.Join(base_struct_condition.GenerateCastString(groupCols, "str_"), ",")
		curr["str_dimension"] = strings.Join(base_struct_condition.AppendPrefix(groupCols, "str_"), ",")
		curr["str_to_dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(groupCols, "str_"), ",")
	}

	curr["dim_key"] = base_struct_condition.GenerateDimKey(groupCols, consts.Empty)
	if isMarket && filterMultiExpr.WhereClause != nil {
		curr["filter_multi_param"] = sql_parse.NewCQL().ParseExpression(filterMultiExpr.WhereClause)
	}

	curr["group_type"] = "rollup"
	if isMarket && len(groupCols) > 0 {
		curr["group_type"] = "cube"
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(req.BizType), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, ApiPathGetMultiDimTargetList, param.SinkTable("target_data"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_data"), param.SinkTable("target_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"dim_key"}))
	f.ExeProduceSql(`
		select  a.dim_key as dim_key,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				(select b.is_larger_advantage as is_larger_advantage) as extra
		from    target_data a
		inner join
				target_meta b
		on      a.target_name=b.name
		order by b.display_order asc
	`, param.SinkTable("target_data_new")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeProduceSql("select dim_key from target_data group by dim_key", param.SinkTable("dim_key_data"))
	f.ExeProduceSql(`
		select 
			dim_key,
			(
			 	select name,value,display_value,display_name,tips,unit,category_name,extra 
				from target_data_new b where b.dim_key = dim_key_data.dim_key 
			) as target_entity
		from dim_key_data
	`, param.SinkTable("res_data"))
	var dimTargets []*dimKeyTargetEntity
	f.ExeView(param.SourceTable("res_data"), &dimTargets)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetMultiDimFlowTrans]引擎调用失败，err=%v+", err)
		return
	}

	totalMap = make(map[string]*analysis.TargetCardEntity)                                            // 当前整体数据
	levelDimTargetMap = make(map[int]map[string]map[string]*analysis.ConclusionMultiContributionInfo) // 每一层级的数据 level : dim_key : target_key : target_entity
	for _, dt := range dimTargets {
		// 属于整体的数据
		if len(strings.ReplaceAll(dt.DimKey, "###", "")) == 0 {
			for _, t := range dt.TargetEntity {
				totalMap[t.Name] = t
			}
			continue
		}

		dimKeyArr := strings.Split(dt.DimKey, "###")
		dimKeyLen := len(dimKeyArr)
		level := dimKeyLen
		// 收集C维度的数据
		var lastDimCode string
		for i := dimKeyLen - 1; i >= 0; i-- {
			if len(dimKeyArr[i]) > 0 {
				lastDimCode = dimKeyArr[i]
				break
			}
			level = i
		}
		dimTargetValMap, exist := levelDimTargetMap[level]
		if !exist {
			dimTargetValMap = make(map[string]map[string]*analysis.ConclusionMultiContributionInfo)
		}
		targetValMap, existD := dimTargetValMap[dt.DimKey]
		if !existD {
			targetValMap = make(map[string]*analysis.ConclusionMultiContributionInfo)
		}

		if level > len(groupCols) || level == 0 {
			continue
		}

		dimCol := groupCols[level-1]
		reqDim, existReqDim := dimColMap[dimCol]
		if !existReqDim {
			continue
		}
		enumV := GetEnumByDim(lastDimCode, reqDim)
		for _, t := range dt.TargetEntity {
			targetValMap[t.Name] = &analysis.ConclusionMultiContributionInfo{
				DimInfo: &dimensions.SelectedDimensionInfo{
					Id:               reqDim.Id,
					Name:             reqDim.Name,
					AttrType:         reqDim.AttrType,
					SelectedOperator: reqDim.SelectedOperator,
					SelectedValues:   []*dimensions.EnumElement{enumV},
				},
				TargetEntity: t,
			}
		}
		dimTargetValMap[dt.DimKey] = targetValMap
		levelDimTargetMap[level] = dimTargetValMap
	}

	for level, dimTargetMap := range levelDimTargetMap {
		for dimKey, targetMap := range dimTargetMap {
			for tName, tValue := range targetMap {
				if !slices.ContainsString(BizRetTargetNameList, tName) {
					continue
				}
				var totalV *analysis.TargetCardEntity
				if level == 1 {
					totalV = totalMap[tName]
				} else {
					parentLevelMap, existLevel := levelDimTargetMap[level-1]
					if existLevel {
						parentDimkeyMap, existDimkey := parentLevelMap[base_struct_condition.GetDimKeyParent(dimKey)]
						if existDimkey {
							parentTarget, existTarget := parentDimkeyMap[tName]
							if existTarget && parentTarget != nil {
								totalV = parentTarget.TargetEntity
							}
						}
					}
				}

				if tValue != nil && totalV != nil && totalV.Value > 0 {
					tValue.Contribution = tValue.TargetEntity.Value / totalV.Value
					fmt.Println(tValue)
				}
			}
		}
	}

	return
}

func GetConfidenceWarnInfo(ctx context.Context, targets []*analysis.TargetCardEntity) (ret *analysis.ConfidenceWarnInfo, err error) {
	if len(targets) > 0 {
		threshold, err := biz_info.GetConclusionWarnThresholdMap(ctx)
		if err != nil {
			return ret, err
		}
		ret = &analysis.ConfidenceWarnInfo{
			IsWarn:      false,
			TargetValue: make(map[string]float64),
			Threshold:   threshold,
		}
		for _, target := range targets {
			if v, exist := ret.Threshold[target.DisplayName]; exist {
				ret.TargetValue[target.DisplayName] = target.Value
				if target.Value < v {
					ret.IsWarn = true
				}
			}
		}
	}
	return
}

func (d *AnalysisService) GetCoreTargetEntity(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, needTrend bool) ([]*analysis.TargetCardEntity, error) {
	baseTargetCardList := make([]*analysis.TargetCardEntity, 0)

	// 获取全部的指标信息
	targetMetaList, err := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BizType, false)
	if err != nil {
		return nil, err
	}
	req.TargetMetaList = make([]string, 0)
	for _, t := range targetMetaList {
		req.TargetMetaList = append(req.TargetMetaList, t.Name)
	}
	targetCardList, err := d.GetProductAnalysisCoreOverview(ctx, req, needTrend)
	if err != nil {
		return nil, err
	}
	if len(targetCardList) > 0 {
		for _, t := range targetCardList {
			baseTargetCardList = append(baseTargetCardList, t.TargetList...)
		}
	}
	sort.Slice(baseTargetCardList, func(i, j int) bool {
		return baseTargetCardList[i].DisplayOrder < baseTargetCardList[j].DisplayOrder
	})
	return baseTargetCardList, nil
}
