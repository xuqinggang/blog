package analysis_service

import (
	"context"
	"sort"
	"strconv"

	"code.byted.org/aweme-go/hstruct/cast"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/sanity-io/litter"
	"github.com/shopspring/decimal"
)

func (d *AnalysisService) GetProductAnalysisMultiDimProductList(ctx context.Context, req *analysis.GetProductAnalysisMultiDimProductListRequest) (resp *analysis.GetProductAnalysisMultiDimProductListData, err error) {
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
				if dimInfo == nil {
					logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
					return nil, errors.New("未查询到维度信息")
				}
				groupCol = dimInfo.DimColumn
			}
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
	}
	// 如果没传order by 参数，默认根据show_pv排序
	if req.OrderBy == nil {
		var orderField = base.OrderByField_ShowPv
		req.OrderBy = &base.OrderByInfo{
			Field:  &orderField,
			IsDesc: true,
		}
	}

	osReq := base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
		OrderBy:        req.OrderBy,
		PageInfo:       req.PageReq,
	}
	// 获取invoker的入参
	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(curr, ApiPathProductDetail, param.SinkTable("product_detail")).SetParallel(true).SetMaxParallelNum(5)
	// 整体信息，商家数, 商品总数
	f.ExeQueryInvokerRaw(curr, ApiPathProductOverall, param.SinkTable("overview_info")).SetParallel(true).SetMaxParallelNum(5)
	// 输入商品id信息，拿到商品图片信息
	f.ExeProduceCustom([]param.Source{param.SourceTable("product_detail")}, AddProductImage, param.SinkTable("product_images"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("product_detail"), param.SinkTable("target_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"prod_id"}))
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{"指标卡", "商品明细"})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeProduceSql(`
		select  prod_id,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.display_order as display_order
		from    target_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		`, param.SinkTable("target_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeProduceSql(`
		select  a.prod_id as prod_id,
				a.prod_name as prod_name,
				b.images as prod_images,
				shop_id,
				shop_name,
				brand_name,
				complex_brand_s_level as brand_level,
				show_pv,
				pay_ord_cnt as order_num,
				industry_name,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name,
				(select * from target_data where target_data.prod_id = product_detail.prod_id) as target_list
		from    product_detail a
		left join
				product_images b
		on      a.prod_id=b.prod_id
	`, param.SinkTable("res_data"))
	var productInfoList = make([]*ProductInfo, 0)
	var overviewInfo = make(map[string]int64)
	f.ExeView(param.SourceTable("res_data"), &productInfoList)
	f.ExeView(param.SourceTable("overview_info"), &overviewInfo)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	logs.CtxInfo(ctx, "productInfoList = "+litter.Sdump(productInfoList))
	resp, err = PackerProductDetail(req.GetPageReq().GetPageNum(), req.GetPageReq().GetPageSize(), overviewInfo, productInfoList, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "打包结果数据失败,err:"+err.Error())
		return nil, err
	}
	if req.BaseReq.BizType == dimensions.BizType_GrowthProductStrategy {
		err = GetProductDetailCostData(ctx, osReq, resp)
		if err != nil {
			logs.CtxError(ctx, "添加货补数据失败,err:"+err.Error())
			return nil, err
		}
	}
	return resp, nil
}

type ProductInfo struct {
	ProdId              string                       `json:"prod_id"`
	ProdName            string                       `json:"prod_name"`
	ProdImages          []string                     `json:"prod_images"`
	MainImage           string                       `json:"main_image"`
	ShopId              string                       `json:"shop_id"`
	ShopName            string                       `json:"shop_name"`
	BrandId             string                       `json:"brand_id"`
	BrandName           string                       `json:"brand_name"`
	BrandLevel          string                       `json:"brand_level"`
	ShowPv              int64                        `json:"show_pv"`
	OrderNum            int64                        `json:"order_num"`
	IndustryName        string                       `json:"industry_name"`
	FirstLevelCateName  string                       `json:"first_level_cate_name"`
	SecondLevelCateName string                       `json:"second_level_cate_name"`
	LeafCateName        string                       `json:"leaf_cate_name"`
	OnlineStatus        string                       `json:"online_status"`
	SellStatus          string                       `json:"sell_status"`
	PriceRange          string                       `json:"price_range"`
	ProductPriceBelt    string                       `json:"product_price_belt"`
	TargetList          []*analysis.TargetCardEntity `json:"target_list"`
	ProdLevel           string                       `json:"prod_level"`
	SkuId               string                       `json:"sku_id"`
	SkuName             string                       `json:"sku_name"`
	SkuClusterId        string                       `json:"sku_cluster_id"`
	SkuClusterName      string                       `json:"sku_cluster_name"`
	InComparePriceTag   string                       `json:"in_compare_price_tag"`
	OutComparePriceTag  string                       `json:"out_compare_price_tag"`
}

func AddProductImage(ctx context.Context, productTable *onetable.Table) (*onetable.Table, error) {
	productIdList := make([]int64, 0)
	for _, m := range productTable.ToRawMap() {
		if id, ok := m["prod_id"]; ok {
			productIdList = append(productIdList, cast.ToInt64(id.(decimal.Decimal).IntPart()))
		}
	}
	productId2ImageList := make([]map[string]interface{}, 0)
	if len(productIdList) == 0 {
		return onetable.NewTable(productId2ImageList), nil
	}
	productInfoList, err := biz_utils.GetProductInfoByIdList(ctx, productIdList)
	if err != nil || len(productInfoList) == 0 {
		if err != nil {
			logs.CtxWarn(ctx, "获取商品信息失败,err:"+err.Error())
		}
		if len(productInfoList) == 0 {
			logs.CtxWarn(ctx, "商品主图获取失败，返回的数据列表长度为0")
		}
		for _, id := range productIdList {
			t := map[string]interface{}{
				"prod_id":    id,
				"name":       "",
				"images":     []string{},
				"main_image": "",
			}
			productId2ImageList = append(productId2ImageList, t)
		}
		return onetable.NewTable(productId2ImageList), nil
	}
	for _, info := range productInfoList {
		if info != nil {
			convertId, _ := strconv.ParseInt(info.Id, 10, 64)
			t := map[string]interface{}{
				"prod_id":    convertId,
				"name":       info.Name,
				"images":     info.Images,
				"main_image": info.MainImage,
			}
			productId2ImageList = append(productId2ImageList, t)
		}
	}

	return onetable.NewTable(productId2ImageList), nil
}

func PackerProductDetail(pageNum, pageSize int32,
	overviewInfo map[string]int64, productInfoList []*ProductInfo, bizType dimensions.BizType) (
	resp *analysis.GetProductAnalysisMultiDimProductListData, err error) {
	var productCnt, shopCnt int64
	// 校验是否有商家数和商品数
	if _, ok := overviewInfo["product_cnt"]; ok {
		productCnt = overviewInfo["product_cnt"]
		if _, ok1 := overviewInfo["big_link_cnt"]; ok1 {
			productCnt = overviewInfo["big_link_cnt"]
		}
	}
	if _, ok := overviewInfo["shop_cnt"]; ok {
		shopCnt = overviewInfo["shop_cnt"]
	}
	resp = &analysis.GetProductAnalysisMultiDimProductListData{
		ProductList: make([]*analysis.MultiDimProductInfo, 0),
		PageInfo: &base.PageResp{
			PageNum:  pageNum,
			PageSize: pageSize,
			Total:    productCnt,
		},
		ShopCnt: shopCnt,
	}

	for _, info := range productInfoList {
		// 对target_list进行排序
		if len(info.TargetList) > 0 {
			sort.Slice(info.TargetList, func(i, j int) bool {
				return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
			})
		}
		productInfo := &analysis.MultiDimProductInfo{
			ProductInfo: &basic_info.ProductBasicInfo{Id: info.ProdId, Name: info.ProdName, Images: info.ProdImages},
			ShopInfo:    &basic_info.ShopBasicInfo{Id: info.ShopId, Name: info.ShopName},
			BrandInfo:   &basic_info.BrandBasicInfo{Name: info.BrandName, Level: info.BrandLevel},
			SkuInfo: &basic_info.SkuBasicInfo{Id: info.SkuId, Name: info.SkuName,
				SkuClusterId: info.SkuClusterId, SkuClusterName: info.SkuClusterName,
				OutComparePriceTag: info.OutComparePriceTag, InComparePriceTag: info.InComparePriceTag},
			ShowPv:              info.ShowPv,
			OrderNum:            info.OrderNum,
			IndustryName:        info.IndustryName,
			FirstLevelCateName:  info.FirstLevelCateName,
			SecondLevelCateName: info.SecondLevelCateName,
			LeafCateName:        info.LeafCateName,
			TargetList:          info.TargetList,
			DimMap:              make(map[string]string),
		}
		if bizType == dimensions.BizType_MorningMarketProduct {
			productInfo.DimMap["早市商品分层"] = info.ProdLevel
		}
		resp.ProductList = append(resp.ProductList, productInfo)
	}
	return
}

func (d *AnalysisService) GetProductAnalysisProdCnt(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisProdCntItem, err error) {
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
				if dimInfo == nil {
					logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
					return nil, errors.New("未查询到维度信息")
				}
				groupCol = dimInfo.DimColumn
			}
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
	}

	osReq := base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
	}
	// 获取invoker的入参
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "获取业务线信息失败 err=%v", err.Error())
		return
	}
	if bizMetaInfo.EffectModule == "大促视图" {
		curr["is_big_activity"] = 1
	}
	if req.OverallReq != nil && req.OverallReq.BaseReq != nil {
		req.OverallReq.BaseReq.StartDate = req.BaseReq.StartDate
		req.OverallReq.BaseReq.EndDate = req.BaseReq.EndDate
		overallOsReq := base_struct_condition.OsParamsReq{
			BaseStruct:     req.OverallReq.BaseReq,
			DimMap:         dimMap,
			DimColMap:      dimColMap,
			MultiDimension: []string{groupCol},
		}
		overallParam, _ := base_struct_condition.GetBaseStructConditionParam(ctx, overallOsReq, base_struct_condition.SQLCalcType_Curr)
		curr["overall_is_open"] = 1
		curr["overall_filter_param"] = overallParam["filter_param"]
		curr["overall_date_expr"] = overallParam["date_expr"]
		curr["overall_start_date"] = overallParam["start_date"]
		curr["overall_end_date"] = overallParam["end_date"]
	}

	apiPath := ApiPathProductOverall
	if req.BaseReq.BizType == dimensions.BizType_BillionSupply {
		apiPath = ApiPathProductOverallBillionSupply
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// 整体信息，商家数, 商品总数
	f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("overview_info")).SetParallel(true).SetMaxParallelNum(5)
	f.ExeProduceSql(`select product_cnt as prod_cnt, shop_cnt, big_link_cnt,overall_prod_cnt from overview_info`, param.SinkTable("overview_info"))
	resp = &analysis.GetProductAnalysisProdCntItem{}
	f.ExeView(param.SourceTable("overview_info"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return resp, nil
}
