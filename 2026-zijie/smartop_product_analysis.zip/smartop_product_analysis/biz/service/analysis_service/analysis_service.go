package analysis_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"github.com/bytedance/sonic"
	"github.com/jinzhu/copier"
	"math"
	"sort"
)

// GetProductAnalysisMultiDimList 获取维度列表清单
func (d *AnalysisService) GetProductAnalysisMultiDimList(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, needTrend bool) (resp []*analysis.MultiDimListRow, err error) {
	if len(req.GroupAttrs) == 0 {
		return nil, errors.New("获取多维分析参数失败")
	}
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取map失败，err=%v+", err)
		return nil, err
	}

	dimColMap, err := d.DimensionListDao.GetDimensionColMap(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取col map失败，err=%v+", err)
		return nil, err
	}

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	var prodCodeTagBaseDim = &dimensions.SelectedDimensionInfo{}
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.Dimensions = append(req.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
				prodCodeTagBaseDim = attr.DimInfo
			}
			req.Dimensions = append(req.Dimensions, attr.DimInfo)
		}
	}
	if len(groupCol) == 0 {
		logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
		return resp, errors.New("多维分析未传入多维配置")
	}

	osReq := base_struct_condition.OsParamsReq{
		BaseStruct:     req,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
	}

	curr, compare, trend, trendSuffix, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	curr["not_base_settings"] = consts.IsTrueString
	compare["not_base_settings"] = consts.IsTrueString
	if err != nil {
		return
	}
	apiPath := bizInfo.TargetCardApiID
	var productCostTargetMap map[string]map[string]*analysis.TargetCardEntity
	var targetKeyMap map[string]*analysis.TargetCardEntity
	// 货补数据走并发获取
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		if req.BizType == dimensions.BizType_GrowthProductStrategy {
			productCostTargetMap, targetKeyMap, err = GetMultipleAnalysisCostData(ctx, osReq, needTrend)
			if err != nil {
				logs.CtxError(ctx, "添加货补数据失败,err:%v", err.Error())
				return err
			}
		}
		return nil
	})

	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BizType, KeyCols: []string{groupCol}, NeedDistribution: true,
	})
	if err != nil {
		return nil, err
	}
	compareTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: compare, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BizType, KeyCols: []string{groupCol},
	})
	if err != nil {
		return nil, err
	}
	currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumn(currTargetList, compareTargetList, nil, nil)

	if needTrend {
		trend["not_base_settings"] = consts.IsTrueString
		trendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: trend, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BizType, KeyCols: []string{groupCol}, TrendCol: "date",
		})
		if err != nil {
			return nil, err
		}
		trendSuffixMap := make(map[string]map[string][]*analysis.TargetTrendPoint)
		if trendSuffix != nil {
			trendSuffix["not_base_settings"] = false
			trendSuffixMap, err = base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: trendSuffix, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BizType, KeyCols: []string{groupCol}, TrendCol: "date",
			})
			if err != nil {
				return nil, err
			}
		}
		currTargetList = base_struct_condition.AddTargetTrend(currTargetList, trendMap, trendSuffixMap)
	}

	resp = make([]*analysis.MultiDimListRow, 0)
	for _, info := range currTargetList {
		if len(info.KeyColValues) > 0 {
			resp = append(resp, &analysis.MultiDimListRow{
				EnumValue:  convert.ToString(info.KeyColValues[0]),
				TargetList: info.TargetEntity,
			})
		}
	}

	sumMap := make(map[string]float64)
	for _, info := range resp {
		sort.Slice(info.TargetList, func(i, j int) bool {
			return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
		})

		for _, i := range info.TargetList {
			if i.Extra.DistributionFlag {
				sumMap[i.Name] += i.Value
			}
		}
		info.DisplayName = enumCodeMap[info.EnumValue]
	}

	for _, info := range resp {
		for _, i := range info.TargetList {
			if i.Extra.DistributionFlag {
				if v, exist := sumMap[i.Name]; exist && v > 0 {
					i.Extra.DistributionValue = i.Value / sumMap[i.Name]
					continue
				}
			}
			i.Extra.DistributionValue = 0
		}
	}
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "并发对象wait失败, err:"+err.Error())
		return nil, err
	}
	// 添加货补数据
	AddProdCostData(ctx, productCostTargetMap, targetKeyMap, resp)
	// 添加prod_tag_code
	for _, row := range resp {
		codeStruct := &dimensions.SelectedDimensionInfo{
			Id:               prodCodeTagBaseDim.Id,
			Name:             prodCodeTagBaseDim.Name,
			AttrType:         prodCodeTagBaseDim.AttrType,
			SelectedOperator: prodCodeTagBaseDim.SelectedOperator,
			SelectedValues:   []*dimensions.EnumElement{{Code: row.EnumValue, Name: row.DisplayName}},
			IsGroup:          false,
		}
		marshalString, err := sonic.MarshalString(codeStruct)
		if err != nil {
			logs.CtxError(ctx, "序列化prod_tag_code失败,err:"+err.Error())
		}
		row.ProdTagCode = marshalString
	}
	return resp, nil
}

func (d *AnalysisService) GetProductAnalysisCoreConclusion(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp *analysis.ProductAnalysisCoreConclusionData, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	resp = &analysis.ProductAnalysisCoreConclusionData{
		BusinessRet: make([]*analysis.TargetCardEntity, 0),
		ProdConstruction: &analysis.ConclusionProdConstructInfo{
			RelateDims:      make([]*analysis.ConclusionProdDimCntInfo, 0),
			DimContribution: make([]*analysis.ConclusionProdDimContributionInfo, 0),
		},
		FlowEfficiency: make([]*analysis.TargetCardEntity, 0),
		ProdEfficiency: make([]*analysis.TargetCardEntity, 0),
	}

	_, ctx, err = biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil {
		return nil, err
	}
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	// 获取基础指标卡数据
	baseTargetCardList, err := d.GetCoreTargetEntity(ctx, req, false)
	if err != nil {
		return nil, err
	}
	if len(baseTargetCardList) == 0 {
		logs.CtxError(ctx, "基础指标卡信息获取为空,req=%s", convert.ToJSONString(req))
		return nil, errors.New("基础指标卡信息获取为空")
	}
	//var baseTargetCardList []*analysis.TargetCardEntity
	warnInfo, err := GetConfidenceWarnInfo(ctx, baseTargetCardList)
	if err != nil {
		return
	}
	if warnInfo != nil {
		resp.WarnInfo = warnInfo
	}

	dimFilterCategory, transName, err := biz_info.GetFilterDimCategory(ctx, req)
	if err != nil {
		return nil, err
	}
	ctx = context.WithValue(ctx, consts.CtxBizInfoDimCategory, dimFilterCategory)

	var totalPayCnt int64
	for _, info := range baseTargetCardList {
		newInfo := base_struct_condition.UpdateTargetDisplayName(info, transName)
		if newInfo == nil {
			continue
		}

		// 支付订单数
		if info.Name == "pay_ord_cnt" {
			totalPayCnt = convert.ToInt64(info.Value)
		}

		if slices.ContainsString(bizMetaInfo.ConclusionTargetMap["businessTargetNames"], info.Name) {
			resp.BusinessRet = append(resp.BusinessRet, newInfo)
		}
		if slices.ContainsString(bizMetaInfo.ConclusionTargetMap["flowEfficiencyTargetNames"], info.Name) {
			resp.FlowEfficiency = append(resp.FlowEfficiency, newInfo)
		}
		if slices.ContainsString(bizMetaInfo.ConclusionTargetMap["prodEfficiencyTargetNames"], info.Name) {
			resp.ProdEfficiency = append(resp.ProdEfficiency, newInfo)
		}
	}

	var cateCntInfo []*analysis.ConclusionProdDimCntInfo                   // 货品结构-类目数量
	var firstCateContribution *analysis.ConclusionProdDimContributionInfo  // 货品结构-一级类目下探
	var secondCateContribution *analysis.ConclusionProdDimContributionInfo // 货品结构-二级类目下探
	var leafCateContribution *analysis.ConclusionProdDimContributionInfo   // 货品结构-一级类目下探
	var hierarchicalInfoInfo []*analysis.HierarchicalInfo                  // 装载货品效率-单量分层占比
	//
	// 开启协程
	cc := co.NewConcurrent(ctx)

	/*
		装载货品结构数据
	*/

	if dimFilterCategory == dimensions.FilterDimCategory_PotentialUsers { // 如果是潜客则不计算
		return
	}
	cc.GoV2(func() error {
		// 计算类目的数量
		cateCntInfo, err = GetCateByCnt(ctx, req, ConclusionDimReq{DimMap: dimMap})
		//if err != nil {
		//	return
		//}
		return err
	})

	cc.GoV2(func() error {
		// 一级类目下探
		firstCateContribution, err = GetDimContributionInfo(ctx, req, ConclusionDimReq{
			EnumCodeCol: "first_level_cate_id",
			EnumNameCol: "first_level_cate_name",
			DimId:       consts.FirstCateDim,
			DimMap:      dimMap,
		}, totalPayCnt)
		//if err != nil {
		//	return
		//}
		return err
	})

	cc.GoV2(func() error {
		// 二级类目下探
		secondCateContribution, err = GetDimContributionInfo(ctx, req, ConclusionDimReq{
			EnumCodeCol: "second_level_cate_id",
			EnumNameCol: "second_level_cate_name",
			DimId:       consts.SecondCateDim,
			DimMap:      dimMap,
		}, totalPayCnt)
		//if err != nil {
		//	return
		//}
		return err
	})

	//cc.GoV2(func() error {
	// 叶子类目下探
	//leafCateContribution, err = GetDimContributionInfo(ctx, req, ConclusionDimReq{
	//	EnumCodeCol: "leaf_cate_id",
	//	EnumNameCol: "leaf_cate_name",
	//	DimId:       consts.LeafCateDim,
	//	DimMap:      dimMap,
	//}, totalPayCnt)
	//if err != nil {
	//	return
	//}
	//})

	cc.GoV2(func() error {
		// 装载货品效率-单量分层占比
		hierarchicalInfoInfo, err = GetProdPayCntHierarchical(ctx, req, dimMap)
		//if err != nil {
		//	return
		//}
		return err
	})

	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreConclusion]查询结论相关信息失败, err: %v", err)
		return
	}

	// 填充数据
	resp.BusinessRet = SortTargetCardEntityByName(resp.BusinessRet, bizMetaInfo.ConclusionTargetMap["businessTargetNames"])
	resp.FlowEfficiency = SortTargetCardEntityByName(resp.FlowEfficiency, bizMetaInfo.ConclusionTargetMap["flowEfficiencyTargetNames"])
	resp.ProdEfficiency = SortTargetCardEntityByName(resp.ProdEfficiency, bizMetaInfo.ConclusionTargetMap["prodEfficiencyTargetNames"])

	if len(cateCntInfo) > 0 {
		resp.ProdConstruction.RelateDims = cateCntInfo
	}

	if firstCateContribution != nil {
		resp.ProdConstruction.DimContribution = append(resp.ProdConstruction.DimContribution, firstCateContribution)
	}

	if secondCateContribution != nil {
		resp.ProdConstruction.DimContribution = append(resp.ProdConstruction.DimContribution, secondCateContribution)
	}

	if leafCateContribution != nil {
		resp.ProdConstruction.DimContribution = append(resp.ProdConstruction.DimContribution, leafCateContribution)
	}

	// 补充货品结构 分层数据的取数列名和指标名
	resp.ProdConstruction.HierarchicalColInfo = []*analysis.HierarchicalColInfo{
		{"product_price_belt", []string{"pay_prod_cnt", "pay_ord_cnt"}},
		{"price_range", []string{"pay_prod_cnt", "pay_ord_cnt"}},
	}

	if len(hierarchicalInfoInfo) > 0 {
		resp.ProdHierarchical = append(resp.ProdHierarchical, hierarchicalInfoInfo...)
	}

	return
}

func SortTargetCardEntityByName(targetEntitys []*analysis.TargetCardEntity, targetList []string) []*analysis.TargetCardEntity {
	sort.Slice(targetEntitys, func(i, j int) bool {
		var valI, valJ int
		for index, t := range targetList {
			if targetEntitys[i].Name == t {
				valI = index
			}
			if targetEntitys[j].Name == t {
				valJ = index
			}
		}

		return valI < valJ
	})
	return targetEntitys
}

func (d *AnalysisService) GetProductAnalysisMultiDimConclusion(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp *analysis.ProductAnalysisMultiDimConclusionData, err error) {
	resp = &analysis.ProductAnalysisMultiDimConclusionData{}
	filterDimCat, _, err := biz_info.GetFilterDimCategory(ctx, req)
	if err != nil {
		return nil, err
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	category, transName, err := biz_info.GetFilterDimCategory(ctx, req)
	if err != nil {
		return
	}
	ctx = context.WithValue(ctx, consts.CtxBizInfoDimCategory, category)

	_, ctx, err = biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil {
		return
	}

	if len(req.GroupAttrs) == 0 {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimConclusion]失败，err=%v+", err)
		return
	}

	for _, attr := range req.GroupAttrs {
		req.Dimensions = append(req.Dimensions, attr.DimInfo)
	}

	// 获取基础指标卡数据
	baseTargetCardList, err := d.GetCoreTargetEntity(ctx, req, false)
	if err != nil {
		return nil, err
	}
	if len(baseTargetCardList) == 0 {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimConclusion]基础指标卡信息获取为空,req=%s", convert.ToJSONString(req))
		return nil, errors.New("基础指标卡信息获取为空")
	}

	warnInfo, err := GetConfidenceWarnInfo(ctx, baseTargetCardList)
	if err != nil {
		return
	}
	if warnInfo != nil {
		resp.WarnInfo = warnInfo
	}

	threshold, err := biz_info.GetAbnormalThreshold(ctx)
	if err != nil {
		return
	}
	pvTargets := make([]*analysis.TargetCardEntity, 0)
	otherTargets := make([]*analysis.TargetCardEntity, 0)
	var needGetPv, needGetOther bool
	targetMap := make(map[string]*analysis.TargetCardEntity, 0)
	for _, info := range baseTargetCardList {
		newInfo := base_struct_condition.UpdateTargetDisplayName(info, transName)
		if newInfo == nil {
			continue
		}

		targetMap[info.Name] = newInfo
		// 动销商品数、支付订单数
		if slices.ContainsString([]string{"pay_ord_cnt", "pay_prod_cnt"}, info.Name) {
			if math.Abs(info.CycleChangeRatio)*100 >= threshold {
				needGetOther = true
			}
			otherTargets = append(otherTargets, info)
		}

		// 曝光PV
		if info.Name == "show_pv" {
			if math.Abs(info.CycleChangeRatio)*100 >= threshold {
				needGetPv = true
			}
			pvTargets = append(pvTargets, info)
		}
	}

	//// 开启协程
	//cc := co.NewConcurrent(ctx)

	var bizRetInfo *analysis.ConclusionMultiBizRetInfo
	var marketOpmDimkeyTargetMap map[string]*analysis.TargetCardEntity
	var flowTrans []*analysis.ConclusionProdDimContributionInfo

	var abnormalPayOrdCnt *analysis.MultiDimConclusionAbnormalInfo
	var abnormalShowPv *analysis.MultiDimConclusionAbnormalInfo
	var abnormalShowProdCnt *analysis.MultiDimConclusionAbnormalInfo
	var abnormalProdPayShowRate *analysis.MultiDimConclusionAbnormalInfo
	var abnormalProdAvgOrdCnt *analysis.MultiDimConclusionAbnormalInfo

	dimEnumInfoMap, err := GetMultiDimEnumMap(ctx, req.GroupAttrs, dimMap)
	if err != nil || dimEnumInfoMap == nil {
		return
	}

	// 获取业务结果
	bizRetInfo, marketOpmDimkeyTargetMap, err = GetMultiBizRetConclusion(ctx, req, dimEnumInfoMap.dimMap, dimColMap, dimMap)
	if err != nil {
		return
	}

	//cc.GoV2(func() error {
	// 获取流量转化信息
	flowTrans, err = GetMultiDimFlowTrans(ctx, req, filterDimCat, dimMap, dimColMap, marketOpmDimkeyTargetMap)
	if err != nil {
		return
	}
	if len(flowTrans) > 0 {
		for _, f := range flowTrans {
			if f == nil {
				continue
			}

			if transName != nil && len(transName.RenameMap) > 0 && f.OrderTargetName != nil {
				if newName, exist := transName.RenameMap[*f.OrderTargetName]; exist {
					f.OrderTargetName = &newName
				}
			}

			if len(f.TargetEntity) > 0 {
				tmp := make([]*analysis.TargetCardEntity, 0)
				for _, ft := range f.TargetEntity {
					newInfo := base_struct_condition.UpdateTargetDisplayName(ft, transName)
					if newInfo == nil {
						continue
					}
					tmp = append(tmp, newInfo)
				}
				f.TargetEntity = tmp
			}
		}
	}

	//})

	if needGetPv {
		//cc.GoV2(func() error {
		// 补充一级、二级入口维度+枚举
		dimMapBiz, err := d.DimensionListDao.GetDimensionMap(ctx, req.BizType)
		if err != nil {
			logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取map失败，err=%v+", err)
			return nil, err
		}
		firstEntrance := dimMapBiz[convert.ToInt64(consts.BTMFirstEntranceDim)]
		secondEntrance := dimMapBiz[convert.ToInt64(consts.BTMSecondEntranceDim)]
		firstDimInfo, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(consts.BTMFirstEntranceDim))
		if err != nil {
			return resp, err
		}
		secondDimInfo, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(consts.BTMSecondEntranceDim))
		if err != nil {
			return resp, err
		}

		useReq := &dimensions.ProductAnalysisBaseStruct{}
		copier.CopyWithOption(useReq, *req, copier.Option{DeepCopy: true})

		firstSelectDimInfo := dao.TransSelectByDimInfo(firstEntrance, firstDimInfo.Values)
		secondSelectDimInfo := dao.TransSelectByDimInfo(secondEntrance, secondDimInfo.Values)
		if firstSelectDimInfo == nil || secondSelectDimInfo == nil {
			abnormalShowPv = SetAbnormalTreeByGroupAttrs(req.GroupAttrs)
		} else {
			dimEnumInfoMap.dimMap[firstEntrance.DimColumn] = firstSelectDimInfo
			dimEnumInfoMap.dimMap[secondEntrance.DimColumn] = secondSelectDimInfo
			abnormalShowPv = &analysis.MultiDimConclusionAbnormalInfo{
				DimInfo:    firstSelectDimInfo,
				SubDimInfo: &analysis.MultiDimConclusionAbnormalInfo{DimInfo: secondSelectDimInfo},
			}

			useReq.Dimensions = append(useReq.Dimensions, firstSelectDimInfo)
		}

		err = d.GetMultiDimAbnormalInfoV2(ctx, useReq, targetMap[consts.AttrNameShowPV], dimEnumInfoMap.dimMap, dimColMap, dimMap, abnormalShowPv)
		//abnormalPv, err = d.GetMultiDimAbnormal(ctx, req, dimMap, pvTargets, targetMap)
		if err != nil {
			return resp, err
		}
		pvTargets = make([]*analysis.TargetCardEntity, 0)
		//})
	}

	if needGetOther {
		//// 开启协程
		cc := co.NewConcurrent(ctx)
		if len(otherTargets) == 1 && otherTargets[0].Name == consts.AttrNamePayOrdCnt {
			cc.GoV2(func() error {
				abnormalPayOrdCnt = SetAbnormalTreeByGroupAttrs(req.GroupAttrs)
				err = d.GetMultiDimAbnormalInfoV2(ctx, req, targetMap[consts.AttrNamePayOrdCnt], dimEnumInfoMap.dimMap, dimColMap, dimMap, abnormalPayOrdCnt)
				//abnormalPv, err = d.GetMultiDimAbnormal(ctx, req, dimMap, pvTargets, targetMap)
				if err != nil {
					return err
				}
				otherTargets = make([]*analysis.TargetCardEntity, 0)
				return nil
			})
		}

		cc.GoV2(func() error {
			abnormalShowProdCnt = SetAbnormalTreeByGroupAttrs(req.GroupAttrs)
			err = d.GetMultiDimAbnormalInfoV2(ctx, req, targetMap[consts.AttrNameShowProdCnt], dimEnumInfoMap.dimMap, dimColMap, dimMap, abnormalShowProdCnt)
			//abnormalPv, err = d.GetMultiDimAbnormal(ctx, req, dimMap, pvTargets, targetMap)
			return err
		})

		cc.GoV2(func() error {
			abnormalProdPayShowRate = SetAbnormalTreeByGroupAttrs(req.GroupAttrs)
			err = d.GetMultiDimAbnormalInfoV2(ctx, req, targetMap[consts.AttrNameProdPayShowRate], dimEnumInfoMap.dimMap, dimColMap, dimMap, abnormalProdPayShowRate)
			//abnormalPv, err = d.GetMultiDimAbnormal(ctx, req, dimMap, pvTargets, targetMap)
			return err
		})

		cc.GoV2(func() error {
			abnormalProdAvgOrdCnt = SetAbnormalTreeByGroupAttrs(req.GroupAttrs)
			err = d.GetMultiDimAbnormalInfoV2(ctx, req, targetMap[consts.AttrNamePayProdAvgOrdCnt], dimEnumInfoMap.dimMap, dimColMap, dimMap, abnormalProdAvgOrdCnt)
			//abnormalPv, err = d.GetMultiDimAbnormal(ctx, req, dimMap, pvTargets, targetMap)
			return err
		})

		cc.WaitV2()
		if err != nil {
			logs.CtxError(ctx, "[GetProductAnalysisMultiDimConclusion]查询结论other下钻相关信息失败, err: %v", err)
			return
		}
	}

	if bizRetInfo != nil {
		resp.BizRet = bizRetInfo
	}

	if len(flowTrans) > 0 {
		resp.FlowTrans = flowTrans
	}

	resp.AbnormalData = make([]*analysis.MultiDimConclusionAbnormalData, 0)
	if abnormalShowPv == nil || abnormalShowPv.TargetEntity == nil {
		resp.AbnormalData = append(resp.AbnormalData, &analysis.MultiDimConclusionAbnormalData{WarnMsg: "未发现曝光PV的明显异动"})
	} else {
		resp.AbnormalData = append(resp.AbnormalData, &analysis.MultiDimConclusionAbnormalData{
			TargetEntity: pvTargets,
			AbnormalInfo: []*analysis.MultiDimConclusionAbnormalInfo{{
				TargetEntity: targetMap[consts.AttrNameShowPV],
				SubDimInfo:   abnormalShowPv,
			}},
		})
	}

	otherAbnormalInfos := make([]*analysis.MultiDimConclusionAbnormalInfo, 0)
	if abnormalPayOrdCnt != nil && abnormalPayOrdCnt.TargetEntity != nil {
		otherAbnormalInfos = append(otherAbnormalInfos, &analysis.MultiDimConclusionAbnormalInfo{
			TargetEntity: targetMap[consts.AttrNamePayOrdCnt],
			SubDimInfo:   abnormalPayOrdCnt,
		})
	}
	if abnormalShowProdCnt != nil && abnormalShowProdCnt.TargetEntity != nil {
		otherAbnormalInfos = append(otherAbnormalInfos, &analysis.MultiDimConclusionAbnormalInfo{
			TargetEntity: targetMap[consts.AttrNameShowProdCnt],
			SubDimInfo:   abnormalShowProdCnt,
		})
	}
	if abnormalProdPayShowRate != nil && abnormalProdPayShowRate.TargetEntity != nil {
		otherAbnormalInfos = append(otherAbnormalInfos, &analysis.MultiDimConclusionAbnormalInfo{
			TargetEntity: targetMap[consts.AttrNameProdPayShowRate],
			SubDimInfo:   abnormalProdPayShowRate,
		})
	}
	if abnormalProdAvgOrdCnt != nil && abnormalProdAvgOrdCnt.TargetEntity != nil {
		otherAbnormalInfos = append(otherAbnormalInfos, &analysis.MultiDimConclusionAbnormalInfo{
			TargetEntity: targetMap[consts.AttrNamePayProdAvgOrdCnt],
			SubDimInfo:   abnormalProdAvgOrdCnt,
		})
	}
	if len(otherAbnormalInfos) == 0 {
		resp.AbnormalData = append(resp.AbnormalData, &analysis.MultiDimConclusionAbnormalData{WarnMsg: "未发现动销商品数与支付订单数的明显异动"})
	} else {
		resp.AbnormalData = append(resp.AbnormalData, &analysis.MultiDimConclusionAbnormalData{
			TargetEntity: otherTargets,
			AbnormalInfo: otherAbnormalInfos,
		})
	}
	return
}

func SetAbnormalTreeByGroupAttrs(groupAttrs []*dimensions.SelectedMultiDimensionInfo) *analysis.MultiDimConclusionAbnormalInfo {
	var multiInfo *analysis.MultiDimConclusionAbnormalInfo

	for i, g := range groupAttrs {
		if i == 0 {
			multiInfo = &analysis.MultiDimConclusionAbnormalInfo{
				DimInfo: &dimensions.SelectedDimensionInfo{
					Id:               g.DimInfo.Id,
					Name:             g.DimInfo.Name,
					AttrType:         g.DimInfo.AttrType,
					SelectedOperator: g.DimInfo.SelectedOperator,
				},
			}
			continue
		}

		multiInfo = SetAbnormalSingleDim(multiInfo, g)
	}
	return multiInfo
}

func SetAbnormalSingleDim(multiInfo *analysis.MultiDimConclusionAbnormalInfo, appendInfo *dimensions.SelectedMultiDimensionInfo) *analysis.MultiDimConclusionAbnormalInfo {
	appendV := &analysis.MultiDimConclusionAbnormalInfo{
		DimInfo: &dimensions.SelectedDimensionInfo{
			Id:               appendInfo.DimInfo.Id,
			Name:             appendInfo.DimInfo.Name,
			AttrType:         appendInfo.DimInfo.AttrType,
			SelectedOperator: appendInfo.DimInfo.SelectedOperator,
		},
	}

	if multiInfo.SubDimInfo == nil {
		multiInfo.SubDimInfo = appendV
		return multiInfo
	}

	return SetAbnormalSingleDim(multiInfo.SubDimInfo, appendInfo)
}
