package analysis_service

import (
	"context"
	"fmt"
	"sort"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"
	"github.com/sanity-io/litter"
)

func (d *AnalysisService) GetProductAnalysisCoreOverview(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, needTrend bool) (resp []*analysis.TargetCategoryList, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	//var cacheResp []*analysis.TargetCategoryList
	//cacheResp, err = base_struct_condition.GetCacheResp(ctx, consts.CacheFuncNameCoreOverviewPrefix, req, cacheResp)
	//if err == nil && cacheResp != nil {
	//	return cacheResp, nil
	//}
	// 获取业务线的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)

	apiPathOverall := bizMetaInfo.TargetCardOverallApiID
	apiPath := bizMetaInfo.TargetCardApiID
	if base_struct_condition.NeedAggregateProdId(req) {
		apiPath = bizMetaInfo.TargetCardOverallApiID
	}
	resp, err = GetTargetCard(ctx, req, needTrend, dimMap, apiPath, apiPathOverall)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreOverview]获取指标卡数据失败，err=%v", err)
		return nil, err
	}
	SortTargetCard(ctx, resp)
	return resp, nil
}

func GetTargetCard(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, needTrend bool, dimMap map[int64]*dao.DimensionInfo, apiPath, apiPathOverall string) ([]*analysis.TargetCategoryList, error) {
	resp := make([]*analysis.TargetCategoryList, 0)
	// 获取invoker的入参
	curr, compare, trend, trendSuffix, overall, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
		UvFlag:     req.UvFlag,
	})
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return nil, err
	}
	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{"货盘核心指标", "指标卡"}), param.SourceConst(req.TargetMetaList)}, dao.GetFilterTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("target_card")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(compare, apiPath, param.SinkTable("target_card_cycle")).SetParallel(true).SetMaxParallelNum(10)
	// 指标卡大盘数据
	f.ExeQueryInvokerRaw(overall, apiPathOverall, param.SinkTable("whole_target")).SetParallel(true).SetMaxParallelNum(10)
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card_cycle"), param.SinkTable("target_card_cycle")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("whole_target"), param.SinkTable("whole_target")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	var trendSubSql string
	// 是否需要趋势图
	if needTrend {
		trend["not_base_settings"] = false
		f.ExeQueryInvokerRaw(trend, apiPath, param.SinkTable("trend_data")).SetParallel(true).SetMaxParallelNum(10)
		if trendSuffix != nil {
			trendSuffix["not_base_settings"] = false
			f.ExeQueryInvokerRaw(trendSuffix, apiPath, param.SinkTable("trend_data2")).SetParallel(true).SetMaxParallelNum(10)
			f.ExeProduceSql(`select * from trend_data union all select * from trend_data2`, param.SinkTable("trend_data"))
		}
		f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").
			SetDimColumns([]string{"date"}))
		// 趋势图加工sql
		trendSubSql = `
		(select  custom_date(date) as x,
				target_name as name,
				m.display_name as display_name,
				target_value as value,
				get_display_value(target_value, m.value_type, m.value_unit,m.target_precision) as display_value
		from    trend_data t
		inner join target_meta m
		on t.target_name = m.name
		where   t.target_name=target_card_new.name
		order by x asc)
	`
	} else {
		trendSubSql = `null`
	}
	// 计算环比,关联大盘数据, 这里直接相减得到pp值，后续根据元信息判断返回pp值还是环比
	f.ExeProduceSql(`
		select 
			a.target_name as name,
			a.target_value as value,
			b.target_value as cycle_value,
			c.target_value as whole_value,
			(a.target_value-b.target_value) / b.target_value as cycle_change_ratio,
			a.target_value-b.target_value as cycle_change_pp
		from target_card a 
		left join target_card_cycle b
		on a.target_name = b.target_name
		left join whole_target c
		on a.target_name = c.target_name
	`, param.SinkTable("target_card_new"))
	// 大盘数据子sql
	// case when a.is_compute_percent = true 即使是个bool值，也得用 = true判断，框架没有开这个口子
	marketSubSql := `
				(
				select  b.whole_value as market_value,
						get_display_value(b.whole_value, a.value_type, a.value_unit,a.target_precision) as display_value,
						a.is_compute_percent as percent_flag,
						case
							when a.is_compute_percent = true then b.value/b.whole_value
							else 0
						end as market_percent,
						a.is_larger_advantage as is_larger_advantage,
						is_distribution as distribution_flag
				)`
	//marketSubSql := `null`
	// 关联指标元信息, 处理额外信息
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.name as name,
				b.value as value,
				get_display_value(b.value, a.value_type, a.value_unit,a.target_precision) as display_value,
				b.cycle_value as cycle_value,
				get_display_value(b.cycle_value, a.value_type, a.value_unit,a.target_precision) as cycle_display_value,
				%v as trend_data,
				case 
					when a.is_use_pp = true then b.cycle_change_pp 
					else b.cycle_change_ratio 
				end as cycle_change_ratio,
				a.display_name as display_name,
				add_second_query_tips_prefix(a.tips, a.need_second_query) as tips,
				a.value_unit as unit,
				a.attribute_type as category_name,
				%v as extra,
				a.display_order as display_order,
				a.need_second_query as need_second_query,
				a.is_use_pp as is_use_pp
		from    target_meta a
		inner join
				target_card_new b
		on      a.name=b.name
		order by a.display_order asc
	`, trendSubSql, marketSubSql), param.SinkTable("card_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value":            onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":                  onetable.NormalFunc(framework_udf.CustomDate),
		"add_second_query_tips_prefix": onetable.NormalFunc(addTipsPrefix), // 添加二次查询指标的hover文案前缀
	})
	// 获取所有指标类型，存到一张表中
	f.ExeProduceSql(`select category_name from card_data group by category_name`, param.SinkTable("category_table"))
	// 根据指标类型，提取指标卡信息
	f.ExeProduceSql(`
		select  category_name,
				(
					select  name,
							value,
							display_value,
							cycle_value,
							cycle_display_value,
							trend_data,
							cycle_change_ratio,
							display_name,
							tips,
							unit,
							extra,
							need_second_query,
							display_order,
							is_use_pp
					from    card_data a
					where   a.category_name = category_table.category_name
				) as target_list
		from    category_table`, param.SinkTable("res_data"))
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return resp, nil
}

func (d *AnalysisService) GetProductAnalysisCoreTarget(ctx context.Context, req *analysis.GetProductAnalysisCoreTargetRequest) (resp *analysis.TargetCardEntity, err error) {
	// 获取业务线的维度信息
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	// 获取invoker的入参
	curr, compare, trend, trendSuffix, overall, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		UvFlag:     req.BaseReq.UvFlag,
	})
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	curr["target_name"] = req.GetTargetName()
	compare["target_name"] = req.GetTargetName()
	trend["target_name"] = req.GetTargetName()
	overall["target_name"] = req.GetTargetName()
	apiPath := ApiPathTargetCardUv

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("target_card")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(compare, apiPath, param.SinkTable("target_card_cycle")).SetParallel(true).SetMaxParallelNum(10)
	// 指标卡大盘数据
	f.ExeQueryInvokerRaw(overall, apiPath, param.SinkTable("whole_target")).SetParallel(true).SetMaxParallelNum(10)
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card_cycle"), param.SinkTable("target_card_cycle")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("whole_target"), param.SinkTable("whole_target")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.ExeQueryInvokerRaw(trend, apiPath, param.SinkTable("trend_data")).SetParallel(true).SetMaxParallelNum(10)
	if trendSuffix != nil {
		f.ExeQueryInvokerRaw(trendSuffix, apiPath, param.SinkTable("trend_data2")).SetParallel(true).SetMaxParallelNum(10)
		f.ExeProduceSql(`select * from trend_data union all select * from trend_data2`, param.SinkTable("trend_data"))
	}
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"date"}))
	// 趋势图加工sql
	trendSubSql := `
		(select  custom_date(date) as x,
				target_name as name,
				m.display_name as display_name,
				target_value as value,
				get_display_value(target_value, m.value_type, m.value_unit, m.target_precision) as display_value
		from    trend_data t
		inner join target_meta m
		on t.target_name = m.name
		where   t.target_name=target_card_new.name
		order by x asc)
	`
	// 计算环比,关联大盘数据
	f.ExeProduceSql(`
		select 
			a.target_name as name,
			a.target_value as value,
			b.target_value as cycle_value,
			c.target_value as whole_value,
			(a.target_value-b.target_value) / b.target_value as cycle_change_ratio,
			a.target_value-b.target_value as cycle_change_pp
		from target_card a 
		left join target_card_cycle b
		on a.target_name = b.target_name
		left join whole_target c
		on a.target_name = c.target_name
	`, param.SinkTable("target_card_new"))
	// 大盘数据子sql
	// case when a.is_compute_percent = true 即使是个bool值，也得用 = true判断，框架没有开这个口子
	marketSubSql := `
				(
				select  b.whole_value as market_value,
						get_display_value(b.whole_value, a.value_type, a.value_unit,a.target_precision) as display_value,
						a.is_compute_percent as percent_flag,
						case
							when a.is_compute_percent = true then b.value/b.whole_value
							else 0
						end as market_percent,
						a.is_larger_advantage as is_larger_advantage
				)`
	//marketSubSql := `null`
	// 关联指标元信息, 处理额外信息
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.name as name,
				b.value as value,
				get_display_value(b.value, a.value_type, a.value_unit, a.target_precision) as display_value,
				b.cycle_value as cycle_value,
				get_display_value(b.cycle_value, a.value_type, a.value_unit, a.target_precision) as cycle_display_value,
				%v as trend_data,
				case 
					when a.is_use_pp = true then b.cycle_change_pp 
					else b.cycle_change_ratio 
				end as cycle_change_ratio,
				a.display_name as display_name,
				a.tips as tips,
				a.value_unit as unit,
				a.attribute_type as category_name,
				%v as extra,
				a.display_order as display_order,
				a.need_second_query as need_second_query
		from    target_meta a
		inner join
				target_card_new b
		on      a.name=b.name
		order by a.display_order asc
	`, trendSubSql, marketSubSql), param.SinkTable("card_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDate),
	})
	targets := make([]*analysis.TargetCardEntity, 0)
	f.ExeView(param.SourceTable("card_data"), &targets)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	if len(targets) > 0 {
		resp = targets[0]
	} else {
		resp = &analysis.TargetCardEntity{}
	}
	return resp, nil
}

// 因为性能问题，需要二次查询的指标，需要在指标tips前追加文案
func addTipsPrefix(tips string, needSecondQuery bool) (string, error) {
	if !needSecondQuery {
		return tips, nil
	}
	secondQueryTips := fmt.Sprintf("由于计算该指标耗时较长，如需查看该指标，请点击\"开始计算\",约3分钟后产出结果(%s)", tips)
	return secondQueryTips, nil
}

func SortTargetCard(ctx context.Context, resp []*analysis.TargetCategoryList) {
	// 指定顺序
	categoryOrder := biz_info.GetTargetCategoryOrder(ctx)
	for _, category := range resp {
		if len(category.TargetList) > 0 {
			sort.Slice(category.TargetList, func(i, j int) bool {
				return category.TargetList[i].DisplayOrder < category.TargetList[j].DisplayOrder
			})
		}
	}
	sort.Slice(resp, func(i, j int) bool {
		// 获取每个元素的排序权重，使用order映射
		// 如果元素不在order中，给一个默认高值保证它排在最后
		rankI, okI := categoryOrder[resp[i].CategoryName]
		if !okI {
			rankI = len(categoryOrder) + 1
		}
		rankJ, okJ := categoryOrder[resp[j].CategoryName]
		if !okJ {
			rankJ = len(categoryOrder) + 1
		}
		return rankI < rankJ
	})
}

func SortTargetCardEntity(resp []*analysis.TargetCardEntity) {
	if len(resp) > 0 {
		for _, t := range resp {
			if len(t.TrendData) > 0 {
				sort.Slice(t.TrendData, func(i, j int) bool {
					if t.TrendData[i].XValue != "" {
						return t.TrendData[i].XValue < t.TrendData[j].XValue
					} else {
						return t.TrendData[i].X < t.TrendData[j].X
					}
				})
			}
			if len(t.CompareTrendData) > 0 {
				sort.Slice(t.CompareTrendData, func(i, j int) bool {
					if t.CompareTrendData[i].XValue != "" {
						return t.CompareTrendData[i].XValue < t.CompareTrendData[j].XValue
					} else {
						return t.CompareTrendData[i].X < t.CompareTrendData[j].X
					}
				})
			}
			if len(t.SubTargetList) > 0 {
				sort.Slice(t.SubTargetList, func(i, j int) bool {
					return t.SubTargetList[i].DisplayOrder < t.SubTargetList[j].DisplayOrder
				})
			}
		}
	}
	sort.Slice(resp, func(i, j int) bool {
		// 获取每个元素的排序权重，使用order映射
		// 如果元素不在order中，给一个默认高值保证它排在最后
		return resp[i].DisplayOrder < resp[j].DisplayOrder
	})
}

func (d *AnalysisService) GetProductAnalysisDefaultFunnelMate(ctx context.Context, bizType dimensions.BizType) (resp []*analysis.CoreOverviewFunnelData, err error) {
	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, bizType = %s", convert.ToJSONString(bizType))
		return nil, err
	}
	return bizInfo.DefaultFunnelMeta, nil
}

// GetProductAnalysisUVCore 获取UV核心指标
func (d *AnalysisService) GetProductAnalysisUVCore(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp []*analysis.TargetCategoryList, err error) {
	resp = make([]*analysis.TargetCategoryList, 0)
	if !JudgeContainUvTargetMeta(req.BaseReq) {
		logs.CtxWarn(ctx, "输入的请求体未包含UV指标，req:%v", litter.Sdump(req.BaseReq.TargetMetaList))
		return resp, nil
	}

	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}
	apiPath := bizMetaInfo.TargetCardUvApiID
	resp, err = GetTargetCard(ctx, req.BaseReq, req.NeedTrend, dimMap, apiPath, apiPath)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreOverview]获取指标卡数据失败，err=%v", err)
		return nil, err
	}
	SortTargetCard(ctx, resp)
	return resp, nil
}

func JudgeContainUvTargetMeta(req *dimensions.ProductAnalysisBaseStruct) bool {
	for _, targetName := range req.TargetMetaList {
		if _, ok := UVTargetMap[targetName]; ok {
			return true
		}
	}
	return false
}
