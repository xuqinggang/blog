package analysis_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

// GetProductAnalysisMultiDimProdCostData
/*
	注：0.9版本优化后，多维分析采用roll up的形式替代之前的懒加载，全量返回多维叉乘数据。
		货补这里首先与和实验平台的交互，依旧采用单维度懒加载的形式，用户下钻维度时，货补数据会额外请求，前端用dimValue进行拼接。
*/
func (d *AnalysisService) GetProductAnalysisMultiDimProdCostData(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.MultiDimExtraTargetItem, err error) {
	resp = &analysis.MultiDimExtraTargetItem{ExtraTargetList: make([]*analysis.MultiDimExtraTargetListRow, 0)}
	// 没有货补数据权限，就直接返回空数组
	if !utils.IsCostUser(ctx) {
		return resp, nil
	}

	prodCostTargetMap, err := GetProdCostTargetMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimProdCostData]获取实验平台指标元信息失败,err:"+err.Error())
		return nil, err
	}

	var costTargetKeyMap = make(map[string]bool)
	// 校验用户有没有选中货补指标，没有就直接返回
	for _, targetKey := range req.BaseReq.TargetMetaList {
		if _, ok := prodCostTargetMap[targetKey]; ok {
			costTargetKeyMap[targetKey] = true
		}
	}
	if len(costTargetKeyMap) == 0 {
		return resp, nil
	}

	if len(req.BaseReq.GroupAttrs) == 0 {
		return nil, errors.New("获取多维分析参数失败")
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
			}
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
	}
	if len(groupCol) == 0 {
		logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
		return resp, errors.New("多维分析未传入多维配置")
	}
	osReq := base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
	}
	// 是否支持货补数据
	isSupportCostTarget, err := JudgeContainNotSupportDim(ctx, osReq)
	if err != nil {
		return nil, err
	}
	if !isSupportCostTarget {
		return resp, nil
	}

	// 如果多维分析的维度，或者
	productCostTargetMap, targetKeyMap, err := GetMultipleAnalysisCostData(ctx, osReq, req.NeedTrend)
	if err != nil {
		logs.CtxError(ctx, "添加货补数据失败,err:%v", err.Error())
		return nil, err
	}
	if productCostTargetMap == nil || targetKeyMap == nil {
		return
	}
	// 这里用一个list存放targetKey，因为map多次遍历顺序不一致
	var targetKeyList = make([]string, 0)
	for key := range targetKeyMap {
		if _, ok := costTargetKeyMap[key]; ok {
			targetKeyList = append(targetKeyList, key)
		}
	}
	SortProdTargetList(ctx, targetKeyList)
	for enum, targetMap := range productCostTargetMap {
		var rowItem = &analysis.MultiDimExtraTargetListRow{
			EnumValue:  enum,
			TargetList: make([]*analysis.TargetCardEntity, 0),
		}
		for _, targetKey := range targetKeyList {
			if _, ok := targetMap[targetKey]; ok {
				rowItem.TargetList = append(rowItem.TargetList, targetMap[targetKey])
			}
		}
		resp.ExtraTargetList = append(resp.ExtraTargetList, rowItem)
	}
	return resp, nil
}
