package analysis_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"errors"
	"fmt"
	"github.com/jinzhu/copier"
	"math"
	"strings"
)

// GetBizInfoMultiRollupListV2 多维分析业务结果获取多维列表
func GetBizInfoMultiRollupListV2(ctx context.Context, isMarket bool, req *dimensions.ProductAnalysisBaseStruct, dimColMap map[string]*dimensions.SelectedDimensionInfo, daoDimColMap map[string]*dao.DimensionInfo, dimMap map[int64]*dao.DimensionInfo) (totalMap map[string]*analysis.TargetCardEntity, levelDimTargetMap map[int]map[string]map[string]*analysis.ConclusionMultiContributionInfo, err error) {
	useReq := &dimensions.ProductAnalysisBaseStruct{}
	copier.CopyWithOption(useReq, *req, copier.Option{DeepCopy: true})
	if isMarket {
		useReq.Dimensions = nil
	}

	// 获取分析的维度信息
	groupCols := make([]string, 0)
	filterMultiExpr := sql_parse.NewCQL()
	for i, attr := range req.GroupAttrs {
		if attr.DimInfo == nil {
			continue
		}
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return nil, nil, errors.New("未查询到维度信息")
		}

		// 查询该维度的枚举值
		if i != 0 || !isMarket {
			groupCols = append(groupCols, dimInfo.DimColumn)

			filterMultiValues := make([]string, 0)
			if attr.DimInfo != nil && len(attr.DimInfo.SelectedValues) > 0 {
				for _, v := range attr.DimInfo.SelectedValues {
					filterMultiValues = append(filterMultiValues, convert.ToString(v.Code))
				}
			}

			if len(filterMultiValues) > 0 {
				filterMultiValues = append(filterMultiValues, consts.Empty)
				filterMultiExpr.AddWhere(dimInfo.DimColumn, sql_parse.IN, filterMultiValues)
			}
		}

	}

	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     useReq,
		DimMap:         dimMap,
		DimColMap:      daoDimColMap,
		MultiDimension: groupCols,
	})
	if err != nil {
		return
	}
	if len(groupCols) > 0 {
		curr["to_str_dimension"] = strings.Join(base_struct_condition.GenerateCastString(groupCols, "str_"), ",")
		curr["str_dimension"] = strings.Join(base_struct_condition.AppendPrefix(groupCols, "str_"), ",")
		curr["str_to_dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(groupCols, "str_"), ",")
	}

	curr["dim_key"] = base_struct_condition.GenerateDimKey(groupCols, consts.Empty)
	if isMarket && filterMultiExpr.WhereClause != nil {
		curr["filter_multi_param"] = sql_parse.NewCQL().ParseExpression(filterMultiExpr.WhereClause)
	}

	curr["group_type"] = "rollup"
	if isMarket && len(groupCols) > 0 {
		curr["group_type"] = "cube"
	}

	dimTargets, err := GetDimKeyTargetList(ctx, curr, consts.Empty, ApiPathGetMultiDimTargetList, req, []string{consts.AttrNamePayOrdCnt, consts.AttrNamePayGMV, consts.AttrNameOPM})
	if err != nil {
		return nil, nil, err
	}

	totalMap = make(map[string]*analysis.TargetCardEntity)                                            // 当前整体数据
	levelDimTargetMap = make(map[int]map[string]map[string]*analysis.ConclusionMultiContributionInfo) // 每一层级的数据 level : dim_key : target_key : target_entity
	for _, dt := range dimTargets {
		// 属于整体的数据
		if len(strings.ReplaceAll(dt.DimKey, "###", "")) == 0 {
			for _, t := range dt.TargetEntity {
				totalMap[t.Name] = t
			}
			continue
		}

		dimKeyArr := strings.Split(dt.DimKey, "###")
		dimKeyLen := len(dimKeyArr)
		level := dimKeyLen
		// 收集C维度的数据
		var lastDimCode string
		for i := dimKeyLen - 1; i >= 0; i-- {
			if len(dimKeyArr[i]) > 0 {
				lastDimCode = dimKeyArr[i]
				break
			}
			level = i
		}
		dimTargetValMap, exist := levelDimTargetMap[level]
		if !exist {
			dimTargetValMap = make(map[string]map[string]*analysis.ConclusionMultiContributionInfo)
		}
		targetValMap, existD := dimTargetValMap[dt.DimKey]
		if !existD {
			targetValMap = make(map[string]*analysis.ConclusionMultiContributionInfo)
		}

		if level > len(groupCols) || level == 0 {
			continue
		}

		dimCol := groupCols[level-1]
		reqDim, existReqDim := dimColMap[dimCol]
		if !existReqDim {
			continue
		}
		enumV := GetEnumByDim(lastDimCode, reqDim)
		for _, t := range dt.TargetEntity {
			targetValMap[t.Name] = &analysis.ConclusionMultiContributionInfo{
				DimInfo: &dimensions.SelectedDimensionInfo{
					Id:               reqDim.Id,
					Name:             reqDim.Name,
					AttrType:         reqDim.AttrType,
					SelectedOperator: reqDim.SelectedOperator,
					SelectedValues:   []*dimensions.EnumElement{enumV},
				},
				TargetEntity: t,
			}
		}
		dimTargetValMap[dt.DimKey] = targetValMap
		levelDimTargetMap[level] = dimTargetValMap
	}

	for level, dimTargetMap := range levelDimTargetMap {
		for dimKey, targetMap := range dimTargetMap {
			for tName, tValue := range targetMap {
				if !slices.ContainsString(BizRetTargetNameList, tName) {
					continue
				}
				var totalV *analysis.TargetCardEntity
				if level == 1 {
					totalV = totalMap[tName]
				} else {
					parentLevelMap, existLevel := levelDimTargetMap[level-1]
					if existLevel {
						parentDimkeyMap, existDimkey := parentLevelMap[base_struct_condition.GetDimKeyParent(dimKey)]
						if existDimkey {
							parentTarget, existTarget := parentDimkeyMap[tName]
							if existTarget && parentTarget != nil {
								totalV = parentTarget.TargetEntity
							}
						}
					}
				}

				if tValue != nil && totalV != nil && totalV.Value > 0 {
					tValue.Contribution = tValue.TargetEntity.Value / totalV.Value
					fmt.Println(tValue)
				}
			}
		}
	}

	return
}

func GetDimKeyTargetList(ctx context.Context, params map[string]interface{}, sql string, apiPath string, req *dimensions.ProductAnalysisBaseStruct, targetNames []string) (dimTargets []*dimKeyTargetEntity, err error) {
	keyColTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: params, Sql: sql, ApiPath: apiPath, BizType: req.BizType, KeyCols: []string{"dim_key"}, TargetMetaMap: BizRetTargetMetaMap,
	})
	if err != nil {
		return nil, err
	}

	dimTargets = make([]*dimKeyTargetEntity, 0)
	for _, info := range keyColTargetList {
		if len(info.KeyColValues) > 0 && len(info.TargetEntity) > 0 {
			t := make([]*analysis.TargetCardEntity, 0)
			for _, target := range info.TargetEntity {
				if slices.ContainsString(targetNames, target.Name) {
					t = append(t, target)
				}
			}
			dimTargets = append(dimTargets, &dimKeyTargetEntity{
				DimKey:       convert.ToString(info.KeyColValues[0]),
				TargetEntity: t,
			})
		}
	}
	return dimTargets, nil
}

func (d *AnalysisService) GetMultiDimAbnormalInfoV2(ctx context.Context,
	req *dimensions.ProductAnalysisBaseStruct,
	targetInfo *analysis.TargetCardEntity,
	dimColMap map[string]*dimensions.SelectedDimensionInfo,
	daoDimColMap map[string]*dao.DimensionInfo,
	dimMap map[int64]*dao.DimensionInfo, multiAbnormalInfo *analysis.MultiDimConclusionAbnormalInfo) (err error) {
	if multiAbnormalInfo == nil || multiAbnormalInfo.DimInfo == nil || targetInfo == nil {
		logs.CtxWarn(ctx, "下钻维度信息为空，multiAbnormalInfo=%s", convert.ToJSONString(multiAbnormalInfo))
		return
	}

	useReq := &dimensions.ProductAnalysisBaseStruct{}
	copier.CopyWithOption(useReq, *req, copier.Option{DeepCopy: true})

	dimInfo, exist := dimMap[convert.ToInt64(multiAbnormalInfo.DimInfo.Id)]
	if !exist {
		logs.CtxError(ctx, "未发现维度信息, selectDimInfo=%s", convert.ToJSONString(multiAbnormalInfo.DimInfo))
		return errors.New("未发现维度信息")
	}

	dimKey := fmt.Sprintf("%s as dim_key", dimInfo.DimColumn)

	var abnormalSubSelectList []string
	var abnormalBaseSelectList []string
	switch targetInfo.Name {
	case consts.AttrNameShowPV:
		abnormalSubSelectList = []string{
			fmt.Sprintf("sum(%s) as show_pv", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey, "show_pv",
		}
	case consts.AttrNamePayOrdCnt:
		abnormalSubSelectList = []string{
			fmt.Sprintf("sum(%s) as pay_ord_cnt", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey,
			"pay_ord_cnt",
		}
	case consts.AttrNameShowProdCnt:
		abnormalSubSelectList = []string{
			fmt.Sprintf("count(distinct if(%s > 0, prod_id, null)) as show_prod_cnt", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey, "show_prod_cnt",
		}
	case consts.AttrNameProdPayShowRate:
		abnormalSubSelectList = []string{
			fmt.Sprintf("count(distinct if(%s > 0, prod_id, null)) as show_prod_cnt", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
			fmt.Sprintf("count(distinct if(%s > 0, prod_id, null)) as pay_prod_cnt", consts.GetTableCol(consts.AttrNamePayGMV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey,
			"round(pay_prod_cnt / show_prod_cnt, 5) as prod_pay_show_rate",
		}
	case consts.AttrNamePayProdAvgOrdCnt:
		abnormalSubSelectList = []string{
			fmt.Sprintf("sum(%s) as pay_ord_cnt", consts.GetTableCol(consts.AttrNamePayOrdCnt, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
			fmt.Sprintf("count(distinct if(%s > 0, prod_id, null)) as show_prod_cnt", consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), req.BizType)),
		}
		abnormalBaseSelectList = []string{
			dimKey,
			"round(pay_ord_cnt / show_prod_cnt, 5) as prod_avg_ord_cnt",
		}
	default:
		return
	}

	currCql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
		BaseStruct:       req,
		MultiDimColumns:  []string{dimInfo.DimColumn},
		CKSettingType:    base_struct_condition.CKSettingSub,
		NeedProdID:       false,
		SubSelectList:    abnormalSubSelectList,
		BaseSelectList:   abnormalBaseSelectList,
		DimMap:           dimMap,
		DimColMap:        daoDimColMap,
		NotSyncBaseMulti: true,
	})
	if err != nil {
		return
	}

	compareCql, _, err := base_struct_condition.GetBaseStructConditionCql(ctx, base_struct_condition.BaseStructConditionReq{
		BaseStruct:       req,
		MultiDimColumns:  []string{dimInfo.DimColumn},
		IsCompare:        true,
		CKSettingType:    base_struct_condition.CKSettingSub,
		NeedProdID:       false,
		SubSelectList:    abnormalSubSelectList,
		BaseSelectList:   abnormalBaseSelectList,
		DimMap:           dimMap,
		DimColMap:        daoDimColMap,
		NotSyncBaseMulti: true,
	})
	if err != nil {
		return
	}

	dimTargets, err := GetDimKeyTargetList(ctx, nil, currCql.Compile(), biz_info.GetCtxBizInfoApiID(ctx), req, []string{targetInfo.Name})
	if err != nil {
		return err
	}

	compareDimTargets, err := GetDimKeyTargetList(ctx, nil, compareCql.Compile(), biz_info.GetCtxBizInfoApiID(ctx), req, []string{targetInfo.Name})
	if err != nil {
		return err
	}

	compareMap := make(map[string]map[string]*analysis.TargetCardEntity)
	for _, dimT := range compareDimTargets {
		if len(dimT.TargetEntity) > 0 {
			compareTargetMap := make(map[string]*analysis.TargetCardEntity)
			for _, t := range dimT.TargetEntity {
				compareTargetMap[t.Name] = t
			}
			compareMap[dimT.DimKey] = compareTargetMap
		}
	}

	for _, dimT := range dimTargets {
		if compareTargetMap, existT := compareMap[dimT.DimKey]; existT && len(dimT.TargetEntity) > 0 {
			for _, t := range dimT.TargetEntity {
				if compareInfo, existCompare := compareTargetMap[t.Name]; existCompare && compareInfo != nil {
					t.CycleValue = compareInfo.Value
					t.CycleChangeRatio = t.Value - compareInfo.Value
					t.CycleDisplayValue = compareInfo.DisplayValue
					if !t.IsUsePp {
						if compareInfo.Value == 0 {
							t.CycleChangeRatio = consts.MagicNumber
						} else {
							t.CycleChangeRatio = t.CycleChangeRatio / compareInfo.Value
						}
					}
				}
			}
		}
	}

	if len(dimTargets) > 0 {
		for _, dt := range dimTargets {
			enumV := GetEnumByDim(dt.DimKey, dimColMap[dimInfo.DimColumn])
			if len(enumV.Code) == 0 {
				continue
			}
			abDimInfo := &dimensions.SelectedDimensionInfo{
				Id:               multiAbnormalInfo.DimInfo.Id,
				Name:             multiAbnormalInfo.DimInfo.Name,
				AttrType:         multiAbnormalInfo.DimInfo.AttrType,
				SelectedOperator: multiAbnormalInfo.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{enumV},
			}
			for _, t := range dt.TargetEntity { // 每个维度组合下，遍历所有指标信息
				if t.Name == targetInfo.Name {
					if multiAbnormalInfo.TargetEntity == nil {
						multiAbnormalInfo.DimInfo = abDimInfo
						multiAbnormalInfo.TargetEntity = t
					} else {
						tVal := (t.Value - t.CycleValue) * targetInfo.CycleChangeRatio
						currVal := (multiAbnormalInfo.TargetEntity.Value - multiAbnormalInfo.TargetEntity.CycleValue) * targetInfo.CycleChangeRatio
						if tVal > currVal {
							multiAbnormalInfo.DimInfo = abDimInfo
							multiAbnormalInfo.TargetEntity = t
						}
					}
				}
			}
		}
	}

	threshold, err := biz_info.GetAbnormalThreshold(ctx)
	if err != nil {
		return
	}
	if multiAbnormalInfo.TargetEntity != nil && len(multiAbnormalInfo.DimInfo.SelectedValues) > 0 &&
		math.Abs(multiAbnormalInfo.TargetEntity.CycleChangeRatio)*100 >= threshold {
		useReq.Dimensions = append(useReq.Dimensions, &dimensions.SelectedDimensionInfo{
			Id:               multiAbnormalInfo.DimInfo.Id,
			Name:             multiAbnormalInfo.DimInfo.Name,
			AttrType:         multiAbnormalInfo.DimInfo.AttrType,
			SelectedOperator: multiAbnormalInfo.DimInfo.SelectedOperator,
			SelectedValues:   []*dimensions.EnumElement{multiAbnormalInfo.DimInfo.SelectedValues[0]},
		})
		err = d.GetMultiDimAbnormalInfoV2(ctx, useReq, targetInfo, dimColMap, daoDimColMap, dimMap, multiAbnormalInfo.SubDimInfo)
		if err != nil {
			return
		}
	} else {
		multiAbnormalInfo.SubDimInfo = nil
	}

	return
}
