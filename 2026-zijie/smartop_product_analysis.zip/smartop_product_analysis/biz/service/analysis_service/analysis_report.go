package analysis_service

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"

	"code.byted.org/aweme-go/dsync"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_smartop_data_access/kitex_gen/common"
	"code.byted.org/overpass/ecom_smartop_data_access/kitex_gen/ecom/smartop/data_access"
	"code.byted.org/overpass/ecom_smartop_data_access/rpc/ecom_smartop_data_access"
	"code.byted.org/temai/go_lib/convert"
)

// GetProductReportTable 获取商品分析日周报表格数据
func (svc *AnalysisService) GetProductReportTable(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *analysis.GetProductReportTableData, err error) {
	// 参数校验
	if err = svc.checkParam(req); err != nil {
		return
	}

	// 根据入参条件，改写时间参数
	svc.rewriteRequestTime(req)

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	// 构建参数
	queryParam, dimCodeValueNameMap, err := svc.buildParam(ctx, req)
	if err != nil {
		return
	}

	// 构建where条件
	whereStr := convert.ToString(queryParam["filter_param"])
	// 指标元信息
	targetMetaMap, err := base_struct_condition.GetFilterTargetMetaInfoMap(ctx, int64(req.BaseReq.BizType), false, true, req.BaseReq.TargetMetaList)
	if err != nil {
		return nil, err
	}
	// 取数追加的参数
	tableAddiCfg := map[string]string{}
	if flag, ok := queryParam["not_distributed_perfect_shard"]; ok && convert.ToString(flag) == consts.IsTrueString {
		tableAddiCfg[convert.ToString(queryParam["table_name"])] = " SETTINGS distributed_product_mode = 'local'"
	} else {
		tableAddiCfg[convert.ToString(queryParam["table_name"])] = " SETTINGS distributed_product_mode = 'local',distributed_perfect_shard = 1 "
	}

	// *******  取数
	templateParam := map[string]string{}
	for k, v := range queryParam {
		templateParam[k] = convert.ToJSONString(v)
	}

	// 当前期 by 周期
	queryId := svc.getQueryIdByBizType(bizInfo)
	var currentDateRow, currentRow, compareDateRow []*data_access.DrillTableRow
	pool := dsync.NewGoPool(3)
	if err = pool.Go(ctx, func() {
		currentDateRow, _, err = svc.getDataFromDataAccess(ctx, queryId, req, true, false, whereStr, tableAddiCfg, templateParam)
	}); err != nil {
		return
	}

	// 当前周期汇总
	if err = pool.Go(ctx, func() {
		currentRow, _, err = svc.getDataFromDataAccess(ctx, queryId, req, false, false, whereStr, tableAddiCfg, templateParam)
	}); err != nil {
		return
	}

	// 对比周期
	if req.CompareType == 2 {
		// 环比
		if err = pool.Go(ctx, func() {
			compareDateRow, _, err = svc.getDataFromDataAccess(ctx, queryId, req, true, true, whereStr, tableAddiCfg, templateParam)
		}); err != nil {
			return
		}
	}
	if err != nil {
		return
	}
	pool.Wait()

	// 组装数据
	targetMap := map[string]map[string]*analysis.TargetCardEntity{}
	dimensionCodeList, _ := svc.buildDimensionCodeList(ctx, req)
	rowDimList := []string{}
	var dimRowKey string
	for _, row := range currentRow {
		if dimRowKey, err = svc.splitDateRow(ctx, false, row, dimensionCodeList, targetMetaMap, targetMap); err != nil {
			return
		} else {
			rowDimList = append(rowDimList, dimRowKey)
		}
	}
	// 拆分 带日期的数据, 行code的结构: dimValue1$@$dimValue2$@$周期最后一天时间戳
	dimensionCodeWithDateList := append(dimensionCodeList, "date")
	for _, row := range currentDateRow {
		if _, err = svc.splitDateRow(ctx, false, row, dimensionCodeWithDateList, targetMetaMap, targetMap); err != nil {
			return
		}
	}

	// 拆分 带日期的数据, 行code的结构: dimValue1$@$dimValue2$@$周期最后一天时间戳
	for _, row := range compareDateRow {
		if _, err = svc.splitDateRow(ctx, true, row, dimensionCodeWithDateList, targetMetaMap, targetMap); err != nil {
			return
		}
	}
	// 结果返回
	targetDimRows := make(map[string][]*analysis.TargetCardEntity)
	dateType, _ := svc.buildDateTypeAndOperator(req, false)
	for dimKey, codeMap := range targetMap {
		targetDimRows[dimKey] = make([]*analysis.TargetCardEntity, 0)
		for _, code := range req.BaseReq.TargetMetaList {
			targetDimRows[dimKey] = append(targetDimRows[dimKey], svc.rebuildTarget(codeMap[code], dateType, targetMetaMap))
		}
	}
	resp = &analysis.GetProductReportTableData{}
	if len(dimensionCodeList) == 0 {
		row := &analysis.MultiDimFullListRow{
			TargetList: targetDimRows[""],
		}
		resp.FullList = append(resp.FullList, row)
	} else {
		resp.FullList = svc.buildDimensionRows(dimensionCodeList, rowDimList, dimCodeValueNameMap, targetDimRows)
	}

	return
}

// GetProductReportTableSubscribe 获取商品分析日周报表格数据
func (svc *AnalysisService) GetProductReportTableSubscribe(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *string, err error) {
	// 参数校验
	if err = svc.checkParam(req); err != nil {
		return
	}

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	// 构建参数 dimCodeValueNameMap
	queryParam, dimCodeValueNameMap, err := svc.buildParam(ctx, req)
	if err != nil {
		return
	}

	logs.CtxInfo(ctx, "dimCodeValueNameMap = %s", convert.ToJSONString(dimCodeValueNameMap))
	// 构建where条件
	whereStr := convert.ToString(queryParam["filter_param"])

	// 取数追加的参数
	tableAddiCfg := map[string]string{}
	if flag, ok := queryParam["not_distributed_perfect_shard"]; ok && convert.ToString(flag) == consts.IsTrueString {
		tableAddiCfg[convert.ToString(queryParam["table_name"])] = " SETTINGS distributed_product_mode = 'local'"
	} else {
		tableAddiCfg[convert.ToString(queryParam["table_name"])] = " SETTINGS distributed_product_mode = 'local',distributed_perfect_shard = 1 "
	}

	// *******  取数
	templateParam := map[string]string{}
	for k, v := range queryParam {
		templateParam[k] = convert.ToJSONString(v)
	}

	// 当前期 by 周期
	queryId := svc.getQueryIdByBizType(bizInfo)

	res, err := ecom_smartop_data_access.RawCall.AvailableDate(ctx, &data_access.AvailableDateReq{
		QueryIds: []string{queryId},
	})

	if err != nil {
		logs.CtxError(ctx, "获取最近产出时间失败, error is %v", err.Error())
		return nil, err
	}

	// 改写时间根据最近产出时间
	var startTs, endTs, cmpStartTs, cmpEndTs int64
	var dateType *common.DateType
	if *req.LarkSubscribeType == 1 {
		startTs = res.Data.EndTime
		endTs = res.Data.EndTime
		req.CompareType = 0
		dateType = common.DateTypePtr(common.DateType_DAY)
	} else if *req.LarkSubscribeType == 2 {
		startTs = res.Data.EndTime - 6*24*60*60
		endTs = res.Data.EndTime
		cmpStartTs = res.Data.EndTime - 13*24*60*60
		cmpEndTs = res.Data.EndTime - 7*24*60*60
		req.CompareType = 2
		dateType = common.DateTypePtr(common.DateType_SEVEN_DAY)
	} else {
		return nil, errors.New("LarkSubscribeType参数错误")
	}

	var _, operator = svc.buildDateTypeAndOperator(req, false)
	dimList, err := svc.buildDimensionList(ctx, req)
	if err != nil {
		return nil, err
	}

	dataAccessReq := &data_access.GetTableDataRequest{
		QueryId: queryId,
		CurrentTime: &data_access.TimeRange{StartTime: startTs,
			EndTime: endTs, DateType: dateType},
		DimensionList: dimList,
		IndicatorList: svc.buildIndicatorList(req, operator),
		Filters: []*data_access.MultiFilter{
			{FieldName: "date_type", ValueType: "string", Op: "=", Value: "1d"},
		},
		ExtraParam: &data_access.ExtraParam{OneIndWithOp: true, LogicTableAddiConfig: tableAddiCfg, TemplateParam: templateParam},
	}

	if whereStr != "" {
		dataAccessReq.Filters = append(dataAccessReq.Filters, &data_access.MultiFilter{
			FieldName: whereStr,
			ValueType: "=",
			Op:        "custom",
		})
	}
	if req.CompareType == 2 {
		dataAccessReq.CompareTime = &data_access.TimeRange{StartTime: cmpStartTs, EndTime: cmpEndTs, DateType: common.DateTypePtr(common.DateType_SEVEN_DAY)}
		dataAccessReq.ChartTime = &data_access.TimeRange{StartTime: endTs - 27*24*60*60, EndTime: endTs, DateType: common.DateTypePtr(common.DateType_SEVEN_DAY)}
	}

	requestStr, _ := json.Marshal(dataAccessReq)
	logs.CtxInfo(ctx, "GetProductReportTableSubscribe req is %v", string(requestStr))

	dataAccessResp, err := ecom_smartop_data_access.RawCall.GetTableData(ctx, dataAccessReq)
	if err != nil {
		logs.CtxError(ctx, "[GetProductReportTable]查询通用取数失败: req=【%v】, err=【%v】", convert.ToJSONString(req), err)
		return
	} else if dataAccessResp.BaseResp != nil && dataAccessResp.BaseResp.StatusCode != 0 {
		logs.CtxError(ctx, "[GetProductReportTable]查询通用取数失败: req=【%v】, resp=【%v】", convert.ToJSONString(req), resp)
		err = errors.Errorf("通用取数查询失败: [%v]%v", dataAccessResp.BaseResp.StatusCode, dataAccessResp.BaseResp.StatusMessage)
		return
	} else if dataAccessResp.Data == nil {
		logs.CtxError(ctx, "[GetProductReportTable]查询通用取数失败: req=【%v】, resp.Data=nil", convert.ToJSONString(req))
		err = errors.Errorf("通用取数查询失败: 数据结果为空")
		return
	}

	//对于是周数据由于日报/周报要的是日均，需要/7

	//假如是带维度，需要将维度信息进行处理
	//把指标转成行,适配展示组件
	//dataAccessResp.Data.IndBaseMap
	extra := make(map[string]interface{})
	groups := make([]map[string]interface{}, 0)
	header := make([]map[string]interface{}, 0)
	if len(dimList) == 0 {
		newRows := make([]*data_access.DrillTableRow, 0)
		for _, row := range dataAccessResp.Data.Rows {
			values := row.Values
			for _, ind := range dataAccessResp.Data.IndBaseMap {
				indValue := &data_access.DrillTableRow{
					Name: ind.Name,
					Code: ind.Code,
				}
				//判断是否带维度
				if row.Code != "" {
					indValue.Code = row.Code + "_" + indValue.Code
					//展示需要分组
					indValue.Name = dimCodeValueNameMap[row.Code][row.Code]
				}
				newValues := make(map[string]*common.BasicOpValueParam)
				for k, v := range values {
					indexList := strings.Split(k, ".")
					if len(indexList) != 2 {
						continue
					}
					if indexList[0] == ind.Code {
						newValues[indexList[1]] = v
					}
				}
				indValue.Values = newValues
				newRows = append(newRows, indValue)
			}
		}
		dataAccessResp.Data.Rows = newRows

		//构建header
		header = append(header, map[string]interface{}{
			"code": "name",
			"name": "指标",
		})

		children := make([]map[string]string, 0)
		if *req.LarkSubscribeType == 1 {
			children = []map[string]string{
				{
					"code": "value",
					"name": "当日值",
				},
				{
					"code": "chainValue",
					"name": "日环比",
				},
				{
					"code": "sameValueWR",
					"name": "周同比",
				},
				{
					"code": "chart",
					"name": "30日趋势",
				},
			}
		} else {
			children = []map[string]string{
				{
					"code": "valueD",
					"name": "周日均",
				},
				{
					"code": "cmpDaily",
					"name": "上周日均",
				},
				{
					"code": "chartWeekAvg",
					"name": "4周趋势图",
				},
			}
		}
		for _, v := range children {
			header = append(header, map[string]interface{}{
				"code": v["code"],
				"name": v["name"],
			})
		}
	} else {
		newRows := make([]*data_access.DrillTableRow, 0)
		for _, row := range dataAccessResp.Data.Rows {
			group := make(map[string]interface{})
			group["name"] = dimCodeValueNameMap[*row.DimCode][row.Code]
			rowCodes := make([]string, 0)
			values := row.Values
			for _, ind := range dataAccessResp.Data.IndBaseMap {
				rowCodes = append(rowCodes, row.Code+"_"+ind.Code)
				indValue := &data_access.DrillTableRow{
					Name: ind.Name,
					Code: ind.Code,
				}
				//判断是否带维度
				if row.DimCode != nil && *row.DimCode != "" {
					indValue.Code = row.Code + "_" + indValue.Code
				}
				newValues := make(map[string]*common.BasicOpValueParam)
				for k, v := range values {
					indexList := strings.Split(k, ".")
					if len(indexList) != 2 {
						continue
					}
					if indexList[0] == ind.Code {
						newValues[indexList[1]] = v
					}
				}
				indValue.Values = newValues
				newRows = append(newRows, indValue)
			}
			group["rowCodes"] = rowCodes
			groups = append(groups, group)
		}
		dataAccessResp.Data.Rows = newRows

		//构建header
		header = append(header, map[string]interface{}{
			"code": "name",
			"name": "指标",
		})

		children := make([]map[string]string, 0)
		if *req.LarkSubscribeType == 1 {
			children = []map[string]string{
				{
					"code": "value",
					"name": "当日值",
				},
				{
					"code": "chainValue",
					"name": "日环比",
				},
				{
					"code": "sameValueWR",
					"name": "周同比",
				},
				{
					"code": "chart",
					"name": "30日趋势",
				},
			}
		} else {
			children = []map[string]string{
				{
					"code": "valueD",
					"name": "周日均",
				},
				{
					"code": "cmpDaily",
					"name": "上周日均",
				},
				{
					"code": "chartWeekAvg",
					"name": "4周趋势图",
				},
			}
		}
		header = append(header, map[string]interface{}{
			"code":     "",
			"name":     "",
			"children": children,
		})

	}
	extra["headers"] = header
	if len(groups) > 0 {
		extra["groups"] = groups
	}
	extra["data_time"] = time.Unix(res.Data.EndTime, 0).Format(consts.Fmt_Date)
	extraStr := convert.ToJSONString(extra)
	dataAccessResp.Data.Extra = &extraStr

	respBytes, castErr := json.Marshal(dataAccessResp.Data)
	if castErr != nil {
		logs.CtxError(ctx, "[GetProductReportTable]查询通用取数失败: req=【%v】, resp=【%v】", convert.ToJSONString(req), resp)
		err = errors.Errorf("通用取数查询失败: 数据结果为空")
		return
	}
	logs.CtxInfo(ctx, "GetProductReportTableSubscribe resp is %v", string(respBytes))

	respStr := string(respBytes)
	return &respStr, nil
}

func (svc *AnalysisService) GetProductReportTableDownload(ctx context.Context, req *analysis.GetProductReportTableRequest) (hasSend bool, err error) {
	// 当前用户信息
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}

	// 维度列
	var dimCodeNameList []string
	if len(req.BaseReq.GroupAttrs) > 0 {
		dimMap, _ := svc.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
		for _, dim := range req.BaseReq.GroupAttrs {
			if _, ok := dimMap[convert.ToInt64(dim.DimInfo.GetId())]; ok {
				dimCodeNameList = append(dimCodeNameList, dim.DimInfo.Name)
			}
		}
	}

	// 数据表格
	dataResp, err := svc.GetProductReportTable(ctx, req)
	if err != nil {
		return
	}

	docName := fmt.Sprintf("%s-%s", bizInfo.EffectModule, bizInfo.BizName)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	table, dateList := svc.GetTableAndDateList(0, map[string]interface{}{}, dimCodeNameList, dataResp.FullList)
	if env.IsPPE() {
		logs.CtxInfo(ctx, "GetProductReportTableDownload: dateList=%v, table.len=%v", dateList, len(table))
	}

	// preheader
	var dateType, aggr = "日", ""
	switch req.AggrType {
	case dimensions.AnalysisAggregationType_WeekDaily:
		dateType = "周"
		aggr = "周日均"
	case dimensions.AnalysisAggregationType_WeekSum:
		dateType = "周"
		aggr = "周累计"
	case dimensions.AnalysisAggregationType_MonthDaily:
		dateType = "月"
		aggr = "月日均"
	case dimensions.AnalysisAggregationType_MonthSum:
		dateType = "月"
		aggr = "月累计"
	default:
		logs.CtxWarn(ctx, "req.AggrType 未匹配 = %v", req.AggrType)
	}

	preHeader := []string{
		"分析周期", fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate()),
		"对比周期", fmt.Sprintf("%v ~ %v", req.BaseReq.GetCompareStartDate(), req.BaseReq.GetCompareEndDate()),
		"分析粒度", dateType,
	}
	if len(aggr) > 0 {
		preHeader = append(preHeader, "分析口径")
		preHeader = append(preHeader, aggr)
	}

	f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genOneTable, param.SinkTable("trend_report"))
	f.ExeCustom([]param.Source{param.SourceTable("trend_report"),
		param.SourceConst(email), param.SourceConst(docName),
		param.SourceConst(preHeader),
		param.SourceConst(dimCodeNameList),
		param.SourceConst(dateList),
	}, svc.genSheet, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func (svc *AnalysisService) checkParam(req *analysis.GetProductReportTableRequest) (err error) {
	if req == nil || req.BaseReq == nil || (req.CompareType == 2 && req.BaseReq.CompareStartDate == "" || req.BaseReq.CompareEndDate == "") {
		return errors.New("参数异常, 缺少必要的参数")
	}

	return
}

func (svc *AnalysisService) buildParam(ctx context.Context,
	req *analysis.GetProductReportTableRequest) (param map[string]interface{}, dimCodeValNameMap map[string]map[string]string, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return
	}

	dimMap, err := svc.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取map失败，err=%v+", err)
		return
	}

	dimColMap, err := svc.DimensionListDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取col map失败，err=%v+", err)
		return
	}

	// 获取分析的维度信息
	groupCols := make([]string, 0)
	dimCodeValNameMap = make(map[string]map[string]string)
	for _, attr := range req.BaseReq.GroupAttrs {
		req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)

		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			err = errors.New("未查询到维度信息")
			return
		}
		groupCols = append(groupCols, dimInfo.DimColumn)
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			enumCodeMap := make(map[string]string)
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
			dimCodeValNameMap[dimInfo.DimColumn] = enumCodeMap
		}
	}

	param, _, _, _, _, err = base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: append(groupCols, base_struct_condition.GenerateDimKey(groupCols, consts.Empty)),
	})

	return
}

func (svc *AnalysisService) buildWhereStr(ctx context.Context,
	req *analysis.GetProductReportTableRequest) (where string, dimCodeValNameMap map[string]map[string]string, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return
	}

	dimMap, err := svc.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取map失败，err=%v+", err)
		return
	}

	dimColMap, err := svc.DimensionListDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取col map失败，err=%v+", err)
		return
	}

	// 获取分析的维度信息
	groupCols := make([]string, 0)
	dimCodeValNameMap = make(map[string]map[string]string)
	for _, attr := range req.BaseReq.GroupAttrs {
		req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)

		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			err = errors.New("未查询到维度信息")
			return
		}
		groupCols = append(groupCols, dimInfo.DimColumn)
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			enumCodeMap := make(map[string]string)
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
			dimCodeValNameMap[dimInfo.DimColumn] = enumCodeMap
		}
	}

	curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: append(groupCols, base_struct_condition.GenerateDimKey(groupCols, consts.Empty)),
	})

	where = convert.ToString(curr["filter_param"])

	return
}

func (svc *AnalysisService) rewriteRequestTime(req *analysis.GetProductReportTableRequest) {
	startTs := time_utils.DateStringToTimestamp(req.BaseReq.StartDate)
	endTs := time_utils.DateStringToTimestamp(req.BaseReq.EndDate)
	dateType, _ := svc.buildDateTypeAndOperator(req, false)
	days := (endTs-startTs)/86400 + 1
	if dateType != nil && *dateType == common.DateType_SEVEN_DAY {
		if days%7 != 0 && days > 7 { // 丢弃尾部的不满周
			endTs = startTs + (days-days%7-1)*86400
		} else if days%7 != 0 && days < 7 {
			startTs = endTs - 6*86400
		}
		req.BaseReq.StartDate = time.Unix(startTs, 0).Format(consts.Fmt_Date)
		req.BaseReq.EndDate = time.Unix(endTs, 0).Format(consts.Fmt_Date)
	}

	if req.BaseReq.CompareStartDate != "" && req.BaseReq.CompareEndDate != "" {
		startTs = time_utils.DateStringToTimestamp(req.BaseReq.CompareStartDate)
		endTs = time_utils.DateStringToTimestamp(req.BaseReq.CompareEndDate)
		days = (endTs-startTs)/86400 + 1
		if dateType != nil && *dateType == common.DateType_SEVEN_DAY {
			if days%7 != 0 && days > 7 { // 丢弃尾部的不满周
				endTs = startTs + (days-days%7-1)*86400
			} else if days%7 != 0 && days < 7 {
				startTs = endTs - 6*86400
			}
			req.BaseReq.CompareStartDate = time.Unix(startTs, 0).Format(consts.Fmt_Date)
			req.BaseReq.CompareEndDate = time.Unix(endTs, 0).Format(consts.Fmt_Date)
		}
	}
}

func (svc *AnalysisService) getDataFromDataAccess(ctx context.Context, queryId string,
	oriReq *analysis.GetProductReportTableRequest, withDate bool, isCmp bool, whereStr string, tableAddiCfg map[string]string, templateParam map[string]string) (tableData []*data_access.DrillTableRow, total *int64, err error) {
	var startTs, endTs = svc.buildTimeRange(oriReq, false)
	var cmpStartTs, cmpEndTs = svc.buildTimeRange(oriReq, true)
	var dateType, operator = svc.buildDateTypeAndOperator(oriReq, withDate)
	dimList, err := svc.buildDimensionList(ctx, oriReq)
	if err != nil {
		return
	}
	if withDate {
		dimList = append(dimList, &data_access.DimensionParam{DimensionCode: "date"}) // 追加时间维度
	}

	req := &data_access.GetTableDataRequest{
		QueryId: queryId,
		CurrentTime: &data_access.TimeRange{StartTime: utils.If(isCmp, cmpStartTs, startTs),
			EndTime: utils.If(isCmp, cmpEndTs, endTs), DateType: utils.If(withDate, dateType, nil)},
		DimensionList: dimList,
		IndicatorList: svc.buildIndicatorList(oriReq, operator),
		Filters: []*data_access.MultiFilter{
			{FieldName: "date_type", ValueType: "string", Op: "=", Value: "1d"},
		},
		ExtraParam: &data_access.ExtraParam{OneIndWithOp: true, LogicTableAddiConfig: tableAddiCfg, TemplateParam: templateParam},
	}
	if whereStr != "" {
		req.Filters = append(req.Filters, &data_access.MultiFilter{
			FieldName: whereStr,
			ValueType: "=",
			Op:        "custom",
		})
	}
	if oriReq.CompareType == 2 {
		req.CompareTime = &data_access.TimeRange{StartTime: cmpStartTs, EndTime: cmpEndTs, DateType: utils.If(withDate, dateType, nil)}
	}
	if !withDate {
		req.Sort = &common.Sort{Field: oriReq.BaseReq.TargetMetaList[0], IsAsc: false}
	}

	resp, err := ecom_smartop_data_access.RawCall.GetTableData(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[GetProductReportTable]查询通用取数失败: req=【%v】, err=【%v】", convert.ToJSONString(req), err)
		return
	} else if resp.BaseResp != nil && resp.BaseResp.StatusCode != 0 {
		logs.CtxError(ctx, "[GetProductReportTable]查询通用取数失败: req=【%v】, resp=【%v】", convert.ToJSONString(req), resp)
		err = errors.Errorf("通用取数查询失败: [%v]%v", resp.BaseResp.StatusCode, resp.BaseResp.StatusMessage)
		return
	} else if resp.Data == nil {
		logs.CtxError(ctx, "[GetProductReportTable]查询通用取数失败: req=【%v】, resp.Data=nil", convert.ToJSONString(req))
		err = errors.Errorf("通用取数查询失败: 数据结果为空")
		return
	}

	tableData = resp.Data.Rows
	total = resp.Data.Total

	return
}

// 根据 周期、聚合方式得到算子
var operatorCycleAggrMap = map[bool]map[string][]string{
	true: {
		"daily": {"cycleDaily"},
		"sum":   {"cycleSum", "chainRatio"},
	},
	false: {
		"daily": {"valueD", "cmpDaily", "lastWeekRatio"},
		"sum":   {"value", "cmpValue", "weekValueRate"},
	},
}

var larkPushAggrMap = map[int64][]string{
	1: {"value", "chainValue", "sameValueWR", "chart"},
	2: {"valueD", "cmpDaily", "chartWeekAvg"},
}

func (svc *AnalysisService) getQueryIdByBizType(bizTypeInfo *biz_utils.BizMetaInfo) string {
	return "productAnalysisReport_" + bizTypeInfo.TableID
}

func (svc *AnalysisService) buildDateTypeAndOperator(oriReq *analysis.GetProductReportTableRequest, withDate bool) (dateType *common.DateType, operator []string) {
	dateType = common.DateTypePtr(common.DateType_DAY)
	operator = operatorCycleAggrMap[withDate]["sum"]

	//考虑日报周报场景
	if oriReq.LarkSubscribeType == nil {
		switch oriReq.AggrType {
		case dimensions.AnalysisAggregationType_WeekDaily:
			dateType = common.DateTypePtr(common.DateType_SEVEN_DAY)
			operator = operatorCycleAggrMap[withDate]["daily"]
		case dimensions.AnalysisAggregationType_WeekSum:
			dateType = common.DateTypePtr(common.DateType_SEVEN_DAY)
			operator = operatorCycleAggrMap[withDate]["sum"]
		case dimensions.AnalysisAggregationType_MonthDaily:
			dateType = common.DateTypePtr(common.DateType_MONTH)
			operator = operatorCycleAggrMap[withDate]["daily"]
		case dimensions.AnalysisAggregationType_MonthSum:
			dateType = common.DateTypePtr(common.DateType_MONTH)
			operator = operatorCycleAggrMap[withDate]["sum"]
		default:
			dateType = common.DateTypePtr(common.DateType_DAY)
			operator = operatorCycleAggrMap[withDate]["sum"]
		}
	} else {
		switch *oriReq.LarkSubscribeType {
		case 1:
			dateType = common.DateTypePtr(common.DateType_DAY)
			operator = larkPushAggrMap[1]
		case 2:
			dateType = common.DateTypePtr(common.DateType_SEVEN_DAY)
			operator = larkPushAggrMap[2]
		default:
			dateType = common.DateTypePtr(common.DateType_DAY)
			operator = operatorCycleAggrMap[withDate]["sum"]
		}
	}

	return
}

func (svc *AnalysisService) buildTimeRange(oriReq *analysis.GetProductReportTableRequest, isCmp bool) (startTs, endTs int64) {
	if isCmp && oriReq.BaseReq.CompareStartDate != "" && oriReq.BaseReq.CompareEndDate != "" {
		startTs = time_utils.DateStringToTimestamp(oriReq.BaseReq.CompareStartDate)
		endTs = time_utils.DateStringToTimestamp(oriReq.BaseReq.CompareEndDate)
	} else {
		startTs = time_utils.DateStringToTimestamp(oriReq.BaseReq.StartDate)
		endTs = time_utils.DateStringToTimestamp(oriReq.BaseReq.EndDate)
	}

	return
}

func (svc *AnalysisService) buildIndicatorList(oriReq *analysis.GetProductReportTableRequest, operator []string) (indList []*data_access.IndicatorParamV2) {
	indList = make([]*data_access.IndicatorParamV2, 0)
	for _, code := range oriReq.BaseReq.TargetMetaList {
		indList = append(indList, &data_access.IndicatorParamV2{Code: code, OperatorList: operator})
	}
	return
}

func (svc *AnalysisService) buildDimensionList(ctx context.Context, oriReq *analysis.GetProductReportTableRequest) (dimensionList []*data_access.DimensionParam, err error) {
	if len(oriReq.BaseReq.GroupAttrs) == 0 {
		return
	}
	dimMap, err := svc.DimensionListDao.GetDimensionMap(ctx, oriReq.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductReportTable]获取col map失败，err=%v+", err)
		return
	}

	for _, dim := range oriReq.BaseReq.GroupAttrs {
		if dimCfg, ok := dimMap[convert.ToInt64(dim.DimInfo.Id)]; !ok || dimCfg == nil {
			logs.CtxError(ctx, "未查询到维度信息, dimInfo=%v", dim.DimInfo)
			err = errors.New("未查询到维度信息")
			return
		} else {
			// 目前是维度打平，后续需要下钻，需要构建下钻维度层级结构
			dimensionList = append(dimensionList, &data_access.DimensionParam{DimensionCode: dimCfg.DimColumn})
		}
	}
	return
}

func (svc *AnalysisService) buildDimensionCodeList(ctx context.Context, oriReq *analysis.GetProductReportTableRequest) (dimensionCodeList []string, err error) {
	if len(oriReq.BaseReq.GroupAttrs) == 0 {
		return
	}
	dimMap, err := svc.DimensionListDao.GetDimensionMap(ctx, oriReq.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductReportTable]获取col map失败，err=%v+", err)
		return
	}

	for _, dim := range oriReq.BaseReq.GroupAttrs {
		if dimCfg, ok := dimMap[convert.ToInt64(dim.DimInfo.Id)]; !ok || dimCfg == nil {
			logs.CtxError(ctx, "未查询到维度信息, dimInfo=%v", dim.DimInfo)
			err = errors.New("未查询到维度信息")
			return
		} else {
			// 目前是维度打平，后续需要下钻，需要构建下钻维度层级结构
			dimensionCodeList = append(dimensionCodeList, dimCfg.DimColumn)
		}
	}
	return
}

// key是维度值拼接
func (svc *AnalysisService) splitDateRow(ctx context.Context, isCompareRow bool,
	row *data_access.DrillTableRow, dimensionCodeList []string,
	targetMetaMap map[string]*dao.TargetMetaInfo,
	targetMap map[string]map[string]*analysis.TargetCardEntity) (dimKey string, err error) {
	if targetMap == nil {
		targetMap = map[string]map[string]*analysis.TargetCardEntity{} // 维度.指标.指标值
	}

	dimValueList := strings.Split(row.Code, "$@$")
	dimKey = row.Code
	var endDateTsString string
	if slices.ContainsString(dimensionCodeList, "date") {
		if len(dimValueList) > 1 {
			dimKey = strings.Join(dimValueList[:len(dimValueList)-1], "$@$")
		} else {
			dimKey = ""
		}
		endDateTsString = dimValueList[len(dimValueList)-1]
	}
	if targetMap[dimKey] == nil {
		targetMap[dimKey] = make(map[string]*analysis.TargetCardEntity)
	}

	// 维度在行，指标和算子在列,row.Values里包含了维度.value信息
	for indOpValKey, indOpVal := range row.Values {
		indOp := strings.Split(indOpValKey, ".")
		if len(indOp) != 2 {
			continue
		}
		if slices.ContainsString(dimensionCodeList, indOp[0]) { // 表明当前是维度
			continue
		}

		var code = indOp[0]
		var op = indOp[1]
		var newTarget *analysis.TargetCardEntity
		if _, ok := targetMap[dimKey][code]; !ok {
			targetMetaInfo := targetMetaMap[code]
			if targetMetaInfo == nil {
				continue
			}
			newTarget, err = base_struct_condition.GetTargetEntity(ctx, indOpVal.Value, targetMetaInfo)
			if err != nil {
				return
			}
			targetMap[dimKey][code] = newTarget
		}
		// 根据算子，来构建不同的数据
		var displayV string
		switch op {
		case "cycleDaily", "cycleSum":
			// 趋势图算子
			displayValue, _ := valueFormat(indOpVal.Value, targetMetaMap[code])
			point := &analysis.TargetTrendPoint{
				Value:        convert.ToFloat64(indOpVal.Value),
				DisplayValue: displayValue,
				Name:         targetMap[dimKey][code].Name,
				DisplayName:  targetMap[dimKey][code].DisplayName,
				X:            endDateTsString,
			}
			if isCompareRow {
				targetMap[dimKey][code].CompareTrendData = append(targetMap[dimKey][code].CompareTrendData, point)
			} else {
				targetMap[dimKey][code].TrendData = append(targetMap[dimKey][code].TrendData, point)
			}

		case "value", "valueD":
			// 当期汇总
			targetMap[dimKey][code].Value = convert.ToFloat64(indOpVal.Value)
			displayV, err = valueFormat(indOpVal.Value, targetMetaMap[code])
			if err != nil {
				logs.CtxError(ctx, "GetBriefMetricDisplayValue Err = %v", err)
				return
			}
			targetMap[dimKey][code].DisplayValue = displayV

		case "cmpDaily", "cmpValue":
			// 对比期汇总
			targetMap[dimKey][code].CycleValue = convert.ToFloat64(indOpVal.Value)
			displayV, err = valueFormat(indOpVal.Value, targetMetaMap[code])
			if err != nil {
				logs.CtxError(ctx, "GetBriefMetricDisplayValue Err = %v", err)
				return
			}
			targetMap[dimKey][code].CycleDisplayValue = displayV
		default:
			logs.CtxWarn(ctx, "op 未匹配 = %v", op)
		}
	}

	return
}

func (svc *AnalysisService) buildDimensionRows(dimCodeList, dimKeyList []string,
	dimCodeValueNameMap map[string]map[string]string, targetMap map[string][]*analysis.TargetCardEntity) (rows []*analysis.MultiDimFullListRow) {
	if len(dimCodeList) == 0 {
		return
	}
	var tmpLevelRowMap = map[int]map[string][]*analysis.MultiDimFullListRow{}
	var levelRowMap = map[int]map[string][]*analysis.MultiDimFullListRow{len(dimCodeList): make(map[string][]*analysis.MultiDimFullListRow)}
	// 维度key顺序，构建维度行
	for _, dimKey := range dimKeyList {
		dimValList := strings.Split(dimKey, "$@$")
		dimCode := dimCodeList[len(dimValList)-1]
		dimVal := dimValList[len(dimValList)-1]
		dimName := dimCodeValueNameMap[dimCode][dimVal]
		row := &analysis.MultiDimFullListRow{
			EnumValue:   dimVal,
			DisplayName: dimName,
			TargetList:  targetMap[dimKey],
			DimKey:      dimKey,
			Children:    nil,
		}
		levelRowMap[len(dimCodeList)][dimKey] = []*analysis.MultiDimFullListRow{row}
	}

	var firstRowMap = map[string]bool{}
	for level := len(dimCodeList); level >= 1; level-- {
		if _, ok := tmpLevelRowMap[level]; !ok {
			tmpLevelRowMap[level] = make(map[string][]*analysis.MultiDimFullListRow)
		}
		for _, dimKey := range dimKeyList {
			dimValList := strings.Split(dimKey, "$@$")
			dimCode := dimCodeList[level-1]
			dimVal := dimValList[level-1]
			dimName := dimCodeValueNameMap[dimCode][dimVal]
			curKey := strings.Join(dimValList[:level], "$@$")
			parentKey := strings.Join(dimValList[:level-1], "$@$")
			tmpRow := &analysis.MultiDimFullListRow{
				EnumValue:   dimVal,
				DisplayName: dimName,
				DimKey:      curKey,
			}
			if level == len(dimCodeList) {
				tmpRow.TargetList = targetMap[curKey]
			}
			if len(tmpLevelRowMap[level+1]) > 0 && len(tmpLevelRowMap[level+1][curKey]) > 0 {
				tmpRow.Children = tmpLevelRowMap[level+1][curKey]
			}

			if level == 1 && !firstRowMap[tmpRow.DimKey] {
				rows = append(rows, tmpRow)
				firstRowMap[tmpRow.DimKey] = true
			} else {
				tmpLevelRowMap[level][parentKey] = append(tmpLevelRowMap[level][parentKey], tmpRow)
			}
		}
	}

	return
}

func (svc *AnalysisService) rebuildTarget(target *analysis.TargetCardEntity, dateType *common.DateType, targetMetaMap map[string]*dao.TargetMetaInfo) *analysis.TargetCardEntity {
	if target == nil || (len(target.TrendData) == 0 && len(target.CompareTrendData) == 0) {
		return target
	}

	if len(target.TrendData) > 0 {
		// 升序排序
		sort.Slice(target.TrendData, func(i, j int) bool {
			return target.TrendData[i].X < target.TrendData[j].X
		})
		// 更新X轴显示
		var valueSum float64
		var days = len(target.TrendData)
		for idx := range target.TrendData {
			end := convert.ToInt64(target.TrendData[idx].X)
			if dateType != nil && *dateType == common.DateType_SEVEN_DAY {
				// 返回的是周期的最后一天，需要往前补开始时间
				start := end - 6*86400
				target.TrendData[idx].X = fmt.Sprintf("%v-%v", time.Unix(start, 0).Format("01月02日"),
					time.Unix(end, 0).Format("01月02日"))
			} else if dateType != nil && *dateType == common.DateType_MONTH {
				target.TrendData[idx].X = time.Unix(end, 0).Format("2006-01月")
			} else {
				target.TrendData[idx].X, _ = framework_udf.CustomDate(target.TrendData[idx].X)
			}
			valueSum += target.TrendData[idx].Value
		}

		// 日均指标，直接用趋势图数据计算
		if target.Extra != nil && target.Extra.AttributeType == "日均指标" && dateType != nil && *dateType == common.DateType_DAY {
			target.Value = valueSum / float64(days)
			target.DisplayValue, _ = valueFormat(target.Value, targetMetaMap[target.Name])
		}
	}

	if len(target.CompareTrendData) > 0 {
		// 升序排序
		sort.Slice(target.CompareTrendData, func(i, j int) bool {
			return target.CompareTrendData[i].X < target.CompareTrendData[j].X
		})

		var valueSum float64
		for idx := range target.CompareTrendData {
			end := convert.ToInt64(target.CompareTrendData[idx].X)
			if dateType != nil && *dateType == common.DateType_SEVEN_DAY {
				// 返回的是周期的最后一天，需要往前补开始时间
				start := end - 6*86400
				target.CompareTrendData[idx].X = fmt.Sprintf("%v-%v", time.Unix(start, 0).Format("01月02日"),
					time.Unix(end, 0).Format("01月02日"))
			} else if dateType != nil && *dateType == common.DateType_MONTH {
				target.CompareTrendData[idx].X = time.Unix(end, 0).Format("2006-01月")
			} else {
				target.CompareTrendData[idx].X, _ = framework_udf.CustomDate(target.CompareTrendData[idx].X)
			}
			valueSum += target.CompareTrendData[idx].Value
		}
		// 日均指标，直接用趋势图数据计算
		if target.Extra != nil && target.Extra.AttributeType == "日均指标" && dateType != nil && *dateType == common.DateType_DAY {
			target.CycleValue = valueSum / float64(len(target.CompareTrendData))
			target.CycleDisplayValue, _ = valueFormat(target.CycleValue, targetMetaMap[target.Name])
		}
	}

	return target
}

func (svc *AnalysisService) GetTableAndDateList(currentDimIdx int, prefix map[string]interface{}, dimNameList []string, rows []*analysis.MultiDimFullListRow) (table []map[string]interface{}, dateList []string) {
	table = make([]map[string]interface{}, 0)
	if len(rows) == 0 {
		return
	}

	for _, row := range rows {
		if len(row.DisplayName) > 0 && currentDimIdx < len(dimNameList) {
			prefix[dimNameList[currentDimIdx]] = row.DisplayName
		}
		if len(row.TargetList) > 0 {
			for _, target := range row.TargetList {
				record := make(map[string]interface{})
				for k, v := range prefix {
					record[k] = v
				}

				record["name"] = target.DisplayName
				if target.DisplayValue == "-" {
					record["value"] = target.DisplayValue
				} else {
					record["value"] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(target.Value, 'f', 5, 64))
				}

				if target.CycleDisplayValue == "-" {
					record["cycle_value"] = target.CycleDisplayValue
				} else {
					record["cycle_value"] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(target.CycleValue, 'f', 5, 64))
				}
				if len(target.TrendData) > 0 {
					// 分析周期
					for _, trend := range target.TrendData {
						if trend.DisplayValue == "-" {
							record[trend.X] = trend.DisplayValue
						} else {
							record[trend.X] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(trend.Value, 'f', 5, 64))
						}
						dateList = append(dateList, trend.X)
					}
				}
				if len(target.CompareTrendData) > 0 {
					// 对比周期
					for _, trend := range target.CompareTrendData {
						if trend.DisplayValue == "-" {
							record[trend.X] = trend.DisplayValue
						} else {
							record[trend.X] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(trend.Value, 'f', 5, 64))
						}
						dateList = append(dateList, trend.X)
					}
				}
				table = append(table, record)
			}
		} else if len(row.Children) > 0 {
			if childTable, childDateList := svc.GetTableAndDateList(currentDimIdx+1, prefix, dimNameList, row.Children); len(childTable) > 0 {
				table = append(table, childTable...)
				dateList = append(dateList, childDateList...)
			}
		}
	}

	dateList = slices.DistinctString(dateList)
	sort.Strings(dateList)

	return
}

func genOneTable(ctx context.Context, table []map[string]interface{}) (*onetable.Table, error) {
	return onetable.NewTable(table), nil
}

func (svc *AnalysisService) genSheet(ctx context.Context, table *onetable.Table,
	email, docName string, preHeader []string,
	dimCodeNameList []string, dateList []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet("报表", table)
	sheet.AddHead([][]string{preHeader})

	// 维度列
	for _, name := range dimCodeNameList {
		sheet.AddColumn(name, name)
	}

	sheet.AddColumn("分析周期汇总数据", "value")
	sheet.AddColumn("对比周期汇总数据", "cycle_value")

	// 指标列
	sheet.AddColumn("指标", "name")

	// 时间列
	for _, d := range dateList {
		sheet.AddColumn(d, d)
	}

	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, fmt.Sprintf("商品分析-%s-趋势分析报告", docName))
	return nil, formatter.Export(ctx, email, nil, nil)
}

func valueFormat(val interface{}, targetMeta *dao.TargetMetaInfo) (displayValue string, err error) {
	if val == nil {
		return "-", nil
	}

	if targetMeta.ValueType == "int" {
		val = int(convert.ToFloat64(val))
	}

	return framework_udf.GetBriefMetricDisplayValue(val, targetMeta.ValueType, targetMeta.ValueUnit, targetMeta.TargetPrecision)
}
