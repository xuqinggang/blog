package analysis_service

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/context"
	"fmt"
	"testing"
)

func Test_InflectionPointInsight(t *testing.T) {
	ctx := context.Background()
	req := &analysis.InflectionPointInsightRequest{
		BaseReq: &dimensions.ProductAnalysisBaseStruct{},
		PageReq: &base.PageInfo{},
		ProductLabels: []*analysis.ProductLabel{
			{ProductId: "123456789012345678", Label: 0},
			{ProductId: "234567890123456789", Label: 1},
		},
		TopDimensions: 5,
		Base:          &base.Base{},
	}
	p := &AnalysisService{}
	resp, err := p.InflectionPointInsight(ctx, req)
	if err != nil {
		t.Errorf("Test_InflectionPointInsight failed, err: %v", err)
	}
	fmt.Println(resp)

}
