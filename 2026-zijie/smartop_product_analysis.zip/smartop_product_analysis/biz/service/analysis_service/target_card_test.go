package analysis_service

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/temai/go_lib/convert"
	"fmt"
	"testing"
)

func TestName(t *testing.T) {
	resp := []*analysis.CoreOverviewFunnelData{
		{
			Targets: []string{"pay_amt", "pay_cnt", "prod_cnt"},
			RatioOption: []*analysis.RatioOption{
				{
					Label: "转化1",
					From:  "pay_amt",
					To:    "pay_cnt",
				}, {
					Label: "转化2",
					From:  "pay_cnt",
					To:    "prod_cnt",
				},
			},
			Dimensions: []*dimensions.SelectedDimensionInfo{
				{
					Id:               "10020",
					Name:             "八大人群",
					AttrType:         1,
					SelectedOperator: 0,
					SelectedValues: []*dimensions.EnumElement{
						{
							Code: "年轻中高消费力女性",
							Name: "年轻中高消费力女性",
						},
					},
				},
			},
		},
	}
	fmt.Print(convert.ToJSONString(resp))
}
