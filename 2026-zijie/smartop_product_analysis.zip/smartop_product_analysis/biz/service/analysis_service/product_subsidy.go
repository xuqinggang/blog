package analysis_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_marketing_promotion_growth_data_platform/kitex_gen/ecom/marketing/promotion_growth_data_platform"
	"code.byted.org/overpass/ecom_marketing_promotion_growth_data_platform/rpc/ecom_marketing_promotion_growth_data_platform"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/bytedance/sonic"
	"github.com/sanity-io/litter"
	"sort"
	"strings"
	"time"
)

func GetMultipleAnalysisCostData(ctx context.Context, osReq base_struct_condition.OsParamsReq, needTrend bool) (map[string]map[string]*analysis.TargetCardEntity, map[string]*analysis.TargetCardEntity, error) {
	// 没有货补数据权限，就直接返回不展示货补数据
	if !utils.IsCostUser(ctx) {
		return nil, nil, nil
	}
	// 商品明细这里的group by字段是商品ID
	groupByDim := GenGroupByDimSql(osReq)
	if groupByDim == "" {
		return nil, nil, errors.New("多维分析group参数为nil，请检查")
	}

	subSql, isForbiddenPerfectShard, err := GenMultipleAnalysisInlaySql(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return nil, nil, err
	}
	// 传给实验平台的sql入参
	var params = &promotion_growth_data_platform.ProductCostSqlParam{
		StartDate:             osReq.BaseStruct.StartDate,
		EndDate:               osReq.BaseStruct.EndDate,
		SubSql:                subSql,
		GroupBySql:            &groupByDim,
		ForbiddenPerfectShard: isForbiddenPerfectShard,
	}
	compareSubSql, isForbiddenPerfectShard, err := GenMultipleAnalysisInlaySql(ctx, osReq, base_struct_condition.SQLCalcType_Compare)
	if err != nil {
		return nil, nil, err
	}
	// 对比周期
	var compareParams = &promotion_growth_data_platform.ProductCostSqlParam{
		StartDate:             osReq.BaseStruct.CompareStartDate,
		EndDate:               osReq.BaseStruct.CompareEndDate,
		SubSql:                compareSubSql,
		GroupBySql:            &groupByDim,
		ForbiddenPerfectShard: isForbiddenPerfectShard,
	}
	// 拿到货补数据
	productCostTargetMap, targetKeyMap, err := GetProductCostData(ctx, params, compareParams, "multiple_dim_analysis", needTrend)
	if err != nil {
		return nil, nil, err
	}
	return productCostTargetMap, targetKeyMap, nil
}

func AddProdCostData(ctx context.Context, productCostTargetMap map[string]map[string]*analysis.TargetCardEntity, targetKeyMap map[string]*analysis.TargetCardEntity, resp []*analysis.MultiDimListRow) {
	if productCostTargetMap == nil || targetKeyMap == nil {
		return
	}
	// 这里用一个list存放targetKey，因为map多次遍历顺序不一致
	var targetKeyList = make([]string, 0)
	for key := range targetKeyMap {
		targetKeyList = append(targetKeyList, key)
	}
	SortProdTargetList(ctx, targetKeyList)
	// 将货补数据关联到resp中
	for _, dimRow := range resp {
		if dimRow.TargetList != nil {
			if _, ok := productCostTargetMap[dimRow.EnumValue]; ok {
				for _, targetKey := range targetKeyList {
					if _, ok := productCostTargetMap[dimRow.EnumValue][targetKey]; ok {
						dimRow.TargetList = append(dimRow.TargetList, productCostTargetMap[dimRow.EnumValue][targetKey])
					} else {
						dimRow.TargetList = append(dimRow.TargetList, targetKeyMap[targetKey])
					}
				}
			} else { // 匹配不到这个商品ID的货补数据，则填充0值
				for _, targetKey := range targetKeyList {
					if _, ok := targetKeyMap[targetKey]; ok {
						dimRow.TargetList = append(dimRow.TargetList, targetKeyMap[targetKey])
					}
				}
			}
		}
	}

}

func GenMultipleAnalysisInlaySql(ctx context.Context, osReq base_struct_condition.OsParamsReq, paramsType base_struct_condition.SQLCalcType) (string, bool, error) {
	var sb = &strings.Builder{}
	params, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, paramsType)
	if err != nil {
		return "", false, err
	}
	// 添加product_id的子查询
	// TopN筛选时，用global in会节约一部分查询时间
	if _, ok := params["not_distributed_perfect_shard"]; ok && params["not_distributed_perfect_shard"] == consts.IsTrueString {
		sb.WriteString(`product_id global in ( select prod_id from `)
	} else {
		sb.WriteString(`product_id in ( select prod_id from `)
	}
	if _, ok := params["table_name"]; ok {
		sb.WriteString(fmt.Sprintf(`%s table_alias `, params["table_name"]))
	} else {
		return "", false, errors.New("未找到关联的逻辑表名")
	}
	sb.WriteString(`where `)
	if _, ok := params["date_expr"]; ok {
		sb.WriteString(fmt.Sprintf(`%s `, params["date_expr"]))
	} else {
		return "", false, errors.New("未找到需要添加的日期值")
	}
	if _, ok := params["filter_param"]; ok {
		sb.WriteString(fmt.Sprintf(`and %s `, params["filter_param"]))
	}
	var isForbiddenPerfectShard bool
	// TopN筛选时，子查询不能添加完美分片参数，不然数据对不上
	if _, ok := params["not_distributed_perfect_shard"]; ok && params["not_distributed_perfect_shard"] == consts.IsTrueString {
		sb.WriteString(`)`)
		isForbiddenPerfectShard = true
	} else {
		sb.WriteString(`settings
        distributed_product_mode='local',
        distributed_perfect_shard=1)`)
	}

	// 添加人和场的筛选项
	sb, err = AddPersonPlaceFilter(ctx, osReq, sb)
	if err != nil {
		logs.CtxError(ctx, "添加人和场的筛选条件失败,err:%v", err.Error())
	}
	return sb.String(), isForbiddenPerfectShard, nil
}

func GenGroupByDimSql(osReq base_struct_condition.OsParamsReq) string {
	subSelect := make([]string, 0)
	for _, d := range osReq.MultiDimension {
		if dimInfo, exist := osReq.DimColMap[d]; exist && len(dimInfo.DimExpr) > 0 {
			subSelect = append(subSelect, fmt.Sprintf("%s", dimInfo.DimExpr))
		} else {
			subSelect = append(subSelect, d)
		}
	}
	// 暂时只支持单维度的多维分析
	if len(subSelect) > 0 {
		return subSelect[0]
	}
	return ""
}

func GetProductDetailCostData(ctx context.Context, osReq base_struct_condition.OsParamsReq, resp *analysis.GetProductAnalysisMultiDimProductListData) error {
	// 没有货补数据权限，就直接返回不展示货补数据
	if !utils.IsCostUser(ctx) {
		return nil
	}
	// 是否支持货补数据
	isSupportCostTarget, err := JudgeContainNotSupportDim(ctx, osReq)
	if err != nil {
		logs.CtxError(ctx, "[GetProductDetailCostData]判断是否支持货补数据失败,err:%v", err.Error())
		return err
	}
	if !isSupportCostTarget {
		logs.CtxWarn(ctx, "[GetProductDetailCostData]当前的分析维度不支持获取货补数据")
		return nil
	}
	// 商品明细数组长度为0时，不请求货补数据
	if len(resp.ProductList) == 0 {
		return nil
	}

	// 商品明细这里的group by字段是商品ID
	groupByDim := `product_id`
	subSql, err := GenProductDetailInlaySql(ctx, osReq, resp)
	if err != nil {
		return err
	}
	// 传给实验平台的sql入参
	var params = &promotion_growth_data_platform.ProductCostSqlParam{
		StartDate:  osReq.BaseStruct.StartDate,
		EndDate:    osReq.BaseStruct.EndDate,
		SubSql:     subSql,
		GroupBySql: &groupByDim,
	}
	// 拿到货补数据
	productCostTargetMap, targetKeyMap, err := GetProductCostData(ctx, params, nil, "product_detail", false)
	if err != nil {
		return err
	}
	// 这里用一个list存放targetKey，因为map多次遍历顺序不一致
	var targetKeyList = make([]string, 0)
	for key := range targetKeyMap {
		targetKeyList = append(targetKeyList, key)
	}
	// 给list排序
	SortProdTargetList(ctx, targetKeyList)
	// 将货补数据关联到resp中
	if productCostTargetMap != nil {
		for _, prodInfo := range resp.ProductList {
			prodInfo.ProdSubsidyData = &analysis.ProdSubsidyData{
				TargetList:               make([]*analysis.TargetCardEntity, 0),
				HasSubsidyDataPermission: true,
			}
			if _, ok := productCostTargetMap[prodInfo.ProductInfo.Id]; ok {
				for _, targetKey := range targetKeyList {
					if _, ok := productCostTargetMap[prodInfo.ProductInfo.Id][targetKey]; ok {
						prodInfo.ProdSubsidyData.TargetList = append(prodInfo.ProdSubsidyData.TargetList, productCostTargetMap[prodInfo.ProductInfo.Id][targetKey])
					} else {
						prodInfo.ProdSubsidyData.TargetList = append(prodInfo.ProdSubsidyData.TargetList, targetKeyMap[targetKey])
					}
				}
			} else { // 匹配不到这个商品ID的货补数据，则填充0值
				for _, targetKey := range targetKeyList {
					if _, ok := targetKeyMap[targetKey]; ok {
						prodInfo.ProdSubsidyData.TargetList = append(prodInfo.ProdSubsidyData.TargetList, targetKeyMap[targetKey])
					}
				}
			}
		}
	}
	return err
}

// SortProdTargetList 指标列表排序
func SortProdTargetList(ctx context.Context, targetList []string) {
	costTargetList, err := dimension_service.GetProdCostTargetMeta(ctx, 0, 0)
	var CategoryOrder = make(map[string]int)
	if err != nil {
		CategoryOrder = map[string]int{"UserCost": 1, "ProductCost": 2, "TotalUgCost": 3}
	} else {
		for i, info := range costTargetList {
			CategoryOrder[info.Name] = i + 1
		}
	}
	sort.Slice(targetList, func(i, j int) bool {
		// 获取每个元素的排序权重，使用order映射
		// 如果元素不在order中，给一个默认高值保证它排在最后
		rankI, okI := CategoryOrder[targetList[i]]
		if !okI {
			rankI = len(CategoryOrder) + 1
		}
		rankJ, okJ := CategoryOrder[targetList[j]]
		if !okJ {
			rankJ = len(CategoryOrder) + 1
		}
		return rankI < rankJ
	})
}

// GetProductCostData 返回值1：维度-指标名-指标卡的map。返回值2：指标名-指标卡的去重汇总集合
func GetProductCostData(ctx context.Context, sqlParams, compareSqlParams *promotion_growth_data_platform.ProductCostSqlParam, moduleName string, needTrend bool) (map[string]map[string]*analysis.TargetCardEntity, map[string]*analysis.TargetCardEntity, error) {
	if sqlParams == nil {
		return nil, nil, errors.New("请保证传入的sqlParams不为nil")
	}
	paramsMarshal, err := sonic.MarshalString(sqlParams)
	if err != nil {
		return nil, nil, err
	}
	var compareSqlKey *string = nil
	// 存入redis，获取redis_key
	ctx = context.WithValue(ctx, consts.CtxRedisCluster, consts.ClusterName_GrowthExperimentPlatform)
	currKey := utils.GenRedisKey(fmt.Sprintf("%s_curr", moduleName))
	err = redis.Set(ctx, currKey, paramsMarshal, 30*24*time.Hour)
	if err != nil {
		logs.CtxError(ctx, "设置redis_key失败,err:%v", err.Error())
		return nil, nil, err
	}
	// 对比sql
	if compareSqlParams != nil {
		compareParamsMarshal, err := sonic.MarshalString(compareSqlParams)
		if err != nil {
			return nil, nil, err
		}
		compareKey := utils.GenRedisKey(fmt.Sprintf("%s_compare", moduleName))
		err = redis.Set(ctx, compareKey, compareParamsMarshal, 30*24*time.Hour)
		if err != nil {
			logs.CtxError(ctx, "设置redis_key失败,err:%v", err.Error())
			return nil, nil, err
		}
		compareSqlKey = &compareKey
	}

	exprReq := &promotion_growth_data_platform.GetProductCostRequest{
		Tenant:             promotion_growth_data_platform.PgdpTenantId_ProductInsights,
		SqlParamKey:        currKey,
		CompareSqlParamKey: compareSqlKey,
		NeedTrend:          needTrend,
	}
	logs.CtxInfo(ctx, "传入实验平台的参数如下: "+litter.Sdump(exprReq))

	// 调用实验平台接口，获取货补数据
	productCost, err := ecom_marketing_promotion_growth_data_platform.RawCall.GetProductCost(ctx, exprReq)
	if err != nil {
		logs.CtxError(ctx, "调用实验平台货补数据接口失败,err:%v", err.Error())
		return nil, nil, err
	}
	logs.CtxInfo(ctx, "获取实验平台数据成功,返回值内容如下: "+litter.Sdump(productCost))
	// key指标名，value 该key对应的0值指标卡
	var targetKeySet = make(map[string]*analysis.TargetCardEntity)
	// key1：维度值，key2：指标名，value指标卡
	var enumValueMap = make(map[string]map[string]*analysis.TargetCardEntity)
	for _, value := range productCost.GroupValue {
		// 生成指标key和趋势图的map
		var targetTrendMap = make(map[string][]*analysis.TargetTrendPoint)
		if needTrend && value.TrendData != nil {
			// value.TrendData.Data 是指标和趋势图的结构体
			for _, keyTrend := range value.TrendData.Data {
				var trendList = make([]*analysis.TargetTrendPoint, 0)
				for i, point := range keyTrend.Value {
					var xAxis string
					if i < len(value.TrendData.Timestamp) {
						xAxis, _ = framework_udf.CustomDate(value.TrendData.Timestamp[i])
					}
					displayValue, _ := framework_udf.GetBriefMetricDisplayValue(point.Number, "double", "", 2)
					trendList = append(trendList, &analysis.TargetTrendPoint{
						Value:        point.Number,
						DisplayValue: displayValue,
						Name:         keyTrend.Key,
						DisplayName:  keyTrend.Name,
						X:            xAxis,
					})
				}
				targetTrendMap[keyTrend.Key] = trendList
			}
		}
		if value != nil && len(value.Indicators) > 0 {
			if _, ok := enumValueMap[value.GroupValue]; !ok {
				enumValueMap[value.GroupValue] = make(map[string]*analysis.TargetCardEntity)
			}
			for _, indicator := range value.Indicators {
				if indicator != nil {
					targetCard := &analysis.TargetCardEntity{
						Name:        indicator.Key,
						DisplayName: indicator.Name,
						Extra: &analysis.TargetCardExtraInfo{
							IsLargerAdvantage: true,
							DistributionFlag:  true,
						},
					}
					if _, ok := targetTrendMap[indicator.Key]; ok {
						targetCard.TrendData = targetTrendMap[indicator.Key]
					}
					if indicator.Value != nil {
						targetCard.Value = indicator.Value.Number
						if indicator.Value.Ratio != nil {
							targetCard.CycleChangeRatio = indicator.Value.Ratio.Ratio
						}
						targetCard.DisplayValue, _ = framework_udf.GetBriefMetricDisplayValue(indicator.Value.Number, "double", "", 2)
					}
					enumValueMap[value.GroupValue][indicator.Key] = targetCard
					if _, ok := targetKeySet[indicator.Key]; !ok {
						targetKeySet[indicator.Key] = &analysis.TargetCardEntity{
							Name:             indicator.Key,
							DisplayName:      indicator.Name,
							Value:            0,
							DisplayValue:     "-",
							CycleChangeRatio: 0,
							Extra: &analysis.TargetCardExtraInfo{
								IsLargerAdvantage: true,
							},
						}
					}
				}
			}
		}
	}

	// 整体数据的指标卡
	var wholeTargetMap = make(map[string]*analysis.TargetCardEntity)
	for _, targetCardMap := range enumValueMap {
		for targetKey, entity := range targetCardMap {
			if _, ok := wholeTargetMap[targetKey]; ok {
				wholeTargetMap[targetKey].Value += entity.Value
				wholeTargetMap[targetKey].CycleValue += entity.Value - (entity.Value)*entity.CycleChangeRatio
				if needTrend {
					for i, point := range wholeTargetMap[targetKey].TrendData {
						if i < len(entity.TrendData) {
							point.Value += entity.TrendData[i].Value
						}
					}
				}
			} else {
				wholeTargetMap[targetKey] = &analysis.TargetCardEntity{
					Value:       entity.Value,
					Name:        entity.Name,
					DisplayName: entity.DisplayName,
					TrendData:   make([]*analysis.TargetTrendPoint, 0),
					CycleValue:  entity.Value - (entity.Value)*entity.CycleChangeRatio,
					Extra: &analysis.TargetCardExtraInfo{
						IsLargerAdvantage: true,
						DistributionFlag:  true,
						DistributionValue: 1,
					},
				}
				if needTrend {
					for _, point := range entity.TrendData {
						wholeTargetMap[targetKey].TrendData = append(wholeTargetMap[targetKey].TrendData, &analysis.TargetTrendPoint{
							Value:        point.Value,
							DisplayValue: point.DisplayValue,
							Name:         point.Name,
							DisplayName:  point.DisplayName,
							X:            point.X,
						})
					}
				}
			}
		}
	}
	// 加工整体的展示值和环比值
	for _, targetEntity := range wholeTargetMap {
		targetEntity.DisplayValue, _ = framework_udf.GetBriefMetricDisplayValue(targetEntity.Value, "double", "", 2)
		if targetEntity.CycleValue > 0 {
			targetEntity.CycleChangeRatio = (targetEntity.Value - targetEntity.CycleValue) / targetEntity.CycleValue
		} else {
			targetEntity.CycleChangeRatio = 0
		}
		if needTrend {
			for _, point := range targetEntity.TrendData {
				point.DisplayValue, _ = framework_udf.GetBriefMetricDisplayValue(point.Value, "double", "", 2)
			}
		}
	}
	// 加工分布比例
	for _, targetMap := range enumValueMap {
		for targetKey, targetEntity := range targetMap {
			if wholeTarget, ok := wholeTargetMap[targetKey]; ok {
				if wholeTarget.Value > 0 {
					targetEntity.Extra.DistributionValue = targetEntity.Value / wholeTarget.Value
				} else {
					targetEntity.Extra.DistributionValue = 0
				}
			}
		}
	}
	enumValueMap[TotalEnumValue] = wholeTargetMap

	// 如果返回了元信息，则以元信息的指标列为准
	if productCost.Title != nil && len(productCost.Title) > 0 {
		for _, targetMeta := range productCost.Title {
			targetKeySet[targetMeta.Key] = &analysis.TargetCardEntity{
				Name:         targetMeta.Key,
				DisplayName:  targetMeta.Name,
				DisplayOrder: targetMeta.FunnelIndicatorSeq,
				Value:        0,
				DisplayValue: "0",
			}
		}
	}
	return enumValueMap, targetKeySet, nil
}

// GenProductDetailInlaySql 生成product_id子查询和人场的where条件
func GenProductDetailInlaySql(ctx context.Context, osReq base_struct_condition.OsParamsReq, resp *analysis.GetProductAnalysisMultiDimProductListData) (string, error) {
	var sb = &strings.Builder{}
	// 首先添加product_id的子查询
	sb.WriteString(`product_id in(`)
	for i, prodInfo := range resp.ProductList {
		if i > 0 {
			sb.WriteString(`,`)
		}
		sb.WriteString(prodInfo.ProductInfo.Id)
	}
	sb.WriteString(`) `)

	sb, err := AddPersonPlaceFilter(ctx, osReq, sb)
	if err != nil {
		logs.CtxError(ctx, "添加人和场的筛选条件失败,err:%v", err.Error())
	}
	return sb.String(), nil
}

func AddPersonPlaceFilter(ctx context.Context, osReq base_struct_condition.OsParamsReq, sb *strings.Builder) (*strings.Builder, error) {
	var filterDims = make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dimension := range osReq.BaseStruct.Dimensions {
		// 人和场的属性需要添加到筛选项中
		if dimension.AttrType == dimensions.DimensionAttributeType_User || dimension.AttrType == dimensions.DimensionAttributeType_Place {
			filterDims = append(filterDims, dimension)
		}
	}
	if len(filterDims) > 0 {
		dims := osReq.BaseStruct.Dimensions
		thresholdAttr := osReq.BaseStruct.ThresholdAttrs
		osReq.BaseStruct.Dimensions = filterDims
		osReq.BaseStruct.ThresholdAttrs = nil
		curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			return nil, err
		}
		// 生成完参数之后再把维度值还原回去
		osReq.BaseStruct.Dimensions = dims
		osReq.BaseStruct.ThresholdAttrs = thresholdAttr
		if _, ok := curr["filter_param"]; ok {
			sb.WriteString(fmt.Sprintf(`and %s`, curr["filter_param"]))
		}
	}
	return sb, nil
}

// JudgeContainNotSupportDim 判断货补数据请求是否包含不支持的维度
func JudgeContainNotSupportDim(ctx context.Context, osReq base_struct_condition.OsParamsReq) (bool, error) {
	var supportDims = make([]int64, 0)
	if err := tcc.GetTccConfWithUnmarshalTarget(ctx, "prod_cost_support_dims", &supportDims); err != nil {
		logs.CtxError(ctx, "JudgeContainNotSupportDim Error, prod_cost_support_dims")
		return true, err
	}
	var supportSet = make(map[int64]bool)
	for _, dimId := range supportDims {
		supportSet[dimId] = true
	}
	// 多维分析的维度
	if osReq.MultiDimension != nil && len(osReq.MultiDimension) > 0 {
		dimColMap, err := new(dao.DimensionListDao).GetDimensionColMap(ctx, osReq.BaseStruct.BizType)
		if err != nil {
			logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取col map失败，err=%v+", err)
			return true, err
		}
		for _, dim := range osReq.MultiDimension {
			if dimInfo, ok := dimColMap[dim]; ok {
				if _, ok2 := supportSet[dimInfo.ID]; !ok2 {
					return false, nil
				}
			}
		}
	}
	for _, dimension := range osReq.BaseStruct.Dimensions {
		// 人和场的属性需要添加到实验平台的底表做筛选，需要判断是否支持
		if dimension.AttrType == dimensions.DimensionAttributeType_User || dimension.AttrType == dimensions.DimensionAttributeType_Place {
			if _, ok := supportSet[convert.ToInt64(dimension.Id)]; !ok {
				return false, nil
			}
		}
	}
	return true, nil
}

func GetProdCostTargetMap(ctx context.Context) (map[string]*dimensions.TargetMetaInfo, error) {
	costTargetList, err := dimension_service.GetProdCostTargetMeta(ctx, 0, 0)
	if err != nil {
		return nil, err
	}
	var resMap = make(map[string]*dimensions.TargetMetaInfo, 0)
	for _, info := range costTargetList {
		resMap[info.Name] = info
	}
	return resMap, nil
}
