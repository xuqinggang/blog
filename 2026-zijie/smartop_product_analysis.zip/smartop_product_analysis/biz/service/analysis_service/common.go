package analysis_service

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
)

type IAnalysisService interface {
	GetProductAnalysisCoreOverview(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, needTrend bool) (resp []*analysis.TargetCategoryList, err error)
	GetProductAnalysisMultiDimList(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, needTrend bool) (resp []*analysis.MultiDimListRow, err error)
	GetProductAnalysisCoreConclusion(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp *analysis.ProductAnalysisCoreConclusionData, err error)
	GetProductAnalysisMultiDimConclusion(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp *analysis.ProductAnalysisMultiDimConclusionData, err error)
	GetProductAnalysisCoreHierarchical(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (resp []*analysis.GetProductAnalysisCoreHierarchicalInfo, err error)
	GetProductAnalysisMultiDimProductList(ctx context.Context, req *analysis.GetProductAnalysisMultiDimProductListRequest) (resp *analysis.GetProductAnalysisMultiDimProductListData, err error)
	GetProductAnalysisCoreTarget(ctx context.Context, req *analysis.GetProductAnalysisCoreTargetRequest) (resp *analysis.TargetCardEntity, err error)
	GetCoreTargetEntity(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, needTrend bool) ([]*analysis.TargetCardEntity, error)
	GetProductAnalysisMultiDimFullList(ctx context.Context, req *analysis.GetProductAnalysisMultiDimFullListRequest, appendParams AppendParams) (resp *analysis.GetProductAnalysisMultiDimFullListData, err error)
	GetProductAnalysisMultiDimTrend(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp []*analysis.GetProductAnalysisMultiDimTrendInfo, err error)
	GetProductAnalysisMultiDimProdCostData(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.MultiDimExtraTargetItem, err error)
	GetProductReportTable(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *analysis.GetProductReportTableData, err error)
	GetProductReportTableSubscribe(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *string, err error)
	GetProductReportTableDownload(ctx context.Context, req *analysis.GetProductReportTableRequest) (hasSend bool, err error)
	GetProductAnalysisDefaultFunnelMate(ctx context.Context, bizType dimensions.BizType) (resp []*analysis.CoreOverviewFunnelData, err error)
	GetProductAnalysisProdCnt(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisProdCntItem, err error)
	GetProductAnalysisUVCore(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp []*analysis.TargetCategoryList, err error)
	GetProductAnalysisMultiDimUvTargets(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.MultiDimExtraTargetItem, err error)
	InflectionPointInsight(ctx context.Context, req *analysis.InflectionPointInsightRequest) (resp *analysis.InflectionPointInsightData, err error)
	InflectionPointInsightDownload(ctx context.Context, req *analysis.InflectionPointInsightDownloadRequest) (hasSend bool, err error)
	GetSimilarProduct(ctx context.Context, req *analysis.GetSimilarProductRequest) (resp *analysis.GetSimilarProductResponseItem, err error)
	GetSimilarProductDownload(ctx context.Context, req *analysis.GetSimilarProductDownloadRequest) (hasSend bool, err error)
	CreateGetSimilarProductPool(ctx context.Context, req *analysis.CreateGetSimilarProductPoolRequest) (poolId string, err error)
	GetTableAndDateList(currentDimIdx int, prefix map[string]interface{}, dimNameList []string, rows []*analysis.MultiDimFullListRow) (table []map[string]interface{}, dateList []string)
}

type AnalysisService struct {
	DimensionListDao dao.IDimensionListDao
	DimensionEnumDao dao.IDimensionEnumDao
	AttributeDao     dao.IAttributeDao
	DimensionService dimension_service.IDimensionService
}

// oneService注册的sqlApiPath
const (
	ApiPathTargetCard                     = "7369884979809109018"
	ApiPathDistribution                   = "7371432796700558387"
	ApiPathProductDetail                  = "7371004413084795954"
	ApiPathProductOverall                 = "7372153638862537754"
	ApiPathProductOverallBillionSupply    = "7566910268622537766" // 超值购供给分析商品数量os api
	ApiPathTargetCardGreatValueBuy        = "7372543278828307466"
	ApiPathTargetCardOverall              = "7373944710404113418"
	ApiPathTargetCardGreatValueBuyOverall = "7373952622140671002"

	// ApiPathTargetCardUv uv指标
	ApiPathTargetCardUv = "7374684821886387250"

	// ApiPathGetMultiDimTargetList 多维分析结论使用
	ApiPathGetMultiDimTargetList = "7381299966280483867"

	// ApiPathGetMultiDimExportList 多维分析下载
	ApiPathGetMultiDimExportList              = "7392101990848906266"
	ApiPathGetMultiDimExportListGreatValueBuy = "7392119646079435814"
)

var UVTargetMap = map[string]string{
	"pay_uv":   "",
	"show_uv":  "",
	"click_uv": "",
}

type SimilarProductInfo struct {
	ProductId    int64   `json:"pid"`
	SimilarScore float64 `json:"sim"`
}
type SimilarProductsData struct {
	SeedProductId      string `json:"seed_pid"`
	SimilarProductsStr string `json:"sim_lst"`
	SimilarProducts    []*SimilarProductInfo
}

type GetSimilarProductCommonReq struct {
	BaseReq                 *dimensions.ProductAnalysisBaseStruct
	SeedProdIds             []string
	SeedPoolId              string
	SimilarProdIds          []string
	SimilarPoolId           string
	SeedFilterDimensions    []*dimensions.SelectedDimensionInfo
	SimilarFilterDimensions []*dimensions.SelectedDimensionInfo
	SimilarCountLimit       int64
}

type GetSimilarProdMatchType int32

const (
	GetSimilarProdMatchType_SeedProdIds GetSimilarProdMatchType = 1 // 种子商品ids
	GetSimilarProdMatchType_SeedPoolId  GetSimilarProdMatchType = 2 // 种子商品池id
	GetSimilarProdMatchType_SimProdIds  GetSimilarProdMatchType = 3 // 相似商品ids
	GetSimilarProdMatchType_SimPoolId   GetSimilarProdMatchType = 4 // 相似商品池id
)

const (
	SimilarProductDimType_asc_layer  = "正向排序" // 具有层级关系的维度，正向排序
	SimilarProductDimType_desc_layer = "反向排序" // 具有层级关系的维度，反向排序
	SimilarProductDimType_bool       = "布尔值"  // 布尔类型的维度
)

const (
	InflectionLocationFormatAsc  = "%s以上更容易是正向品\n%s以下更容易是非正向品"
	InflectionLocationFormatDesc = "%s以下更容易是正向品\n%s以上更容易是非正向品"
	InflectionLocationFormatBool = "%s更容易是正向品\n非%vs更容易是非正向品"
)
