package analysis_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/bytedance/sonic"
	"github.com/sanity-io/litter"
	"sort"
	"strings"
)

var TotalEnumValue = "不被匹配的整体"
var AllTotalEnumValue = "全量不被匹配的整体"

type AppendParams struct {
	OSParams        map[string]interface{}
	OSApiPath       string
	IsAllTotal      bool
	IsBuildTargetV2 bool // 新指标构建方法（变动点，分析周期/对比周期，构造赋值）
}

// GetProductAnalysisMultiDimFullList 获取维度列表清单
func (d *AnalysisService) GetProductAnalysisMultiDimFullList(ctx context.Context, req *analysis.GetProductAnalysisMultiDimFullListRequest, appendParams AppendParams) (resp *analysis.GetProductAnalysisMultiDimFullListData, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	if len(req.BaseReq.GroupAttrs) == 0 {
		return resp, errors.New("获取多维分析参数失败")
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	var prodCodeTagBaseDims = make([]*dimensions.SelectedDimensionInfo, 0)
	// 获取分析的维度信息
	groupCols := make([]string, 0)
	dimColEnumCodeMap := make(map[string]map[string]string)
	arrGroupColFilters := make([]string, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		if !appendParams.IsAllTotal {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}

		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		groupCols = append(groupCols, dimInfo.DimColumn)
		prodCodeTagBaseDims = append(prodCodeTagBaseDims, attr.DimInfo)
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			enumCodeMap := make(map[string]string)

			enumCodes := make([]string, 0)
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
				enumCodes = append(enumCodes, enum.Code)
			}
			if dimInfo.ProcessType == "数组类型" {
				enumCodes = slices.DistinctString(enumCodes)
				enumFilterStr := fmt.Sprintf("%s_new in ('%s')", dimInfo.DimColumn, strings.Join(enumCodes, "','"))
				if dimInfo.EnumDataType == "long" {
					enumFilterStr = fmt.Sprintf("%s_new in (%s)", dimInfo.DimColumn, strings.Join(enumCodes, ","))
				}
				arrGroupColFilters = append(arrGroupColFilters, enumFilterStr)
			}
			dimColEnumCodeMap[dimInfo.DimColumn] = enumCodeMap
		}
	}

	curr, compare, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: append(groupCols, base_struct_condition.GenerateDimKey(groupCols, consts.Empty)),
	})
	if err != nil {
		return
	}

	subSelect := make([]string, 0)
	newGroupCols := make([]string, 0)
	if !appendParams.IsAllTotal {
		for _, col := range groupCols {
			dimInfo, exist := dimColMap[col]
			if exist {
				if len(dimInfo.DimExpr) > 0 {
					subSelect = append(subSelect, fmt.Sprintf("cast(%s as String) as %s", dimInfo.DimExpr, col))
					newGroupCols = append(newGroupCols, col)
					continue
				}

				if dimInfo.ProcessType == "数组类型" {
					subSelect = append(subSelect, fmt.Sprintf("arrayJoin(%s) as %s_new", col, col))
					newGroupCols = append(newGroupCols, col+"_new")
					continue
				}
			}

			subSelect = append(subSelect, fmt.Sprintf("cast(%s as String) as %s", col, col))
			newGroupCols = append(newGroupCols, col)
		}

		curr["sub_select"] = strings.Join(subSelect, ",")
		curr["sub_select_join_on"] = base_struct_condition.GenerateDimKeyJoinOn(newGroupCols)
		//curr["sub_group"] = strings.Join(newGroupCols, ",")
		curr["export_select"] = strings.Join(append(newGroupCols, base_struct_condition.GenerateDimKey(newGroupCols, "")), ",")
		curr["dimension_rollup"] = strings.Join(newGroupCols, ",")
		if len(arrGroupColFilters) > 0 {
			curr["arr_group_col_filter"] = strings.Join(arrGroupColFilters, " and ")
		}
		//curr["dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(newGroupCols, "str_"), ",")

		compare["sub_select"] = strings.Join(subSelect, ",")
		compare["sub_select_join_on"] = base_struct_condition.GenerateDimKeyJoinOn(newGroupCols)
		//compare["sub_group"] = strings.Join(newGroupCols, ",")
		compare["export_select"] = strings.Join(append(newGroupCols, base_struct_condition.GenerateDimKey(newGroupCols, "")), ",")
		compare["dimension_rollup"] = strings.Join(newGroupCols, ",")
		if len(arrGroupColFilters) > 0 {
			compare["arr_group_col_filter"] = strings.Join(arrGroupColFilters, " and ")
		}
		//compare["dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(newGroupCols, "str_"), ",")
	} else {
		curr["sub_select"] = nil
		compare["sub_select"] = nil
		curr["export_select"] = "'all_total' as dim_key"
		compare["export_select"] = "'all_total' as dim_key"
	}

	if len(appendParams.OSParams) > 0 {
		for k, v := range appendParams.OSParams {
			curr[k] = v
			compare[k] = v
		}
	}

	apiPath := bizMetaInfo.MultiDimApiID
	if len(appendParams.OSApiPath) > 0 {
		apiPath = appendParams.OSApiPath
	}
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, NeedDistribution: true,
		KeyCols: append(newGroupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
	})
	if err != nil {
		return nil, err
	}

	if len(currTargetList) >= 10000 {
		logs.CtxWarn(ctx, "[GetProductAnalysisMultiDimList]获取的多维组合数量=%v+，超过1w", len(currTargetList))
		return resp, errors.New("MAX_10000_LIMIT_ERROR")
	}

	if req.NeedIncr {
		compareTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compare, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType,
			KeyCols: append(newGroupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return nil, err
		}
		if appendParams.IsBuildTargetV2 {
			currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumnV2(currTargetList, compareTargetList, nil, nil)
		} else {
			currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumn(currTargetList, compareTargetList, nil, nil)
		}
	}

	resp = &analysis.GetProductAnalysisMultiDimFullListData{
		FullList: make([]*analysis.MultiDimFullListRow, 0),
	}
	outParentRowMap := make(map[string][]*analysis.MultiDimFullListRow, 0)
	for _, keyTargetList := range currTargetList {
		if appendParams.IsAllTotal {
			resp.AllTotal = &analysis.MultiDimFullListRow{
				EnumValue:   AllTotalEnumValue,
				DisplayName: "全量整体",
				TargetList:  keyTargetList.TargetEntity,
				ProdTagCode: "",
			}
			continue
		}

		if len(keyTargetList.KeyColValues) <= len(groupCols) {
			continue
		}

		dimKey := convert.ToString(keyTargetList.KeyColValues[len(groupCols)])
		if len(strings.ReplaceAll(dimKey, "#", "")) == 0 && resp.Total == nil {
			resp.Total = &analysis.MultiDimFullListRow{
				EnumValue:   TotalEnumValue,
				DisplayName: "整体",
				TargetList:  keyTargetList.TargetEntity,
				ProdTagCode: "",
			}
			continue
		}

		maxLen := base_struct_condition.GetDimKeyMaxLen(dimKey)
		if maxLen == -1 {
			maxLen = 0
		}
		enumCode := convert.ToString(keyTargetList.KeyColValues[maxLen])
		displayName := consts.Empty
		enumCodeMap, exist := dimColEnumCodeMap[groupCols[maxLen]]
		if exist {
			displayName = enumCodeMap[enumCode]
		}
		if displayName == consts.Empty {
			displayName = dimKey
		}
		fullRow := &analysis.MultiDimFullListRow{
			EnumValue:   enumCode,
			DisplayName: displayName,
			TargetList:  keyTargetList.TargetEntity,
			DimKey:      dimKey,
			ProdTagCode: "",
		}
		if maxLen == 0 {
			resp.FullList = append(resp.FullList, fullRow)
		} else {
			children, existC := outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)]
			if !existC {
				children = make([]*analysis.MultiDimFullListRow, 0)
			}
			children = append(children, fullRow)
			outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)] = children
		}
	}

	CalcDistributionRatio(resp.Total)
	CalcDistributionRatio(resp.AllTotal)
	CalcDistributionRatio(resp.FullList...)
	for _, fullRow := range resp.FullList {
		if children, existC := outParentRowMap[fullRow.DimKey]; existC {
			CalcDistributionRatio(children...)
			fullRow.Children = children
		}
		if len(fullRow.Children) > 0 {
			for _, subFullRow := range fullRow.Children {
				if subChildren, existSubC := outParentRowMap[subFullRow.DimKey]; existSubC {
					CalcDistributionRatio(subChildren...)
					subFullRow.Children = subChildren
				}
			}
		}
	}
	// 添加prod_tag_code
	for _, row := range resp.FullList {
		if len(prodCodeTagBaseDims) > 0 {
			codeStruct := &dimensions.SelectedDimensionInfo{
				Id:               prodCodeTagBaseDims[0].Id,
				Name:             prodCodeTagBaseDims[0].Name,
				AttrType:         prodCodeTagBaseDims[0].AttrType,
				SelectedOperator: prodCodeTagBaseDims[0].SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{{Code: row.EnumValue, Name: row.DisplayName}},
				IsGroup:          false,
			}
			dims := []*dimensions.SelectedDimensionInfo{codeStruct}
			marshalString, err := sonic.MarshalString(dims)
			if err != nil {
				logs.CtxError(ctx, "序列化prod_tag_code失败,err:"+err.Error())
			}
			row.ProdTagCode = marshalString
			// 递归填充children的tagCode
			AddChildrenTagCode(ctx, prodCodeTagBaseDims, dims, 1, row.Children)
		}
	}
	// 整体的tag_code
	if resp.Total != nil {
		codeStruct := &dimensions.SelectedDimensionInfo{
			Id:             "-1",
			Name:           TotalEnumValue,
			SelectedValues: []*dimensions.EnumElement{{Code: TotalEnumValue, Name: TotalEnumValue}},
		}
		dims := []*dimensions.SelectedDimensionInfo{codeStruct}
		marshalString, err := sonic.MarshalString(dims)
		if err != nil {
			logs.CtxError(ctx, "序列化prod_tag_code失败,err:"+err.Error())
		}
		resp.Total.ProdTagCode = marshalString
	}

	return resp, nil
}

// AddChildrenTagCode 递归填充tagCode
func AddChildrenTagCode(ctx context.Context, prodCodeTagBaseDims, selectDims []*dimensions.SelectedDimensionInfo, floor int, resp []*analysis.MultiDimFullListRow) {
	if floor >= len(prodCodeTagBaseDims) || len(resp) == 0 {
		return
	}
	for _, row := range resp {
		codeStruct := &dimensions.SelectedDimensionInfo{
			Id:               prodCodeTagBaseDims[floor].Id,
			Name:             prodCodeTagBaseDims[floor].Name,
			AttrType:         prodCodeTagBaseDims[floor].AttrType,
			SelectedOperator: prodCodeTagBaseDims[floor].SelectedOperator,
			SelectedValues:   []*dimensions.EnumElement{{Code: row.EnumValue, Name: row.DisplayName}},
			IsGroup:          false,
		}
		// 防止递归遍历过程中添加多余的维度枚举
		if len(selectDims) > floor {
			selectDims = selectDims[:floor]
		}
		selectDims = append(selectDims, codeStruct)
		marshalString, err := sonic.MarshalString(selectDims)
		if err != nil {
			logs.CtxError(ctx, "序列化prod_tag_code失败,err:"+err.Error())
		}
		row.ProdTagCode = marshalString
		// 递归填充code
		AddChildrenTagCode(ctx, prodCodeTagBaseDims, selectDims, floor+1, row.Children)
	}
}

// GetProductAnalysisMultiDimTrend 获取趋势图
func (d *AnalysisService) GetProductAnalysisMultiDimTrend(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp []*analysis.GetProductAnalysisMultiDimTrendInfo, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	if len(req.BaseReq.GroupAttrs) == 0 {
		return nil, errors.New("获取多维分析参数失败")
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	// 获取分析的维度信息
	var groupCol string
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		if attr.NeedDrillDown && !req.IsTotal {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
			}
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
	}
	if len(groupCol) == 0 {
		logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
		return resp, errors.New("多维分析未传入多维配置")
	}

	groupCols := utils.If(req.IsTotal, []string{}, []string{groupCol})
	osReq := base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: groupCols,
	}

	_, _, trend, trendSuffix, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	if err != nil {
		return
	}
	apiPath := bizMetaInfo.TargetCardApiID
	trend["not_base_settings"] = consts.IsTrueString
	trendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: trend, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, KeyCols: groupCols, TrendCol: "date",
	})
	if err != nil {
		return nil, err
	}
	trendSuffixMap := make(map[string]map[string][]*analysis.TargetTrendPoint)
	if trendSuffix != nil {
		trendSuffix["not_base_settings"] = false
		trendSuffixMap, err = base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: trendSuffix, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, KeyCols: groupCols, TrendCol: "date",
		})
		if err != nil {
			return nil, err
		}
	}
	newTrendMap := base_struct_condition.MergeTargetTrendMap(trendMap, trendSuffixMap)

	trendList := make([]*analysis.GetProductAnalysisMultiDimTrendInfo, 0)
	for k, vMap := range newTrendMap {
		for targetName, trendInfo := range vMap {
			sort.Slice(trendInfo, func(i, j int) bool {
				return trendInfo[i].X < trendInfo[j].X
			})
			trendList = append(trendList, &analysis.GetProductAnalysisMultiDimTrendInfo{
				TargetList: trendInfo,
				TargetName: targetName,
				EnumValue:  utils.If(req.IsTotal, TotalEnumValue, k),
			})
		}
	}

	return trendList, nil
}

// CalcDistributionRatio 计算列表分布占比
func CalcDistributionRatio(listRow ...*analysis.MultiDimFullListRow) {
	sumMap := make(map[string]float64)
	for _, info := range listRow {
		if info == nil {
			continue
		}
		sort.Slice(info.TargetList, func(i, j int) bool {
			if info.TargetList[i] == nil || info.TargetList[j] == nil {
				return true
			}
			return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
		})

		for _, i := range info.TargetList {
			if i != nil && i.Extra != nil && i.Extra.DistributionFlag {
				sumMap[i.Name] += i.Value
			}
		}
	}

	for _, info := range listRow {
		if info == nil {
			continue
		}
		for _, i := range info.TargetList {
			if i != nil && i.Extra != nil {
				if i.Extra.DistributionFlag {
					if v, exist := sumMap[i.Name]; exist && v > 0 {
						i.Extra.DistributionValue = i.Value / sumMap[i.Name]
						continue
					}
				}
				i.Extra.DistributionValue = 0
			}
		}
	}
}

func (d *AnalysisService) GetProductAnalysisMultiDimUvTargets(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.MultiDimExtraTargetItem, err error) {
	resp = &analysis.MultiDimExtraTargetItem{ExtraTargetList: make([]*analysis.MultiDimExtraTargetListRow, 0)}
	if !JudgeContainUvTargetMeta(req.BaseReq) {
		logs.CtxWarn(ctx, "输入的请求体未包含UV指标，req:%v", litter.Sdump(req.BaseReq.TargetMetaList))
		return resp, nil
	}
	if len(req.BaseReq.GroupAttrs) == 0 {
		return nil, errors.New("获取多维分析参数失败")
	}
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取map失败，err=%v+", err)
		return nil, err
	}

	dimColMap, err := d.DimensionListDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取col map失败，err=%v+", err)
		return nil, err
	}

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.BaseReq.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
			}
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
	}
	if len(groupCol) == 0 {
		logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
		return resp, errors.New("多维分析未传入多维配置")
	}
	osReq := base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
	}
	curr, compare, trend, trendSuffix, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	curr["not_base_settings"] = consts.IsTrueString
	compare["not_base_settings"] = consts.IsTrueString
	if err != nil {
		return
	}
	apiPath := bizInfo.TargetCardUvApiID
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, KeyCols: []string{groupCol}, NeedDistribution: true,
	})
	if err != nil {
		return nil, err
	}
	compareTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: compare, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, KeyCols: []string{groupCol},
	})
	if err != nil {
		return nil, err
	}
	currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumn(currTargetList, compareTargetList, nil, nil)

	if req.NeedTrend {
		trend["is_trend"] = true
		if _, ok := trend["dimension"]; ok {
			splitList := strings.Split(trend["dimension"].(string), ",")
			if len(splitList) > 0 {
				trend["dimension_split"] = splitList[0]
			}
		}
		trend["not_base_settings"] = consts.IsTrueString
		trendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: trend, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, KeyCols: []string{groupCol}, TrendCol: "date",
		})
		if err != nil {
			return nil, err
		}
		trendSuffixMap := make(map[string]map[string][]*analysis.TargetTrendPoint)
		if trendSuffix != nil {
			trendSuffix["is_trend"] = true
			if _, ok := trendSuffix["dimension"]; ok {
				splitList := strings.Split(trendSuffix["dimension"].(string), ",")
				if len(splitList) > 0 {
					trendSuffix["dimension_split"] = splitList[0]
				}
			}
			trendSuffix["not_base_settings"] = false
			trendSuffixMap, err = base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: trendSuffix, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, KeyCols: []string{groupCol}, TrendCol: "date",
			})
			if err != nil {
				return nil, err
			}
		}
		currTargetList = base_struct_condition.AddTargetTrend(currTargetList, trendMap, trendSuffixMap)
	}
	resp = &analysis.MultiDimExtraTargetItem{ExtraTargetList: make([]*analysis.MultiDimExtraTargetListRow, 0)}
	for _, info := range currTargetList {
		if len(info.KeyColValues) > 0 {
			resp.ExtraTargetList = append(resp.ExtraTargetList, &analysis.MultiDimExtraTargetListRow{
				EnumValue:  convert.ToString(info.KeyColValues[0]),
				TargetList: info.TargetEntity,
			})
		}
	}

	sumMap := make(map[string]float64)
	for _, info := range resp.ExtraTargetList {
		sort.Slice(info.TargetList, func(i, j int) bool {
			return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
		})

		for _, i := range info.TargetList {
			if i.Extra.DistributionFlag {
				sumMap[i.Name] += i.Value
			}
		}
	}

	for _, info := range resp.ExtraTargetList {
		for _, i := range info.TargetList {
			if i.Extra.DistributionFlag {
				if v, exist := sumMap[i.Name]; exist && v > 0 {
					i.Extra.DistributionValue = i.Value / sumMap[i.Name]
					continue
				}
			}
			i.Extra.DistributionValue = 0
		}
	}
	return resp, nil
}
