package attribution_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/version_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/data_abtest_meta_rpc/kitex_gen/meta_rpc"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/mohae/deepcopy"
	"strconv"
	"strings"
)

type LibraItem struct {
	VersionName      string `json:"version_name"`
	VersionId        string `json:"version_id"`
	VersionStartTime string `json:"version_start_time"`
	VersionEndTime   string `json:"version_end_time"`
	ProdCnt          int64  `json:"prod_cnt"`
	ShowPv           int64  `json:"show_pv"`
	AvgUv            int64  `json:"avg_uv"`
}

type ProductItem struct {
	ProdId string   `json:"prod_id"`
	VidCnt int64    `json:"version_cnt"`
	ShowPv int64    `json:"show_pv"`
	AvgUv  int64    `json:"avg_uv"`
	Name   string   `json:"name"`
	Images []string `json:"images"`
}

func (d *AttributionService) GetAttributionABtestList(ctx context.Context, req *analysis.GetAttributionABtestListRequest) (resp *analysis.GetAttributionABtestListResponse, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	// 获取invoker的入参
	curr, err := base_struct_condition.GetAttributionStructConditionParam(ctx, base_struct_condition.AttributionOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
		PageInfo:   req.PageReq,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if req.GetProdId() != "" {
		curr["prod_filter_param"] = fmt.Sprintf("%s = %s", consts.ProductID, req.GetProdId())
	}
	curr["data_type"] = 1 // 第二行及以上数据
	orderBy := convert.ToString(curr["order_by"])
	curr["order_by"] = strings.Replace(orderBy, "prod_id", "flight_id", -1)
	if req.GetStartRangeStartDate() != "" {
		curr["start_range_start_date"] = req.StartRangeStartDate
	}
	if req.GetStartRangeEndDate() != "" {
		curr["start_range_end_date"] = req.StartRangeEndDate
	}
	if req.GetEndRangeStartDate() != "" {
		curr["end_range_start_date"] = req.EndRangeStartDate
	}
	if req.GetEndRangeEndDate() != "" {
		curr["end_range_end_date"] = req.EndRangeEndDate
	}

	overAllParams := map[string]interface{}{}
	if v, ok := deepcopy.Copy(curr).(map[string]interface{}); ok {
		overAllParams = v
	}
	overAllParams["data_type"] = 0
	// 前端组件的问题，每个页20个的话，全部行算一条，所以其它查19条，后续的查询offset向前偏移一位，因为第一页少查了一条。
	limit, offset := int32(0), int32(0)
	if req.PageReq.PageNum == 1 {
		limit = req.PageReq.PageSize - 1
		offset = req.PageReq.PageSize * (req.PageReq.PageNum - 1)
	} else {
		limit = req.PageReq.PageSize
		offset = req.PageReq.PageSize*(req.PageReq.PageNum-1) - 1
	}
	curr["limit"] = limit
	curr["offset"] = offset
	cc := co.NewConcurrent(ctx)
	oneLibraList, allLibraList := make([]*analysis.GetAttributionABtestInfo, 0), make([]*analysis.GetAttributionABtestInfo, 0)
	cc.GoV2(func() error {
		oneLibraList, err = libraList(ctx, req.BaseReq.BizType, curr, ApiPathProdLibraList, true)
		return err
	})
	cc.GoV2(func() error {
		allLibraList, err = libraList(ctx, req.BaseReq.BizType, overAllParams, ApiPathProdLibraList, false)
		return err
	})
	//oneLibraList, err := libraList(ctx, req.BaseReq.BizType, curr, ApiPathProdLibraList, true)
	//allLibraList, err := libraList(ctx, req.BaseReq.BizType, overAllParams, ApiPathProdLibraList, false)
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "GetAttributionABtestList err=%v", err)
		return nil, err
	}
	libraCount := int64(0)
	if len(allLibraList) > 0 {
		for _, target := range allLibraList[0].TargetList {
			if target.Name == "version_cnt" {
				libraCount = int64(target.Value) + 1 // +1是全部那一条
			}
		}
	}
	if req.PageReq.PageNum == 1 { // 第一页显示全部,后续不再显示全部
		allLibraList = append(allLibraList, oneLibraList...)
	} else {
		allLibraList = oneLibraList
	}
	// 不显示version_cnt
	for _, item := range allLibraList {
		item.TargetList = removeTargetCardEntity(item.TargetList, "version_cnt")
	}
	resp = analysis.NewGetAttributionABtestListResponse()
	resp.Data = &analysis.GetAttributionABtestList{
		ProductList: allLibraList,
		PageInfo: &base.PageResp{
			PageNum:  req.PageReq.PageNum,
			PageSize: req.PageReq.PageSize,
			Total:    libraCount,
		},
	}
	return resp, nil
}

func libraList(ctx context.Context, bizType dimensions.BizType, curr map[string]interface{}, apiID string, isLibraList bool) ([]*analysis.GetAttributionABtestInfo, error) {
	keyCols := []string{"flight_id_all", "flight_display_name_all", "flight_start_time_all", "flight_end_time_all"}
	if isLibraList {
		keyCols = []string{"flight_id", "flight_display_name", "flight_start_time", "flight_end_time"}
	}
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiID, BizType: bizType, NeedDistribution: false,
		KeyCols: keyCols, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
	})
	if err != nil {
		return nil, err
	}

	var libraList = make([]*analysis.GetAttributionABtestInfo, 0)
	if len(currTargetList) > 0 {
		for _, record := range currTargetList {
			if len(record.KeyColValues) < len(keyCols) {
				continue
			}
			resTargets := make([]*analysis.TargetCardEntity, 0)
			prodCnt := int64(0)
			for _, target := range record.TargetEntity {
				if target.Name == "prod_cnt" {
					prodCnt = int64(target.Value)
				} else {
					resTargets = append(resTargets, target)
				}
			}
			targetOrderMap := map[string]int{"show_pv": 1, "avg_uv": 2}
			SortTargetList(targetOrderMap, resTargets)
			libraList = append(libraList, &analysis.GetAttributionABtestInfo{
				VersionInfo: &basic_info.ABtestBasicInfo{
					VersionId:        convert.ToString(record.KeyColValues[0]),
					VersionName:      convert.ToString(record.KeyColValues[1]),
					VersionStartTime: convert.ToString(record.KeyColValues[2]),
					VersionEndTime:   convert.ToString(record.KeyColValues[3]),
				},
				Cnt:        prodCnt,
				TargetList: resTargets,
			})
		}
	}
	if isLibraList {
		PackVersionData(ctx, libraList)
	}
	return libraList, nil
}

func (d *AttributionService) GetAttributionABtestProdList(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) (resp *analysis.GetAttributionABtestListResponse, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	// 获取invoker的入参
	curr, err := base_struct_condition.GetAttributionStructConditionParam(ctx, base_struct_condition.AttributionOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
		PageInfo:   req.PageReq,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if req.GetVersionId() != "" {
		curr["version_filter_param"] = fmt.Sprintf("flight_id = %s", req.GetVersionId())
	}
	curr["data_type"] = 1 // 第二行及以上数据

	overAllParams := map[string]interface{}{}
	if v, ok := deepcopy.Copy(curr).(map[string]interface{}); ok {
		overAllParams = v
	}
	overAllParams["offset"] = 0
	overAllParams["data_type"] = 0
	orderByStr := convert.ToString(overAllParams["order_by"])
	if orderByStr != "" {
		overAllParams["order_by"] = strings.Replace(orderByStr, ",prod_id", "", -1)
	}
	// 前端组件的问题，每个页20个的话，全部行算一条，所以其它查19条，后续的查询offset向前偏移一位，因为第一页少查了一条。
	limit, offset := int32(0), int32(0)
	if req.PageReq.PageNum == 1 {
		limit = req.PageReq.PageSize - 1
		offset = req.PageReq.PageSize * (req.PageReq.PageNum - 1)
	} else {
		limit = req.PageReq.PageSize
		offset = req.PageReq.PageSize*(req.PageReq.PageNum-1) - 1
	}
	curr["limit"] = limit
	curr["offset"] = offset
	oneProdList, allProdList := make([]*analysis.GetAttributionABtestInfo, 0), make([]*analysis.GetAttributionABtestInfo, 0)
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		oneProdList, err = prodList(ctx, req.BaseReq.BizType, curr, ApiPathProdList, true)
		return err
	})
	cc.GoV2(func() error {
		allProdList, err = prodList(ctx, req.BaseReq.BizType, overAllParams, ApiPathProdList, false)
		return err
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "GetAttributionABtestProdList err=%v", err)
		return nil, err
	}
	//oneProdList, err := prodList(ctx, req.BaseReq.BizType, curr, ApiPathProdList, true)
	//allProdList, err := prodList(ctx, req.BaseReq.BizType, overAllParams, ApiPathProdList, false)
	prodCount := int64(0)
	if len(allProdList) > 0 {
		for _, target := range allProdList[0].TargetList {
			if target.Name == "prod_cnt" {
				prodCount = int64(target.Value) + 1 // +1是全部那一条
			}
		}
	}
	if req.PageReq.PageNum == 1 {
		allProdList = append(allProdList, oneProdList...)
	} else {
		allProdList = oneProdList
	}
	// 不显示prod_cnt
	for _, item := range allProdList {
		item.TargetList = removeTargetCardEntity(item.TargetList, "prod_cnt")
	}
	resp = analysis.NewGetAttributionABtestListResponse()
	resp.Data = &analysis.GetAttributionABtestList{
		ProductList: allProdList,
		PageInfo: &base.PageResp{
			PageNum:  req.PageReq.PageNum,
			PageSize: req.PageReq.PageSize,
			Total:    prodCount,
		},
	}
	return resp, nil
}

func prodList(ctx context.Context, bizType dimensions.BizType, curr map[string]interface{}, apiID string, isProdList bool) ([]*analysis.GetAttributionABtestInfo, error) {
	keyCols := []string{"prod_all", "prod_name_all"}
	if isProdList {
		keyCols = []string{"prod_id", "prod_name"}
	}
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiID, BizType: bizType, NeedDistribution: false,
		KeyCols: keyCols, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
	})
	if err != nil {
		return nil, err
	}

	var prodList = make([]*analysis.GetAttributionABtestInfo, 0)
	if len(currTargetList) > 0 {
		for _, record := range currTargetList {
			if len(record.KeyColValues) < len(keyCols) {
				continue
			}
			resTargets := make([]*analysis.TargetCardEntity, 0)
			VersionCount := int64(0)
			for _, target := range record.TargetEntity {
				if target.Name == "version_cnt" {
					VersionCount = int64(target.Value)
				} else {
					resTargets = append(resTargets, target)
				}
			}
			targetOrderMap := map[string]int{"show_pv": 1, "avg_uv": 2}
			SortTargetList(targetOrderMap, resTargets)
			prodList = append(prodList, &analysis.GetAttributionABtestInfo{
				ProductInfo: &basic_info.ProductBasicInfo{
					Id:   convert.ToString(record.KeyColValues[0]),
					Name: convert.ToString(record.KeyColValues[1]),
				},
				Cnt:        VersionCount,
				TargetList: resTargets,
			})
		}
	}
	return prodList, nil
}

// 去除某个指标
func removeTargetCardEntity(targets []*analysis.TargetCardEntity, removeTargetName string) []*analysis.TargetCardEntity {
	newTargets := make([]*analysis.TargetCardEntity, 0)
	for _, target := range targets {
		if target.Name != removeTargetName {
			newTargets = append(newTargets, target)
		}
	}
	return newTargets
}

func PackVersionData(ctx context.Context, libraList []*analysis.GetAttributionABtestInfo) {
	versionIds := make([]int64, 0)
	for _, libra := range libraList {
		versionId, err := strconv.ParseInt(libra.VersionInfo.GetVersionId(), 10, 64)
		if err != nil {
			logs.CtxError(ctx, "ParseInt VersionId err=%v", err)
			continue
		}
		versionIds = append(versionIds, versionId)
	}
	res := version_info.GetVersionInfo(ctx, versionIds)
	for _, libra := range libraList {
		versionId, err := strconv.ParseInt(libra.VersionInfo.GetVersionId(), 10, 64)
		if err != nil {
			logs.CtxError(ctx, "ParseInt VersionId err=%v", err)
			continue
		}
		if data, ok := res[versionId]; ok {
			switch data.Status {
			case meta_rpc.FlightStatus_EXPIRED:
				libra.VersionInfo.VersionStatus = "已过期"
			case meta_rpc.FlightStatus_PROCESSING:
				libra.VersionInfo.VersionStatus = "进行中"
			case meta_rpc.FlightStatus_READY:
				libra.VersionInfo.VersionStatus = "待调度"
			case meta_rpc.FlightStatus_TESTING:
				libra.VersionInfo.VersionStatus = "测试中"
			case meta_rpc.FlightStatus_SUSPEND:
				libra.VersionInfo.VersionStatus = "已暂停"
			case meta_rpc.FlightStatus_RELEASED:
				libra.VersionInfo.VersionStatus = "满足预期"
			case meta_rpc.FlightStatus_OTHER:
				libra.VersionInfo.VersionStatus = "其它"
			default:
				libra.VersionInfo.VersionStatus = "-"
			}
			switch data.GetFlightType() { // 实验类型转换
			case meta_rpc.FlightType_STRATEGY:
				libra.VersionInfo.VersionType = "服务端实验"
			case meta_rpc.FlightType_PRODUCT:
				libra.VersionInfo.VersionType = "普通客户端实验"
			case meta_rpc.FlightType_AD_USER:
				libra.VersionInfo.VersionType = "广告用户实验"
			case meta_rpc.FlightType_AD_ADVERTISER:
				libra.VersionInfo.VersionType = "广告主实验"
			case meta_rpc.FlightType_AD_PLAN:
				libra.VersionInfo.VersionType = "广告计划实验"
			case meta_rpc.FlightType_INTERLEAVING:
				libra.VersionInfo.VersionType = "搜索实验"
			case meta_rpc.FlightType_AB_CLIENT_SDK:
				libra.VersionInfo.VersionType = "AB客户端SDK实验"
			case meta_rpc.FlightType_SETTINGS_CLIENT_SDK:
				libra.VersionInfo.VersionType = "Settings SDK实验"
			case meta_rpc.FlightType_SETTINGS_LOCAL_AB:
				libra.VersionInfo.VersionType = "Settings本地分流实验"
			case meta_rpc.FlightType_REGRESSION:
				libra.VersionInfo.VersionType = "自动搜参实验"
			case meta_rpc.FlightType_SETTINGS_NORMAL_CLIENT:
				libra.VersionInfo.VersionType = "Settings普通客户端实验"
			case meta_rpc.FlightType_OTHER:
				libra.VersionInfo.VersionType = "其它"
			default:
				libra.VersionInfo.VersionType = "-"
			}
			libra.VersionInfo.VersionLink = "https://data.bytedance.net/libra/flight/" + libra.VersionInfo.GetVersionId() + "/edit"
		}
	}
}
