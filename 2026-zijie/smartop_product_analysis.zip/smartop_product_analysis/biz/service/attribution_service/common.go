package attribution_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

type IAttributionService interface {
	GetProductListTargetInfo(ctx context.Context, req *analysis.GetAttributionCommonPageRequest, needAttrInfo bool) (resp *analysis.GetAttributionCommonProdList, err error)
	GetTargetListByProductIDs(ctx context.Context, req *analysis.AttributionCommonBaseStruct, prodIDs []string, isProdPV bool) (resp map[string][]*analysis.TargetCardEntity, err error)
	GetAttributionCommonCoreOverview(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp []*analysis.TargetCardEntity, err error)
	GetGuessCoreOverview(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp []*analysis.TargetCardEntity, err error)
	GetAttributionCommonProdList(ctx context.Context, req *analysis.GetAttributionCommonPageRequest, needAttrInfo bool) (resp *analysis.GetAttributionCommonProdList, err error)
	GetAttributionMetaInfo(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionMetaInfoItem, err error)
	GetAttributionCoreTree(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionCoreTreeData, err error)
	GetAttributionABtestList(ctx context.Context, req *analysis.GetAttributionABtestListRequest) (resp *analysis.GetAttributionABtestListResponse, err error)
	GetAttributionABtestProdList(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) (resp *analysis.GetAttributionABtestListResponse, err error)
	GetAttributionABtestListDownload(ctx context.Context, req *analysis.GetAttributionABtestListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error)
	GetAttributionABtestProdListDownload(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error)
	GetAttributionTreeMetaList(ctx context.Context, req *analysis.GetAttributionTreeMetaListRequest) (resp []*analysis.GetAttributionTreeMetaData, err error)
	GetAttributionCommonProdListDownload(ctx context.Context, req *analysis.GetAttributionCommonPageRequest) (resp bool, err error)
	GetAttributionCommonCoreOverviewDownload(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp bool, err error)
	GetAttributionFlowChange(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionFlowChangeData, err error)
	GetAttributionProdPriceDistribution(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionProdPriceDistributionData, err error)
	GetProductDetail(ctx context.Context, req *analysis.GetProductDetailRequest) (resp *analysis.MultiDimProductInfo, err error)
	GetProductDetailBy360(ctx context.Context, req *analysis.GetProductDetailRequest) (resp *analysis.GetProductBriefInfoData, err error)
	GetAttributionAnalysisBizList(ctx context.Context, req *analysis.GetAttributionAnalysisBizListRequest) (resp *analysis.GetAttributionAnalysisBizListItem, err error)
	GetAttributionMultiDimAnalysis(ctx context.Context, req *analysis.GetAttributionMultiDimAnalysisRequest) (resp *analysis.GetAttributionMultiDimAnalysisItem, err error)
	GuessAllTreeDownload(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest, data *analysis.GetAttributionCommonCoreOverviewResponse) (err error)
	GetGreatBuyCoreTreeDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, resp *great_value_buy.GetGreatValueBuyAttributionCoreTreeResponse) (err error)
}

type AttributionService struct {
	DimensionListDao      dao.IDimensionListDao
	DimensionEnumDao      dao.IDimensionEnumDao
	AttributeDao          dao.IAttributeDao
	DimensionService      dimension_service.IDimensionService
	DimensionBizListDao   dao.IDimensionBizListDao
	AttributionTreeBizDao dao.IAttributionTreeBizDao
}

// oneService注册的sqlApiPath
const (
	GetProdListPVApiID       = "7409942640407348250"
	GetProdCntApiID          = "7410029932312544307"
	ApiPathTreeTargetCard    = "7409947868137636873"
	ApiPathContributeProdCnt = "7410313825347486747"
	ApiPathProdLibraList     = "7410610144985252914" // 命中实验情况
	ApiPathProdList          = "7412192798386029578"
	APiPathFlowChange        = "7411047754681549861"
	APiPathGuessFlowChange   = "7441558640718267429"

	// ApiPathGuessProdCnt 猜喜相关
	ApiPathGuessProdCnt = "7441039134900159539"

	ApiPathProdDetail = "7412522338949858355"
	ApiPathLeafAvg    = "7412569670940656666"
)

var TreeGroupAttrs = []int64{10112, 10006}

var TreeFilterAttrs = []int64{10035}

var FlowChangeGroupAttrMap = map[int64]int64{10112: 10113, 10006: 10007}

var FlowChangeFilterAttrs = []int64{10035}

func (d *AttributionService) GetAttributionMetaInfo(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionMetaInfoItem, err error) {
	object := &dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao), DimensionEnumDao: new(dao.DimensionEnumDao)}
	var idList = make([]int64, 0)
	idList = append(idList, TreeGroupAttrs...)
	idList = append(idList, TreeFilterAttrs...)
	idList = append(idList, FlowChangeFilterAttrs...)
	for key, value := range FlowChangeGroupAttrMap {
		idList = append(idList, key, value)
	}
	dimMap, err := object.GetDimensionMapByIDList(ctx, idList)
	if err != nil {
		return nil, err
	}
	resp = &analysis.GetAttributionMetaInfoItem{
		TreeMeta: &analysis.AttributionTreeMeta{
			GroupAttrs: make([]*dimensions.DimensionInfo, 0),
			Dimensions: make([]*dimensions.DimensionInfo, 0),
		},
		FlowChangeMeta: &analysis.FlowChangeMeta{
			GroupRelations: make([]*analysis.DimDepend, 0),
			Dimensions:     make([]*dimensions.DimensionInfo, 0),
		},
	}
	for _, attr := range TreeGroupAttrs {
		if dim, ok := dimMap[convert.ToString(attr)]; ok {
			resp.TreeMeta.GroupAttrs = append(resp.TreeMeta.GroupAttrs, dim)
		}
	}
	for _, attr := range TreeFilterAttrs {
		if dim, ok := dimMap[convert.ToString(attr)]; ok {
			resp.TreeMeta.Dimensions = append(resp.TreeMeta.Dimensions, dim)
		}
	}
	for _, attr := range FlowChangeFilterAttrs {
		if dim, ok := dimMap[convert.ToString(attr)]; ok {
			resp.FlowChangeMeta.Dimensions = append(resp.FlowChangeMeta.Dimensions, dim)
		}
	}
	for key, value := range FlowChangeGroupAttrMap {
		var mainDim, childDim *dimensions.DimensionInfo
		if dim, ok := dimMap[convert.ToString(key)]; ok {
			mainDim = dim
		}
		if dim, ok := dimMap[convert.ToString(value)]; ok {
			childDim = dim
		}
		if mainDim != nil && childDim != nil {
			resp.FlowChangeMeta.GroupRelations = append(resp.FlowChangeMeta.GroupRelations, &analysis.DimDepend{
				MainDim:  mainDim,
				ChildDim: childDim,
			})
		}
	}
	return resp, nil
}
