package attribution_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_review_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"context"
)

const (
	Title         = "诊断命题"
	Name          = "指标名称"
	BaseValue     = "分析周期值"
	CompareValue  = "对比周期值"
	Rate          = "增幅"
	SuggestAction = "建议动作"
	SuggestScript = "建议话术"
)

func (d *AttributionService) GuessAllTreeDownload(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest, resp *analysis.GetAttributionCommonCoreOverviewResponse) (err error) {
	if req == nil || resp == nil || resp.Data == nil {
		return nil
	}
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return err
	}
	if env.IsBoe() {
		email = "wumin.13@bytedance.com"
	}

	header := [][]string{{"分析周期", req.BaseReq.StartDate + "~" + req.BaseReq.EndDate}, {"对比周期", req.BaseReq.CompareStartDate + "~" + req.BaseReq.CompareEndDate}}
	targetList := []string{Title, Name, BaseValue, CompareValue, Rate, SuggestAction, SuggestScript}
	allRows := make([]map[string]interface{}, 0)
	for _, v := range resp.Data.TargetList {
		if v == nil {
			continue
		}
		row := make(map[string]interface{})
		row[Title] = v.Extra.AttributeType
		row[Name] = v.DisplayName
		row[BaseValue] = v.Value
		row[CompareValue] = v.ComparePeriodData.CompareValue
		row[Rate] = utils.If(v.ComparePeriodData.CompareChangeRatio == consts.MagicNumber, 0, v.ComparePeriodData.CompareChangeRatio)
		row[SuggestAction] = v.Extra.SuggestAction
		row[SuggestScript] = v.Extra.SuggestScript
		allRows = append(allRows, row)
	}

	err = product_review_service.DoExportData(ctx, "猜喜异动归因-命题诊断明细", email, header, targetList, allRows)
	return err
}
