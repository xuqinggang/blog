package attribution_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

func (d *AttributionService) GetAttributionAnalysisBizList(ctx context.Context, req *analysis.GetAttributionAnalysisBizListRequest) (resp *analysis.GetAttributionAnalysisBizListItem, err error) {
	var oriBizType dimensions.BizType
	var oriBizName string
	if req.ObjectBizType != nil {
		// 获取业务线信息
		bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, *req.ObjectBizType)
		if err != nil || bizInfo == nil {
			logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
			return nil, errors.WithMessage(err, "业务线未发现元信息")
		}
		oriBizType = req.GetObjectBizType()
		oriBizName = bizInfo.BizName
		bizType := biz_utils.GetAnalysisBizType(*req.ObjectBizType, bizInfo.DependBizID)
		req.ObjectBizType = &bizType
	}
	//else { // 没有bizType就返回全量元信息
	//	bizType := dimensions.BizType_AttributionCore
	//	req.ObjectBizType = &bizType
	//}
	// 获取业务线的维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionAllList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionAnalysisBizList]获取map失败，err=%v+", err)
		return nil, err
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	var dimIdList = make([]int64, 0)
	for id := range dimMap {
		dimIdList = append(dimIdList, id)
	}
	object := &dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao), DimensionEnumDao: new(dao.DimensionEnumDao)}
	dimMapIdl, err := object.GetDimensionMapByIDList(ctx, dimIdList)
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionAnalysisBizList]获取IDL版DimMap失败, err:%v", err.Error())
		return nil, err
	}
	ctx = context.WithValue(ctx, consts.CtxDimMapIDLType, dimMapIdl)

	bizInfoList, err := biz_utils.GetAttributionTreeBizInfo(ctx, req.ObjectBizType)
	if err != nil {
		return nil, err
	}
	var resBizInfoList = make([]*analysis.GetProductAnalysisBizInfo, 0)
	for _, bizInfo := range bizInfoList {
		if req.ObjectBizType == nil {
			oriBizType = bizInfo.ObjectBizType
			oriBizName = bizInfo.ObjectBizName
		}
		resBizInfoList = append(resBizInfoList, &analysis.GetProductAnalysisBizInfo{
			ObjectBizType:     oriBizType,
			BizName:           oriBizName,
			SupportBizModules: bizInfo.ReasonMeta,
			TreeMeta:          bizInfo.AttributionTreeMeta,
			FlowChangeMeta:    bizInfo.FlowChangeMeta,
		})
	}

	return &analysis.GetAttributionAnalysisBizListItem{BizList: resBizInfoList}, nil
}
