package attribution_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"sort"
)

// GetGuessCoreOverview 获取指标列表
func (d *AttributionService) GetGuessCoreOverview(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp []*analysis.TargetCardEntity, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	osReq := base_struct_condition.AttributionOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	}

	// 获取invoker的入参
	curr, compare, _, _, err := base_struct_condition.GetAttributionStructConditionParams(ctx, osReq)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	// 查询分析周期、对比周期数据
	var currTargetList, compareTargetList []*base_struct_condition.KeyColsTargetEntity
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		currTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, Sql: consts.Empty, ApiPath: bizInfo.MultiDimApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return err
		}
		return nil
	})

	cc.GoV2(func() error {
		compareTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compare, Sql: consts.Empty, ApiPath: bizInfo.MultiDimApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return err
		}
		return nil
	})

	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionCommonCoreOverview]并发对象wait失败, err:"+err.Error())
		return nil, err
	}

	currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumnV2(currTargetList, compareTargetList, nil, nil)
	if len(currTargetList) == 0 || len(currTargetList[0].TargetEntity) <= 0 {
		return resp, nil
	}

	// pp场景同样计算aa增幅
	initCompareChangeRatio(ctx, currTargetList)

	// 指标排序
	sortTargets(ctx, currTargetList)

	// 构建返回结构体
	resp = currTargetList[0].TargetEntity
	return resp, nil
}

func sortTargets(ctx context.Context, targets []*base_struct_condition.KeyColsTargetEntity) {
	if len(targets) == 0 {
		return
	}

	for _, target := range targets {
		if len(target.TargetEntity) == 0 {
			continue
		}

		entitys := target.TargetEntity
		sort.SliceStable(entitys, func(i, j int) bool {
			if entitys[i] == nil || entitys[j] == nil {
				return true
			}
			return entitys[i].DisplayOrder < entitys[j].DisplayOrder
		})
	}
}

func initCompareChangeRatio(ctx context.Context, list []*base_struct_condition.KeyColsTargetEntity) {
	for _, v := range list {
		if v == nil {
			continue
		}

		for _, target := range v.TargetEntity {
			if target == nil || target.ComparePeriodData == nil {
				continue
			}

			// 仅pp场景处理
			if !target.IsUsePp {
				continue
			}

			// 已经计算不处理
			if target.ComparePeriodData.CompareChangeRatio != 0 {
				continue
			}

			if target.ComparePeriodData.CompareValue == 0 {
				continue
			}

			target.ComparePeriodData.CompareChangeRatio = target.Value/target.ComparePeriodData.CompareValue - 1
		}
	}
}

func parseBizTypes(data *analysis.GetAttributionAnalysisBizListItem) []dimensions.BizType {
	bizTypes := make([]dimensions.BizType, 0)
	bizTypeMap := make(map[dimensions.BizType]interface{})
	if data == nil {
		return bizTypes
	}
	if len(data.BizList) <= 0 {
		return bizTypes
	}
	for _, biz := range data.BizList[0].SupportBizModules {
		if biz == nil || biz.BizType == nil {
			continue
		}
		bizTypeMap[*biz.BizType] = nil
		fillBizTypeMap(bizTypeMap, biz.Children)
	}

	for biz, _ := range bizTypeMap {
		bizTypes = append(bizTypes, biz)
	}
	return bizTypes
}

func fillBizTypeMap(typeMap map[dimensions.BizType]interface{}, children []*analysis.GetAttributionMetaInfo) {
	if typeMap == nil {
		return
	}
	for _, child := range children {
		if child == nil {
			continue
		}
		typeMap[child.BizType] = nil
	}
	return
}
