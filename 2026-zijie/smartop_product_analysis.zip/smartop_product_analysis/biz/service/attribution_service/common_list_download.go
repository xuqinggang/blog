package attribution_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"sort"
	"strconv"
	"strings"
)

func (d *AttributionService) GetAttributionCommonCoreOverviewDownload(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	docName := fmt.Sprintf("%s-%s", bizInfo.EffectModule, bizInfo.BizName)

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	coreRet, err := d.GetAttributionCommonCoreOverview(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	table, dateList, subTargetList := getTableAndDateList(coreRet)

	f.ExeQueryCustom([]param.Source{param.SourceConst(table)}, genGetAttributionCommonCoreOverviewTable, param.SinkTable("target_data"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetCompareStartDate(), req.BaseReq.GetCompareEndDate())),
		param.SourceConst(docName), param.SourceConst(dateList), param.SourceConst(subTargetList)}, doExportGetAttributionCommonCoreOverview, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func getTableAndDateList(targets []*analysis.TargetCardEntity) ([]map[string]interface{}, []string, []string) {
	table := make([]map[string]interface{}, 0)
	dateList := make([]string, 0)
	subTargetList := make([]string, 0)
	if len(targets) > 0 {
		for _, target := range targets {
			record := make(map[string]interface{})
			record["name"] = target.DisplayName
			record["value"] = target.Value
			record["compare_value"] = target.CycleValue
			record["diff"], record["diff_ratio"] = utils.GetDiffStr(target.DiffExtra)
			for _, meta := range SubTargetPrefixMeta {
				record[meta.prefix], record["compare_"+meta.prefix] = "-", "-"
			}
			if len(target.SubTargetList) > 0 {
				for _, sub := range target.SubTargetList {
					for _, meta := range SubTargetPrefixMeta {
						if strings.HasPrefix(sub.Name, meta.prefix) {
							record[meta.prefix] = sub.DisplayValue
							record["compare_"+meta.prefix] = sub.CycleDisplayValue
							subTargetList = append(subTargetList, meta.prefix)
						}
					}
				}
			}

			if len(target.TrendData) > 0 {
				for _, trend := range target.TrendData {
					record[trend.X] = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(trend.Value, 'f', 5, 64))
					dateList = append(dateList, trend.X)
				}
			}
			table = append(table, record)
		}
	}
	dateList = slices.DistinctString(dateList)
	sort.Strings(dateList)
	return table, dateList, subTargetList
}

func genGetAttributionCommonCoreOverviewTable(ctx context.Context, table []map[string]interface{}) (*onetable.Table, error) {
	return onetable.NewTable(table), nil
}

func doExportGetAttributionCommonCoreOverview(ctx context.Context, table *onetable.Table, email string, analysisRange, compareRange, docName string, dateList, subTargetList []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet("指标列表", table)
	sheet.AddHead([][]string{{"分析周期", analysisRange, "对比周期", compareRange}})

	sheet.AddColumn("指标", "name").
		AddColumn("分析周期值", "value").
		AddColumn("对比周期值", "compare_value").
		AddColumn("DIFF", "diff").
		AddColumn("幅度", "diff_ratio")
	if len(subTargetList) > 0 {
		for _, meta := range SubTargetPrefixMeta {
			if slices.ContainsString(subTargetList, meta.prefix) {
				sheet.AddColumn(fmt.Sprintf("%s-分析周期", meta.name), meta.prefix).AddColumn(fmt.Sprintf("%s-对比周期", meta.name), "compare_"+meta.prefix)
			}
		}
	}
	for _, d := range dateList {
		sheet.AddColumn(d, d)
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, fmt.Sprintf("异动归因-%s-指标列表", docName))
	return nil, formatter.Export(ctx, email, nil, nil)
}

func (d *AttributionService) GetAttributionCommonProdListDownload(ctx context.Context, req *analysis.GetAttributionCommonPageRequest) (resp bool, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "xiaoyuzhe@bytedance.com"
	}

	req.PageReq = &base.PageInfo{
		PageNum:  1,
		PageSize: 10000,
	}

	prodList, err := d.GetAttributionCommonProdList(ctx, req, false)
	if err != nil {
		logs.CtxError(ctx, "GetAttributionCommonProdListDownload GetAttributionCommonProdList err = %v+", err)
		return false, err
	}

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	docName := fmt.Sprintf("%s-%s", bizInfo.EffectModule, bizInfo.BizName)

	if prodList != nil && len(prodList.ProductList) > 0 {
		doc := document.NewEmptyDoc()
		app := application.NewApp(doc)
		f := flow.Empty()

		tableMap, targetMap, groupName := genCommonProdListTable(ctx, prodList.ProductList)
		f.ExeCustom([]param.Source{param.SourceConst(tableMap), param.SourceConst(email),
			param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetStartDate(), req.BaseReq.GetEndDate())),
			param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.GetCompareStartDate(), req.BaseReq.GetCompareEndDate())),
			param.SourceConst(docName),
			param.SourceConst(targetMap), param.SourceConst(groupName)}, doExportCommonProdList, nil)
		app.Use(f.ToStack(ctx))
		_, err = app.Run(ctx)
		if err != nil {
			logs.CtxError(ctx, err.Error())
			return false, err
		}
	}
	return true, nil
}

func genCommonProdListTable(ctx context.Context, prodList []*analysis.GetAttributionCommonProd) (map[string]*onetable.Table, map[string][]*analysis.TargetCardEntity, []string) {
	targetsMap := make(map[string][]*analysis.TargetCardEntity)
	tableMap := make(map[string]*onetable.Table)
	groupName := make([]string, 0)
	if len(prodList) > 0 {
		needGroup := len(prodList[0].TargetList) > 24 // 判断是否需要分组下载

		if needGroup {
			for _, t := range prodList[0].TargetList {
				tmp := targetsMap[t.Extra.AttributeType]
				if len(tmp) == 0 {
					tmp = make([]*analysis.TargetCardEntity, 0)
				}
				tmp = append(tmp, t)
				targetsMap[t.Extra.AttributeType] = tmp
				if !slices.ContainsString(groupName, t.Extra.AttributeType) {
					groupName = append(groupName, t.Extra.AttributeType)
				}
			}
		} else {
			targetsMap["商品明细"] = prodList[0].TargetList
			groupName = append(groupName, "商品明细")
		}

		for name, _ := range targetsMap {
			table := make([]map[string]interface{}, 0)
			for _, prodInfo := range prodList {
				record := make(map[string]interface{})
				if prodInfo.ProductInfo == nil {
					continue
				}

				shopName := "-"
				if prodInfo.ShopInfo != nil {
					shopName = prodInfo.ShopInfo.Name
				}
				record["prod_id"] = prodInfo.ProductInfo.Id
				record["prod_name"] = prodInfo.ProductInfo.Name
				record["shop_name"] = shopName
				record["first_level_cate_name"] = prodInfo.FirstLevelCateName
				record["second_level_cate_name"] = prodInfo.SecondLevelCateName
				record["leaf_cate_name"] = prodInfo.LeafCateName

				for _, t := range prodInfo.TargetList {
					if !needGroup || t.Extra.AttributeType == name {
						record[t.Name] = t.Value
					}
				}
				table = append(table, record)
			}
			tableMap[name] = onetable.NewTable(table)
		}

	}

	return tableMap, targetsMap, groupName
}

func doExportCommonProdList(ctx context.Context, tableMap map[string]*onetable.Table, email string, analysisRange, compareRange, docName string, targetsMap map[string][]*analysis.TargetCardEntity, groupName []string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	for _, name := range groupName {
		if table, exist := tableMap[name]; exist {
			sheet := lark_export.NewLarkDocSheet(name, table)
			sheet.AddHead([][]string{{"分析周期", analysisRange, "对比周期", compareRange}})
			sheet.AddColumn("商品ID", "prod_id").
				AddColumn("商品名称", "prod_name").
				AddColumn("所属商家", "shop_name").
				AddColumn("一级类目", "first_level_cate_name").
				AddColumn("二级类目", "second_level_cate_name").
				AddColumn("叶子类目", "leaf_cate_name")
			if targets, existT := targetsMap[name]; existT && len(targets) > 0 {
				for _, t := range targets {
					sheet.AddColumn(t.DisplayName, t.Name)
				}
			}
			formatter.AddSheet(sheet)
		}
	}
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, fmt.Sprintf("异动归因-%s-商品明细", docName))
	return nil, formatter.Export(ctx, email, nil, nil)
}
