package attribution_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"sort"
)

type ChangeProdCnt struct {
	Dimension   string  `json:"dimension"`
	RiseProdCnt float64 `json:"rise_prod_cnt"`
	DropProdCnt float64 `json:"drop_prod_cnt"`
}

type DimCardEntity struct {
	Card       *analysis.TargetCardEntity `json:"card"`
	Dimension  string                     `json:"dimension"`
	Dimension2 string                     `json:"dimension2"`
}

func (d *AttributionService) GetAttributionCoreTree(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionCoreTreeData, err error) {
	// 猜喜的归因树走定制逻辑
	if req.BizType == dimensions.BizType_AttributionCoreGuess {
		return getGuessAttributionTree(ctx, req)
	}
	// 归因树底表是大盘用增表，这里固定查这个biz_type
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, dimensions.BizType_GrowthProductStrategy)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	// 归因树需要下钻一个维度
	if len(req.GroupAttrs) == 0 {
		return nil, errors.New("归因树需要保证至少有一个下钻维度，请检查入参是否正确")
	}

	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}
	dimColMap, err := d.DimensionListDao.GetDimensionColMap(ctx, dimensions.BizType_GrowthProductStrategy)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取col map失败，err=%v+", err)
		return nil, err
	}
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.Dimensions = append(req.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
			}
			req.Dimensions = append(req.Dimensions, attr.DimInfo)
		}
	}
	if len(groupCol) == 0 {
		logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
		return resp, errors.New("多维分析未传入多维配置")
	}

	osReq := base_struct_condition.OsParamsReq{
		BaseStruct: &dimensions.ProductAnalysisBaseStruct{
			BizType:          dimensions.BizType_GrowthProductStrategy,
			StartDate:        req.StartDate,
			EndDate:          req.EndDate,
			CompareStartDate: req.CompareStartDate,
			CompareEndDate:   req.CompareEndDate,
			Dimensions:       req.Dimensions,
			GroupAttrs:       req.GroupAttrs,
		},
		DimMap: dimMap,
	}
	// 获取invoker的入参,第一层整体
	currWhole, compareWhole, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	// 添加多维分析参数
	osReq.DimColMap = dimColMap
	osReq.MultiDimension = []string{groupCol}
	// 获取invoker的入参,第二层多维分析
	curr, compare, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	// 获取完整时间周期的日期参数
	if osReq.BaseStruct.StartDate > osReq.BaseStruct.CompareStartDate {
		osReq.BaseStruct.StartDate = osReq.BaseStruct.CompareStartDate
	}
	if osReq.BaseStruct.EndDate < osReq.BaseStruct.CompareEndDate {
		osReq.BaseStruct.EndDate = osReq.BaseStruct.CompareEndDate
	}
	fullDate, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(dimensions.BizType_GrowthProductStrategy)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(currWhole, ApiPathTreeTargetCard, param.SinkTable("curr_target_card_whole")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(compareWhole, ApiPathTreeTargetCard, param.SinkTable("compare_target_card_whole")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(curr, ApiPathTreeTargetCard, param.SinkTable("curr_target_card")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(compare, ApiPathTreeTargetCard, param.SinkTable("compare_target_card")).SetParallel(true).SetMaxParallelNum(10)
	// 添加第三层的入参
	err = addSecondEntranceDimFilter(ctx, curr, req)
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionCoreTree]err:"+err.Error())
		return nil, err
	}
	// 添加第三层的入参
	err = addSecondEntranceDimFilter(ctx, compare, req)
	if err != nil {
		return nil, err
	}
	f.ExeQueryInvokerRaw(curr, ApiPathTreeTargetCard, param.SinkTable("second_curr_target_card")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(compare, ApiPathTreeTargetCard, param.SinkTable("second_compare_target_card")).SetParallel(true).SetMaxParallelNum(10)
	// 计算提升幅度时用完整周期
	curr["date_expr"] = fullDate["date_expr"]
	currWhole["date_expr"] = fullDate["date_expr"]
	f.ExeQueryInvokerRaw(currWhole, ApiPathContributeProdCnt, param.SinkTable("contribute_prod_cnt_whole")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(curr, ApiPathContributeProdCnt, param.SinkTable("contribute_prod_cnt")).SetParallel(true).SetMaxParallelNum(10)
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("curr_target_card_whole"), param.SinkTable("curr_target_card_whole")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("compare_target_card_whole"), param.SinkTable("compare_target_card_whole")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("curr_target_card"), param.SinkTable("curr_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"dimension"}))
	f.ExeProduceSql(`select * from curr_target_card union all select 'zjr_mock' as dimension, '' as target_name, 0 as target_value`, param.SinkTable("curr_target_card"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("compare_target_card"), param.SinkTable("compare_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"dimension"}))
	f.ExeProduceSql(`select * from compare_target_card union all select 'zjr_mock_compare' as dimension, '' as target_name, 0 as target_value`, param.SinkTable("compare_target_card"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("second_curr_target_card"), param.SinkTable("second_curr_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"dimension", "dimension2"}))
	f.ExeProduceSql(`select * from second_curr_target_card union all select 'zjr_mock' as dimension, 'zjr_mock' as dimension2, '' as target_name, 0 as target_value`, param.SinkTable("second_curr_target_card"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("second_compare_target_card"), param.SinkTable("second_compare_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"dimension", "dimension2"}))
	f.ExeProduceSql(`select * from second_compare_target_card union all select 'zjr_mock_compare' as dimension, 'zjr_mock_compare' as dimension2, '' as target_name, 0 as target_value`, param.SinkTable("second_compare_target_card"))
	// 第一层指标卡(整体)
	addTargetFlow(f, "curr_target_card_whole", "compare_target_card_whole", "first_level", "target_meta", []string{})
	// 第二层指标卡(一级入口 or 一级坑位)
	addTargetFlow(f, "curr_target_card", "compare_target_card", "second_level", "target_meta", []string{"dimension"})
	addTargetFlow(f, "second_curr_target_card", "second_compare_target_card", "third_level", "target_meta", []string{"dimension", "dimension2"})
	f.ExeProduceSql(`
		SELECT  dimension,
				dimension2,
				(
					SELECT  name,
							value,
							display_value,
							cycle_value,
							cycle_display_value,
							cycle_change_ratio,
							display_name,
							tips,
							extra,
							display_order,
							diff_extra
				) AS card
		FROM    third_level`, param.SinkTable("third_level"))
	var firstCards = make([]*analysis.TargetCardEntity, 0)
	var secondCards = make([]*analysis.TargetCardEntity, 0)
	var thirdCards = make([]*DimCardEntity, 0)
	var changeValues = make([]*ChangeProdCnt, 0)
	var changeValuesWhole = make([]*ChangeProdCnt, 0)
	f.ExeView(param.SourceTable("first_level"), &firstCards)
	f.ExeView(param.SourceTable("second_level"), &secondCards)
	f.ExeView(param.SourceTable("third_level"), &thirdCards)
	f.ExeView(param.SourceTable("contribute_prod_cnt"), &changeValues)
	f.ExeView(param.SourceTable("contribute_prod_cnt_whole"), &changeValuesWhole)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	resp = PackTreeRes(firstCards, secondCards, thirdCards, changeValuesWhole, changeValues, req.BizType)
	SortResp(resp)
	return resp, nil
}

func getGuessAttributionTree(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionCoreTreeData, err error) {
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	// 归因树需要下钻一个维度
	if len(req.GroupAttrs) == 0 {
		return nil, errors.New("归因树需要保证至少有一个下钻维度，请检查入参是否正确")
	}
	// 猜喜第二层不下钻，把多维分析的维度拼接到where条件即可
	for _, attr := range req.GroupAttrs {
		req.Dimensions = append(req.Dimensions, attr.DimInfo)
	}
	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	//osReq := base_struct_condition.OsParamsReq{
	//	BaseStruct: &dimensions.ProductAnalysisBaseStruct{
	//		BizType:          req.BizType,
	//		StartDate:        req.StartDate,
	//		EndDate:          req.EndDate,
	//		CompareStartDate: req.CompareStartDate,
	//		CompareEndDate:   req.CompareEndDate,
	//		Dimensions:       req.Dimensions,
	//	},
	//	DimMap: dimMap,
	//}
	// 获取invoker的入参,第一层整体
	//currWhole, compareWhole, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	//if err != nil {
	//	logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
	//	return
	//}
	curr, compare, _, _, err := base_struct_condition.GetAttributionStructConditionParams(ctx, base_struct_condition.AttributionOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	})
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	//f.ExeQueryCustom([]param.Source{param.SourceConst(int64(dimensions.BizType_GrowthProductStrategy)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(*req.ObjectBizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta_guess"))
	// 请求invoker，获取数据
	//f.ExeQueryInvokerRaw(currWhole, ApiPathTreeTargetCard, param.SinkTable("curr_target_card_whole")).SetParallel(true).SetMaxParallelNum(10)
	//f.ExeQueryInvokerRaw(compareWhole, ApiPathTreeTargetCard, param.SinkTable("compare_target_card_whole")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(curr, ApiPathGuessProdCnt, param.SinkTable("curr_target_card")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(compare, ApiPathGuessProdCnt, param.SinkTable("compare_target_card")).SetParallel(true).SetMaxParallelNum(10)
	// 指标值行转列
	//f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("curr_target_card_whole"), param.SinkTable("curr_target_card_whole")).
	//	SetValueColumn("target_value").
	//	SetTargetNameColumn("target_name"))
	//f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("compare_target_card_whole"), param.SinkTable("compare_target_card_whole")).
	//	SetValueColumn("target_value").
	//	SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("curr_target_card"), param.SinkTable("curr_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("compare_target_card"), param.SinkTable("compare_target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	// 第一层指标卡(整体)
	//addTargetFlow(f, "curr_target_card_whole", "compare_target_card_whole", "first_level", "target_meta", []string{})
	// 第二层指标卡(猜喜整体)
	addTargetFlow(f, "curr_target_card", "compare_target_card", "first_level", "target_meta_guess", []string{})
	var firstCards = make([]*analysis.TargetCardEntity, 0)
	//var secondCards = make([]*analysis.TargetCardEntity, 0)
	f.ExeView(param.SourceTable("first_level"), &firstCards)
	//f.ExeView(param.SourceTable("second_level"), &secondCards)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	resp = &analysis.GetAttributionCoreTreeData{
		Name:       "猜喜整体",
		TargetList: firstCards,
		Children:   make([]*analysis.GetAttributionCoreTreeData, 0),
		Code:       "猜喜整体",
	}
	//resp = PackTreeRes(firstCards, nil, nil, nil, nil, req.BizType)
	//SortResp(resp)
	sort.Slice(resp.TargetList, func(i, j int) bool {
		return resp.TargetList[i].DisplayOrder < resp.TargetList[j].DisplayOrder
	})
	return resp, nil
}

func addSecondEntranceDimFilter(ctx context.Context, params map[string]interface{}, req *analysis.AttributionCommonBaseStruct) error {
	if len(req.GroupAttrs) > 0 && req.GroupAttrs[0].DimInfo != nil {
		id := convert.ToInt64(req.GroupAttrs[0].DimInfo.Id)
		if id2, ok := FlowChangeGroupAttrMap[id]; ok {
			dimC, err := (&dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao)}).GetDimColumnExpressStr(ctx, id2)
			if err != nil {
				return err
			}
			params["dimension2"] = dimC
			return nil
		}
	}
	return errors.New("未匹配到第二维度")
}

func addTargetFlow(f flow.Flow, currTableName, cycleTableName, resTableName, targetMetaTableName string, dimColumnNames []string) {
	var dims, joinExpress string
	tempTableName := fmt.Sprintf("target_value_%v", resTableName)
	for _, dim := range dimColumnNames {
		dims += fmt.Sprintf("a.%v as %v, ", dim, dim)
		joinExpress += fmt.Sprintf(" and a.%v = b.%v ", dim, dim)
	}
	f.ExeProduceSql(fmt.Sprintf(`
		select 
			%v
			a.target_name as name,
			a.target_value as value,
			b.target_value as cycle_value,
			(a.target_value-b.target_value) / b.target_value as cycle_change_ratio,
			a.target_value-b.target_value as cycle_change_pp
		from %v a 
		left join %v b
		on a.target_name = b.target_name %v
	`, dims, currTableName, cycleTableName, joinExpress), param.SinkTable(tempTableName))

	var groupSubSql string
	// 加工多维分析子sql
	if len(dimColumnNames) > 0 {
		groupSubSql = fmt.Sprintf(`(select a.%v as name, a.%v as display_name) as group_info,`, dimColumnNames[len(dimColumnNames)-1], dimColumnNames[len(dimColumnNames)-1])
	}

	var percentSubSql string
	if len(dimColumnNames) == 0 {
		percentSubSql = `, case when b.is_compute_percent = true then 1 else 0 end as market_percent`
	} else if len(dimColumnNames) == 1 {
		percentSubSql = `, case when b.is_compute_percent = true then a.value/(select value from first_level c where c.name = a.name) else 0 end as market_percent`
	}
	// 前端暂时不需要二级入口这一层的占比
	//else if len(dimColumnNames) == 2 {
	//	percentSubSql = `, case when b.is_compute_percent = true then a.value/(select value from second_level c where c.name = a.name and c.dimension = a.dimension) else 0 end as market_percent`
	//}

	f.ExeProduceSql(fmt.Sprintf(`
		select
				%v
				b.name as name,
				a.value as value,
				get_display_value(a.value, b.value_type, b.value_unit,b.target_precision) as display_value,
				a.cycle_value as cycle_value,	
				get_display_value(a.cycle_value, b.value_type, b.value_unit,b.target_precision) as cycle_display_value,
				case 
					when b.is_use_pp = true then a.cycle_change_pp 
					else a.cycle_change_ratio 
				end as cycle_change_ratio,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				(
					select 						
						b.is_compute_percent as percent_flag,
						b.is_larger_advantage as is_larger_advantage,
						b.is_distribution as distribution_flag,
						b.is_compute_percent as percent_flag
						%v
				) as extra,
				b.display_order as display_order,
				b.is_use_pp as is_use_pp,
				%v
				(
					select
						a.cycle_change_pp as diff,
						get_display_value(a.cycle_change_pp, b.value_type, b.value_unit,b.target_precision) as display_value
				) as diff_extra
		from    %v b
		inner join
				%v a
		on      a.name = b.name
		order by b.display_order asc
	`, dims, percentSubSql, groupSubSql, targetMetaTableName, tempTableName), param.SinkTable(resTableName)).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
}

func PackTreeRes(firstCards, secondCards []*analysis.TargetCardEntity, thirdCards []*DimCardEntity, changeValuesWhole, changeValues []*ChangeProdCnt, bizType dimensions.BizType) *analysis.GetAttributionCoreTreeData {
	var dimCardsMap = make(map[string][]*analysis.TargetCardEntity)
	var ThirdCardsMap = make(map[string]map[string][]*analysis.TargetCardEntity)
	var changeValueMap = make(map[string]*ChangeProdCnt)

	for _, card := range secondCards {
		if card != nil {
			if card.GroupInfo == nil {
				if bizType == dimensions.BizType_AttributionCoreGuess {
					card.GroupInfo = &analysis.TargetCardGroupInfo{Name: "猜喜"}
				} else {
					card.GroupInfo = &analysis.TargetCardGroupInfo{Name: ""}
				}
			}
			if _, ok := dimCardsMap[card.GroupInfo.Name]; ok {
				dimCardsMap[card.GroupInfo.Name] = append(dimCardsMap[card.GroupInfo.Name], card)
			} else {
				dimCardsMap[card.GroupInfo.Name] = []*analysis.TargetCardEntity{card}
			}
		}
	}
	for _, card := range thirdCards {
		if card != nil {
			if _, ok := ThirdCardsMap[card.Dimension]; ok {
				if _, ok2 := ThirdCardsMap[card.Dimension][card.Dimension2]; ok2 {
					ThirdCardsMap[card.Dimension][card.Dimension2] = append(ThirdCardsMap[card.Dimension][card.Dimension2], card.Card)
				} else {
					ThirdCardsMap[card.Dimension][card.Dimension2] = []*analysis.TargetCardEntity{card.Card}
				}
			} else {
				ThirdCardsMap[card.Dimension] = map[string][]*analysis.TargetCardEntity{card.Dimension2: {card.Card}}
			}
		}
	}

	for _, value := range changeValues {
		changeValueMap[value.Dimension] = value
	}

	resp := &analysis.GetAttributionCoreTreeData{
		Name:       "整体",
		TargetList: firstCards,
		Children:   make([]*analysis.GetAttributionCoreTreeData, 0),
		Code:       "整体",
	}
	if len(firstCards) > 0 && len(changeValuesWhole) > 0 {
		if firstCards[0].Value > firstCards[0].CycleValue {
			resp.ContributeProdCnt = int64(changeValuesWhole[0].RiseProdCnt)
		} else {
			resp.ContributeProdCnt = int64(changeValuesWhole[0].DropProdCnt)
		}
	}
	for enum, cards := range dimCardsMap {
		if len(cards) > 0 {
			var treeData = &analysis.GetAttributionCoreTreeData{
				Name:       enum,
				TargetList: cards,
				Code:       enum,
			}
			if _, ok := ThirdCardsMap[enum]; ok {
				treeData.Children = make([]*analysis.GetAttributionCoreTreeData, 0)
				for dim2Value, entities := range ThirdCardsMap[enum] {
					treeData.Children = append(treeData.Children, &analysis.GetAttributionCoreTreeData{
						Name:       dim2Value,
						TargetList: entities,
						Code:       dim2Value,
					})
				}
			}

			if changeValue, ok := changeValueMap[enum]; ok {
				if cards[0].Value > cards[0].CycleValue {
					treeData.ContributeProdCnt = int64(changeValue.RiseProdCnt)
				} else {
					treeData.ContributeProdCnt = int64(changeValue.DropProdCnt)
				}
			}
			resp.Children = append(resp.Children, treeData)
		}
	}
	return resp
}

func SortResp(resp *analysis.GetAttributionCoreTreeData) {
	// 卡片指标排序
	targetOrderMap := map[string]int{"show_pv": 1, "pay_gmv": 2, "pay_ord_cnt": 3, "opm": 4, "gpm": 5}
	if resp != nil {
		SortTargetList(targetOrderMap, resp.TargetList)
		for _, child := range resp.Children {
			if child != nil {
				SortTargetList(targetOrderMap, child.TargetList)
				for _, secondChild := range child.Children {
					if secondChild != nil {
						SortTargetList(targetOrderMap, secondChild.TargetList)
					}
				}
			}
		}
	}
	// 第二层卡片根据PV排序
	if resp != nil && len(resp.Children) > 0 {
		sort.Slice(resp.Children, func(i, j int) bool {
			if len(resp.Children[i].TargetList) > 0 && len(resp.Children[j].TargetList) > 0 {
				return resp.Children[i].TargetList[0].Value > resp.Children[j].TargetList[0].Value
			} else {
				return false
			}
		})
		//if len(resp.Children) > 5 {
		//	resp.Children = resp.Children[:5]
		//}
	}
}

func SortTargetList(targetOrderMap map[string]int, targetList []*analysis.TargetCardEntity) {
	sort.Slice(targetList, func(i, j int) bool {
		// 获取每个元素的排序权重，使用order映射
		// 如果元素不在order中，给一个默认高值保证它排在最后
		rankI, okI := targetOrderMap[targetList[i].Name]
		if !okI {
			rankI = len(targetOrderMap) + 1
		}
		rankJ, okJ := targetOrderMap[targetList[j].Name]
		if !okJ {
			rankJ = len(targetOrderMap) + 1
		}
		return rankI < rankJ
	})
}

func JoinCurrCompareTable(ctx context.Context, groupTable *onetable.Table, dimensionId, dimColumnName string) (*onetable.Table, error) {
	return nil, nil
}
