package attribution_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

func (d *AttributionService) GetAttributionABtestListDownload(ctx context.Context, req *analysis.GetAttributionABtestListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return resp, err
	}
	if env.IsBoe() {
		email = "zhangruiwen.raven@bytedance.com"
	}
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()

	f.ExeQueryCustom([]param.Source{param.SourceConst(req)}, d.getAttributionABtestList, param.SinkTable("res_data"))
	f.ExeCustom([]param.Source{param.SourceTable("res_data"), param.SourceConst(email)}, doExportLibraList, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.Data = true
	return resp, nil
}

func (d *AttributionService) getAttributionABtestList(ctx context.Context, req *analysis.GetAttributionABtestListRequest) ([]*LibraItem, error) {
	resp, err := d.GetAttributionABtestList(ctx, req)
	if err != nil {
		return nil, err
	}
	libraItems := make([]*LibraItem, 0)
	for _, item := range resp.Data.ProductList {
		temp := &LibraItem{
			VersionName:      item.VersionInfo.VersionName,
			VersionId:        item.VersionInfo.VersionId,
			VersionStartTime: item.VersionInfo.VersionStartTime,
			VersionEndTime:   item.VersionInfo.VersionEndTime,
			ProdCnt:          item.Cnt,
		}
		for _, target := range item.TargetList {
			switch target.Name {
			case "avg_uv":
				temp.AvgUv = int64(target.Value)
			case "show_pv":
				temp.ShowPv = int64(target.Value)
			default:
				continue
			}
		}
		libraItems = append(libraItems, temp)
	}
	return libraItems, nil
}

func (d *AttributionService) GetAttributionABtestProdListDownload(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	if env.IsBoe() {
		email = "zhangruiwen.raven@bytedance.com"
	}
	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryCustom([]param.Source{param.SourceConst(req)}, d.getAttributionABtestProdList, param.SinkTable("res_data"))
	f.ExeCustom([]param.Source{param.SourceTable("res_data"), param.SourceConst(email)}, doExportProdList, nil)
	resData := make([]*ProductItem, 0)
	f.ExeView(param.SourceTable("res_data"), &resData)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.Data = true
	return resp, nil
}

func (d *AttributionService) getAttributionABtestProdList(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) ([]*ProductItem, error) {
	resp, err := d.GetAttributionABtestProdList(ctx, req)
	if err != nil {
		return nil, err
	}
	prodItems := make([]*ProductItem, 0)
	for _, item := range resp.Data.ProductList {
		temp := &ProductItem{
			Name:   item.ProductInfo.Name,
			ProdId: item.ProductInfo.Id,
			VidCnt: item.Cnt,
		}
		for _, target := range item.TargetList {
			switch target.Name {
			case "show_pv":
				temp.ShowPv = int64(target.Value)
			case "avg_uv":
				temp.AvgUv = int64(target.Value)
			default:
				continue
			}
		}
		prodItems = append(prodItems, temp)
	}
	return prodItems, nil
}

// doExportLibraList 实验列表导出
func doExportLibraList(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("实验列表", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("实验名称", "version_name").
		AddColumn("实验ID", "version_id").
		AddColumn("关联商品数", "prod_cnt").
		AddColumn("关联PV", "show_pv").
		AddColumn("关联日均UV(汇总)", "avg_uv").
		AddColumn("开始时间", "version_start_time").
		AddColumn("结束时间", "version_end_time")

	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}

// doExportProdList 商品列表导出
func doExportProdList(ctx context.Context, table *onetable.Table, email string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("商品关联实验明细", table)
	// 这边直接用oneService的返回值进行导出，修改字段名时需要注意os api里面有该字段。
	sheet1.AddColumn("商品名称", "name").
		AddColumn("关联实验数", "version_cnt").
		AddColumn("实验关联PV", "show_pv").
		AddColumn("实验关联日均UV(汇总)", "avg_uv")

	formatter.AddSheet(sheet1)
	return nil, formatter.Export(ctx, email, nil, nil)
}
