package attribution_service

import (
	copier "code.byted.org/ecom/compass_strategy_toolbox/util/copy"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/ecom_product_search"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/overpass/ecom_smartop_industry/kitex_gen/ecom/smartop/industry"
	"context"
	"github.com/bytedance/sonic"
	"sort"
	"strconv"
)

func (d *AttributionService) GetProductDetail(ctx context.Context, req *analysis.GetProductDetailRequest) (resp *analysis.MultiDimProductInfo, err error) {
	var params = make(map[string]interface{})
	newest, err := utils.GetNewestDay(ctx, consts.LogicTableUserGrowth, consts.LogicTableBillion)
	if err != nil {
		return nil, err
	}
	params["date"] = newest
	params["prod_id"] = req.ProdId
	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(dimensions.BizType_GrowthProductStrategy)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryInvokerRaw(params, ApiPathProdDetail, param.SinkTable("product_detail"))
	f.ExeQueryInvokerRaw(params, ApiPathLeafAvg, param.SinkTable("leaf_avg")).AddParam("leaf_cate_id", param.SourceSqlWithType("select `leaf_cate_id` from `product_detail`", []interface{}{}))
	f.ExeProduceCustom([]param.Source{param.SourceTable("product_detail")}, analysis_service.AddProductImage, param.SinkTable("product_images"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("leaf_avg"), param.SinkTable("leaf_avg")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("product_detail"), param.SinkTable("target_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"prod_id"}))
	f.ExeProduceSql(`
		select  prod_id,
				a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
				concat('近7日', b.display_name) as display_name,
				b.tips as tips,
				b.display_order as display_order,
				(select c.target_value as leaf_avg_value,
					case when a.target_name in ('opm','gpm') then true else false end as leaf_compare_flag,
					case when a.target_value > c.target_value then true else false end as is_better_than_leaf
				) as extra
		from    target_data a
		inner   join
				target_meta b
		on      a.target_name=b.name
		left join
				leaf_avg c
		on a.target_name = c.target_name
		order by b.display_order asc
		`, param.SinkTable("target_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeProduceSql(`
		select  a.prod_id as prod_id,
				a.prod_name as prod_name,
				b.images as prod_images,
				b.main_image as main_image,
				shop_id,
				shop_name,
				brand_id,
				brand_name,
				complex_brand_s_level as brand_level,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name,
				prod_status as online_status,
				saleable_status as sell_status,
				price_range,
				product_price_belt,
				(select * from target_data where target_data.prod_id = product_detail.prod_id) as target_list
		from    product_detail a
		left join
				product_images b
		on      a.prod_id = b.prod_id
	`, param.SinkTable("res_data"))
	var productInfoList = make([]*analysis_service.ProductInfo, 0)
	f.ExeView(param.SourceTable("res_data"), &productInfoList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return PackProdDetail(productInfoList), nil
}

func PackProdDetail(productInfoList []*analysis_service.ProductInfo) *analysis.MultiDimProductInfo {
	if len(productInfoList) == 0 {
		return nil
	}
	for _, info := range productInfoList {
		if info != nil {
			sort.Slice(info.TargetList, func(i, j int) bool {
				return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
			})
		}
	}
	return &analysis.MultiDimProductInfo{
		ProductInfo:         &basic_info.ProductBasicInfo{Id: productInfoList[0].ProdId, Name: productInfoList[0].ProdName, Images: productInfoList[0].ProdImages, MainImage: productInfoList[0].MainImage},
		ShopInfo:            &basic_info.ShopBasicInfo{Id: productInfoList[0].ShopId, Name: productInfoList[0].ShopName},
		BrandInfo:           &basic_info.BrandBasicInfo{Id: productInfoList[0].BrandId, Name: productInfoList[0].BrandName, Level: productInfoList[0].BrandLevel},
		OnlineStatus:        productInfoList[0].OnlineStatus,
		SellStatus:          productInfoList[0].SellStatus,
		PriceRange:          productInfoList[0].PriceRange,
		ProductPriceBelt:    productInfoList[0].ProductPriceBelt,
		FirstLevelCateName:  productInfoList[0].FirstLevelCateName,
		SecondLevelCateName: productInfoList[0].SecondLevelCateName,
		LeafCateName:        productInfoList[0].LeafCateName,
		TargetList:          productInfoList[0].TargetList,
	}
}

func (d *AttributionService) GetProductDetailBy360(ctx context.Context, req *analysis.GetProductDetailRequest) (resp *analysis.GetProductBriefInfoData, err error) {
	resp = &analysis.GetProductBriefInfoData{
		Brief: make(map[string]*analysis.BasicFormatItem),
	}
	var brief *industry.GetProductBriefInfoData
	brief, err = ecom_product_search.GetProductBrief(ctx, req.ProdId)
	if err != nil {
		return nil, err
	}
	if brief == nil {
		// 兜底，保证商品全景搜不到的商品，我们这里不会报错
		parseInt, err := strconv.ParseInt(req.ProdId, 10, 64)
		if err != nil {
			logs.CtxWarn(ctx, "[GetProductDetailBy360]输入的prodId不是数字，请检查输入是否正确，prodId = %v", req.ProdId)
			return resp, nil
		}
		list, err := biz_utils.GetProductInfoByIdList(ctx, []int64{parseInt})
		if err != nil {
			logs.CtxWarn(ctx, "[GetProductDetailBy360]调用商品全景获取商品详情后，兜底失败，err: %v", err.Error())
			return resp, nil
		}
		if len(list) == 0 || list[0] == nil {
			logs.CtxWarn(ctx, "[GetProductDetailBy360]调用商品全景获取商品详情后，兜底失败，查询不到该商品，prodId = %v", req.ProdId)
			return resp, nil
		}
		imgListMarshal, err := sonic.MarshalString(list[0].Images)
		if err != nil {
			logs.CtxWarn(ctx, "[GetProductDetailBy360]图片列表序列化失败，err: %v", err.Error())
		}
		brief = &industry.GetProductBriefInfoData{
			Brief: map[string]*industry.BasicFormatItem{
				"product_img_list": {
					DataType: "img_list",
					Name:     "商品图片列表",
					Value:    &imgListMarshal,
				},
				"product_id": {
					DataType: "raw",
					Name:     "商品ID",
					Value:    &list[0].Id,
				},
				"product_name": {
					DataType: "raw",
					Name:     "商品名称",
					Value:    &list[0].Name,
				},
			},
		}
		//return nil, errors.New("[GetProductDetailBy360]根据prod_id调用商品全景搜索商品信息，返回值为nil")
	}
	for key, value := range brief.Brief {
		var item = &analysis.BasicFormatItem{}
		err = copier.Copy(item, value)
		if err != nil {
			return nil, err
		}
		resp.Brief[key] = item
	}
	//err = copier.Copy(resp.Brief, brief.Brief)
	//if err != nil {
	//	return nil, err
	//}
	return resp, nil
}
