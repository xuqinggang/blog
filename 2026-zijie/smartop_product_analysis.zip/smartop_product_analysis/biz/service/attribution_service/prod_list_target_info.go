package attribution_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"sort"
	"strings"
)

type ProductInfo struct {
	ProdId              string                       `json:"prod_id"`
	ProdName            string                       `json:"prod_name"`
	ProdImages          []string                     `json:"prod_images"`
	ShopId              string                       `json:"shop_id"`
	ShopName            string                       `json:"shop_name"`
	FirstLevelCateName  string                       `json:"first_level_cate_name"`
	SecondLevelCateName string                       `json:"second_level_cate_name"`
	LeafCateName        string                       `json:"leaf_cate_name"`
	TargetList          []*analysis.TargetCardEntity `json:"target_list"`
}

func (d *AttributionService) GetProductListTargetInfo(ctx context.Context, req *analysis.GetAttributionCommonPageRequest, needAttrInfo bool) (resp *analysis.GetAttributionCommonProdList, err error) {
	// 如果没传order by 参数，默认根据show_pv排序
	if req.OrderBy == nil || req.OrderBy.ColumnName == nil || len(*req.OrderBy.ColumnName) == 0 {
		var orderField = consts.AttrNameShowPV
		req.OrderBy = &base.OrderByInfo{
			ColumnName: &orderField,
			IsDesc:     true,
		}
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	osReq := base_struct_condition.OsParamsReq{
		BaseStruct: &dimensions.ProductAnalysisBaseStruct{
			BizType:          dimensions.BizType_GrowthProductStrategy,
			StartDate:        req.BaseReq.StartDate,
			EndDate:          req.BaseReq.EndDate,
			CompareStartDate: req.BaseReq.CompareStartDate,
			CompareEndDate:   req.BaseReq.CompareEndDate,
			Dimensions:       req.BaseReq.Dimensions,
			GroupAttrs:       req.BaseReq.GroupAttrs,
		},
		DimMap:    dimMap,
		DimColMap: dimColMap,
		OrderBy:   req.OrderBy,
		PageInfo:  req.PageReq,
	}
	// 获取invoker的入参
	curr, compare, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, osReq)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	curr["compare_date_expr"] = compare["date_expr"]
	return GetCommonProdList(ctx, req.BaseReq.BizType, needAttrInfo, curr, GetProdListPVApiID, req.PageReq)
}

func (d *AttributionService) GetTargetListByProductIDs(ctx context.Context, req *analysis.AttributionCommonBaseStruct, prodIDs []string, isProdPV bool) (resp map[string][]*analysis.TargetCardEntity, err error) {
	if len(prodIDs) == 0 {
		return
	}
	if req.Dimensions == nil {
		req.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	prodIDsSelectDim := &dimensions.SelectedDimensionInfo{
		Id:               consts.ProdIDSingleDim,
		AttrType:         dimensions.DimensionAttributeType_Product,
		SelectedOperator: base.OperatorType_IN,
		SelectedValues:   make([]*dimensions.EnumElement, 0),
		IsGroup:          false,
	}
	for _, id := range prodIDs {
		prodIDsSelectDim.SelectedValues = append(prodIDsSelectDim.SelectedValues, &dimensions.EnumElement{
			Code: id,
		})
	}
	req.Dimensions = append(req.Dimensions, prodIDsSelectDim)
	newReq := &analysis.GetAttributionCommonPageRequest{
		BaseReq: req,
		PageReq: &base.PageInfo{
			PageNum:  1,
			PageSize: int32(len(prodIDs)),
		},
	}

	var prodList *analysis.GetAttributionCommonProdList
	if isProdPV {
		prodList, err = d.GetProductListTargetInfo(ctx, newReq, false)
	} else {
		//prodList, err = d.GetAttributionProductListTargetInfo(ctx, newReq, false)
	}
	if err != nil {
		return nil, err
	}

	resp = make(map[string][]*analysis.TargetCardEntity)
	for _, info := range prodList.ProductList {
		if info != nil && info.ProductInfo != nil {
			resp[info.ProductInfo.Id] = info.TargetList
		}
	}
	return
}

func PackerProductDetail(pageNum, pageSize int32, overviewInfo map[string]int64, productInfoList []*ProductInfo) (resp *analysis.GetAttributionCommonProdList, err error) {
	var productCnt, shopCnt int64
	// 校验是否有商家数和商品数
	if _, ok := overviewInfo["product_cnt"]; ok {
		productCnt = overviewInfo["product_cnt"]
	}
	if _, ok := overviewInfo["shop_cnt"]; ok {
		shopCnt = overviewInfo["shop_cnt"]
	}
	resp = &analysis.GetAttributionCommonProdList{
		ProductList: make([]*analysis.GetAttributionCommonProd, 0),
		PageInfo: &base.PageResp{
			PageNum:  pageNum,
			PageSize: pageSize,
			Total:    productCnt,
		},
		ShopCnt: shopCnt,
	}
	for _, info := range productInfoList {
		// 对target_list进行排序
		if len(info.TargetList) > 0 {
			sort.Slice(info.TargetList, func(i, j int) bool {
				return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
			})
			for _, target := range info.TargetList {
				if strings.HasPrefix(target.Name, "diff_") && target.Value > 0 && len(target.DisplayValue) > 0 {
					target.DisplayValue = "+" + target.DisplayValue
				}
			}
		}
		resp.ProductList = append(resp.ProductList, &analysis.GetAttributionCommonProd{
			ProductInfo:         &basic_info.ProductBasicInfo{Id: info.ProdId, Name: info.ProdName, Images: info.ProdImages},
			ShopInfo:            &basic_info.ShopBasicInfo{Id: info.ShopId, Name: info.ShopName},
			FirstLevelCateName:  info.FirstLevelCateName,
			SecondLevelCateName: info.SecondLevelCateName,
			LeafCateName:        info.LeafCateName,
			TargetList:          info.TargetList,
		})
	}
	return
}

var KeyCols = []string{"prod_id", "prod_name", "shop_id_new", "shop_name", "first_level_cate_name", "second_level_cate_name", "leaf_cate_name"}

func GetCommonProdList(ctx context.Context, bizType dimensions.BizType, needAttrInfo bool, curr map[string]interface{}, prodListApiID string, pageReq *base.PageInfo) (resp *analysis.GetAttributionCommonProdList, err error) {
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: prodListApiID, BizType: bizType, NeedDistribution: false,
		KeyCols: KeyCols, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
	})
	if err != nil {
		return nil, err
	}

	var productInfoList = make([]*ProductInfo, 0)
	var prodIDs = make([]int64, 0)
	if len(currTargetList) > 0 {
		for _, record := range currTargetList {
			if len(record.KeyColValues) < len(KeyCols) {
				continue
			}
			productInfoList = append(productInfoList, &ProductInfo{
				ProdId:              convert.ToString(record.KeyColValues[0]),
				ProdName:            convert.ToString(record.KeyColValues[1]),
				ProdImages:          make([]string, 0),
				ShopId:              convert.ToString(record.KeyColValues[2]),
				ShopName:            convert.ToString(record.KeyColValues[3]),
				FirstLevelCateName:  convert.ToString(record.KeyColValues[4]),
				SecondLevelCateName: convert.ToString(record.KeyColValues[5]),
				LeafCateName:        convert.ToString(record.KeyColValues[6]),
				TargetList:          record.TargetEntity,
			})
			prodIDs = append(prodIDs, convert.ToInt64(record.KeyColValues[0]))
		}
	}

	var overviewInfo = make(map[string]int64)
	if needAttrInfo {
		doc := document.NewEmptyDoc()
		app := application.NewApp(doc)
		f := flow.Empty()
		// 整体信息，商家数, 商品总数
		f.ExeQueryInvokerRaw(curr, GetProdCntApiID, param.SinkTable("overview_info")).SetParallel(true).SetMaxParallelNum(5)
		f.ExeView(param.SourceTable("overview_info"), &overviewInfo)
		app.Use(f.ToStack(ctx))
		_, err = app.Run(ctx)
		if err != nil {
			logs.CtxError(ctx, err.Error())
			return nil, err
		}

		// 输入商品id信息，拿到商品图片信息
		imageProdList, err := biz_utils.GetProductInfoByIdList(ctx, prodIDs)
		if err == nil && len(imageProdList) > 0 {
			prodId2ImageMap := make(map[string][]string)
			for _, i := range imageProdList {
				prodId2ImageMap[i.Id] = i.Images
			}
			for _, info := range productInfoList {
				info.ProdImages = prodId2ImageMap[info.ProdId]
			}
		}
	}

	resp, err = PackerProductDetail(pageReq.GetPageNum(), pageReq.GetPageSize(), overviewInfo, productInfoList)
	if err != nil {
		logs.CtxError(ctx, "打包结果数据失败,err:"+err.Error())
		return nil, err
	}
	return resp, nil
}

func GetProdIDsByResp(prodList *analysis.GetAttributionCommonProdList) []string {
	ret := make([]string, 0)
	if prodList != nil && len(prodList.ProductList) > 0 {
		for _, info := range prodList.ProductList {
			if info == nil || info.ProductInfo == nil {
				continue
			}
			ret = append(ret, info.ProductInfo.Id)
		}
	}
	return ret
}

func AppendRespWithProdIDs(prodList *analysis.GetAttributionCommonProdList, prodTargetMap map[string][]*analysis.TargetCardEntity) {
	if len(prodTargetMap) > 0 && prodList != nil && len(prodList.ProductList) > 0 {
		for _, info := range prodList.ProductList {
			if info == nil || info.ProductInfo == nil {
				continue
			}
			if targetList, exist := prodTargetMap[info.ProductInfo.Id]; exist {
				info.TargetList = append(info.TargetList, targetList...)
			}
			analysis_service.SortTargetCardEntity(info.TargetList)
		}
	}
}
