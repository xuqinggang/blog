package attribution_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"github.com/bytedance/sonic"
	"gopkg.in/errgo.v2/errors"
	"math"
	"regexp"
	"sort"
	"strings"
)

type subTargetPrefixMetaStruct struct {
	prefix string
	name   string
}

var SubTargetPrefixMeta = []subTargetPrefixMetaStruct{
	{"leaf_avg_", "叶子类目均值"},
	{"leaf_top20_", "叶子类目TOP20%"},
	{"leaf_vbline_avg_", "叶子子赛道均值"},
}

// GetAttributionCommonCoreOverview 获取指标列表
func (d *AttributionService) GetAttributionCommonCoreOverview(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp []*analysis.TargetCardEntity, err error) {
	var guessFlag, isShowCompare bool
	if req.BaseReq.ObjectBizType != nil && *req.BaseReq.ObjectBizType == dimensions.BizType_AttributionCoreGuess {
		guessFlag = true
		var isCycle bool
		isCycle, err = time_utils.JudgeIsCycle(req.BaseReq.StartDate, req.BaseReq.EndDate, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
		if err != nil {
			logs.CtxError(ctx, "[GetAttributionCommonCoreOverview]日期解析失败,err:%v", err.Error())
			return
		}
		isShowCompare = !isCycle
	}
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	ctx = context.WithValue(ctx, consts.CtxAllDatePoolFlag, "异动归因核心指标")
	osReq := base_struct_condition.AttributionOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	}
	// 获取invoker的入参
	curr, compare, trend, compareTrend, err := base_struct_condition.GetAttributionStructConditionParams(ctx, osReq)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	var currTargetList, compareTargetList, cycleTargetList, syncTargetList []*base_struct_condition.KeyColsTargetEntity
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		currTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return err
		}
		return nil
	})

	cc.GoV2(func() error {
		compareTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compare, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
			KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return err
		}
		return nil
	})

	// 此时对比时间和环比不重叠，需要展示对比周期值
	if guessFlag && isShowCompare {
		cycleStartDate, cycleEndDate, err := time_utils.GetCycleStartEndDate(req.BaseReq.StartDate, req.BaseReq.EndDate)
		if err != nil {
			return nil, err
		}
		cycleOsReq := GenOsReqWithNewDate(osReq, cycleStartDate, cycleEndDate)
		cc.GoV2(func() error {
			cycle, err := base_struct_condition.GetAttributionStructConditionParam(ctx, cycleOsReq, base_struct_condition.SQLCalcType_Curr)
			if err != nil {
				return err
			}
			cycleTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: cycle, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
				KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
			})
			if err != nil {
				return err
			}
			return nil
		})
	}
	// 同比周期数据
	if guessFlag && req.BaseReq.SyncType != nil && *req.BaseReq.SyncType != analysis.SyncType_NotNeed {
		syncStartDate, syncEndDate, err := time_utils.GetSyncDate(req.BaseReq.StartDate, req.BaseReq.EndDate, *req.BaseReq.SyncType)
		if err != nil {
			return nil, err
		}
		syncOsReq := GenOsReqWithNewDate(osReq, syncStartDate, syncEndDate)
		cc.GoV2(func() error {
			sync, err := base_struct_condition.GetAttributionStructConditionParam(ctx, syncOsReq, base_struct_condition.SQLCalcType_Curr)
			if err != nil {
				return err
			}
			syncTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: sync, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: false,
				KeyCols: []string{}, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
			})
			if err != nil {
				return err
			}
			return nil
		})
	}

	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionCommonCoreOverview]并发对象wait失败, err:"+err.Error())
		return nil, err
	}
	currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumn(currTargetList, compareTargetList, cycleTargetList, syncTargetList)

	// 是否需要趋势图
	if req.BaseReq.NeedTrend != nil && *req.BaseReq.NeedTrend {
		trendCol := "date"
		if req.BaseReq.BizType == dimensions.BizType_AttributionSupply || req.BaseReq.BizType == dimensions.BizType_AttributionFlow || req.BaseReq.BizType == dimensions.BizType_AttributionQuality {
			trendCol = "dimension"
		}
		trendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: trend, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, KeyCols: []string{}, TrendCol: trendCol, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return nil, err
		}
		currTargetList = base_struct_condition.AddTargetTrend(currTargetList, trendMap)

		compareTrendMap, err := base_struct_condition.GetTargetTrendWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compareTrend, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, KeyCols: []string{}, TrendCol: trendCol, TargetMetaEffectModule: []string{"指标卡", "商品明细"},
		})
		if err != nil {
			return nil, err
		}
		currTargetList = base_struct_condition.AddCompareTargetTrend(currTargetList, compareTrendMap)
	}

	if len(currTargetList) == 0 {
		return resp, nil
	}
	resData := currTargetList[0].TargetEntity
	analysis_service.SortTargetCardEntity(resData)

	targetMeta, err := dao.GetTargetMetaInfo(ctx, int64(req.BaseReq.BizType), false, []string{"指标卡", "商品明细"})
	if err != nil {
		return nil, err
	}
	var targetMetaMap = make(map[string]*dao.TargetMetaInfo)
	for _, info := range targetMeta {
		targetMetaMap[info.Name] = info
	}

	err = AddDiff(ctx, resData, targetMetaMap)
	if err != nil {
		return nil, err
	}

	// 抽出叶子类目塞到子指标中
	resp = make([]*analysis.TargetCardEntity, 0)
	if len(resData) > 0 {
		subPrefixTargetMap := make(map[string]map[string]*analysis.TargetCardEntity)
		for _, i := range resData {
			isSub := false
			for _, prefix := range SubTargetPrefixMeta {
				if strings.HasPrefix(i.Name, prefix.prefix) {
					subTargetMap, exist := subPrefixTargetMap[prefix.prefix]
					if !exist {
						subTargetMap = make(map[string]*analysis.TargetCardEntity)
					}
					subTargetMap[i.Name] = i
					subPrefixTargetMap[prefix.prefix] = subTargetMap
					isSub = true
					break
				}
			}
			if isSub {
				continue
			}
			resp = append(resp, i)
		}
		for _, i := range resp {
			if i.SubTargetList == nil {
				i.SubTargetList = make([]*analysis.TargetBasicInfo, 0)
			}

			for _, prefix := range SubTargetPrefixMeta {
				if subTargetMap, exist := subPrefixTargetMap[prefix.prefix]; exist && len(subTargetMap) > 0 {
					i.SubTargetList = append(i.SubTargetList, TargetEntity2TargetBasicInfo(subTargetMap[prefix.prefix+i.Name], prefix.name, i.Value, i.CycleValue, targetMetaMap[prefix.prefix+i.Name]))
				}
			}
		}
	}

	if guessFlag {
		// 猜喜的建议关注逻辑：比率下降就建议关注
		for _, i := range resp {
			if i.CycleChangeRatio <= 0 {
				if i.Extra == nil {
					i.Extra = &analysis.TargetCardExtraInfo{}
				}
				if i.CycleChangeRatio == 0 {
					i.Extra.TargetTag = "hidden"
				} else {
					i.Extra.TargetTag = "focus_on"
				}
			}
			if i.ComparePeriodData != nil && i.ComparePeriodData.CompareChangeRatio <= 0 {
				if i.ComparePeriodData.CompareChangeRatio == 0 {
					i.ComparePeriodData.CompareTargetTag = "hidden"
				} else {
					i.ComparePeriodData.CompareTargetTag = "focus_on"
				}
			}
			if i.ComparePeriodData != nil && i.ComparePeriodData.SyncChangeRatio <= 0 {
				if i.ComparePeriodData.SyncChangeRatio == 0 {
					i.ComparePeriodData.SyncTargetTag = "hidden"
				} else {
					i.ComparePeriodData.SyncTargetTag = "focus_on"
				}
			}
		}
	} else {
		// 获取指标的变化阈值记录信息
		targetThrMap, err := biz_info.GetTccAttributionTargetThresholdMap(ctx)
		if err != nil {
			return nil, err
		}
		for _, i := range resp {
			// 读取不到时，默认阈值为20%
			incrThr := int64(20)
			if thr, exist := targetThrMap[i.Name]; exist {
				incrThr = thr
			}
			extr := i.Extra
			if extr == nil {
				continue
			}

			extr.TargetTag = consts.Empty
			if i.Value == i.CycleValue {
				extr.TargetTag = "hidden"
			} else if AddTargetTag(i.CycleChangeRatio, incrThr, req, extr.IsLargerAdvantage) {
				extr.TargetTag = "focus_on"
			}

			if len(i.SubTargetList) > 0 {
				for _, subT := range i.SubTargetList {
					if AddTargetTag(subT.DiffBaseRatio, incrThr, req, extr.IsLargerAdvantage) {
						for _, prefix := range SubTargetPrefixMeta {
							if strings.HasPrefix(subT.Name, prefix.prefix) {
								subT.TargetTag = "focus_on"
								break
							}
						}
					}
				}
			}
		}

		AddTagByBizType(req.BaseReq, resp)
	}
	return resp, nil
}

func AddTagByBizType(req *analysis.AttributionCommonBaseStruct, resp []*analysis.TargetCardEntity) {
	if len(resp) == 0 {
		return
	}
	switch req.BizType {
	case dimensions.BizType_AttributionProdBase:
		sort.Slice(resp, func(i, j int) bool {
			if req.PvIncrType != nil && *req.PvIncrType == analysis.AttributionPVIncrType_LESS_THAN {
				return resp[i].CycleChangeRatio < resp[j].CycleChangeRatio
			}
			return resp[i].CycleChangeRatio > resp[j].CycleChangeRatio
		})
		// 不可买原因非波动前三的，隐藏
		top := 3
		for _, info := range resp {
			if strings.HasPrefix(info.Name, "no_purchase_pv_") {
				if top <= 0 {
					info.Extra.TargetTag = "hidden"
				}
				top = top - 1
			}
		}
		sort.Slice(resp, func(i, j int) bool {
			return resp[i].DisplayOrder < resp[j].DisplayOrder
		})
	default:
		return
	}
}

func AddTargetTag(cycleChangeRatio float64, incrThr int64, req *analysis.GetAttributionCommonBaseRequest, isLargerAdvantage bool) bool {
	if math.Abs(cycleChangeRatio)*100 >= convert.ToFloat64(incrThr) && req.BaseReq.PvIncrType != nil && *req.BaseReq.PvIncrType != analysis.AttributionPVIncrType_EQUAL {
		var pvForward = utils.If(*req.BaseReq.PvIncrType == analysis.AttributionPVIncrType_GREATER_THAN, 1, 0)
		var cycleForward = utils.If(cycleChangeRatio > 0, 1, 0)
		if (pvForward ^ cycleForward) == utils.If(!isLargerAdvantage, 1, 0) {
			return true
		}
	}
	return false
}

func TargetEntity2TargetBasicInfo(input *analysis.TargetCardEntity, name string, baseVal, compareVal float64, targetMeta *dao.TargetMetaInfo) *analysis.TargetBasicInfo {
	if input == nil || targetMeta == nil {
		return &analysis.TargetBasicInfo{
			DisplayValue:      "-",
			DisplayName:       name,
			CycleDisplayValue: "-",
		}
	}
	diffBaseRatio := float64(0)
	diffBaseCurr := baseVal - input.Value
	diffBaseCurrDisplayName, _ := framework_udf.GetBriefMetricDisplayValue(diffBaseCurr, targetMeta.ValueType, targetMeta.ValueUnit, targetMeta.TargetPrecision)
	diffBaseCurrDisplayName = transPositiveOrNegative(diffBaseCurrDisplayName, diffBaseCurr)
	diffBaseCompare := compareVal - input.CycleValue
	diffBaseCompareDisplayName, _ := framework_udf.GetBriefMetricDisplayValue(diffBaseCompare, targetMeta.ValueType, targetMeta.ValueUnit, targetMeta.TargetPrecision)
	diffBaseCompareDisplayName = transPositiveOrNegative(diffBaseCompareDisplayName, diffBaseCompare)
	if diffBaseCompare != 0 {
		diffBaseRatio = (diffBaseCurr - diffBaseCompare) / diffBaseCompare
	}
	return &analysis.TargetBasicInfo{
		Value:                      input.Value,
		DisplayValue:               input.DisplayValue,
		Name:                       input.Name,
		DisplayName:                name,
		Tips:                       input.Tips,
		DisplayOrder:               input.DisplayOrder,
		CycleValue:                 input.CycleValue,
		CycleDisplayValue:          input.CycleDisplayValue,
		CycleChangeRatio:           input.CycleChangeRatio,
		DiffBaseCurrDisplayName:    diffBaseCurrDisplayName,
		DiffBaseCompareDisplayName: diffBaseCompareDisplayName,
		DiffBaseRatio:              diffBaseRatio,
	}
}

func AddDiff(ctx context.Context, targetList []*analysis.TargetCardEntity, targetMetaMap map[string]*dao.TargetMetaInfo) error {
	for _, entity := range targetList {
		var diffRatio float64
		if entity.CycleValue != 0 {
			diffRatio = (entity.Value - entity.CycleValue) / entity.CycleValue
		}
		entity.DiffExtra = &analysis.DiffExtraInfo{
			Diff:      entity.Value - entity.CycleValue,
			DiffRatio: diffRatio,
		}
		if meta, ok := targetMetaMap[entity.Name]; ok {
			entity.DiffExtra.DisplayValue, _ = framework_udf.GetBriefMetricDisplayValue(entity.DiffExtra.Diff, meta.ValueType, meta.ValueUnit, meta.TargetPrecision)
		}
	}
	return nil
}

// GetAttributionCommonProdList 获取商品明细
func (d *AttributionService) GetAttributionCommonProdList(ctx context.Context, req *analysis.GetAttributionCommonPageRequest, needAttrInfo bool) (resp *analysis.GetAttributionCommonProdList, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	// 获取invoker的入参
	curr, err := base_struct_condition.GetAttributionStructConditionParam(ctx, base_struct_condition.AttributionOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
		OrderBy:    req.OrderBy,
		PageInfo:   req.PageReq,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	return GetCommonProdList(ctx, req.BaseReq.BizType, needAttrInfo, curr, bizInfo.ProdListApiID, req.PageReq)
}

// GetAttributionTreeMetaList 获取元数据信息
func (d *AttributionService) GetAttributionTreeMetaList(ctx context.Context, req *analysis.GetAttributionTreeMetaListRequest) (resp []*analysis.GetAttributionTreeMetaData, err error) {
	return biz_info.GetTccAttributionTreeMetaData(ctx)
}

func (d *AttributionService) GetAttributionProdPriceDistribution(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionProdPriceDistributionData, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}

	dimMap := biz_info.GetCtxBizInfoAllDimMap(ctx)
	// 获取invoker的入参
	trend, err := base_struct_condition.GetAttributionStructConditionParam(ctx, base_struct_condition.AttributionOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Trend)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryInvokerRaw(trend, "7408769498779550770", param.SinkTable("trend_data"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"date"}))
	f.ExeProduceSql(`
		select  custom_date(date) as x,
				target_name as name,
				m.display_name as display_name,
				target_value as value,
				date as prod_tag_code,
				get_display_value(target_value, m.value_type, m.value_unit,m.target_precision) as display_value
		from trend_data t
		inner join target_meta m
		on t.target_name = m.name`, param.SinkTable("display_trend")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDate),
	})
	var trendPointList = make([]*analysis.TargetTrendPoint, 0)
	f.ExeView(param.SourceTable("display_trend"), &trendPointList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	resp = PackPriceDistribution(ctx, trendPointList)
	return resp, nil
}

type PriceDistributionTag struct {
	Date           string `json:"date"`
	PriceCondition string `json:"price_condition"`
}

func PackPriceDistribution(ctx context.Context, data []*analysis.TargetTrendPoint) *analysis.GetAttributionProdPriceDistributionData {
	var resp = &analysis.GetAttributionProdPriceDistributionData{
		PriceXd:  make([]*analysis.TargetTrendPoint, 0),
		PriceOut: make([]*analysis.TargetTrendPoint, 0),
	}
	var outHighPriceList = make([]*analysis.TargetTrendPoint, 0)
	var outLowPriceList = make([]*analysis.TargetTrendPoint, 0)
	var xdHighPriceList = make([]*analysis.TargetTrendPoint, 0)
	var xdLowPriceList = make([]*analysis.TargetTrendPoint, 0)
	for _, point := range data {
		AddPriceDistributionTag(ctx, point, point.Name)
		switch point.Name {
		case "out_hprice_prod_cnt":
			outHighPriceList = append(outHighPriceList, point)
		case "out_lprice_prod_cnt":
			outLowPriceList = append(outLowPriceList, point)
		case "xd_hprice_prod_cnt":
			xdHighPriceList = append(xdHighPriceList, point)
		case "xd_lprice_prod_cnt":
			xdLowPriceList = append(xdLowPriceList, point)
		default:
			continue
		}
	}
	sort.Slice(outHighPriceList, func(i, j int) bool {
		return outHighPriceList[i].X < outHighPriceList[j].X
	})
	sort.Slice(outLowPriceList, func(i, j int) bool {
		return outLowPriceList[i].X < outLowPriceList[j].X
	})
	sort.Slice(xdHighPriceList, func(i, j int) bool {
		return xdHighPriceList[i].X < xdHighPriceList[j].X
	})
	sort.Slice(xdLowPriceList, func(i, j int) bool {
		return xdLowPriceList[i].X < xdLowPriceList[j].X
	})
	resp.PriceXd = append(resp.PriceXd, xdLowPriceList...)
	resp.PriceXd = append(resp.PriceXd, xdHighPriceList...)
	resp.PriceOut = append(resp.PriceOut, outLowPriceList...)
	resp.PriceOut = append(resp.PriceOut, outHighPriceList...)
	return resp
}

func AddPriceDistributionTag(ctx context.Context, point *analysis.TargetTrendPoint, targetName string) {
	var tag = &PriceDistributionTag{
		Date: point.ProdTagCode, // 上面处理的时候把date塞到了这个字段
	}
	switch targetName {
	case "out_hprice_prod_cnt":
		tag.PriceCondition = " prd_out_price_power_tag_name = '高价' and prd_out_is_high_price_range_tag = 1 "
	case "out_lprice_prod_cnt":
		tag.PriceCondition = " prd_out_price_power_tag_name in ('优价','均价') and prd_out_is_high_price_range_tag = 1 "
	case "xd_hprice_prod_cnt":
		tag.PriceCondition = " prd_xd_price_power_tag_name = '高价' and prd_xd_is_high_price_range_tag = 1 "
	case "xd_lprice_prod_cnt":
		tag.PriceCondition = " prd_xd_price_power_tag_name in ('优价','均价') and prd_xd_is_high_price_range_tag = 1 "
	default:
		logs.CtxWarn(ctx, "AddPriceDistributionTag 没发现 targetName = %s", targetName)
	}
	str, err := sonic.MarshalString(tag)
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionProdPriceDistribution]序列化tagCode失败,err:"+err.Error())
	}
	point.ProdTagCode = str
}

var transPositiveOrNegativeRegex = regexp.MustCompile("^(-|\\+)(.*)")

func transPositiveOrNegative(input string, val float64) string {
	prefixStr := ""
	if val > 0 {
		prefixStr = "高"
	}
	if val < 0 {
		prefixStr = "低"
	}
	out := input
	matchArr := transPositiveOrNegativeRegex.FindStringSubmatch(input)
	fmt.Println(convert.ToJSONString(matchArr))
	if len(matchArr) > 2 {
		out = matchArr[2]
	}
	return prefixStr + out
}
