package attribution_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

type FlowChange struct {
	DimEnum          string  `json:"dim_enum"`
	Curr             float64 `json:"curr"`
	CurrDisplay      string  `json:"curr_display"`
	Compare          float64 `json:"compare"`
	CompareDisplay   string  `json:"compare_display"`
	Diff             float64 `json:"diff"`
	DiffDisplay      string  `json:"diff_display"`
	DiffRatio        float64 `json:"diff_ratio"`
	DiffRatioDisplay string  `json:"diff_ratio_display"`
}

func (d *AttributionService) GetAttributionFlowChange(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (resp *analysis.GetAttributionFlowChangeData, err error) {
	// 归因树底表是大盘用增表，这里固定查这个biz_type
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, dimensions.BizType_GrowthProductStrategy)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	// 归因树需要下钻一个维度
	if len(req.GroupAttrs) == 0 {
		return nil, errors.New("流量变化至少需要下钻一个维度")
	}
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}
	dimColMap, err := d.DimensionListDao.GetDimensionColMap(ctx, dimensions.BizType_GrowthProductStrategy)
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisMultiDimList]获取col map失败，err=%v+", err)
		return nil, err
	}
	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range req.GroupAttrs {
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			req.Dimensions = append(req.Dimensions, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
			}
			req.Dimensions = append(req.Dimensions, attr.DimInfo)
		}
	}
	if len(groupCol) == 0 {
		logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
		return resp, errors.New("多维分析未传入多维配置")
	}

	bizId := dimensions.BizType_GrowthProductStrategy
	if req.ObjectBizType != nil && *req.ObjectBizType == dimensions.BizType_AttributionCoreGuess {
		bizId = *req.ObjectBizType
	}
	osReq := base_struct_condition.OsParamsReq{
		BaseStruct: &dimensions.ProductAnalysisBaseStruct{
			BizType:          bizId,
			StartDate:        req.StartDate,
			EndDate:          req.EndDate,
			CompareStartDate: req.CompareStartDate,
			CompareEndDate:   req.CompareEndDate,
			Dimensions:       req.Dimensions,
			GroupAttrs:       req.GroupAttrs,
		},
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: []string{groupCol},
	}
	// 获取invoker的入参,第一层整体
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
	}
	// 获取完整时间周期的日期参数
	if osReq.BaseStruct.StartDate > osReq.BaseStruct.CompareStartDate {
		osReq.BaseStruct.StartDate = osReq.BaseStruct.CompareStartDate
	}
	if osReq.BaseStruct.EndDate < osReq.BaseStruct.CompareEndDate {
		osReq.BaseStruct.EndDate = osReq.BaseStruct.CompareEndDate
	}
	fullDate, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if curr == nil {
		curr = make(map[string]interface{})
	}
	curr["date_expr"] = fullDate["date_expr"]
	apiPath := APiPathFlowChange
	if req.GetObjectBizType() == dimensions.BizType_AttributionCoreGuess { // 猜喜异动归因
		apiPath = APiPathGuessFlowChange
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(curr, apiPath, param.SinkTable("flow_change")).SetParallel(true).SetMaxParallelNum(10)
	f.ExeProduceSql(`
		select  dimension as dim_enum,
				curr_show_pv as curr,
				get_display_value(curr, 'int', '', 1) as curr_display,
				compare_show_pv as compare,
				get_display_value(compare, 'int', '', 1) as compare_display,
				curr_show_pv-compare_show_pv as diff,
				get_display_value(curr_show_pv-compare_show_pv, 'int', '', 1) as diff_display,
				(curr_show_pv-compare_show_pv) / compare_show_pv as diff_ratio,
				get_display_value((curr_show_pv-compare_show_pv) / compare_show_pv, 'double', '%', 2) as diff_ratio_display
		from    flow_change`, param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	var resData = make([]*FlowChange, 0)
	f.ExeView(param.SourceTable("res_data"), &resData)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	resp = &analysis.GetAttributionFlowChangeData{
		Targets: PackFlowChangeResp(resData),
	}
	return resp, nil
}

func PackFlowChangeResp(changeData []*FlowChange) []*analysis.TargetTrendPoint {
	var resp = make([]*analysis.TargetTrendPoint, 0)
	for _, row := range changeData {
		point := &analysis.TargetTrendPoint{
			Value:        row.Diff,
			DisplayValue: row.DiffDisplay,
			X:            row.DimEnum,
			Name:         "diff",
			DisplayName:  "PV变化",
			SubTargetList: []*analysis.TargetBasicInfo{
				{
					Value:        row.Curr,
					DisplayValue: row.CurrDisplay,
					Name:         "curr",
					DisplayName:  "当前周期PV",
				},
				{
					Value:        row.Compare,
					DisplayValue: row.CompareDisplay,
					Name:         "compare",
					DisplayName:  "对比周期PV",
				},
				{
					Value:        row.DiffRatio,
					DisplayValue: row.DiffRatioDisplay,
					Name:         "diff_ratio",
					DisplayName:  "变化率",
				},
			},
		}
		resp = append(resp, point)
	}
	return resp
}
