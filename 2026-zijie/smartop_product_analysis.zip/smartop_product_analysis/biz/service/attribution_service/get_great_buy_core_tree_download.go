package attribution_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_review_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"context"
)

const (
	Dimention    = "维度"
	BaseRatio    = "分析周期贡献度"
	CompareRatio = "对比周期贡献度"
	RatioRatio   = "贡献度AA增幅"
	RatioDiff    = "贡献度AA增量"
)

func (d *AttributionService) GetGreatBuyCoreTreeDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest, resp *great_value_buy.GetGreatValueBuyAttributionCoreTreeResponse) (err error) {
	if req == nil || resp == nil || resp.Data == nil || len(resp.Data.DataList) <= 0 {
		return nil
	}
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return err
	}
	if env.IsBoe() {
		email = "wumin.13@bytedance.com"
	}

	header := [][]string{{"分析周期", req.BaseReq.StartDate + "~" + req.BaseReq.EndDate}, {"对比周期", req.BaseReq.CompareStartDate + "~" + req.BaseReq.CompareEndDate}}
	targetList := []string{Dimention, Name, BaseValue, CompareValue, BaseRatio, CompareRatio, RatioRatio, RatioDiff}
	allRows := make([]map[string]interface{}, 0)

	// 整体指标
	for _, v := range resp.Data.DataList {
		if v == nil {
			continue
		}
		allRows = append(allRows, initRow(v.Name, v.TargetList)...)
	}

	// 维度下钻指标
	for _, v := range resp.Data.DataList {
		if v == nil {
			continue
		}
		for _, cd := range v.Children {
			if cd == nil {
				continue
			}
			allRows = append(allRows, initRow(cd.Name, cd.TargetList)...)
		}
	}

	err = product_review_service.DoExportData(ctx, "猜喜异动归因-归因树", email, header, targetList, allRows)
	return err
}

func initRow(dimention string, list []*analysis.TargetCardEntity) []map[string]interface{} {
	rows := make([]map[string]interface{}, 0)
	for _, v := range list {
		if v == nil {
			continue
		}
		row := make(map[string]interface{})
		row[Dimention] = dimention
		row[Name] = v.DisplayName
		row[BaseValue] = v.Value
		row[CompareValue] = v.ComparePeriodData.CompareValue
		row[BaseRatio] = v.Extra.DistributionValue
		row[CompareRatio] = v.ComparePeriodData.DistributionValue
		row[RatioRatio] = v.ComparePeriodData.DistributionValueRatio
		row[RatioDiff] = v.Extra.DistributionValue - v.ComparePeriodData.DistributionValue
		rows = append(rows, row)
	}
	return rows
}
