package attribution_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"sort"
)

func (d *AttributionService) GetAttributionMultiDimAnalysis(ctx context.Context, req *analysis.GetAttributionMultiDimAnalysisRequest) (resp *analysis.GetAttributionMultiDimAnalysisItem, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	ctx = context.WithValue(ctx, consts.CtxAllDatePoolFlag, "异动归因核心指标")
	var dim2 string
	if len(req.BaseReq.GroupAttrs) > 1 && req.BaseReq.GroupAttrs[1].DimInfo != nil {
		id := convert.ToInt64(req.BaseReq.GroupAttrs[1].DimInfo.Id)
		dim2, err = d.DimensionService.GetDimColumnExpressStr(ctx, id)
		if err != nil {
			return
		}
	}
	// 获取分析的维度信息
	var groupCol string
	var prodCodeTagBaseDims = make([]*dimensions.SelectedDimensionInfo, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		prodCodeTagBaseDims = append(prodCodeTagBaseDims, attr.DimInfo)
	}
	if len(req.BaseReq.GroupAttrs) > 0 {
		attr := req.BaseReq.GroupAttrs[0]
		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		if len(groupCol) == 0 {
			groupCol = dimInfo.DimColumn
		}
		req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)

		if len(groupCol) == 0 {
			logs.CtxError(ctx, "多维分析未传入多维配置, req = %s", convert.ToJSONString(req))
			return resp, errors.New("多维分析未传入多维配置")
		}
	}
	osReq := base_struct_condition.AttributionOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
		DimColMap:  dimColMap,
	}

	if len(groupCol) >= 0 {
		osReq.MultiDimension = []string{groupCol}
	}

	curr, err := base_struct_condition.GetAttributionStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return nil, err
	}
	var currOneDimTargetList, currTwoDimTargetList, compareOneDimTargetList, compareTwoDimTargetList, cycleOneDimTargetList, cycleTwoDimTargetList, syncOneDimTargetList, syncTwoDimTargetList []*base_struct_condition.KeyColsTargetEntity
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		currOneDimTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: true,
			KeyCols: []string{"dimension"}, FilterTarget: true, FilterTargetNames: []string{req.DrillTarget},
		})
		if err != nil {
			return err
		}
		return nil
	})
	curr2, err := base_struct_condition.GetAttributionStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		return nil, err
	}
	if len(dim2) > 0 {
		// 添加第二个group by维度
		curr2["dimension2"] = dim2
	}
	cc.GoV2(func() error {
		currTwoDimTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: curr2, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: true,
			KeyCols: []string{"dimension", "dimension2"}, FilterTarget: true, FilterTargetNames: []string{req.DrillTarget},
		})
		if err != nil {
			return err
		}
		return nil
	})
	var compare, cycle, sync map[string]interface{}
	//var compareOneDimTargetList, compareTwoDimTargetList, cycleOneDimTargetList, cycleTwoDimTargetList, syncOneDimTargetList, syncTwoDimTargetList []*base_struct_condition.KeyColsTargetEntity
	if req.NeedCompare != nil && *req.NeedCompare {
		compare, err = base_struct_condition.GetAttributionStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Compare)
		if err != nil {
			return nil, err
		}
		cc.GoV2(func() error {
			compareOneDimTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: compare, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: true,
				KeyCols: []string{"dimension"}, FilterTarget: true, FilterTargetNames: []string{req.DrillTarget},
			})
			if err != nil {
				return err
			}
			return nil
		})
		compare2, err := base_struct_condition.GetAttributionStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Compare)
		if err != nil {
			return nil, err
		}
		if len(dim2) > 0 {
			// 添加第二个group by维度
			compare2["dimension2"] = dim2
		}
		cc.GoV2(func() error {
			compareTwoDimTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: compare2, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: true,
				KeyCols: []string{"dimension", "dimension2"}, FilterTarget: true, FilterTargetNames: []string{req.DrillTarget},
			})
			if err != nil {
				return err
			}
			return nil
		})
	}
	if req.NeedCycle != nil && *req.NeedCycle {
		cycleStartDate, cycleEndDate, err := time_utils.GetCycleStartEndDate(req.BaseReq.StartDate, req.BaseReq.EndDate)
		if err != nil {
			return nil, err
		}

		cycleOsReq := GenOsReqWithNewDate(osReq, cycleStartDate, cycleEndDate)
		cycle, err = base_struct_condition.GetAttributionStructConditionParam(ctx, cycleOsReq, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			return nil, err
		}
		cc.GoV2(func() error {
			cycleOneDimTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: cycle, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: true,
				KeyCols: []string{"dimension"}, FilterTarget: true, FilterTargetNames: []string{req.DrillTarget},
			})
			if err != nil {
				return err
			}
			return nil
		})
		cycle2, err := base_struct_condition.GetAttributionStructConditionParam(ctx, cycleOsReq, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			return nil, err
		}
		if len(dim2) > 0 {
			// 添加第二个group by维度
			cycle2["dimension2"] = dim2
		}
		cc.GoV2(func() error {
			cycleTwoDimTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: cycle2, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: true,
				KeyCols: []string{"dimension", "dimension2"}, FilterTarget: true, FilterTargetNames: []string{req.DrillTarget},
			})
			if err != nil {
				return err
			}
			return nil
		})
	}
	if req.NeedSync != nil && *req.NeedSync {
		syncStartDate, syncEndDate, err := time_utils.GetSyncDate(req.BaseReq.StartDate, req.BaseReq.EndDate, *req.BaseReq.SyncType)
		if err != nil {
			return nil, err
		}
		syncOsReq := GenOsReqWithNewDate(osReq, syncStartDate, syncEndDate)
		sync, err = base_struct_condition.GetAttributionStructConditionParam(ctx, syncOsReq, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			return nil, err
		}
		cc.GoV2(func() error {
			syncOneDimTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: sync, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: true,
				KeyCols: []string{"dimension"}, FilterTarget: true, FilterTargetNames: []string{req.DrillTarget},
			})
			if err != nil {
				return err
			}
			return nil
		})
		sync2, err := base_struct_condition.GetAttributionStructConditionParam(ctx, syncOsReq, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			return nil, err
		}
		if len(dim2) > 0 {
			// 添加第二个group by维度
			sync2["dimension2"] = dim2
		}
		cc.GoV2(func() error {
			syncTwoDimTargetList, err = base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: sync2, Sql: consts.Empty, ApiPath: bizInfo.TargetCardApiID, BizType: req.BaseReq.BizType, NeedDistribution: true,
				KeyCols: []string{"dimension", "dimension2"}, FilterTarget: true, FilterTargetNames: []string{req.DrillTarget},
			})
			if err != nil {
				return err
			}
			return nil
		})
	}
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[GetAttributionMultiDimAnalysis]并发对象wait失败, err:"+err.Error())
		return nil, err
	}
	resp = packAttributionMultiDimAnalysis(currOneDimTargetList, currTwoDimTargetList, compareOneDimTargetList, compareTwoDimTargetList, cycleOneDimTargetList, cycleTwoDimTargetList, syncOneDimTargetList, syncTwoDimTargetList, prodCodeTagBaseDims)
	// 添加TagCode
	analysis_service.AddChildrenTagCode(ctx, prodCodeTagBaseDims, []*dimensions.SelectedDimensionInfo{}, 0, resp.GetCompareList())
	analysis_service.AddChildrenTagCode(ctx, prodCodeTagBaseDims, []*dimensions.SelectedDimensionInfo{}, 0, resp.GetCycleList())
	analysis_service.AddChildrenTagCode(ctx, prodCodeTagBaseDims, []*dimensions.SelectedDimensionInfo{}, 0, resp.GetSyncList())
	return resp, nil
}

func GenOsReqWithNewDate(osReq base_struct_condition.AttributionOsParamsReq, startDate, endDate string) base_struct_condition.AttributionOsParamsReq {
	return base_struct_condition.AttributionOsParamsReq{
		BaseStruct: &analysis.AttributionCommonBaseStruct{
			BizType:          osReq.BaseStruct.BizType,
			ObjectBizType:    osReq.BaseStruct.ObjectBizType,
			InsightType:      osReq.BaseStruct.InsightType,
			StartDate:        startDate,
			EndDate:          endDate,
			CompareStartDate: osReq.BaseStruct.CompareStartDate,
			CompareEndDate:   osReq.BaseStruct.CompareEndDate,
			SyncType:         osReq.BaseStruct.SyncType,
			Dimensions:       osReq.BaseStruct.Dimensions,
			GroupAttrs:       osReq.BaseStruct.GroupAttrs,
			ThresholdAttrs:   osReq.BaseStruct.ThresholdAttrs,
			ThresholdExpr:    osReq.BaseStruct.ThresholdExpr,
			NeedTrend:        osReq.BaseStruct.NeedTrend,
			PvIncrType:       osReq.BaseStruct.PvIncrType,
		},
		DimMap:         osReq.DimMap,
		DimColMap:      osReq.DimColMap,
		MultiDimension: osReq.MultiDimension,
		OrderBy:        osReq.OrderBy,
		PageInfo:       osReq.PageInfo,
	}
}

// 筛选TopN
func sortRespAndGetTopN(resp []*analysis.MultiDimFullListRow, compareType base_struct_condition.CompareType) []*analysis.MultiDimFullListRow {
	resp = sortResp(resp, compareType)
	if len(resp) >= 1 {
		resp = resp[:1]
	}
	for _, row := range resp {
		row.Children = sortResp(row.Children, compareType)
		if len(row.Children) >= 3 {
			row.Children = row.Children[:3]
		}
	}
	return resp
}

// 根据DIFF排序
func sortResp(resp []*analysis.MultiDimFullListRow, compareType base_struct_condition.CompareType) []*analysis.MultiDimFullListRow {
	if len(resp) == 0 {
		return resp
	}
	sort.Slice(resp, func(i, j int) bool {
		if compareType == base_struct_condition.CompareTypeCycle {
			if len(resp[i].TargetList) > 0 && len(resp[j].TargetList) > 0 && resp[i].TargetList[0].DiffExtra != nil && resp[j].TargetList[0].DiffExtra != nil {
				return resp[i].TargetList[0].DiffExtra.Diff < resp[j].TargetList[0].DiffExtra.Diff
			}
		} else if compareType == base_struct_condition.CompareTypeSync {
			if len(resp[i].TargetList) > 0 && len(resp[j].TargetList) > 0 && resp[i].TargetList[0].ComparePeriodData != nil && resp[j].TargetList[0].ComparePeriodData != nil {
				return resp[i].TargetList[0].ComparePeriodData.SyncDiff < resp[j].TargetList[0].ComparePeriodData.SyncDiff
			}
		} else if compareType == base_struct_condition.CompareTypeCompare {
			if len(resp[i].TargetList) > 0 && len(resp[j].TargetList) > 0 && resp[i].TargetList[0].ComparePeriodData != nil && resp[j].TargetList[0].ComparePeriodData != nil {
				return resp[i].TargetList[0].ComparePeriodData.CompareDiff < resp[j].TargetList[0].ComparePeriodData.CompareDiff
			}
		}
		return true
	})
	return resp
}

// 打包结果
func packAttributionMultiDimAnalysis(currentOne, currentTwo, compareOne, compareTwo, cycleOne, cycleTwo, syncOne, syncTwo []*base_struct_condition.KeyColsTargetEntity, prodCodeTagBaseDims []*dimensions.SelectedDimensionInfo) *analysis.GetAttributionMultiDimAnalysisItem {
	var resp = &analysis.GetAttributionMultiDimAnalysisItem{}
	if len(compareOne) > 0 {
		resp.CompareList = GetRespPeriod(currentOne, currentTwo, compareOne, compareTwo, base_struct_condition.CompareTypeCompare)
		resp.CompareList = sortRespAndGetTopN(resp.CompareList, base_struct_condition.CompareTypeCompare)
	}
	if len(cycleOne) > 0 {
		resp.CycleList = GetRespPeriod(currentOne, currentTwo, cycleOne, cycleTwo, base_struct_condition.CompareTypeCycle)
		resp.CycleList = sortRespAndGetTopN(resp.CycleList, base_struct_condition.CompareTypeCycle)
	}

	if len(syncOne) > 0 {
		resp.SyncList = GetRespPeriod(currentOne, currentTwo, syncOne, syncTwo, base_struct_condition.CompareTypeSync)
		resp.SyncList = sortRespAndGetTopN(resp.SyncList, base_struct_condition.CompareTypeSync)
	}
	return resp
}

func GetRespPeriod(currentOne, currentTwo, compareOne, compareTwo []*base_struct_condition.KeyColsTargetEntity, compareType base_struct_condition.CompareType) []*analysis.MultiDimFullListRow {
	compareOne = base_struct_condition.GetTargetCycleRatioListWithKeyColumnByType(currentOne, compareOne, compareType)
	var secondDimMap = make(map[string][]*base_struct_condition.KeyColsTargetEntity)
	if compareTwo != nil {
		compareTwo = base_struct_condition.GetTargetCycleRatioListWithKeyColumnByType(currentTwo, compareTwo, compareType)
		for _, item := range compareTwo {
			if len(item.KeyColValues) > 0 {
				if len(secondDimMap[convert.ToString(item.KeyColValues[0])]) == 0 {
					secondDimMap[convert.ToString(item.KeyColValues[0])] = []*base_struct_condition.KeyColsTargetEntity{item}
				} else {
					secondDimMap[convert.ToString(item.KeyColValues[0])] = append(secondDimMap[convert.ToString(item.KeyColValues[0])], item)
				}
			}
		}
	}
	var res = make([]*analysis.MultiDimFullListRow, 0)
	for _, entity := range compareOne {
		var displayName string
		if len(entity.KeyColValues) > 0 {
			displayName = convert.ToString(entity.KeyColValues[0])
		} else {
			displayName = ""
		}
		var children = make([]*analysis.MultiDimFullListRow, 0)
		if _, ok := secondDimMap[displayName]; ok {
			for _, item := range secondDimMap[displayName] {
				var name string
				if len(item.KeyColValues) > 1 {
					name = convert.ToString(item.KeyColValues[1])
				} else {
					name = ""
				}
				children = append(children, &analysis.MultiDimFullListRow{
					EnumValue:   name,
					DisplayName: name,
					TargetList:  item.TargetEntity,
					DimKey:      base_struct_condition.GetMapKeyColsString(item.KeyColValues),
				})
			}
		}

		res = append(res, &analysis.MultiDimFullListRow{
			EnumValue:   displayName,
			DisplayName: displayName,
			TargetList:  entity.TargetEntity,
			DimKey:      displayName,
			Children:    children,
		})
	}
	return res
}
