package coral_service

import (
	"context"
	"errors"
	"fmt"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/gopkg/logs/v2"
	"gopkg.in/resty.v1"
)

type CoralQueryDDLReq struct {
	DbName    string `json:"dbName"`
	TableName string `json:"tableName"`
	Limit     int    `json:"limit"`
}

type CoralQueryDDLResp struct {
	ErrorCode string `json:"errorCode"`
	Code      int    `json:"code"`
	Version   string `json:"version"`
	Message   string `json:"message"`
	Data      struct {
		Cid        int    `json:"cid"`
		ParentName string `json:"parentName"`
		Name       string `json:"name"`
		Ddl        string `json:"ddl"`
	} `json:"data"`
}

type CoralQueryPartitionsResp struct {
	ErrorCode string `json:"errorCode"`
	Code      int    `json:"code"`
	Version   string `json:"version"`
	Message   string `json:"message"`
	Data      struct {
		Partitions []CoralTablePartition `json:"partitions"`
	}
}

type CoralTablePartition struct {
	PartName string `json:"partName,omitempty"`
	NumRows  int64  `json:"numRows,omitempty"`
}

type CoralChatQueryReq struct {
	Query         string `json:"query"`
	Mode          string `json:"mode"`
	BusinessLine  string `json:"businessLine"`
	RealUser      string `json:"realUser"`
	KnowledgeBase string `json:"knowledgeBase"`
}

type CoralChatQueryResp struct {
	Think  string `json:"think"`
	Answer string `json:"answer"`
}

// 获取Hive建表ddl信息
func QueryHiveDDL(ctx context.Context, req *CoralQueryDDLReq) (resp *CoralQueryDDLResp, err error) {
	defer func() {
		if resp != nil {
			resp.Data.Ddl = DDLFilterSketchField(DDLSimplify(resp.Data.Ddl)) // 简化
		}
	}()

	if len(req.DbName) == 0 || len(req.TableName) == 0 {
		return nil, errors.New("param is empty")
	}

	resp = &CoralQueryDDLResp{}
	config, err := biz_info.GetCoralOpenAPIConfig(ctx)
	if err != nil || config == nil || len(config.AuthKey) == 0 {
		logs.CtxError(ctx, "[QueryHiveDDL] can not get auth key, err=%v", err)
		return nil, err
	}

	if runResp, err := resty.New().
		SetTimeout(60 * time.Second).
		R().
		SetResult(resp).
		SetHeaders(map[string]string{
			"authorization": config.AuthKey,
			"Content-Type":  "application/json",
		}).Get(fmt.Sprintf("https://openapi-dp.byted.org/openapi/new_coralng/v2/bridge/hive/ddl?cid=0&dbName=%s&tableName=%s", req.DbName, req.TableName)); err != nil {
		logs.CtxError(ctx, "[QueryHiveDDL] failed, dbName: %s, tableName: %s, err: %v", req.DbName, req.TableName, err)
		return nil, err
	} else if runResp == nil || runResp.StatusCode() != 200 {
		logs.CtxError(ctx, "[QueryHiveDDL] failed, dbName: %s, tableName: %s, resp is nil or status code is not 200", req.DbName, req.TableName)
		return nil, fmt.Errorf("QueryHiveDDL failed, resp is nil or status code is not 200")
	}

	return
}

// 获取Hive表分区信息
func QueryHivePartitions(ctx context.Context, req *CoralQueryDDLReq) (resp *CoralQueryPartitionsResp, err error) {
	if len(req.DbName) == 0 || len(req.TableName) == 0 {
		return nil, errors.New("param is empty")
	}

	resp = &CoralQueryPartitionsResp{}
	config, err := biz_info.GetCoralOpenAPIConfig(ctx)
	if err != nil || config == nil || len(config.AuthKey) == 0 {
		logs.CtxError(ctx, "[QueryHivePartitions] can not get auth key, err=%v", err)
		return nil, err
	}

	if runResp, err := resty.New().
		SetTimeout(60 * time.Second).
		R().
		SetResult(resp).
		SetHeaders(map[string]string{
			"authorization": config.AuthKey,
			"Content-Type":  "application/json",
		}).Get(fmt.Sprintf("https://openapi-dp.byted.org/openapi/new_coralng/v2/bridge/hive/partitions?limit=%v&cluster=default&qualifiedName=%s", req.Limit, fmt.Sprintf("HiveTable:///%s/%s@0", req.DbName, req.TableName))); err != nil {
		logs.CtxError(ctx, "[QueryHivePartitions] failed, dbName: %s, tableName: %s, err: %v", req.DbName, req.TableName, err)
		return nil, err
	} else if runResp == nil || runResp.StatusCode() != 200 {
		logs.CtxError(ctx, "[QueryHivePartitions] failed, dbName: %s, tableName: %s, resp is nil or status code is not 200", req.DbName, req.TableName)
		return nil, fmt.Errorf("QueryHivePartitions failed, resp is nil or status code is not 200")
	}

	return
}

// 数小秘聊天
func CoralChat(ctx context.Context, req *CoralChatQueryReq) (resp *CoralChatQueryResp, err error) {
	if len(req.Query) == 0 {
		return nil, errors.New("param is empty")
	}

	resp = &CoralChatQueryResp{}
	config, err := biz_info.GetCoralOpenAPIConfig(ctx)
	if err != nil || config == nil || len(config.AuthKey) == 0 {
		logs.CtxError(ctx, "[ChatQuery] can not get auth key, err=%v", err)
		return nil, err
	}

	if runResp, err := resty.New().
		SetTimeout(5 * time.Minute).
		R().
		SetBody(req).
		SetResult(resp).
		SetHeaders(map[string]string{
			"authorization": config.AuthKey,
			"Content-Type":  "application/json",
		}).
		Post("http://openapi-dp.byted.org/openapi/new_coralng/ai/chat/open/query"); err != nil {
		logs.CtxError(ctx, "[ChatQuery] failed, query: %s, err: %v", req.Query, err)
		return nil, err
	} else if runResp == nil || runResp.StatusCode() != 200 {
		logs.CtxError(ctx, "[ChatQuery] failed, query: %s, resp is nil or status code is not 200", req.Query)
		return nil, fmt.Errorf("ChatQuery failed, resp is nil or status code is not 200")
	}

	return
}
