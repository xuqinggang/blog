package coral_service

import "strings"

func DDLFilterSketchField(sql string) string {
	if len(sql) == 0 {
		return sql
	}
	var lines []string
	for _, line := range strings.Split(sql, "\n") {
		if strings.Contains(line, "_sketch") {
			continue
		}
		lines = append(lines, line)
	}
	return strings.Join(lines, "\n")
}

func DDLSimplify(sql string) string {
	/*
		去掉DDL中多余的信息
	*/
	sql = strings.ReplaceAll(sql, "CREATE TABLE\n", "CREATE TABLE")

	if len(sql) > 0 {
		if idx := strings.Index(sql, "ROW FORMAT SERDE"); idx > 0 {
			sql = sql[:idx]
		}
		if strings.Contains(sql, "ENGINE=InnoDB") {
			sql = strings.ReplaceAll(sql, "ENGINE=InnoDB", "")
		}
	}
	return sql
}
