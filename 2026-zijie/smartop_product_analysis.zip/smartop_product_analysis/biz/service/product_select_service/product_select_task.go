package product_select_service

import (
	"context"
	"math"
	"strconv"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/product_select"
	"code.byted.org/gopkg/jsonx"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
)

var (
	featureKey = []int64{1023, 1022, 1020, 1016, 1008, 992, 960, 896, 768,
		512, 768, 896, 960, 992, 1008, 1016, 1020, 1022, 1023}
)

const OneServiceAPIPath = "7569207340994479113"
const OneServicePreviewAPIPath = "7569556325085021222"

func getFeatureInfoRedisKey(businessType product_select.BusinessType) string {
	return "product_select_algorithm_feature_" + utils.Int642String(int64(businessType))
}

func getOneServiceTableAPI(ctx context.Context, bizType dimensions.BizType, businessType product_select.BusinessType) string {
	// 从TCC获取配置
	configMap, err := biz_info.GetProductSelectBizTypeApiConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetProductSelectBizTypeApiConfig error, %s", err.Error())
		// 失败时返回默认值
		return consts.ProductSelectZeroSubsidy
	}
	if configMap == nil {
		return consts.ProductSelectZeroSubsidy
	}

	// 优先使用 bizType 获取配置
	if bizType != dimensions.BizType_Unknown {
		bizTypeStr := strconv.FormatInt(int64(bizType), 10)
		if apiPath, ok := configMap.BizType2Api[bizTypeStr]; ok && apiPath != "" {
			return apiPath
		}
	}

	// 如果 bizType 无值，则使用 businessType 获取
	businessTypeStr := strconv.FormatInt(int64(businessType), 10)
	if apiPath, ok := configMap.BusinessType2Api[businessTypeStr]; ok {
		return apiPath
	}

	// 默认值
	return consts.ProductSelectZeroSubsidy
}

func getDimensionKey(dimension *dimensions.SelectedDimensionInfo) string {
	return dimension.Id + "|" + dimension.Name
}

func UpdateDimensionSQL(ctx context.Context, taskInfo *dao.ProductSelectTask) {
	extra := &product_select.Extra{}
	if taskInfo.Extra != "" {
		err := sonic.UnmarshalString(taskInfo.Extra, extra)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker, parse extra failed, err: %s, extra: %s", err, taskInfo.Extra)
		}
	}

	// 过滤无效任务
	businessType := extra.BusinessType
	isManual := extra.IsManual
	if !isManual {
		if businessType == product_select.BusinessType_AggregationLinks || businessType == product_select.BusinessType_FastConsumer {
			return
		}
	}

	poolRule := &dimensions.ProductAnalysisBaseStruct{}
	if taskInfo.PoolRule != "" {
		err := sonic.UnmarshalString(taskInfo.PoolRule, poolRule)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker, parse extra failed, err: %s, poolRule: %s", err, taskInfo.PoolRule)
		}
	}

	dimensionsList := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dimension := range poolRule.Dimensions {
		if dimension.Id == consts.AlgorithmFeatureSignId {
			continue
		}
		dimensionsList = append(dimensionsList, dimension)
	}
	poolRule.Dimensions = dimensionsList

	dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, dimensions.BizType(taskInfo.BizType))
	if err != nil {
		logs.CtxError(ctx, "[GetProdPortrait]获取map失败，err=%v+", err)
		return
	}

	logs.CtxInfo(ctx, "ProductSelectTaskWorker UpdateDimensionSQL task %+v, poolRule: %+v", taskInfo, poolRule)
	params, err := base_struct_condition.GetBaseStructConditionParam(ctx,
		base_struct_condition.OsParamsReq{
			BaseStruct: poolRule,
			DimMap:     dimMap,
		},
		base_struct_condition.SQLCalcType_Curr,
	)
	if err != nil {
		logs.CtxError(ctx, "ProductSelectTaskWorker GetBaseStructConditionParams error, %s", err.Error())
		return
	}
	logs.CtxInfo(ctx, "ProductSelectTaskWorker UpdateDimensionSQL params: %+v", params)
	extra.DimensionSql = convert.ToString(params["filter_param"])

	taskInfo.Extra, _ = sonic.MarshalString(extra)
	var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
	err = ProductSelectTaskDao.UpdateProductSelectTask(ctx, taskInfo.TaskId, taskInfo)
	if err != nil {
		logs.CtxError(ctx, "ProductSelectTaskWorker UpdateProductSelectTask failed, err: %s", err)
		return
	}
}

func ProductSelectTaskWorker(ctx context.Context, taskInfo *dao.ProductSelectTask, forceExecute bool) {
	if taskInfo == nil {
		return
	}
	ctx = logs.CtxAddKVs(ctx, "task_id", taskInfo.TaskId)
	logs.CtxInfo(ctx, "ProductSelectTaskWorker start, taskInfo: %s", jsonx.ToString(taskInfo))

	// 解析extra
	extra := &product_select.Extra{}
	if taskInfo.Extra != "" {
		err := sonic.UnmarshalString(taskInfo.Extra, extra)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker, parse extra failed, err: %s, extra: %s", err, taskInfo.Extra)
			return
		}
	}

	businessType := extra.BusinessType

	// todo 暂时剔除无效类型
	if businessType == product_select.BusinessType_AggregationLinks || businessType == product_select.BusinessType_FastConsumer {
		taskInfo.IsDelete = 1
		var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
		err := ProductSelectTaskDao.UpdateProductSelectTask(ctx, taskInfo.TaskId, taskInfo)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker UpdateProductSelectTask failed, err: %s", err)
			return
		}
		return
	}

	// 获取逻辑表
	bizType := dimensions.BizType(taskInfo.BizType)
	tableAPI := getOneServiceTableAPI(ctx, bizType, businessType)
	newestDay, err := utils.GetNewestDay(ctx, tableAPI)
	if err != nil {
		logs.CtxError(ctx, "ProductSelectTaskWorker getNewestDay failed, err: %s", err)
		return
	}
	minNewTime, err := time.Parse(consts.FmtDate, newestDay)
	if err != nil {
		logs.CtxError(ctx, "ProductSelectTaskWorker time.Parse failed, err: %s", err)
		return
	}
	minNewDate := minNewTime.Format(consts.FmtDateSlash)
	logs.CtxInfo(ctx, "ProductSelectTaskWorker getNewestDay: %s, taskId: %d", minNewDate, taskInfo.TaskId)

	// 解析Pool
	poolRule := &dimensions.ProductAnalysisBaseStruct{}
	if taskInfo.PoolRule != "" {
		err := sonic.UnmarshalString(taskInfo.PoolRule, poolRule)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker, parse extra failed, err: %s, poolRule: %s", err, taskInfo.PoolRule)
			return
		}
	} else {
		poolRule = &dimensions.ProductAnalysisBaseStruct{
			BizType: bizType,
		}
	}

	poolRule.StartDate = minNewDate
	poolRule.EndDate = minNewDate
	poolRule.CompareStartDate = minNewDate
	poolRule.CompareEndDate = minNewDate

	// 剔除算法规则, 下面重新生产
	userSelectedDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dimension := range poolRule.Dimensions {
		if dimension.Id == consts.AlgorithmFeatureSignId {
			continue
		}
		userSelectedDimensions = append(userSelectedDimensions, dimension)
	}
	poolRule.Dimensions = userSelectedDimensions

	// 最新分区日期
	featureUpdateDayStart := GetTodayStartSecondInShanghai(minNewTime.Unix())

	// redis判断执行过则跳过
	executed, err := getProductSelectTaskFlag(ctx, taskInfo.BizType, taskInfo.TaskId, featureUpdateDayStart)
	if err != nil {
		logs.CtxError(ctx, "ProductSelectTaskWorker getProductSelectTaskFlag failed, err: %s", err)
		return
	}
	if executed && !forceExecute {
		logs.CtxNotice(ctx, "ProductSelectTaskWorker getProductSelectTaskFlag executed, taskInfo: %s, featureUpdateDay:%s",
			jsonx.ToString(taskInfo), time.Unix(featureUpdateDayStart, 0).Format("20060102"))
		return
	}

	if extra.IsManual { // 人工圈选
		// 更新任务信息
		extra.PoolRule, _ = sonic.MarshalString(poolRule)
		taskInfo.Extra, _ = sonic.MarshalString(extra)
		taskInfo.PoolRule = extra.PoolRule
		taskInfo.TaskStatus = 1
		var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
		err := ProductSelectTaskDao.UpdateProductSelectTask(ctx, taskInfo.TaskId, taskInfo)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker UpdateProductSelectTask failed, err: %s", err)
			return
		}

		// 更新货盘规则
		if taskInfo.PoolId != "" {
			var AnalysisPoolService = &analysis_pool_service.AnalysisPoolService{}
			_, err = AnalysisPoolService.UpdateAnalysisPoolRule(ctx, &analysis_pool.UpdateAnalysisPoolReq{
				PoolId:   taskInfo.PoolId,
				PoolRule: &taskInfo.PoolRule,
			})
		}

		// 设置任务状态为已完成
		_ = setProductSelectTaskFlag(ctx, taskInfo.BizType, taskInfo.TaskId, featureUpdateDayStart)
	} else {
		if businessType == product_select.BusinessType_Unknown {
			return
		}
		//查询 特征redis
		//查询 特征宽表日期
		//判断日期是否一致，是否可以启动任务
		featureInfo, err := getFeatureInfo(ctx, businessType)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker getFeatureInfo failed, err: %s", err)
			return
		}
		if featureInfo == nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker getFeatureInfo failed, featureInfo is nil")
			return
		}

		// 获取注册的特征
		dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, dimensions.BizType(taskInfo.BizType))
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker GetDimensionMap error, %s", err.Error())
			return
		}

		// 生成参数
		params, err := base_struct_condition.GetBaseStructConditionParam(ctx,
			base_struct_condition.OsParamsReq{
				BaseStruct: poolRule,
				DimMap:     dimMap,
			},
			base_struct_condition.SQLCalcType_Curr,
		)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker GetBaseStructConditionParams error, %s", err.Error())
			return
		}
		logs.CtxInfo(ctx, "ProductSelectTaskWorker params: %s", jsonx.ToString(params))

		// 执行查询
		req := base_struct_condition.GetTargetListWithKeyColumnReq{
			Params:  params,
			Sql:     consts.Empty,
			ApiPath: OneServiceAPIPath,
		}
		_, dataList, err := base_struct_condition.GetDataListByOS(ctx, req.Params, req.Sql, req.ApiPath)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker GetDataListByOS error, %s", err.Error())
			return
		}
		if len(dataList) != 1 || len(dataList[0]) != 20 {
			logs.CtxError(ctx, "ProductSelectTaskWorker GetDataListByOS failed, data_list len illegal, data_list: %s", jsonx.ToString(dataList))
			return
		}

		logs.CtxInfo(ctx, "ProductSelectTaskWorker GetDataListByOS, req: %s, dataList: %s, task: %s", jsonx.ToString(req), jsonx.ToString(dataList), jsonx.ToString(taskInfo))

		queryResp := make([]int64, 0)
		for _, target := range dataList {
			for _, entity := range target {
				val := int64(convert.ToFloat64(entity))
				queryResp = append(queryResp, val)
				logs.CtxNotice(ctx, "ProductSelectTaskWorker, entity:%+v, value: %s", entity, val)
			}
		}
		logs.CtxInfo(ctx, "ProductSelectTaskWorker queryResp: %s", jsonx.ToString(queryResp))
		totalProdCnt := queryResp[len(queryResp)-1]
		queryResp = queryResp[0 : len(queryResp)-1]

		// 3. 计算圈选商品数量、使用的特征
		hitIdx := -1
		selectProductCnt := int64(0)
		for idx, queryCnt := range queryResp {
			hitIdx = idx
			selectProductCnt = queryCnt
			logs.CtxNotice(ctx, "ProductSelectTaskWorker, idx: %d, query_cnt: %d, target_amount:%d", idx, queryCnt, taskInfo.TargetAmount)
			if queryCnt >= taskInfo.TargetAmount {
				break
			}
		}
		if hitIdx == -1 {
			logs.CtxError(ctx, "ProductSelectTaskWorker, hitIdx is -1, queryResp: %s", jsonx.ToString(queryResp))
			return
		}
		logs.CtxInfo(ctx, "ProductSelectTaskWorker, hitIdx: %d, selectProductCnt: %d", hitIdx, selectProductCnt)

		// 4. 保存结果
		threshold := featureKey[hitIdx]
		zeroPoint := len(featureKey) / 2
		operater := "exist"
		if hitIdx < zeroPoint {
			operater = "equal"
		}

		// 生成新的dimensions
		dimensionsMap := make(map[string]*dimensions.SelectedDimensionInfo)
		for _, dimension := range poolRule.Dimensions {
			dimensionKey := getDimensionKey(dimension)
			if _, exist := dimensionsMap[dimensionKey]; !exist {
				dimensionsMap[dimensionKey] = dimension
			}
		}
		// 拼装算法特征
		newFeatureDimension := &dimensions.SelectedDimensionInfo{
			Id:   consts.AlgorithmFeatureSignId,
			Name: consts.AlgorithmFeatureSignName,
			SelectedValues: []*dimensions.EnumElement{
				&dimensions.EnumElement{
					Code:      strconv.FormatInt(threshold, 10),
					ExtraInfo: operater,
				},
			},
		}
		dimensionsMap[getDimensionKey(newFeatureDimension)] = newFeatureDimension
		// 执行生成动作
		newDimensionList := make([]*dimensions.SelectedDimensionInfo, 0)
		for _, dimension := range dimensionsMap {
			newDimensionList = append(newDimensionList, dimension)
		}
		poolRule.Dimensions = newDimensionList

		extra.ZeroSubsidyExplodeFeature = featureInfo
		extra.BasePoolProdCount = totalProdCnt
		extra.SelectProdCount = selectProductCnt
		extra.UsedFeatureInfo = extra.ZeroSubsidyExplodeFeature.FeatureInfo[0 : int(math.Abs(float64(hitIdx-zeroPoint)))+1]
		extra.PoolRule, _ = sonic.MarshalString(poolRule)
		taskInfo.PoolRule = extra.PoolRule
		taskInfo.Extra, _ = sonic.MarshalString(extra)
		taskInfo.TaskStatus = 1

		var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
		err = ProductSelectTaskDao.UpdateProductSelectTask(ctx, taskInfo.TaskId, taskInfo)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker UpdateProductSelectTask failed, err: %s", err)
			return
		}
		if taskInfo.PoolId != "" {
			var AnalysisPoolService = &analysis_pool_service.AnalysisPoolService{}
			_, err = AnalysisPoolService.UpdateAnalysisPoolRule(ctx, &analysis_pool.UpdateAnalysisPoolReq{
				PoolId:   taskInfo.PoolId,
				PoolRule: &taskInfo.PoolRule,
			})
		}
		// 设置任务状态为已完成
		_ = setProductSelectTaskFlag(ctx, taskInfo.BizType, taskInfo.TaskId, featureUpdateDayStart)
	}
}

func GetTodayStartSecondInShanghai(t int64) int64 {
	// 加载上海时区
	shanghai, _ := time.LoadLocation("Asia/Shanghai")
	now := time.Unix(t, 0).In(shanghai)
	return time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, shanghai).Unix()
}
