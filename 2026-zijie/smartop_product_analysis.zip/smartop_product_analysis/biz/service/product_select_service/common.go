package product_select_service

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"strconv"
	"time"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/analysis"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	analysis2 "code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/product_select"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/jsonx"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"code.byted.org/temai/go_portal_sdk/models"
	"github.com/bytedance/sonic"
	"github.com/mohae/deepcopy"
	"github.com/sanity-io/litter"
)

type IProductSelectService interface {
	ICreateAndUpdateProductSelectTask(ctx context.Context, req *product_select.CreateAndUpdateProductSelectTaskRequest) (*product_select.CreateAndUpdateProductSelectTaskResponse, error)
	IGetProductSelectTaskList(ctx context.Context, req *product_select.GetProductSelectTaskListRequest) (*product_select.GetProductSelectTaskListResponse, error)
	IGetProductSelectTaskDetail(ctx context.Context, req *product_select.GetProductSelectTaskDetailRequest) (*product_select.GetProductSelectTaskDetailResponse, error)
	IGetProdDetailList(ctx context.Context, req *product_select.GetProdDetailListRequest) (*product_select.GetProdDetailListResponse, error)
	IGetProdDetailList2(ctx context.Context, req *product_select.GetProdDetailListRequest) (*product_select.GetProdDetailListResponse, error)
	IGetProductSelectAdministratorConfig(ctx context.Context, req *product_select.GetProductSelectAdministratorConfigRequest) (*product_select.GetProductSelectAdministratorConfigResponse, error)
	IGetProductSelectTaskPreviewResult(ctx context.Context, req *product_select.GetProductSelectTaskPreviewResultRequest) (*product_select.GetProductSelectTaskPreviewResultResponse, error)
	IGetUserPrivilege(ctx context.Context, req *product_select.GetUserPrivilegeRequest) (*product_select.GetUserPrivilegeResponse, error)
}

type ProductSelectService struct {
	SelectTaskDao dao.IProductSelectTaskDao
}

func filterReqInValidDimensionList(dimensionList []*dimensions.SelectedDimensionInfo) []*dimensions.SelectedDimensionInfo {
	ret := make([]*dimensions.SelectedDimensionInfo, 0, len(dimensionList))
	for _, dimension := range dimensionList {
		if dimension == nil {
			continue
		}
		if len(dimension.Id) == 0 || len(dimension.SelectedValues) == 0 {
			continue
		}

		ret = append(ret, dimension)
	}

	return ret
}

func (d *ProductSelectService) ICreateAndUpdateProductSelectTask(ctx context.Context, req *product_select.CreateAndUpdateProductSelectTaskRequest) (resp *product_select.CreateAndUpdateProductSelectTaskResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] ICreateAndUpdateProductSelectTask failed, err:%s", err)
		}
	}()

	if req == nil || req.Task == nil {
		return nil, errors.New("[ICreateAndUpdateProductSelectTask] invalid params")
	}

	// 过滤入参中不符合规定的规则列表
	req.Dimensions = filterReqInValidDimensionList(req.Dimensions)
	if len(req.Dimensions) == 0 {
		return nil, errors.New("ICreateAndUpdateProductSelectTask invalid DimensionsParams")
	}

	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.EmployeeId == nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] failed, userInfo is nil")
		return nil, errors.New("[ICreateAndUpdateProductSelectTask] userInfo is nil")
	}

	// 权限检查：获取用户权限角色
	bizType := req.Task.BizType
	if bizType == dimensions.BizType_Unknown {
		bizType = dimensions.BizType_ProdSelectAlgorithm
	}
	if req.Task.Extra != nil {
		if req.Task.Extra.BusinessType > 0 {
			bizType = consts.BusinessType2BizType[req.Task.Extra.BusinessType]
			req.Task.BizType = bizType
		}
		if bizType != dimensions.BizType_ProdSelectNavigation && req.Task.Extra.IsManual {
			if biz_info.IsUseNewManualTask(ctx) {
				bizType = dimensions.BizType_ProdSelectManual
				req.Task.BizType = bizType
			}
		}
	}
	role, err := d.getUserPermissionRole(ctx, *userInfo.EmployeeId, bizType)
	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] getUserPermissionRole error, err: %s", err.Error())
		return nil, err
	}
	if role == "" {
		return nil, errors.New("[ICreateAndUpdateProductSelectTask] permission denied")
	}

	// 检查入参的Dimensions列表是否包含所有必需的维度
	if !d.checkRequiredDimensions(ctx, req, userInfo) {
		logs.CtxError(ctx, "ICreateAndUpdateProductSelectTask failed: missing required dimensions")
		return nil, errors.New("ICreateAndUpdateProductSelectTask failed: missing required dimensions")
	}

	taskIdInt := convert.ToInt64(req.Task.TaskId)
	if taskIdInt != 0 {
		originTaskList, _, err := d.SelectTaskDao.GetProductSelectTaskList(ctx, &dao.ProductSelectTaskQueryParams{
			TaskId: taskIdInt,
		})
		if len(originTaskList) == 0 {
			logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] failed, no task found, taskId: %d", taskIdInt)
			return nil, errors.New(fmt.Sprintf("taskId:%d not exist", taskIdInt))
		}

		originTask := originTaskList[0]

		// 解析Extra
		extra := &product_select.Extra{}
		if originTask.Extra != "" {
			err := sonic.UnmarshalString(originTask.Extra, extra)
			if err != nil {
				logs.CtxError(ctx, "ProductSelectTaskWorker, parse extra failed, err: %s, extra: %s", err, originTask.Extra)
				return nil, errors.New(fmt.Sprintf("ProductSelectTaskWorker, parse extra failed, err: %s", err))
			}
		}

		// 解析PoolRule
		poolRule := &dimensions.ProductAnalysisBaseStruct{}
		if originTask.PoolRule != "" {
			err := sonic.UnmarshalString(originTask.PoolRule, poolRule)
			if err != nil {
				logs.CtxError(ctx, "ProductSelectTaskWorker, parse PoolRule failed, err: %s, poolRule: %s", err, originTask.PoolRule)
				return nil, errors.New(fmt.Sprintf("ProductSelectTaskWorker, parse PoolRule failed, err: %s", err))
			}
		}
		poolRule.Dimensions = req.Dimensions
		poolRuleStr, _ := sonic.MarshalString(poolRule)
		extra.PoolRule = poolRuleStr

		if len(req.SelectedPageModuleConfig) > 0 {
			selectedPageModuleConfigStr, _ := sonic.MarshalString(req.SelectedPageModuleConfig)
			extra.SelectedPageModuleConfig = selectedPageModuleConfigStr
		}

		extraStr, _ := sonic.MarshalString(extra)

		newTask := &dao.ProductSelectTask{
			TaskId:       originTask.TaskId,
			TaskName:     originTask.TaskName,
			TargetAmount: originTask.TargetAmount,
			BizType:      originTask.BizType,
			IsDelete:     originTask.IsDelete,
			PoolId:       originTask.PoolId,
			PoolRule:     poolRuleStr,
			Extra:        extraStr,
		}
		if req.Task.TaskName != "" {
			newTask.TaskName = req.Task.TaskName
		}
		if req.Task.TargetAmount != 0 {
			newTask.TargetAmount = req.Task.TargetAmount
		}
		if req.Task.IsDel != 0 {
			newTask.IsDelete = int(req.Task.IsDel)
		}
		newTask.UpdateUserId = *userInfo.EmployeeId

		err = d.SelectTaskDao.UpdateProductSelectTask(ctx, taskIdInt, newTask)
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] UpdateProductSelectTask err: %s", err)
			return nil, err
		}

		go func() {
			defer func() {
				if err := recover(); err != nil {
					logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] panic, while execute ProductSelectTaskWorker: %s", err)
				}
			}()
			ProductSelectTaskWorker(ctx, newTask, true)
		}()

		return &product_select.CreateAndUpdateProductSelectTaskResponse{
			Data: true,
		}, nil
	}

	if req.Task.Extra == nil {
		return nil, errors.New("ICreateAndUpdateProductSelectTask invalid ExtraParams")
	}
	if req.Task.Extra.BusinessType == product_select.BusinessType_AggregationLinks || req.Task.Extra.BusinessType == product_select.BusinessType_FastConsumer {
		return nil, errors.New("ICreateAndUpdateProductSelectTask invalid BusinessTypeParams")
	}

	extra := product_select.Extra{}
	var businessType product_select.BusinessType
	isManual := false
	if req.Task.Extra != nil {
		isManual = req.Task.Extra.IsManual
		extra.IsManual = isManual
		if isManual {
			businessType = product_select.BusinessType_ZeroSubsidyExplode
		}

		if req.Task.Extra.BusinessType != product_select.BusinessType_Unknown { // todo 后续去除
			businessType = req.Task.Extra.BusinessType
		} else {
			if _, exist := consts.BizType2BusinessType[bizType]; exist {
				businessType = consts.BizType2BusinessType[bizType]
			}
		}
		extra.BusinessType = businessType
	}
	featureInfo, err := getFeatureInfo(ctx, businessType)
	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] getZeroSubsidyFeatureInfo failed, err: %s", err)
	} else {
		extra.ZeroSubsidyExplodeFeature = featureInfo
	}
	if bizType == dimensions.BizType_ProdSelectNavigation {
		selectedPageModuleConfigStr, _ := sonic.MarshalString(req.SelectedPageModuleConfig)
		extra.SelectedPageModuleConfig = selectedPageModuleConfigStr
	}

	extraStr, _ := sonic.MarshalString(extra)

	taskInfo := &dao.ProductSelectTask{
		BizType:      convert.ToInt64(req.Task.BizType),
		TaskName:     req.Task.TaskName,
		TargetAmount: convert.ToInt64(req.Task.TargetAmount),
		CreateUserId: *userInfo.EmployeeId,
		IsDelete:     int(req.Task.IsDel),
		TaskStatus:   0,
		Extra:        extraStr,
	}

	tableAPI := getOneServiceTableAPI(ctx, bizType, businessType)
	newestDay, err := utils.GetNewestDay(ctx, tableAPI)
	minNewTime, _ := time.Parse(consts.FmtDate, newestDay)
	if len(req.Dimensions) > 0 {
		poolRule := &dimensions.ProductAnalysisBaseStruct{
			BizType:          bizType,
			StartDate:        minNewTime.Format(consts.FmtDateSlash),
			EndDate:          minNewTime.Format(consts.FmtDateSlash),
			CompareStartDate: minNewTime.Format(consts.FmtDateSlash),
			CompareEndDate:   minNewTime.Format(consts.FmtDateSlash),
			Dimensions:       req.Dimensions,
		}
		poolRuleStr, err := sonic.MarshalString(poolRule)
		if err != nil {
			logs.CtxError(ctx, "ICreateAndUpdateProductSelectTask sonic.MarshalString err: %s", err.Error())
			return nil, err
		}
		taskInfo.PoolRule = poolRuleStr
	}
	logs.CtxInfo(ctx, "ICreateAndUpdateProductSelectTask taskInfo, %s", jsonx.ToString(taskInfo))

	err = d.SelectTaskDao.CreateProductSelectTask(ctx, taskInfo)

	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] CreateProductSelectTask err: %s", err)
		return nil, err
	}

	go func() {
		defer func() {
			if err := recover(); err != nil {
				logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] panic, while execute ProductSelectTaskWorker: %s", err)
			}
		}()
		ProductSelectTaskWorker(ctx, taskInfo, false)
	}()

	return &product_select.CreateAndUpdateProductSelectTaskResponse{
		Data: true,
	}, nil
}

func (d *ProductSelectService) IGetProductSelectTaskList(ctx context.Context, req *product_select.GetProductSelectTaskListRequest) (resp *product_select.GetProductSelectTaskListResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[IGetProductSelectTaskList] IGetProductSelectTaskList failed, err: %s", err)
		}
	}()

	if req == nil {
		return nil, errors.New("[IGetProductSelectTaskList] invalid params")
	}

	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.Id == nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProductSelectTask] failed, userInfo is nil")
		return nil, errors.New("[ICreateAndUpdateProductSelectTask] userInfo is nil")
	}

	reportList, count, err := d.SelectTaskDao.GetProductSelectTaskList(ctx, &dao.ProductSelectTaskQueryParams{
		CreateUserId: req.CreateUserId,
		IsDeleted:    0,
		PageNum:      int(req.PageNum),
		PageSize:     int(req.PageSize),
	})

	if err != nil {
		logs.CtxError(ctx, "[IGetProductSelectTaskList] IGetProductSelectTaskList failed, err: %s", err)
		return nil, err
	}

	return &product_select.GetProductSelectTaskListResponse{
		Data:       TransProductSelectTaskDao(reportList),
		TotalCount: count,
	}, nil
}

func (d *ProductSelectService) IGetProductSelectTaskDetail(ctx context.Context, req *product_select.GetProductSelectTaskDetailRequest) (resp *product_select.GetProductSelectTaskDetailResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[IGetProductSelectTaskDetail] IGetProductSelectTaskDetail failed, err: %s", err)
		}
	}()

	if req == nil {
		return nil, errors.New("[IGetProductSelectTaskDetail] invalid params")
	}

	taskId, err := strconv.ParseInt(req.TaskId, 10, 64)
	if err != nil {
		logs.CtxError(ctx, "[IGetProductSelectTaskDetail] parse task id failed, err: %s", err)
		return nil, err
	}

	reportList, _, err := d.SelectTaskDao.GetProductSelectTaskList(ctx, &dao.ProductSelectTaskQueryParams{
		TaskId:    taskId,
		IsDeleted: 0,
	})

	if err != nil {
		logs.CtxError(ctx, "[IGetProductSelectTaskDetail] IGetProductSelectTaskDetail failed, err: %s", err)
		return nil, err
	}
	if len(reportList) == 0 {
		logs.CtxError(ctx, "[IGetProductSelectTaskDetail] IGetProductSelectTaskDetail failed, reportList empty")
		return nil, errors.New("record not found")
	}
	if len(reportList) > 1 {
		logs.CtxError(ctx, "[IGetProductSelectTaskDetail] IGetProductSelectTaskDetail failed, reportList:%s", jsonx.ToString(reportList))
		reportList = []*dao.ProductSelectTask{reportList[0]}
	}

	task := TransProductSelectTaskDao(reportList)[0]
	if task == nil {
		return &product_select.GetProductSelectTaskDetailResponse{}, nil
	}

	poolRule := dimensions.ProductAnalysisBaseStruct{}
	selectedModuleConfig := make(map[product_select.PageModuleType]*product_select.SelectedPageModuleConfig)

	if task.Extra != nil {
		if len(task.Extra.PoolRule) > 0 {
			if unmarshalErr := sonic.UnmarshalString(task.Extra.PoolRule, &poolRule); unmarshalErr != nil {
				logs.CtxError(ctx, "IGetProductSelectTaskDetail UnmarshalString poolRule error, %s", unmarshalErr.Error())
			}
		}

		if task.BizType == dimensions.BizType_ProdSelectNavigation {
			unmarshalErr := sonic.UnmarshalString(task.Extra.SelectedPageModuleConfig, &selectedModuleConfig)
			if unmarshalErr != nil {
				logs.CtxError(ctx, "[IGetProductSelectTaskDetail] UnmarshalString selectedModuleConfig err: %s", unmarshalErr.Error())
			}
		}
	}

	logs.CtxInfo(ctx, "IGetProductSelectTaskDetail Dimensions %s, selectedModuleConfig %s",
		jsonx.ToString(poolRule.Dimensions), jsonx.ToString(selectedModuleConfig))

	return &product_select.GetProductSelectTaskDetailResponse{
		Data:                     task,
		Dimensions:               poolRule.Dimensions,
		SelectedPageModuleConfig: selectedModuleConfig,
	}, nil
}

func getProdPortraitHandler() *analysis.ProdPortraitHandler {
	var DimensionListDao = &dao.DimensionListDao{}
	var DimensionEnumDao = &dao.DimensionEnumDao{}
	var AttributeDao = &dao.AttributeDao{}
	var DimensionBizListDao = &dao.DimensionBizListDao{}
	var DimensionService = &dimension_service.DimensionService{
		DimensionListDao:    DimensionListDao,
		DimensionEnumDao:    DimensionEnumDao,
		AttributeDao:        AttributeDao,
		DimensionBizListDao: DimensionBizListDao,
	}
	var ProdPortraitService = &prod_portrait.ProdPortraitService{
		DimensionListDao: DimensionListDao,
		DimensionEnumDao: DimensionEnumDao,
		AttributeDao:     AttributeDao,
		DimensionService: DimensionService,
	}

	return &analysis.ProdPortraitHandler{ProdPortraitService: ProdPortraitService}
}

func (d *ProductSelectService) GetTaskDetail(ctx context.Context, taskId int64) (*product_select.ProductSelectTask, error) {
	reportList, _, err := d.SelectTaskDao.GetProductSelectTaskList(ctx, &dao.ProductSelectTaskQueryParams{
		TaskId:    taskId,
		IsDeleted: 0,
	})

	if err != nil {
		logs.CtxError(ctx, "[IGetProductSelectTaskDetail] IGetProductSelectTaskDetail failed, err: %s", err)
		return nil, err
	}
	if len(reportList) == 0 {
		logs.CtxError(ctx, "[IGetProductSelectTaskDetail] IGetProductSelectTaskDetail failed, reportList empty")
		return nil, errors.New("record not found")
	}
	if len(reportList) > 1 {
		logs.CtxError(ctx, "[IGetProductSelectTaskDetail] IGetProductSelectTaskDetail failed, reportList:%s", jsonx.ToString(reportList))
		reportList = []*dao.ProductSelectTask{reportList[0]}
	}

	task := TransProductSelectTaskDao(reportList)[0]
	return task, nil
}

func (d *ProductSelectService) IGetProdDetailList(ctx context.Context, req *product_select.GetProdDetailListRequest) (resp *product_select.GetProdDetailListResponse, err error) {
	// 用户权限检查
	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.EmployeeId == nil {
		logs.CtxError(ctx, "[IGetProdDetailList] failed, userInfo is nil")
		return nil, errors.New("[IGetProdDetailList] userInfo is nil")
	}

	// 权限检查：获取用户权限角色
	// 从任务信息中获取bizType
	bizType := dimensions.BizType_ProdSelectAlgorithm
	if req.BaseReq.TaskId != nil && *req.BaseReq.TaskId != "" {
		taskId, _ := utils.String2Int64(*req.BaseReq.TaskId)
		task, pErr := d.GetTaskDetail(ctx, taskId)
		if pErr != nil {
			logs.CtxError(ctx, "[IGetProdDetailList] getProductSelectTaskById error, err: %s", pErr.Error())
			return nil, pErr
		}
		if task != nil {
			bizType = task.BizType
		}
	}

	role, err := d.getUserPermissionRole(ctx, *userInfo.EmployeeId, bizType)
	if err != nil {
		logs.CtxError(ctx, "[IGetProdDetailList] getUserPermissionRole error, err: %s", err.Error())
		return nil, err
	}
	if role == "" {
		return nil, errors.New("[IGetProdDetailList] permission denied")
	}

	// 创建事务
	poolRule := &dimensions.ProductAnalysisBaseStruct{}
	if len(req.BaseReq.GetTaskId()) > 0 {
		tx := mysql.DB(ctx).Begin()
		if tx.Error != nil {
			logs.CtxError(ctx, "IGetProdDetailList 获取数据库的事务失败，err=%v+", tx.Error.Error())
			return nil, errors.New("获取数据库的事务失败")
		}
		var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
		taskId, _ := utils.String2Int64(req.BaseReq.GetTaskId())
		taskInfo, err := ProductSelectTaskDao.GetProductSelectTask(ctx, tx, taskId)
		if err != nil {
			return nil, err
		}
		tx.Commit()

		// 解析Pool
		if taskInfo.PoolRule != "" {
			err := sonic.UnmarshalString(taskInfo.PoolRule, poolRule)
			if err != nil {
				logs.CtxError(ctx, "ProductSelectTaskWorker, parse extra failed, err: %s, poolRule: %s", err, taskInfo.PoolRule)
				return nil, err
			}
		}
	} else {
		poolRule = &dimensions.ProductAnalysisBaseStruct{
			BizType:    bizType,
			StartDate:  req.BaseReq.GetStartDate(),
			EndDate:    req.BaseReq.GetEndDate(),
			Dimensions: req.BaseReq.GetDimensions(),
		}
	}

	// 生成查询参数
	commonReq := common_request.CommonAnalysisRequest{
		BaseReq: poolRule,
	}
	commonReqStr, _ := sonic.MarshalString(commonReq)
	prodReq := &analysis2.GetPordDetailListRequest{
		BaseReq: &analysis2.ProdDetailBaseRequest{
			StartDate:  poolRule.StartDate,
			EndDate:    poolRule.EndDate,
			Router:     prod_portrait.ProductSelectProdDetailList,
			ReqMarshal: commonReqStr,
		},
		PageReq: req.PageReq,
		OrderBy: req.OrderBy,
		Base:    req.Base,
	}

	// 执行查询
	prodResp, err := getProdPortraitHandler().GetPordDetailList(ctx, prodReq)
	if err != nil {
		logs.CtxError(ctx, "IGetProdDetailList GetPordDetailList error, %s", err.Error())
		return nil, err
	}

	resp = &product_select.GetProdDetailListResponse{
		Data: &product_select.GetProdDetailListData{
			PageInfo:    prodResp.Data.PageInfo,
			ProductList: prodResp.Data.ProductList,
		},
	}

	return resp, nil
}

func (d *ProductSelectService) IGetProdDetailList2(ctx context.Context, req *product_select.GetProdDetailListRequest) (resp *product_select.GetProdDetailListResponse, err error) {
	var prodSubSql string
	var appendParams map[string]interface{}
	var bizType dimensions.BizType
	var osReq base_struct_condition.OsParamsReq

	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, "[CreateAnalysisPool]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return nil, errors.New("获取数据库的事务失败")
	}
	var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
	taskId, _ := utils.String2Int64(req.BaseReq.GetTaskId())
	taskInfo, err := ProductSelectTaskDao.GetProductSelectTask(ctx, tx, taskId)
	if err != nil {
		return nil, err
	}
	tx.Commit()

	// 解析Pool
	poolRule := &dimensions.ProductAnalysisBaseStruct{}
	if taskInfo.PoolRule != "" {
		err := sonic.UnmarshalString(taskInfo.PoolRule, poolRule)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker, parse extra failed, err: %s, poolRule: %s", err, taskInfo.PoolRule)
		}
	}

	dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, dimensions.BizType(taskInfo.BizType))
	if err != nil {
		logs.CtxError(ctx, "[GetProdPortrait]获取map失败，err=%v+", err)
		return nil, err
	}
	// 如果没传order by 参数，默认根据show_pv排序
	if req.OrderBy == nil {
		var orderField = base.OrderByField_ShowPv
		req.OrderBy = &base.OrderByInfo{
			Field:  &orderField,
			IsDesc: true,
		}
	}
	osReq = base_struct_condition.OsParamsReq{
		BaseStruct: poolRule,
		DimMap:     dimMap,
		PageInfo:   req.PageReq,
		OrderBy:    req.OrderBy,
	}

	logs.CtxInfo(ctx, "IGetProdDetailList osReq, %s", jsonx.ToString(osReq))
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, osReq, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "IGetProdDetailList GetBaseStructConditionParam error, %s", err.Error())
		return nil, err
	}

	// 解析extra
	extra := &product_select.Extra{}
	if taskInfo.Extra != "" {
		err := sonic.UnmarshalString(taskInfo.Extra, extra)
		if err != nil {
			logs.CtxError(ctx, "ProductSelectTaskWorker, parse extra failed, err: %s, extra: %s", err, taskInfo.Extra)
		}
	}

	curr["table_name"] = ""
	if len(prodSubSql) > 0 {
		curr["prod_sub_sql"] = prodSubSql
	}
	if len(appendParams) > 0 {
		for k, v := range appendParams {
			curr[k] = v
		}
	}
	logs.CtxInfo(ctx, "IGetProdDetailList curr, %s", jsonx.ToString(curr))

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)

	f := flow.Empty()
	// 输入商品id信息，拿到商品图片信息
	f.ExeQueryInvokerRaw(curr,
		biz_utils.ApiPathMap[dimensions.BizType(taskInfo.BizType)].ProdDetailPath,
		param.SinkTable("product_detail")).SetParallel(true).SetMaxParallelNum(5)
	f.ExeProduceCustom([]param.Source{param.SourceTable("product_detail")},
		analysis_service.AddProductImage,
		param.SinkTable("product_images"))

	f.ExeProduceSql(fmt.Sprintf(`
		select  a.prod_id as prod_id,
				b.images as prod_images,
				a.prod_name as prod_name,
				shop_id,
				shop_name,
				brand_name,
				complex_brand_s_level as brand_level,
				show_pv,
				pay_ord_cnt as order_num,
				industry_name,
				first_level_cate_name,
				second_level_cate_name,
				leaf_cate_name
		from    product_detail a
		left join
				product_images b
		on      a.prod_id=b.prod_id
		where %s
	`, curr["filter_param"]), param.SinkTable("res_data"))

	var productInfoList = make([]*analysis_service.ProductInfo, 0)
	f.ExeView(param.SourceTable("res_data"), &productInfoList)

	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	logs.CtxInfo(ctx, "productInfoList = "+litter.Sdump(productInfoList))
	productList, err := PackProductDetail(productInfoList, bizType)
	resp = &product_select.GetProdDetailListResponse{
		Data: &product_select.GetProdDetailListData{
			PageInfo: &base.PageResp{},
		},
	}
	resp.Data.ProductList = productList
	if err != nil {
		logs.CtxError(ctx, "打包结果数据失败,err:"+err.Error())
		return nil, err
	}

	return resp, nil
}

func PackProductDetail(productInfoList []*analysis_service.ProductInfo, bizType dimensions.BizType) ([]*analysis2.MultiDimProductInfo, error) {
	resp := make([]*analysis2.MultiDimProductInfo, 0)

	for _, info := range productInfoList {
		// 对target_list进行排序
		if len(info.TargetList) > 0 {
			sort.Slice(info.TargetList, func(i, j int) bool {
				return info.TargetList[i].DisplayOrder < info.TargetList[j].DisplayOrder
			})
		}
		productInfo := &analysis2.MultiDimProductInfo{
			ProductInfo: &basic_info.ProductBasicInfo{Id: info.ProdId, Name: info.ProdName, Images: info.ProdImages},
			ShopInfo:    &basic_info.ShopBasicInfo{Id: info.ShopId, Name: info.ShopName},
			BrandInfo:   &basic_info.BrandBasicInfo{Name: info.BrandName, Level: info.BrandLevel},
			SkuInfo: &basic_info.SkuBasicInfo{Id: info.SkuId, Name: info.SkuName,
				SkuClusterId: info.SkuClusterId, SkuClusterName: info.SkuClusterName,
				OutComparePriceTag: info.OutComparePriceTag, InComparePriceTag: info.InComparePriceTag},
			ShowPv:              info.ShowPv,
			OrderNum:            info.OrderNum,
			IndustryName:        info.IndustryName,
			FirstLevelCateName:  info.FirstLevelCateName,
			SecondLevelCateName: info.SecondLevelCateName,
			LeafCateName:        info.LeafCateName,
			DimMap:              make(map[string]string),
		}
		if bizType == dimensions.BizType_MorningMarketProduct {
			productInfo.DimMap["早市商品分层"] = info.ProdLevel
		}
		resp = append(resp, productInfo)
	}

	return resp, nil
}

// IGetUserPrivilege 获取用户在产品选择功能中的权限级别
func (d *ProductSelectService) IGetUserPrivilege(ctx context.Context, req *product_select.GetUserPrivilegeRequest) (*product_select.GetUserPrivilegeResponse, error) {
	// 初始化响应对象
	resp := &product_select.GetUserPrivilegeResponse{}

	// 获取业务类型和员工ID
	bizType := req.GetBizType()
	employeeId := req.GetEmployeeId()

	role, err := d.getUserPermissionRole(ctx, employeeId, bizType)
	if err != nil {
		logs.CtxError(ctx, "IGetProductSelectAdministratorConfig getUserPermissionRole error, err: %s", err.Error())
		// 不返回错误，继续执行，使用空角色
		role = ""
	}

	privilegeConfig, err := biz_info.GetProductSelectBizTypePrivilegeConfig(ctx, bizType)
	if err != nil {
		return nil, err
	}

	if role == "" { // 无权限
		// 去除管理员权限, 管理员权限不通过界面申请
		privilegeIdCanApply := make(map[string]bool)
		for privilegeId, privilegeType := range privilegeConfig.PrivilegeIDToPrivilegeType {
			if product_select.PrivilegeType(privilegeType) != product_select.PrivilegeType_Administrator {
				privilegeIdCanApply[privilegeId] = true
			}
		}
		canApplySecondaryIdList := make([]string, 0)
		for _, privilegeId := range privilegeConfig.PrivilegeSecondaryIDList {
			if privilegeIdCanApply[privilegeId] {
				canApplySecondaryIdList = append(canApplySecondaryIdList, privilegeId)
			}
		}
		canApplyPrivilege := &product_select.PrivilegeItem{
			DataPrivilegeId:              &privilegeConfig.PrivilegeID,
			DataPrivilegePrimaryId:       &privilegeConfig.PrivilegePrimaryID,
			DataPrivilegeSecondaryIdList: canApplySecondaryIdList,
		}
		resp.CanApplyPrivilege = canApplyPrivilege
	} else { // 有权限
		appliedPrivilege := &product_select.PrivilegeItem{
			DataPrivilegeId:              &privilegeConfig.PrivilegeID,
			DataPrivilegePrimaryId:       &privilegeConfig.PrivilegePrimaryID,
			DataPrivilegeSecondaryIdList: []string{role},
		}
		resp.AppliedPrivilege = appliedPrivilege
		privilegeType := privilegeConfig.PrivilegeIDToPrivilegeType[role]
		resp.PrivilegeType = product_select.PrivilegeType(privilegeType)
	}

	return resp, nil
}

// checkRequiredDimensions 检查入参的Dimensions列表是否包含所有必需的维度
func (d *ProductSelectService) checkRequiredDimensions(ctx context.Context,
	req *product_select.CreateAndUpdateProductSelectTaskRequest, userInfo *models.UserInfo) bool {
	// 获取用户权限角色
	reqDimensions := req.Dimensions
	bizType := req.Task.BizType
	if bizType == dimensions.BizType_Unknown { // 人工选品, 使用0补爆品的权限
		bizType = dimensions.BizType_ProdSelectAlgorithm
	}

	role, err := d.getUserPermissionRole(ctx, *userInfo.EmployeeId, bizType)
	if err != nil {
		logs.CtxError(ctx, "IGetProductSelectAdministratorConfig getUserPermissionRole error, err: %s", err.Error())
		// 不返回错误，继续执行，使用空角色
		role = ""
	}

	// 获取角色对应的维度列表
	var requiredDimensions []*dimensions.SelectedDimensionInfo
	if role != "" {
		roleDimensionConfig, err := biz_info.GetProductSelectRoleDimensionConfig(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "IGetProductSelectAdministratorConfig GetProductSelectRoleDimensionConfig error, err: %s", err.Error())
			// 不返回错误，继续执行，使用空列表
		} else {
			requiredDimensions = roleDimensionConfig[role]
		}
	}

	if len(requiredDimensions) == 0 {
		// 没有必需的维度，直接返回true
		return true
	}

	// 将入参的维度ID和SelectedValues转换为map，便于查找
	reqDimensionMap := make(map[string]*dimensions.SelectedDimensionInfo)
	for _, dimension := range reqDimensions {
		reqDimensionMap[dimension.Id] = dimension
	}

	// 检查是否包含所有必需的维度和对应的SelectedValues
	for _, requiredDimension := range requiredDimensions {
		// 检查维度ID是否存在
		reqDimension, exists := reqDimensionMap[requiredDimension.Id]
		if !exists {
			// 缺少必需的维度
			logs.CtxError(ctx, "checkRequiredDimensions failed: missing required dimension %s", requiredDimension.Id)
			return false
		}

		// 检查SelectedValues是否包含关系
		if len(requiredDimension.SelectedValues) > 0 {
			// 将入参的SelectedValues转换为map，便于查找
			reqSelectedValuesMap := make(map[string]bool)
			for _, value := range reqDimension.SelectedValues {
				reqSelectedValuesMap[value.Code] = true
			}

			// 检查入参的SelectedValues是否包含必需的所有SelectedValues
			for _, requiredValue := range requiredDimension.SelectedValues {
				if !reqSelectedValuesMap[requiredValue.Code] {
					// 入参的SelectedValues缺少必需的取值
					logs.CtxError(ctx, "checkRequiredDimensions failed: dimension %s missing required selected value %s",
						requiredDimension.Id, requiredValue.Code)
					return false
				}
			}
		}
	}

	// 包含所有必需的维度和对应的SelectedValues
	return true
}

// getUserPermissionRole 获取用户的权限角色
func (d *ProductSelectService) getUserPermissionRole(ctx context.Context,
	employeeId string, bizType dimensions.BizType) (string, error) {
	// 如果GetDimensionsByUser失败或未找到权限，调用GetUserDimension
	userDimensionResp, err := utils.GetUserDimensionWithCache(ctx, employeeId)
	if err != nil {
		logs.CtxError(ctx, "getUserPermissionRole GetUserDimension error, err: %s", err.Error())
		return "", err
	}
	logs.CtxInfo(ctx, "getUserPermissionRole GetUserDimension, %s", jsonx.ToString(userDimensionResp))

	if userDimensionResp == nil {
		return "", errors.New("response is nil")
	}
	userDimensionCodeMap := make(map[string]bool)
	for _, dimension := range userDimensionResp.Dimension.Values {
		userDimensionCodeMap[dimension.Code] = true
	}

	targetCode := ""
	// 从TCC获取bizType对应的维度列表
	dimensionsList, err := biz_info.GetProductSelectBizTypeSecondaryIdList(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "getUserPermissionRole GetProductSelectBizTypeSecondaryIdList error, err: %s", err.Error())
		// 不返回错误，继续执行
		dimensionsList = []string{}
	}

	// 遍历维度列表，查找用户拥有的维度
	for _, dimension := range dimensionsList {
		if userDimensionCodeMap[dimension] {
			targetCode = dimension
			break
		}
	}

	return targetCode, nil
}

func (d *ProductSelectService) IGetProductSelectAdministratorConfig(ctx context.Context, req *product_select.GetProductSelectAdministratorConfigRequest) (resp *product_select.GetProductSelectAdministratorConfigResponse, err error) {
	// 获取用户信息
	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.EmployeeId == nil {
		logs.CtxError(ctx, "IGetProductSelectAdministratorConfig failed, userInfo is nil")
		return nil, errors.New("userInfo is nil")
	}

	// 获取管理员配置
	configMap, err := biz_info.GetProductSelectAdministratorConfig(ctx, int64(req.GetBizType()))
	if err != nil {
		logs.CtxError(ctx, "IGetProductSelectAdministratorConfig GetProductSelectAdministratorConfig error, err: %s", err.Error())
	}
	logs.CtxInfo(ctx, "IGetProductSelectAdministratorConfig GetProductSelectAdministratorConfig, %s", jsonx.ToString(configMap))

	// 获取快速维度配置
	quickDimensions, err := biz_info.GetProductSelectQuickDimensionsConfig(ctx, int64(req.GetBizType()))
	if err != nil {
		logs.CtxError(ctx, "IGetProductSelectAdministratorConfig GetProductSelectQuickDimensionsConfig error, err: %s", err.Error())
	}

	// 从TCC获取选品类型配置
	typeConfigs, err := biz_info.GetProductSelectTypeConfigs(ctx)
	if err != nil {
		// 读取失败时不中断流程, 记录英文日志并降级为空列表
		logs.CtxError(ctx, "IGetProductSelectAdministratorConfig GetProductSelectTypeConfigs error, err: %s", err.Error())
		typeConfigs = []*product_select.ProductSelectTypeConfig{}
	} else {
		logs.CtxInfo(ctx, "IGetProductSelectAdministratorConfig type configs fetched, count=%d", len(typeConfigs))
	}

	bizType := req.GetBizType()
	if bizType == dimensions.BizType_Unknown {
		if req.GetBusinessType() != product_select.BusinessType_Unknown {
			bizType = consts.BusinessType2BizType[req.GetBusinessType()]
		} else { // 人工选品, 像0补爆品看齐
			bizType = dimensions.BizType_ProdSelectAlgorithm
		}
	}

	// 获取用户权限角色
	role, err := d.getUserPermissionRole(ctx, *userInfo.EmployeeId, bizType)
	if err != nil {
		logs.CtxError(ctx, "IGetProductSelectAdministratorConfig getUserPermissionRole error, err: %s", err.Error())
		// 不返回错误，继续执行，使用空角色
		role = ""
	}
	logs.CtxInfo(ctx, "IGetProductSelectAdministratorConfig getUserPermissionRole, %s", role)

	// 获取角色对应的维度列表
	var requiredDimensions []*dimensions.SelectedDimensionInfo
	if role != "" {
		roleDimensionConfig, err := biz_info.GetProductSelectRoleDimensionConfig(ctx, bizType)
		if err != nil {
			logs.CtxError(ctx, "IGetProductSelectAdministratorConfig GetProductSelectRoleDimensionConfig error, err: %s", err.Error())
			// 不返回错误，继续执行，使用空列表
		} else {
			requiredDimensions = roleDimensionConfig[role]
		}
	}

	pageModule := make(map[product_select.PageModuleType]*product_select.PageModuleConfig)
	if bizType == dimensions.BizType_ProdSelectNavigation {
		pageModule[product_select.PageModuleType_HotSale] = &product_select.PageModuleConfig{
			DimensionIds: []string{
				"10627",
				"10628",
			},
			ThresholdAttrIds: []string{
				"proportion_gmv_absolute_date",
				"proportion_gmv_relative_date",
			},
		}
		pageModule[product_select.PageModuleType_Addition] = &product_select.PageModuleConfig{
			DimensionIds: []string{
				"10627",
				"10628",
			},
			ThresholdAttrIds: []string{
				"top_gmv_relative_date",
				"top_gmv_absolute_date",
			},
		}
	}

	resp = &product_select.GetProductSelectAdministratorConfigResponse{
		TargetDimensions:   configMap["target_dimensions"],
		FeatureDimensions:  configMap["feature_dimensions"],
		QuickDimensions:    quickDimensions,
		RequiredDimensions: requiredDimensions,
		TypeConfigs:        typeConfigs,
		PageModuleConfig:   pageModule,
	}
	logs.CtxInfo(ctx, "IGetProductSelectAdministratorConfig resp, %s", jsonx.ToString(resp))

	return resp, nil
}

func (d *ProductSelectService) IGetProductSelectTaskPreviewResult(ctx context.Context, req *product_select.GetProductSelectTaskPreviewResultRequest) (resp *product_select.GetProductSelectTaskPreviewResultResponse, err error) {
	defaultBizType := dimensions.BizType_ProdSelectAlgorithm
	if req.GetBizType() == dimensions.BizType_Unknown {
		req.BizType = &defaultBizType
	}

	poolRule := &dimensions.ProductAnalysisBaseStruct{}
	selectedModuleConfig := make(map[product_select.PageModuleType]*product_select.SelectedPageModuleConfig)
	if req.PreviewScene == product_select.PreviewScene_TaskResult {
		tx := mysql.DB(ctx).Begin()
		if tx.Error != nil {
			logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult 获取数据库的事务失败，err=%v+", tx.Error.Error())
			return nil, errors.New("获取数据库的事务失败")
		}
		var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
		taskId, _ := utils.String2Int64(req.GetTaskId())
		taskInfo, err := ProductSelectTaskDao.GetProductSelectTask(ctx, tx, taskId)
		if err != nil {
			return nil, err
		}
		tx.Commit()

		// 解析Pool
		if taskInfo.PoolRule != "" {
			err := sonic.UnmarshalString(taskInfo.PoolRule, poolRule)
			if err != nil {
				logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult, parse extra failed, err: %s, poolRule: %s", err, taskInfo.PoolRule)
				return nil, err
			}
		}

		// 解析extra
		extra := &product_select.Extra{}
		if taskInfo.Extra != "" {
			err := sonic.UnmarshalString(taskInfo.Extra, extra)
			if err != nil {
				logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult, parse extra failed, err: %s, extra: %s", err, taskInfo.Extra)
				return nil, err
			}
		}
		poolRule.StartDate = req.GetStartDate()
		poolRule.EndDate = req.GetEndDate()

		// 解析任务的extra字段，获取SelectedPageModuleConfig
		if taskInfo.Extra != "" {
			extra := &product_select.Extra{}
			err = sonic.UnmarshalString(taskInfo.Extra, extra)
			if err != nil {
				logs.CtxError(ctx, "[DownloadAnalysisPoolProductList]解析extra失败，err=%v+, extra=%v", err, taskInfo.Extra)
			} else {
				unmarshalErr := sonic.UnmarshalString(extra.SelectedPageModuleConfig, &selectedModuleConfig)
				if unmarshalErr != nil {
					logs.CtxError(ctx, "[IGetProductSelectTaskDetail] UnmarshalString err: %s", unmarshalErr.Error())
				}
				logs.CtxInfo(ctx, "[DownloadAnalysisPoolProductList]获取SelectedPageModuleConfig成功，config=%v", selectedModuleConfig)
			}
		}

	} else if req.PreviewScene == product_select.PreviewScene_TaskCreate {
		poolRule.BizType = req.GetBizType()
		poolRule.Dimensions = req.Dimensions
		poolRule.StartDate = req.GetStartDate()
		poolRule.EndDate = req.GetEndDate()
		selectedModuleConfig = req.SelectedPageModuleConfig
	}

	// 获取特征参数
	dimMap, err := new(dao.DimensionListDao).GetDimensionMap(ctx, req.GetBizType())
	if err != nil {
		logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult 获取map失败，err=%v+", err)
		return
	}

	params := make(map[string]interface{})
	if poolRule.BizType == dimensions.BizType_ProdSelectNavigation {
		params["date"] = poolRule.EndDate
		rawDimensions := deepcopy.Copy(poolRule.Dimensions).([]*dimensions.SelectedDimensionInfo)

		// 赛道
		filterDimensionsInit := deepcopy.Copy(rawDimensions)
		filterDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
		for _, fd := range filterDimensionsInit.([]*dimensions.SelectedDimensionInfo) {
			if fd.Id == "10520" || fd.Id == "10521" || fd.Id == "10522" || fd.Id == "10523" {
				filterDimensions = append(filterDimensions, fd)
			}
		}
		poolRule.Dimensions = filterDimensions
		vblineParams, _ := base_struct_condition.GetBaseStructConditionParam(ctx,
			base_struct_condition.OsParamsReq{
				BaseStruct: poolRule,
				DimMap:     dimMap,
			},
			base_struct_condition.SQLCalcType_Curr,
		)
		params["vbline_filter_param"] = vblineParams["filter_param"]

		// 热销
		navigationDimensions := deepcopy.Copy(rawDimensions).([]*dimensions.SelectedDimensionInfo)
		navigationDimensions = append(navigationDimensions, selectedModuleConfig[product_select.PageModuleType_HotSale].Dimensions...)
		poolRule.Dimensions = navigationDimensions
		if len(selectedModuleConfig[product_select.PageModuleType_HotSale].ThresholdAttrs) == 0 {
			return nil, errors.New("ThresholdAttrs is nil")
		}
		navigationAttr := selectedModuleConfig[product_select.PageModuleType_HotSale].ThresholdAttrs[0]
		navigationStartDate, navigationEndDate, err := utils.GetStartDateAndEndDate(ctx, poolRule.EndDate, navigationAttr.DateRule)
		if err != nil {
			logs.CtxError(ctx, "GetStartDateAndEndDate error, %s", err.Error())
			return nil, err
		}
		params["navigation_start_date"] = navigationStartDate
		params["navigation_end_date"] = navigationEndDate
		params["gmv_threshold"] = navigationAttr.AccThreshold.GetThreshold()

		navigationParams, _ := base_struct_condition.GetBaseStructConditionParam(ctx,
			base_struct_condition.OsParamsReq{
				BaseStruct: poolRule,
				DimMap:     dimMap,
			},
			base_struct_condition.SQLCalcType_Curr,
		)
		params["navigation_filter_param"] = navigationParams["filter_param"]

		// 补品
		if additionConfig, exist := selectedModuleConfig[product_select.PageModuleType_Addition]; exist && additionConfig != nil && len(additionConfig.Dimensions) > 0 && len(additionConfig.ThresholdAttrs) > 0 {
			supplyDimensions := deepcopy.Copy(rawDimensions).([]*dimensions.SelectedDimensionInfo)
			supplyDimensions = append(supplyDimensions, selectedModuleConfig[product_select.PageModuleType_Addition].Dimensions...)
			poolRule.Dimensions = supplyDimensions
			supplyParams, _ := base_struct_condition.GetBaseStructConditionParam(ctx,
				base_struct_condition.OsParamsReq{
					BaseStruct: poolRule,
					DimMap:     dimMap,
				},
				base_struct_condition.SQLCalcType_Curr,
			)
			params["supply_filter_param"] = supplyParams["filter_param"]

			supplyAttr := selectedModuleConfig[product_select.PageModuleType_Addition].ThresholdAttrs[0]
			supplyStartDate, supplyEndDate, err := utils.GetStartDateAndEndDate(ctx, poolRule.EndDate, supplyAttr.DateRule)
			if err != nil {
				logs.CtxError(ctx, "GetStartDateAndEndDate error, %s", err.Error())
				return nil, err
			}
			params["supply_start_date"] = supplyStartDate
			params["supply_end_date"] = supplyEndDate
			params["top_threshold"] = supplyAttr.GetTopN()
		}

		logs.CtxInfo(ctx, "DownloadAnalysisPoolProductList navigation_filter_param, %s", jsonx.ToString(params))

		previewReq := base_struct_condition.GetTargetListWithKeyColumnReq{
			Params:  params,
			Sql:     consts.Empty,
			ApiPath: "7600040479975080987",
		}
		_, dataList, previewErr := base_struct_condition.GetDataListByOS(ctx, previewReq.Params, previewReq.Sql, previewReq.ApiPath)
		if previewErr != nil {
			logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult GetDataListByOS error, %s", previewErr.Error())
			return nil, previewErr
		}
		if len(dataList) == 0 {
			logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult GetDataListByOS dataList is nil")
			return nil, errors.New("dataList is nil")
		}

		logs.CtxInfo(ctx, "DownloadAnalysisPoolProductList navigation_filter_param, %s, %s", jsonx.ToString(params), jsonx.ToString(dataList))
		stringResult := make(map[product_select.TaskPreviewType]*analysis2.TargetCardEntity)
		stringResult[product_select.TaskPreviewType_HotSaleProductTotal] = &analysis2.TargetCardEntity{
			DisplayName:  "热销品商品数量",
			DisplayValue: convert.ToString(dataList[0][0]),
		}
		stringResult[product_select.TaskPreviewType_HotSaleProductGMV] = &analysis2.TargetCardEntity{
			DisplayName:  "热销品支付GMV (元)",
			DisplayValue: convert.ToString(dataList[0][1]),
		}
		stringResult[product_select.TaskPreviewType_AdditionProductTotal] = &analysis2.TargetCardEntity{
			DisplayName:  "补品商品数量",
			DisplayValue: convert.ToString(dataList[0][2]),
		}
		stringResult[product_select.TaskPreviewType_AdditionProductGMV] = &analysis2.TargetCardEntity{
			DisplayName:  "补品支付GMV (元)",
			DisplayValue: convert.ToString(dataList[0][3]),
		}
		stringResult[product_select.TaskPreviewType_AdditionFrameCount] = &analysis2.TargetCardEntity{
			DisplayName:  "补品覆盖领航框数量",
			DisplayValue: convert.ToString(dataList[0][4]),
		}
		stringResult[product_select.TaskPreviewType_HotSaleProductGMVRate] = &analysis2.TargetCardEntity{
			DisplayName:  "热销品支付GMV 渗透率",
			DisplayValue: convert.ToString(dataList[0][5]),
		}
		stringResult[product_select.TaskPreviewType_AdditionProductGMVRate] = &analysis2.TargetCardEntity{
			DisplayName:  "补品支付GMV 渗透率",
			DisplayValue: convert.ToString(dataList[0][6]),
		}
		resp = &product_select.GetProductSelectTaskPreviewResultResponse{}
		if len(stringResult) > 0 {
			resp.StringResult_ = stringResult
		}
		return resp, nil
	}
	// 生成参数
	originParams, err := base_struct_condition.GetBaseStructConditionParam(ctx,
		base_struct_condition.OsParamsReq{
			BaseStruct: poolRule,
			DimMap:     dimMap,
		},
		base_struct_condition.SQLCalcType_Curr,
	)
	if err != nil {
		logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult GetBaseStructConditionParams error, %s", err.Error())
		return
	}
	logs.CtxInfo(ctx, "IGetProductSelectTaskPreviewResult params: %s", jsonx.ToString(originParams))

	// 生成结果字段
	stringResult := make(map[product_select.TaskPreviewType]*analysis2.TargetCardEntity)
	trendResult := make(map[product_select.TaskPreviewType][]*analysis2.TargetTrendPoint)
	pieResult := make(map[product_select.TaskPreviewType]*analysis2.PieGraphItem)

	//lock := sync.Mutex{}
	//group := errgroup.Group{}

	for _, previewType_ := range req.PreviewTypes {
		previewType := previewType_
		params := deepcopy.Copy(originParams).(map[string]any)

		switch previewType {
		case product_select.TaskPreviewType_ProductTotal:
			params["count_param"] = "prod_id"
		case product_select.TaskPreviewType_BrandLevelDistribution:
			params["group_param"] = "complex_brand_s_level"
			params["count_param"] = "prod_id"
		case product_select.TaskPreviewType_ShopLevelDistribution:
			params["group_param"] = "shop_type_name"
			params["count_param"] = "prod_id"
		case product_select.TaskPreviewType_IndustryDistribution:
			params["group_param"] = "op_industry"
			params["count_param"] = "prod_id"
		case product_select.TaskPreviewType_ShopTotal:
			params["count_param"] = "shop_id"
		case product_select.TaskPreviewType_FirstCategoryTotal:
			params["count_param"] = "first_cid"
		case product_select.TaskPreviewType_LeafCategoryTotal:
			params["count_param"] = "leaf_cid"
		case product_select.TaskPreviewType_BrandTotal:
			params["count_param"] = "complex_brand_name"
		case product_select.TaskPreviewType_OrderTotal:
			params["count_param"] = "prod_pay_ord_cnt_30d"
		case product_select.TaskPreviewType_OPGroupDistribution:
			params["group_param"] = "op_group"
			params["count_param"] = "prod_id"
		default:
			logs.CtxWarn(ctx, "IGetProductSelectTaskPreviewResult default, %d", previewType)
		}

		previewReq := base_struct_condition.GetTargetListWithKeyColumnReq{
			Params:  params,
			Sql:     consts.Empty,
			ApiPath: OneServicePreviewAPIPath,
		}
		_, dataList, previewErr := base_struct_condition.GetDataListByOS(ctx, previewReq.Params, previewReq.Sql, previewReq.ApiPath)
		if previewErr != nil {
			logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult GetDataListByOS error, %s", previewErr.Error())
		}
		if len(dataList) == 0 {
			continue
		}

		switch previewType {
		case product_select.TaskPreviewType_ProductTotal:
			stringResult[previewType] = &analysis2.TargetCardEntity{
				DisplayName:  "圈品数量",
				DisplayValue: convert.ToString(dataList[0][0]),
			}
		case product_select.TaskPreviewType_ShopTotal:
			stringResult[previewType] = &analysis2.TargetCardEntity{
				DisplayName:  "店铺数量",
				DisplayValue: convert.ToString(dataList[0][0]),
			}
		case product_select.TaskPreviewType_FirstCategoryTotal:
			stringResult[previewType] = &analysis2.TargetCardEntity{
				DisplayName:  "一级类目数量",
				DisplayValue: convert.ToString(dataList[0][0]),
			}
		case product_select.TaskPreviewType_LeafCategoryTotal:
			stringResult[previewType] = &analysis2.TargetCardEntity{
				DisplayName:  "叶子类目数量",
				DisplayValue: convert.ToString(dataList[0][0]),
			}
		case product_select.TaskPreviewType_BrandTotal:
			stringResult[previewType] = &analysis2.TargetCardEntity{
				DisplayName:  "品牌数量",
				DisplayValue: convert.ToString(dataList[0][0]),
			}
		case product_select.TaskPreviewType_OrderTotal:
			stringResult[previewType] = &analysis2.TargetCardEntity{
				DisplayName:  "订单数量",
				DisplayValue: convert.ToString(dataList[0][0]),
			}
		case
			product_select.TaskPreviewType_BrandLevelDistribution,
			product_select.TaskPreviewType_ShopLevelDistribution,
			product_select.TaskPreviewType_IndustryDistribution,
			product_select.TaskPreviewType_OPGroupDistribution:

			// 总数量
			var totalCount float64 = 0
			for _, item := range dataList {
				if convert.ToString(item[0]) == "" {
					continue
				}
				totalCount += convert.ToFloat64(item[1])
			}

			// 每扇数据
			cardList := make([]*analysis2.DimEnumTargetCard, 0)
			for _, item := range dataList {
				name := convert.ToString(item[0])
				if name == "" {
					continue
				}
				count := convert.ToFloat64(item[1])
				card := &analysis2.DimEnumTargetCard{
					DisplayName:  "商品数量",
					DisplayValue: convert.ToString(count),
					EnumCode:     name,
					EnumName:     name,
					IsFakeDimId:  false,
					TargetName:   name,
					TargetValue:  count,
					Percent:      count / totalCount,
				}
				cardList = append(cardList, card)
			}

			title := consts.TaskPreviewType2Title[previewType]
			pieResult[previewType] = &analysis2.PieGraphItem{
				Name:  title,
				Value: cardList,
			}
		default:
			logs.CtxWarn(ctx, "IGetProductSelectTaskPreviewResult default, %d", previewType)
		}
	}

	//if err := group.Wait(); err != nil {
	//	logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult Run1 error, %s", err.Error())
	//}

	//group = errgroup.Group{}
	for _, previewType_ := range req.PreviewTypes {
		previewType := previewType_
		params := deepcopy.Copy(originParams).(map[string]any)

		var disPlayName = ""
		switch previewType {
		case product_select.TaskPreviewType_ProductTotal:
			params["group_param"] = "date"
			params["count_param"] = "prod_id"
			disPlayName = "圈品数量"
		case product_select.TaskPreviewType_ShopTotal:
			params["group_param"] = "date"
			params["count_param"] = "shop_id"
			disPlayName = "店铺数量"
		case product_select.TaskPreviewType_FirstCategoryTotal:
			params["group_param"] = "date"
			params["count_param"] = "first_cid"
			disPlayName = "一级类目数量"
		case product_select.TaskPreviewType_LeafCategoryTotal:
			params["group_param"] = "date"
			params["count_param"] = "leaf_cid"
			disPlayName = "叶子类目数量"
		case product_select.TaskPreviewType_BrandTotal:
			params["group_param"] = "date"
			params["count_param"] = "complex_brand_name"
			disPlayName = "品牌数量"
		case product_select.TaskPreviewType_OrderTotal:
			params["group_param"] = "date"
			params["count_param"] = "prod_pay_ord_cnt_30d"
			disPlayName = "订单数量"
		default:
			continue
		}

		previewReq := base_struct_condition.GetTargetListWithKeyColumnReq{
			Params:  params,
			Sql:     consts.Empty,
			ApiPath: OneServicePreviewAPIPath,
		}
		sqlResp, dataList, previewErr := base_struct_condition.GetDataListByOS(ctx, previewReq.Params, previewReq.Sql, previewReq.ApiPath)
		if previewErr != nil {
			logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult GetDataListByOS error, %s", previewErr.Error())
			continue
		}
		if len(dataList) == 0 {
			continue
		}

		tradeList := make([]*analysis2.TargetTrendPoint, 0)
		for _, item := range dataList {
			tradeList = append(tradeList, &analysis2.TargetTrendPoint{
				DisplayName:  disPlayName,
				DisplayValue: convert.ToString(item[1]),
				Name:         disPlayName,
				Value:        convert.ToFloat64(item[1]),
				X:            convert.ToString(item[0]),
				XValue:       convert.ToString(item[1]),
			})
		}
		if stringResult[previewType] == nil {
			continue
		}
		stringResult[previewType].TrendData = tradeList

		logs.CtxInfo(ctx, "IGetProductSelectTaskPreviewResult params %s, %s, %+v, %+v", params, sqlResp, dataList, tradeList)
	}

	//if err := group.Wait(); err != nil {
	//	logs.CtxError(ctx, "IGetProductSelectTaskPreviewResult Run2 error, %s", err.Error())
	//}

	resp = &product_select.GetProductSelectTaskPreviewResultResponse{}
	if len(stringResult) > 0 {
		resp.StringResult_ = stringResult
	}
	if len(pieResult) > 0 {
		resp.PieResult_ = pieResult
	}
	if len(trendResult) > 0 {
		resp.TrendResult_ = trendResult
	}

	return resp, err
}

func TransProductSelectTaskDao(taskList []*dao.ProductSelectTask) []*product_select.ProductSelectTask {
	res := make([]*product_select.ProductSelectTask, 0, len(taskList))

	for _, task := range taskList {
		tmpTask := &product_select.ProductSelectTask{
			TaskId:       strconv.FormatInt(task.TaskId, 10),
			TaskName:     task.TaskName,
			BizType:      dimensions.BizType(task.BizType),
			TargetAmount: task.TargetAmount,
			CreateUserId: task.CreateUserId,
			UpdateUserId: task.UpdateUserId,
			TaskStatus:   int32(task.TaskStatus),
			CreateTime:   task.CreateTime.Unix(),
			UpdateTime:   task.UpdateTime.Unix(),
			IsDel:        int32(task.IsDelete),
			PoolId:       task.PoolId,
		}
		if task.Extra != "" {
			extra := &product_select.Extra{}
			err := sonic.UnmarshalString(task.Extra, extra)
			if err != nil {
				logs.CtxError(context.Background(), "sonic.UnmarshalString failed, err: %s", err)
				continue
			}
			if extra.PoolRule == "" && task.PoolRule != "" {
				extra.PoolRule = task.PoolRule
			}
			tmpTask.Extra = extra
		}

		res = append(res, tmpTask)
	}
	return res
}

func getFeatureInfo(ctx context.Context, businessType product_select.BusinessType) (resp *product_select.ZeroSubsidyExplodeFeature, err error) {
	key := getFeatureInfoRedisKey(businessType)

	value, err := redis.Get(ctx, key)
	if err != nil {
		logs.CtxError(ctx, "getZeroSubsidyFeatureInfo Redis Get failed, err: %s, key:%s", err, key)
		return resp, err
	}

	if len(value) == 0 {
		logs.CtxError(ctx, "getZeroSubsidyFeatureInfo Redis Get failed, val empty, key:%s", key)
		return resp, err
	}

	err = sonic.UnmarshalString(value, &resp)
	if err != nil {
		logs.CtxError(ctx, "getZeroSubsidyFeatureInfo sonic.UnmarshalString failed, err: %s, key:%s", err, key)
		return resp, err
	}
	logs.CtxNotice(ctx, "getZeroSubsidyFeatureInfo key: %s, resp: %s", key, jsonx.ToString(resp))
	return resp, nil
}

func fmtProductSelectTaskFlag(bizType int64, taskId, timestamp int64) string {
	key := fmt.Sprintf("product_select_task_flag:%d:%d:%s", bizType, taskId, time.Unix(timestamp, 0).Format("20060102"))
	if env.IsPPE() {
		key += "_ppe"
	}
	return key
}

func getProductSelectTaskFlag(ctx context.Context, bizType int64, taskId, timestamp int64) (executed bool, err error) {
	key := fmtProductSelectTaskFlag(bizType, taskId, timestamp)
	logs.CtxInfo(ctx, "getProductSelectTaskFlag  key:%s", key)

	value, err := redis.Get(ctx, key)
	if err != nil {
		logs.CtxError(ctx, "getProductSelectTaskFlag Redis Get failed, err: %s, key:%s", err, key)
		return false, err
	}

	if len(value) == 0 {
		logs.CtxInfo(ctx, "getProductSelectTaskFlag Redis Get failed, val empty, key:%s", key)
		return false, nil
	}
	return value == "1", nil
}

func setProductSelectTaskFlag(ctx context.Context, bizType int64, taskId, timestamp int64) (err error) {
	key := fmtProductSelectTaskFlag(bizType, taskId, timestamp)
	logs.CtxInfo(ctx, "setProductSelectTaskFlag  key:%s", key)

	duration := 1 * time.Hour
	if env.IsPPE() {
		duration = 1 * time.Minute
	}

	err = redis.Set(ctx, key, "1", duration)
	if err != nil {
		logs.CtxError(ctx, "setProductSelectTaskFlag Redis set failed, err: %s, key:%s", err, key)
		return err
	}

	return nil
}
