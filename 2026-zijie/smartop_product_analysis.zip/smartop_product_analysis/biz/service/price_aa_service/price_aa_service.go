package price_aa_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	b64 "encoding/base64"
	"fmt"
	"github.com/bytedance/sonic"
	"github.com/jinzhu/copier"
	"sort"
	"strings"
)

type IPriceAAService interface {
	GetPriceAACoreOverview(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, channel string) (resp []*analysis.TargetCardEntity, err error)
	GetPriceAAFlowStandardCoreOverview(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, channel string) (resp []*analysis.TargetCardEntity, err error)
	GetPriceAAMarketCoreOverview(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp []*analysis.TargetCardEntity, err error)
	GetPriceAABizIncomeTrend(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp []*analysis.GetPriceAABizIncomeTrendData, err error)
	GetPriceAABizIncomeDiffDistributed(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp []*analysis.GetPriceAAMultiPieChartData, err error)
	GetPriceAASupplyCntList(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp []*analysis.GetPriceAASupplyCntData, err error)
	GetPriceAASupplyDistributed(ctx context.Context, req *analysis.GetPriceAASupplyDistributedRequest) (resp []*analysis.GetPriceAASupplyCntData, err error)
}

type PriceAAService struct {
	DimensionListDao dao.IDimensionListDao
	DimensionEnumDao dao.IDimensionEnumDao
	AttributeDao     dao.IAttributeDao
	DimensionService dimension_service.IDimensionService
}

func (d *PriceAAService) GetPriceAACoreOverview(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, channel string) (resp []*analysis.TargetCardEntity, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}

	//获取invoker的入参
	curr, err := base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	beforePriceTagName, afterPriceTagName, err := biz_info.GetCtxBizInfoPriceAAChangeSourceName(ctx)
	if err != nil {
		return
	}
	curr["before_price_tag_name"], curr["after_price_tag_name"] = beforePriceTagName, afterPriceTagName

	if len(channel) > 0 {
		switch *req.Granularity {
		case dimensions.AnalysisGranularity_PROD:
			curr["channel_filter"] = fmt.Sprintf("channel = '%s'", channel)
		case dimensions.AnalysisGranularity_SKU:
			channelMetaMap, err := biz_info.GetOrderSourceChannelMetaInfoMap(ctx, true)
			if err != nil {
				return nil, err
			}
			cInfo, exist := channelMetaMap[channel]
			if !exist {
				logs.CtxWarn(ctx, "[GetPriceAACoreOverview]获取订单来源场域信息失败,channel=%s", channel)
				return nil, errors.New("未发现订单来源场域参数")
			}
			curr["channel_filter"] = cInfo.Express
		default:
			return nil, errors.New("未选择商品/SKU粒度参数")
		}
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.PriceAAApiCoreOverview, param.SinkTable("target_card"))
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"price_power_tag_name"}))
	// 拆分改价前后数据
	f.ExeProduceSql(fmt.Sprintf(`
		select 
			target_name,
			target_value
		from target_card
		where price_power_tag_name = '%s'
	`, beforePriceTagName), param.SinkTable("before_target_card"))
	f.ExeProduceSql(fmt.Sprintf(`
		select 
			target_name,
			target_value
		from target_card
		where price_power_tag_name = '%s'
	`, afterPriceTagName), param.SinkTable("after_target_card"))
	f.ExeProduceSql(`
		select 
			a.target_name as name,
			a.target_value as value,
			b.target_name as before_name,
			b.target_value as before_value,
			a.target_value-b.target_value as diff_value,
			(a.target_value-b.target_value) / b.target_value as diff_ratio
		from after_target_card a 
		left join before_target_card b
		on a.target_name = b.target_name
	`, param.SinkTable("target_card_new"))
	f.ExeProduceSql(fmt.Sprintf(`
		select  a.name as name,
				a.value as value,
				get_display_value(a.value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order,
				(
					select 
						diff_value as diff,
						get_display_value(a.diff_value, b.value_type, b.value_unit, b.target_precision) as display_value,
						diff_ratio as diff_ratio
				) as diff_extra,
				(
					select 
						before_value as value,
						get_display_value(a.before_value, b.value_type, b.value_unit, b.target_precision) as display_value,
						before_name as name,
						'%s' as display_name,
						b.display_order as display_order
				) as sub_target_list,
				(
					select 
						b.is_larger_advantage as is_larger_advantage
				) as extra
		from    target_card_new a
		inner join
				target_meta b
		on      a.name=b.name order by b.display_order asc
	`, beforePriceTagName+"时"), param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	analysis_service.SortTargetCardEntity(resp)
	return
}

func (d *PriceAAService) GetPriceAAFlowStandardCoreOverview(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, channel string) (resp []*analysis.TargetCardEntity, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}

	//获取invoker的入参
	curr, err := base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	if len(channel) > 0 {
		curr["channel"] = channel
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.PriceAAApiEntityCnt, param.SinkTable("aa_entity_cnt"))
	var cntInfo = make(map[string]int64)
	f.ExeView(param.SourceTable("aa_entity_cnt"), &cntInfo)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAAFlowStandardCoreOverview], err=%v+", err.Error())
		return nil, err
	}
	entityCnt := cntInfo["entity_cnt"]
	if entityCnt <= 0 {
		logs.CtxWarn(ctx, "[GetPriceAAFlowStandardCoreOverview], 未发现全量实体数量")
		return resp, errors.New("未发现全量实体数量")
	}

	return GetPriceAAFlowStandardTargetWithChannel(ctx, req, dimMap, entityCnt, channel)
}

func GetPriceAAFlowStandardTargetWithChannel(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo, entityCnt int64, channel string) (resp []*analysis.TargetCardEntity, err error) {
	// 获取达标的商品/sku数量
	curr, err := base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if len(channel) > 0 {
		curr["channel"] = channel
	}

	// 获取趋势图
	trend, err := base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Trend)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	if len(channel) > 0 {
		trend["channel"] = channel
	}

	// 获取达标的gmv和订单数
	var targetParam map[string]interface{}
	if len(channel) == 0 {
		targetParam, err = base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
			BaseStruct: req,
			DimMap:     dimMap,
		}, base_struct_condition.SQLCalcType_Curr)
		if err != nil {
			logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
			return resp, err
		}

		entityList := make([]string, 0)
		entityList = append(entityList, consts.ProductID)
		if req.Granularity != nil && *req.Granularity == dimensions.AnalysisGranularity_SKU {
			entityList = append(entityList, consts.SkuID)
		}

		allSubCql, err := base_struct_condition.GetPriceChangeFlowStandardSubSQL(ctx, base_struct_condition.PriceFlowStandardParamsReq{
			BaseStruct:       req,
			DimMap:           dimMap,
			EntityList:       entityList,
			FlowStandardType: dimensions.PriceFlowStandardType_FlowStandard_ALL,
		})
		if err != nil {
			return resp, err
		}
		aaSubCql, err := base_struct_condition.GetPriceChangeFlowStandardSubSQL(ctx, base_struct_condition.PriceFlowStandardParamsReq{
			BaseStruct:       req,
			DimMap:           dimMap,
			EntityList:       entityList,
			FlowStandardType: dimensions.PriceFlowStandardType_FlowStandard_AA,
		})
		if err != nil {
			return resp, err
		}
		cspuSubCql, err := base_struct_condition.GetPriceChangeFlowStandardSubSQL(ctx, base_struct_condition.PriceFlowStandardParamsReq{
			BaseStruct:       req,
			DimMap:           dimMap,
			EntityList:       entityList,
			FlowStandardType: dimensions.PriceFlowStandardType_FlowStandard_CSPU,
		})
		if err != nil {
			return resp, err
		}

		targetParam["flow_standard_all"] = allSubCql.Compile()
		targetParam["flow_standard_aa"] = aaSubCql.Compile()
		targetParam["flow_standard_cspu"] = cspuSubCql.Compile()
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.PriceAAApiFlowStandardCoreOverviewTrend, param.SinkTable("target_card")).SetParallel(true)
	f.ExeQueryInvokerRaw(trend, consts.PriceAAApiFlowStandardCoreOverviewTrend, param.SinkTable("trend_data")).SetParallel(true)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").
		SetDimColumns([]string{"date"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name"))
	f.ExeProduceSql(fmt.Sprintf(`
		select target_name as type, target_value/%d as value, 'entity_rate' as name from target_card
	`, entityCnt), param.SinkTable("target_card_sub"))
	if len(channel) == 0 {
		f.ExeQueryInvokerRaw(targetParam, consts.PriceAAApiFlowStandardCoreOverview, param.SinkTable("sub_target_card_list")).SetParallel(true)
		f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("sub_target_card_list"), param.SinkTable("sub_target_card_list")).
			SetValueColumn("target_value").
			SetTargetNameColumn("target_name").SetDimColumns([]string{"type"}))
		f.ExeProduceSql(`
			select type, value, name from target_card_sub
			union all 
			select type, target_value as value, target_name as name from sub_target_card_list
		`, param.SinkTable("target_card_sub"))
	}
	f.ExeProduceSql(`
		select  a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order,
				(
					select
							sub_t.name as name,
							m.display_name as display_name,
							sub_t.value as value,
							get_display_value(sub_t.value, m.value_type, m.value_unit,m.target_precision) as display_value,
							m.display_order as display_order
					from    target_card_sub sub_t
					inner join target_meta m
					on sub_t.name = m.name
					where   sub_t.type = target_card.target_name
					order by b.display_order asc
				) as sub_target_list,
				(
					select  custom_date(date) as x,
							target_name as name,
							m.display_name as display_name,
							target_value as value,
							get_display_value(target_value, m.value_type, m.value_unit,m.target_precision) as display_value
					from    trend_data t
					inner join target_meta m
					on t.target_name = m.name
					where   t.target_name=target_card.target_name
					order by x asc
				) as trend_data,
				(
					select 
						b.is_larger_advantage as is_larger_advantage
				) as extra
		from target_card a
		inner join
				target_meta b
		on      a.target_name=b.name order by b.display_order asc
	`, param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDate),
	})
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAAFlowStandardCoreOverview], err=%v+", err.Error())
		return nil, err
	}
	analysis_service.SortTargetCardEntity(resp)
	if len(resp) > 0 {
		for _, r := range resp {
			if r.Extra == nil {
				r.Extra = &analysis.TargetCardExtraInfo{}
			}
			switch r.Name {
			case "flow_standard_aa_prd_cnt":
				r.Extra.ProdTagCode = convert.ToString(int64(dimensions.PriceFlowStandardType_FlowStandard_AA))
			case "flow_standard_cspu_prd_cnt":
				r.Extra.ProdTagCode = convert.ToString(int64(dimensions.PriceFlowStandardType_FlowStandard_CSPU))
			case "flow_standard_all_prd_cnt":
				r.Extra.ProdTagCode = convert.ToString(int64(dimensions.PriceFlowStandardType_FlowStandard_ALL))
			default:
				continue
			}
		}
	}

	return
}

func (d *PriceAAService) GetPriceAAMarketCoreOverview(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp []*analysis.TargetCardEntity, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}

	//获取invoker的入参
	curr, trend, _, err := base_struct_condition.GetPriceBaseStructConditionParams(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
		return
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	indexCardCom := index_card.NewIndexCard(ctx)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.PriceAAApiMarketCoreOverview, param.SinkTable("target_card")).SetParallel(true)
	f.ExeQueryInvokerRaw(trend, consts.PriceAAApiMarketCoreOverview, param.SinkTable("trend_data")).SetParallel(true)
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("trend_data"), param.SinkTable("trend_data")).
		SetValueColumn("value").
		SetTargetNameColumn("name").
		SetDimColumns([]string{"date"}))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("value").
		SetTargetNameColumn("name"))
	f.ExeProduceSql(`
		select  a.name as name,
				a.value as value,
				get_display_value(a.value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order,
				(
					select  custom_date(t.date) as x,
							t.name as name,
							m.display_name as display_name,
							t.value as value,
							get_display_value(t.value, m.value_type, m.value_unit,m.target_precision) as display_value
					from    trend_data t
					inner join target_meta m
					on t.name = m.name
					where   t.name=target_card.name
					order by x asc
				) as trend_data,
				(
					select 
						b.is_larger_advantage as is_larger_advantage
				) as extra
		from target_card a
		inner join
				target_meta b
		on      a.name=b.name order by b.display_order asc
	`, param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"custom_date":       onetable.NormalFunc(framework_udf.CustomDate),
	})
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAAFlowStandardCoreOverview], err=%v+", err.Error())
		return nil, err
	}

	return
}

type TargetTypeMeta struct {
	TargetName string
	Title      string
}

var BizIncomeTrendTypeMap = map[analysis.PriceAATargetType][]TargetTypeMeta{
	analysis.PriceAATargetType_PAY:  {{"day_avg_pay_amt", "支付GMV"}, {"day_avg_order_cnt", "支付订单数"}},
	analysis.PriceAATargetType_SHOW: {{"day_avg_show_cnt", "曝光PV"}},
}

func (d *PriceAAService) GetPriceAABizIncomeTrend(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp []*analysis.GetPriceAABizIncomeTrendData, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}

	if len(req.BaseReq.Dimensions) == 0 {
		req.BaseReq.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, req.Dimensions...)

	//获取invoker的入参
	curr, err := base_struct_condition.GetPriceBaseStructConditionParam(ctx, base_struct_condition.PriceOsParamsReq{
		BaseStruct: req.BaseReq,
		DimMap:     dimMap,
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]生成invoker sql api入参失败,err:"+err.Error())
		return
	}
	curr["price_in_out_type"] = int(biz_info.GetCtxBizInfoPriceAAInOutType(ctx))
	beforePriceTagName, afterPriceTagName, err := biz_info.GetCtxBizInfoPriceAAChangeSourceName(ctx)
	if err != nil {
		return
	}
	curr["before_price_tag_name"], curr["after_price_tag_name"] = beforePriceTagName, afterPriceTagName
	curr["target_type"] = int64(req.TargetType)
	curr["order_source_channel_selects"], curr["order_source_channel_array_join"], err = base_struct_condition.GetOrderSourceChannelSelect(ctx, false)
	if err != nil {
		return
	}

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.PriceAAApiBizIncomeTrend, param.SinkTable("target_card"))
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"price_power_tag_name", "channel"}))
	// 拆分改价前后数据
	f.ExeProduceSql(fmt.Sprintf(`
		select 
			target_name,
			target_value,
			channel
		from target_card
		where price_power_tag_name = '%s'
	`, beforePriceTagName), param.SinkTable("before_target_card"))
	f.ExeProduceSql(fmt.Sprintf(`
		select 
			target_name,
			target_value,
			channel
		from target_card
		where price_power_tag_name = '%s'
	`, afterPriceTagName), param.SinkTable("after_target_card"))
	f.ExeProduceSql(`
		select 
			a.target_name as name,
			a.target_value as value,
			b.target_name as before_name,
			b.target_value as before_value,
			a.target_value-b.target_value as diff_value,
			(a.target_value-b.target_value) / b.target_value as diff_ratio,
			channel
		from after_target_card a 
		left join before_target_card b
		on a.target_name = b.target_name and a.channel = b.channel
	`, param.SinkTable("target_card_new"))
	f.ExeProduceSql(`
		select  a.name as name,
				a.value as value,
				get_display_value(a.value, b.value_type, b.value_unit, b.target_precision) as display_value,
				b.display_name as display_name,
				a.channel as dim_name,
				(
					select 
						a.diff_ratio as value,
						get_display_value(a.diff_ratio, 'double', '%', 1) as display_value,
						'diff_ratio' as name,	
						'变化幅度' as display_name
				) as sub_target_list
		from    target_card_new a
		inner join
				target_meta b
		on      a.name=b.name order by b.display_order asc
	`, param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})

	var targetTrendList []*analysis.TargetTrendPoint
	f.ExeView(param.SourceTable("res_data"), &targetTrendList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	if len(targetTrendList) > 0 {
		targetTrendMap := make(map[string][]*analysis.TargetTrendPoint)
		for _, t := range targetTrendList {
			trends := targetTrendMap[t.Name]
			if len(trends) == 0 {
				trends = make([]*analysis.TargetTrendPoint, 0)
			}
			trends = append(trends, t)
			targetTrendMap[t.Name] = trends
		}
		resp = make([]*analysis.GetPriceAABizIncomeTrendData, 0)
		channelMetaMap, err := biz_info.GetOrderSourceChannelMetaInfoMap(ctx, *req.BaseReq.Granularity == dimensions.AnalysisGranularity_SKU)
		if err != nil || channelMetaMap == nil {
			return nil, err
		}
		for _, metaInfo := range BizIncomeTrendTypeMap[req.TargetType] {
			if trends, exist := targetTrendMap[metaInfo.TargetName]; exist && len(trends) > 0 {
				for _, info := range trends {
					channelInfo := channelMetaMap[info.DimName]
					if channelInfo != nil {
						info.X = channelMetaMap[info.DimName].DisplayName
						info.DimDisplayName = info.X
					}
					info.DisplayName = fmt.Sprintf("%s时%s", afterPriceTagName, info.DisplayName)
				}
				sort.Slice(trends, func(i, j int) bool {
					infoI := channelMetaMap[trends[i].DimName]
					infoJ := channelMetaMap[trends[j].DimName]
					if infoI != nil && infoJ != nil {
						return infoI.Order < infoJ.Order
					}
					return false
				})

				var subTrends []*analysis.TargetTrendPoint
				if len(trends) > 1 {
					subTrends = trends[1:]
				}

				resp = append(resp, &analysis.GetPriceAABizIncomeTrendData{
					Name:  metaInfo.Title,
					Total: trends[0],
					Sub:   subTrends,
				})
			}
		}
	}
	return
}

func (d *PriceAAService) GetPriceAABizIncomeDiffDistributed(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp []*analysis.GetPriceAAMultiPieChartData, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}

	if len(req.BaseReq.Dimensions) == 0 {
		req.BaseReq.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, req.Dimensions...)

	currCql, err := GetPriceAABizIncomeDiffDistributedSubSQL(ctx, base_struct_condition.PriceFlowStandardParamsReq{
		BaseStruct:       req.BaseReq,
		DimMap:           dimMap,
		Channel:          req.Channel,
		FlowStandardType: dimensions.PriceFlowStandardType_FlowStandard_NONE,
	})
	if err != nil {
		return
	}
	curr := make(map[string]interface{})
	curr["sub_sql"] = currCql.Compile()

	aaCql, err := GetPriceAABizIncomeDiffDistributedSubSQL(ctx, base_struct_condition.PriceFlowStandardParamsReq{
		BaseStruct:       req.BaseReq,
		DimMap:           dimMap,
		Channel:          req.Channel,
		FlowStandardType: dimensions.PriceFlowStandardType_FlowStandard_AA,
	})
	if err != nil {
		return
	}
	aaParam := make(map[string]interface{})
	aaParam["sub_sql"] = aaCql.Compile()

	cspuCql, err := GetPriceAABizIncomeDiffDistributedSubSQL(ctx, base_struct_condition.PriceFlowStandardParamsReq{
		BaseStruct:       req.BaseReq,
		DimMap:           dimMap,
		Channel:          req.Channel,
		FlowStandardType: dimensions.PriceFlowStandardType_FlowStandard_CSPU,
	})
	if err != nil {
		return
	}
	cspuParam := make(map[string]interface{})
	cspuParam["sub_sql"] = cspuCql.Compile()

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.PriceAAApiBizIncomeDiffDistributed, param.SinkTable("target_card_curr")).SetParallel(true)
	f.ExeQueryInvokerRaw(aaParam, consts.PriceAAApiBizIncomeDiffDistributed, param.SinkTable("target_card_aa")).SetParallel(true)
	//f.ExeQueryInvokerRaw(cspuParam, consts.PriceAAApiBizIncomeDiffDistributed, param.SinkTable("target_card_cspu")).SetParallel(true)

	isSku := req.BaseReq.Granularity != nil && *req.BaseReq.Granularity == dimensions.AnalysisGranularity_SKU
	entityCntName, entityDisplayName := utils.If(isSku, "sku_cnt", "prod_cnt"), utils.If(isSku, "SKU数", "商品数")

	f.ExeProduceSql(fmt.Sprintf(`
		select 
			diff_type,
			entity_cnt,
			target_type, 
			'AA流量提升规则达标%s' as display_name, 
			'%s' as name,
			a.entity_cnt/b.entity_cnt as percent,
			concat('2===', target_type, '_type===', diff_type) prod_tag_code
		from target_card_aa a 
		inner join target_card_curr b
		on a.diff_type = b.diff_type and a.target_type = b.target_type
	`, entityDisplayName, entityCntName), param.SinkTable("target_card_flow_standard"))
	f.ExeProduceSql(fmt.Sprintf(`
		select 
			diff_type,
			entity_cnt,
			target_type, 
			get_diff_display_name(diff_type, target_type, '%s') as display_name, 
			'%s' as name,
			concat('0===', target_type, '_type===', diff_type) prod_tag_code
		from target_card_curr
	`, entityDisplayName, entityCntName), param.SinkTable("target_card_curr")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_diff_display_name": onetable.NormalFunc(GetDiffDisplayName), // 获取变化的文案
	})
	f.ExeProduceSql(`
		select  a.target_type as name,
				a.entity_cnt as value,
				get_display_value(a.entity_cnt, b.value_type, b.value_unit, b.target_precision) as display_value,
				a.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order,
				(
					select	fs.name as name,
							fs.display_name as display_name,
							fs.entity_cnt as value,
							get_display_value(fs.entity_cnt, m.value_type, m.value_unit,m.target_precision) as display_value,
							fs.percent as percent,
							m.display_order as display_order,
							fs.prod_tag_code as prod_tag_code
					from    target_card_flow_standard fs
					inner join target_meta m
					on fs.name = m.name
					where   fs.diff_type = target_card_curr.diff_type and fs.target_type = target_card_curr.target_type
					order by m.display_order asc
				) as sub_target_list,
				(
					select 
						b.is_larger_advantage as is_larger_advantage,
						a.prod_tag_code as prod_tag_code
				) as extra
		from target_card_curr a
		inner join
				target_meta b
		on      a.name=b.name order by b.display_order asc
	`, param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	var targetList []*analysis.TargetCardEntity
	f.ExeView(param.SourceTable("res_data"), &targetList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	if len(targetList) > 0 {
		targetMap := make(map[string][]*analysis.TargetCardEntity)
		for _, t := range targetList {
			targets := targetMap[t.Name]
			if len(targets) == 0 {
				targets = make([]*analysis.TargetCardEntity, 0)
			}
			targets = append(targets, t)
			targetMap[t.Name] = targets
		}
		resp = []*analysis.GetPriceAAMultiPieChartData{
			{"商品支付订单数变化情况分布", targetMap["order_cnt"]},
			{"商品GMV变化情况分布", targetMap["pay_amt"]},
		}
	}

	return
}

func GetPriceAABizIncomeDiffDistributedSubSQL(ctx context.Context, req base_struct_condition.PriceFlowStandardParamsReq) (cql *sql_parse.CQL, err error) {
	isSku := req.BaseStruct.Granularity != nil && *req.BaseStruct.Granularity == dimensions.AnalysisGranularity_SKU

	subCql := sql_parse.NewCQL().
		Select("date").
		From(fmt.Sprintf("%s as income_diff_distributed_sub_sql", utils.If(isSku, consts.OrdPricePowerTableName, consts.ProdPriceChannelFlowTableName))).
		AddWhereRawCond("date between ? and ?", req.BaseStruct.StartDate, req.BaseStruct.EndDate)

	switch biz_info.GetCtxBizInfoPriceAAInOutType(ctx) {
	case dimensions.PriceInOutType_PRICE_IN:
		priceTagName := fmt.Sprintf("%s_%s", utils.If(isSku, "sku", "prd"), "xd_price_power_tag_name")
		subCql.AddSelect(fmt.Sprintf("if(%s in ('均价', '优价'),'非高价', %s) as price_power_tag_name", priceTagName, priceTagName))
		subCql.AddWhere(fmt.Sprintf("%s%s", utils.If(isSku, "sku_", ""), "xd_is_high_price_range_tag"), sql_parse.EQUAL, 1)
	case dimensions.PriceInOutType_PRICE_OUT:
		priceTagName := fmt.Sprintf("%s_%s", utils.If(isSku, "sku", "prd"), "out_price_power_tag_name")
		subCql.AddSelect(fmt.Sprintf("if(%s in ('均价', '优价'),'非高价', %s) as price_power_tag_name", priceTagName, priceTagName))
		subCql.AddWhere(fmt.Sprintf("%s%s", utils.If(isSku, "sku_", ""), "out_is_high_price_range_tag"), sql_parse.EQUAL, 1)
	default:
		return nil, errors.New("未设置内/外价格力对比")
	}
	beforePriceTagName, afterPriceTagName, err := biz_info.GetCtxBizInfoPriceAAChangeName(ctx)
	if err != nil {
		return
	}
	subCql.AddRawWhere(fmt.Sprintf("and price_power_tag_name in (%s, %s)", beforePriceTagName, afterPriceTagName))

	if isSku {
		channelMetaMap, err := biz_info.GetOrderSourceChannelMetaInfoMap(ctx, true)
		if err != nil {
			return nil, err
		}
		cInfo, exist := channelMetaMap[req.Channel]
		if !exist {
			logs.CtxWarn(ctx, "[GetPriceAACoreOverview]获取订单来源场域信息失败,channel=%s", req.Channel)
			return nil, errors.New("未发现订单来源场域参数")
		}
		subCql.AddSelect("sku_id", "prod_id", "pay_amt").AddRawWhere(fmt.Sprintf("and %s", cInfo.Express))
	} else {
		subCql.AddSelect("prod_id", "pay_ord_cnt", "pay_ord_amt as pay_amt").AddWhere("channel", sql_parse.EQUAL, req.Channel)
	}
	req.EntityList = make([]string, 0)
	req.EntityList = append(req.EntityList, consts.ProductID)
	if isSku {
		req.EntityList = append(req.EntityList, consts.SkuID)
	}
	miniCql, err := base_struct_condition.GetPriceChangeFlowStandardSubSQL(ctx, req)
	if err != nil {
		return
	}
	subCql.AddSubQueryWhere(utils.If(isSku, fmt.Sprintf("(%s, %s)", consts.ProductID, consts.SkuID), consts.ProductID), sql_parse.IN, miniCql)

	baseCql := sql_parse.NewCQL().Select("prod_id").GroupBy("prod_id")
	if isSku {
		baseCql.AddSelect("sku_id").AddGroupBy("sku_id")
	}
	baseCql.AddSelect(
		fmt.Sprintf("toFloat64(count(distinct if(price_power_tag_name in (%s),date,null))) as before_date_cnt", beforePriceTagName),
		fmt.Sprintf("toFloat64(count(distinct if(price_power_tag_name in (%s),date,null))) as after_date_cnt", afterPriceTagName),
		fmt.Sprintf("sum(if(price_power_tag_name in (%s),pay_amt,0)) as before_pay_amt", beforePriceTagName),
		fmt.Sprintf("sum(if(price_power_tag_name in (%s),pay_amt,0)) as after_pay_amt", afterPriceTagName),
		fmt.Sprintf("sum(if(price_power_tag_name in (%s),%s,0)) as before_order_cnt", beforePriceTagName, utils.If(isSku, "1", "pay_ord_cnt")),
		fmt.Sprintf("sum(if(price_power_tag_name in (%s),%s,0)) as after_order_cnt", afterPriceTagName, utils.If(isSku, "1", "pay_ord_cnt")),
		"round(if(before_date_cnt = 0, 0, before_pay_amt / before_date_cnt),5) as day_avg_before_pay_amt",
		"round(if(before_date_cnt = 0, 0, before_order_cnt / before_date_cnt),5) as day_avg_before_order_cnt",
		"round(if(after_date_cnt = 0, 0, after_pay_amt / after_date_cnt),5) as day_avg_after_pay_amt",
		"round(if(after_date_cnt = 0, 0, after_order_cnt / after_date_cnt),5) as day_avg_after_order_cnt",
		"if(day_avg_before_pay_amt = 0, 0, (day_avg_after_pay_amt-day_avg_before_pay_amt) / day_avg_before_pay_amt) as day_avg_pay_amt_diff_ratio",
		"if(day_avg_before_order_cnt = 0, 0, (day_avg_after_order_cnt-day_avg_before_order_cnt) / day_avg_before_order_cnt) as day_avg_order_cnt_diff_ratio",
		`case 
            when day_avg_after_pay_amt > day_avg_before_pay_amt then '上涨'
            when day_avg_after_pay_amt < day_avg_before_pay_amt then '下降'
        else '不变' end as pay_amt_type`,
		`case 
            when day_avg_after_order_cnt > day_avg_before_order_cnt then '上涨'
            when day_avg_after_order_cnt < day_avg_before_order_cnt then '下降'
        else '不变' end as order_cnt_type`,
	).FromCql(subCql)

	return baseCql, nil
}

func GetDiffDisplayName(diffType, targetType, entityDisplayName string) (string, error) {
	switch targetType {
	case "pay_amt":
		return fmt.Sprintf("日均支付GMV%s的%s", diffType, entityDisplayName), nil
	case "order_cnt":
		return fmt.Sprintf("日均支付订单数%s的%s", diffType, entityDisplayName), nil
	default:
		return consts.Empty, errors.New("未发现该指标信息")
	}
	return consts.Empty, errors.New("未发现该指标信息")
}

func (d *PriceAAService) GetPriceAASupplyCntList(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (resp []*analysis.GetPriceAASupplyCntData, err error) {
	resp = make([]*analysis.GetPriceAASupplyCntData, 0)
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return
	}

	marketR, err := GetPriceAASupplyCnt(ctx, req, dimMap, consts.PriceAASupplyCntType_Market)
	if err != nil {
		return
	}
	resp = append(resp, marketR)
	priceChangeR, err := GetPriceAASupplyCnt(ctx, req, dimMap, consts.PriceAASupplyCntType_PriceChange)
	if err != nil {
		return
	}
	resp = append(resp, priceChangeR)
	priceChangeFilterR, err := GetPriceAASupplyCnt(ctx, req, dimMap, consts.PriceAASupplyCntType_PriceChange_Filter)
	if err != nil {
		return
	}
	resp = append(resp, priceChangeFilterR)
	return resp, nil
}

func GetPriceAASupplyCnt(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo, supplyType consts.PriceAASupplyCntType) (resp *analysis.GetPriceAASupplyCntData, err error) {
	//获取invoker的入参
	curr := base_struct_condition.GetPriceConditionSimpleParam(ctx, req)
	subCql, err := GetPriceAASupplyCntSubSQL(ctx, req, dimMap, consts.Empty, supplyType)
	if err != nil {
		return
	}

	apiPath := consts.PriceAAApiSupplyMarketCnt
	if supplyType == consts.PriceAASupplyCntType_PriceChange || supplyType == consts.PriceAASupplyCntType_PriceChange_Filter {
		priceChangeSubCql := sql_parse.NewCQL()
		err = copier.CopyWithOption(priceChangeSubCql, &subCql, copier.Option{DeepCopy: true})
		if err != nil {
			return nil, err
		}
		curr["price_change_sub_sql"] = priceChangeSubCql.Compile()
		apiPath = consts.PriceAAApiSupplyFilterCnt
	}

	isSku := *req.Granularity == dimensions.AnalysisGranularity_SKU
	subCql.Select(utils.If(isSku, fmt.Sprintf("count(distinct %s) as entity_cnt", consts.SkuID), fmt.Sprintf("count(distinct %s) as entity_cnt", consts.ProductID)))
	curr["entity_cnt_sub_sql"] = subCql.Compile()
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BizType, KeyCols: []string{},
	})
	if err != nil {
		return nil, err
	}

	var baseTarget *analysis.TargetCardEntity
	subTargetList := make([]*analysis.TargetBasicInfo, 0)
	if len(currTargetList) > 0 {
		for _, info := range currTargetList {
			if len(info.TargetEntity) > 0 {
				for _, targetEntity := range info.TargetEntity {
					if targetEntity.Name == "entity_cnt" {
						if targetEntity.Extra == nil {
							targetEntity.Extra = &analysis.TargetCardExtraInfo{}
						}
						targetEntity.Extra.ProdTagCode = convert.ToString(int64(supplyType))
						baseTarget = targetEntity
					} else {
						subTargetList = append(subTargetList, &analysis.TargetBasicInfo{
							Value:        targetEntity.Value,
							DisplayValue: targetEntity.DisplayValue,
							Name:         targetEntity.Name,
							DisplayName:  targetEntity.DisplayName,
						})
					}
				}
			}
		}
	}
	if baseTarget != nil && len(subTargetList) > 0 {
		baseTarget.SubTargetList = subTargetList
	}
	resp = &analysis.GetPriceAASupplyCntData{
		Name:       consts.PriceAASupplyCntTypeNameMap[supplyType].Name,
		Tips:       consts.PriceAASupplyCntTypeNameMap[supplyType].Tips,
		TargetList: []*analysis.TargetCardEntity{baseTarget},
	}
	return
}

func GetPriceAASupplyCntSubSQL(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo, prodTagCode string, supplyType consts.PriceAASupplyCntType) (cql *sql_parse.CQL, err error) {
	if req == nil {
		return nil, errors.New("请求体为空")
	}
	isSku := req.Granularity != nil && *req.Granularity == dimensions.AnalysisGranularity_SKU
	entityCol := utils.If(isSku && len(prodTagCode) == 0, []string{consts.ProductID, consts.SkuID}, []string{consts.ProductID})
	cql = sql_parse.NewCQL()
	switch supplyType {
	case consts.PriceAASupplyCntType_Market:
		cql.From(fmt.Sprintf("%s as supply_cnt_sub_sql", consts.SkuPricePowerTableName)).AddWhereRawCond("date between ? and ?", req.StartDate, req.EndDate)
		switch biz_info.GetCtxBizInfoPriceAAInOutType(ctx) {
		case dimensions.PriceInOutType_PRICE_IN:
			cql.AddWhere(fmt.Sprintf("%s%s", utils.If(isSku, "sku_", "prd_"), "xd_is_high_price_range_tag"), sql_parse.EQUAL, 1)
			cql.AddWhere(fmt.Sprintf("%s%s", utils.If(isSku, "sku_", "prd_"), "xd_price_power_tag_name"), sql_parse.IN, consts.PricePowerList)
		case dimensions.PriceInOutType_PRICE_OUT:
			cql.AddWhere(fmt.Sprintf("%s%s", utils.If(isSku, "sku_", "prd_"), "out_is_high_price_range_tag"), sql_parse.EQUAL, 1)
			cql.AddWhere(fmt.Sprintf("%s%s", utils.If(isSku, "sku_", "prd_"), "out_price_power_tag_name"), sql_parse.IN, consts.PricePowerList)
		default:
			return nil, errors.New("未设置内/外价格力对比")
		}
	case consts.PriceAASupplyCntType_PriceChange, consts.PriceAASupplyCntType_PriceChange_Filter:
		cql, err = base_struct_condition.GetPriceChangeFlowStandardSubSQL(ctx, base_struct_condition.PriceFlowStandardParamsReq{
			BaseStruct:       req,
			DimMap:           dimMap,
			EntityList:       entityCol,
			FlowStandardType: dimensions.PriceFlowStandardType_FlowStandard_NONE,
			IsOverall:        supplyType == consts.PriceAASupplyCntType_PriceChange,
		})
		if err != nil {
			return
		}
	default:
		return nil, errors.New("未设置正确的供给类型")
	}
	if len(prodTagCode) > 0 && prodTagCode != consts.IsTrueString {
		colStr, err := b64.StdEncoding.DecodeString(prodTagCode)
		if err != nil {
			logs.CtxError(ctx, "[GetPriceAASupplyCntSubSQL]b64.StdEncoding.DecodeString Error, err = %v", err)
			return nil, err
		}
		prodTagCodeParam := &consts.ProdTagCodeParam{}
		err = sonic.UnmarshalString(string(colStr), &prodTagCodeParam)
		if err != nil {
			logs.CtxError(ctx, "指标入参反序列化失败，err:"+err.Error())
			return nil, err
		}
		if len(prodTagCodeParam.Col) == 0 || len(prodTagCodeParam.Value) == 0 {
			logs.CtxError(ctx, "获取prod tag code 失败, colStr = %s", colStr)
			return nil, errors.New("[GetPriceAASupplyCntSubSQL]prodTagCodeParam 参数为空")
		}
		cql.AddWhere(prodTagCodeParam.Col, sql_parse.EQUAL, prodTagCodeParam.Value)
	}
	cql.Select(entityCol...).AddClickHouseSettings("distributed_product_mode = 'local', distributed_perfect_shard = 1")
	return
}

func (d *PriceAAService) GetPriceAASupplyDistributed(ctx context.Context, req *analysis.GetPriceAASupplyDistributedRequest) (resp []*analysis.GetPriceAASupplyCntData, err error) {
	resp = make([]*analysis.GetPriceAASupplyCntData, 0)
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return
	}

	ret, err := d.GetPriceAASupplyDistributedPieChart(ctx, req.BaseReq, dimMap, convert.ToInt64(req.DimId))
	if err != nil {
		return resp, err
	}
	resp = append(resp, ret)
	return
}

func (d *PriceAAService) GetPriceAASupplyDistributedPieChart(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo, dimID int64) (resp *analysis.GetPriceAASupplyCntData, err error) {
	//获取invoker的入参
	curr := base_struct_condition.GetPriceConditionSimpleParam(ctx, req)
	market := base_struct_condition.GetPriceConditionSimpleParam(ctx, req)
	priceChange := base_struct_condition.GetPriceConditionSimpleParam(ctx, req)

	dimEnumsInfo, err := d.DimensionService.GetDimensionByID(ctx, dimID)
	if err != nil {
		return
	}

	dimInfo := dimMap[dimID]
	if dimInfo == nil {
		logs.CtxError(ctx, "[GetPriceAASupplyDistributedPieChart]未查询到维度信息,id=%d", dimID)
		return nil, errors.New("未查询到维度信息")
	}

	var newDimStr string
	enumOrderMap := make(map[string]int)
	if dimEnumsInfo != nil && len(dimEnumsInfo.Values) > 0 {
		newDimStr = GetPriceAASupplyDistributedNewDimExp(ctx, dimEnumsInfo, dimInfo.DimColumn)
		for i, enum := range dimEnumsInfo.Values {
			enumOrderMap[enum.Name] = i + 1
		}
	} else {
		newDimStr = dimInfo.DimColumn
	}

	market["new_dim_str"] = newDimStr
	market["dimesion_express"] = utils.If(len(dimInfo.DimExpr) > 0, fmt.Sprintf("%s as %s", dimInfo.DimExpr, dimInfo.DimColumn), dimInfo.DimColumn)
	market["dimesion"] = dimInfo.DimColumn
	market["entity_cnt_sub_sql"], err = GetPriceAASupplyDistributedSubSQL(ctx, req, dimMap, consts.Empty, consts.PriceAASupplyCntType_Market, dimInfo)
	if err != nil {
		return
	}
	priceChange["new_dim_str"] = newDimStr
	priceChange["dimesion_express"] = utils.If(len(dimInfo.DimExpr) > 0, fmt.Sprintf("%s as %s", dimInfo.DimExpr, dimInfo.DimColumn), dimInfo.DimColumn)
	priceChange["dimesion"] = dimInfo.DimColumn
	priceChange["entity_cnt_sub_sql"], err = GetPriceAASupplyDistributedSubSQL(ctx, req, dimMap, consts.Empty, consts.PriceAASupplyCntType_PriceChange, dimInfo)
	if err != nil {
		return
	}
	curr["new_dim_str"] = newDimStr
	curr["dimesion_express"] = utils.If(len(dimInfo.DimExpr) > 0, fmt.Sprintf("%s as %s", dimInfo.DimExpr, dimInfo.DimColumn), dimInfo.DimColumn)
	curr["dimesion"] = dimInfo.DimColumn
	curr["entity_cnt_sub_sql"], err = GetPriceAASupplyDistributedSubSQL(ctx, req, dimMap, consts.Empty, consts.PriceAASupplyCntType_PriceChange_Filter, dimInfo)
	if err != nil {
		return
	}
	filterSubCql, err := GetPriceAASupplyCntSubSQL(ctx, req, dimMap, consts.Empty, consts.PriceAASupplyCntType_PriceChange_Filter)
	if err != nil {
		return
	}
	curr["price_change_sub_sql"] = filterSubCql.Compile()

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.PriceAAApiSupplyFilterMultiDim, param.SinkTable("target_card")).SetParallel(true)
	f.ExeQueryInvokerRaw(market, consts.PriceAAApiSupplyMarketMultiDim, param.SinkTable("target_card_market")).SetParallel(true)
	f.ExeQueryInvokerRaw(priceChange, consts.PriceAAApiSupplyFilterMultiDim, param.SinkTable("target_card_price_change")).SetParallel(true)
	// 指标值行转列
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("target_card"), param.SinkTable("target_card")).
		SetValueColumn("target_value").SetTargetNameColumn("target_name").SetDimColumns([]string{"new_dim"}))
	f.ExeProduceSql(`
		select target_name, target_value, new_dim from target_card where target_name = 'entity_cnt'
	`, param.SinkTable("target_card_base"))
	f.ExeProduceSql(`
		select target_name, target_value, new_dim from target_card where target_name != 'entity_cnt'
	`, param.SinkTable("target_card_sub"))
	f.ExeProduceSql(`
		select	target_name as name,
				target_value as value,
				new_dim as new_dim
		from    target_card_sub
		union all
		select 
			'price_change_percent' as name, 
			t1.target_value/c.entity_cnt value,
			c.new_dim as new_dim
		from target_card_price_change c inner join target_card_base t1 on c.new_dim = t1.new_dim
		union all
		select 
			'market_percent' as name, 
			t2.target_value/m.entity_cnt value,
			m.new_dim as new_dim
		from target_card_market m inner join target_card_base t2 on m.new_dim = t2.new_dim
	`, param.SinkTable("target_card_sub"))

	f.ExeProduceSql(fmt.Sprintf(`
		select  a.target_name as name,
				a.target_value as value,
				get_display_value(a.target_value, b.value_type, b.value_unit, b.target_precision) as display_value,
				a.new_dim as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order,
				(
					select	sub.name as name,
							m.display_name as display_name,
							sub.value as value,
							get_display_value(sub.value, m.value_type, m.value_unit,m.target_precision) as display_value,
							m.display_order as display_order
					from    target_card_sub sub
					inner join target_meta m
					on sub.name = m.name
					where sub.new_dim = target_card_base.new_dim
					order by m.display_order asc
				) as sub_target_list,
				(
					select 
						b.is_larger_advantage as is_larger_advantage
				) as extra
		from target_card_base a
		inner join
				target_meta b
		on      a.target_name=b.name order by b.display_order asc
	`), param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	var targetList []*analysis.TargetCardEntity
	f.ExeView(param.SourceTable("res_data"), &targetList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	if len(targetList) > 0 {
		sort.Slice(targetList, func(i, j int) bool {
			orderI, existI := enumOrderMap[targetList[i].DisplayName]
			if !existI {
				orderI = 999
			}
			orderJ, existJ := enumOrderMap[targetList[j].DisplayName]
			if !existJ {
				orderJ = 999
			}
			return orderI < orderJ
		})

		for _, t := range targetList {
			if t.Extra == nil {
				t.Extra = &analysis.TargetCardExtraInfo{}
			}
			t.Extra.ProdTagCode = b64.StdEncoding.EncodeToString([]byte(convert.ToJSONString(consts.ProdTagCodeParam{
				Col:   newDimStr,
				Value: t.DisplayName,
			})))
		}
	}

	resp = &analysis.GetPriceAASupplyCntData{
		Name:       dimEnumsInfo.ShowName,
		TargetList: targetList,
	}
	return
}

func GetPriceAASupplyDistributedSubSQL(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo, prodTagCode string, supplyType consts.PriceAASupplyCntType, dimInfo *dao.DimensionInfo) (sql string, err error) {
	cql, err := GetPriceAASupplyCntSubSQL(ctx, req, dimMap, prodTagCode, supplyType)
	if err != nil {
		return
	}

	isSku := *req.Granularity == dimensions.AnalysisGranularity_SKU
	cql.Select(utils.If(isSku, fmt.Sprintf("count(distinct %s) as entity_cnt", consts.SkuID), fmt.Sprintf("count(distinct %s) as entity_cnt", consts.ProductID)))

	if len(dimInfo.DimExpr) > 0 {
		cql.AddSelect(fmt.Sprintf("%s as %s", dimInfo.DimExpr, dimInfo.DimColumn))
	} else {
		cql.AddSelect(dimInfo.DimColumn)
	}

	cql.GroupBy(dimInfo.DimColumn)
	return cql.Compile(), nil
}

func GetPriceAASupplyDistributedNewDimExp(ctx context.Context, dimEnumsInfo *dimensions.DimensionInfo, dimCol string) string {
	colArr := make([]string, 0)
	for _, enum := range dimEnumsInfo.Values {
		colArr = append(colArr, fmt.Sprintf(" when cast(%s as String) = '%s' then '%s' ", dimCol, enum.Code, enum.Name))
	}
	return fmt.Sprintf("case %s else '未知' end", strings.Join(colArr, " "))
}
