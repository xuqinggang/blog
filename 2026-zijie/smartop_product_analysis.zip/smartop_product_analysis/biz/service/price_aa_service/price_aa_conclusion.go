package price_aa_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs/v2"
	"context"
	"fmt"
)

func (d *PriceAAService) GetPriceAACoreConclusion(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.PriceAACoreConclusionData, err error) {
	// 获取业务线的维度信息
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetPriceAACoreOverview]获取map失败，err=%v+", err)
		return nil, err
	}

	resp = &analysis.PriceAACoreConclusionData{
		TotalInfo:     &analysis.TotalConclusionInfo{},
		BizIncomeInfo: make([]*analysis.TargetDiffConclusionData, 0),
		FlowDiffInfo:  make([]*analysis.TargetDiffConclusionData, 0),
		SupplyInfo: &analysis.SupplyConclusionData{
			ProdPool: make([]*analysis.TargetCardEntity, 0),
			CateInfo: nil,
		},
		FlowStandardConclusion: nil,
	}
	// 获取整体的数量
	marketR, err := GetPriceAASupplyCnt(ctx, req.BaseReq, dimMap, consts.PriceAASupplyCntType_Market)
	if err != nil {
		return
	}
	if len(marketR.TargetList) > 0 {
		resp.TotalInfo.Market = marketR.TargetList[0]
	}
	priceChangeR, err := GetPriceAASupplyCnt(ctx, req.BaseReq, dimMap, consts.PriceAASupplyCntType_PriceChange)
	if err != nil {
		return
	}
	if len(priceChangeR.TargetList) > 0 {
		resp.TotalInfo.PriceChange = priceChangeR.TargetList[0]
	}
	priceChangeFilterR, err := GetPriceAASupplyCnt(ctx, req.BaseReq, dimMap, consts.PriceAASupplyCntType_PriceChange_Filter)
	if err != nil {
		return
	}
	if len(priceChangeFilterR.TargetList) > 0 {
		resp.TotalInfo.PriceChangeFilter = priceChangeFilterR.TargetList[0]
	}

	// 业务收益分析
	coreTargetList, err := d.GetPriceAACoreOverview(ctx, req.BaseReq, consts.Empty)
	if err != nil {
		return
	}
	for _, target := range coreTargetList {
		switch target.Name {
		case "day_avg_show_cnt":
			resp.FlowDiffInfo = append(resp.FlowDiffInfo, &analysis.TargetDiffConclusionData{
				TotalTarget: target,
				IncrInfo:    nil,
				ReduceInfo:  nil,
			})
		case "day_avg_pay_amt":
			resp.BizIncomeInfo = append(resp.BizIncomeInfo, &analysis.TargetDiffConclusionData{
				TotalTarget: target,
				IncrInfo:    nil,
				ReduceInfo:  nil,
			})
		case "day_avg_order_cnt":
			resp.BizIncomeInfo = append(resp.BizIncomeInfo, &analysis.TargetDiffConclusionData{
				TotalTarget: target,
				IncrInfo:    nil,
				ReduceInfo:  nil,
			})
		default:
			continue
		}
	}

	// 商品池
	aGroupInfo, err := d.GetPriceAASupplyDistributed(ctx, &analysis.GetPriceAASupplyDistributedRequest{
		BaseReq: req.BaseReq,
		DimId:   consts.FourthAGroupProdDim,
	})
	if err != nil {
		return
	}
	if len(aGroupInfo) > 0 && len(aGroupInfo[0].TargetList) > 0 {
		for _, aT := range aGroupInfo[0].TargetList {
			if aT.DisplayName == "是" {
				resp.SupplyInfo.ProdPool = append(resp.SupplyInfo.ProdPool, aT)
			}
		}
	}
	bGroupInfo, err := d.GetPriceAASupplyDistributed(ctx, &analysis.GetPriceAASupplyDistributedRequest{
		BaseReq: req.BaseReq,
		DimId:   consts.FourthBGroupProdDim,
	})
	if err != nil {
		return
	}
	if len(bGroupInfo) > 0 && len(bGroupInfo[0].TargetList) > 0 {
		for _, bT := range bGroupInfo[0].TargetList {
			if bT.DisplayName == "是" {
				resp.SupplyInfo.ProdPool = append(resp.SupplyInfo.ProdPool, bT)
			}
		}
	}

	// 获取流量达标的数据
	d.GetPriceAAFlowStandardCoreOverview(ctx, req.BaseReq, "")
	GetPriceAADiffDistributedConclusion(ctx, &analysis.GetPriceAABaseRequest{
		BaseReq:    req.BaseReq,
		Channel:    "",
	}, dimMap, dimensions.PriceFlowStandardType_FlowStandard_AA)
	GetPriceAADiffDistributedConclusion(ctx, &analysis.GetPriceAABaseRequest{
		BaseReq:    req.BaseReq,
		Channel:    "",
	}, dimMap, dimensions.PriceFlowStandardType_FlowStandard_CSPU)
	return
}

func GetPriceAADiffDistributedConclusion(ctx context.Context, req *analysis.GetPriceAABaseRequest, dimMap map[int64]*dao.DimensionInfo, flowStandardType dimensions.PriceFlowStandardType) (resp []*analysis.TargetCardEntity, err error) {
	currCql, err := GetPriceAABizIncomeDiffDistributedSubSQL(ctx, base_struct_condition.PriceFlowStandardParamsReq{
		BaseStruct:       req.BaseReq,
		DimMap:           dimMap,
		Channel:          req.Channel,
		FlowStandardType: flowStandardType,
	})
	if err != nil {
		return
	}
	curr := make(map[string]interface{})
	curr["sub_sql"] = currCql.Compile()

	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	// 指标元信息
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BaseReq.BizType)), param.SourceConst(false), param.SourceConst([]string{})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	// 请求invoker，获取数据
	f.ExeQueryInvokerRaw(curr, consts.PriceAAApiBizIncomeDiffDistributed, param.SinkTable("target_card"))

	isSku := req.BaseReq.Granularity != nil && *req.BaseReq.Granularity == dimensions.AnalysisGranularity_SKU
	entityCntName, entityDisplayName := utils.If(isSku, "sku_cnt", "prod_cnt"), utils.If(isSku, "SKU数", "商品数")

	f.ExeProduceSql(fmt.Sprintf(`
		select 
			diff_type,
			entity_cnt,
			avg_diff_ratio,
			target_type, 
			get_diff_display_name(diff_type, target_type, '%s') as display_name, 
			'%s' as name
		from target_card
	`, entityDisplayName, entityCntName), param.SinkTable("target_card")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_diff_display_name": onetable.NormalFunc(GetDiffDisplayName), // 获取变化的文案
	})
	f.ExeProduceSql(`
		select  a.target_type as name,
				a.entity_cnt as value,
				get_display_value(a.entity_cnt, b.value_type, b.value_unit, b.target_precision) as display_value,
				a.display_name as display_name,
				b.tips as tips,
				b.value_unit as unit,
				b.attribute_type as category_name,
				b.display_order as display_order,
				(
					select 
						a.avg_diff_ratio as value,
						get_display_value(a.avg_diff_ratio, 'double', '%', 1) as display_value,
						'avg_diff_ratio' as name,	
						'平均变化幅度' as display_name
				) as sub_target_list,
				(
					select 
						b.is_larger_advantage as is_larger_advantage
				) as extra
		from target_card a
		inner join
				target_meta b
		on      a.name=b.name order by b.display_order asc
	`, param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
	})
	var targetList []*analysis.TargetCardEntity
	f.ExeView(param.SourceTable("res_data"), &targetList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	analysis_service.SortTargetCardEntity(resp)
	return
}
