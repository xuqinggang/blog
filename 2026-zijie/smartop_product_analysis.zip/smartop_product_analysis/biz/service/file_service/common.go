package file_service

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/file"
	"context"
)

type IFileService interface {
	UploadFile(ctx context.Context, req *file.UploadFileRequest) (url string, objKey string, err error)
}

type FileService struct {
}
