package file_service

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"mime"
	"mime/multipart"
	"path/filepath"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tos"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/file"
	"code.byted.org/gopkg/logs/v2"
)

type ParsedFile struct {
	FieldName string // 表单字段名（file或imageFile）
	FileName  string // 文件名
	Content   []byte // 文件内容
}

const (
	UploadFile  = "file"
	UploadImage = "image"
)

func (m *FileService) UploadFile(ctx context.Context, req *file.UploadFileRequest) (url string, objKey string, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[UploadFile] failed, err: %v", err)
		}
	}()

	parsedFiles, err := m.ParseMultiPartFormData(ctx, req)
	if err != nil {
		return
	}
	for _, file := range parsedFiles {
		switch file.FieldName {
		case UploadImage:
			objKey, err = tos.UploadImage(ctx, file.Content, filepath.Ext(file.FileName))
			if err != nil {
				return
			}
			url = tos.BuildOpenBucketURL(objKey)
		case UploadFile:
			if strings.HasSuffix(file.FileName, ".csv") {
				// 暂时不检验csv的格式
				// var records [][]string
				// records, err = utils.ParseContentToCSVFormat(ctx, file.Content)
				// if err != nil {
				// 	resp.BaseResp = &base.BaseResp{
				// 		StatusMessage: "抱歉，当前仅支持纯数据型CSV分析（首行为完整表头且无空列名，每行数据与表头严格对应，无合并单元格、无表头/页脚）",
				// 		StatusCode:    -1,
				// 	}
				// 	return resp, nil
				// }
				// //CSV文件上传
				// objKey := utils.CalcCsvMD5(ctx, records) //相同的内容文件内容使用相同的url，防止后面重复创建hive表
				// if len(objKey) == 0 {
				// 	objKey = uuid.New().String()
				// }
				objKey, err = tos.UploadCsv(ctx, file.Content, filepath.Ext(file.FileName))
				if err != nil {
					return
				}
				url = tos.BuildOpenBucketURL(objKey)
			} else {
				err = fmt.Errorf("暂不支持该文件类型")
			}
		default:
			err = fmt.Errorf("暂不支持该文件类型")
		}
	}
	return
}

func (m *FileService) ParseMultiPartFormData(ctx context.Context, req *file.UploadFileRequest) (parsedFiles []ParsedFile, err error) {
	if req == nil || len(req.RawBody) == 0 || req.ContentType == "" {
		err = fmt.Errorf("req is nil or RawBody is empty or ContentType is empty")
		return
	}

	// 从Content-Type提取boundary
	_, params, err := mime.ParseMediaType(req.ContentType)
	if err != nil {
		return
	}
	boundary, ok := params["boundary"]
	if !ok || boundary == "" {
		err = fmt.Errorf("boundary is empty")
		return
	}

	// 解析multipart
	var (
		part        *multipart.Part
		disposition string
		content     []byte
		recvErr     error
	)
	reader := multipart.NewReader(bytes.NewReader(req.RawBody), boundary)
	defer func() {
		if part != nil {
			if closeErr := part.Close(); closeErr != nil {
				logs.CtxError(ctx, "[ParseMultiPartFormData] multipart reader close error: %v", closeErr)
			}
		}
	}()
	for {
		part, recvErr = reader.NextPart()
		if errors.Is(recvErr, io.EOF) {
			return
		}
		if recvErr != nil {
			return nil, recvErr
		}
		if part.Header == nil {
			err = fmt.Errorf("part Header is nil")
			return
		}

		// 解析Content-Disposition
		dispositionLine := part.Header.Get("Content-Disposition")
		if dispositionLine == "" {
			err = fmt.Errorf("Content-Disposition is empty")
			return
		}
		disposition, params, err = mime.ParseMediaType(dispositionLine)
		if err != nil {
			return
		}
		if disposition != "form-data" {
			continue
		}

		// 读取文件内容
		content, err = io.ReadAll(part)
		if err != nil {
			return
		}
		parsedFiles = append(parsedFiles, ParsedFile{
			FieldName: params["name"],
			FileName:  params["filename"],
			Content:   content,
		})
	}
}
