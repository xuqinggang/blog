package subscription

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/subscription"
)

type ISubscriptionService interface {
	// 订阅配置 - 获取订阅通用配置
	GetSubscriptionConfig(ctx context.Context, req *subscription.GetSubscriptionConfigRequest) (resp *subscription.GetSubscriptionConfigResponse, err error)
	// 获取单个订阅
	GetUserSubscriptionById(ctx context.Context, id int64) (data *subscription.UserSubscription, err error)
	// 订阅管理 - 用户的所有订阅
	GetUserSubscriptionList(ctx context.Context, req *subscription.GetUserSubscriptionListRequest) (resp *subscription.GetUserSubscriptionListResponse, err error)
	// 订阅管理 - 推送预览
	PreviewUserSubscription(ctx context.Context, req *subscription.PreviewUserSubscriptionRequest) (err error)
	// 订阅管理 - 保存/更新/暂停推送
	SaveUserSubscription(ctx context.Context, req *subscription.SaveUserSubscriptionRequest) (resp *subscription.SaveUserSubscriptionResponse, err error)
	// 订阅管理 - 删除推送
	DeleteUserSubscription(ctx context.Context, req *subscription.DeleteUserSubscriptionRequest) (err error)
	// 发送消息
	SendCard(ctx context.Context, subReportMsg SubReportMsg) (err error)

	SaveSubscriptionFilterConfig(ctx context.Context, req *subscription.SaveSubscriptionFilterConfigRequest) (resp *subscription.SaveSubscriptionFilterConfigResponse, err error)
	// 订阅管理 - 删除推送
	GetSubscriptionFilterConfig(ctx context.Context, req *subscription.GetSubscriptionFilterConfigRequest) (resp *subscription.GetSubscriptionFilterConfigResponse, err error)
}

type SubscriptionService struct {
	DimensionService dimension_service.IDimensionService
}

type SubReportMsg struct {
	BusinessId  int64  `json:"business_Id"`
	TaskId      int64  `json:"task_Id"`
	ExtraInfo   string `json:"extra_info"`
	TargetEmail string `json:"target_email"`
}

const (
	larkUploadImgPoolSize = 20
)

var templateCommon = `[
    {
      "tag": "column_set",
      "flex_mode": "none",
      "background_style": "grey",
      "columns": [
        {
          "tag": "column",
          "width": "weighted",
          "weight": 1,
          "vertical_align": "top",
          "elements": [
            {
              "tag": "div",
              "text": {
                "content": "分析对象: ${target_name}",
                "tag": "plain_text"
              }
            }
          ]
        },
        {
          "tag": "column",
          "width": "weighted",
          "weight": 1,
          "vertical_align": "top",
          "elements": [
			{
              "tag": "markdown",
              "content": "创建人：<at email=${creator}></at>"
            }
          ]
        }
      ]
    },
    ${img_content},
    {
      "actions": [
        {
          "tag": "button",
          "text": {
            "content": "查看诊断详情",
            "tag": "plain_text"
          },
          "type": "primary",
          "multi_url": {
            "url": "${attribution_url}",
            "pc_url": "",
            "android_url": "",
            "ios_url": ""
          }
        }
      ],
      "tag": "action"
    }
  ]`

var screenWarnTemplate = `[
    {
      "tag": "column_set",
      "flex_mode": "none",
      "background_style": "grey",
      "columns": [
        {
          "tag": "column",
          "width": "weighted",
          "weight": 1,
          "vertical_align": "top",
          "elements": [
            {
              "tag": "div",
              "text": {
                "content": "分析对象: ${target_name}",
                "tag": "plain_text"
              }
            }
          ]
        },
        {
          "tag": "column",
          "width": "weighted",
          "weight": 1,
          "vertical_align": "top",
          "elements": [
			{
              "tag": "markdown",
              "content": "创建人：<at email=${creator}></at>"
            }
          ]
        }
      ]
    },
    {
      "tag": "div",
      "text": {
        "content": "${warn_msg}",
        "tag": "lark_md"
      }
    }
  ]`

var screenShotConfigCommon = `{"subscreen":{"url":"https://ecop.bytedance.net/product_insight/attribution?cjSiteCode=St12403140000002&type=screenshot","cookie":"00CJK63YWRCRTD6W62HUIFMN3FTSICEXNXUL4X4I5JMFH4C7PATSVAa662255939a32bb8c2a1dd77efc724f02ef60ac0981e1c13ad58c7887104f6efaf14a681bd75477884b5de057553e46026bc5a4ddc8e235fc570b45e4b107475e95fb30e2aa35f1bacc788ffcdf9bf7fb0271a30c01c8fef16818141c2ff42ad247ef5c14e23560beaead190f1cce30bcf725e3fdfc5322b37be0d4c81bdf6f38dc25d8e8d8380af094d333d076311d3924d8a0b3d1181fe4b25bdc04ba4af8b85b493193e738822ef2bf9fb69b4749c2dc6c622d80ff8d77da5db3b13060e89d57204aab28e4606f6fbf956fb480e236bc3e9646f4896f32e6a751063ebbfdf97","page_width":1280,"page_height":3000,"page_scale":2,"screen_shot_tasks":[{"sleep_time":25,"target_sel":"#attribution-global-diagnosis","target_sel_type":"by_id","img_name":"归因结论"}]},"table_chart":{}}`
