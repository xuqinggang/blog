package subscription

import (
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
	"math/rand"
	"strings"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom_smartop_data_subscription"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/subscription"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_smartop_data_subcription/kitex_gen/ecom/smartop/data_subcription"
	"code.byted.org/temai/ecom-smartop-matrix/tools"
	"code.byted.org/temai/go_lib/convert"
	"code.byted.org/temai/go_portal_sdk/models"
	"github.com/bytedance/sonic"
	"github.com/hashicorp/go-uuid"
	"github.com/thoas/go-funk"
)

const (
	// TODO: 待确认
	updateConfigDimCode = ""
	updateConfigDimVal  = ""
)

// 订阅配置 - 获取订阅通用配置
func (svc *SubscriptionService) GetSubscriptionConfig(ctx context.Context, req *subscription.GetSubscriptionConfigRequest) (resp *subscription.GetSubscriptionConfigResponse, err error) {
	configList, total, errDb := dao.FindSubscriptionConfig(ctx,
		0, req.GetPageName(), req.GetModuleName(), req.GetPage(), req.GetPageSize())
	if errDb != nil {
		err = errDb
		return
	}
	resp = &subscription.GetSubscriptionConfigResponse{
		Data:     &subscription.GetSubscriptionConfigData{ConfigList: configList, Total: total},
		BaseResp: base.NewBaseResp(),
	}

	return
}

// 获取单个订阅
func (svc *SubscriptionService) GetSubscriptionConfigById(ctx context.Context, id int64) (data *subscription.SubscriptionConfig, err error) {
	return dao.GetSubscriptionConfigById(ctx, id)
}

// 获取单个订阅
func (svc *SubscriptionService) GetUserSubscriptionById(ctx context.Context, id int64) (data *subscription.UserSubscription, err error) {
	return dao.GetUserSubscriptionRecord(ctx, id)
}

// 订阅管理 - 用户的所有订阅
func (svc *SubscriptionService) GetUserSubscriptionList(ctx context.Context, req *subscription.GetUserSubscriptionListRequest) (resp *subscription.GetUserSubscriptionListResponse, err error) {
	dataList, total, errDb := dao.FindUserSubscriptionRecord(ctx, req)
	if errDb != nil {
		err = errDb
		return
	}
	resp = &subscription.GetUserSubscriptionListResponse{
		Data:     &subscription.GetUserSubscriptionListData{Records: dataList, Total: total},
		BaseResp: base.NewBaseResp(),
	}

	return
}

// 订阅管理 - 推送预览
func (svc *SubscriptionService) PreviewUserSubscription(ctx context.Context, req *subscription.PreviewUserSubscriptionRequest) (err error) {
	if _, err = saveUserSubscriptionCheck(ctx, req.Task, true); err != nil {
		return
	}

	if req.Task.Creator == "" {
		currentUser, _ := utils.GetCurrentUser(ctx)
		req.Task.Creator = convert.ToString(currentUser.Email)
	}

	return ecom_smartop_data_subscription.PreviewSubscription(ctx, req)
}

// 订阅管理 - 保存/更新/暂停推送
func (svc *SubscriptionService) SaveUserSubscription(ctx context.Context, req *subscription.SaveUserSubscriptionRequest) (resp *subscription.SaveUserSubscriptionResponse, err error) {
	resp = &subscription.SaveUserSubscriptionResponse{BaseResp: base.NewBaseResp()}
	defer func() {
		if err != nil {
			resp.BaseResp.StatusCode = -1
			resp.BaseResp.StatusMessage = err.Error()
		}
	}()
	var subCenterId map[subscription.DateType]int64
	if subCenterId, err = saveUserSubscriptionCheck(ctx, req.Task, false); err != nil {
		return
	}

	var task *subscription.UserSubscription
	_ = sonic.UnmarshalString(convert.ToJSONString(req.Task), &task)
	currentUser, _ := utils.GetCurrentUser(ctx)
	if len(req.Task.BusinessKey) == 0 {
		task.BusinessKey = genBusinessKey(int64(req.Task.BusinessId))
	}

	// 如果是创建，需要先写DB
	var subId = req.Task.Id
	if req.Task.Id == 0 {
		subId, err = dao.CreateUserSubscriptionRecord(ctx, task, *currentUser, nil)
		task.Id = subId
		task.Status = subscription.Status_RUNING
	}

	// 同步到订阅中心
	dsIdMap, err := ecom_smartop_data_subscription.SaveSubscription(ctx, toDataSubscriptionSaveRequest(task, *currentUser, subCenterId))
	if err != nil {
		return
	}

	// if req.Task.Id == 0 {
	// 	subId, err = dao.CreateUserSubscriptionRecord(ctx, req.Task, *currentUser, dsIdMap)
	// } else {
	// 	err = dao.UpdateUserSubscriptionRecord(ctx, task, *currentUser, dsIdMap)
	// }

	// 保存数据
	err = dao.UpdateUserSubscriptionRecord(ctx, task, *currentUser, dsIdMap)
	if err != nil {
		return
	}

	resp.Data, err = dao.GetUserSubscriptionRecord(ctx, subId)

	return
}

// 订阅管理 - 删除推送
func (svc *SubscriptionService) DeleteUserSubscription(ctx context.Context, req *subscription.DeleteUserSubscriptionRequest) (err error) {
	if req == nil || req.SubId == 0 {
		err = errors.New("缺少必要参数")
		return
	}

	task, errDB := dao.GetUserSubscriptionRecord(ctx, req.SubId)
	if errDB != nil {
		err = errors.New("删除订阅失败，请稍后重试")
		return
	} else if task == nil {
		err = errors.New("订阅不存在，请刷新页面重试")
		return
	}
	var subCenterId map[subscription.DateType]int64
	task.Status = subscription.Status_DELETE
	subCenterId, err = saveUserSubscriptionCheck(ctx, task, false)
	if err != nil {
		return
	}

	// 更新DB
	currentUser, _ := utils.GetCurrentUser(ctx)
	if err = dao.UpdateUserSubscriptionRecord(ctx, task, *currentUser, subCenterId); err != nil {
		return
	}

	// 更新订阅中心状态
	_, _ = ecom_smartop_data_subscription.SaveSubscription(ctx, toDataSubscriptionSaveRequest(task, *currentUser, subCenterId))

	return
}

func saveUserSubscriptionCheck(ctx context.Context,
	task *subscription.UserSubscription, isPreview bool) (subCenterId map[subscription.DateType]int64, err error) {
	if task == nil || (task.ConfigId == 0 && task.Id == 0) {
		err = errors.New("缺少必要参数")
		return
	}

	currentUser, err := utils.GetCurrentUser(ctx)
	if err != nil {
		return
	}
	if currentUser == nil {
		err = errors.New("未登录")
		return
	}

	// 查看配置是否存在
	if dbConfig, errCfg := dao.GetSubscriptionConfigModel(ctx, task.ConfigId); errCfg != nil || dbConfig == nil {
		err = errors.New("订阅依赖的配置信息不存在")
		return
	} else if dbConfig.BusinessId != int64(task.BusinessId) {
		err = errors.New("订阅依赖的配置业务ID与当前订阅不一致")
		return
	}

	if task.Id == 0 {
		// 创建
		if !isPreview && (task.ConfigId == 0 || task.BusinessId == 0 ||
			len(task.SubscribeName) == 0 || (len(task.TargetGroup) == 0 && len(task.TargetUser) == 0) ||
			len(task.PushTime) == 0 || task.ContentType.String() == "<UNSET>" ||
			(task.ContentType == subscription.ContentType_ScreenShot && (task.Param == nil || task.Param.ScreenParam == nil || len(task.Param.ScreenParam.UrlParams) == 0))) {
			err = errors.New("创建订阅缺少必要参数")
			return
		}

		// 预览
		if isPreview && (task.ConfigId == 0 || task.BusinessId == 0 ||
			len(task.SubscribeName) == 0 ||
			task.ContentType.String() == "<UNSET>" ||
			(task.ContentType == subscription.ContentType_ScreenShot && (task.Param == nil || task.Param.ScreenParam == nil || len(task.Param.ScreenParam.UrlParams) == 0))) {
			err = errors.New("预览缺少必要参数")
			return
		}
	} else {
		// 修改订阅
		if dbSub, errDB := dao.GetUserSubscriptionRecordModel(ctx, task.Id); errDB != nil {
			err = errDB
			return
		} else if dbSub == nil {
			err = errors.New("无该订阅记录")
			return
		} else {
			var ownerEmail []*subscription.Target
			_ = sonic.UnmarshalString(dbSub.Owner, &ownerEmail)
			if currentUser.Email == nil || !funk.Contains(ownerEmail, func(t *subscription.Target) bool {
				return strings.Split(t.Email, "@")[0] == strings.Split(convert.ToString(currentUser.Email), "@")[0]
			}) {
				dimPerMap, errPerm := tools.CheckUserDimensionPermission(ctx, updateConfigDimCode, []string{updateConfigDimVal})
				if (errPerm != nil || len(dimPerMap) == 0 || !dimPerMap[updateConfigDimVal]) && !env.IsBoe() {
					err = errors.New("您无权修改该订阅，请联系订阅Owner修改")
					return
				}
			}

			_ = sonic.UnmarshalString(dbSub.SubCenterId, &subCenterId)
		}
	}

	return
}

func toDataSubscriptionSaveRequest(info *subscription.UserSubscription, currentUser models.UserInfo, subCenterId map[subscription.DateType]int64) (dsReq map[subscription.DateType]*data_subcription.SaveSubscribeConfigRpcReq) {
	var buildPushTimeReq = func(t *subscription.PushTime) *data_subcription.SaveSubscribeConfigRpcReq {
		req := &data_subcription.SaveSubscribeConfigRpcReq{
			SubscribeName:   convert.ToStringPtr(info.SubscribeName),
			SubscribeType:   []int32{1}, // 1:日常播报
			SubscribeStatus: convert.ToInt32Ptr(int32(info.Status)),
			ExtraInfo:       convert.ToStringPtr(convert.ToJSONString(info)),
			BotName:         convert.ToStringPtr("商品流量洞察"),
			OpUserId:        currentUser.EmployeeId,
			OpUserName:      currentUser.UserName,
			BusinessId:      int64(info.BusinessId),
			BusinessKey:     convert.ToStringPtr(info.BusinessKey),
		}
		if t != nil && len(subCenterId) > 0 && subCenterId[t.DateType] != 0 {
			req.SubscribeId = convert.ToInt64Ptr(subCenterId[t.DateType])
		}
		if len(info.TargetGroup) > 0 {
			for _, group := range info.TargetGroup {
				req.ChatGroupId = append(req.ChatGroupId, group.Id)
			}
		}
		if len(info.TargetUser) > 0 {
			for _, user := range info.TargetUser {
				req.SubcribeEmail = append(req.SubcribeEmail, user.Email)
			}
		}
		if t != nil {
			req.PushTime = []*data_subcription.PushTime{{
				IntervalUnit:  int32(int(t.DateType)),
				DayOfWeek:     t.DayOfWeek,
				DayOfMonth:    t.DayOfMonth,
				Hour:          t.Hour,
				Minute:        t.Minute,
				SubscribeType: 1,
			}}
		}

		if (req.SubscribeId == nil || *req.SubscribeId == 0) && int32(info.Status) == 0 {
			req.SubscribeStatus = convert.ToInt32Ptr(1) // 运行中
		}

		return req
	}

	dsReq = map[subscription.DateType]*data_subcription.SaveSubscribeConfigRpcReq{}
	for _, t := range info.PushTime {
		dsReq[t.DateType] = buildPushTimeReq(t)
	}

	return
}

func genBusinessKey(businessId int64) (key string) {
	uuidStr, err := uuid.GenerateUUID()
	if err != nil {
		uuidStr = fmt.Sprintf("%v_%v", time.Now().Nanosecond(), rand.New(rand.NewSource(int64(time.Now().Nanosecond()))).Int63()%1000000)
	}
	return fmt.Sprintf("bi_%v_%v", businessId, uuidStr)
}

func (svc *SubscriptionService) SaveSubscriptionFilterConfig(ctx context.Context, req *subscription.SaveSubscriptionFilterConfigRequest) (resp *subscription.SaveSubscriptionFilterConfigResponse, err error) {
	resp = &subscription.SaveSubscriptionFilterConfigResponse{BaseResp: base.NewBaseResp()}
	defer func() {
		if err != nil {
			resp.Code = -1
			resp.Msg = err.Error()
		}
	}()
	if req == nil || req.ConfigId == 0 {
		err = errors.New("缺少必要参数")
		return
	}
	config, configGetErr := dao.GetSubscriptionConfigModel(ctx, req.ConfigId)
	if configGetErr != nil {
		err = errors.New("查询配置失败")
		return
	}
	if config == nil {
		err = errors.New("配置不存在")
		return
	}
	uuidStr, err := uuid.GenerateUUID()
	if err != nil {
		uuidStr = fmt.Sprintf("%v_%v", time.Now().Nanosecond(), rand.New(rand.NewSource(int64(time.Now().Nanosecond()))).Int63()%1000000)
		return
	}
	logs.CtxInfo(ctx, "newUUID:%v", uuidStr)
	filterConfig, saveErr := dao.CreateSubscriptionFilterConfig(ctx, uuidStr, req.ConfigId, req.ConfigFilterMap)
	if saveErr != nil {
		err = errors.New("保存配置失败")
		return
	}
	if filterConfig == 0 {
		err = errors.New("保存失败")
		return
	}
	resp = &subscription.SaveSubscriptionFilterConfigResponse{
		ResId: uuidStr,
	}
	return
}
func (svc *SubscriptionService) GetSubscriptionFilterConfig(ctx context.Context, req *subscription.GetSubscriptionFilterConfigRequest) (resp *subscription.GetSubscriptionFilterConfigResponse, err error) {
	resp = &subscription.GetSubscriptionFilterConfigResponse{BaseResp: base.NewBaseResp()}
	defer func() {
		if err != nil {
			resp.Code = -1
			resp.Msg = err.Error()
		}
	}()
	item := &subscription.SubscriptionFilterConfigItem{}
	if req == nil || req.ResId == "" {
		err = errors.New("缺少必要参数")
		return
	}
	config, configGetErr := dao.GetSubscriptionFilterConfig(ctx, req.ResId)
	if configGetErr != nil {
		err = errors.New("查询配置失败")
		return
	}
	if config == nil {
		err = errors.New("配置不存在")
		return
	}
	var filterMap map[string]string
	if config.ConfigFilterMap == nil {
		filterMap = make(map[string]string)
	} else {
		castErr := sonic.Unmarshal([]byte(*config.ConfigFilterMap), &filterMap)
		if castErr != nil {
			err = castErr
			logs.CtxError(ctx, "castErr:%v", castErr)
			return
		}
	}
	item.ConfigFilterMap = filterMap
	item.ConfigId = config.ConfigId
	resp = &subscription.GetSubscriptionFilterConfigResponse{
		Data: item,
	}
	return
}
