package subscription

import (
	"context"
	"fmt"
	"net/url"
	"strings"
	"sync"
	"time"

	"code.byted.org/aweme-go/dsync"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom_smartop_data_img"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom_smartop_data_subscription"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/subscription"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_smartop_data_img/kitex_gen/ecom/smartop/data_img"
	"code.byted.org/overpass/ecom_smartop_data_subcription/kitex_gen/ecom/smartop/data_subcription"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
)

func (svc *SubscriptionService) SendCard(ctx context.Context, subReportMsg SubReportMsg) (err error) {
	var subInfo *subscription.UserSubscription
	if err = sonic.Unmarshal([]byte(subReportMsg.ExtraInfo), &subInfo); err != nil {
		logs.CtxError(ctx, "SendCard Unmarshal, extraInfo:%v, error:%+v", subReportMsg.ExtraInfo, err.Error())
		return
	}

	var dateType *subscription.DateType
	// 判断是及时消息还是日常消息
	if checkIsSendNow(subReportMsg) {
		logs.CtxInfo(ctx, "CheckisSendNow :yes")
		// 及时消息直接调接口发送
		if env.IsPPE() {
			ready, errCheck := svc.checkDataReady(ctx, subInfo)
			logs.CtxInfo(ctx, "SendCard now, extraInfo:%v, isReady=%v, err=%v", subReportMsg.ExtraInfo, ready, errCheck)
		}
		return svc.sendReport(ctx, subReportMsg, subInfo, dateType)
	}

	// 日常消息，判断数据是否产出
	// 查询当前的订阅
	dbSub, dbErr := dao.GetUserSubscriptionRecord(ctx, subInfo.Id)
	if dbErr != nil || dbSub == nil {
		err = errors.New("日常订阅记录不存在")
		logs.CtxInfo(ctx, "SendCard subscription db not exists, subId=%d, err=%v", subInfo.Id, dbErr)
		_ = sendTrigger(ctx, subInfo, subReportMsg.TaskId, subReportMsg.TargetEmail, 3, "") // 仅ACK，不发飞书消息
		return
	}
	if dbSub.Status != subscription.Status_RUNING {
		logs.CtxInfo(ctx, "SendCard subscription(id=%d) status != running", subInfo.Id)
		_ = sendTrigger(ctx, subInfo, subReportMsg.TaskId, subReportMsg.TargetEmail, 3, "") // 仅ACK，不发飞书消息
		return nil
	}

	ready, err := svc.checkDataReady(ctx, dbSub)
	if err != nil {
		return err
	}
	if !ready {
		// 如果数据没ready 直接返回
		logs.CtxInfo(ctx, "SendCard subscription(id=%d) not ready", subInfo.Id)
		return nil
	}
	if len(subInfo.PushTime) > 0 {
		dateType = &subInfo.PushTime[0].DateType
	}
	return svc.sendReport(ctx, subReportMsg, dbSub, dateType)
}

func (svc *SubscriptionService) sendReport(ctx context.Context, subReportMsg SubReportMsg,
	subInfo *subscription.UserSubscription, dateType *subscription.DateType) (err error) {
	if subInfo == nil {
		return
	}
	var dbSub *subscription.UserSubscription
	var configId = subInfo.ConfigId
	if subInfo.Id > 0 {
		// 实际调度的订阅
		if dbSub, err = svc.GetUserSubscriptionById(ctx, subInfo.Id); err != nil {
			return err
		} else if dbSub == nil {
			err = errors.New("订阅ID对应的订阅配置不存在")
			return
		}
		configId = dbSub.ConfigId
	}

	dbConfig, err := svc.GetSubscriptionConfigById(ctx, configId)
	if err != nil {
		return
	} else if dbConfig == nil {
		err = errors.New("依赖的订阅配置不存在")
		return
	}

	var content string
	if dbSub != nil {
		switch dbSub.ContentType {
		case subscription.ContentType_ScreenShot:
			content, err = buildScreenshotContent(ctx, dbSub, dbConfig)
		default:
			return
		}
	} else {
		switch subInfo.ContentType {
		case subscription.ContentType_ScreenShot:
			content, err = buildScreenshotContent(ctx, subInfo, dbConfig)
		default:
			return
		}
	}

	// 非立即推送（定时推送），遇到有err，就不ACK，则需要等到下次调度
	if subReportMsg.TargetEmail == "" && err != nil {
		return
	}

	// 6.发送
	// req := data_subcription.NewBusinessTriggerReq()
	// req.BusinessId = int64(subInfo.BusinessId)
	// req.TaskId = subReportMsg.TaskId
	// req.BusinessAckStatus = 2
	// if subReportMsg.TargetEmail != "" {
	// 	req.TargetEmail = convert.ToStringPtr(subReportMsg.TargetEmail)
	// }
	// req.CardContent = &data_subcription.FeiShuContent{
	// 	Title:    convert.ToStringPtr(subInfo.SubscribeName),
	// 	Elements: convert.ToStringPtr(content),
	// 	Color:    convert.ToStringPtr("orange"),
	// }
	// err = ecom_smartop_data_subscription.BusinessTrigger(ctx, req)
	// if err != nil {
	// 	logs.CtxError(ctx, "SendReports BusinessTrigger req: %v, error:%+v", convert.ToJSONString(req), err.Error())
	// 	return err
	// }
	// return nil
	return sendTrigger(ctx, subInfo, subReportMsg.TaskId, subReportMsg.TargetEmail, 2, content)
}

// 构建截图消息
func buildScreenshotContent(ctx context.Context, subInfo *subscription.UserSubscription, subConfig *subscription.SubscriptionConfig) (content string, err error) {
	defer func() {
		if env.IsPPE() {
			logs.CtxInfo(ctx, "buildScreenshotContent, subInfo=%v, subConfig=%v, content=%v",
				convert.ToJSONString(subInfo), convert.ToJSONString(subConfig), content)
		}
	}()

	if subInfo == nil {
		logs.CtxInfo(ctx, "subInfo empty:%v", subInfo)
		return
	}

	var targetName string
	if subInfo.Param != nil && subInfo.Param.ScreenParam != nil {
		targetName = convert.ToString(subInfo.Param.ScreenParam.TargetName)
	}

	// 构建消息内容
	templateParam := map[string]interface{}{
		"target_name": targetName,
		"creator":     subInfo.Creator,
		"title":       subInfo.SubscribeName,
	}

	var formatErr error
	if subInfo.ContentType != subscription.ContentType_ScreenShot || subConfig == nil || subConfig.ExtraInfo == nil ||
		subConfig.ExtraInfo.Subscreen == nil {
		templateParam["warn_msg"] = "截图缺少必要参数,请联系相关产研"
		content, formatErr = utils.StringFormatByRegex(screenWarnTemplate, templateParam)
		if env.IsPPE() {
			logs.CtxInfo(ctx, "buildScreenshotContent, param error, content:%v, err:%v", content, formatErr)
		}
		return
	}

	template := subConfig.Template[subInfo.ContentType]
	if env.IsBoe() {
		template = templateCommon
	}

	logs.CtxInfo(ctx, "buildScreenshotContent, template:%v", template)
	logs.CtxInfo(ctx, "subConfig:%v", convert.ToJSONString(subConfig))
	imgReq, err := buildScreenShotReq(ctx, subInfo, subConfig)
	if err != nil {
		templateParam["warn_msg"] = "构建截图请求参数失败,请稍后重试"
		content, formatErr = utils.StringFormatByRegex(screenWarnTemplate, templateParam)
		if env.IsPPE() {
			logs.CtxInfo(ctx, "buildScreenshotContent, screenReq error, content:%v, err:%v", content, formatErr)
		}
		return
	}
	// 截图
	templateParam["attribution_url"] = imgReq.Url
	logs.CtxInfo(ctx, "buildScreenshotContent, CreateScreenShot, imgReq:%v", convert.ToJSONString(imgReq))
	imgList, err := ecom_smartop_data_img.CreateScreenShot(ctx, imgReq)
	if err != nil || len(imgList) == 0 {
		content, formatErr = utils.StringFormatByRegex(screenWarnTemplate, templateParam)
		if env.IsPPE() {
			logs.CtxInfo(ctx, "buildScreenshotContent, emptyImg, content:%v, err:%v", content, formatErr)
		}
		if err == nil {
			err = formatErr
		}
		return
	}

	// 上传图片
	imgKeyList, err := GetImgKeyMap(ctx, int64(subInfo.BusinessId), imgList)
	if err != nil {
		templateParam["warn_msg"] = "截图上传飞书失败，请稍后重试"
		content, formatErr = utils.StringFormatByRegex(screenWarnTemplate, templateParam)
		if env.IsPPE() {
			logs.CtxInfo(ctx, "buildScreenshotContent, img upload error, content:%v, err:%v", content, formatErr)
		}
		if err == nil {
			err = formatErr
		}
		return
	}

	// 构建截图部分的模板
	var larkCard = make([]interface{}, 0)
	var larkCardString []string
	for _, imgKey := range imgKeyList {
		larkImg := map[string]interface{}{
			"tag":     "img",
			"img_key": imgKey,
			"alt": map[string]interface{}{
				"tag":     "plain_text",
				"content": "图片",
			},
			"mode": "fit_horizontal",
		}
		larkCard = append(larkCard, larkImg)
		larkCardString = append(larkCardString, convert.ToJSONString(larkImg))
	}

	templateParam["img_content"] = strings.Join(larkCardString, ",")
	logs.CtxInfo(ctx, "buildScreenshotContent, final templateParam:%v", templateParam)
	logs.CtxInfo(ctx, "buildScreenshotContent, final template :%v", template)
	content, err = utils.StringFormatByRegex(template, templateParam)
	if env.IsPPE() {
		logs.CtxInfo(ctx, "buildScreenshotContent, content:%v, err:%v", content, err)
	}

	return
}

func checkIsSendNow(subReportMsg SubReportMsg) bool {
	if subReportMsg.TargetEmail != "" {
		return true
	}
	return false
}

func (svc *SubscriptionService) checkDataReady(ctx context.Context, subInfo *subscription.UserSubscription) (isReady bool, err error) {
	resp, err := svc.DimensionService.GetReadyTime(ctx, subInfo.BizType)
	logs.CtxInfo(ctx, "SendCard.checkDateReady, subInfo:%v, resp=%v, err: %v",
		convert.ToJSONString(subInfo), resp, err)
	if err != nil {
		return
	} else if resp == nil || len(resp.NewestPartition_) == 0 {
		return
	}

	// 按日推送，产出了即可推送
	if len(subInfo.PushTime) == 0 || (subInfo.PushTime[0].DateType == subscription.DateType_Day) {
		bizInfo, _, errGet := biz_utils.GetBizMetaInfo(ctx, subInfo.BizType)
		if env.IsPPE() {
			logs.CtxInfo(ctx, "Subscription.checkDataReady: subInfo=%v, bizInfo=%v, errGet=%v", subInfo, bizInfo, errGet)
		}
		if errGet != nil || bizInfo == nil {
			logs.CtxWarn(ctx, "业务线未发现元信息, bizType = %d", subInfo.BizType)
			err = errors.New("未能获取到业务线信息")
			return
		}
		offsetDays := int(bizInfo.DataDelayDay)
		if offsetDays == 0 {
			offsetDays = 1
		}
		shouldReadyDay := time.Now().AddDate(0, 0, -offsetDays).Format(consts.FmtDateSlash)
		if resp.NewestPartition_ == shouldReadyDay {
			isReady = true
		}
	} else {
		partitionDay, _ := time.ParseInLocation(consts.FmtDateSlash, resp.NewestPartition_, time.Local)
		if subInfo.PushTime[0].DateType == subscription.DateType_Week {
			weekDay := int32(partitionDay.Weekday())
			if weekDay == 0 { // 周日
				weekDay = 7
			}
			// 周粒度，如果数据产出日 是周X = 预计推送的周X
			if weekDay == subInfo.PushTime[0].GetDayOfWeek() {
				isReady = true
			}
		} else if subInfo.PushTime[0].DateType == subscription.DateType_Month && partitionDay.Day() == int(subInfo.PushTime[0].GetDayOfMonth()) {
			// 月粒度，如果数据产出日 是月X = 预计推送的月X
			isReady = true
		}
	}

	return
}

func buildScreenShotReq(ctx context.Context, subInfo *subscription.UserSubscription, subConfig *subscription.SubscriptionConfig) (imgReq *data_img.ScreenShotRequest, err error) {
	// 构建截图请求参数
	uri, _ := url.Parse(subConfig.ExtraInfo.Subscreen.Url)
	uriValues := uri.Query()
	if subInfo.Param != nil && subInfo.Param.ScreenParam != nil && len(subInfo.Param.ScreenParam.UrlParams) > 0 {
		for k, v := range subInfo.Param.ScreenParam.UrlParams {
			uriValues.Add(k, v)
		}
	}
	if len(subInfo.PushTime) > 0 && len(subInfo.PushTime[0].UrlParams) > 0 {
		for k, v := range subInfo.PushTime[0].UrlParams {
			uriValues.Add(k, v)
		}
	}

	uri.RawQuery = uriValues.Encode()
	param := subConfig.ExtraInfo
	if env.IsPPE() && subInfo.ConfigId == 1 {
		err = sonic.UnmarshalString(screenShotConfigCommon, &param)
		if param.Subscreen == nil {
			return
		}
	}

	imgReq = &data_img.ScreenShotRequest{
		Url:        uri.String(),
		Cookie:     convert.ToStringPtr(param.Subscreen.Cookie),
		PageWidth:  convert.ToInt64Ptr(param.Subscreen.PageWidth),
		PageHeight: convert.ToInt64Ptr(param.Subscreen.PageHeight),
		PageScale:  convert.ToFloat64Ptr(param.Subscreen.PageScale),
	}
	for _, task := range param.Subscreen.ScreenShotTasks {
		actionList := make([]*data_img.UserAction, 0, len(task.Actions))
		if len(task.Actions) > 0 {
			for _, action := range task.Actions {
				newAction := &data_img.UserAction{
					ActionType: action.ActionType,
				}
				if len(action.WaitSel) > 0 {
					newAction.WaitSel = &action.WaitSel
				}
				if len(action.WaitSelType) > 0 {
					newAction.WaitSelType = &action.WaitSelType
				}
				if action.SleepTime != 0 {
					newAction.SleepTime = &action.SleepTime
				}
				if action.ClickAction != nil {
					newAction.ClickAction = &data_img.ClickAction{
						Sel:     action.ClickAction.Sel,
						SelType: action.ClickAction.SelType,
					}
				}
				actionList = append(actionList, newAction)
			}
		}

		tt := &data_img.ScreenShotTask{
			Actions:       actionList,
			TargetSel:     task.TargetSel,
			TargetSelType: task.TargetSelType,
			ImgName:       task.ImgName,
			IncludeTexts:  param.Subscreen.OcrWords,
		}
		if len(task.AfterWaitSel) > 0 {
			tt.AfterWaitSel = &task.AfterWaitSel
		}
		if len(task.AfterWaitSelType) > 0 {
			tt.AfterWaitSelType = &task.AfterWaitSelType
		}
		if task.SleepTime != 0 {
			tt.SleepTime = &task.SleepTime
		}
		imgReq.ScreenShotTasks = append(imgReq.ScreenShotTasks, tt)
	}

	return
}

// 获取img在飞书开放平台的key
func GetImgKeyMap(ctx context.Context, businessId int64, reportImages []*data_img.ScreenShotImg) (imgKeyList []string, err error) {
	var lock sync.Mutex
	var errorList []error
	pool := dsync.NewGoPool(larkUploadImgPoolSize)
	imgKeyList = make([]string, len(reportImages))
	for idx, reportImg := range reportImages {
		tmpReportImg := reportImg
		tmpIdx := idx
		_ = pool.Go(ctx, func() {
			imgKey, err := lark_service.UploadImage(ctx, businessId, tmpReportImg.ImgStr, tmpReportImg.ImgName)
			lock.Lock()
			if err != nil {
				errorList = append(errorList, err)
			} else {
				imgKeyList[tmpIdx] = imgKey
			}
			lock.Unlock()
		})
	}
	pool.Wait()

	if len(errorList) > 0 {
		err = errors.New(fmt.Sprintf("UploadImage err:%+v", errorList[0].Error()))
		return
	}
	return
}

func sendTrigger(ctx context.Context, subInfo *subscription.UserSubscription, taskId int64, targetEmail string, ackStatus int32, content string) (err error) {
	req := data_subcription.NewBusinessTriggerReq()
	req.BusinessId = int64(subInfo.BusinessId)
	req.TaskId = taskId
	req.BusinessAckStatus = ackStatus
	if targetEmail != "" {
		req.TargetEmail = convert.ToStringPtr(targetEmail)
	}
	req.CardContent = &data_subcription.FeiShuContent{
		Title:    convert.ToStringPtr(subInfo.SubscribeName),
		Elements: convert.ToStringPtr(content),
		Color:    convert.ToStringPtr("orange"),
	}
	err = ecom_smartop_data_subscription.BusinessTrigger(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "SendReports BusinessTrigger req: %v, error:%+v", convert.ToJSONString(req), err.Error())
		return err
	}
	return
}
