package product_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"context"
	"errors"
)

func (d *ProductReviewService) IGetProductReviewStrategyTypeList(ctx context.Context, req *prod_review.GetProdReviewStrategyTypeListRequest) (resp *prod_review.GetProdReviewStrategyTypeListResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[IGetProductReviewStrategyTypeList] IGetProductReviewStrategyTypeList Err:%s", err.Error())
		}
	}()

	if req == nil {
		return nil, errors.New("[IGetProductReviewStrategyTypeList] invalid params")
	}

	bizMetaInfo, ctx, _ := biz_utils.GetBizMetaInfo(ctx, req.GetBizType())
	dependBizType := req.GetBizType()
	if bizMetaInfo != nil && bizMetaInfo.DependBizID != 0 {
		dependBizType = dimensions.BizType(bizMetaInfo.DependBizID)
	}
	strategyTypes, err := d.StrategyTypeDao.GetStrategyTypeBizType(ctx, dependBizType)

	if err != nil {
		logs.CtxError(ctx, "[IGetProductReviewStrategyTypeList] IGetProductReviewStrategyTypeList err: %v", err)
		return nil, err
	}

	return &prod_review.GetProdReviewStrategyTypeListResponse{
		Data: TransStrategyTypeDao(strategyTypes),
	}, nil
}
