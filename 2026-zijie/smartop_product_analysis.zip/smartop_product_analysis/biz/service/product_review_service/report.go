package product_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/temai/go_lib/convert"
	"code.byted.org/temai/go_portal_sdk/models"
	"context"
	"errors"
	"github.com/bytedance/sonic"
	"time"
)

func (d *ProductReviewService) ICreateAndUpdateProdReviewReport(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewReportRequest) (resp *prod_review.CreateAndUpdateProdReviewReportResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewReport] ICreateAndUpdateProdReviewReport Err:%s", err.Error())
		}
	}()

	if req == nil || req.Report == nil {
		return nil, errors.New("[ICreateAndUpdateProdReviewReport] invalid params")
	}

	filterDimensions, err := sonic.MarshalString(req.Report.FilterDimensions)
	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewReport] MarshalString filterDimensions err: %v", err)
		return nil, err
	}
	compareFilterDimensions, err := sonic.MarshalString(req.Report.CompareFilterDimensions)
	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewReport] MarshalString CompareFilterDimensions err: %v", err)
		return nil, err
	}

	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.Email == nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewBizProject] userInfo is nil")
		return nil, errors.New("[ICreateAndUpdateProdReviewBizProject] userInfo is nil")
	}

	if convert.ToInt64(req.Report.ReportId) != 0 {
		// 新增：权限校验
		oldReport, _, qErr := d.ReportDao.GetProductReviewReportList(ctx, &dao.ProductReviewReportQueryParams{
			ReportId: convert.ToInt64(req.Report.ReportId),
		})
		if qErr != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewReport] GetProductReviewReportById err: %v", qErr)
			return nil, qErr
		}
		if len(oldReport) == 0 {
			return nil, errors.New("[ICreateAndUpdateProdReviewReport] report not found")
		}
		if !checkReportEditPermission(ctx, userInfo, oldReport[0]) {
			return nil, errors.New("[ICreateAndUpdateProdReviewReport] permission denied: only creator can update")
		}
		err = d.ReportDao.UpdateProductReviewReport(ctx, convert.ToInt64(req.Report.ReportId), &dao.ProductReviewReport{
			ReportName:              req.Report.ReportName,
			RelationId:              convert.ToInt64(req.Report.RelationId),
			BizId:                   int(req.Report.BizType),
			EntityType:              int(req.Report.EntityType),
			FilterDimensions:        filterDimensions,
			CompareFilterDimensions: compareFilterDimensions,
			CompareProdPoolType:     int(req.Report.CompareProdPoolType),
			UpdateUser:              gptr.Indirect(userInfo.Email),
			UpdateTime:              time.Now(),
			IsDelete:                int(req.Report.IsDel),
		})

		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewReport] UpdateProductReviewReport err: %v", err)
			return nil, err
		}

		return &prod_review.CreateAndUpdateProdReviewReportResponse{
			Data: true,
		}, nil

	}

	err = d.ReportDao.CreateProductReviewReport(ctx, &dao.ProductReviewReport{
		ReportName:              req.Report.ReportName,
		RelationId:              convert.ToInt64(req.Report.RelationId),
		EntityType:              int(req.Report.EntityType),
		FilterDimensions:        filterDimensions,
		CompareFilterDimensions: compareFilterDimensions,
		CompareProdPoolType:     int(req.Report.CompareProdPoolType),
		CreateUser:              gptr.Indirect(userInfo.Email),
		CreateTime:              time.Now(),
		IsDelete:                int(req.Report.IsDel),
		BizId:                   int(req.Report.BizType),
	})

	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewReport] CreateProductReviewReport err: %v", err)
		return nil, err
	}

	return &prod_review.CreateAndUpdateProdReviewReportResponse{
		Data: true,
	}, nil
}

func (d *ProductReviewService) IGetProductReviewReportList(ctx context.Context, req *prod_review.GetProdReviewReportListRequest) (resp *prod_review.GetProdReviewReportListResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[IGetProductReviewReportList] IGetProductReviewReportList Err:%s", err.Error())
		}
	}()
	if req == nil {
		return nil, errors.New("[IGetProductReviewReportList] invalid params")
	}
	bizMetaInfo, ctx, _ := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	bizRequiredDimInfos := make([]*dimensions.SelectedDimensionInfo, 0)
	bizIds := make([]int64, 0)
	if bizMetaInfo != nil {
		bizRequiredDimInfos = append(bizRequiredDimInfos, bizMetaInfo.RequiredDimInfo...)
		bizList, err := d.BizListDao.GetBizEffectModuleList(ctx, bizMetaInfo.EffectModule)
		if err != nil {
			logs.CtxError(ctx, "[IGetProductReviewStrategyList] GetBizEffectModuleList err: %v", err)
			return nil, err
		}
		for _, biz := range bizList {
			bizIds = append(bizIds, int64(biz.BizType))
		}
	}
	reportList, count, err := d.ReportDao.GetProductReviewReportList(ctx, &dao.ProductReviewReportQueryParams{
		ReportId:   convert.ToInt64(req.ReportId),
		ReportName: req.ReportName,
		CreateUser: req.CreateUser,
		BizIds:     bizIds,
		IsDeleted:  0,
		PageNum:    int(req.PageNum),
		PageSize:   int(req.PageSize),
	})

	if err != nil {
		logs.CtxError(ctx, "[IGetProductReviewReportList] IGetProductReviewReportList err: %v", err)
		return nil, err
	}
	newReportList := TransReportDao(ctx, reportList)
	for _, report := range newReportList {
		if len(bizRequiredDimInfos) > 0 { // 加入视角的限制维度
			report.FilterDimensions = append(report.FilterDimensions, bizRequiredDimInfos...)
		}
		if report.EntityType == prod_review.EntityType_Strategy {
			strategyReq := &prod_review.GetProdReviewStrategyListRequest{
				BizType:             req.BizType,
				StrategyIds:         []string{report.RelationId},
				AnalysisStartDate:   req.AnalysisStartDate,
				AnalysisEndDate:     req.AnalysisEndDate,
				IsNeedReturnTargets: req.IsNeedReturnTargets,
			}
			res, err := d.IGetProductReviewStrategyList(ctx, strategyReq, report.FilterDimensions)
			if err != nil {
				logs.CtxError(ctx, "[IGetProductReviewStrategyList] IGetProductReviewBizProjectList err: %v", err)
			}
			if res != nil && res.Data != nil && len(res.Data.StrategyList) > 0 {
				report.ProdReviewStrategy = res.Data.StrategyList[0]
			}
		} else if report.EntityType == prod_review.EntityType_BizProject {
			bizProjectReq := &prod_review.GetProdReviewBizProjectListRequest{
				BizType:             req.BizType,
				BizProjectId:        report.RelationId,
				AnalysisStartDate:   req.AnalysisStartDate,
				AnalysisEndDate:     req.AnalysisEndDate,
				IsNeedReturnTargets: req.IsNeedReturnTargets,
			}
			res, err := d.IGetProductReviewBizProjectList(ctx, bizProjectReq, report.FilterDimensions)
			if err != nil {
				logs.CtxError(ctx, "[IGetProductReviewBizProjectList] IGetProductReviewBizProjectList err: %v", err)
			}
			if res != nil && res.Data != nil && len(res.Data.BizProjectList) > 0 {
				report.BizProject = res.Data.BizProjectList[0]
			}
		}
	}

	return &prod_review.GetProdReviewReportListResponse{
		Data: &prod_review.GetProdReviewReportListData{
			ReportList: newReportList,
			TotalCount: count,
		},
	}, nil
}

func checkReportEditPermission(ctx context.Context, userInfo *models.UserInfo, report *dao.ProductReviewReport) bool {
	if report == nil {
		return false
	}
	if userInfo == nil || userInfo.Email == nil {
		logs.CtxError(ctx, "[checkReportEditPermission] userInfo is nil")
		return false
	}
	return report.CreateUser == gptr.Indirect(userInfo.Email)
}
