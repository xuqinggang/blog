package product_review_service

import (
	"code.byted.org/ecom/common/utils/async2"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"github.com/bytedance/sonic"
	"sort"
	"sync"
	"time"
)

// GetStrategyListTarget 获取策略列表外露指标
func (t *ProductReviewService) GetStrategyListTarget(ctx context.Context, req *prod_review.GetProdReviewStrategyListRequest, strategyList []*dao.ProductReviewStrategy, strategyTypeIdToType map[int64]*dao.ProductReviewStrategyType, filterDimensions []*dimensions.SelectedDimensionInfo) map[int64][]*analysis.TargetCardEntity {

	res := make(map[int64][]*analysis.TargetCardEntity)

	dependBizType := req.BizType
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if bizMetaInfo != nil && bizMetaInfo.DependBizID != 0 {
		dependBizType = dimensions.BizType(bizMetaInfo.DependBizID)
	}

	dimensionListDao := &dao.DimensionListDao{}

	// 获取业务线的维度信息
	dimMap, err := dimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取map失败，err=%v+", err)
		return nil
	}
	dimColMap, err := dimensionListDao.GetDimensionColMap(ctx, dependBizType)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取col map失败，err=%v+", err)
		return nil
	}

	params := make(map[string]interface{})
	queryItems := make([]map[string]interface{}, 0)

	readyTime, err := t.DimensionService.GetReadyTime(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]GetReadyTime失败，err=%v+", err)
		return nil
	}

	for _, strategy := range strategyList {
		strategy := strategy // 捕获循环变量
		strategyTypeId := strategy.StrategyTypeId
		if _, ok := strategyTypeIdToType[strategyTypeId]; !ok {
			continue
		}

		strategyType := strategyTypeIdToType[strategyTypeId]
		selectedDimensionInfos := make([]*dimensions.SelectedDimensionInfo, 0)
		if err := sonic.UnmarshalString(strategy.RelationProdPool, &selectedDimensionInfos); err != nil {
			logs.CtxError(ctx, "[GetStrategyListTarget]获取策略关联条件失败，err=%v+", err)
			continue
		}

		var startDate, endDate string
		// 取策略最新一天数据
		newestTime := readyTime.NewestPartition_
		newestDay, err := time.Parse(consts.Fmt_Date, newestTime)
		if err != nil {
			logs.CtxError(ctx, "[GetStrategyListTarget]Parse newestTime failed, err=%v+", err)
			continue
		}
		if !strategy.StartDate.IsZero() && !strategy.EndDate.IsZero() && strategy.EndDate.Before(newestDay) {
			startDate = strategy.EndDate.Format(consts.Fmt_Date)
			endDate = strategy.EndDate.Format(consts.Fmt_Date)
		} else {
			startDate = newestDay.Format(consts.Fmt_Date)
			endDate = newestDay.Format(consts.Fmt_Date)
		}

		curr, err := buildStrategyQueryParams(ctx, dependBizType, strategy, strategyType, dimMap, dimColMap, startDate, endDate, filterDimensions)
		if err != nil {
			logs.CtxError(ctx, "[GetStrategyListTarget]获取策略关联条件失败，err=%v+", err)
			continue
		}
		curr["start_date"] = startDate
		curr["end_date"] = endDate
		curr["strategy_id"] = strategy.StrategyId
		queryItems = append(queryItems, curr)
	}
	params["query_items"] = queryItems
	apiPath, ok := BizApiMap[dependBizType][SingleStrategyCoverProd]
	if !ok {
		logs.CtxError(ctx, "GetStrategyListTarget apiPath not  found, bizType=%v", req.BizType)
		return nil
	}
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: params, Sql: consts.Empty, ApiPath: apiPath, BizType: dependBizType, KeyCols: []string{"strategy_id"},
	})
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]GetTargetListWithKeyColumn 失败，err=%v+", err)
		return nil
	}
	logs.CtxInfo(ctx, "GetStrategyListTarget GetTargetListWithKeyColumn 成功，res=%v+", currTargetList)

	for _, targetEntity := range currTargetList {
		if len(targetEntity.KeyColValues) == 0 || len(targetEntity.TargetEntity) == 0 {
			continue
		}
		sort.SliceStable(targetEntity.TargetEntity, func(i, j int) bool {
			return targetEntity.TargetEntity[i].DisplayOrder < targetEntity.TargetEntity[j].DisplayOrder
		})
		strategyId := convert.ToInt64(targetEntity.KeyColValues[0])
		res[strategyId] = append(res[strategyId], targetEntity.TargetEntity...)
	}
	return res
}

// GetBizProjectListTarget 获取业务专项业务列表
func GetBizProjectListTarget(ctx context.Context, req *prod_review.GetProdReviewBizProjectListRequest, bizProjectList []*dao.ProductReviewBizProject, filterDimensions []*dimensions.SelectedDimensionInfo) map[int64][]*analysis.TargetCardEntity {

	res := make(map[int64][]*analysis.TargetCardEntity)

	dependBizType := req.BizType
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if bizMetaInfo != nil && bizMetaInfo.DependBizID != 0 {
		dependBizType = dimensions.BizType(bizMetaInfo.DependBizID)
	}
	dimensionListDao := &dao.DimensionListDao{}

	// 获取业务线的维度信息
	dimMap, err := dimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取map失败，err=%v+", err)
		return nil
	}
	dimColMap, err := dimensionListDao.GetDimensionColMap(ctx, dependBizType)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取col map失败，err=%v+", err)
		return nil
	}
	// 并发处理 strategyList
	var (
		mu sync.Mutex // 保护对 res 的写入
	)

	as := async2.New(ctx)

	for _, bizProject := range bizProjectList {
		bizProjectItem := bizProject // 捕获循环变量
		as.Add(func() {
			{
				selectedDimensionInfos := make([]*dimensions.SelectedDimensionInfo, 0)
				if err := sonic.UnmarshalString(bizProjectItem.FilterDimensions, &selectedDimensionInfos); err != nil {
					logs.CtxError(ctx, "[GetStrategyListTarget]获取策略关联条件失败，err=%v+", err)
					return
				}
				if len(filterDimensions) > 0 {
					selectedDimensionInfos = append(selectedDimensionInfos, filterDimensions...)
				}
				curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx,
					base_struct_condition.OsParamsReq{
						BaseStruct: &dimensions.ProductAnalysisBaseStruct{
							BizType:          dependBizType,
							StartDate:        req.AnalysisStartDate,
							EndDate:          req.AnalysisEndDate,
							CompareStartDate: req.AnalysisStartDate,
							CompareEndDate:   req.AnalysisEndDate,
							Dimensions:       selectedDimensionInfos,
						},
						DimMap:    dimMap,
						DimColMap: dimColMap,
					})
				if err != nil {
					return
				}
				apiPath, ok := BizApiMap[dependBizType][BizProjectTargetList]
				if !ok {
					logs.CtxError(ctx, "GetStrategyListTarget apiPath not found, bizType=%v", req.BizType)
					return
				}
				currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
					Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: dependBizType,
				})
				if err != nil {
					logs.CtxError(ctx, "[GetStrategyListTarget]GetTargetListWithKeyColumn 失败，err=%v+", err)
					return
				}
				mu.Lock()
				defer mu.Unlock()
				for _, targetEntity := range currTargetList {
					res[bizProjectItem.BizProjectId] = append(res[bizProjectItem.BizProjectId], targetEntity.TargetEntity...)
				}
				sort.SliceStable(res[bizProjectItem.BizProjectId], func(i, j int) bool {
					return res[bizProjectItem.BizProjectId][i].DisplayOrder < res[bizProjectItem.BizProjectId][j].DisplayOrder
				})
				return
			}
		})
	}
	as.RunWithRecover() // 忽略错误
	return res
}
