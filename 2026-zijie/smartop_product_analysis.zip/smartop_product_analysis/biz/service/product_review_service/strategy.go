package product_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/lang/gg/gslice"
	"code.byted.org/temai/go_lib/convert"
	"code.byted.org/temai/go_portal_sdk/models"
	"context"
	"errors"
	"github.com/bytedance/sonic"
	"strings"
	"time"
)

func (d *ProductReviewService) ICreateAndUpdateProdReviewStrategy(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewStrategyRequest) (resp *prod_review.CreateAndUpdateProdReviewStrategyResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] ICreateAndUpdateProdReviewStrategy Err:%s", err.Error())
		}
	}()

	if req == nil || req.Strategy == nil {
		return nil, errors.New("[ICreateAndUpdateProdReviewStrategy] invalid params")
	}

	relationProdPool, err := sonic.MarshalString(req.Strategy.RelationProdPool)
	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] MarshalString RelationProdPool err: %v", err)
		return nil, err
	}

	var baseVersionInfo, allVersionInfo string

	if req.Strategy.BaseVersionInfo != nil {
		baseVersionInfo, err = sonic.MarshalString(req.Strategy.BaseVersionInfo)
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] MarshalString BaseVersionInfo err: %v", err)
			return nil, err
		}
	}

	if len(req.Strategy.AllVersionInfo) != 0 {
		allVersionInfo, err = sonic.MarshalString(req.Strategy.AllVersionInfo)
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] MarshalString AllExpVersionInfo err: %v", err)
			return nil, err
		}
	}

	strategyReachRule, err := sonic.MarshalString(req.Strategy.StrategyReachRule)
	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] MarshalString StrategyReachRule err: %v", err)
		return nil, err
	}

	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.Email == nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] userInfo is nil")
		return nil, errors.New("[ICreateAndUpdateProdReviewStrategy] userInfo is nil")
	}

	shortGoal, longGoal := req.Strategy.ShortTermGoal, req.Strategy.LongTermGoal

	// ---------------- 更新 ----------------
	if convert.ToInt64(req.Strategy.StrategyId) != 0 {
		// 新增：权限校验
		oldStrategy, _, qErr := d.StrategyDao.GetProductReviewStrategyList(ctx, &dao.ProductReviewStrategyQueryParams{
			StrategyIds: []int64{convert.ToInt64(req.Strategy.StrategyId)},
		})
		if qErr != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] GetProductReviewStrategyById err: %v", qErr)
			return nil, qErr
		}
		if len(oldStrategy) == 0 {
			return nil, errors.New("[ICreateAndUpdateProdReviewStrategy] strategy not found")
		}
		if !checkStrategyEditPermission(ctx, userInfo, oldStrategy[0]) {
			return nil, errors.New("[ICreateAndUpdateProdReviewStrategy] permission denied: only creator can update")
		}

		err = d.StrategyDao.UpdateProductReviewStrategy(ctx, convert.ToInt64(req.Strategy.StrategyId), &dao.ProductReviewStrategy{
			StrategyName:        req.Strategy.StrategyName,
			StrategyDesc:        req.Strategy.StrategyDesc,
			Granularity:         int(req.Strategy.Granularity),
			StrategyTypeId:      convert.ToInt64(req.Strategy.StrategyType.StrategyTypeId),
			AnalysisPerspective: int(req.Strategy.AnalysisPerspective),
			StartDate:           time.Unix(req.Strategy.StartDate, 0),
			EndDate:             time.Unix(req.Strategy.EndDate, 0),
			FlightId:            convert.ToInt64(req.Strategy.FlightId),
			BaseVersionInfo:     baseVersionInfo,
			AllExpVersionInfo:   allVersionInfo,
			RelationProdPool:    relationProdPool,
			TargetList:          strings.Join(req.Strategy.TargetList, ","),
			AAIncreaseCalType:   int(req.Strategy.AaIncreaseCalType),
			StatisticType:       int(req.Strategy.StatisticType),
			StrategyReachRule:   strategyReachRule,
			UpdateUser:          gptr.Indirect(userInfo.Email),
			UpdateTime:          time.Now(),
			IsDelete:            int(req.Strategy.IsDel),
		})

		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] UpdateProductReviewStrategy err: %v", err)
			return nil, err
		}

		sid := convert.ToInt64(req.Strategy.StrategyId)

		if shortGoal != nil {
			shortGoal.GoalType = prod_review.GoalType_ShortTerm
			err = d.updateRelation(ctx, sid, shortGoal)
			if err != nil {
				logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] UpdateProductReviewStrategy err: %v", err)
				return nil, err
			}
		}

		if longGoal != nil {
			longGoal.GoalType = prod_review.GoalType_LongTerm
			err = d.updateRelation(ctx, sid, longGoal)
			if err != nil {
				logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] UpdateProductReviewStrategy err: %v", err)
				return nil, err
			}
		}

		return &prod_review.CreateAndUpdateProdReviewStrategyResponse{
			Data: true,
		}, nil
	}

	// ---------------- 创建 ----------------
	strategyId, err := d.StrategyDao.CreateProductReviewStrategy(ctx, &dao.ProductReviewStrategy{
		StrategyName:        req.Strategy.StrategyName,
		StrategyDesc:        req.Strategy.StrategyDesc,
		Granularity:         int(req.Strategy.Granularity),
		StrategyTypeId:      convert.ToInt64(req.Strategy.StrategyType.StrategyTypeId),
		BizId:               int64(req.Strategy.BizType),
		AnalysisPerspective: int(req.Strategy.AnalysisPerspective),
		StartDate:           time.Unix(req.Strategy.StartDate, 0),
		EndDate:             time.Unix(req.Strategy.EndDate, 0),
		FlightId:            convert.ToInt64(req.Strategy.FlightId),
		BaseVersionInfo:     baseVersionInfo,
		AllExpVersionInfo:   allVersionInfo,
		RelationProdPool:    relationProdPool,
		TargetList:          strings.Join(req.Strategy.TargetList, ","),
		AAIncreaseCalType:   int(req.Strategy.AaIncreaseCalType),
		StatisticType:       int(req.Strategy.StatisticType),
		StrategyReachRule:   strategyReachRule,
		CreateUser:          gptr.Indirect(userInfo.Email),
		CreateTime:          time.Now(),
	})

	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] CreateProductReviewStrategy err: %v", err)
		return nil, err
	}

	if shortGoal != nil {
		shortGoal.GoalType = prod_review.GoalType_ShortTerm
		err = d.createRelation(ctx, strategyId, shortGoal)
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] CreateStrategyRelation err: %v", err)
			return nil, err
		}
	}

	if longGoal != nil {
		longGoal.GoalType = prod_review.GoalType_LongTerm
		err = d.createRelation(ctx, strategyId, longGoal)
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewStrategy] CreateStrategyRelation err: %v", err)
			return nil, err
		}
	}

	return &prod_review.CreateAndUpdateProdReviewStrategyResponse{
		Data: true,
	}, nil
}

func (d *ProductReviewService) IGetProductReviewStrategyList(ctx context.Context, req *prod_review.GetProdReviewStrategyListRequest, filterDimensions []*dimensions.SelectedDimensionInfo) (resp *prod_review.GetProdReviewStrategyListResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[IGetProductReviewStrategyList] IGetProductReviewStrategyList Err:%s", err.Error())
		}
	}()

	if req == nil {
		return nil, errors.New("[IGetProductReviewStrategyList] invalid params")
	}

	if len(filterDimensions) == 0 {
		filterDimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	bizMetaInfo, ctx, _ := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	bizIds := make([]int64, 0)
	if bizMetaInfo != nil && bizMetaInfo.BizType != dimensions.BizType(0) {
		filterDimensions = append(filterDimensions, bizMetaInfo.RequiredDimInfo...) // 业务线依赖的维度加上
		// 该业务线下所有策略类型
		bizList, err := d.BizListDao.GetBizEffectModuleList(ctx, bizMetaInfo.EffectModule)
		if err != nil {
			logs.CtxError(ctx, "[IGetProductReviewStrategyList] GetBizEffectModuleList err: %v", err)
			return nil, err
		}
		for _, biz := range bizList {
			bizIds = append(bizIds, int64(biz.BizType))
		}
	}

	// 查策略列表
	strategyList, count, err := d.StrategyDao.GetProductReviewStrategyList(ctx, &dao.ProductReviewStrategyQueryParams{
		StrategyIds:       convert.ToInt64Slice(req.StrategyIds),
		StrategyTypeId:    convert.ToInt64(req.StrategyTypeId),
		StrategyName:      req.StrategyName,
		StrategyStartTime: req.EffectiveStartDate,
		StrategyEndTime:   req.EffectiveEndDate,
		BizIds:            bizIds,
		PageNum:           int(req.PageNum),
		PageSize:          int(req.PageSize),
		IsNeedAll:         req.IsNeedAll,
	})

	if err != nil {
		logs.CtxError(ctx, "[IGetProductReviewStrategyList] IGetProductReviewStrategyList err: %v", err)
		return nil, err
	}

	// 查策略类型
	strategyTypeIdList := gslice.Map(strategyList, func(s *dao.ProductReviewStrategy) int64 {
		return convert.ToInt64(s.StrategyTypeId)
	})
	strategyTypeList, err := d.StrategyTypeDao.GetProductReviewStrategyTypeByIdList(ctx, strategyTypeIdList)
	if err != nil {
		logs.CtxError(ctx, "[IGetProductReviewStrategyList] GetProductReviewStrategyTypeByIdList err: %v", err)
		return nil, err
	}
	strategyTypeIdToType := gslice.ToMap(strategyTypeList, func(s *dao.ProductReviewStrategyType) (int64, *dao.ProductReviewStrategyType) {
		return s.StrategyTypeId, s
	})

	// 查目标
	strategyIdList := gslice.Map(strategyList, func(s *dao.ProductReviewStrategy) int64 {
		return convert.ToInt64(s.StrategyId)
	})

	strategyRelationList, err := d.StrategyRelationDao.GetProductReviewStrategyRelationByStrategyIdList(ctx, strategyIdList)
	if err != nil {
		logs.CtxError(ctx, "[IGetProductReviewStrategyList] GetProductReviewStrategyRelationByStrategyIdList err: %v", err)
		return nil, err
	}

	strategyIdToRelation := make(map[int64][]*dao.StrategyRelation)

	gslice.ForEach(strategyRelationList, func(s *dao.StrategyRelation) {
		if _, ok := strategyIdToRelation[s.StrategyID]; !ok {
			strategyIdToRelation[s.StrategyID] = make([]*dao.StrategyRelation, 0)
		}
		strategyIdToRelation[s.StrategyID] = append(strategyIdToRelation[s.StrategyID], s)
	})

	// 查策略列表外露指标
	targetCardMap := make(map[int64][]*analysis.TargetCardEntity)
	// 需要返回数据，才进行返回
	if req.IsNeedReturnTargets {
		targetCardMap = d.GetStrategyListTarget(ctx, req, strategyList, strategyTypeIdToType, filterDimensions)
	}

	return &prod_review.GetProdReviewStrategyListResponse{
		Data: &prod_review.GetProdReviewStrategyListData{
			StrategyList: TransStrategyDao(ctx, strategyList, strategyTypeIdToType, strategyIdToRelation, targetCardMap, req.EmployeeId),
			TotalCount:   count,
		},
	}, nil
}

func (d *ProductReviewService) createRelation(ctx context.Context, strategyId int64, goal *prod_review.StrategyGoal) error {
	return d.StrategyRelationDao.CreateStrategyRelation(ctx, &dao.StrategyRelation{
		StrategyID:          strategyId,
		GoalType:            int(goal.GoalType),
		AfterStrategyEndDay: int64(goal.AfterStrategyEndDay),
		TargetName:          goal.TargetName,
		TargetDisplayName:   goal.TargetDisplayName,
		TargetType:          int(goal.TargetType),
		ViewType:            int(goal.ViewType),
		GoalCondition:       int(goal.GoalCondition),
		GoalTargetValue:     goal.GoalTargetValue,
	})
}

func (d *ProductReviewService) updateRelation(ctx context.Context, strategyId int64, goal *prod_review.StrategyGoal) error {
	return d.StrategyRelationDao.UpdateStrategyRelation(ctx, &dao.StrategyRelation{
		StrategyID:          strategyId,
		GoalType:            int(goal.GoalType),
		AfterStrategyEndDay: int64(goal.AfterStrategyEndDay),
		TargetName:          goal.TargetName,
		TargetDisplayName:   goal.TargetDisplayName,
		TargetType:          int(goal.TargetType),
		ViewType:            int(goal.ViewType),
		GoalCondition:       int(goal.GoalCondition),
		GoalTargetValue:     goal.GoalTargetValue,
	})
}

func checkStrategyEditPermission(ctx context.Context, userInfo *models.UserInfo, strategy *dao.ProductReviewStrategy) bool {
	if strategy == nil {
		logs.CtxError(ctx, "[checkStrategyEditPermission] strategy is nil")
		return false
	}
	if userInfo == nil || userInfo.Email == nil {
		logs.CtxError(ctx, "[checkStrategyEditPermission] userInfo is nil")
		return false
	}
	return strategy.CreateUser == gptr.Indirect(userInfo.Email)
}
