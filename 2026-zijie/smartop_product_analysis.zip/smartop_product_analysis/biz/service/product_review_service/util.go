package product_review_service

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gslice"
	"code.byted.org/temai/go_lib/convert"
	"code.byted.org/temai/go_portal_sdk/models"
	"github.com/bytedance/sonic"
	"github.com/jinzhu/copier"
)

func TransBizProjectDao(ctx context.Context, bizProjectList []*dao.ProductReviewBizProject) []*prod_review.BizProject {
	res := make([]*prod_review.BizProject, 0, len(bizProjectList))
	userInfo := utils.GetUserInfo(ctx)
	for _, bizProject := range bizProjectList {

		//expConfig := &prod_review.ExpConfig{}
		//_ = sonic.UnmarshalString(bizProject.ExpConfig, &expConfig)

		var filterDimensions []*dimensions.SelectedDimensionInfo
		_ = sonic.UnmarshalString(bizProject.FilterDimensions, &filterDimensions)
		res = append(res, &prod_review.BizProject{
			BizProjectId:     strconv.FormatInt(bizProject.BizProjectId, 10),
			BizProjectName:   bizProject.BizProjectName,
			FilterDimensions: filterDimensions,
			BindStrategyIds:  utils.StringSplitNotEmpty(bizProject.BindStrategyIds, ","),
			BizType:          dimensions.BizType(bizProject.BizId),
			//AaIncreaseCalType:   prod_review.InCreaseCalType(bizProject.AAIncreaseCalType),
			SummaryType:         prod_review.SummaryType(bizProject.SummaryType),
			TargetList:          utils.StringSplitNotEmpty(bizProject.TargetList, ","),
			DiagnosisTargetList: utils.StringSplitNotEmpty(bizProject.DiagnosisTargetList, ","),
			// ExpConfig:           expConfig,
			CreateUser:        bizProject.CreateUser,
			UpdateUser:        bizProject.UpdateUser,
			CreateTime:        bizProject.CreateTime.Unix(),
			UpdateTime:        bizProject.UpdateTime.Unix(),
			EffectiveTime:     bizProject.EffectiveTime.Format(TimeFormat),
			IsDel:             int32(bizProject.IsDelete),
			HasEditPermission: checkBizProjectEditPermission(ctx, userInfo, bizProject),
		})
	}

	return res
}

func TransStrategyDao(ctx context.Context, strategyList []*dao.ProductReviewStrategy, strategyTypeMap map[int64]*dao.ProductReviewStrategyType,
	strategyRelationMap map[int64][]*dao.StrategyRelation, strategyTargetCardMap map[int64][]*analysis.TargetCardEntity, employeeId *string) []*prod_review.ProdReviewStrategy {
	res := make([]*prod_review.ProdReviewStrategy, 0, len(strategyList))
	var userInfo *models.UserInfo

	if employeeId != nil {
		user, _ := utils.GetEcopUserByEmployeeId(ctx, *employeeId)
		copier.Copy(userInfo, user)
	} else {
		userInfo = utils.GetUserInfo(ctx)
	}

	for _, strategy := range strategyList {
		strategyType := strategyTypeMap[strategy.StrategyTypeId]
		if strategyType == nil {
			strategyType = &dao.ProductReviewStrategyType{}
		}

		var shortGoal, longGoal *prod_review.StrategyGoal

		strategyRelations := strategyRelationMap[strategy.StrategyId]
		gslice.ForEach(strategyRelations, func(strategyRelation *dao.StrategyRelation) {
			goal := &prod_review.StrategyGoal{
				GoalType:            prod_review.GoalType(strategyRelation.GoalType),
				AfterStrategyEndDay: int32(strategyRelation.AfterStrategyEndDay),
				TargetName:          strategyRelation.TargetName,
				TargetType:          prod_review.TargetType(strategyRelation.TargetType),
				ViewType:            prod_review.ViewType(strategyRelation.ViewType),
				TargetDisplayName:   strategyRelation.TargetDisplayName,
				GoalCondition:       prod_review.CompareCondition(strategyRelation.GoalCondition),
				GoalTargetValue:     strategyRelation.GoalTargetValue,
			}

			if strategyRelation.GoalType == int(prod_review.GoalType_ShortTerm) {
				shortGoal = goal
			} else if strategyRelation.GoalType == int(prod_review.GoalType_LongTerm) {
				longGoal = goal
			}

			if shortGoal != nil && longGoal != nil {
				return
			}
		})

		var baseVersionInfo *prod_review.LibraItem
		_ = sonic.UnmarshalString(strategy.BaseVersionInfo, &baseVersionInfo)

		var allVersionInfo []*prod_review.LibraItem
		_ = sonic.UnmarshalString(strategy.AllExpVersionInfo, &allVersionInfo)

		var relationProdPool []*dimensions.SelectedDimensionInfo
		_ = sonic.UnmarshalString(strategy.RelationProdPool, &relationProdPool)

		var reachRule []*dimensions.SelectedDimensionInfo
		_ = sonic.UnmarshalString(strategy.StrategyReachRule, &reachRule)

		flightId := ""
		if strategy.FlightId != 0 {
			flightId = strconv.FormatInt(strategy.FlightId, 10)
		}
		res = append(res, &prod_review.ProdReviewStrategy{
			StrategyId:          strconv.FormatInt(strategy.StrategyId, 10),
			StrategyName:        strategy.StrategyName,
			StrategyDesc:        strategy.StrategyDesc,
			StrategyType:        TransStrategyTypeDao([]*dao.ProductReviewStrategyType{strategyType})[0],
			Granularity:         prod_review.StrategyGranularity(strategy.Granularity),
			StartDate:           strategy.StartDate.Unix(),
			EndDate:             strategy.EndDate.Unix(),
			FlightId:            flightId,
			BaseVersionInfo:     baseVersionInfo,
			AllVersionInfo:      allVersionInfo,
			RelationProdPool:    relationProdPool,
			ShortTermGoal:       shortGoal,
			LongTermGoal:        longGoal,
			TargetList:          utils.StringSplitNotEmpty(strategy.TargetList, ","),
			AnalysisPerspective: prod_review.AnalysisPerspective(strategy.AnalysisPerspective),
			AaIncreaseCalType:   prod_review.InCreaseCalType(strategy.AAIncreaseCalType),
			StrategyReachRule:   reachRule,
			QueryTargetList:     strategyTargetCardMap[strategy.StrategyId],
			StatisticType:       prod_review.StatisticType(strategy.StatisticType),
			CreateUser:          strategy.CreateUser,
			UpdateUser:          strategy.UpdateUser,
			CreateTime:          strategy.CreateTime.Unix(),
			UpdateTime:          strategy.UpdateTime.Unix(),
			IsDel:               int32(strategy.IsDelete),
			HasEditPermission:   checkStrategyEditPermission(ctx, userInfo, strategy),
			BizType:             dimensions.BizType(strategy.BizId),
		})
	}

	return res
}

func TransReportDao(ctx context.Context, reviewReports []*dao.ProductReviewReport) []*prod_review.ProdReviewReport {
	res := make([]*prod_review.ProdReviewReport, 0, len(reviewReports))
	userInfo := utils.GetUserInfo(ctx)

	for _, report := range reviewReports {

		var filterDimensions, compareFilterDimensions []*dimensions.SelectedDimensionInfo
		_ = sonic.UnmarshalString(report.FilterDimensions, &filterDimensions)
		_ = sonic.UnmarshalString(report.CompareFilterDimensions, &compareFilterDimensions)

		res = append(res, &prod_review.ProdReviewReport{
			ReportId:                strconv.FormatInt(report.ReportId, 10),
			ReportName:              report.ReportName,
			RelationId:              strconv.FormatInt(report.RelationId, 10),
			EntityType:              prod_review.EntityType(report.EntityType),
			FilterDimensions:        filterDimensions,
			CompareFilterDimensions: compareFilterDimensions,
			CreateUser:              report.CreateUser,
			UpdateUser:              report.UpdateUser,
			CreateTime:              report.CreateTime.Unix(),
			UpdateTime:              report.UpdateTime.Unix(),
			IsDel:                   int32(report.IsDelete),
			CompareProdPoolType:     prod_review.CompareProdPoolType(report.CompareProdPoolType),
			HasEditPermission:       checkReportEditPermission(ctx, userInfo, report),
		})
	}

	return res
}

func TransStrategyTypeDao(strategyTypes []*dao.ProductReviewStrategyType) []*prod_review.StrategyType {
	res := make([]*prod_review.StrategyType, 0, len(strategyTypes))

	for _, strategyType := range strategyTypes {
		res = append(res, &prod_review.StrategyType{
			StrategyTypeId:      strconv.FormatInt(strategyType.StrategyTypeId, 10),
			StrategyTypeName:    strategyType.StrategyTypeName,
			BindingDimensionIds: utils.StringSplitNotEmpty(strategyType.BindingDimensionIds, ","),
			SupportAnalysisPerspective: gslice.Map(utils.StringSplitNotEmpty(strategyType.SupportAnalysisPerspective, ","), func(s string) prod_review.AnalysisPerspective {
				return prod_review.AnalysisPerspective(convert.ToInt64(s))
			}),
			SupportObject:        prod_review.SupportObject(strategyType.SupportObject),
			BizType:              dimensions.BizType(convert.ToInt64(strategyType.BizId)),
			ProcessLogicId:       prod_review.ProcessLogicId(strategyType.ProcessLogicId),
			ReachStdRule:         strategyType.ReachStdRule,
			IsDependUserInput:    strategyType.IsDependUserInput == 1,
			PeriodCompareType:    prod_review.PeriodCompareType(strategyType.PeriodCompareType),
			StrategyAnalysisType: prod_review.StrategyAnalysisType(strategyType.StrategyAnalysisType),
			SelectProductType:    prod_review.SelectProductType(strategyType.SelectProductType),
			IsDependSubQuery:     strategyType.IsDependSubQuery == 1,
			AiPrompt:             strategyType.AiPrompt,
		})
	}

	return res
}

func buildStrategyQueryParams(
	ctx context.Context,
	bizType dimensions.BizType,
	strategy *dao.ProductReviewStrategy,
	strategyType *dao.ProductReviewStrategyType, dimMap map[int64]*dao.DimensionInfo,
	dimColMap map[string]*dao.DimensionInfo, startDate, endDate string,
	filterDimensions []*dimensions.SelectedDimensionInfo,
) (map[string]interface{}, error) {
	res := make(map[string]interface{})
	//switch prod_review.ProcessLogicId(strategyType.ProcessLogicId) {
	//case prod_review.ProcessLogicId_MarketSignUpActivity:
	switch prod_review.StrategyAnalysisType(strategyType.StrategyAnalysisType) {
	case prod_review.StrategyAnalysisType_AACommonAnalysis:
		selectedDimensionInfos := make([]*dimensions.SelectedDimensionInfo, 0)
		if err := sonic.UnmarshalString(strategy.RelationProdPool, &selectedDimensionInfos); err != nil {
			return nil, err
		}
		if len(filterDimensions) > 0 {
			selectedDimensionInfos = append(selectedDimensionInfos, filterDimensions...)
		}
		curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx,
			base_struct_condition.OsParamsReq{
				BaseStruct: &dimensions.ProductAnalysisBaseStruct{
					BizType:          bizType,
					StartDate:        startDate,
					EndDate:          endDate,
					CompareStartDate: startDate,
					CompareEndDate:   endDate,
					Dimensions:       selectedDimensionInfos,
				},
				DimMap:    dimMap,
				DimColMap: dimColMap,
			})
		if err != nil {
			return nil, err
		}
		res = curr
	//case prod_review.ProcessLogicId_MarketReverseAB:
	case prod_review.StrategyAnalysisType_ABExpAnalysis:
		versionIds := make([]string, 0)
		var baseVersionInfo *prod_review.LibraItem
		_ = sonic.UnmarshalString(strategy.BaseVersionInfo, &baseVersionInfo)
		if baseVersionInfo == nil || baseVersionInfo.VersionId == "" {
			return nil, errors.New("[buildStrategyQueryParams] baseVersionInfo is nil")
		}
		versionIds = append(versionIds, baseVersionInfo.VersionId)

		var allVersionInfo []*prod_review.LibraItem
		_ = sonic.UnmarshalString(strategy.AllExpVersionInfo, &allVersionInfo)
		if len(allVersionInfo) == 0 {
			return nil, errors.New("[buildStrategyQueryParams] allVersionInfo is empty")
		}
		for _, item := range allVersionInfo {
			if item == nil || item.VersionId == "" {
				logs.CtxError(ctx, "[buildStrategyQueryParams] allVersionInfo is nil")
				return nil, errors.New("[buildStrategyQueryParams] baseVersionInfo is nil")
			}
			versionIds = append(versionIds, item.VersionId)
		}

		res["filter_param"] = fmt.Sprintf("version_id in (%s)", strings.Join(versionIds, ","))
		res["force_table_name"] = consts.BizABTableMap[bizType]
	default:
		logs.CtxError(ctx, "[buildStrategyQueryParams] not support strategy type")
		return nil, errors.New("[buildStrategyQueryParams] not support strategy type")
	}

	return res, nil
}

var TotalEnumValue = "不被匹配的整体"
var AllTotalEnumValue = "全量不被匹配的整体"

type AppendParams struct {
	OSParams   map[string]interface{}
	OSApiPath  string
	IsAllTotal bool
}

// GetProdReviewMultiDimItem 获取维度列表清单
func (d *ProductReviewService) GetProdReviewMultiDimItem(ctx context.Context, req *analysis.GetProductAnalysisMultiDimFullListRequest, appendParams AppendParams) (resp *analysis.GetProductAnalysisMultiDimFullListData, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	//if len(req.BaseReq.GroupAttrs) == 0 {
	//	return resp, errors.New("获取多维分析参数失败")
	//}

	dimMap, dimColMap := biz_info.GetCtxBizInfoAllDimMap(ctx), biz_info.GetCtxCtxBizInfoAllDimColMap(ctx)
	var prodCodeTagBaseDims = make([]*dimensions.SelectedDimensionInfo, 0)
	// 获取分析的维度信息
	groupCols := make([]string, 0)
	dimColEnumCodeMap := make(map[string]map[string]string)
	arrGroupColFilters := make([]string, 0)
	for _, attr := range req.BaseReq.GroupAttrs {
		if !appendParams.IsAllTotal {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}

		// 获取维度的查询字段名
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
			return resp, errors.New("未查询到维度信息")
		}
		groupCols = append(groupCols, dimInfo.DimColumn)
		prodCodeTagBaseDims = append(prodCodeTagBaseDims, attr.DimInfo)
		// 查询该维度的枚举值
		if len(attr.DimInfo.SelectedValues) > 0 {
			enumCodeMap := make(map[string]string)

			enumCodes := make([]string, 0)
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
				enumCodes = append(enumCodes, enum.Code)
			}
			if dimInfo.ProcessType == "数组类型" {
				enumCodes = slices.DistinctString(enumCodes)
				enumFilterStr := fmt.Sprintf("%s_new in ('%s')", dimInfo.DimColumn, strings.Join(enumCodes, "','"))
				if dimInfo.EnumDataType == "long" {
					enumFilterStr = fmt.Sprintf("%s_new in (%s)", dimInfo.DimColumn, strings.Join(enumCodes, ","))
				}
				arrGroupColFilters = append(arrGroupColFilters, enumFilterStr)
			}
			dimColEnumCodeMap[dimInfo.DimColumn] = enumCodeMap
		}
	}

	curr, compare, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req.BaseReq,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: append(groupCols, base_struct_condition.GenerateDimKey(groupCols, consts.Empty)),
	})
	if err != nil {
		return
	}

	subSelect := make([]string, 0)
	newGroupCols := make([]string, 0)
	if !appendParams.IsAllTotal {
		for _, col := range groupCols {
			dimInfo, exist := dimColMap[col]
			if exist {
				if len(dimInfo.DimExpr) > 0 {
					subSelect = append(subSelect, fmt.Sprintf("cast(%s as String) as %s", dimInfo.DimExpr, col))
					newGroupCols = append(newGroupCols, col)
					continue
				}

				if dimInfo.ProcessType == "数组类型" {
					subSelect = append(subSelect, fmt.Sprintf("arrayJoin(%s) as %s_new", col, col))
					newGroupCols = append(newGroupCols, col+"_new")
					continue
				}
			}

			subSelect = append(subSelect, fmt.Sprintf("cast(%s as String) as %s", col, col))
			newGroupCols = append(newGroupCols, col)
		}

		curr["sub_select"] = strings.Join(subSelect, ",")
		curr["sub_select_join_on"] = base_struct_condition.GenerateDimKeyJoinOn(newGroupCols)
		//curr["sub_group"] = strings.Join(newGroupCols, ",")
		curr["export_select"] = strings.Join(append(newGroupCols, base_struct_condition.GenerateDimKey(newGroupCols, "")), ",")
		curr["dimension_rollup"] = strings.Join(newGroupCols, ",")
		if len(arrGroupColFilters) > 0 {
			curr["arr_group_col_filter"] = strings.Join(arrGroupColFilters, " and ")
		}
		//curr["dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(newGroupCols, "str_"), ",")

		compare["sub_select"] = strings.Join(subSelect, ",")
		compare["sub_select_join_on"] = base_struct_condition.GenerateDimKeyJoinOn(newGroupCols)
		//compare["sub_group"] = strings.Join(newGroupCols, ",")
		compare["export_select"] = strings.Join(append(newGroupCols, base_struct_condition.GenerateDimKey(newGroupCols, "")), ",")
		compare["dimension_rollup"] = strings.Join(newGroupCols, ",")
		if len(arrGroupColFilters) > 0 {
			compare["arr_group_col_filter"] = strings.Join(arrGroupColFilters, " and ")
		}
		//compare["dimension"] = strings.Join(base_struct_condition.AppendPrefixSelf(newGroupCols, "str_"), ",")
	} else {
		curr["sub_select"] = nil
		compare["sub_select"] = nil
		curr["export_select"] = "'all_total' as dim_key"
		compare["export_select"] = "'all_total' as dim_key"
	}

	if len(appendParams.OSParams) > 0 {
		for k, v := range appendParams.OSParams {
			curr[k] = v
			compare[k] = v
		}
	}

	apiPath := bizMetaInfo.MultiDimApiID
	if len(appendParams.OSApiPath) > 0 {
		apiPath = appendParams.OSApiPath
	}
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType, NeedDistribution: true,
		KeyCols: append(newGroupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
	})
	if err != nil {
		return nil, err
	}

	if len(currTargetList) >= 10000 {
		logs.CtxWarn(ctx, "[GetProductAnalysisMultiDimList]获取的多维组合数量=%v+，超过1w", len(currTargetList))
		return resp, errors.New("MAX_10000_LIMIT_ERROR")
	}

	if req.NeedIncr {
		compareTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: compare, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType,
			KeyCols: append(newGroupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.BaseReq.TargetMetaList,
		})
		if err != nil {
			return nil, err
		}
		currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumnByTypeMagic(currTargetList, compareTargetList, base_struct_condition.CompareTypeCompare)
	}

	resp = &analysis.GetProductAnalysisMultiDimFullListData{
		FullList: make([]*analysis.MultiDimFullListRow, 0),
	}
	outParentRowMap := make(map[string][]*analysis.MultiDimFullListRow, 0)
	for _, keyTargetList := range currTargetList {
		if appendParams.IsAllTotal {
			resp.AllTotal = &analysis.MultiDimFullListRow{
				EnumValue:   AllTotalEnumValue,
				DisplayName: "全量整体",
				TargetList:  keyTargetList.TargetEntity,
				ProdTagCode: "",
			}
			continue
		}

		if len(keyTargetList.KeyColValues) <= len(groupCols) {
			continue
		}

		dimKey := convert.ToString(keyTargetList.KeyColValues[len(groupCols)])
		if len(strings.ReplaceAll(dimKey, "#", "")) == 0 {
			resp.Total = &analysis.MultiDimFullListRow{
				EnumValue:   TotalEnumValue,
				DisplayName: "整体",
				TargetList:  keyTargetList.TargetEntity,
				ProdTagCode: "",
			}
			continue
		}

		maxLen := base_struct_condition.GetDimKeyMaxLen(dimKey)
		enumCode := convert.ToString(keyTargetList.KeyColValues[maxLen])
		displayName := consts.Empty
		enumCodeMap, exist := dimColEnumCodeMap[groupCols[maxLen]]
		if exist {
			displayName = enumCodeMap[enumCode]
		}
		fullRow := &analysis.MultiDimFullListRow{
			EnumValue:   enumCode,
			DisplayName: displayName,
			TargetList:  keyTargetList.TargetEntity,
			DimKey:      dimKey,
			ProdTagCode: "",
		}
		if maxLen == 0 {
			resp.FullList = append(resp.FullList, fullRow)
		} else {
			children, existC := outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)]
			if !existC {
				children = make([]*analysis.MultiDimFullListRow, 0)
			}
			children = append(children, fullRow)
			outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)] = children
		}
	}

	analysis_service.CalcDistributionRatio(resp.Total)
	analysis_service.CalcDistributionRatio(resp.AllTotal)
	analysis_service.CalcDistributionRatio(resp.FullList...)
	for _, fullRow := range resp.FullList {
		if children, existC := outParentRowMap[fullRow.DimKey]; existC {
			analysis_service.CalcDistributionRatio(children...)
			fullRow.Children = children
		}
		if len(fullRow.Children) > 0 {
			for _, subFullRow := range fullRow.Children {
				if subChildren, existSubC := outParentRowMap[subFullRow.DimKey]; existSubC {
					analysis_service.CalcDistributionRatio(subChildren...)
					subFullRow.Children = subChildren
				}
			}
		}
	}
	// 添加prod_tag_code
	for _, row := range resp.FullList {
		if len(prodCodeTagBaseDims) > 0 {
			codeStruct := &dimensions.SelectedDimensionInfo{
				Id:               prodCodeTagBaseDims[0].Id,
				Name:             prodCodeTagBaseDims[0].Name,
				AttrType:         prodCodeTagBaseDims[0].AttrType,
				SelectedOperator: prodCodeTagBaseDims[0].SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{{Code: row.EnumValue, Name: row.DisplayName}},
				IsGroup:          false,
			}
			dims := []*dimensions.SelectedDimensionInfo{codeStruct}
			marshalString, err := sonic.MarshalString(dims)
			if err != nil {
				logs.CtxError(ctx, "序列化prod_tag_code失败,err:"+err.Error())
			}
			row.ProdTagCode = marshalString
			// 递归填充children的tagCode
			analysis_service.AddChildrenTagCode(ctx, prodCodeTagBaseDims, dims, 1, row.Children)
		}
	}
	// 整体的tag_code
	if resp.Total != nil {
		codeStruct := &dimensions.SelectedDimensionInfo{
			Id:             "-1",
			Name:           TotalEnumValue,
			SelectedValues: []*dimensions.EnumElement{{Code: TotalEnumValue, Name: TotalEnumValue}},
		}
		dims := []*dimensions.SelectedDimensionInfo{codeStruct}
		marshalString, err := sonic.MarshalString(dims)
		if err != nil {
			logs.CtxError(ctx, "序列化prod_tag_code失败,err:"+err.Error())
		}
		resp.Total.ProdTagCode = marshalString
	}

	return resp, nil
}
