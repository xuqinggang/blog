package product_review_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"context"
	"encoding/json"
	"fmt"
	"github.com/mohae/deepcopy"
	"strconv"
)

func (d *ProductReviewService) GetBubbleChart(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.UnifiedData, err error) {
	if req == nil || req.BaseReq == nil {
		return nil, errors.New("req or req.BaseReq is nil")
	}
	bizProjectId, strategyId, reportId := "", "", ""
	var bizProject *prod_review.BizProject
	var strategy *prod_review.ProdReviewStrategy
	var report *prod_review.ProdReviewReport
	prodReviewParams := &prod_review.ProdReviewParams{}
	if req.BizExtraInfo != nil && req.BizExtraInfo.ProdReviewParams != nil {
		prodReviewParams = req.BizExtraInfo.ProdReviewParams
		bizProjectId = req.BizExtraInfo.ProdReviewParams.BizProjectId
		strategyId = req.BizExtraInfo.ProdReviewParams.StrategyId
		reportId = req.BizExtraInfo.ProdReviewParams.ReportId
	}
	bubbleChartParam := &prod_review.BubbleChartParams{}
	if prodReviewParams.BubbleChartParams != nil {
		bubbleChartParam = prodReviewParams.BubbleChartParams
	}
	if bubbleChartParam.XAxis == nil || bubbleChartParam.YAxis == nil {
		return nil, errors.New("x_axis or y_axis is nil")
	}
	if bubbleChartParam.ProdPoolType == prod_review.ProdPoolType_Unknown {
		bubbleChartParam.ProdPoolType = prod_review.ProdPoolType_Current
	}
	// 业务专项
	if bizProjectId != "" {
		bizProject = d.GetBizProjectById(ctx, bizProjectId)
	}
	// 单策略
	if strategyId != "" {
		strategy = d.GetStrategyById(ctx, strategyId)
	}
	// 个性化复盘报告
	if reportId != "" {
		report = d.GetReportById(ctx, reportId)
	}
	// 四象限查询
	if bizProject == nil && strategy == nil && report == nil {
		return nil, nil
	}
	if strategy == nil && report != nil && report.EntityType == prod_review.EntityType_Strategy {
		strategy = report.ProdReviewStrategy
	}
	if bizProject == nil && report != nil && report.EntityType == prod_review.EntityType_BizProject {
		bizProject = report.BizProject
	}
	dimMap, err := d.DimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取map失败，err=%v+", err)
		return nil, err
	}
	dimColMap, err := d.DimensionListDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取col map失败，err=%v+", err)
		return nil, err
	}
	queryItems := make([]map[string]interface{}, 0)
	currItem := make(map[string]interface{})
	compareItem := make(map[string]interface{})
	currItem["is_curr"] = 1
	compareItem["is_curr"] = 0

	reqDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	bizProjectFilterDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	if bizProject != nil {
		bizProjectFilterDimensions = bizProject.FilterDimensions
		bizProjectCurrItem, bizProjectCompareItem := genBizProjectParam(ctx, req, bizProject, bubbleChartParam.ProdPoolType, prodReviewParams.CompareProdPoolType, dimMap, dimColMap)
		for key, value := range bizProjectCurrItem {
			currItem[key] = value
		}
		for key, value := range bizProjectCompareItem {
			compareItem[key] = value
		}
	} else if strategy != nil {
		strategyCurrItem, strategyCompareItem := genStrategyParam(ctx, req, strategy, bubbleChartParam.ProdPoolType, prodReviewParams.CompareProdPoolType, dimMap, dimColMap)
		for key, value := range strategyCurrItem {
			currItem[key] = value
		}
		for key, value := range strategyCompareItem {
			compareItem[key] = value
		}
	}
	if bubbleChartParam.ProdPoolType == prod_review.ProdPoolType_Current {
		reqDimensions = append(reqDimensions, req.BaseReq.Dimensions...)
		reqDimensions = append(reqDimensions, bizProjectFilterDimensions...) // 添加业务专项
	} else if bubbleChartParam.ProdPoolType == prod_review.ProdPoolType_Compare {
		reqDimensions = append(reqDimensions, req.CompareReq.Dimensions...)
	}
	// 二级下钻选中
	reqDimensions = append(reqDimensions, bubbleChartParam.Dimensions...)

	currParam, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx,
		base_struct_condition.OsParamsReq{
			BaseStruct: &dimensions.ProductAnalysisBaseStruct{
				BizType:          req.BaseReq.BizType,
				StartDate:        req.BaseReq.StartDate,
				EndDate:          req.BaseReq.EndDate,
				CompareStartDate: req.BaseReq.CompareStartDate,
				CompareEndDate:   req.BaseReq.CompareEndDate,
				Dimensions:       reqDimensions,
			},
			DimMap:    dimMap,
			DimColMap: dimColMap,
		})
	if bubbleChartParam.QuadrantQueryParam != "" {
		quadrantQueryParam := make(map[string]interface{})
		_ = json.Unmarshal([]byte(bubbleChartParam.QuadrantQueryParam), &quadrantQueryParam)
		currParam["quadrant_query_param"] = quadrantQueryParam
	}
	if bubbleChartParam.ProductFractureParams != "" {
		productFractureParams := make(map[string]interface{})
		_ = json.Unmarshal([]byte(bubbleChartParam.ProductFractureParams), &productFractureParams)
		currParam["product_fracture_params"] = productFractureParams
	}
	// 指标前缀
	targetPrefix := ""
	isNeedCompare := false
	switch bubbleChartParam.XAxis.ValueType {
	case prod_review.ValueType_AbsoluteValue: // 当前值
		targetPrefix = "curr_"
	case prod_review.ValueType_Increase: // AA增量
		targetPrefix = "aa_increase_"
		isNeedCompare = true
	case prod_review.ValueType_AAIncreasePercent: // AA增幅
		targetPrefix = "aa_increase_rate_"
		isNeedCompare = true
	case prod_review.ValueType_ABIncreasePercent: // AB增幅
		targetPrefix = "aa_increase_rate_"
		isNeedCompare = true
	case prod_review.ValueType_ABIncrease: // AB增量
		targetPrefix = "aa_increase_"
		isNeedCompare = true
	default:
		return nil, errors.New("BubbleChartParam.XAxis.ValueType is Unknown")
	}
	xTargetName := targetPrefix + bubbleChartParam.XAxis.AxisTargetName
	yTargetName := targetPrefix + bubbleChartParam.YAxis.AxisTargetName
	//xTargetValue := bubbleChartParam.XAxis.AxisSegmentationValue
	//yTargetValue := bubbleChartParam.XAxis.AxisSegmentationValue
	currParam["x_target_name"] = xTargetName
	currParam["y_target_name"] = yTargetName

	currItem["filter_param"] = currParam["filter_param"]
	compareItem["filter_param"] = currParam["filter_param"]

	subSelect := ""
	subSelectCol := ""
	subSelectDim := &dao.DimensionInfo{}
	if bubbleChartParam.DrillDimensionId != "" {
		dimId, _ := strconv.ParseInt(bubbleChartParam.DrillDimensionId, 10, 64)
		if dimInfo, ok := dimMap[dimId]; ok {
			subSelectDim = dimInfo
			subSelectCol = dimInfo.DimColumn
			if dimInfo.DimExpr == "" {
				subSelect = dimInfo.DimColumn
			} else {
				subSelect = fmt.Sprintf("cast(%s as String) as %s", dimInfo.DimExpr, dimInfo.DimColumn)
			}
		}
	}
	currParam["sub_select"] = subSelect
	bizConfig, err := biz_info.GetBizInfoConfig(ctx, req.BaseReq.BizType)
	apiPath := "7568328946589172774"
	if bizConfig != nil && bizConfig.ProdReviewConfig != nil {
		if strategy != nil && bizConfig.ProdReviewConfig.StrategyModuleConfig != nil &&
			bizConfig.ProdReviewConfig.StrategyModuleConfig.SupplyBubbleChartConf != nil {
			apiPath = bizConfig.ProdReviewConfig.StrategyModuleConfig.SupplyBubbleChartConf.OneServiceApi
		}
		if bizProject != nil && bizConfig.ProdReviewConfig.BizProjectModuleConfig != nil &&
			bizConfig.ProdReviewConfig.BizProjectModuleConfig.SupplyBubbleChartConf != nil {
			apiPath = bizConfig.ProdReviewConfig.BizProjectModuleConfig.SupplyBubbleChartConf.OneServiceApi
		}
	}
	if strategy != nil && strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis {
		currParam["table_name"] = consts.BizABTableMap[req.BaseReq.BizType]
	}
	if bizProject != nil && bubbleChartParam.AnalysisObject == prod_review.AnalysisObject_StrategyCoveredProduct && len(bizProject.StrategyList) > 0 {
		if bubbleChartParam.StrategyId != "" { // 覆盖某一策略
			for _, strategyTemp := range bizProject.StrategyList {
				if strategyTemp.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis &&
					bubbleChartParam.StrategyId == strategyTemp.StrategyId {
					currParam["table_name"] = consts.BizABTableMap[req.BaseReq.BizType]
					break
				}
			}
		}
	}
	currItem["table_name"] = currParam["table_name"]
	compareItem["table_name"] = currParam["table_name"]
	if !isNeedCompare {
		currItem["reach_std"] = 1
		compareItem["reach_std"] = 1
	}
	queryItems = append(queryItems, currItem)
	if isNeedCompare { // 需要增量的时候才去查对比时间
		queryItems = append(queryItems, compareItem)
	}
	currParam["query_items"] = queryItems
	// X,Y轴划分取值
	bubbleChartInfo := &prod_review.BubbleChartInfo{}
	bubblePoints := make([]map[string]string, 0)
	cc := co.NewConcurrent(ctx)
	cc.GoV2(func() error {
		currP1 := deepcopy.Copy(currParam).(map[string]interface{})
		currP1["is_need_segmentation_info"] = 1
		currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: currP1, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType,
			KeyCols: []string{}, FilterTarget: false,
		})
		xSegTargetName := ""
		ySegTargetName := ""
		switch bubbleChartParam.AxisSegmentation {
		case prod_review.AxisSegmentation_Mean:
			xSegTargetName = "x_avg"
			ySegTargetName = "y_avg"
		case prod_review.AxisSegmentation_Median:
			xSegTargetName = "x_p50"
			ySegTargetName = "y_p50"
		case prod_review.AxisSegmentation_Top10Percent:
			xSegTargetName = "x_p90"
			ySegTargetName = "y_p90"
		case prod_review.AxisSegmentation_Top20Percent:
			xSegTargetName = "x_p80"
			ySegTargetName = "y_p80"
		default:
			return errors.New("AxisSegmentation is Unknown")
		}
		if len(currTargetList) > 0 {
			xTarget := GetTargetEntityByName(currTargetList[0].TargetEntity, xSegTargetName)
			yTarget := GetTargetEntityByName(currTargetList[0].TargetEntity, ySegTargetName)
			bubbleChartInfo.XAxisTargetValue = strconv.FormatFloat(xTarget.Value, 'f', -1, 64)
			bubbleChartInfo.XAxisTargetDisplayValue = xTarget.DisplayValue
			bubbleChartInfo.YAxisTargetValue = strconv.FormatFloat(yTarget.Value, 'f', -1, 64)
			bubbleChartInfo.YAxisTargetDisplayValue = yTarget.DisplayValue
		}
		return err
	})
	cc.GoV2(func() error {
		currP2 := deepcopy.Copy(currParam).(map[string]interface{})
		currP2["is_need_segmentation_info"] = 0
		currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: currP2, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType,
			KeyCols: []string{subSelectCol}, FilterTarget: false,
		})
		for _, row := range currTargetList {
			bubblePoint := make(map[string]string, 0)
			if len(row.KeyColValues) > 0 {
				bubblePoint["drill_dimension_name"] = row.KeyColValues[0].(string)
				bubblePoint["drill_dimension_code"] = row.KeyColValues[0].(string)
				prodTagCodeDims := make([]*dimensions.SelectedDimensionInfo, 0)
				selectDimension := &dimensions.SelectedDimensionInfo{}
				selectDimension.Id = bubbleChartParam.DrillDimensionId
				selectDimension.Name = subSelectDim.ShowName
				selectDimension.SelectedOperator = base.OperatorType_IN
				selectDimension.SelectedValues = []*dimensions.EnumElement{
					{
						Code: row.KeyColValues[0].(string),
						Name: row.KeyColValues[0].(string),
					},
				}
				prodTagCodeDims = append(prodTagCodeDims, selectDimension)
				if len(bubbleChartParam.Dimensions) > 0 {
					prodTagCodeDims = append(prodTagCodeDims, bubbleChartParam.Dimensions...)
				}
				jsonStr, _ := json.Marshal(prodTagCodeDims)
				bubblePoint["prod_tag_code"] = string(jsonStr)
			}
			for _, target := range row.TargetEntity {
				if target.Name == bubbleChartParam.XAxis.AxisTargetName {
					bubblePoint["x"] = strconv.FormatFloat(target.Value, 'f', -1, 64)
					bubblePoint["x_name"] = target.Name
					bubblePoint["x_display_name"] = target.DisplayName
					bubblePoint["x_display_value"] = target.DisplayValue
				}
				if target.Name == bubbleChartParam.YAxis.AxisTargetName {
					bubblePoint["y"] = strconv.FormatFloat(target.Value, 'f', -1, 64)
					bubblePoint["y_name"] = target.Name
					bubblePoint["y_display_name"] = target.DisplayName
					bubblePoint["y_display_value"] = target.DisplayValue
				}
				if target.Name == bubbleChartParam.BubbleSizeTargetName {
					bubblePoint["z"] = strconv.FormatFloat(target.Value, 'f', -1, 64)
					bubblePoint["z_name"] = target.Name
					bubblePoint["z_display_name"] = target.DisplayName
					bubblePoint["z_display_value"] = target.DisplayValue
				}
			}
			bubblePoints = append(bubblePoints, bubblePoint)
		}
		return err
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "[GetProductAnalysisCoreConclusion]查询结论相关信息失败, err: %v", err)
		return
	}
	resp = &common_response.UnifiedData{}
	resp.KeyValueList = bubblePoints
	resp.ExtraInfo = &common_response.UnifiedDataExtraInfo{}
	resp.ExtraInfo.BubbleChartInfo = bubbleChartInfo
	return
}

func GetTargetEntityByName(targets []*analysis.TargetCardEntity, targetName string) *analysis.TargetCardEntity {
	for _, target := range targets {
		if target.Name == targetName {
			return target
		}
	}
	return nil
}

func (d *ProductReviewService) BubbleChartDownload(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp bool, err error) {

	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "zhangruiwen.raven@bytedance.com"
	}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	result, err := d.GetBubbleChart(ctx, req)
	if err != nil || result == nil {
		logs.CtxError(ctx, "[BubbleChartDownload]GetBubbleChart, err: %v", err)
		return false, err
	}
	if result == nil {
		logs.CtxError(ctx, "[BubbleChartDownload]GetBubbleChart, nil")
		return false, errors.New("BubbleChartInfo is nil")
	}
	f.ExeQueryCustom([]param.Source{param.SourceConst(result.KeyValueList)}, GenTargetCardTable, param.SinkTable("target_data"))
	f.ExeCustom([]param.Source{param.SourceTable("target_data"), param.SourceConst(email),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.BaseReq.StartDate, req.BaseReq.EndDate)),
		param.SourceConst(fmt.Sprintf("%v ~ %v", req.CompareReq.EndDate, req.CompareReq.EndDate))}, doExportTargetCard, nil)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	return true, nil
}

func GenTargetCardTable(ctx context.Context, data []map[string]string) (*onetable.Table, error) {
	table := make([]map[string]interface{}, 0)
	for _, row := range data {
		t := make(map[string]interface{}, 0)
		for key, value := range row {
			t[key] = value
		}
		table = append(table, t)
	}
	return onetable.NewTable(table), nil
}

func doExportTargetCard(ctx context.Context, table *onetable.Table, email string, analysisRange, compareRange string) (interface{}, error) {
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet1 := lark_export.NewLarkDocSheet("指标卡数据", table)
	sheet1.AddHead([][]string{{"分析周期", analysisRange}, {"对比周期", compareRange}})
	sheet1.AddColumn("维度名称", "drill_dimension_name").
		AddColumn("支付GMV", "gmv").
		AddColumn("曝光商品数", "show_prod_cnt").
		AddColumn("曝光PV", "show_pv").
		AddColumn("支付订单数", "order_cnt")
	formatter.AddSheet(sheet1)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, "核心指标")
	return nil, formatter.Export(ctx, email, nil, nil)
}
