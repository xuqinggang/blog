package product_review_service

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	multi_dim_table_service "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_table_domain/service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"github.com/mohae/deepcopy"
)

type IProductReviewService interface {
	ICreateAndUpdateProdReviewBizProject(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewBizProjectRequest) (*prod_review.CreateAndUpdateProdReviewBizProjectResponse, error)
	IGetProductReviewBizProjectList(ctx context.Context, req *prod_review.GetProdReviewBizProjectListRequest, filterDimensions []*dimensions.SelectedDimensionInfo) (*prod_review.GetProdReviewBizProjectListResponse, error)

	ICreateAndUpdateProdReviewStrategy(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewStrategyRequest) (*prod_review.CreateAndUpdateProdReviewStrategyResponse, error)
	IGetProductReviewStrategyList(ctx context.Context, req *prod_review.GetProdReviewStrategyListRequest, filterDimensions []*dimensions.SelectedDimensionInfo) (*prod_review.GetProdReviewStrategyListResponse, error)

	ICreateAndUpdateProdReviewReport(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewReportRequest) (*prod_review.CreateAndUpdateProdReviewReportResponse, error)
	IGetProductReviewReportList(ctx context.Context, req *prod_review.GetProdReviewReportListRequest) (*prod_review.GetProdReviewReportListResponse, error)

	IGetProductReviewStrategyTypeList(ctx context.Context, req *prod_review.GetProdReviewStrategyTypeListRequest) (*prod_review.GetProdReviewStrategyTypeListResponse, error)

	IGetLibraInfo(ctx context.Context, req *prod_review.GetLibraInfoRequest) (*prod_review.GetLibraInfoResponse, error)

	//ICommonAnalysisMultiDimTable(ctx context.Context, req *common_request.CommonAnalysisRequest) (*common_response.MultiDimTableData, map[string]apiResult, error)
	//ICommonAnalysisMultiDimTableDownload(ctx context.Context, req *common_request.CommonAnalysisRequest) (bool, error)

	ICommonAnalysisItemData(ctx context.Context, req *common_request.CommonAnalysisRequest) (*common_response.ItemDataList, error)

	ICommonAnalysisTargetTable(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisTargetTableResponse)

	ICommonGetBizConfig(ctx context.Context, req *common_request.BizConfigRequest) (resp *common_response.BizConfigData, err error)

	ProductValueClassify(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.ItemDataList, err error)

	ProductFourQuadrantAnalysis(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.ItemDataList, err error)

	IGetStrategyCoverageRatio(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp map[string]string, err error)
	GetBubbleChart(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.UnifiedData, err error)

	BubbleChartDownload(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp bool, err error)
}

type ProductReviewService struct {
	MultiDimTableService multi_dim_table_service.IMultiDimTableService
	DimensionListDao     dao.IDimensionListDao
	BizListDao           dao.IDimensionBizListDao
	BizProjectDao        dao.IProductReviewBizProjectDao
	StrategyDao          dao.IProductReviewStrategyDao
	ReportDao            dao.IProductReviewReportDao
	StrategyTypeDao      dao.IProductReviewStrategyTypeDao
	StrategyRelationDao  dao.IProductReviewStrategyRelationDao
	AnalysisService      analysis_service.IAnalysisService
	DimensionService     dimension_service.IDimensionService
}

const (
	//  功能API分类
	BizProjectTargetList           = "BizProjectTargetList"
	BizFunnelChart                 = "BizFunnelChart"
	SpecialFunnelMultiDimAnalysis  = "SpecialFunnelMultiDimAnalysis"
	SpecialItemMultiDimOverall     = "SpecialItemMultiDimOverall"
	AIDiagnosisMultiDimOverall     = "AIDiagnosisMultiDimOverall"
	SingleStrategyMultiDimAnalysis = "SingleStrategyMultiDimAnalysis"
	SingleStrategyMultiDimOverall  = "SingleStrategyMultiDimOverall"
	SingleStrategyCoverProd        = "SingleStrategyCoverProd"
)
const (
	// 业务线API
	ApiSingleStrategyMultiDimAnalysisMarket = "7541293207888462858"
	ApiSingleStrategyMultiDimOverallMarket  = "7542500213324334126"
	ApiSingleStrategyCoverProdCommon        = "7542766528312198171"
	ApiSingleStrategyCoverProdUnionCommon   = "7569154291932382217"
	ApiSingleStrategyCoverProdUnionZero     = "7576925069138478130"
	ApiSpecialItemMultiDimOverallMarket     = "7549099097400050715"
	ApiBizProjectTargetListCommon           = "7546216415091606580"
	ApiBizFunnelChartZS                     = "7547914485449770022"
	ApiSpecialItemFunnelMultiDimAnalysisZS  = "7547996258045051942"
	ApiSpecialItemMultiDimOverallZS         = "7547996197470897190"
	ApiAIDiagnosisMultiDimOverallZS         = "7548797679560557606"

	ApiSingleStrategyMultiDimAnalysisOverview = "7553959671158015027"
	ApiSpecialItemMultiDimOverallOverview     = "7553959936074581002"
	ApiBizFunnelChartCommon                   = "7564377025595638810"
)

var BizApiMap = map[dimensions.BizType]map[string]string{
	dimensions.BizType_ProdReviewMarket: {
		BizProjectTargetList:           ApiBizProjectTargetListCommon,
		SingleStrategyMultiDimAnalysis: ApiSingleStrategyMultiDimAnalysisMarket,
		SingleStrategyMultiDimOverall:  ApiSingleStrategyMultiDimOverallMarket,
		SingleStrategyCoverProd:        ApiSingleStrategyCoverProdUnionCommon,
		SpecialItemMultiDimOverall:     ApiSpecialItemMultiDimOverallMarket,
		BizFunnelChart:                 ApiBizFunnelChartCommon,
	},
	dimensions.BizType_ProdReviewGreatValueBuy: {
		BizProjectTargetList:          ApiBizProjectTargetListCommon,
		BizFunnelChart:                ApiBizFunnelChartZS,
		SpecialFunnelMultiDimAnalysis: ApiSpecialItemFunnelMultiDimAnalysisZS,
		SpecialItemMultiDimOverall:    ApiSpecialItemMultiDimOverallZS,
		AIDiagnosisMultiDimOverall:    ApiAIDiagnosisMultiDimOverallZS,
		SingleStrategyCoverProd:       ApiSingleStrategyCoverProdUnionZero,
	},
	dimensions.BizType_ProdReviewCore: {
		BizProjectTargetList:           ApiBizProjectTargetListCommon,
		SingleStrategyMultiDimAnalysis: ApiSingleStrategyMultiDimAnalysisOverview,
		SingleStrategyCoverProd:        ApiSingleStrategyCoverProdUnionCommon,
		SpecialItemMultiDimOverall:     ApiSpecialItemMultiDimOverallOverview,
		BizFunnelChart:                 ApiBizFunnelChartCommon,
	},
	dimensions.BizType_ProdReviewBigPromotion: {
		BizProjectTargetList:           ApiBizProjectTargetListCommon,
		SingleStrategyMultiDimAnalysis: ApiSingleStrategyMultiDimAnalysisOverview,
		SingleStrategyCoverProd:        ApiSingleStrategyCoverProdUnionCommon,
		SpecialItemMultiDimOverall:     ApiSpecialItemMultiDimOverallOverview,
		BizFunnelChart:                 ApiBizFunnelChartCommon,
	},
	dimensions.BizType_ProdReviewSeckill: {
		BizProjectTargetList:           ApiBizProjectTargetListCommon,
		SingleStrategyMultiDimAnalysis: ApiSingleStrategyMultiDimAnalysisOverview,
		SingleStrategyCoverProd:        ApiSingleStrategyCoverProdUnionCommon,
		SpecialItemMultiDimOverall:     ApiSpecialItemMultiDimOverallOverview,
		BizFunnelChart:                 ApiBizFunnelChartCommon,
	},
	dimensions.BizType_ProdReviewGovSubsidy: {
		BizProjectTargetList:           ApiBizProjectTargetListCommon,
		SingleStrategyMultiDimAnalysis: ApiSingleStrategyMultiDimAnalysisOverview,
		SingleStrategyCoverProd:        ApiSingleStrategyCoverProdUnionCommon,
		SpecialItemMultiDimOverall:     ApiSpecialItemMultiDimOverallOverview,
		BizFunnelChart:                 ApiBizFunnelChartCommon,
	},
	dimensions.BizType_ProdReviewGuess: {
		BizProjectTargetList:           ApiBizProjectTargetListCommon,
		SingleStrategyMultiDimAnalysis: ApiSingleStrategyMultiDimAnalysisOverview,
		SingleStrategyCoverProd:        ApiSingleStrategyCoverProdUnionCommon,
		SpecialItemMultiDimOverall:     ApiSpecialItemMultiDimOverallOverview,
		BizFunnelChart:                 ApiBizFunnelChartCommon,
	},
	dimensions.BizType_ProdReviewSearch: {
		BizProjectTargetList:           ApiBizProjectTargetListCommon,
		SingleStrategyMultiDimAnalysis: ApiSingleStrategyMultiDimAnalysisOverview,
		SingleStrategyCoverProd:        ApiSingleStrategyCoverProdUnionCommon,
		SpecialItemMultiDimOverall:     ApiSpecialItemMultiDimOverallOverview,
		BizFunnelChart:                 ApiBizFunnelChartCommon,
	},
}

type TargetRules string

const (
	DivisionTotalRules TargetRules = "DivisionTotalRules"
	DivisionRules      TargetRules = "DivisionRules"
	DiffRules          TargetRules = "DiffRules"
)

var MarketTargetsRules = map[TargetRules]map[string]map[string]string{
	DivisionTotalRules: {
		"act_gmv_in_overall_total": map[string]string{
			"accumulate_gmv": "accumulate_overall_gmv",
		},
		"act_gmv_in_mall_total": map[string]string{
			"accumulate_gmv": "accumulate_overall_mall_gmv",
		},
		"act_gmv_in_mall_new_entrance_total": map[string]string{
			"accumulate_gmv": "accumulate_overall_mall_new_entrance_gmv",
		},
	},
}

// FunnelFloorConfig 漏斗层配置
type FunnelFloorConfig struct {
	Name              string
	FilterDimensions  []*dimensions.SelectedDimensionInfo
	FloorOrder        int    //  层级顺序
	GmvGoalTargetName string // GMV目标指标名
	ProdCntTargetName string // 商品数目标指标名
	Tips              string // 提示词
}

func NewFunnelFloorConfig(name string) []*dimensions.SelectedDimensionInfo {
	switch name {
	case "全域商品卡0补品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10430",
				Name:     "大盘0补品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
			&dimensions.SelectedDimensionInfo{
				Id:       "10035",
				Name:     "载体",
				AttrType: dimensions.DimensionAttributeType_Place,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "product_card",
						Name: "商品卡",
					},
				},
			},
		}
	case "0补品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10430",
				Name:     "大盘0补品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
			&dimensions.SelectedDimensionInfo{
				Id:       "10035",
				Name:     "载体",
				AttrType: dimensions.DimensionAttributeType_Place,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "product_card",
						Name: "商品卡",
					},
				},
			},
		}
	case "商城":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10437",
				Name:     "是否商城",
				AttrType: dimensions.DimensionAttributeType_Place,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "品规内":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10431",
				Name:     "超值购品规内",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "符合",
					},
				},
			},
		}
	case "优价":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10428",
				Name:     "B店混比",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "优价",
						Name: "优价",
					},
					&dimensions.EnumElement{
						Code: "均价",
						Name: "均价",
					},
					&dimensions.EnumElement{
						Code: "无同款",
						Name: "无同款",
					},
				},
			},
		}
	case "大盘0补品（品规内）&非0动销&有资质品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10035",
				Name:     "载体",
				AttrType: dimensions.DimensionAttributeType_Place,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "product_card",
						Name: "商品卡",
					},
				},
			},
			&dimensions.SelectedDimensionInfo{
				Id:       "10432",
				Name:     "超值购资质",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "有",
					},
				},
			},
			&dimensions.SelectedDimensionInfo{
				Id:       "10438",
				Name:     "是否动销品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
			&dimensions.SelectedDimensionInfo{
				Id:       "10431",
				Name:     "超值购品规内",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "符合",
					},
				},
			},
			&dimensions.SelectedDimensionInfo{
				Id:       "10430",
				Name:     "大盘0补品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "非0动销&有资质品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10432",
				Name:     "超值购资质",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "有",
					},
				},
			},
			&dimensions.SelectedDimensionInfo{
				Id:       "10438",
				Name:     "是否动销品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "报名超值购品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10436",
				Name:     "报名超值购",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "未报名超值购品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10436",
				Name:     "报名超值购",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "0",
						Name: "否",
					},
				},
			},
		}
	case "报名成功品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10433",
				Name:     "超值购底池",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "报名未成功品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10433",
				Name:     "超值购底池",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "0",
						Name: "否",
					},
				},
			},
		}
	case "报名价格符合品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10439",
				Name:     "是否价格符合",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "报名价格不符合品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{Id: "10439",
				Name:     "是否价格符合",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "0",
						Name: "否",
					},
				}},
		}
	case "A组":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10414",
				Name:     "一级子赛道",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "112504030090200",
						Name: "A组",
					},
				},
			},
		}
	case "A1-服饰美奢(A组)":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10415",
				Name:     "二级子赛道",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "11230509000002",
						Name: "A1-服饰美奢(A组)",
					},
				},
			},
		}
	case "服饰女装(A组/A1-服饰美奢)":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10418",
				Name:     "三级子赛道",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "112403110000101",
						Name: "服饰女装(A组/A1-服饰美奢)",
					},
				},
			},
		}
	case "动销品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10453",
				Name:     "是否动销品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "曝光品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10445",
				Name:     "是否曝光品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "点击品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10602",
				Name:     "是否点击品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "报名特征挖掘词品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10444",
				Name:     "招募策略ID",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "3510",
						Name: "特征挖掘词策略",
					},
				},
			},
		}
	case "商品卡爆品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10446",
				Name:     "是否商品卡爆品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	case "全域爆品":
		return []*dimensions.SelectedDimensionInfo{
			&dimensions.SelectedDimensionInfo{
				Id:       "10447",
				Name:     "是否全域爆品",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{
					&dimensions.EnumElement{
						Code: "1",
						Name: "是",
					},
				},
			},
		}
	}

	return nil
}

// FunnelChar 漏斗图图配置
var FunnelChar = map[prod_review.FunnelChart][]*FunnelFloorConfig{
	prod_review.FunnelChart_CoreBizFunnel: {
		&FunnelFloorConfig{
			Name:              "全域商品卡0补品",
			FilterDimensions:  NewFunnelFloorConfig("全域商品卡0补品"),
			FloorOrder:        1,
			GmvGoalTargetName: "zs_prod_card_gmv",
			//ProdCntTargetName: "zs_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:              "商城0补品",
			FilterDimensions:  NewFunnelFloorConfig("商城"),
			FloorOrder:        2,
			GmvGoalTargetName: "zs_m_prod_card_gmv",
			//ProdCntTargetName: "zs_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:              "品规内0补品",
			FilterDimensions:  NewFunnelFloorConfig("品规内"),
			FloorOrder:        3,
			GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			//ProdCntTargetName: "zs_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:              "品规内优价0补品(混比)",
			FilterDimensions:  NewFunnelFloorConfig("优价"),
			FloorOrder:        4,
			GmvGoalTargetName: "zs_m_pingui_gprice_prod_card_gmv",
			//ProdCntTargetName: "zs_prod_cnt",
		},
	},
	prod_review.FunnelChart_RuleFunnel: {
		&FunnelFloorConfig{
			Name:             "大盘0补品",
			FilterDimensions: NewFunnelFloorConfig("0补品"),
			FloorOrder:       1,
			//GmvGoalTargetName: "zs_prod_card_gmv",
			ProdCntTargetName: "zs_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:             "大盘0补品（品规内）",
			FilterDimensions: NewFunnelFloorConfig("品规内"),
			FloorOrder:       2,
			//GmvGoalTargetName: "zs_prod_card_gmv",
			ProdCntTargetName: "zs_pingui_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:             "大盘0补品（品规内）&非0动销&有资质",
			FilterDimensions: NewFunnelFloorConfig("非0动销&有资质品"),
			FloorOrder:       3,
			//GmvGoalTargetName: "zs_prod_card_gmv",
			ProdCntTargetName: "zs_pingui_pass_qua_prod_cnt",
		},
	},
	prod_review.FunnelChart_OperationFunnelSignUpSuccess: {
		&FunnelFloorConfig{
			Name:             "大盘0补品（品规内）&非0动销&有资质品",
			FilterDimensions: NewFunnelFloorConfig("大盘0补品（品规内）&非0动销&有资质品"),
			FloorOrder:       1,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "zs_pingui_pass_qua_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:             "报名超值购品",
			FilterDimensions: NewFunnelFloorConfig("报名超值购品"),
			FloorOrder:       2,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
		&FunnelFloorConfig{
			Name:             "报名成功品",
			FilterDimensions: NewFunnelFloorConfig("报名成功品"),
			FloorOrder:       3,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		}},
	prod_review.FunnelChart_OperationFunnelSignUpFailPriceMatch: {
		&FunnelFloorConfig{
			Name:             "大盘0补品（品规内）&非0动销&有资质品",
			FilterDimensions: NewFunnelFloorConfig("大盘0补品（品规内）&非0动销&有资质品"),
			FloorOrder:       1,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "zs_pingui_pass_qua_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:             "报名超值购品",
			FilterDimensions: NewFunnelFloorConfig("报名超值购品"),
			FloorOrder:       2,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
		&FunnelFloorConfig{
			Name:             "报名未成功品",
			FilterDimensions: NewFunnelFloorConfig("报名未成功品"),
			FloorOrder:       3,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
		&FunnelFloorConfig{
			Name:             "报名价格符合品",
			FilterDimensions: NewFunnelFloorConfig("报名价格符合品"),
			FloorOrder:       4,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
	},
	prod_review.FunnelChart_OperationFunnelSignUpFailPriceNoMatch: {
		&FunnelFloorConfig{
			Name:             "大盘0补品（品规内）&非0动销&有资质品",
			FilterDimensions: NewFunnelFloorConfig("大盘0补品（品规内）&非0动销&有资质品"),
			FloorOrder:       1,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "zs_pingui_pass_qua_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:             "报名超值购品",
			FilterDimensions: NewFunnelFloorConfig("报名超值购品"),
			FloorOrder:       2,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
		&FunnelFloorConfig{
			Name:             "报名未成功品",
			FilterDimensions: NewFunnelFloorConfig("报名未成功品"),
			FloorOrder:       3,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
		&FunnelFloorConfig{
			Name:             "报名价格不符合品",
			FilterDimensions: NewFunnelFloorConfig("报名价格不符合品"),
			FloorOrder:       4,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
	},
	prod_review.FunnelChart_OperationFunnelNoSignUpPriceMatch: {
		&FunnelFloorConfig{
			Name:             "大盘0补品（品规内）&非0动销&有资质品",
			FilterDimensions: NewFunnelFloorConfig("大盘0补品（品规内）&非0动销&有资质品"),
			FloorOrder:       1,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "zs_pingui_pass_qua_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:             "未报名超值购品",
			FilterDimensions: NewFunnelFloorConfig("未报名超值购品"),
			FloorOrder:       2,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
		&FunnelFloorConfig{
			Name:             "报名价格符合品",
			FilterDimensions: NewFunnelFloorConfig("报名价格符合品"),
			FloorOrder:       3,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
	},
	prod_review.FunnelChart_OperationFunnelNoSignUpPriceNoMatch: {
		&FunnelFloorConfig{
			Name:             "大盘0补品（品规内）&非0动销&有资质品",
			FilterDimensions: NewFunnelFloorConfig("大盘0补品（品规内）&非0动销&有资质品"),
			FloorOrder:       1,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "zs_pingui_pass_qua_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:             "未报名超值购品",
			FilterDimensions: NewFunnelFloorConfig("未报名超值购品"),
			FloorOrder:       2,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
		&FunnelFloorConfig{
			Name:             "报名价格不符合品",
			FilterDimensions: NewFunnelFloorConfig("报名价格不符合品"),
			FloorOrder:       3,
			//GmvGoalTargetName: "zs_m_pingui_prod_card_gmv",
			ProdCntTargetName: "",
		},
	},
	prod_review.FunnelChart_OperationFunnelTest: {
		&FunnelFloorConfig{
			Name:             "A组",
			FilterDimensions: NewFunnelFloorConfig("A组"),
			FloorOrder:       1,
		},
		&FunnelFloorConfig{
			Name:             "A1-服饰美奢(A组)",
			FilterDimensions: NewFunnelFloorConfig("A1-服饰美奢(A组)"),
			FloorOrder:       2,
		},
		&FunnelFloorConfig{
			Name:             "服饰女装(A组/A1-服饰美奢)",
			FilterDimensions: NewFunnelFloorConfig("服饰女装(A组/A1-服饰美奢)"),
			FloorOrder:       3,
		},
	},
	prod_review.FunnelChart_RecruitProdFunnel: {
		&FunnelFloorConfig{
			Name:              "报名特征挖掘词品",
			FilterDimensions:  NewFunnelFloorConfig("报名特征挖掘词品"),
			FloorOrder:        1,
			ProdCntTargetName: "show_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:              "曝光品",
			FilterDimensions:  NewFunnelFloorConfig("曝光品"),
			FloorOrder:        2,
			ProdCntTargetName: "show_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:              "动销品",
			FilterDimensions:  NewFunnelFloorConfig("动销品"),
			FloorOrder:        3,
			ProdCntTargetName: "show_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:              "全域爆品",
			FilterDimensions:  NewFunnelFloorConfig("全域爆品"),
			FloorOrder:        4,
			ProdCntTargetName: "show_prod_cnt",
		},
		&FunnelFloorConfig{
			Name:              "商品卡爆品",
			FilterDimensions:  NewFunnelFloorConfig("商品卡爆品"),
			FloorOrder:        5,
			ProdCntTargetName: "show_prod_cnt",
		},
	},
	prod_review.FunnelChart_CommonFunnel: {
		&FunnelFloorConfig{
			Name:              "曝光品",
			FilterDimensions:  NewFunnelFloorConfig("曝光品"),
			FloorOrder:        1,
			ProdCntTargetName: "show_prod_cnt",
			Tips:              "此处的商品限制了有曝光的条件!",
		},
		&FunnelFloorConfig{
			Name:              "动销品",
			FilterDimensions:  NewFunnelFloorConfig("动销品"),
			FloorOrder:        2,
			ProdCntTargetName: "show_prod_cnt",
			Tips:              "此处的商品限制了有曝光的条件!",
		},
		&FunnelFloorConfig{
			Name:              "全域爆品",
			FilterDimensions:  NewFunnelFloorConfig("全域爆品"),
			FloorOrder:        3,
			ProdCntTargetName: "show_prod_cnt",
			Tips:              "此处的商品限制了有曝光的条件!",
		},
		&FunnelFloorConfig{
			Name:              "商品卡爆品",
			FilterDimensions:  NewFunnelFloorConfig("商品卡爆品"),
			FloorOrder:        4,
			ProdCntTargetName: "show_prod_cnt",
			Tips:              "此处的商品限制了有曝光的条件!",
		},
	},
	prod_review.FunnelChart_MarketCommonFunnel: {
		&FunnelFloorConfig{
			Name:              "曝光品",
			FilterDimensions:  NewFunnelFloorConfig("曝光品"),
			FloorOrder:        1,
			ProdCntTargetName: "show_prod_cnt",
			Tips:              "此处的商品限制了有曝光的条件!",
		},
		&FunnelFloorConfig{
			Name:              "点击品",
			FilterDimensions:  NewFunnelFloorConfig("点击品"),
			FloorOrder:        2,
			ProdCntTargetName: "show_prod_cnt",
			Tips:              "此处的商品限制了有曝光的条件!",
		},
		&FunnelFloorConfig{
			Name:              "动销品",
			FilterDimensions:  NewFunnelFloorConfig("动销品"),
			FloorOrder:        3,
			ProdCntTargetName: "show_prod_cnt",
			Tips:              "此处的商品限制了有曝光的条件!",
		},
	},
}

func GetFunnelFloorConfigs(ctx context.Context, funnel prod_review.FunnelChart) []*FunnelFloorConfig {
	fConfigMap := make(map[int]*FunnelFloorConfig)
	resConfigs := make([]*FunnelFloorConfig, 0)
	if res, ok := FunnelChar[funnel]; ok {
		resConfigs = deepcopy.Copy(res).([]*FunnelFloorConfig)
		for _, v := range resConfigs {
			fConfigMap[v.FloorOrder] = v
			logs.CtxInfo(ctx, "floor %v len=%v", v.FloorOrder, len(v.FilterDimensions))
		}
	}
	for i := 2; i <= len(resConfigs); i++ {
		fConfigMap[i].FilterDimensions = append(fConfigMap[i].FilterDimensions, fConfigMap[i-1].FilterDimensions...)
		logs.CtxInfo(ctx, "GetFunnelFloorConfigs,floor %v len=%v", fConfigMap[i].FloorOrder, len(fConfigMap[i].FilterDimensions))
	}
	return resConfigs
}
