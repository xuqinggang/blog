package product_review_service

import (
	"code.byted.org/ecom/common/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/prod_review_tool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
)

func (d *ProductReviewService) ProductFourQuadrantAnalysis(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.ItemDataList, err error) {
	if req == nil || req.BaseReq == nil {
		return nil, errors.New("req or req.BaseReq is nil")
	}
	bizProjectId, strategyId, reportId := "", "", ""
	var bizProject *prod_review.BizProject
	var strategy *prod_review.ProdReviewStrategy
	var report *prod_review.ProdReviewReport
	prodReviewParams := &prod_review.ProdReviewParams{}
	if req.BizExtraInfo != nil && req.BizExtraInfo.ProdReviewParams != nil {
		prodReviewParams = req.BizExtraInfo.ProdReviewParams
		bizProjectId = req.BizExtraInfo.ProdReviewParams.BizProjectId
		strategyId = req.BizExtraInfo.ProdReviewParams.StrategyId
		reportId = req.BizExtraInfo.ProdReviewParams.ReportId
	}
	quadrantPartitionParams := &prod_review.QuadrantPartitionParams{}
	if prodReviewParams.QuadrantPartitionParams != nil {
		quadrantPartitionParams = prodReviewParams.QuadrantPartitionParams
	}
	if quadrantPartitionParams.XAxisConfig == nil || quadrantPartitionParams.YAxisConfig == nil {
		return nil, errors.New("x_axis_config or y_axis_config is nil")
	}
	if quadrantPartitionParams.ProdPoolType == prod_review.ProdPoolType_Unknown {
		quadrantPartitionParams.ProdPoolType = prod_review.ProdPoolType_Current
	}
	quadrantQueryParam := make(map[string]interface{}, 0)

	// 业务专项
	if bizProjectId != "" {
		bizProject = d.GetBizProjectById(ctx, bizProjectId)
	}
	// 单策略
	if strategyId != "" {
		strategy = d.GetStrategyById(ctx, strategyId)
	}
	// 个性化复盘报告
	if reportId != "" {
		report = d.GetReportById(ctx, reportId)
	}
	// 四象限查询
	if bizProject == nil && strategy == nil && report == nil {
		return nil, nil
	}
	if strategy == nil && report != nil && report.EntityType == prod_review.EntityType_Strategy {
		strategy = report.ProdReviewStrategy
	}
	if bizProject == nil && report != nil && report.EntityType == prod_review.EntityType_BizProject {
		bizProject = report.BizProject
	}
	dimMap, err := d.DimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取map失败，err=%v+", err)
		return nil, err
	}
	dimColMap, err := d.DimensionListDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取col map失败，err=%v+", err)
		return nil, err
	}
	queryItems := make([]map[string]interface{}, 0)
	currItem := make(map[string]interface{})
	compareItem := make(map[string]interface{})
	currItem["is_curr"] = 1
	compareItem["is_curr"] = 0
	reqDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	bizProjectFilterDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	if bizProject != nil {
		bizProjectFilterDimensions = bizProject.FilterDimensions
		bizProjectCurrItem, bizProjectCompareItem := genBizProjectParam(ctx, req, bizProject, quadrantPartitionParams.ProdPoolType, prodReviewParams.CompareProdPoolType, dimMap, dimColMap)
		for key, value := range bizProjectCurrItem {
			currItem[key] = value
		}
		for key, value := range bizProjectCompareItem {
			compareItem[key] = value
		}
	} else if strategy != nil {
		strategyCurrItem, strategyCompareItem := genStrategyParam(ctx, req, strategy, quadrantPartitionParams.ProdPoolType, prodReviewParams.CompareProdPoolType, dimMap, dimColMap)
		for key, value := range strategyCurrItem {
			currItem[key] = value
		}
		for key, value := range strategyCompareItem {
			compareItem[key] = value
		}
	}
	if quadrantPartitionParams.ProdPoolType == prod_review.ProdPoolType_Current {
		reqDimensions = append(reqDimensions, req.BaseReq.Dimensions...)
		reqDimensions = append(reqDimensions, bizProjectFilterDimensions...) // 添加业务专项
	} else if quadrantPartitionParams.ProdPoolType == prod_review.ProdPoolType_Compare {
		reqDimensions = append(reqDimensions, req.CompareReq.Dimensions...)
	}

	currParam, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx,
		base_struct_condition.OsParamsReq{
			BaseStruct: &dimensions.ProductAnalysisBaseStruct{
				BizType:          req.BaseReq.BizType,
				StartDate:        req.BaseReq.StartDate,
				EndDate:          req.BaseReq.EndDate,
				CompareStartDate: req.BaseReq.CompareStartDate,
				CompareEndDate:   req.BaseReq.CompareEndDate,
				Dimensions:       reqDimensions,
			},
			DimMap:    dimMap,
			DimColMap: dimColMap,
		})
	// 指标前缀
	targetPrefix := ""
	isNeedCompare := false
	switch quadrantPartitionParams.XAxisConfig.ValueType {
	case prod_review.ValueType_AbsoluteValue: // 当前值
		targetPrefix = "curr_"
	case prod_review.ValueType_Increase: // AA 增量
		targetPrefix = "aa_increase_"
		isNeedCompare = true
	case prod_review.ValueType_AAIncreasePercent: // AA增幅
		targetPrefix = "aa_increase_rate_"
		isNeedCompare = true
	case prod_review.ValueType_ABIncreasePercent: // AB增幅，复用AA增量的名称，计算逻辑不一样
		targetPrefix = "aa_increase_rate_"
		isNeedCompare = true
	case prod_review.ValueType_ABIncrease: // AB增量
		targetPrefix = "aa_increase_"
		isNeedCompare = true
	default:
		return nil, errors.New("QuadrantPartitionParams.XAxis.ValueType is Unknown")
	}
	xTargetName := targetPrefix + quadrantPartitionParams.XAxisConfig.AxisTargetName
	yTargetName := targetPrefix + quadrantPartitionParams.YAxisConfig.AxisTargetName

	xTargetValue := quadrantPartitionParams.XAxisConfig.AxisSegmentationValue
	yTargetValue := quadrantPartitionParams.YAxisConfig.AxisSegmentationValue
	quadrantQueryParam["x_target_name"] = xTargetName
	quadrantQueryParam["y_target_name"] = yTargetName

	if quadrantPartitionParams.ThresholdType == prod_review.ThresholdType_Percentile {
		quadrantQueryParam["is_quantile"] = 1
		if quadrantPartitionParams.XAxisConfig.AxisSegmentation == prod_review.AxisSegmentation_Top10Percent {
			xTargetName = "x_p90"
			xTargetValue = 0.9
		} else if quadrantPartitionParams.XAxisConfig.AxisSegmentation == prod_review.AxisSegmentation_Top20Percent {
			xTargetName = "x_p80"
			xTargetValue = 0.8
		}
		if quadrantPartitionParams.YAxisConfig.AxisSegmentation == prod_review.AxisSegmentation_Top10Percent {
			yTargetName = "y_p90"
			yTargetValue = 0.9
		} else if quadrantPartitionParams.YAxisConfig.AxisSegmentation == prod_review.AxisSegmentation_Top20Percent {
			yTargetName = "y_p80"
			yTargetValue = 0.8
		}
	} else if quadrantPartitionParams.ThresholdType == prod_review.ThresholdType_AbsoluteValue {
		quadrantQueryParam["is_quantile"] = 0
	}
	conditions := getFourQuadrant(quadrantPartitionParams.XAxisConfig.AxisCondition, quadrantPartitionParams.YAxisConfig.AxisCondition)
	fourQuadrantConds := make([]string, 5)
	for i, cond := range conditions {
		fourQuadrantConds[i] = fmt.Sprintf("%s %s %f and %s %s %f", xTargetName, cond[0], xTargetValue, yTargetName, cond[1], yTargetValue)
	}
	logs.CtxInfo(ctx, "target filter conditions:", fourQuadrantConds)
	quadrantQueryParam["four_conditions"] = fourQuadrantConds
	currItem["filter_param"] = currParam["filter_param"]
	compareItem["filter_param"] = currParam["filter_param"]
	if !isNeedCompare { // 如果不需要计算AA增量，那么所有查询都是达标的
		currItem["reach_std"] = 1
		compareItem["reach_std"] = 1
	}
	bizConfig, err := biz_info.GetBizInfoConfig(ctx, req.BaseReq.BizType)
	apiPath := "7567005306568344602"
	mainDimensionCol := "leaf_cate_name"
	if bizConfig != nil && bizConfig.ProdReviewConfig != nil {
		if strategy != nil && bizConfig.ProdReviewConfig.StrategyModuleConfig != nil &&
			bizConfig.ProdReviewConfig.StrategyModuleConfig.QuadrantPartitionConf != nil {
			apiPath = bizConfig.ProdReviewConfig.StrategyModuleConfig.QuadrantPartitionConf.OneServiceApi
			if bizConfig.ProdReviewConfig.StrategyModuleConfig.QuadrantPartitionConf.MainDimensionCol != "" {
				mainDimensionCol = bizConfig.ProdReviewConfig.StrategyModuleConfig.QuadrantPartitionConf.MainDimensionCol
			}
			if bizConfig.ProdReviewConfig.StrategyModuleConfig.QuadrantPartitionConf.MainDimensionId != "" {
				dimId, _ := strconv.ParseInt(bizConfig.ProdReviewConfig.BizProjectModuleConfig.QuadrantPartitionConf.MainDimensionId, 10, 64)
				if dimInfo, ok := dimMap[dimId]; ok {
					if dimInfo.DimExpr != "" {
						mainDimensionCol = fmt.Sprintf("cast(%s as String) as %s", dimInfo.DimExpr, dimInfo.DimColumn)
					} else {
						mainDimensionCol = dimInfo.DimColumn
					}
				}
			}
		}
		if bizProject != nil && bizConfig.ProdReviewConfig.BizProjectModuleConfig != nil &&
			bizConfig.ProdReviewConfig.BizProjectModuleConfig.QuadrantPartitionConf != nil {
			apiPath = bizConfig.ProdReviewConfig.BizProjectModuleConfig.QuadrantPartitionConf.OneServiceApi
			if bizConfig.ProdReviewConfig.BizProjectModuleConfig.QuadrantPartitionConf.MainDimensionId != "" {
				dimId, _ := strconv.ParseInt(bizConfig.ProdReviewConfig.BizProjectModuleConfig.QuadrantPartitionConf.MainDimensionId, 10, 64)
				if dimInfo, ok := dimMap[dimId]; ok {
					if dimInfo.DimExpr != "" {
						mainDimensionCol = fmt.Sprintf("cast(%s as String) as %s", dimInfo.DimExpr, dimInfo.DimColumn)
					} else {
						mainDimensionCol = dimInfo.DimColumn
					}
				}
			}
		}
	}
	currItem["main_dimension_col"] = mainDimensionCol
	compareItem["main_dimension_col"] = mainDimensionCol

	if strategy != nil && strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis {
		currParam["table_name"] = consts.BizABTableMap[req.BaseReq.BizType]
	}
	if bizProject != nil && quadrantPartitionParams.AnalysisObject == prod_review.AnalysisObject_StrategyCoveredProduct && len(bizProject.StrategyList) > 0 {
		if quadrantPartitionParams.StrategyId != "" { // 覆盖某一策略
			for _, strategyTemp := range bizProject.StrategyList {
				if strategyTemp.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis &&
					strategyTemp.StrategyId == quadrantPartitionParams.StrategyId {
					currParam["table_name"] = consts.BizABTableMap[req.BaseReq.BizType]
					break
				}
			}
		}
	}
	currItem["table_name"] = currParam["table_name"]
	compareItem["table_name"] = currParam["table_name"]
	queryItems = append(queryItems, currItem)
	if isNeedCompare { // 需要增量的时候才去查对比时间
		queryItems = append(queryItems, compareItem)
	}
	quadrantQueryParam["query_items"] = queryItems
	currParam["quadrant_query_param"] = quadrantQueryParam
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: currParam, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType,
		KeyCols: []string{"quadrant_name", "main_dimension_col", "dim_key"}, FilterTarget: false,
	})
	if err != nil {
		logs.CtxError(ctx, "[ProductFourQuadrantAnalysis]调用OneService查询四象限数据失败，err=%v+", err)
		return nil, err
	}
	resp = &common_response.ItemDataList{
		ItemDataList: make([]*common_response.ItemData, 0),
		ExtraInfo:    &common_response.ItemDataListExtraInfo{},
	}
	respMap := make(map[string]*common_response.ItemData)
	mainCategoryCountMap := make(map[string]int)
	totalTargets := make([]*analysis.TargetCardEntity, 0)
	for _, row := range currTargetList {
		dimKey := ""
		if len(row.KeyColValues) == 3 {
			dimKey = row.KeyColValues[2].(string)
		}
		keys := strings.Split(dimKey, "###")
		if len(keys) == 2 && keys[1] == "" && keys[0] == "" {
			totalTargets = row.TargetEntity
		}
		if len(keys) == 2 && keys[1] == "" && keys[0] != "" {
			itemData := common_response.NewItemData()
			itemData.TargetList = row.TargetEntity
			itemData.ItemName = keys[0]
			quadrantName := ""
			quadrantIndex := 0
			switch keys[0] {
			case "first_quadrant":
				quadrantName = "可反向招商品"
				quadrantIndex = 1
			case "second_quadrant":
				quadrantName = "流量扶持高收益品"
				quadrantIndex = 2
			case "third_quadrant":
				quadrantName = "建议汰换品"
				quadrantIndex = 3
			case "fourth_quadrant":
				quadrantName = "建议优化CTR/CVR品"
				quadrantIndex = 4
			default:
				quadrantName = "未知"
				quadrantIndex = 0
			}
			quadrantQueryParam["condition"] = fourQuadrantConds[quadrantIndex]
			itemData.ExtraInfo = &common_response.ItemDataExtraInfo{
				QuadrantInfo: &common_response.QuadrantInfo{
					QuadrantName:       quadrantName,
					MainCategoryName:   make([]string, 0),
					QuadrantQueryParam: utils.JSONF(quadrantQueryParam),
				},
			}
			resp.ItemDataList = append(resp.ItemDataList, itemData)
			respMap[keys[0]] = itemData
			mainCategoryCountMap[keys[0]] = 0
		}
	}
	// 叶子类目下钻
	topCategoryCount := 5
	for _, row := range currTargetList {
		dimKey := ""
		if len(row.KeyColValues) == 3 {
			dimKey = row.KeyColValues[2].(string)
		}
		keys := strings.Split(dimKey, "###")
		if len(keys) == 2 && keys[1] != "" {
			if itemData, ok := respMap[keys[0]]; ok {
				if mainCategoryCountMap[keys[0]] >= topCategoryCount {
					continue
				}
				itemData.ExtraInfo.QuadrantInfo.MainCategoryName =
					append(itemData.ExtraInfo.QuadrantInfo.MainCategoryName, keys[1])
				mainCategoryCountMap[keys[0]]++
			}
		}
	}
	// 处理占比数据
	for _, itemData := range respMap {
		for _, item := range itemData.TargetList {
			for _, totalItem := range totalTargets {
				if totalItem.Value == 0 {
					continue
				}
				if item.Name == totalItem.Name {
					if item.Extra == nil {
						item.Extra = &analysis.TargetCardExtraInfo{}
					}
					item.Extra.DistributionFlag = true
					item.Extra.DistributionValue = item.Value / totalItem.Value
					break
				}
			}
		}
		sort.Slice(itemData.TargetList, func(i, j int) bool {
			return itemData.TargetList[i].DisplayOrder < itemData.TargetList[j].DisplayOrder
		})
	}
	return resp, nil
}

func getFourQuadrant(xCondition, yCondition prod_review.CompareCondition) [][]string {
	result := [][]string{make([]string, 2), make([]string, 2), make([]string, 2), make([]string, 2), make([]string, 2)}
	if xCondition == prod_review.CompareCondition_GreaterThan {
		result[1][0] = ">"
		result[2][0] = "<="
		result[3][0] = "<="
		result[4][0] = ">"
	} else if xCondition == prod_review.CompareCondition_GreaterThanOrEqual {
		result[1][0] = ">="
		result[2][0] = "<"
		result[3][0] = "<"
		result[4][0] = ">="
	}
	if yCondition == prod_review.CompareCondition_GreaterThan {
		result[1][1] = ">"
		result[2][1] = ">"
		result[3][1] = "<="
		result[4][1] = "<="
	} else if yCondition == prod_review.CompareCondition_GreaterThanOrEqual {
		result[1][1] = ">="
		result[2][1] = ">="
		result[3][1] = "<"
		result[4][1] = "<"
	}
	return result
}

func buildQuadrantParam(currParam map[string]interface{}, condition string) string {
	quadrantParam := make(map[string]interface{})
	keys := []string{"query_items", "x_target_name", "y_target_name", "is_quantile"}
	for _, key := range keys {
		quadrantParam[key] = currParam[key]
	}
	quadrantParam["condition"] = condition
	jsonStr, _ := json.Marshal(quadrantParam)
	return string(jsonStr)
}

func getFilterParam(ctx context.Context, req *common_request.CommonAnalysisRequest, addFilterDimensions []*dimensions.SelectedDimensionInfo,
	dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo,
	startDate, endDate, compareStartDate, compareEndDate string) interface{} {
	currParam, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx,

		base_struct_condition.OsParamsReq{
			BaseStruct: &dimensions.ProductAnalysisBaseStruct{
				BizType:          req.BaseReq.BizType,
				StartDate:        startDate,
				EndDate:          endDate,
				CompareStartDate: compareStartDate,
				CompareEndDate:   compareEndDate,
				Dimensions:       addFilterDimensions,
			},
			DimMap:    dimMap,
			DimColMap: dimColMap,
		})
	if err != nil {
		logs.CtxError(ctx, "[getFilterParam]获取map失败，err=%v+", err)
		return nil
	}
	if filterParam, ok := currParam["filter_param"]; ok {
		return filterParam
	}
	return nil
}

func genStrategyParam(ctx context.Context, req *common_request.CommonAnalysisRequest, strategy *prod_review.ProdReviewStrategy,
	analysisProdPoolType prod_review.ProdPoolType, compareProdPoolType prod_review.CompareProdPoolType,
	dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo) (currItem, compareItem map[string]interface{}) {
	currItem, compareItem = make(map[string]interface{}), make(map[string]interface{})
	if strategy == nil {
		return currItem, compareItem
	}
	if strategy.AaIncreaseCalType == prod_review.InCreaseCalType_ReachStdVsReachStd { // 达标 vs 达标
		currItem["reach_std"] = 1
		compareItem["reach_std"] = 1
	} else if strategy.AaIncreaseCalType == prod_review.InCreaseCalType_ReachStdVsNoReachStd { // 达标 vs 未达标
		currItem["reach_std"] = 1
		compareItem["reach_std"] = 0
	} else if strategy.AaIncreaseCalType == prod_review.InCreaseCalType_ReachStdVsTotalPeriod { // 达标 vs 全周期
		currItem["reach_std"] = 1
		compareItem["reach_std"] = 2
	}
	if strategy.StrategyType != nil && strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis { // 依赖用户输入
		currItem["reach_std"] = 2
		compareItem["reach_std"] = 2
	}
	/*
		同品对比：对比周期分析的商品范围，需要用当前周期的时间去筛选，
		规则品对比：对比周期分析的商品范围，用对比周期的时间去筛选
	*/
	if strategy.StrategyType == nil {
		logs.CtxError(ctx, "[genStrategyParam]StrategyType is nil")
		return nil, nil
	}
	if strategy.StrategyType.PeriodCompareType == prod_review.PeriodCompareType_SameProdCompare { // 同品对比
		currItem["compare_type"] = "same_prod"
		compareItem["compare_type"] = "same_prod"
	} else if strategy.StrategyType.PeriodCompareType == prod_review.PeriodCompareType_RuleProdCompare { // 规则品对比
		currItem["compare_type"] = "rule_prod"
		compareItem["compare_type"] = "rule_prod"
	}
	if strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_AACommonAnalysis { // AA通用分析
		currItem["strategy_type"] = "AA"
		compareItem["strategy_type"] = "AA"
	} else if strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis {
		currItem["strategy_type"] = "AB"
		compareItem["strategy_type"] = "AB"
	}
	strategyFilterDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	strategySubQueryFilterDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	currItem["entity_type"] = "strategy"
	compareItem["entity_type"] = "strategy"
	if strategy.StrategyType != nil && strategy.StrategyType.IsDependSubQuery { // 依赖子查询
		strategySubQueryFilterDimensions = strategy.RelationProdPool
		currItem["is_need_two_table"] = 1
		compareItem["is_need_two_table"] = 1
	} else {
		strategyFilterDimensions = strategy.RelationProdPool
		currItem["is_need_two_table"] = 0
		compareItem["is_need_two_table"] = 0
		if !strategy.StrategyType.IsDependUserInput { // 不依赖用户输入
			currItem["reach_rule"] = strategy.StrategyType.ReachStdRule
			compareItem["reach_rule"] = strategy.StrategyType.ReachStdRule
		}
	}
	var baseRequest *dimensions.ProductAnalysisBaseStruct
	if analysisProdPoolType == prod_review.ProdPoolType_Compare {
		baseRequest = req.CompareReq
	} else {
		baseRequest = req.BaseReq
	}
	if baseRequest == nil {
		return currItem, compareItem
	}
	currItem["start_date"] = baseRequest.StartDate
	currItem["end_date"] = baseRequest.EndDate
	compareItem["start_date"] = baseRequest.CompareStartDate
	compareItem["end_date"] = baseRequest.CompareEndDate
	if strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis {
		compareItem["start_date"] = baseRequest.StartDate
		compareItem["end_date"] = baseRequest.EndDate
	}
	if (analysisProdPoolType == prod_review.ProdPoolType_Compare &&
		compareProdPoolType == prod_review.CompareProdPoolType_StrategyOverall) ||
		analysisProdPoolType == prod_review.ProdPoolType_Current ||
		analysisProdPoolType == prod_review.ProdPoolType_SuggestExpandScaleProduct ||
		analysisProdPoolType == prod_review.ProdPoolType_SuggestTrafficSupportProduct ||
		analysisProdPoolType == prod_review.ProdPoolType_SuggestOptimizeConvertProduct ||
		analysisProdPoolType == prod_review.ProdPoolType_SuggestEliminateProduct ||
		analysisProdPoolType == prod_review.ProdPoolType_ShortTermValueProduct ||
		analysisProdPoolType == prod_review.ProdPoolType_LongTermValueProduct ||
		analysisProdPoolType == prod_review.ProdPoolType_StrategyNegativeProduct {
		if strategy.StrategyType != nil && strategy.StrategyType.IsDependSubQuery {
			currItem["sub_query"] = prod_review_tool.GetSubQuerySql(ctx, req.BaseReq, strategySubQueryFilterDimensions, dimMap, baseRequest.StartDate, baseRequest.EndDate)
			compareItem["sub_query"] = prod_review_tool.GetSubQuerySql(ctx, req.BaseReq, strategySubQueryFilterDimensions, dimMap, baseRequest.CompareStartDate, baseRequest.CompareEndDate)
		} else {
			strategyFilterParam := getFilterParam(ctx, req, strategyFilterDimensions, dimMap, dimColMap,
				req.BaseReq.StartDate, req.BaseReq.EndDate, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
			currItem["strategy_filter_param"] = strategyFilterParam
			compareItem["strategy_filter_param"] = strategyFilterParam
			if strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis {
				if req.BizExtraInfo != nil && req.BizExtraInfo.ProdReviewParams != nil &&
					req.BizExtraInfo.ProdReviewParams.ExpConfig != nil {
					strategyFilterParamCurr := fmt.Sprintf("version_id = '%s'",
						req.BizExtraInfo.ProdReviewParams.ExpConfig.BaseVersionId)
					strategyFilterParamCompare := fmt.Sprintf("version_id = '%s'",
						req.BizExtraInfo.ProdReviewParams.ExpConfig.ExpVersionId)
					if strategyFilterParam != nil {
						strategyFilterParamCurr = fmt.Sprintf("%s and %s", strategyFilterParam, strategyFilterParamCurr)
						strategyFilterParamCompare = fmt.Sprintf("%s and %s", strategyFilterParam, strategyFilterParamCompare)
					}
					currItem["strategy_filter_param"] = strategyFilterParamCurr
					compareItem["strategy_filter_param"] = strategyFilterParamCompare
				}
			}

			if strategy.StrategyType.IsDependUserInput { // 依赖用户输入
				currItem["reach_rule"] = strategyFilterParam
				compareItem["reach_rule"] = strategyFilterParam
			}
		}
		if strategy.StrategyType != nil && strategy.StrategyType.PeriodCompareType == prod_review.PeriodCompareType_SameProdCompare {
			compareItem["curr_sub_query"] = prod_review_tool.GetSubQuerySql(ctx, req.BaseReq, strategySubQueryFilterDimensions, dimMap, req.BaseReq.StartDate, req.BaseReq.EndDate)
			compareItem["curr_start_date"] = baseRequest.StartDate
			compareItem["curr_end_date"] = baseRequest.EndDate
		}
	}
	if analysisProdPoolType == prod_review.ProdPoolType_Compare &&
		compareProdPoolType != prod_review.CompareProdPoolType_StrategyOverall {
		currItem["reach_std"] = nil
		compareItem["reach_std"] = nil
	}
	return currItem, compareItem

}

func genBizProjectParam(ctx context.Context, req *common_request.CommonAnalysisRequest, bizProject *prod_review.BizProject,
	analysisProdPoolType prod_review.ProdPoolType, compareProdPoolType prod_review.CompareProdPoolType,
	dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo) (currItem, compareItem map[string]interface{}) {
	currItem, compareItem = make(map[string]interface{}), make(map[string]interface{})
	if bizProject == nil {
		return currItem, compareItem
	}
	currItem["entity_type"] = "biz_project"
	compareItem["entity_type"] = "biz_project"
	var baseRequest *dimensions.ProductAnalysisBaseStruct
	if analysisProdPoolType == prod_review.ProdPoolType_Compare {
		baseRequest = req.CompareReq
	} else {
		baseRequest = req.BaseReq
	}
	if baseRequest == nil {
		return currItem, compareItem
	}
	currItem["start_date"] = baseRequest.StartDate
	currItem["end_date"] = baseRequest.EndDate
	compareItem["start_date"] = baseRequest.CompareStartDate
	compareItem["end_date"] = baseRequest.CompareEndDate
	//if analysisProdPoolType == prod_review.ProdPoolType_Current {
	//
	//} else if analysisProdPoolType == prod_review.ProdPoolType_Compare {
	//	currItem["start_date"] = req.CompareReq.StartDate
	//	currItem["end_date"] = req.CompareReq.EndDate
	//	compareItem["start_date"] = req.CompareReq.CompareStartDate
	//	compareItem["end_date"] = req.CompareReq.CompareEndDate
	//}
	quadrantParam := req.BizExtraInfo.ProdReviewParams.QuadrantPartitionParams
	bubbleChartParam := req.BizExtraInfo.ProdReviewParams.BubbleChartParams
	strategyId := ""
	analysisObject := prod_review.AnalysisObject_Unknown
	if quadrantParam != nil && quadrantParam.AnalysisObject != prod_review.AnalysisObject_Unknown {
		strategyId = quadrantParam.StrategyId
		analysisObject = quadrantParam.AnalysisObject
	} else if bubbleChartParam != nil && bubbleChartParam.AnalysisObject != prod_review.AnalysisObject_Unknown {
		strategyId = bubbleChartParam.StrategyId
		analysisObject = bubbleChartParam.AnalysisObject
	}
	// 分析对象为策略覆盖品
	if analysisObject == prod_review.AnalysisObject_StrategyCoveredProduct && len(bizProject.StrategyList) > 0 {
		if strategyId != "" { // 覆盖某一策略
			for _, strategy := range bizProject.StrategyList {
				if strategy.StrategyId == strategyId {
					strategyFilterParam := getFilterParam(ctx, req, strategy.RelationProdPool, dimMap, dimColMap,
						req.BaseReq.StartDate, req.BaseReq.EndDate, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
					currItem["strategy_filter_param"] = strategyFilterParam
					compareItem["strategy_filter_param"] = strategyFilterParam
					if strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis {
						if req.BizExtraInfo != nil && req.BizExtraInfo.ProdReviewParams != nil &&
							req.BizExtraInfo.ProdReviewParams.ExpConfig != nil {
							strategyFilterParamCurr := fmt.Sprintf("version_id = '%s'",
								req.BizExtraInfo.ProdReviewParams.ExpConfig.BaseVersionId)
							strategyFilterParamCompare := fmt.Sprintf("version_id = '%s'",
								req.BizExtraInfo.ProdReviewParams.ExpConfig.ExpVersionId)
							if strategyFilterParam != nil {
								strategyFilterParamCurr = fmt.Sprintf("%s and %s", strategyFilterParam, strategyFilterParamCurr)
								strategyFilterParamCompare = fmt.Sprintf("%s and %s", strategyFilterParam, strategyFilterParamCompare)
							}
							currItem["strategy_filter_param"] = strategyFilterParamCurr
							compareItem["strategy_filter_param"] = strategyFilterParamCompare
							compareItem["start_date"] = baseRequest.StartDate
							compareItem["end_date"] = baseRequest.EndDate
						}
					}
					break
				}
			}
		} else { // 不传策略id，默认取所有策略
			strategyFilterParams := make([]string, 0)
			for _, strategy := range bizProject.StrategyList {
				strategyFilterParam := getFilterParam(ctx, req, strategy.RelationProdPool, dimMap, dimColMap,
					req.BaseReq.StartDate, req.BaseReq.EndDate, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
				if strategyFilterParam == nil {
					logs.CtxWarn(ctx, "[GenBizProjectParam]Get strategy filter fail, strategy id=%v", strategy.StrategyId)
					continue
				}
				strategyFilterParams = append(strategyFilterParams, "( "+strategyFilterParam.(string)+" )")
			}
			if len(strategyFilterParams) > 0 {
				currItem["strategy_filter_param"] = "( " + strings.Join(strategyFilterParams, " or ") + " )"
				compareItem["strategy_filter_param"] = "( " + strings.Join(strategyFilterParams, " or ") + " )"
			}
		}
	}
	// 分析对象为策略未覆盖品
	if analysisObject == prod_review.AnalysisObject_StrategyUncoveredProduct {
		if strategyId != "" {
			for _, strategy := range bizProject.StrategyList {
				if strategy.StrategyId == strategyId {
					strategyFilterParam := getFilterParam(ctx, req, strategy.RelationProdPool, dimMap, dimColMap,
						req.BaseReq.StartDate, req.BaseReq.EndDate, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
					currItem["no_strategy_filter_params"] = strategyFilterParam
					compareItem["no_strategy_filter_params"] = strategyFilterParam
					if strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis {
						//versionIds := make([]string, 0)
						//for _, vid := range strategy.AllVersionInfo {
						//	versionIds = append(versionIds, "'"+vid.VersionId+"'")
						//}
						//versionIdsStr := strings.Join(versionIds, ",")
						//libraFilter := fmt.Sprintf("prod_id in ("+
						//	"select prod_id "+
						//	"from %s as ab_table "+
						//	"where version_id in (%s) "+
						//	"and date >= '%s' and date <= '%s'"+
						//	")", consts.BizABTableMap[req.BaseReq.BizType], versionIdsStr, req.BaseReq.StartDate, req.BaseReq.EndDate)
						libraFilter := getABStrategyLibraFilter(consts.BizABTableMap[req.BaseReq.BizType], req.BaseReq.StartDate, req.BaseReq.EndDate, strategy)
						strategyFilterParamCurr := libraFilter
						strategyFilterParamCompare := libraFilter
						if strategyFilterParam != nil {
							strategyFilterParamCurr = fmt.Sprintf("(%s and %s)", strategyFilterParam, strategyFilterParamCurr)
							strategyFilterParamCompare = fmt.Sprintf("(%s and %s)", strategyFilterParam, strategyFilterParamCompare)
						}
						currItem["no_strategy_filter_params"] = strategyFilterParamCurr
						compareItem["no_strategy_filter_params"] = strategyFilterParamCompare
					}
					break
				}
			}
		}
		//else {
		//	strategyFilterParams := make([]string, 0)
		//	for _, strategy := range bizProject.StrategyList {
		//		strategyFilterParam := getFilterParam(ctx, req, strategy.RelationProdPool, dimMap, dimColMap,
		//			req.BaseReq.StartDate, req.BaseReq.EndDate, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
		//		strategyFilterParamStr := strategyFilterParam.(string)
		//		strategyFilterParams = append(strategyFilterParams, "( "+strategyFilterParamStr+" )")
		//	}
		//	currItem["no_strategy_filter_params"] = "( " + strings.Join(strategyFilterParams, " or ") + " )"
		//	compareItem["no_strategy_filter_params"] = "( " + strings.Join(strategyFilterParams, " or ") + " )"
		//}
	}
	return currItem, compareItem
}

func getABStrategyLibraFilter(abTableName, startDate, endDate string, strategy *prod_review.ProdReviewStrategy) string {
	if strategy != nil && strategy.StrategyType != nil &&
		strategy.StrategyType.StrategyAnalysisType == prod_review.StrategyAnalysisType_ABExpAnalysis {
		versionIds := make([]string, 0)
		for _, vid := range strategy.AllVersionInfo {
			versionIds = append(versionIds, "'"+vid.VersionId+"'")
		}
		versionIdsStr := strings.Join(versionIds, ",")
		libraFilter := fmt.Sprintf("prod_id in ("+
			"select prod_id "+
			"from %s as ab_table "+
			"where version_id in (%s) "+
			"and date >= '%s' and date <= '%s'"+
			")", abTableName, versionIdsStr, startDate, endDate)
		return libraFilter
	}
	return ""
}
