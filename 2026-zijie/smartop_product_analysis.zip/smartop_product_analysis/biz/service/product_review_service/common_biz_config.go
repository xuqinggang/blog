package product_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"context"
)

func (d *ProductReviewService) ICommonGetBizConfig(ctx context.Context, req *common_request.BizConfigRequest) (resp *common_response.BizConfigData, err error) {
	bizMetaInfo, ctx, _ := biz_utils.GetBizMetaInfo(ctx, req.GetBizType())
	dependBizType := req.BizType
	if bizMetaInfo != nil && bizMetaInfo.DependBizID != 0 {
		dependBizType = dimensions.BizType(bizMetaInfo.DependBizID)
	}
	res, err := biz_info.GetBizInfoConfig(ctx, dependBizType)
	if err != nil {
		logs.CtxError(ctx, "ICommonGetBizConfig Error, biz_info_config,biz_type=%d,err=%v", req.BizType, err)
		return nil, err
	}
	return res, nil
}
