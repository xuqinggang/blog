package product_review_service

import (
	"context"
	"fmt"
	"sort"
	"time"

	"code.byted.org/ecom/common/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
)

// ProductValueClassify 商品价值分化
func (d *ProductReviewService) ProductValueClassify(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.ItemDataList, err error) {
	if req == nil || req.BaseReq == nil {
		return nil, errors.New("req or req.BaseReq is nil")
	}
	bizProjectId, strategyId, reportId := "", "", ""
	var bizProject *prod_review.BizProject
	var strategy *prod_review.ProdReviewStrategy
	var report *prod_review.ProdReviewReport
	prodReviewParams := &prod_review.ProdReviewParams{}
	if req.BizExtraInfo != nil && req.BizExtraInfo.ProdReviewParams != nil {
		prodReviewParams = req.BizExtraInfo.ProdReviewParams
		bizProjectId = req.BizExtraInfo.ProdReviewParams.BizProjectId
		strategyId = req.BizExtraInfo.ProdReviewParams.StrategyId
		reportId = req.BizExtraInfo.ProdReviewParams.ReportId
	}

	productValueClassifyParams := &prod_review.ProductValueClassifyParams{}
	if prodReviewParams.ProductValueClassifyParams != nil {
		productValueClassifyParams = prodReviewParams.ProductValueClassifyParams
	} else {
		return nil, errors.New("invalid product value classify params")
	}

	queryParam := make(map[string]interface{}, 0)
	queryParam["analysis_start_date"] = req.BaseReq.StartDate
	queryParam["analysis_end_date"] = req.BaseReq.EndDate
	queryParam["analysis_compare_start_date"] = req.BaseReq.CompareStartDate
	queryParam["analysis_compare_end_date"] = req.BaseReq.CompareEndDate
	queryParam["prod_pool_type"] = productValueClassifyParams.ProdPoolType
	queryParam["define_type"] = productValueClassifyParams.DefineType
	queryParam["short_term_threshold"] = productValueClassifyParams.ShortTermThreshold
	queryParam["long_term_threshold"] = productValueClassifyParams.LongTermThreshold
	queryParam["query_type"] = productValueClassifyParams.QueryType
	if productValueClassifyParams.TargetPoolType == nil {
		queryParam["target_pool_type"] = 0
	} else {
		queryParam["target_pool_type"] = productValueClassifyParams.TargetPoolType
	}

	// 抄来的基础信息填充
	// 业务专项
	if bizProjectId != "" {
		bizProject = d.GetBizProjectById(ctx, bizProjectId)
	}
	// 单策略
	if strategyId != "" {
		strategy = d.GetStrategyById(ctx, strategyId)
	}
	// 个性化复盘报告
	if reportId != "" {
		report = d.GetReportById(ctx, reportId)
	}

	if bizProject == nil && strategy == nil && report == nil {
		return nil, nil
	}
	if strategy == nil && report != nil && report.EntityType == prod_review.EntityType_Strategy {
		strategy = report.ProdReviewStrategy
	}
	if bizProject == nil && report != nil && report.EntityType == prod_review.EntityType_BizProject {
		bizProject = report.BizProject
	}

	// 填充查询的策略时间
	if strategy != nil {
		// 将时间戳转换为时间对象
		strategyStartTime := time.Unix(strategy.StartDate, 0)
		strategyEndTime := time.Unix(strategy.EndDate, 0)

		// 格式化原策略时间
		startDate := strategyStartTime.Format(consts.Fmt_Date)
		endDate := strategyEndTime.Format(consts.Fmt_Date)

		// 计算时间段长度（天数）
		duration := strategyEndTime.Sub(strategyStartTime)
		days := int(duration.Hours() / 24)

		// 向前平移等长的时间，得到比较时间段
		compareStartDate := strategyStartTime.AddDate(0, 0, -days-1).Format(consts.Fmt_Date)
		compareEndDate := strategyStartTime.AddDate(0, 0, -1).Format(consts.Fmt_Date)

		// 添加原策略时间参数
		queryParam["strategy_start_date"] = startDate
		queryParam["strategy_end_date"] = endDate

		// 添加比较时间段参数
		queryParam["strategy_compare_start_date"] = compareStartDate
		queryParam["strategy_compare_end_date"] = compareEndDate

		dimMap, err := d.DimensionListDao.GetAllDimensionMap(ctx)
		if err != nil {
			logs.CtxError(ctx, "[GetStrategyListTarget]获取map失败，err=%v+", err)
			return nil, err
		}
		dimColMap, err := d.DimensionListDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
		if err != nil {
			logs.CtxError(ctx, "[GetStrategyListTarget]获取col map失败，err=%v+", err)
			return nil, err
		}

		strategyFilterParam := getFilterParam(ctx, req, strategy.RelationProdPool, dimMap, dimColMap,
			startDate, endDate, compareStartDate, compareEndDate)
		queryParam["strategy_filter"] = strategyFilterParam

		// WARNING:这里使用分析周期&对比周期的时间，进行填充
		currStrategyFilterParam := getFilterParam(ctx, req, strategy.RelationProdPool, dimMap, dimColMap,
			req.BaseReq.StartDate, req.BaseReq.EndDate, req.BaseReq.StartDate, req.BaseReq.EndDate)
		queryParam["curr_strategy_filter"] = currStrategyFilterParam
		compareStrategyFilterParam := getFilterParam(ctx, req, strategy.RelationProdPool, dimMap, dimColMap,
			req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate, req.BaseReq.CompareStartDate, req.BaseReq.CompareEndDate)
		queryParam["compare_strategy_filter"] = compareStrategyFilterParam

		// 处理日期 - 将 longTermStartData 设置为 req.BaseReq.EndDate 的后一天
		endDateItem, err := time.Parse(consts.Fmt_Date, endDate)
		if err != nil {
			logs.CtxError(ctx, "[ProductValueClassify] parse end date failed, err=%v", err)
			return nil, err
		}
		longTermStartData := endDateItem.AddDate(0, 0, 1).Format(consts.Fmt_Date)
		longTermEndData := endDateItem.AddDate(0, 0, 7).Format(consts.Fmt_Date)
		queryParam["long_term_date_expr"] = fmt.Sprintf("date between '%s' and '%s'  and days_type='1d'", longTermStartData, longTermEndData)

	} else {
		return nil, errors.New("strategy is empty")
	}
	dimMap, err := d.DimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[ProductValueClassify] get dimension map failed, err=%v", err)
		return nil, err
	}
	dimColMap, err := d.DimensionListDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[ProductValueClassify] get dimension col map failed, err=%v", err)
		return nil, err
	}

	currItem := make(map[string]interface{})
	compareItem := make(map[string]interface{})

	currItem["is_curr"] = 1
	compareItem["is_curr"] = 0
	currItem["is_long_term"] = 0
	compareItem["is_long_term"] = 0

	reqDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	bizProjectFilterDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	if bizProject != nil {
		bizProjectFilterDimensions = bizProject.FilterDimensions
		bizProjectCurrItem, bizProjectCompareItem := genBizProjectParam(ctx, req, bizProject, productValueClassifyParams.ProdPoolType, prodReviewParams.CompareProdPoolType, dimMap, dimColMap)
		for key, value := range bizProjectCurrItem {
			currItem[key] = value
		}
		for key, value := range bizProjectCompareItem {
			compareItem[key] = value
		}
	} else if strategy != nil {
		strategyCurrItem, strategyCompareItem := genStrategyParam(ctx, req, strategy, productValueClassifyParams.ProdPoolType, prodReviewParams.CompareProdPoolType, dimMap, dimColMap)
		for key, value := range strategyCurrItem {
			currItem[key] = value
		}
		for key, value := range strategyCompareItem {
			compareItem[key] = value
		}
	}

	longCurrItem := make(map[string]interface{})
	longCompareItem := make(map[string]interface{})

	longCurrItem["is_curr"] = 1
	longCompareItem["is_curr"] = 0
	longCurrItem["is_long_term"] = 1
	longCompareItem["is_long_term"] = 1

	if bizProject != nil {
		bizProjectCurrItem, bizProjectCompareItem := genBizProjectParam(ctx, req, bizProject, productValueClassifyParams.ProdPoolType, prodReviewParams.CompareProdPoolType, dimMap, dimColMap)
		for key, value := range bizProjectCurrItem {
			longCurrItem[key] = value
		}
		for key, value := range bizProjectCompareItem {
			longCompareItem[key] = value
		}
	} else if strategy != nil {
		strategyCurrItem, strategyCompareItem := genStrategyParam(ctx, req, strategy, productValueClassifyParams.ProdPoolType, prodReviewParams.CompareProdPoolType, dimMap, dimColMap)
		for key, value := range strategyCurrItem {
			longCurrItem[key] = value
		}
		for key, value := range strategyCompareItem {
			longCompareItem[key] = value
		}
	}

	queryParam["query_items"] = []map[string]interface{}{currItem, compareItem, longCurrItem, longCompareItem}

	if productValueClassifyParams.ProdPoolType == prod_review.ProdPoolType_Current {
		reqDimensions = append(reqDimensions, req.BaseReq.Dimensions...)
		reqDimensions = append(reqDimensions, bizProjectFilterDimensions...) // 添加业务专项
	} else if productValueClassifyParams.ProdPoolType == prod_review.ProdPoolType_Compare {
		reqDimensions = append(reqDimensions, req.CompareReq.Dimensions...)
	}

	currParam, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx,
		base_struct_condition.OsParamsReq{
			BaseStruct: &dimensions.ProductAnalysisBaseStruct{
				BizType:          req.BaseReq.BizType,
				StartDate:        req.BaseReq.StartDate,
				EndDate:          req.BaseReq.EndDate,
				CompareStartDate: req.BaseReq.CompareStartDate,
				CompareEndDate:   req.BaseReq.CompareEndDate,
				Dimensions:       reqDimensions,
			},
			DimMap:    dimMap,
			DimColMap: dimColMap,
		})
	if err != nil {
		logs.CtxError(ctx, "[ProductValueClassify] GetBaseStructConditionParams failed, err=%v", err)
		return nil, err
	}

	currParam["product_value_classify_query_params"] = queryParam

	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: currParam, Sql: consts.Empty, ApiPath: "7559566815534367753", BizType: req.BaseReq.BizType,
		KeyCols: []string{}, FilterTarget: false,
	})
	logs.CtxInfo(ctx, "current target list: %v", currTargetList)

	if err != nil {
		logs.CtxError(ctx, "[ProductValueClassify] GetTargetListWithKeyColumn failed, err=%v", err)
		return nil, err
	}
	resp = &common_response.ItemDataList{
		ItemDataList: make([]*common_response.ItemData, 0),
		ExtraInfo:    &common_response.ItemDataListExtraInfo{},
	}

	// 按照 DisplayOrder 对 TargetEntity 进行排序
	sort.Slice(currTargetList[0].TargetEntity, func(i, j int) bool {
		return currTargetList[0].TargetEntity[i].DisplayOrder < currTargetList[0].TargetEntity[j].DisplayOrder
	})

	itemData := common_response.NewItemData()
	itemData.TargetList = currTargetList[0].TargetEntity
	itemData.ExtraInfo = &common_response.ItemDataExtraInfo{}
	itemData.ExtraInfo.ValueClassifyInfo = &common_response.ValueClassifyInfo{
		QueryParam:   utils.JSONF(queryParam),
		OriginParams: productValueClassifyParams,
	}

	resp.ItemDataList = append(resp.ItemDataList, itemData)

	return resp, nil
}
