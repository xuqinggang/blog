package product_review_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/lark_export"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/times"
	"code.byted.org/gopkg/logs"
	"context"
	"time"
)

const (
	Group          = "指标分组"
	Name           = "指标名称"
	Dim            = "维度"
	Type           = "指标类型"
	CycleNow       = "周期表现-当前周期"
	CycleCompare   = "周期表现-对比周期"
	CycleRate      = "周期表现-增幅"
	MtdNow         = "MTD表现-本月"
	MtdLast        = "MTD表现-上月"
	MtdRate        = "MTD表现-增幅"
	TargetRateNow  = "目标完成度-本月"
	TargetRateLast = "目标完成度-上月"
	TargetNow      = "目标-本月"
	TargetLast     = "目标-上月"
)

func CommonAnalysisTargetTableDownload(ctx context.Context, req *common_request.CommonAnalysisRequest, data []*common_response.TargetData) (bool, error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, err
	}
	if env.IsBoe() {
		email = "wumin.13@bytedance.com"
	}

	endDate, _ := time.Parse(consts.Fmt_Date, req.BaseReq.EndDate)
	month := times.Format(endDate, "2006-01")
	header := [][]string{{"分析周期", req.BaseReq.StartDate + "~" + req.BaseReq.EndDate}, {"对比周期", req.BaseReq.CompareStartDate + "~" + req.BaseReq.CompareEndDate}, {"MTD周期", month}}
	targetList := []string{Group, Name, Type, Dim, CycleNow, CycleCompare, CycleRate, MtdNow, MtdLast, MtdRate, TargetRateNow, TargetRateLast, TargetNow, TargetLast}
	allRows := make([]map[string]interface{}, 0)
	for _, v := range data {
		if v == nil {
			continue
		}
		group := v.Group
		for _, record := range v.Records {
			if record == nil {
				continue
			}
			tp := record.Type
			name := record.Name
			allRows = append(allRows, toKeyMap(group, name, tp, "", record.IndexList))
			for _, dimRecord := range record.ChildrenTarget {
				if dimRecord == nil {
					continue
				}
				dim := dimRecord.Code

				allRows = append(allRows, toKeyMap("", "", "", dim, dimRecord.IndexList))
			}
			// 分组只展示一次
			group = ""
		}
	}

	err = DoExportData(ctx, "零补品-目标明细", email, header, targetList, allRows)
	if err != nil {
		return false, err
	}
	return true, nil
}

func toKeyMap(group, name, tp, dim string, etys []*analysis.TargetCardEntity) map[string]interface{} {
	resp := make(map[string]interface{})
	resp[Group] = group
	resp[Name] = name
	resp[Dim] = dim
	resp[Type] = tp
	// 周期表现
	if len(etys) > 0 {
		resp[CycleNow] = etys[0].Value
		resp[CycleCompare] = "0"
		resp[CycleRate] = "0"
		if etys[0].ComparePeriodData != nil {
			resp[CycleCompare] = etys[0].ComparePeriodData.CompareValue
			if etys[0].ComparePeriodData.CompareChangeRatio != consts.MagicNumber {
				resp[CycleRate] = etys[0].ComparePeriodData.CompareChangeRatio
			}
		}
	}
	// MTD表现
	if len(etys) > 1 {
		resp[MtdNow] = etys[1].Value
		resp[MtdLast] = "0"
		resp[MtdRate] = "0"
		if etys[1].ComparePeriodData != nil {
			resp[MtdLast] = etys[1].ComparePeriodData.CompareValue
			if etys[1].ComparePeriodData.CompareChangeRatio != consts.MagicNumber {
				resp[MtdRate] = etys[1].ComparePeriodData.CompareChangeRatio
			}
		}
	}
	// 目标达成率
	if len(etys) > 2 {
		resp[TargetRateNow] = etys[2].Value
		resp[TargetRateLast] = "0"
		if etys[2].ComparePeriodData != nil {
			resp[TargetRateLast] = etys[2].ComparePeriodData.CompareValue
		}
	}
	// 目标
	if len(etys) > 3 {
		resp[TargetNow] = etys[2].Value
		resp[TargetLast] = "0"
		if etys[2].ComparePeriodData != nil {
			resp[TargetLast] = etys[2].ComparePeriodData.CompareValue
		}
	}
	return resp
}

func DoExportData(ctx context.Context, sheetName, email string, header [][]string, targetList []string, rows []map[string]interface{}) error {
	table := onetable.NewTable(rows)
	formatter := &lark_export.LarkDocFormatterV2{}
	sheet := lark_export.NewLarkDocSheet(sheetName, table)
	sheet.AddHead(header)
	for _, t := range targetList {
		sheet.AddColumn(t, t)
	}
	formatter.AddSheet(sheet)
	ctx = context.WithValue(ctx, consts.CtxExportModuleName, sheetName)
	return formatter.Export(ctx, email, nil, nil)
}
