package product_review_service

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/prod_review_tool"
	"code.byted.org/ecom/smartop_product_analysis/dal/db/model"
	"code.byted.org/ecom/smartop_product_analysis/dal/db/query"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"context"
	"fmt"
	"github.com/jinzhu/copier"
	"sort"
	"time"
)

const (
	DimensionClass    = "10426"
	DimensionCategory = "10427"
)

func (d *ProductReviewService) ICommonAnalysisTargetTable(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisTargetTableResponse) {
	resp = &common_response.CommonAnalysisTargetTableResponse{BaseResp: base.NewBaseResp()}

	cc := co.NewConcurrent(ctx)
	bizId := int32(req.BaseReq.BizType)
	// 查询目标配置信息
	var targetMeta map[string]*model.TargetMeta
	cc.GoV2(func() error {
		var err error
		// 查询目标元信息
		targetMeta, err = GetTargetMeta(ctx, bizId)
		return err
	})

	// 查询周期数据
	var cycleData *common_response.MultiDimTableData
	cc.GoV2(func() error {
		var err error
		cycleData, _, err = d.MultiDimTableService.ICommonAnalysisMultiDimTable(ctx, req)
		return err
	})

	// 查询MTD数据
	var mtdData *common_response.MultiDimTableData
	cc.GoV2(func() error {
		var err error
		mtdData, _, err = d.MultiDimTableService.ICommonAnalysisMultiDimTable(ctx, parseNewReq(req))
		return err
	})

	err := cc.WaitV2()
	if err != nil {
		resp.BaseResp.StatusCode = stcodes.StatusCodeDefaultError.Int()
		resp.BaseResp.StatusMessage = err.Error()
		return
	}

	// 数据转换
	records := trans2TargetDatas(cycleData, mtdData)
	// merge 目标元信息
	data := initTargetMeta(records, targetMeta)
	// sort 数据排序，基于指标展示顺序
	sortData(data)
	// merge 目标配置
	err = initTargetConfig(ctx, data, bizId, req)
	if err != nil {
		resp.BaseResp.StatusCode = stcodes.StatusCodeDefaultError.Int()
		resp.BaseResp.StatusMessage = err.Error()
		return
	}

	resp.Data = data
	return resp
}

func sortData(data []*common_response.TargetData) {
	// 指标排序
	for _, v := range data {
		if v == nil {
			continue
		}
		sort.SliceStable(v.Records, func(i, j int) bool {
			irange := 1000
			if len(v.Records[i].IndexList) > 0 {
				irange = int(v.Records[i].IndexList[0].DisplayOrder)
			}
			jrange := 1000
			if len(v.Records[j].IndexList) > 0 {
				jrange = int(v.Records[j].IndexList[0].DisplayOrder)
			}
			return irange < jrange
		})
	}

	// 分组排序，以排序第一的指标作为分组序号
	sort.SliceStable(data, func(i, j int) bool {
		irange := 1000
		if len(data[i].Records) > 0 && len(data[i].Records[0].IndexList) > 0 && data[i].Group != "其他指标" {
			irange = int(data[i].Records[0].IndexList[0].DisplayOrder)
		}
		jrange := 1000
		if len(data[j].Records) > 0 && len(data[j].Records[0].IndexList) > 0 && data[j].Group != "其他指标" {
			jrange = int(data[j].Records[0].IndexList[0].DisplayOrder)
		}
		return irange < jrange
	})

	// 维度排序
	for _, v := range data {
		if v == nil {
			continue
		}
		for _, vv := range v.Records {
			if vv == nil {
				continue
			}
			sort.SliceStable(vv.ChildrenTarget, func(i, j int) bool {
				irange := 1000.0
				if len(vv.ChildrenTarget[i].IndexList) > 0 && vv.ChildrenTarget[i].IndexList[0] != nil {
					irange = vv.ChildrenTarget[i].IndexList[0].Value
				}
				jrange := 1000.0
				if len(vv.ChildrenTarget[j].IndexList) > 0 && vv.ChildrenTarget[j].IndexList[0] != nil {
					jrange = vv.ChildrenTarget[j].IndexList[0].Value
				}
				return irange > jrange
			})
		}
	}
}

func initTargetConfig(ctx context.Context, data []*common_response.TargetData, bizId int32, req *common_request.CommonAnalysisRequest) error {
	date := req.BaseReq.EndDate
	var dimId string
	if len(req.BaseReq.GroupAttrs) > 0 && req.BaseReq.GroupAttrs[0].DimInfo != nil {
		dimId = req.BaseReq.GroupAttrs[0].DimInfo.Id
	}
	endDate, _ := time.Parse(consts.Fmt_Date, date)
	lastMonthDate := endDate.AddDate(0, -1, 0)

	// 本月/上月目标配置
	wholeMap, classMap, categoryMap, err := prod_review_tool.GetTargetConfig(ctx, bizId, endDate.Unix())
	if err != nil {
		return err
	}
	lastWholeMap, lastClassMap, lastCategoryMap, err := prod_review_tool.GetTargetConfig(ctx, bizId, lastMonthDate.Unix())

	for _, v := range data {
		if v == nil {
			continue
		}
		for _, record := range v.Records {
			if record == nil {
				continue
			}
			target := wholeMap[record.Code]
			lastTarget := lastWholeMap[record.Code]
			if len(record.IndexList) >= 1 {
				record.IndexList = append(record.IndexList, toIndex(record.IndexList[1], target, lastTarget)...)
			}

			// 维度目标，计算达成率
			for _, dimRecord := range record.ChildrenTarget {
				if dimRecord == nil {
					continue
				}

				var dimTarget, dimLastTarget *prod_review_tool.TargetIndex

				if dimId == DimensionClass {
					if len(classMap[record.Code]) > 0 && classMap[record.Code][dimRecord.Code] != nil {
						dimTarget = classMap[record.Code][dimRecord.Code]
					}
				} else if len(categoryMap[record.Code]) > 0 && categoryMap[record.Code][dimRecord.Code] != nil {
					dimTarget = categoryMap[record.Code][dimRecord.Code]
				}
				if dimId == DimensionClass {
					if len(lastClassMap[record.Code]) > 0 && lastClassMap[record.Code][dimRecord.Code] != nil {
						dimLastTarget = lastClassMap[record.Code][dimRecord.Code]
					}
				} else if len(lastCategoryMap[record.Code]) > 0 && lastCategoryMap[record.Code][dimRecord.Code] != nil {
					dimLastTarget = lastCategoryMap[record.Code][dimRecord.Code]
				}
				if len(record.IndexList) >= 1 {
					dimRecord.IndexList = append(dimRecord.IndexList, toIndex(dimRecord.IndexList[1], dimTarget, dimLastTarget)...)
				}
			}
		}
	}
	return nil
}

func toIndex(mtdData *analysis.TargetCardEntity, target *prod_review_tool.TargetIndex, lastTarget *prod_review_tool.TargetIndex) []*analysis.TargetCardEntity {
	if mtdData == nil {
		return nil
	}

	// 本月/上月完成度
	data := analysis.TargetCardEntity{
		ComparePeriodData: &analysis.ComparePeriodData{},
	}
	if target != nil && target.Destination != 0 {
		rate := mtdData.Value / target.Destination
		data.Value = rate
		data.DisplayValue = fmt.Sprintf("%.2f%%", rate*100)
	}
	if lastTarget != nil && lastTarget.Destination != 0 {
		lastRate := mtdData.ComparePeriodData.CompareValue / lastTarget.Destination
		data.ComparePeriodData.CompareValue = lastRate
		data.ComparePeriodData.CompareDisplayValue = fmt.Sprintf("%.2f%%", lastRate*100)
	}

	// 本月/上月目标
	targetData := analysis.TargetCardEntity{
		ComparePeriodData: &analysis.ComparePeriodData{},
	}
	if target != nil {
		targetData.Value = target.Destination
		targetData.DisplayValue = target.DestinationDisplay
	}
	if lastTarget != nil {
		targetData.ComparePeriodData.CompareValue = lastTarget.Destination
		targetData.ComparePeriodData.CompareDisplayValue = lastTarget.DestinationDisplay
	}

	return []*analysis.TargetCardEntity{&data, &targetData}
}

func initTargetMeta(records []*common_response.TargetRowData, meta map[string]*model.TargetMeta) []*common_response.TargetData {
	resp := make([]*common_response.TargetData, 0)
	groupDatas := make(map[string][]*common_response.TargetRowData)
	if meta == nil {
		meta = make(map[string]*model.TargetMeta)
	}
	for _, v := range records {
		if v == nil {
			continue
		}

		recodeMeta := meta[v.Code]

		// 指标分类
		idx := ""
		if recodeMeta != nil && recodeMeta.IdxType != "" {
			idx = recodeMeta.IdxType
		}
		v.Type = idx

		// 分组分组
		group := "其他指标"
		if recodeMeta != nil && recodeMeta.IdxGroup != "" {
			group = recodeMeta.IdxGroup
		}
		groupDatas[group] = append(groupDatas[group], v)
	}

	for k, v := range groupDatas {
		if v == nil {
			continue
		}
		resp = append(resp, &common_response.TargetData{
			Group:   k,
			Records: v,
		})
	}

	return resp
}

func trans2TargetDatas(cycleData *common_response.MultiDimTableData, mtdData *common_response.MultiDimTableData) []*common_response.TargetRowData {
	if cycleData == nil {
		return nil
	}
	// 整体指标
	cycleEntity := parseTotal(cycleData.Total)
	mtdEntity := parseTotal(mtdData.Total)
	// 下钻指标
	cycleDimentionEntity := parseRows(cycleData.Rows)
	mtdDimentionEntity := parseRows(mtdData.Rows)
	// 维度 code -> name 映射关系
	dimMap := parseDimMap(append(cycleData.Rows, mtdData.Rows...))
	// 行列转换
	return parse2Resp(cycleEntity, mtdEntity, cycleDimentionEntity, mtdDimentionEntity, dimMap)
}

func parseDimMap(rows []*common_response.RowData) map[string]string {
	resp := make(map[string]string)
	for _, row := range rows {
		if row == nil {
			continue
		}
		for _, target := range row.TargetList {
			if target == nil {
				continue
			}
			resp[row.DimensionCode] = row.DimensionName
		}
	}
	return resp
}

func parse2Resp(cycleEntity, mtdEntity map[string]*analysis.TargetCardEntity, cycleDimentionEntity, mtdDimentionEntity map[string]map[string]*analysis.TargetCardEntity, dimMap map[string]string) []*common_response.TargetRowData {
	resp := make([]*common_response.TargetRowData, 0)

	for k, cycleValue := range cycleEntity {
		if cycleValue == nil {
			continue
		}

		// cycle数据
		resp = append(resp, &common_response.TargetRowData{
			Code:           cycleValue.Name,
			Name:           cycleValue.DisplayName,
			Type:           "", // 暂时不填
			IndexList:      []*analysis.TargetCardEntity{cycleValue, mtdEntity[k]},
			ChildrenTarget: toChildrenTarget(cycleDimentionEntity[k], mtdDimentionEntity[k], dimMap),
		})
	}
	return resp
}

func toChildrenTarget(cycleDimentionEntitys, mtdDimentionEntitys map[string]*analysis.TargetCardEntity, dimMap map[string]string) []*common_response.TargetRowData {
	resp := make([]*common_response.TargetRowData, 0)
	if mtdDimentionEntitys == nil {
		mtdDimentionEntitys = make(map[string]*analysis.TargetCardEntity)
	}
	for k, value := range cycleDimentionEntitys {
		if value == nil {
			continue
		}

		dimName := k
		if dimMap != nil && dimMap[k] != "" {
			dimName = dimMap[k]
		}

		// cycle数据
		resp = append(resp, &common_response.TargetRowData{
			Code:      k,
			Name:      dimName,
			Type:      "", // 暂时不填
			IndexList: []*analysis.TargetCardEntity{value, mtdDimentionEntitys[k]},
		})
	}
	return resp
}

func parseRows(rows []*common_response.RowData) map[string]map[string]*analysis.TargetCardEntity {
	resp := make(map[string]map[string]*analysis.TargetCardEntity)
	for _, row := range rows {
		if row == nil {
			continue
		}
		for _, target := range row.TargetList {
			if target == nil {
				continue
			}
			if resp[target.Name] == nil {
				resp[target.Name] = make(map[string]*analysis.TargetCardEntity)
			}
			resp[target.Name][row.DimensionCode] = target
		}
	}
	return resp
}

func parseTotal(total *common_response.RowData) map[string]*analysis.TargetCardEntity {
	wholeEntity := make(map[string]*analysis.TargetCardEntity)
	if total == nil {
		return wholeEntity
	}
	for _, v := range total.TargetList {
		if v == nil {
			continue
		}
		wholeEntity[v.Name] = v
	}
	return wholeEntity
}

func parseNewReq(req *common_request.CommonAnalysisRequest) *common_request.CommonAnalysisRequest {
	newReq := &common_request.CommonAnalysisRequest{}
	copier.Copy(&newReq, &req)

	monthDate, _ := GetMonthDates(req.BaseReq.EndDate)
	newReq.BaseReq.StartDate = monthDate.CurrentStart
	newReq.BaseReq.EndDate = monthDate.CurrentEnd
	newReq.BaseReq.CompareStartDate = monthDate.LastStart
	newReq.BaseReq.CompareEndDate = monthDate.LastEnd
	return newReq
}

// MonthDates 用于存储月份的日期范围
type MonthDates struct {
	CurrentStart string // 当月月初
	CurrentEnd   string // 当月月末
	LastStart    string // 上月月初
	LastEnd      string // 上月月末
}

// GetMonthDates 接收"2006-01-02"格式的日期，返回当月和上月的月初和月末日期
func GetMonthDates(dateStr string) (MonthDates, error) {
	// 解析输入日期
	date, err := time.Parse("2006-01-02", dateStr)
	if err != nil {
		return MonthDates{}, fmt.Errorf("日期格式错误，请使用2006-01-02格式: %v", err)
	}

	// 计算当月月初日期（当月第一天）
	currentStart := time.Date(date.Year(), date.Month(), 1, 0, 0, 0, 0, date.Location())

	// 计算当月月末日期（下个月第一天减一天）
	firstDayOfNextMonth := currentStart.AddDate(0, 1, 0)
	currentEnd := firstDayOfNextMonth.AddDate(0, 0, -1)

	// 计算上月月初日期（当月月初减一个月）
	lastStart := currentStart.AddDate(0, -1, 0)

	// 计算上月月末日期（当月月初减一天）
	lastEnd := currentStart.AddDate(0, 0, -1)

	return MonthDates{
		CurrentStart: currentStart.Format("2006-01-02"),
		CurrentEnd:   currentEnd.Format("2006-01-02"),
		LastStart:    lastStart.Format("2006-01-02"),
		LastEnd:      lastEnd.Format("2006-01-02"),
	}, nil
}

// GetTargetMeta 查询目标元信息
func GetTargetMeta(ctx context.Context, bizId int32) (map[string]*model.TargetMeta, error) {
	resp := make(map[string]*model.TargetMeta)
	metas, err := query.TargetMetaDB(ctx).WithContext(ctx).Where(query.TargetMetaDB(ctx).BizID.Eq(bizId)).Find()
	if err != nil {
		return resp, err
	}
	for _, meta := range metas {
		if meta == nil {
			continue
		}
		resp[meta.IdxName] = meta
	}
	return resp, nil
}
