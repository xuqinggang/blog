package product_review_service

import (
	"context"
	"strconv"
	"strings"
	"sync"

	"code.byted.org/ecom/common/utils/async2"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	utilsCurr "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_table_domain/extension/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
	"github.com/jinzhu/copier"
)

// 计算专项和所有策略各自覆盖商品数
func (d *ProductReviewService) IGetStrategyCoverageRatio(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp map[string]string, err error) {
	// 非专项直接返回, 只计算专项下且选择全部商品时
	if req.BizExtraInfo == nil || req.BizExtraInfo.ProdReviewParams == nil || req.BizExtraInfo.ProdReviewParams.BizProjectId == "" ||
		req.BizExtraInfo.ProdReviewParams.FlowDistributionParams.AnalysisObject != prod_review.AnalysisObject_AllProduct {
		return nil, nil
	}

	resp = make(map[string]string)
	analysisStartDate := req.BaseReq.StartDate
	analysisEndDate := req.BaseReq.EndDate

	dependBizType := req.BaseReq.BizType
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if bizMetaInfo != nil && bizMetaInfo.DependBizID != 0 {
		dependBizType = dimensions.BizType(bizMetaInfo.DependBizID)
	}

	// bizIds := make([]int64, 0)
	filterDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	filterDimensions = append(filterDimensions, req.BaseReq.Dimensions...) // 添加分析货盘的筛选条件
	if bizMetaInfo != nil {
		filterDimensions = append(filterDimensions, bizMetaInfo.RequiredDimInfo...) // 业务线依赖的维度加上
		//bizList, err := d.BizListDao.GetBizEffectModuleList(ctx, bizMetaInfo.EffectModule)
		//if err != nil {
		//	logs.CtxError(ctx, "[IGetProductReviewStrategyList] GetBizEffectModuleList err: %v", err)
		//	return nil, err
		//}
		//for _, biz := range bizList {
		//	bizIds = append(bizIds, int64(biz.BizType))
		//}
	}

	// 获取业务线的维度信息
	dimensionListDao := &dao.DimensionListDao{}
	dimMap, err := dimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取map失败，err=%v+", err)
		return nil, err
	}
	dimColMap, err := dimensionListDao.GetDimensionColMap(ctx, dependBizType)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取col map失败，err=%v+", err)
		return nil, err
	}

	bizProjectList, _, err := d.BizProjectDao.GetProductReviewBizProjectList(ctx, &dao.ProductReviewBizProjectQueryParams{
		BizProjectId: convert.ToInt64(req.BizExtraInfo.ProdReviewParams.BizProjectId),
	})
	if err != nil || len(bizProjectList) == 0 {
		logs.CtxError(ctx, "[IGetStrategyCoverageRatio] GetProductReviewBizProjectList err: %v", err)
		return nil, errors.New("GetProductReviewBizProjectList err or ProductReviewBizProject is empty")
	}

	bizProject := bizProjectList[0]

	// 并发处理 strategyList
	var (
		mu sync.Mutex // 保护对 res 的写入
	)

	as := async2.New(ctx)

	// 求专项全部商品数指标
	as.Add(func() {
		{
			selectedDimensionInfos := make([]*dimensions.SelectedDimensionInfo, 0)
			if err := sonic.UnmarshalString(bizProject.FilterDimensions, &selectedDimensionInfos); err != nil {
				logs.CtxError(ctx, "[GetStrategyListTarget]获取策略关联条件失败，err=%v+", err)
				return
			}
			if len(filterDimensions) > 0 {
				selectedDimensionInfos = append(selectedDimensionInfos, filterDimensions...)
			}
			curr, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx,
				base_struct_condition.OsParamsReq{
					BaseStruct: &dimensions.ProductAnalysisBaseStruct{
						BizType:          dependBizType,
						StartDate:        analysisStartDate,
						EndDate:          analysisEndDate,
						CompareStartDate: analysisStartDate,
						CompareEndDate:   analysisEndDate,
						Dimensions:       selectedDimensionInfos,
					},
					DimMap:    dimMap,
					DimColMap: dimColMap,
				})
			if err != nil {
				return
			}
			apiPath, ok := BizApiMap[dependBizType][BizProjectTargetList]
			if !ok {
				logs.CtxError(ctx, "BizProjectTargetList apiPath not found, bizType=%v", dependBizType)
				return
			}
			currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
				Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: dependBizType,
			})
			if err != nil {
				logs.CtxError(ctx, "[GetStrategyListTarget]GetTargetListWithKeyColumn 失败，err=%v+", err)
				return
			}
			mu.Lock()
			defer mu.Unlock()
			targetList := make([]*analysis.TargetCardEntity, 0)
			for _, targetEntity := range currTargetList {
				targetList = append(targetList, targetEntity.TargetEntity...)
			}
			for _, targetItem := range targetList {
				// 记录专项覆盖全部商品数
				if targetItem.Name == "cover_prod_cnt" {
					resp["special_cover_prod_cnt"] = strconv.FormatFloat(targetItem.Value, 'f', 6, 64)
					resp["special_cover_prod_cnt_display_value"] = targetItem.DisplayValue
				}
			}
			return
		}
	})

	// 求全部策略的覆盖商品数指标
	as.Add(func() {
		// 所有单策略过滤参数 放到数组中
		strategyFilterParamArr := make([]string, 0)

		params := make(map[string]interface{})
		strategyFilterParam := make(map[string]interface{})

		bindStrategyIds := strings.Split(bizProject.BindStrategyIds, ",")
		for _, strategyId := range bindStrategyIds {
			strategy, err := d.StrategyDao.GetProductReviewStrategyById(ctx, convert.ToInt64(strategyId))
			if err != nil {
				logs.CtxError(ctx, "GetProductReviewStrategyById err=%v", err)
				continue
			}
			strategyTypeList, err := d.StrategyTypeDao.GetProductReviewStrategyTypeByIdList(ctx, []int64{strategy.StrategyTypeId})
			if err != nil {
				logs.CtxError(ctx, "[getStrategyWithType] GetProductReviewStrategyTypeByIdList err: %v", err)
				continue
			}
			if len(strategyTypeList) == 0 {
				logs.CtxError(ctx, "[getStrategyWithType] strategy type not found, id: %d", strategy.StrategyTypeId)
				continue
			}
			strategyType := strategyTypeList[0]
			// 分析货盘
			currReq := &dimensions.ProductAnalysisBaseStruct{}
			_ = copier.CopyWithOption(currReq, req.BaseReq, copier.Option{DeepCopy: true})
			compareReq := &dimensions.ProductAnalysisBaseStruct{}
			_ = copier.CopyWithOption(compareReq, req.CompareReq, copier.Option{DeepCopy: true})
			// 添加顶部分析货盘的过滤

			strategyCoverParamsCurr, _, err := BuildStrategyCoverParams(ctx, currReq, strategy, strategyType, dimMap, dimColMap, filterDimensions)
			if err != nil {
				logs.CtxError(ctx, "IGetStrategyCoverageRatio BuildStrategyCoverParams err=%v", err)
				return
			}
			strategyFilterParam = strategyCoverParamsCurr
			strategyFilterParam["strategy_id"] = strategy.StrategyId

			// AA策略
			if prod_review.StrategyAnalysisType(strategyType.StrategyAnalysisType) == prod_review.StrategyAnalysisType_AACommonAnalysis {
				// strategyCoverParamsCurr, _, err := BuildStrategyCoverParams(ctx, currReq, strategy, strategyType, dimMap, dimColMap, filterDimensions)
				// if err != nil {
				// 	logs.CtxError(ctx, "IGetStrategyCoverageRatio BuildStrategyCoverParamsNoAB err=%v", err)
				// 	return
				// }
				// strategyFilterParam = strategyCoverParamsCurr
				// strategyFilterParam["strategy_id"] = strategy.StrategyId

				if strategyCoverParamsCurr != nil && strategyCoverParamsCurr["filter_param"] != nil {
					strategyFilterParamArr = append(strategyFilterParamArr, strategyCoverParamsCurr["filter_param"].(string))
				}
			}
			// AB策略
			if prod_review.StrategyAnalysisType(strategyType.StrategyAnalysisType) == prod_review.StrategyAnalysisType_ABExpAnalysis {
				filterSql, err := utilsCurr.BuildABStrategySubSql(ctx, currReq, strategy, true, true, nil, dimMap, dimColMap)
				if err != nil {
					logs.CtxError(ctx, "IGetStrategyCoverageRatio BuildABStrategySubSql err=%v", err)
					return
				}

				if filterSql != "" {
					strategyFilterParamArr = append(strategyFilterParamArr, filterSql)
				}
			}
		}

		if len(strategyFilterParamArr) != 0 {
			// 将所有策略的过滤参数 or 拼接
			strategyFilterParam["filter_param"] = "( " + strings.Join(strategyFilterParamArr, " or ") + " )"
		}

		params["query_items"] = []map[string]interface{}{strategyFilterParam}

		apiPath, ok := BizApiMap[dependBizType][SingleStrategyCoverProd]
		if !ok {
			logs.CtxError(ctx, "GetStrategyListTarget apiPath not  found, bizType=%v", req.BaseReq.BizType)
			return
		}
		currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
			Params: params, Sql: consts.Empty, ApiPath: apiPath, BizType: dependBizType,
		})
		if err != nil {
			logs.CtxError(ctx, "[GetStrategyListTarget]GetTargetListWithKeyColumn 失败，err=%v+", err)
			return
		}
		mu.Lock()
		defer mu.Unlock()
		targetList := make([]*analysis.TargetCardEntity, 0)
		for _, targetEntity := range currTargetList {
			targetList = append(targetList, targetEntity.TargetEntity...)
		}
		for _, targetItem := range targetList {
			// 记录策略覆盖全部商品数
			if targetItem.Name == "cover_prod_cnt" {
				resp["strategy_cover_prod_cnt"] = strconv.FormatFloat(targetItem.Value, 'f', 6, 64)
				resp["strategy_cover_prod_cnt_display_value"] = targetItem.DisplayValue
			}
		}
	})

	as.RunWithRecover() // 忽略错误
	return resp, nil
}

func BuildStrategyCoverParams(
	ctx context.Context,
	req *dimensions.ProductAnalysisBaseStruct,
	strategy *dao.ProductReviewStrategy,
	strategyType *dao.ProductReviewStrategyType,
	dimMap map[int64]*dao.DimensionInfo,
	dimColMap map[string]*dao.DimensionInfo,
	filterDimensions []*dimensions.SelectedDimensionInfo,
) (map[string]interface{}, map[string]interface{}, error) {
	curr := make(map[string]interface{})
	compare := make(map[string]interface{})
	var err error

	selectedDimensionInfos := make([]*dimensions.SelectedDimensionInfo, 0)
	if err := sonic.UnmarshalString(strategy.RelationProdPool, &selectedDimensionInfos); err != nil {
		return nil, nil, err
	}
	selectedDimensionInfos = append(selectedDimensionInfos, filterDimensions...)
	curr, compare, _, _, _, err = base_struct_condition.GetBaseStructConditionParams(ctx,
		base_struct_condition.OsParamsReq{
			BaseStruct: &dimensions.ProductAnalysisBaseStruct{
				BizType:          req.BizType,
				StartDate:        req.StartDate,
				EndDate:          req.EndDate,
				CompareStartDate: req.CompareStartDate,
				CompareEndDate:   req.CompareEndDate,
				Dimensions:       selectedDimensionInfos,
			},
			DimMap:    dimMap,
			DimColMap: dimColMap,
		})
	if err != nil {
		return nil, nil, err
	}

	return curr, compare, nil
}
