package product_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/version_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gslice"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"errors"
	"strconv"
)

func (d *ProductReviewService) IGetLibraInfo(ctx context.Context, req *prod_review.GetLibraInfoRequest) (resp *prod_review.GetLibraInfoResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[IGetLibraInfo] IGetLibraInfo Err:%s", err.Error())
		}
	}()

	if req == nil || req.FlightId == "" {
		return nil, errors.New("[IGetLibraInfo] invalid params")
	}

	fid := convert.ToInt64(req.GetFlightId())
	if fid == 0 {
		return nil, errors.New("[IGetLibraInfo] invalid flight_id")
	}

	versionMap := version_info.GetVersionInfoByFlightId(ctx, fid)

	versions := make([]*prod_review.LibraVersion, 0, len(versionMap))

	for _, v := range versionMap {
		versions = append(versions, &prod_review.LibraVersion{
			Id:                strconv.FormatInt(v.Id, 10),
			Name:              v.Name,
			DisplayName:       v.DisplayName,
			Config:            v.Config,
			VersionType:       prod_review.VersionType(v.VersionType),
			Status:            prod_review.VersionStatus(v.Status),
			UserTag:           v.UserTag,
			FlightId:          strconv.FormatInt(v.FlightId, 10),
			FlightName:        v.FlightName,
			FlightDisplayName: v.FlightDisplayName,
			Owner:             v.Owner,
			FlightStatus:      prod_review.FlightStatus(v.FlightStatus),
			StartTime:         v.StartTime,
			EndTime:           v.EndTime,
			ProductId:         strconv.FormatInt(v.ProductId, 10),
			HashStrategy:      prod_review.HashStrategy(v.HashStrategy),
			CreateTime:        v.CreateTime,
			Description:       v.Description,
			FlightType:        prod_review.FlightType(v.FlightType),
			LayerName:         v.LayerName,
			Token:             v.Token,
			AppId:             strconv.FormatInt(v.AppId, 10),
			Apps: func() []string {
				return gslice.Map(v.Apps, func(appId int64) string {
					return strconv.FormatInt(appId, 10)
				})
			}(),
			AppName:           v.AppName,
			IsUTC:             v.IsUTC,
			Owners:            v.Owners,
			UserList:          v.UserList,
			LayerId:           strconv.FormatInt(v.LayerId, 10),
			LayerDisplayName:  v.LayerDisplayName,
			ConditionalConfig: v.ConditionalConfig,
		})
	}

	return &prod_review.GetLibraInfoResponse{
		Data: &prod_review.LibraInfo{
			LibraVersionInfoList: versions,
		},
	}, nil
}
