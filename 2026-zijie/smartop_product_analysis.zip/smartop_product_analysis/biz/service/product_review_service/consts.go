package product_review_service

const TimeFormat = "2006-01-02 15:04:05"

// Prompt Key
const (
	// 专项-目标分析
	GlobalDiagnosisPromptKey = "product_analysis.prod_review.global_diagnosis"
	// 专项-供给分析
	SupplyDiagnosisPromptKey = "product_analysis.prod_review.supply_diagnosis"
	// 单一策略-人货场洞察
	SingleStrategyMultiDimAnalysisPromptKey = "product_analysis.prod_review.strategy_analysis"
	// 单一策略-供给分析
	SingleStrategySupplyDiagnosisPromptKey = "product_analysis.prod_review.strategy_supply_diagnosis"
)

// Node Key
const (
	diagnosisConclusionTemplateNodeKey = "diagnosis_conclusion_template"
	diagnosisConclusionModelNodeKey    = "diagnosis_conclusion_model"
)
