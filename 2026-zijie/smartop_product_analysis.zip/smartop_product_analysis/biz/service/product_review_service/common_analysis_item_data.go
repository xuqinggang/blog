package product_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/prod_review_tool"
	"context"
	"fmt"
	"strings"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
)

func (d *ProductReviewService) ICommonAnalysisItemData(ctx context.Context, req *common_request.CommonAnalysisRequest) (*common_response.ItemDataList, error) {
	if req == nil || req.BizExtraInfo == nil || req.BizExtraInfo.ProdReviewParams == nil {
		return nil, errors.New("param is nil")
	}
	// 漏斗图
	if req.BizExtraInfo.ProdReviewParams.ModuleName == prod_review.ModuleName_AllowanceFunnel ||
		req.BizExtraInfo.ProdReviewParams.ModuleName == prod_review.ModuleName_RecruitProdFunnel ||
		req.BizExtraInfo.ProdReviewParams.ModuleName == prod_review.ModuleName_SummaryLayer ||
		req.BizExtraInfo.ProdReviewParams.ModuleName == prod_review.ModuleName_SingleStrategy {
		return d.getFunnelChart(ctx, req)
	}
	return nil, nil
}

func (d *ProductReviewService) getFunnelChart(ctx context.Context, req *common_request.CommonAnalysisRequest) (*common_response.ItemDataList, error) {

	dimensionListDao := &dao.DimensionListDao{}
	// 获取业务线的维度信息
	dimMap, err := dimensionListDao.GetAllDimensionMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取map失败，err=%v+", err)
		return nil, err
	}
	dimColMap, err := dimensionListDao.GetDimensionColMap(ctx, req.BaseReq.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget]获取col map失败，err=%v+", err)
		return nil, err
	}
	bizProjectDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	strategyDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	reportDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
	var strategyEntity *prod_review.ProdReviewStrategy
	// 获取个性化报告
	if req.BizExtraInfo.ProdReviewParams.ReportId != "" {
		report := d.GetReportById(ctx, req.BizExtraInfo.ProdReviewParams.ReportId)
		if report != nil {
			reportDimensions = report.FilterDimensions
			if report.EntityType == prod_review.EntityType_BizProject &&
				report.BizProject != nil {
				bizProjectDimensions = report.BizProject.FilterDimensions
			} else if report.EntityType == prod_review.EntityType_Strategy &&
				report.ProdReviewStrategy != nil {
				strategyEntity = report.ProdReviewStrategy
				strategyDimensions = report.ProdReviewStrategy.RelationProdPool
			}
		}
	}
	// 获取业务专项配置
	if req.BizExtraInfo.ProdReviewParams.BizProjectId != "" {
		bizProject := d.GetBizProjectById(ctx, req.BizExtraInfo.ProdReviewParams.BizProjectId)
		if bizProject != nil {
			bizProjectDimensions = bizProject.FilterDimensions
		}
	}
	// 业务专项维度
	// 获取策略配置
	if req.BizExtraInfo.ProdReviewParams.StrategyId != "" {
		strategy := d.GetStrategyById(ctx, req.BizExtraInfo.ProdReviewParams.StrategyId)
		if strategy != nil {
			strategyEntity = strategy
			strategyDimensions = strategy.RelationProdPool
		}
	}
	libraFilter := ""
	if strategyEntity != nil {
		libraFilter = getABStrategyLibraFilter(consts.BizABTableMap[req.BaseReq.BizType], req.BaseReq.StartDate, req.BaseReq.EndDate, strategyEntity)
	}
	// 获取业务目标
	t, _ := time.Parse("2006-01-02", req.BaseReq.EndDate)
	unixTimestamp := t.Unix()
	wholeMap, classMap, categoryMap, _ := prod_review_tool.GetTargetConfig(ctx, int32(req.BaseReq.BizType), unixTimestamp)
	logs.CtxInfo(ctx, "[GetTargetConfig] wholeMap=%v,classMap=%v,categoryMap=%v", wholeMap, classMap, categoryMap)
	// 获取目标
	// 获取漏斗配置

	if req.BaseReq.BizType == dimensions.BizType_ProdReviewMarket &&
		req.BizExtraInfo.ProdReviewParams.FunnelChart == prod_review.FunnelChart_CommonFunnel {
		req.BizExtraInfo.ProdReviewParams.FunnelChart = prod_review.FunnelChart_MarketCommonFunnel
	}
	fConfigs := GetFunnelFloorConfigs(ctx, req.BizExtraInfo.ProdReviewParams.FunnelChart)
	coreTargetName := "gmv"
	if req.BizExtraInfo.ProdReviewParams.FunnelChart == prod_review.FunnelChart_RecruitProdFunnel ||
		req.BizExtraInfo.ProdReviewParams.FunnelChart == prod_review.FunnelChart_CommonFunnel {
		coreTargetName = "show_prod_cnt"
		bizMeta, _, _ := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
		if bizMeta != nil && strings.Contains(bizMeta.EffectModule, "货盘复盘-超值购") {
			coreTargetName = "prod_cnt"
		}
	} else if req.BizExtraInfo.ProdReviewParams.FunnelChart != prod_review.FunnelChart_CoreBizFunnel {
		coreTargetName = "prod_cnt"
	}
	floorFilter := make([]map[string]interface{}, 0)
	curr := make(map[string]interface{}, 0)

	for _, funnel := range fConfigs {
		// 获取目标
		currFloorDimensions := append(funnel.FilterDimensions, req.BaseReq.Dimensions...)
		if len(bizProjectDimensions) > 0 {
			currFloorDimensions = append(currFloorDimensions, bizProjectDimensions...)
		}
		if len(strategyDimensions) > 0 {
			currFloorDimensions = append(currFloorDimensions, strategyDimensions...)
		}
		if len(reportDimensions) > 0 {
			currFloorDimensions = append(currFloorDimensions, reportDimensions...)
		}
		newFloorDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
		isSignupSuccess := -1
		for _, dim := range currFloorDimensions {
			if dim.Id == "10433" && len(dim.SelectedValues) > 0 {
				if dim.SelectedValues[0].Code == "1" {
					isSignupSuccess = 1
				} else if dim.SelectedValues[0].Code == "0" {
					isSignupSuccess = 0
				}
				continue
			}
			if req.BizExtraInfo.ProdReviewParams.FunnelChart == prod_review.FunnelChart_CommonFunnel &&
				req.BaseReq.BizType == dimensions.BizType_ProdReviewGreatValueBuy && dim.Id == "10453" {
				dim.Id = "10438" // 替换为超值购动销
			}
			newFloorDimensions = append(newFloorDimensions, dim)
		}
		logs.CtxInfo(ctx, "%v dimension len=%v,%v,%v,%v", funnel.FloorOrder, len(funnel.FilterDimensions), len(req.BaseReq.Dimensions), len(bizProjectDimensions), len(currFloorDimensions))
		currParam, _, _, _, _, err := base_struct_condition.GetBaseStructConditionParams(ctx,
			base_struct_condition.OsParamsReq{
				BaseStruct: &dimensions.ProductAnalysisBaseStruct{
					BizType:          req.BaseReq.BizType,
					StartDate:        req.BaseReq.StartDate,
					EndDate:          req.BaseReq.EndDate,
					CompareStartDate: req.BaseReq.CompareStartDate,
					CompareEndDate:   req.BaseReq.CompareEndDate,
					Dimensions:       newFloorDimensions,
				},
				DimMap:    dimMap,
				DimColMap: dimColMap,
			})
		if err != nil {
			logs.CtxError(ctx, "[GetStrategyListTarget]get curr param err=%v+", err)
			continue
		}
		floorM := make(map[string]interface{}, 0)
		if libraFilter == "" {
			floorM["filter_param"] = currParam["filter_param"]
		} else {
			if filterParamI, ok := currParam["filter_param"]; ok {
				if filterParamStr, ok1 := filterParamI.(string); ok1 {
					floorM["filter_param"] = fmt.Sprintf("(%s and %s)", filterParamStr, libraFilter)
				}
			}
		}
		floorM["floor_order"] = funnel.FloorOrder
		if isSignupSuccess != -1 {
			floorM["is_signup_success"] = isSignupSuccess
		}
		floorFilter = append(floorFilter, floorM)
		curr = currParam
	}
	curr["funnel_items"] = floorFilter
	apiPath, ok := BizApiMap[req.BaseReq.BizType][BizFunnelChart]
	if !ok {
		logs.CtxError(ctx, "GetStrategyListTarget apiPath not found, bizType=%v", req.BaseReq.BizType)
		return nil, err
	}

	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: apiPath, BizType: req.BaseReq.BizType,
		KeyCols: []string{"floor_order"}, FilterTarget: false,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyListTarget] get targetList err=%v+", err)
		return nil, err
	}
	itemDataList := common_response.NewItemDataList()
	itemDataList.ItemDataList = make([]*common_response.ItemData, 0)
	for _, targetEntity := range currTargetList {
		if len(targetEntity.KeyColValues) > 0 {
			currFunnel := &FunnelFloorConfig{}
			for _, funnel := range fConfigs {
				if convert.ToInt(targetEntity.KeyColValues[0]) == funnel.FloorOrder {
					currFunnel = funnel
					break
				}
			}
			setGoalInfo(currFunnel, req, wholeMap, classMap, categoryMap, targetEntity.TargetEntity, coreTargetName)
			itemDataList.ItemDataList = append(itemDataList.ItemDataList, &common_response.ItemData{
				ItemName:   currFunnel.Name,
				TargetList: targetEntity.TargetEntity,
				ExtraInfo: &common_response.ItemDataExtraInfo{
					FunnelFloor: &prod_review.FunnelFloor{
						DimensionInfos:   currFunnel.FilterDimensions,
						FunnelFloorOrder: int64(currFunnel.FloorOrder),
						CoreTargetName:   coreTargetName,
						Tips:             currFunnel.Tips,
					},
				},
			})
		}
	}
	return itemDataList, nil
}

func setGoalInfo(funnel *FunnelFloorConfig, req *common_request.CommonAnalysisRequest,
	wholeMap map[string]*prod_review_tool.TargetIndex, classMap map[string]map[string]*prod_review_tool.TargetIndex,
	categoryMap map[string]map[string]*prod_review_tool.TargetIndex, targets []*analysis.TargetCardEntity, targetName string) {
	goalTargetName := ""
	if targetName == "prod_cnt" || targetName == "show_prod_cnt" {
		goalTargetName = funnel.ProdCntTargetName
	} else if targetName == "gmv" {
		goalTargetName = funnel.GmvGoalTargetName
	}
	goalTargetValue := float64(0)
	goalTargetDisplayValue := ""
	if req.BizExtraInfo == nil || req.BizExtraInfo.ProdReviewParams == nil {
		return
	}
	if req.BizExtraInfo.ProdReviewParams.GoalInfo == nil || req.BizExtraInfo.ProdReviewParams.GoalInfo.DimensionId == "" { // 整体目标
		if res, ok := wholeMap[goalTargetName]; ok {
			goalTargetValue = res.Destination
			goalTargetDisplayValue = res.DestinationDisplay
		}
	} else if req.BizExtraInfo.ProdReviewParams.GoalInfo.DimensionId == DimensionClass {
		if res, ok := classMap[goalTargetName]; ok {
			if res1, ok1 := res[req.BizExtraInfo.ProdReviewParams.GoalInfo.DimensionCode]; ok1 {
				goalTargetValue = res1.Destination
				goalTargetDisplayValue = res1.DestinationDisplay
			}
		}
	} else if req.BizExtraInfo.ProdReviewParams.GoalInfo.DimensionId == DimensionCategory {
		if res, ok := categoryMap[goalTargetName]; ok {
			if res1, ok1 := res[req.BizExtraInfo.ProdReviewParams.GoalInfo.DimensionCode]; ok1 {
				goalTargetValue = res1.Destination
				goalTargetDisplayValue = res1.DestinationDisplay
			}
		}
	}
	for _, target := range targets {
		if target.Name != targetName {
			continue
		}
		if target.Extra == nil {
			target.Extra = &analysis.TargetCardExtraInfo{}
		}
		target.Extra.TargetGoalDisplayValue = &goalTargetDisplayValue
		if goalTargetValue != 0 {
			completeRatio := target.Value / goalTargetValue
			target.Extra.TargetGoalCompleteRatio = &completeRatio
		}
	}
}
