package product_review_service

import (
	"context"
	"errors"
	"strconv"
	"strings"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"code.byted.org/temai/go_lib/convert"
	"code.byted.org/temai/go_portal_sdk/models"
	"github.com/bytedance/sonic"
)

func (d *ProductReviewService) ICreateAndUpdateProdReviewBizProject(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewBizProjectRequest) (resp *prod_review.CreateAndUpdateProdReviewBizProjectResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewBizProject] ICreateAndUpdateProdReviewBizProject Err:%s", err.Error())
		}
	}()

	if req == nil || req.BizProject == nil {
		return nil, errors.New("[ICreateAndUpdateProdReviewBizProject] invalid params")
	}

	//expConfig, _ := sonic.MarshalString(req.BizProject.ExpConfig)
	filterDimensions, err := sonic.MarshalString(req.BizProject.FilterDimensions)
	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewBizProject] MarshalString filterDimensions err: %v", err)
		return nil, err
	}
	bindStrategyIds := func() []string {
		bindStrategyIdsStr := make([]string, 0)
		for _, bindStrategyId := range req.BizProject.BindStrategyIds {
			bindStrategyIdsStr = append(bindStrategyIdsStr, convert.ToString(bindStrategyId))
		}
		return bindStrategyIdsStr
	}()

	userInfo := utils.GetUserInfo(ctx)
	if userInfo == nil || userInfo.Email == nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewBizProject] userInfo is nil")
		return nil, errors.New("[ICreateAndUpdateProdReviewBizProject] userInfo is nil")
	}

	if convert.ToInt64(req.BizProject.BizProjectId) != 0 {
		// 新增：权限校验
		oldBizProject, _, qErr := d.BizProjectDao.GetProductReviewBizProjectList(ctx, &dao.ProductReviewBizProjectQueryParams{
			BizProjectId: convert.ToInt64(req.BizProject.BizProjectId),
		})
		if qErr != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewBizProject] GetProductReviewBizProjectById err: %v", qErr)
			return nil, qErr
		}
		if len(oldBizProject) == 0 {
			return nil, errors.New("[ICreateAndUpdateProdReviewBizProject] biz_project not found")
		}
		if !checkBizProjectEditPermission(ctx, userInfo, oldBizProject[0]) {
			return nil, errors.New("[ICreateAndUpdateProdReviewBizProject] permission denied: only creator can update")
		}

		err = d.BizProjectDao.UpdateProductReviewBizProject(ctx, convert.ToInt64(req.BizProject.BizProjectId), &dao.ProductReviewBizProject{
			BizProjectName:   req.BizProject.BizProjectName,
			FilterDimensions: filterDimensions,
			BindStrategyIds:  strings.Join(bindStrategyIds, ","),
			// BizId:            int64(req.BizProject.BizType),  不更新业务线
			//AAIncreaseCalType:   int(req.BizProject.AaIncreaseCalType),
			SummaryType:         int(req.BizProject.SummaryType),
			TargetList:          strings.Join(req.BizProject.TargetList, ","),
			DiagnosisTargetList: strings.Join(req.BizProject.DiagnosisTargetList, ","),
			// ExpConfig:           expConfig,
			CreateUser: req.BizProject.CreateUser,
			UpdateUser: gptr.Indirect(userInfo.Email),
			CreateTime: time.Unix(req.BizProject.CreateTime, 0),
			UpdateTime: time.Now(),
			IsDelete:   int(req.BizProject.IsDel),
		})

		if err != nil {
			logs.CtxError(ctx, "[ICreateAndUpdateProdReviewBizProject] UpdateProductReviewBizProject err: %v", err)
			return nil, err
		}

		return &prod_review.CreateAndUpdateProdReviewBizProjectResponse{
			Data: true,
		}, nil

	}

	effectiveTime, _ := time.ParseInLocation(TimeFormat, req.BizProject.EffectiveTime, time.Local)

	err = d.BizProjectDao.CreateProductReviewBizProject(ctx, &dao.ProductReviewBizProject{
		BizProjectName:   req.BizProject.BizProjectName,
		FilterDimensions: filterDimensions,
		BindStrategyIds:  strings.Join(bindStrategyIds, ","),
		BizId:            int64(req.BizProject.BizType),
		//AAIncreaseCalType:   int(req.BizProject.AaIncreaseCalType),
		SummaryType:         int(req.BizProject.SummaryType),
		TargetList:          strings.Join(req.BizProject.TargetList, ","),
		DiagnosisTargetList: strings.Join(req.BizProject.DiagnosisTargetList, ","),
		//ExpConfig:           expConfig,
		CreateUser:    gptr.Indirect(userInfo.Email),
		EffectiveTime: effectiveTime,
		CreateTime:    time.Now(),
		IsDelete:      int(req.BizProject.IsDel),
	})

	if err != nil {
		logs.CtxError(ctx, "[ICreateAndUpdateProdReviewBizProject] CreateProductReviewBizProject err: %v", err)
		return nil, err
	}

	return &prod_review.CreateAndUpdateProdReviewBizProjectResponse{
		Data: true,
	}, nil
}

func (d *ProductReviewService) IGetProductReviewBizProjectList(ctx context.Context, req *prod_review.GetProdReviewBizProjectListRequest, filterDimensions []*dimensions.SelectedDimensionInfo) (resp *prod_review.GetProdReviewBizProjectListResponse, err error) {
	defer func() {
		if err != nil {
			logs.CtxError(ctx, "[IGetProductReviewBizProjectList] IGetProductReviewBizProjectList Err:%s", err.Error())
		}
	}()
	if req == nil {
		return nil, errors.New("[IGetProductReviewBizProjectList] invalid params")
	}

	bizMetaInfo, ctx, _ := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if len(filterDimensions) == 0 {
		filterDimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	bizIds := make([]int64, 0)
	if bizMetaInfo != nil && bizMetaInfo.BizType != 0 {
		filterDimensions = append(filterDimensions, bizMetaInfo.RequiredDimInfo...) // 业务线依赖的维度加上
		bizList, err := d.BizListDao.GetBizEffectModuleList(ctx, bizMetaInfo.EffectModule)
		if err != nil {
			logs.CtxError(ctx, "[IGetProductReviewStrategyList] GetBizEffectModuleList err: %v", err)
			return nil, err
		}
		for _, biz := range bizList {
			bizIds = append(bizIds, int64(biz.BizType))
		}
	}
	bizProjectList, count, err := d.BizProjectDao.GetProductReviewBizProjectList(ctx, &dao.ProductReviewBizProjectQueryParams{
		BizProjectId:   convert.ToInt64(req.BizProjectId),
		BizProjectName: req.BizProjectName,
		BizIds:         bizIds,
		IsDeleted:      0,
		PageNum:        int(req.PageNum),
		PageSize:       int(req.PageSize),
	})

	if err != nil {
		logs.CtxError(ctx, "[IGetProductReviewBizProjectList] IGetProductReviewBizProjectList err: %v", err)
		return nil, err
	}
	// 获取业务专项指标数据
	projectList := TransBizProjectDao(ctx, bizProjectList)
	if req.AnalysisStartDate != "" && req.AnalysisEndDate != "" || req.IsNeedReturnTargets == true {
		bizProjectTargetMap := GetBizProjectListTarget(ctx, req, bizProjectList, filterDimensions)
		for _, bizProject := range projectList {
			bizProjectId, _ := strconv.ParseInt(bizProject.BizProjectId, 10, 64)
			if targetList, ok := bizProjectTargetMap[bizProjectId]; ok {
				bizProject.QueryTargetList = targetList
			}
		}
	}

	// 获取策略相关指标数据
	for _, project := range projectList {
		if len(project.BindStrategyIds) == 0 { // 没有绑定策略，跳过
			continue
		}
		sReq := &prod_review.GetProdReviewStrategyListRequest{
			StrategyIds:         project.BindStrategyIds,
			BizType:             req.BizType,
			AnalysisStartDate:   req.AnalysisStartDate,
			AnalysisEndDate:     req.AnalysisEndDate,
			IsNeedAll:           1,
			IsNeedReturnTargets: req.IsNeedReturnTargets,
		}
		filterDimensions = append(filterDimensions, project.FilterDimensions...)
		sList, err := d.IGetProductReviewStrategyList(ctx, sReq, filterDimensions)
		if err != nil {
			logs.CtxError(ctx, "[IGetProductReviewStrategyList] IGetProductReviewStrategyList err: %v", err)
			return nil, err
		}
		if sList != nil && sList.Data != nil {
			project.StrategyList = sList.Data.StrategyList
		}
	}
	return &prod_review.GetProdReviewBizProjectListResponse{

		Data: &prod_review.GetProdReviewBizProjectListData{
			BizProjectList: projectList,
			TotalCount:     count,
		},
	}, nil
}

func checkBizProjectEditPermission(ctx context.Context, userInfo *models.UserInfo, bizProject *dao.ProductReviewBizProject) bool {
	if bizProject == nil {
		return false
	}
	if userInfo == nil || userInfo.Email == nil {
		logs.CtxError(ctx, "[CheckBizProjectEditPermission] userInfo is nil")
		return false
	}
	return bizProject.CreateUser == gptr.Indirect(userInfo.Email)
}
