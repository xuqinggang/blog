package product_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/gopkg/logs"
	"context"
)

func (d *ProductReviewService) GetStrategyById(ctx context.Context, strategyId string) (strategy *prod_review.ProdReviewStrategy) {
	res, err := d.IGetProductReviewStrategyList(ctx, &prod_review.GetProdReviewStrategyListRequest{
		StrategyIds:        []string{strategyId},
		IsOnlyNeedStrategy: 1,
	}, nil)
	if err != nil {
		logs.CtxError(ctx, "[GetStrategyById] IGetProductReviewStrategyList err: %v", err)
		return
	}
	if res.Data != nil && len(res.Data.StrategyList) > 0 {
		strategy = res.Data.StrategyList[0]
	}
	return
}

func (d *ProductReviewService) GetBizProjectById(ctx context.Context, bizProjectId string) (bizProject *prod_review.BizProject) {
	res, err := d.IGetProductReviewBizProjectList(ctx, &prod_review.GetProdReviewBizProjectListRequest{
		BizProjectId: bizProjectId,
	}, nil)
	if err != nil {
		logs.CtxError(ctx, "[GetBizProjectById] IGetProductReviewBizProjectList err: %v", err)
		return
	}
	if res.Data != nil && len(res.Data.BizProjectList) > 0 {
		bizProject = res.Data.BizProjectList[0]
	}
	return
}

func (d *ProductReviewService) GetReportById(ctx context.Context, reportId string) (report *prod_review.ProdReviewReport) {
	res, err := d.IGetProductReviewReportList(ctx, &prod_review.GetProdReviewReportListRequest{
		ReportId: reportId,
	})
	if err != nil {
		logs.CtxError(ctx, "[ProductFourQuadrantAnalysis] IGetProductReviewReportList err: %v", err)
		return
	}
	if res.Data != nil && len(res.Data.ReportList) > 0 {
		report = res.Data.ReportList[0]
	}
	return
}
