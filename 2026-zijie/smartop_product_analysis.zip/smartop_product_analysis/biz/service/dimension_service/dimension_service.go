package dimension_service

import (
	"context"
	"fmt"
	"reflect"
	"sort"
	"strings"
	"sync"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/sophon_sdk"
	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"

	"code.byted.org/ecom/smartop_product_analysis/dal/db/model"
	"code.byted.org/gopkg/env"
	"code.byted.org/temai/go_portal_sdk/models"
	"github.com/gogo/protobuf/proto"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/dynamic_enum"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_marketing_promotion_growth_data_platform/kitex_gen/ecom/marketing/promotion_growth_data_platform"
	"code.byted.org/overpass/ecom_marketing_promotion_growth_data_platform/rpc/ecom_marketing_promotion_growth_data_platform"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
	"github.com/valyala/fasttemplate"
)

type IDimensionService interface {
	GetDimensionList(ctx context.Context, bizType dimensions.BizType) ([]*dimensions.DimensionInfo, error)
	GenerateDimensionWithNlp(ctx context.Context, req *dimensions.GenerateDimensionWithNlpRequest) (*dimensions.GenerateDimensionWithNlpData, error)
	GetReadyTime(ctx context.Context, req dimensions.BizType) (resp *dimensions.DataReadyTime, err error)
	GetDimensionByID(ctx context.Context, dimID int64) (*dimensions.DimensionInfo, error)
	GetDimensionPageEnumList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) (*dimensions.GetDimensionPageEnumInfo, error)
	GetDimensionMapByIDList(ctx context.Context, dimIDList []int64) (map[string]*dimensions.DimensionInfo, error)
	GetPriceHybridTagEnumList(ctx context.Context, bizType dimensions.BizType) ([]*dimensions.DimSimpleElement, error)
	GetDimColumnExpressStr(ctx context.Context, dimID int64) (string, error)
	GetProductAnalysisBizList(ctx context.Context, effectModule string) (*dimensions.GetProductAnalysisBizData, error)
	GetProductAnalysisTargetMetaList(ctx context.Context, bizType dimensions.BizType, onlyDefault bool) (resp []*dimensions.TargetMetaInfo, err error)
	GetDimEnumInfoByDimInfoList(ctx context.Context, dimList []*dao.DimensionInfo, bizType *dimensions.BizType) ([]*dimensions.DimensionInfo, error)
	GetAttributionTreeBizList(ctx context.Context, effectModule string) (*dimensions.GetProductAnalysisBizData, error)
	BatchGetDimensionByShowNameList(ctx context.Context, bizType dimensions.BizType, showNameList []string, searchMap map[string][]string) ([]*dimensions.DimensionInfo, error)
	RegisterNeedDumpDimension(ctx context.Context, req *dimensions.RegisterNeedDumpDimensionRequest) (resp bool, err error)
}

type DimensionService struct {
	DimensionListDao    dao.IDimensionListDao
	DimensionEnumDao    dao.IDimensionEnumDao
	AttributeDao        dao.IAttributeDao
	DimensionBizListDao dao.IDimensionBizListDao
}

// GetDimensionByName 获取维度
func (d *DimensionService) BatchGetDimensionByShowNameList(ctx context.Context, bizType dimensions.BizType, showNameList []string, searchMap map[string][]string) ([]*dimensions.DimensionInfo, error) {
	dimList, err := d.DimensionListDao.BatchGetDimensionByShowNameList(ctx, bizType, showNameList)
	if err != nil {
		return nil, err
	}

	dimensionList := make([]*dimensions.DimensionInfo, 0)
	var mu sync.Mutex
	// 问题原因是在并发执行的闭包中使用了循环变量 dimInfo，由于闭包是引用捕获，
	// 当协程执行时，循环可能已经结束，所有协程访问的 dimInfo 可能是最后一个元素。
	// 解决方法是在每次循环时创建一个新的变量，将当前的 dimInfo 复制给它。
	cc := co.NewConcurrent(ctx)
	for _, dimInfo := range dimList {
		// 复制当前的 dimInfo 到一个新的局部变量，避免闭包引用问题
		info := dimInfo
		cc.GoV2(func() error {
			dimID := info.ID
			dimEnumMap := make(map[int64][]*dimensions.EnumElement)
			switch dimensions.EnumType(info.EnumType) {
			case dimensions.EnumType_StaticEnum:
				dimEnumMap, err = d.DimensionEnumDao.GetEnumByDimIds(ctx, dimID)
				if err != nil {
					return err
				}
			case dimensions.EnumType_DynamicEnum:
				if len(info.DynamicFuncName) > 0 {
					if slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, info.DynamicFuncName) {
						pageEnumReq := &dimensions.GetDimensionPageEnumListRequest{
							DimensionId: convert.ToString(dimID),
						}
						if searchMap != nil {
							pageEnumReq.SearchEnumNameList = searchMap[info.ShowName]
						}

						pageEnum, _err := d.GetDimensionPageEnumList(ctx, pageEnumReq)
						if _err != nil {
							return _err
						}
						dimEnumMap[info.ID] = pageEnum.EnumList
					} else {
						enums, _err := dynamic_enum.GetEnumByMethod(ctx, info.DynamicFuncName)
						if _err != nil {
							return _err
						}
						if len(enums) > 0 {
							dimEnumMap[info.ID] = enums
						}
					}
				}
			default:
				return nil
			}

			// 线程安全问题：多个协程同时修改 dimensionList 会导致数据竞争
			// 这里使用一个互斥锁来保证线程安全
			mu.Lock()
			defer mu.Unlock()
			dimensionList = append(dimensionList, &dimensions.DimensionInfo{
				Id:                convert.ToString(info.ID),
				ShowName:          info.ShowName,
				ShowType:          info.ShowType,
				DimensionCategory: dimensions.DimensionAttributeType(info.DimensionCategory),
				EnumType:          dimensions.EnumType(info.EnumType),
				Values:            dimEnumMap[info.ID],
				IsMultiDim:        info.IsMultiDim == 1,
				IsDefaultShow:     info.IsDefaultShow == 1,
				NeedPageSearch:    slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, info.DynamicFuncName),
			})

			return nil
		})
	}

	err = cc.WaitV2()
	if err != nil {
		return nil, err
	}

	return dimensionList, nil
}

// GetDimensionByID 获取维度
func (d *DimensionService) GetDimensionByID(ctx context.Context, dimID int64) (*dimensions.DimensionInfo, error) {
	dimInfo, err := d.DimensionListDao.GetDimensionById(ctx, dimID)
	if err != nil || dimInfo == nil {
		return nil, err
	}

	dimEnumMap := make(map[int64][]*dimensions.EnumElement)
	switch dimensions.EnumType(dimInfo.EnumType) {
	case dimensions.EnumType_StaticEnum:
		dimEnumMap, err = d.DimensionEnumDao.GetEnumByDimIds(ctx, dimID)
		if err != nil {
			return nil, err
		}
	case dimensions.EnumType_DynamicEnum:
		if len(dimInfo.DynamicFuncName) > 0 {
			if slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, dimInfo.DynamicFuncName) {
				pageEnum, err := d.GetDimensionPageEnumList(ctx, &dimensions.GetDimensionPageEnumListRequest{
					DimensionId: convert.ToString(dimID),
					PageInfo: &base.PageInfo{
						PageNum:  1,
						PageSize: 20,
					},
				})
				if err != nil {
					return nil, err
				}
				if pageEnum != nil && len(pageEnum.EnumList) > 0 {
					dimEnumMap[dimInfo.ID] = pageEnum.EnumList
				}
			} else {
				enums, err := dynamic_enum.GetEnumByMethod(ctx, dimInfo.DynamicFuncName)
				if err != nil {
					return nil, err
				}
				if len(enums) > 0 {
					dimEnumMap[dimInfo.ID] = enums
				}
			}
		}
	}

	return &dimensions.DimensionInfo{
		Id:                convert.ToString(dimInfo.ID),
		ShowName:          dimInfo.ShowName,
		ShowType:          dimInfo.ShowType,
		DimensionCategory: dimensions.DimensionAttributeType(dimInfo.DimensionCategory),
		EnumType:          dimensions.EnumType(dimInfo.EnumType),
		Values:            dimEnumMap[dimInfo.ID],
		IsMultiDim:        dimInfo.IsMultiDim == 1,
		IsDefaultShow:     dimInfo.IsDefaultShow == 1,
		NeedPageSearch:    slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, dimInfo.DynamicFuncName),
	}, nil
}

func (d *DimensionService) GetDimensionMapByIDList(ctx context.Context, dimIDList []int64) (map[string]*dimensions.DimensionInfo, error) {
	dimInfoList, err := d.DimensionListDao.BatchGetDimensionByIdList(ctx, dimIDList)
	if err != nil {
		return nil, err
	}
	ret, err := d.GetDimEnumInfoByDimInfoList(ctx, dimInfoList, nil)
	if err != nil {
		return nil, err
	}
	var dimMap = make(map[string]*dimensions.DimensionInfo)
	for _, info := range ret {
		dimMap[info.Id] = info
	}
	return dimMap, nil
}

// GetDimensionList 获取维度列表清单
func (d *DimensionService) GetDimensionList(ctx context.Context, bizType dimensions.BizType) ([]*dimensions.DimensionInfo, error) {
	bizInfo, _, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, bizType = %s", convert.ToJSONString(bizType))
		return nil, err
	}
	bizType = biz_utils.GetAnalysisBizType(bizType, bizInfo.DependBizID)
	dimList, err := d.DimensionListDao.GetDimensionList(ctx, bizType)
	if err != nil {
		return nil, err
	}
	ret, err := d.GetDimEnumInfoByDimInfoList(ctx, dimList, &bizType)
	if err != nil {
		return nil, err
	}
	return ret, nil
}

func (d *DimensionService) GetDimEnumInfoByDimInfoList(ctx context.Context, dimList []*dao.DimensionInfo, bizType *dimensions.BizType) ([]*dimensions.DimensionInfo, error) {
	// 获取业务线信息
	bizRequiredDimMap := make(map[int64][]string)
	bizRequiredEditableMap := make(map[int64]int32)
	if bizType != nil {
		bizInfo, _, err := biz_utils.GetBizMetaInfo(ctx, *bizType)
		if err != nil || bizInfo == nil {
			logs.CtxWarn(ctx, "业务线未发现元信息, bizType = %s", convert.ToJSONString(bizType))
			return nil, err
		}
		if len(bizInfo.RequiredDimInfo) > 0 {
			for _, rD := range bizInfo.RequiredDimInfo {
				vals := make([]string, 0)
				if len(rD.SelectedValues) > 0 {
					for _, v := range rD.SelectedValues {
						vals = append(vals, v.Code)
					}
				}
				bizRequiredDimMap[convert.ToInt64(rD.Id)] = vals
				bizRequiredEditableMap[convert.ToInt64(rD.Id)] = rD.Editable
			}
		}
	}

	// 存储属于静态枚举的维度ID列表
	dimStaticIds := make([]int64, 0)
	// 存储属于动态枚举，需要2次查询接口数据的维度清单
	dimDynamicList := make([]*dao.DimensionInfo, 0)
	// 遍历
	for _, dim := range dimList {
		switch dimensions.EnumType(dim.EnumType) {
		case dimensions.EnumType_StaticEnum:
			dimStaticIds = append(dimStaticIds, dim.ID)
		case dimensions.EnumType_DynamicEnum:
			if !slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, dim.DynamicFuncName) {
				dimDynamicList = append(dimDynamicList, dim)
			}
		default:
			continue
		}
	}

	// 存储每个维度-枚举映射关系
	dimEnumMap := make(map[int64][]*dimensions.EnumElement)

	// 计算静态枚举
	if len(dimStaticIds) > 0 {
		dimStaticEnumMap, err := d.DimensionEnumDao.GetEnumByDimIds(ctx, dimStaticIds...)
		if err != nil {
			return nil, err
		}
		for k, v := range dimStaticEnumMap {
			dimEnumMap[k] = GetDimEnumsByBizFilter(v, bizRequiredDimMap[k])
		}
	}

	// 计算动态枚举
	if len(dimDynamicList) > 0 {
		for _, dim := range dimDynamicList {
			if len(dim.DynamicFuncName) == 0 {
				logs.CtxWarn(ctx, "该维度动态枚举未封装方法，dim=%s", convert.ToJSONString(dim))
				continue
			}
			enums, err := dynamic_enum.GetEnumByMethod(ctx, dim.DynamicFuncName)
			if err != nil {
				return nil, err
			}
			dimEnumMap[dim.ID] = enums
			// 维度允许编辑，则需全量返回枚举
			if len(enums) > 0 && bizRequiredEditableMap[dim.ID] != 1 {
				dimEnumMap[dim.ID] = GetDimEnumsByBizFilter(enums, bizRequiredDimMap[dim.ID])
			}
		}
	}

	// 封装结构体
	ret := make([]*dimensions.DimensionInfo, 0)
	for _, dim := range dimList {
		tmp := &dimensions.DimensionInfo{
			Id:                convert.ToString(dim.ID),
			ShowName:          dim.ShowName,
			ShowType:          dim.ShowType,
			DimensionCategory: dimensions.DimensionAttributeType(dim.DimensionCategory),
			EnumType:          dimensions.EnumType(dim.EnumType),
			Values:            dimEnumMap[dim.ID],
			IsMultiDim:        dim.IsMultiDim == 1,
			IsDefaultShow:     dim.IsDefaultShow == 1,
			NeedPageSearch:    slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, dim.DynamicFuncName),
		}
		dimGroups := make([]dimensions.DimGroup, 0)
		for _, g := range strings.Split(dim.DimGroups, ",") {
			dimGroups = append(dimGroups, dimensions.DimGroup(convert.ToInt64(g)))
		}
		tmp.DimGroups = dimGroups
		dimGroupArr := strings.Split(dim.DimGroupInfo, "#")
		tmp.DimensionGroup = dimGroupArr[0]
		if len(dimGroupArr) > 1 {
			tmp.DimensionGroupOrder = convert.ToInt64(dimGroupArr[1])
		}
		if len(dimGroupArr) > 2 {
			tmp.DimensionGroupDimOrder = convert.ToInt64(dimGroupArr[2])
		} else {
			tmp.DimensionGroupDimOrder = dim.ID
		}

		if rejectEnumMap, exist := consts.StaticRejectDims[tmp.Id]; exist && len(rejectEnumMap) > 0 {
			tmp.RejectDimIds = make([]string, 0)
			for _, enum := range tmp.Values {
				if info, enumExist := rejectEnumMap[enum.Code]; enumExist {
					for _, t := range info.TargetDim {
						tmp.RejectDimIds = append(tmp.RejectDimIds, t.Id)
					}
					enum.DependCode = info.TargetDim
				}
			}
			tmp.RejectDimIds = slices.DistinctString(tmp.RejectDimIds)
		}
		if rejects, exist := consts.DynamicRejectDims[tmp.Id]; exist {
			tmp.RejectDimIds = rejects
		}
		ret = append(ret, tmp)
	}
	return ret, nil
}

func (d *DimensionService) GetDimensionPageEnumList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) (resp *dimensions.GetDimensionPageEnumInfo, err error) {
	if req.PageInfo == nil || req.PageInfo.PageNum == 0 || req.PageInfo.PageSize == 0 {
		pageSize := 20
		if len(req.EnumCodeList) > 0 {
			pageSize = len(req.EnumCodeList)
		}
		if len(req.SearchEnumNameList) > 0 {
			pageSize = len(req.SearchEnumNameList)
		}
		req.PageInfo = &base.PageInfo{
			PageNum:  1,
			PageSize: int32(pageSize),
		}
	}
	resp = &dimensions.GetDimensionPageEnumInfo{
		PageInfo: &base.PageResp{
			PageNum:  req.PageInfo.PageNum,
			PageSize: req.PageInfo.PageSize,
		},
	}
	dimInfo, err := d.DimensionListDao.GetDimensionById(ctx, convert.ToInt64(req.DimensionId))
	if err != nil {
		return nil, err
	}
	if dimInfo == nil {
		return
	}

	if !slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, dimInfo.DynamicFuncName) {

		// 仅支持在传入查询code时实现
		if len(req.EnumCodeList) > 0 {
			dimEnumsInfo, err := d.GetDimensionByID(ctx, convert.ToInt64(req.DimensionId))
			if err != nil {
				return nil, err
			}

			if len(dimEnumsInfo.Values) > 0 {
				resp.EnumList = make([]*dimensions.EnumElement, 0)
				for _, v := range dimEnumsInfo.Values {
					if slices.ContainsString(req.EnumCodeList, v.Code) {
						resp.EnumList = append(resp.EnumList, v)
					}
				}
				return resp, nil
			}
		}

		logs.CtxWarn(ctx, "不包含在需要分页查询的维度内，dimInfo=%s，req=%s", convert.ToJSONString(dimInfo), convert.ToJSONString(req))
		return nil, errors.New("不包含在需要分页查询的维度内")
	}

	dynamicEnum := &dynamic_enum.DynamicEnum{}
	if method, hasMethod := reflect.TypeOf(dynamicEnum).MethodByName(dimInfo.DynamicFuncName); hasMethod &&
		method.Type.NumOut() == 3 && method.Type.NumIn() == 3 {
		methodParams := []reflect.Value{reflect.ValueOf(dynamicEnum), reflect.ValueOf(ctx), reflect.ValueOf(req)}
		methodCallResp := method.Func.Call(methodParams)

		if err, errOk := methodCallResp[2].Interface().(error); errOk && err != nil {
			logs.CtxError(ctx, "interface to error Fail, err=%v+", err)
			return nil, err
		}

		if enums, ok := methodCallResp[0].Interface().([]*dimensions.EnumElement); ok && len(enums) > 0 {
			resp.EnumList = enums
		}

		if total, ok := methodCallResp[1].Interface().(int64); ok {
			resp.PageInfo.Total = total
		}
	} else {
		logs.CtxWarn(ctx, "[GetDimensionPageEnumList]DynamicEnum DynamicFuncName Fail, name=%s", dimInfo.DynamicFuncName)
	}
	return
}

// GenerateDimensionWithNlp NLP 智能填充
func (d *DimensionService) GenerateDimensionWithNlp(ctx context.Context, req *dimensions.GenerateDimensionWithNlpRequest) (*dimensions.GenerateDimensionWithNlpData, error) {
	promptMsg, err := biz_info.GetFilterPromptMsg(ctx)
	if err != nil {
		return nil, err
	}

	// 获取指标
	attrList, err := d.AttributeDao.GetTargetMetaInfo(ctx, int64(req.BizType), nil)
	if err != nil {
		return nil, err
	}

	// 获取维度
	dimList, err := d.GetDimensionList(ctx, req.BizType)
	if err != nil {
		return nil, err
	}

	metaInfoMsg := make([]string, 0)
	attrMap := make(map[string]*dao.TargetMetaInfo)
	for _, a := range attrList {
		attrMap[a.DisplayName] = a
		metaInfoMsg = append(metaInfoMsg, fmt.Sprintf("%s: 是指标", a.DisplayName))
	}
	dimMap := make(map[string]*dimensions.DimensionInfo)
	dimEnumMap := make(map[string]map[string]*dimensions.EnumElement)
	for _, dim := range dimList {
		dimMap[dim.ShowName] = dim
		if len(dim.Values) == 0 {
			metaInfoMsg = append(metaInfoMsg, fmt.Sprintf("%s: 是维度", dim.ShowName))
			continue
		}
		enumName := make([]string, 0)
		enumMap := make(map[string]*dimensions.EnumElement)
		for _, e := range dim.Values {
			enumName = append(enumName, e.Name)
			enumMap[e.Name] = e
		}
		dimEnumMap[dim.ShowName] = enumMap
		metaInfoMsg = append(metaInfoMsg, fmt.Sprintf("%s: 是维度, 它的枚举值是: %s", dim.ShowName, strings.Join(enumName, "、")))
	}

	content := fmt.Sprintf(promptMsg, strings.Join(metaInfoMsg, "   \n"), req.Text)
	retContent, err := sophon_sdk.ChatContentCompletion(ctx, content)
	if err != nil {
		logs.CtxError(ctx, "[GenerateDimensionWithNlp]ChatContentCompletion Err: %v+", err)
		return nil, err
	}

	ret := &dimensions.GenerateDimensionWithNlpData{}
	ret.BaseStruct = &dimensions.ProductAnalysisBaseStruct{
		BizType:        req.BizType,
		Dimensions:     make([]*dimensions.SelectedDimensionInfo, 0),
		ThresholdAttrs: make([]*dimensions.ThresholdAttr, 0),
	}

	var thresholdType dimensions.ThresholdType
	warnTargetList := make([]string, 0)
	warnDimList := make([]string, 0)
	retDimMap := make(map[string]*dimensions.SelectedDimensionInfo)
	var hasRecognition bool
	for _, c := range strings.Split(retContent, "\n") {
		c = strings.TrimSpace(c)
		if strings.HasPrefix(c, "指标的意图") {
			if strings.Contains(c, "具体阈值") {
				thresholdType = dimensions.ThresholdType_ACC_THRESHOLD
			}
			if strings.Contains(strings.ToUpper(c), "TOPN") {
				thresholdType = dimensions.ThresholdType_TOP_THRESHOLD
			}
			if strings.Contains(c, "累计贡献") {
				thresholdType = dimensions.ThresholdType_CONTRIBUTION_THRESHOLD
			}
		}
		if strings.HasPrefix(c, "指标意图的关系") {
			if strings.Contains(c, "且") {
				ret.BaseStruct.ThresholdExpr = base.LogicalExprTypePtr(base.LogicalExprType_AND)
			}
			if strings.Contains(c, "或") {
				ret.BaseStruct.ThresholdExpr = base.LogicalExprTypePtr(base.LogicalExprType_OR)
			}
		}
		if strings.HasPrefix(c, "指标意图公式") {
			c = strings.ReplaceAll(strings.ReplaceAll(strings.ReplaceAll(c, "指标意图公式", ""), ":", ""), "：", "")
			for _, tmp := range strings.Split(c, "###") {
				tmpArr := strings.Split(tmp, "-")
				if len(tmpArr) == 3 {
					targetName := strings.TrimSpace(tmpArr[0])
					operatorStr := strings.TrimSpace(tmpArr[1])
					threshold := strings.TrimSpace(tmpArr[2])
					if targetInfo, exist := attrMap[targetName]; exist {
						switch thresholdType {
						case dimensions.ThresholdType_ACC_THRESHOLD:
							var operator base.OperatorType
							if strings.Contains(operatorStr, "大于") {
								operator = base.OperatorType_GREATER_THAN
							} else if strings.Contains(operatorStr, "小于") {
								operator = base.OperatorType_LESS_THAN
							} else if strings.Contains(operatorStr, "大于等于") {
								operator = base.OperatorType_GREATER_EQUAL_THAN
							} else if strings.Contains(operatorStr, "小于等于") {
								operator = base.OperatorType_LESS_EQUAL_THAN
							} else {
								continue
							}
							hasRecognition = true
							ret.BaseStruct.ThresholdAttrs = append(ret.BaseStruct.ThresholdAttrs, &dimensions.ThresholdAttr{
								Type: thresholdType,
								Key:  targetInfo.Name,
								AccThreshold: &dimensions.AccThreshold{
									Operator:  operator,
									Threshold: convert.ToFloat64(threshold),
								},
							})
						case dimensions.ThresholdType_TOP_THRESHOLD, dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
							hasRecognition = true
							ret.BaseStruct.ThresholdAttrs = append(ret.BaseStruct.ThresholdAttrs, &dimensions.ThresholdAttr{
								Type: thresholdType,
								Key:  targetInfo.Name,
								TopN: convert.ToInt64Ptr(convert.ToInt64(threshold)),
							})
						default:
							continue
						}
					} else {
						warnTargetList = append(warnTargetList, targetName)
					}
				}
			}
		}
		if strings.HasPrefix(c, "维度枚举值") {
			c = strings.ReplaceAll(strings.ReplaceAll(c, "维度枚举值：", ""), "维度枚举值:", "")
			for _, tmp := range strings.Split(c, "###") {
				tmpArr := strings.Split(tmp, "-")
				if len(tmpArr) != 2 {
					continue
				}

				dimName := strings.TrimSpace(tmpArr[0])
				if dimInfo, exist := dimMap[dimName]; exist {
					tmpDimInfo, existTmp := retDimMap[dimName]
					if !existTmp {
						tmpDimInfo = &dimensions.SelectedDimensionInfo{
							Id:               dimInfo.Id,
							Name:             dimInfo.ShowName,
							AttrType:         dimInfo.DimensionCategory,
							SelectedOperator: base.OperatorType_IN,
						}
					}
					enumName := strings.TrimSpace(tmpArr[1])
					if enumInfo, existEnum := dimEnumMap[dimName][enumName]; existEnum {
						if len(tmpDimInfo.SelectedValues) == 0 {
							tmpDimInfo.SelectedValues = make([]*dimensions.EnumElement, 0)
						}
						tmpDimInfo.SelectedValues = append(tmpDimInfo.SelectedValues, &dimensions.EnumElement{
							Code: enumInfo.Code,
							Name: enumInfo.Name,
						})
					}

					hasRecognition = true
					retDimMap[dimName] = tmpDimInfo
				} else {
					warnDimList = append(warnDimList, dimName)
				}
			}
		}

		if strings.HasPrefix(c, "未找到的指标") {
			c = strings.ReplaceAll(strings.ReplaceAll(c, "未找到的指标：", ""), "未找到的指标:", "")
			for _, tmp := range strings.Split(c, "###") {
				if strings.TrimSpace(tmp) != "无" {
					warnTargetList = append(warnTargetList, strings.TrimSpace(tmp))
				}
			}
		}
		if strings.HasPrefix(c, "未找到的维度") {
			c = strings.ReplaceAll(strings.ReplaceAll(c, "未找到的维度：", ""), "未找到的维度:", "")
			for _, tmp := range strings.Split(c, "###") {
				if strings.TrimSpace(tmp) != "无" {
					warnDimList = append(warnDimList, strings.TrimSpace(tmp))
				}
			}
		}
	}

	if len(retDimMap) > 0 {
		for _, info := range retDimMap {
			ret.BaseStruct.Dimensions = append(ret.BaseStruct.Dimensions, info)
		}
	}

	if len(warnTargetList) > 0 || len(warnDimList) > 0 {
		ret.WarnCode = 1
		warnMsgList := make([]string, 0)
		warnMsgList = append(warnMsgList, "您输入的以下维度/指标暂不支持筛选，敬请期待～ \n")
		if len(warnDimList) > 0 {
			warnMsgList = append(warnMsgList, fmt.Sprintf("维度（枚举值）：%s ", strings.Join(warnDimList, "、")))
		}
		if len(warnTargetList) > 0 {
			warnMsgList = append(warnMsgList, fmt.Sprintf("指标：%s ", strings.Join(warnTargetList, "、")))
		}
		if hasRecognition {
			warnMsgList = append(warnMsgList, "\n其他维度和指标解析已完成，见筛选区。")
		}

		ret.WarnMsg = strings.Join(warnMsgList, "\n")
	}

	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "获取email失败，err=%v+", err)
	}
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, errors.New("获取数据库的事务失败")
	}
	dao.AddNlpMetricsPoint(ctx, tx, req.BizType, email, req.Text, retContent, ret.WarnMsg)
	tx.Commit()
	return ret, nil
}

// GetReadyTime 底表就绪时间
func (d *DimensionService) GetReadyTime(ctx context.Context, req dimensions.BizType) (resp *dimensions.DataReadyTime, err error) {
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}
	// 映射为真实的bizType
	req = biz_utils.GetAnalysisBizType(req, bizInfo.DependBizID)
	var logicTableIdList []string
	// 拿到biz_type对应的逻辑表
	if _, ok := consts.LogicTableIdMap[req]; ok {
		logicTableIdList = consts.LogicTableIdMap[req]
	} else {
		return nil, errors.New("未找到该bizType对应的逻辑表列表")
	}
	if bizInfo.EffectModule == "大促视图" {
		tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
		if err != nil {
			logs.CtxError(ctx, "获取大促视图逻辑表配置失败, err=%v", err)
			return nil, err
		}
		logicTableIdList = tableConf.LogicTableList
	}
	oldest, newest, err := utils.GetOldestAndNewestDate(ctx, logicTableIdList, convert.ToInt(bizInfo.MaxRangeDay))
	if bizInfo.EffectModule == "大促视图" {
		newestTime, _ := time.Parse(consts.FmtDateSlash, newest)
		oldest = newestTime.AddDate(0, 0, -convert.ToInt(bizInfo.MaxRangeDay)+1).Format(consts.FmtDateSlash)
	}

	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, err
	}
	return &dimensions.DataReadyTime{
		OldestPartition:  oldest,
		NewestPartition_: newest,
		MaxDateRange:     bizInfo.SelectRangeDay,
		DateRangeInfo:    bizInfo.DateRangeInfo,
	}, nil
}

func (d *DimensionService) GetPriceHybridTagEnumList(ctx context.Context, bizType dimensions.BizType) ([]*dimensions.DimSimpleElement, error) {
	return biz_info.GetPriceHybridTagEnumList(ctx)
}

func (d *DimensionService) GetDimColumnExpressStr(ctx context.Context, dimID int64) (string, error) {
	dim, err := d.DimensionListDao.GetDimensionById(ctx, dimID)
	if err != nil {
		return consts.Empty, errors.WithMessage(err, "根据维度ID查询维度失败")
	}
	dimC := dim.DimColumn
	if len(dim.DimExpr) > 0 {
		dimC = dim.DimExpr
	}
	if strings.Contains(dimC, "{{") && strings.Contains(dimC, "}}") {
		templateMap, err := base_struct_condition.GenerateTemplateMap(ctx)
		if err != nil {
			return consts.Empty, err
		}
		dimC = fasttemplate.ExecuteString(dimC, "{{", "}}", templateMap)
	}
	return dimC, nil
}

func (d *DimensionService) GetProductAnalysisBizList(ctx context.Context, effectModule string) (*dimensions.GetProductAnalysisBizData, error) {
	bizList, err := d.DimensionBizListDao.GetBizEffectModuleList(ctx, effectModule)
	if err != nil {
		return nil, err
	}
	userDimensionMap, err := utils.GetUserDimensionMap(ctx)
	if err != nil {
		return nil, err
	}

	resp := &dimensions.GetProductAnalysisBizData{
		BizList:                 make([]*dimensions.GetProductAnalysisBizInfo, 0),
		ParentUserDimensionCode: consts.ProductAnalysisDataAuth,
	}

	sort.Slice(bizList, func(i, j int) bool {
		return bizList[i].DisplayOrder < bizList[j].DisplayOrder
	})

	for _, bizDaoInfo := range bizList {
		if len(bizDaoInfo.UserDimensionCode) > 0 {
			var requiredDimInfo []*dimensions.SelectedDimensionInfo
			if len(bizDaoInfo.RequiredDimInfo) > 0 {
				err = sonic.UnmarshalString(bizDaoInfo.RequiredDimInfo, &requiredDimInfo)
				if err != nil {
					logs.CtxError(ctx, "[GetProductAnalysisBizList]RequiredDimInfo = %s, err = %v+", bizDaoInfo.RequiredDimInfo, err)
					return nil, err
				}
			}

			var hiddenModule []string
			if len(bizDaoInfo.HiddenModule) > 0 {
				err := sonic.UnmarshalString(bizDaoInfo.HiddenModule, &hiddenModule)
				if err != nil {
					logs.CtxError(ctx, "[GetProductAnalysisBizList]HiddenModule = %s, err = %v+", bizDaoInfo.HiddenModule, err)
					return nil, err
				}
			}
			resp.BizList = append(resp.BizList, &dimensions.GetProductAnalysisBizInfo{
				BizType:           bizDaoInfo.BizType,
				BizName:           bizDaoInfo.BizName,
				RequiredDimInfo:   requiredDimInfo,
				UserDimensionCode: bizDaoInfo.UserDimensionCode,
				HavePermission:    utils.CheckUserDimension(userDimensionMap, bizDaoInfo.UserDimensionCode),
				HiddenModule:      hiddenModule,
				DependBizId:       bizDaoInfo.DependBizID,
			})
		}
	}
	return resp, nil
}

func (d *DimensionService) GetAttributionTreeBizList(ctx context.Context, effectModule string) (*dimensions.GetProductAnalysisBizData, error) {
	return d.GetProductAnalysisBizList(ctx, effectModule)
}

func GetDimEnumsByBizFilter(enums []*dimensions.EnumElement, filterEnums []string) []*dimensions.EnumElement {
	if len(filterEnums) > 0 && len(enums) > 0 {
		newRet := make([]*dimensions.EnumElement, 0)
		for _, e := range enums {
			if slices.ContainsString(filterEnums, e.Code) {
				newRet = append(newRet, e)
			}
		}
		return newRet
	}
	return enums
}

func (d *DimensionService) GetProductAnalysisTargetMetaList(ctx context.Context, bizType dimensions.BizType, onlyDefault bool) (resp []*dimensions.TargetMetaInfo, err error) {
	resp = make([]*dimensions.TargetMetaInfo, 0)
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, bizType = %s", convert.ToJSONString(bizType))
		return resp, err
	}

	categoryOrder := biz_info.GetTargetCategoryOrder(ctx) // 获取分组顺序
	var oriBizType = bizType
	bizType = biz_utils.GetAnalysisBizType(bizType, bizInfo.DependBizID)

	targetMeteInfo, err := d.AttributeDao.GetTargetMetaInfo(ctx, int64(bizType), nil)
	if err != nil {
		return nil, err
	}
	for _, targetItem := range targetMeteInfo {
		if !onlyDefault || targetItem.IsDefaultShow {
			if (targetItem.Name == "channel_gov_subsidy_amt" ||
				targetItem.Name == "gov_subsidy_amt") &&
				(!utils.IsCostUser(ctx) || bizInfo.BizType != dimensions.BizType_GrowthProductStrategy) {
				// 国补指标，非管理员不展示
				continue
			}
			resp = append(resp, &dimensions.TargetMetaInfo{
				Name:               targetItem.Name,
				DisplayName:        targetItem.DisplayName,
				Tips:               targetItem.Tips,
				BizType:            bizInfo.BizType,
				IsDefaultShow:      targetItem.IsDefaultShow,
				AttributeType:      targetItem.AttributeType,
				DisplayOrder:       int64(targetItem.DisplayOrder),
				IsComputePercent:   targetItem.IsComputePercent,
				AttributeTypeOrder: GetCategoryOrder(targetItem.AttributeType, categoryOrder),
			})
		}
	}

	// 猜喜的默认指标单独处理
	if oriBizType == dimensions.BizType_GuessProduct {
		for _, targetMeta := range resp {
			targetMeta.IsDefaultShow = false
			for _, targetName := range consts.GuessDefaultTargets {
				if targetMeta.Name == targetName {
					targetMeta.IsDefaultShow = true
					break
				}
			}
		}
	}

	// 如果有货补权限，加入货补指标, 目前只有大盘商品有货补数据
	if !onlyDefault && utils.IsCostUser(ctx) && bizInfo.BizType == dimensions.BizType_GrowthProductStrategy {
		costMeta, err := GetProdCostTargetMeta(ctx, bizInfo.BizType, GetCategoryOrder("成交相关", categoryOrder))
		if err != nil {
			return nil, err
		}
		resp = append(resp, costMeta...)
	}
	return
}

func (d *DimensionService) RegisterNeedDumpDimension(ctx context.Context, req *dimensions.RegisterNeedDumpDimensionRequest) (resp bool, err error) {
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return false, errors.New("获取数据库的事务失败")
	}
	user, err := utils.GetCurrentUser(ctx)
	if err != nil && !env.IsBoe() {
		logs.CtxError(ctx, err.Error())
		return false, errors.New("获取当前用户信息失败")
	}
	if env.IsBoe() {
		user = &models.UserInfo{
			Email: proto.String("boe_test_user"),
		}
	}
	needDumpDims := make([]*model.NeedDumpDimensionInfo, 0)
	err = tx.Table("need_dump_dimension_info").Where("is_delete = ?", 0).
		Where("entity_id in (?)", req.EntityIds).Find(&needDumpDims).Error
	if err != nil {
		logs.CtxWarn(ctx, "RegisterNeedDumpDimension find current entity_id err=%v", err.Error())
		return false, err
	}
	if len(needDumpDims) > 0 {
		return false, errors.New("current entity_id have registered.")
	}

	for _, entityId := range req.EntityIds {
		dbErr := tx.Exec(`insert into need_dump_dimension_info 
			set entity_id = ?, 
			dimension_type = ?, 
			status = ?, 
			is_delete = ?,
			create_user=?,
			update_user=?`, entityId, int32(req.RegisterDimensionType), 2, false,
			*user.Email, *user.Email).Error
		if dbErr != nil {
			tx.Rollback()
			logs.CtxError(ctx, "RegisterNeedDumpDimension insert err=%v", dbErr.Error())
			return false, dbErr
		}
	}
	err = tx.Commit().Error
	if err != nil {
		logs.CtxWarn(ctx, "RegisterNeedDumpDimension Commit err=%v", err.Error())
		return false, err
	}
	return true, nil
}

// CheckTargetMetaListValid 用户传入要查询的指标，是否可以查看
func CheckTargetMetaListValid(ctx context.Context, bizType dimensions.BizType, targetMateList []string) bool {
	attributeDao := new(dao.AttributeDao)
	targetMateInfoList, err := (&DimensionService{AttributeDao: attributeDao}).GetProductAnalysisTargetMetaList(ctx, bizType, false)
	if err != nil {
		logs.CtxError(ctx, "CheckTargetMetaListValid Err: %v+", err)
		return false
	}
	checkMap := make(map[string]*dimensions.TargetMetaInfo)
	for _, t := range targetMateInfoList {
		checkMap[t.Name] = t
	}
	for _, name := range targetMateList {
		if _, exist := checkMap[name]; !exist {
			return false
		}
	}

	return true
}

// GetDefaultTargetMetaList 获取默认的指标列表
func GetDefaultTargetMetaList(ctx context.Context, bizType dimensions.BizType) []string {
	ret := make([]string, 0)
	attributeDao := new(dao.AttributeDao)
	targetMateInfoList, err := (&DimensionService{AttributeDao: attributeDao}).GetProductAnalysisTargetMetaList(ctx, bizType, true)
	if err != nil {
		logs.CtxError(ctx, "CheckTargetMetaListValid Err: %v+", err)
		return ret
	}
	sort.Slice(targetMateInfoList, func(i, j int) bool {
		return targetMateInfoList[i].DisplayOrder < targetMateInfoList[j].DisplayOrder
	})
	for _, targetName := range targetMateInfoList {
		ret = append(ret, targetName.Name)
	}
	return ret
}

func GetCategoryOrder(c string, categoryOrder map[string]int) int64 {
	if order, exist := categoryOrder[c]; exist {
		return convert.ToInt64(order)
	}
	return 999
}

func GetProdCostTargetMeta(ctx context.Context, bizType dimensions.BizType, categoryOrder int64) ([]*dimensions.TargetMetaInfo, error) {
	costReq := &promotion_growth_data_platform.GetIndicatorMetaRequest{
		Tenant:     promotion_growth_data_platform.PgdpTenantId_ProductInsights,
		ConfigType: promotion_growth_data_platform.MetricConfigType_ProductCostData,
	}
	// 调用实验平台接口，获取货补数据
	productCostMeta, err := ecom_marketing_promotion_growth_data_platform.RawCall.GetIndicatorMeta(ctx, costReq)
	if err != nil {
		logs.CtxError(ctx, "[GetProdCostTargetMeta]调用实验平台获取指标元信息失败, err:"+err.Error())
		return nil, errors.WithMessage(err, "调用实验平台获取指标元信息失败")
	}
	var targetMetaList = make([]*dimensions.TargetMetaInfo, 0)
	if productCostMeta != nil && len(productCostMeta.Data) > 0 {
		for i, targetMeta := range productCostMeta.Data {
			if targetMeta != nil {
				targetMetaList = append(targetMetaList, &dimensions.TargetMetaInfo{
					Name:               targetMeta.Key,
					DisplayName:        targetMeta.Name,
					Tips:               targetMeta.Desc,
					AttributeType:      "成交相关",
					DisplayOrder:       int64(997 + i), // 设置成这样是保证货补指标排最后
					BizType:            bizType,
					IsDefaultShow:      false,
					SystemSource:       dimensions.SystemSource_GoodsSupply,
					AttributeTypeOrder: categoryOrder,
				})
			}
		}
	}
	return targetMetaList, nil
}
