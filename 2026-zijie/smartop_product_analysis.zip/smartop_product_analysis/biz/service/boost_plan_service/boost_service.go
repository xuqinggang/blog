package boost_plan_service

import (
	"context"
	"fmt"
	"strconv"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"github.com/gogo/protobuf/proto"
)

type IBoostPlanService interface {
	GetPoolIDByPlanID(ctx context.Context, planID int64, planName string) (poolID string, err error)
	GetCreatePoolReq(ctx context.Context, planID int64, scene int32, planName, sceneName string) (req *analysis_pool.CreateAnalysisPoolReq)
}
type BoostPlanService struct {
	IBoostPlanService
}

func (v *BoostPlanService) GetPoolIDByPlanID(ctx context.Context, planID int64, planName string) (poolID string, err error) {
	pools := make([]analysis_pool.AnalysisPool, 0)
	err = mysql.DB(ctx).Raw(`
		select pool_id from analysis_pool where pool_name = ? and pool_rule like ? and is_delete = 0
	`, initPoolName(planID, planName), fmt.Sprintf("%%%d%%", planID)).Scan(&pools).Error
	if err != nil {
		logs.CtxError(ctx, "GetPoolByPlanID|planID:%d, err:%s", planID, err.Error())
		return "", err
	}
	if len(pools) <= 0 {
		return "", nil
	}
	// 存在多条记录告警
	if len(pools) > 1 {
		logs.CtxError(ctx, "GetPoolByPlanID|exist more than 1 record, planID", planID)
	}
	return *pools[0].PoolId, nil
}

func (v *BoostPlanService) GetCreatePoolReq(ctx context.Context, planID int64, scene int32, planName, sceneName string) (req *analysis_pool.CreateAnalysisPoolReq) {
	//thresholdExpr := base.LogicalExprType_AND
	req = &analysis_pool.CreateAnalysisPoolReq{
		PoolName:   initPoolName(planID, planName),
		PoolType:   1,
		PoolSource: 0,
		BaseStruct: &dimensions.ProductAnalysisBaseStruct{
			BizType:          dimensions.BizType_GuessBoostData,
			StartDate:        getDateString(-1),
			EndDate:          getDateString(-1),
			CompareStartDate: getDateString(-2),
			CompareEndDate:   getDateString(-2),
			Dimensions: []*dimensions.SelectedDimensionInfo{{
				Id:       "10291",
				AttrType: dimensions.DimensionAttributeType_Product,
				SelectedValues: []*dimensions.EnumElement{{
					Code: strconv.FormatInt(planID, 10),
					Name: planName,
					//TypeValue:     nil,
					//DependCode:    nil,
					//IsDefaultShow: false,
					//LegendExtra:   nil,
					//CreateUserId:  "",
					//LinkUrl:       "",
					//ExtraInfo:     "",
				}},
				//Editable:         0,
				//IsGroup:          false,
			}, {
				Id: "10353",
				//Name:             "",
				AttrType: dimensions.DimensionAttributeType_Place,
				//SelectedOperator: 0,
				SelectedValues: []*dimensions.EnumElement{{
					Code: strconv.FormatInt(int64(scene), 10),
					Name: sceneName,
					//TypeValue:     nil,
					//DependCode:    nil,
					//IsDefaultShow: false,
					//LegendExtra:   nil,
					//CreateUserId:  "",
					//LinkUrl:       "",
					//ExtraInfo:     "",
				}},
				//Editable:         0,
				//IsGroup:          false,
			}},
			//ThresholdAttrs:   []*dimensions.ThresholdAttr{},
			//ThresholdExpr: &thresholdExpr,
			GroupAttrs: []*dimensions.SelectedMultiDimensionInfo{},
			//UvFlag:           nil,
			//TargetMetaList:   nil,
			//CompareType: nil,
			//IsTotal:          nil,
		},
		IsTotal: proto.Bool(true),
	}
	return req
}

func initPoolName(id int64, name string) string {
	return fmt.Sprintf("%s(%d)", name, id)
}

func getDateString(days int32) string {
	// 获取当前时间
	now := time.Now()
	// 计算昨天的时间
	yesterday := now.AddDate(0, 0, int(days))
	// 按照指定格式格式化昨天的日期
	return yesterday.Format("2006-01-02")
}
