package analysis_pool_diagnosis_service

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	"time"

	"encoding/json"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	ecom_smartop_data_access "code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom.smartop.data_access"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_diagnosis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	data_access_common "code.byted.org/overpass/ecom_smartop_data_access/kitex_gen/common"
	"code.byted.org/overpass/ecom_smartop_data_access/kitex_gen/ecom/smartop/data_access"
	"code.byted.org/temai/go_lib/convert"
	jsoniter "github.com/json-iterator/go"
	"github.com/thoas/go-funk"
)

type IAnalysisPoolDiagnosisService interface {
	GetDiagnosisJudgeConditionList(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisJudgeConditionListReq) (resp *analysis_pool_diagnosis.GetDiagnosisJudgeConditionListData, err error)
	GetDiagnosisIndicatorCategoryJudge(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeReq) (resp *analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeData, err error)
	GetDiagnosisFactorList(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisFactorListReq) (resp *analysis_pool_diagnosis.GetDiagnosisFactorListData, err error)
	QueryDiagnosisProductList(ctx context.Context, req *analysis_pool_diagnosis.QueryDiagnosisProductListReq) (resp *analysis_pool_diagnosis.QueryDiagnosisProductListData, err error)
	QueryDiagnosisFlowSpaceProductList(ctx context.Context, req *analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListReq) (resp *analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListData, err error)
}

type AnalysisPoolDiagnosisService struct {
}

type OsParamsReqStruct struct {
	StartDate *string `thrift:"start_date,1,optional" frugal:"1,optional,string" json:"start_date,omitempty"`
	EndDate   *string `thrift:"end_date,2,optional" frugal:"2,optional,string" json:"end_date,omitempty"`
	App       *string `thrift:"app,3,optional" frugal:"3,optional,string" json:"app,omitempty"`
}

type ProductInfoName struct {
	IdStr  *string `thrift:"id_str,1,optional" frugal:"1,optional,string" json:"id_str,omitempty"`
	Name   *string `thrift:"name,2,optional" frugal:"2,optional,string" json:"name,omitempty"`
	ImgUrl *string `thrift:"img_url,3,optional" frugal:"3,optional,string" json:"img_url,omitempty"`
}

type IndicatorTableParams struct {
	StartDate        *string `thrift:"start_date,1,optional" frugal:"1,optional,string" json:"start_date,omitempty"`
	EndDate          *string `thrift:"end_date,2,optional" frugal:"2,optional,string" json:"end_date,omitempty"`
	CompareStartDate *string `thrift:"compare_start_date,3,optional" frugal:"3,optional,string" json:"compare_start_date,omitempty"`
	CompareEndDate   *string `thrift:"compare_end_date,4,optional" frugal:"4,optional,string" json:"compare_end_date,omitempty"`
	App              *string `thrift:"app,5,optional" frugal:"5,optional,string" json:"app,omitempty"`
	PidList          *string `thrift:"pid_list,6,optional" frugal:"6,optional,string" json:"pid_list,omitempty"`
	Page             int32   `thrift:"page,7,required" frugal:"7,required,i32" json:"page"`
	PageSize         *int32  `thrift:"pageSize,8,optional" frugal:"8,optional,i32" json:"pageSize,omitempty"`
	SortField        *string `thrift:"sort_field,9,optional" frugal:"9,optional,string" json:"sort_field,omitempty"`
	SortIsAsc        *bool   `thrift:"sort_is_asc,10,optional" frugal:"10,optional,bool" json:"sort_is_asc,omitempty"`
}

func (t *AnalysisPoolDiagnosisService) QueryDiagnosisProductList(ctx context.Context, req *analysis_pool_diagnosis.QueryDiagnosisProductListReq) (resp *analysis_pool_diagnosis.QueryDiagnosisProductListData, err error) {
	resp = &analysis_pool_diagnosis.QueryDiagnosisProductListData{
		PageInfo: &base.PageResp{
			PageNum:  req.PageReq.PageNum,
			PageSize: req.PageReq.PageSize,
			Total:    0,
		},
		List: make([]*analysis_pool_diagnosis.DiagnosisProductInfo, 0),
	}

	if req.JudgeKey == nil {
		logs.CtxInfo(ctx, "[QueryDiagnosisProductList] JudgeKey nil req=%v", req)
		return nil, errors.New("未传入判定条件")
	}

	factorList, err := biz_info.GetDiagnosisFactorList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[QueryDiagnosisProductList]调用tcc GetDiagnosisFactorList失败 req=%v err=%v", req, err)
		return nil, err
	}

	reqFactorList := make([]*analysis_pool_diagnosis.DiagnosisFactorInfo, 0)
	drillDownFactorList := make([]*analysis_pool_diagnosis.DiagnosisFactorInfo, 0)
	for _, item := range factorList {
		for _, factorKey := range req.FactorKeyList {
			var p = new(analysis_pool_diagnosis.DiagnosisFactorInfo)
			p = item
			if (req.Scene != nil && *item.Scene == *req.Scene && *item.Factor.FactorKey == factorKey) || (req.Scene == nil && *item.Factor.FactorKey == factorKey) {
				reqFactorList = append(reqFactorList, p)
			}
		}
		for _, factorKey := range req.DrillDownFactorKey {
			var p = new(analysis_pool_diagnosis.DiagnosisFactorInfo)
			p = item
			if (req.Scene != nil && *item.Scene == *req.Scene && *item.Factor.FactorKey == factorKey) || (req.Scene == nil && *item.Factor.FactorKey == factorKey) {
				drillDownFactorList = append(drillDownFactorList, p)
			}
		}
	}

	requestIndicatorInfoList := []*analysis_pool_diagnosis.DiagnosisIndicator{
		{
			Key:      convert.ToStringPtr("level_cate_name_concat"),
			Name:     convert.ToStringPtr("类目"),
			Priority: convert.ToInt64Ptr(1),
			Group:    convert.ToStringPtr("基础信息"),
		},
		{
			Key:      convert.ToStringPtr("leaf_exp_type"),
			Name:     convert.ToStringPtr("叶子类目类型"),
			Priority: convert.ToInt64Ptr(2),
			Group:    convert.ToStringPtr("基础信息"),
		},
		{
			Key:      convert.ToStringPtr("prod_exp_type"),
			Name:     convert.ToStringPtr("商品状态"),
			Priority: convert.ToInt64Ptr(3),
			Group:    convert.ToStringPtr("基础信息"),
		},
		{
			Key:      convert.ToStringPtr("emp_name"),
			Name:     convert.ToStringPtr("小二"),
			Priority: convert.ToInt64Ptr(4),
			Group:    convert.ToStringPtr("基础信息"),
		},
	}

	requestIndicatorList, mapOk := funk.Map(requestIndicatorInfoList, func(indicatorInfo *analysis_pool_diagnosis.DiagnosisIndicator) string {
		return *indicatorInfo.Key
	}).([]string)
	if !mapOk {
		requestIndicatorList = make([]string, 0)
	}

	for _, reqFactorItem := range reqFactorList {
		requestIndicatorList = append(requestIndicatorList, *reqFactorItem.Indicator.Key)
		requestIndicatorInfoList = append(requestIndicatorInfoList, reqFactorItem.Indicator)
		if len(reqFactorItem.RelationIndicator) > 0 {
			for _, relationItem := range reqFactorItem.RelationIndicator {
				requestIndicatorList = append(requestIndicatorList, *relationItem.Key)
				requestIndicatorInfoList = append(requestIndicatorInfoList, relationItem)
			}
		}
	}

	pidList, err := getPoolPidList(ctx, req.BaseStruct)
	if err != nil {
		logs.CtxError(ctx, "[QueryDiagnosisProductList]调用getPoolPidList失败 req=%v err=%v", req, err)
		return nil, err
	}
	if len(pidList) == 0 {
		logs.CtxInfo(ctx, "[QueryDiagnosisProductList]pidList为空 req=%v", req)
		return nil, errors.New("无可查询商品")
	}

	// 根据需要下钻的关键因子对应的指标异常商品id进行过滤
	if len(drillDownFactorList) > 0 {
		pidList, err = getPidListWithDrillDown(ctx, pidList, req.BaseStruct, *req.JudgeKey, drillDownFactorList)
		if err != nil {
			logs.CtxError(ctx, "[QueryDiagnosisProductList]调用getPidListWithDrillDown失败 drillDownFactorList=%v err=%v", drillDownFactorList, err)
			return nil, err
		}
	}

	pidListStr, err := jsoniter.MarshalToString(pidList)
	if (err != nil) || (pidListStr == "") {
		logs.CtxError(ctx, "[QueryDiagnosisProductList]pidList marshal err: %v", err)
		return nil, err
	}

	productInfoList, total, err := getProdInfoList(ctx, IndicatorTableParams{
		StartDate:        &req.BaseStruct.StartDate,
		EndDate:          &req.BaseStruct.EndDate,
		CompareStartDate: req.BaseStruct.CompareStartDate,
		CompareEndDate:   req.BaseStruct.CompareEndDate,
		PidList:          &pidListStr,
		Page:             req.PageReq.PageNum,
		PageSize:         &req.PageReq.PageSize,
		App:              req.BaseStruct.App,
		SortField:        req.Sort.Field,
		SortIsAsc:        req.Sort.IsAsc,
	}, requestIndicatorInfoList)
	if err != nil {
		logs.CtxError(ctx, "[QueryDiagnosisProductList]调用getProdInfoList失败 req=%v err=%v", req, err)
		return nil, err
	}

	resp.List = productInfoList
	if total == 0 {
		total = convert.ToInt64(len(pidList))
	}
	resp.PageInfo.Total = total

	return resp, nil
}

func (t *AnalysisPoolDiagnosisService) QueryDiagnosisFlowSpaceProductList(ctx context.Context, req *analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListReq) (resp *analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListData, err error) {
	resp = &analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListData{
		PageInfo: &base.PageResp{
			PageNum:  req.PageReq.PageNum,
			PageSize: req.PageReq.PageSize,
			Total:    0,
		},
		List: make([]*analysis_pool_diagnosis.DiagnosisProductInfo, 0),
	}

	if req.JudgeKey == nil {
		logs.CtxInfo(ctx, "[QueryDiagnosisFlowSpaceProductList] JudgeKey nil req=%v", req)
		return nil, errors.New("未传入判定条件")
	}
	requestIndicatorInfoList := []*analysis_pool_diagnosis.DiagnosisIndicator{
		{
			Key:      convert.ToStringPtr("level_cate_name_concat"),
			Name:     convert.ToStringPtr("类目"),
			Priority: convert.ToInt64Ptr(1),
			Group:    convert.ToStringPtr("基础信息"),
		},
		{
			Key:      convert.ToStringPtr("leaf_exp_type"),
			Name:     convert.ToStringPtr("叶子类目类型"),
			Priority: convert.ToInt64Ptr(2),
			Group:    convert.ToStringPtr("基础信息"),
		},
		{
			Key:      convert.ToStringPtr("prod_exp_type"),
			Name:     convert.ToStringPtr("商品状态"),
			Priority: convert.ToInt64Ptr(3),
			Group:    convert.ToStringPtr("基础信息"),
		},
		{
			Key:      convert.ToStringPtr("emp_name"),
			Name:     convert.ToStringPtr("小二"),
			Priority: convert.ToInt64Ptr(4),
			Group:    convert.ToStringPtr("基础信息"),
		},
		{
			Key:      convert.ToStringPtr("show_search_mgr_search_cnt_1d"),
			Name:     convert.ToStringPtr("有商品曝光query搜索pv"),
			Priority: convert.ToInt64Ptr(11),
			Group:    convert.ToStringPtr("商品流量空间"),
		},
		{
			Key:      convert.ToStringPtr("search_mgr_search_cnt_1d"),
			Name:     convert.ToStringPtr("有商品下发query搜索pv"),
			Priority: convert.ToInt64Ptr(12),
			Group:    convert.ToStringPtr("商品流量空间"),
		},
		{
			Key:      convert.ToStringPtr("diff_search_mgr_search_cnt_1d"),
			Name:     convert.ToStringPtr("商品流量空间"),
			Priority: convert.ToInt64Ptr(13),
			Group:    convert.ToStringPtr("商品流量空间"),
		},
		{
			Key:      convert.ToStringPtr("show_search_mgr_search_cnt_rate"),
			Name:     convert.ToStringPtr("有商品曝光query搜索pv周环比"),
			Priority: convert.ToInt64Ptr(14),
			Group:    convert.ToStringPtr("流量空间趋势"),
		},
		{
			Key:      convert.ToStringPtr("search_mgr_search_cnt_rate"),
			Name:     convert.ToStringPtr("有商品下发query搜索pv周环比"),
			Priority: convert.ToInt64Ptr(15),
			Group:    convert.ToStringPtr("流量空间趋势"),
		},
		{
			Key:      convert.ToStringPtr("diff_search_mgr_search_cnt_rate"),
			Name:     convert.ToStringPtr("商品流量空间周环比"),
			Priority: convert.ToInt64Ptr(16),
			Group:    convert.ToStringPtr("流量空间趋势"),
		},
	}

	factorList, err := biz_info.GetDiagnosisFactorList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[QueryDiagnosisFlowSpaceProductList]调用tcc GetDiagnosisFactorList失败 req=%v err=%v", req, err)
		return nil, err
	}

	drillDownFactorList := make([]*analysis_pool_diagnosis.DiagnosisFactorInfo, 0)
	for _, item := range factorList {
		for _, factorKey := range req.DrillDownFactorKey {
			var p = new(analysis_pool_diagnosis.DiagnosisFactorInfo)
			p = item
			if (req.Scene != nil && *item.Scene == *req.Scene && *item.Factor.FactorKey == factorKey) || (req.Scene == nil && *item.Factor.FactorKey == factorKey) {
				drillDownFactorList = append(drillDownFactorList, p)
			}
		}
	}

	pidList, err := getPoolPidList(ctx, req.BaseStruct)
	if err != nil {
		logs.CtxError(ctx, "[QueryDiagnosisFlowSpaceProductList]调用getPoolPidList失败 req=%v err=%v", req, err)
		return nil, err
	}
	if len(pidList) == 0 {
		logs.CtxInfo(ctx, "[QueryDiagnosisFlowSpaceProductList]pidList为空 req=%v", req)
		return nil, errors.New("无可查询商品")
	}

	// 根据需要下钻的关键因子对应的指标异常商品id进行过滤
	if len(drillDownFactorList) > 0 {
		pidList, err = getPidListWithDrillDown(ctx, pidList, req.BaseStruct, *req.JudgeKey, drillDownFactorList)
		if err != nil {
			logs.CtxError(ctx, "[QueryDiagnosisFlowSpaceProductList]调用getPidListWithDrillDown失败 drillDownFactorList=%v err=%v", drillDownFactorList, err)
			return nil, err
		}
	}

	pidListStr, err := jsoniter.MarshalToString(pidList)
	if (err != nil) || (pidListStr == "") {
		logs.CtxError(ctx, "[QueryDiagnosisFlowSpaceProductList]pidList marshal err: %v", err)
		return nil, err
	}

	productInfoList, total, err := getProdInfoList(ctx, IndicatorTableParams{
		StartDate:        &req.BaseStruct.StartDate,
		EndDate:          &req.BaseStruct.EndDate,
		CompareStartDate: req.BaseStruct.CompareStartDate,
		CompareEndDate:   req.BaseStruct.CompareEndDate,
		PidList:          &pidListStr,
		Page:             req.PageReq.PageNum,
		PageSize:         &req.PageReq.PageSize,
		App:              req.BaseStruct.App,
		SortField:        req.Sort.Field,
		SortIsAsc:        req.Sort.IsAsc,
	}, requestIndicatorInfoList)
	if err != nil {
		logs.CtxError(ctx, "[QueryDiagnosisFlowSpaceProductList]调用getProdInfoList失败 req=%v err=%v", req, err)
		return nil, err
	}

	resp.List = productInfoList
	if total == 0 {
		total = convert.ToInt64(len(pidList))
	}
	resp.PageInfo.Total = total

	return resp, nil
}

func (t *AnalysisPoolDiagnosisService) GetDiagnosisFactorList(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisFactorListReq) (resp *analysis_pool_diagnosis.GetDiagnosisFactorListData, err error) {
	resp = &analysis_pool_diagnosis.GetDiagnosisFactorListData{}

	if req.JudgeKey == nil {
		logs.CtxInfo(ctx, "[GetDiagnosisFactorList] JudgeKey nil req=%v", req)
		return nil, errors.New("未传入判定条件")
	}

	if req.Scene == nil {
		logs.CtxInfo(ctx, "[GetDiagnosisFactorList] Scene nil req=%v", req)
		return nil, errors.New("未传入诊断场景")
	}

	pidList, err := getPoolPidList(ctx, req.BaseStruct)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisFactorList]调用getPoolPidList失败 req=%v err=%v", req, err)
		return nil, err
	}
	if len(pidList) == 0 {
		logs.CtxInfo(ctx, "[GetDiagnosisFactorList]pidList为空 req=%v", req)
		return nil, errors.New("无可查询商品")
	}

	factorList, err := biz_info.GetDiagnosisFactorList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisFactorList]调用tcc GetDiagnosisFactorList失败 req=%v err=%v", req, err)
		return nil, err
	}

	// 过滤出对应场景的配置
	sceneFactorList := make([]*analysis_pool_diagnosis.DiagnosisFactorInfo, 0)
	if req.Scene != nil {
		for _, item := range factorList {
			if *item.Scene == *req.Scene {
				sceneFactorList = append(sceneFactorList, item)
			}
		}
	} else {
		sceneFactorList = factorList
	}

	// 通过os拿到该场景的指标判定商品数量数据
	allProductCountDetail := map[string]string{}
	if len(pidList) > 1 {
		allProductCountDetail, err = getFactorJudgeProdCount(ctx, pidList, req.BaseStruct, *req.JudgeKey, sceneFactorList)
	}

	if req.IndicatorCategory == nil {
		if err != nil {
			logs.CtxError(ctx, "[GetDiagnosisFactorList]调用getFactorJudgeProdCount失败 req=%v err=%v", req, err)
			return nil, err
		}

		resFactorList, isOk := funk.Map(sceneFactorList, func(factorInfo *analysis_pool_diagnosis.DiagnosisFactorInfo) *analysis_pool_diagnosis.DiagnosisFactorCombine {
			indicatorKey := factorInfo.Indicator.Key
			judgeProdCountKey := ""
			if indicatorKey != nil {
				judgeProdCountKey = fmt.Sprintf("%v_%v", *indicatorKey, "prod_count")
			}
			judgeProdCountValue := (allProductCountDetail)[judgeProdCountKey]
			return &analysis_pool_diagnosis.DiagnosisFactorCombine{
				FactorInfo:                  factorInfo,
				FactorIndicatorProductCount: &judgeProdCountValue,
			}
		}).([]*analysis_pool_diagnosis.DiagnosisFactorCombine)
		if !isOk {
			resFactorList = make([]*analysis_pool_diagnosis.DiagnosisFactorCombine, 0)
		}
		resp.FactorList = resFactorList
		return resp, nil
	}

	indicatorCategoryList, err := biz_info.GetDiagnosisIndicatorCategory(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisFactorList]调用tcc GetDiagnosisIndicatorCategory失败 req=%v err=%v", req, err)
		return nil, err
	}
	// 过滤出对应判定条件的配置
	targetCategory := &analysis_pool_diagnosis.DiagnosisIndicatorCategory{}

	for _, item := range indicatorCategoryList {
		if *item.Scene == *req.Scene && *req.IndicatorCategory == *item.IndicatorCategory {
			targetCategory = item
		}
	}

	targetCategoryFactorList := make([]*analysis_pool_diagnosis.DiagnosisFactorInfo, 0)
	for _, sceneFactorItem := range sceneFactorList {
		if sceneFactorItem != nil && sceneFactorItem.Factor != nil {
			for _, targetCategoryFactorItem := range targetCategory.FactorList {
				if targetCategoryFactorItem.FactorKey != nil && sceneFactorItem.Factor.FactorKey != nil && *targetCategoryFactorItem.FactorKey == *sceneFactorItem.Factor.FactorKey {
					targetCategoryFactorList = append(targetCategoryFactorList, sceneFactorItem)
					break
				}
			}
		}
	}

	resFactorList, isOk := funk.Map(targetCategoryFactorList, func(factorInfo *analysis_pool_diagnosis.DiagnosisFactorInfo) *analysis_pool_diagnosis.DiagnosisFactorCombine {
		indicatorKey := factorInfo.Indicator.Key
		judgeProdCountKey := ""
		if indicatorKey != nil {
			judgeProdCountKey = fmt.Sprintf("%v_%v", *indicatorKey, "prod_count")
		}
		judgeProdCountValue := (allProductCountDetail)[judgeProdCountKey]
		return &analysis_pool_diagnosis.DiagnosisFactorCombine{
			FactorInfo:                  factorInfo,
			FactorIndicatorProductCount: &judgeProdCountValue,
		}
	}).([]*analysis_pool_diagnosis.DiagnosisFactorCombine)
	if !isOk {
		resFactorList = make([]*analysis_pool_diagnosis.DiagnosisFactorCombine, 0)
	}

	resp.FactorList = resFactorList

	return resp, nil
}

func (t *AnalysisPoolDiagnosisService) GetDiagnosisJudgeConditionList(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisJudgeConditionListReq) (resp *analysis_pool_diagnosis.GetDiagnosisJudgeConditionListData, err error) {
	resp = &analysis_pool_diagnosis.GetDiagnosisJudgeConditionListData{}

	list, err := biz_info.GetDiagnosisJudgeConditionList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisJudgeConditionList]调用tcc GetDiagnosisJudgeConditionList失败 req=%v err=%v", req, err)
		return nil, err
	}

	// 过滤出对应场景的配置
	sceneConditionList := make([]*analysis_pool_diagnosis.DiagnosisJudgeCondition, 0)
	if req.Scene != nil {
		for _, item := range list {
			if *item.Scene == *req.Scene {
				sceneConditionList = append(sceneConditionList, item)
			}
		}
	} else {
		sceneConditionList = list
	}
	resp.ConditionList = sceneConditionList
	return resp, nil
}

func (t *AnalysisPoolDiagnosisService) GetDiagnosisIndicatorCategoryJudge(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeReq) (resp *analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeData, err error) {
	resp = &analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeData{}

	if req.JudgeKey == nil {
		logs.CtxInfo(ctx, "[GetDiagnosisIndicatorCategoryJudge] JudgeKey nil req=%v", req)
		return nil, errors.New("未传入判定条件")
	}

	if req.Scene == nil {
		logs.CtxInfo(ctx, "[GetDiagnosisIndicatorCategoryJudge] Scene nil req=%v", req)
		return nil, errors.New("未传入诊断场景")
	}

	pidList, err := getPoolPidList(ctx, req.BaseStruct)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisIndicatorCategoryJudge]调用getPoolPidList失败 req=%v err=%v", req, err)
		return nil, err
	}
	if len(pidList) == 0 {
		logs.CtxInfo(ctx, "[GetDiagnosisIndicatorCategoryJudge]pidList为空 req=%v", req)
		return nil, errors.New("无可查询商品")
	}

	judgeConditionList, err := biz_info.GetDiagnosisJudgeConditionList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisIndicatorCategoryJudge]调用tcc GetDiagnosisJudgeConditionList失败 req=%v err=%v", req, err)
		return nil, err
	}

	judgeKeyIndicatorValuePrefix := ""
	respJudgeCondition := &analysis_pool_diagnosis.DiagnosisJudgeCondition{}
	for _, item := range judgeConditionList {
		if *item.JudgeKey == *req.JudgeKey {
			judgeKeyIndicatorValuePrefix = *item.JudgeKeyIndicatorValuePrefix
			if judgeKeyIndicatorValuePrefix == "leaf_top_twenty" {
				judgeKeyIndicatorValuePrefix = "leaf_top_avg"
			}
			respJudgeCondition = item
		}
	}

	indicatorCategoryList, err := biz_info.GetDiagnosisIndicatorCategory(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisIndicatorCategoryJudge]调用tcc GetDiagnosisIndicatorCategory失败 req=%v err=%v", req, err)
		return nil, err
	}

	// 过滤出对应判定条件的配置
	targetCategory := &analysis_pool_diagnosis.DiagnosisIndicatorCategory{}

	for _, item := range indicatorCategoryList {
		if *item.Scene == *req.Scene && *req.IndicatorCategory == *item.IndicatorCategory {
			targetCategory = item
		}
	}

	// 多商品 返回不符合条件商品数量
	factorList, err := biz_info.GetDiagnosisFactorList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisIndicatorCategoryJudge]调用tcc GetDiagnosisFactorList失败 req=%v err=%v", req, err)
		return nil, err
	}

	targetCategoryFactorList := make([]*analysis_pool_diagnosis.DiagnosisFactorInfo, 0)
	for _, item := range factorList {
		isContain := funk.Contains(factorList, func(foo *analysis_pool_diagnosis.DiagnosisFactorInfo) bool {
			return *foo.Factor.FactorKey == *item.Factor.FactorKey
		})
		if isContain {
			targetCategoryFactorList = append(targetCategoryFactorList, item)
		}
	}
	targetCategoryIndicatorList := make([]*analysis_pool_diagnosis.DiagnosisIndicator, 0)
	for _, item := range targetCategoryFactorList {
		if item != nil && item.Indicator != nil {
			targetCategoryIndicatorList = append(targetCategoryIndicatorList, item.Indicator)
		}
		if item != nil && len(item.RelationIndicator) > 0 {
			for _, relationItem := range item.RelationIndicator {
				targetCategoryIndicatorList = append(targetCategoryIndicatorList, relationItem)
			}
		}
	}

	for _, item := range indicatorCategoryList {
		if *item.Scene == *req.Scene && *req.IndicatorCategory == *item.IndicatorCategory {
			targetCategory = item
		}
	}

	allProductCountDetail := make(map[string]string)
	singleProdIndicatorEntityList := make([]*analysis_pool_diagnosis.IndicatorEntity, 0)
	allProductCountDetail, err = getFactorJudgeProdCount(ctx, pidList, req.BaseStruct, *req.JudgeKey, targetCategoryFactorList)
	if err != nil {
		logs.CtxError(ctx, "[GetDiagnosisIndicatorCategoryJudge]调用getFactorJudgeProdCount失败，err=%v+", err)
		return nil, err
	}

	productCount := len(pidList)
	productCountStr := strconv.Itoa(productCount)

	// 单商品 返回当前指标数据和判定条件的指标数据
	if productCount == 1 {
		pidListStr, err := jsoniter.MarshalToString(pidList)
		if (err != nil) || (pidListStr == "") {
			logs.CtxError(ctx, "[QueryDiagnosisProductList]pidList marshal err: %v", err)
			return nil, err
		}
		pageSize := int32(10)
		prodInfoList, _, err := getProdInfoList(ctx, IndicatorTableParams{
			StartDate:        &req.BaseStruct.StartDate,
			EndDate:          &req.BaseStruct.EndDate,
			CompareStartDate: req.BaseStruct.CompareStartDate,
			CompareEndDate:   req.BaseStruct.CompareEndDate,
			PidList:          &pidListStr,
			Page:             1,
			PageSize:         &pageSize,
			App:              req.BaseStruct.App,
		}, targetCategoryIndicatorList)
		if err != nil {
			logs.CtxError(ctx, "[QueryDiagnosisProductList]调用getProdInfoList失败 err=%v", err)
			return nil, err
		}
		if len(prodInfoList) > 0 {
			singleProdIndicatorEntityList = prodInfoList[0].IndicatorEntityList
		}
	}

	for _, item := range targetCategory.JudgeIndicatorList {
		indicatorKey := item.Key
		judgeProdCountKey := ""
		if indicatorKey != nil && *indicatorKey != "" {
			judgeProdCountKey = fmt.Sprintf("%v_%v", *indicatorKey, "prod_count")
		}
		judgeConditionIndicatorKey := ""
		if indicatorKey != nil && *indicatorKey != "" && judgeKeyIndicatorValuePrefix != "" {
			judgeConditionIndicatorKey = fmt.Sprintf("%v_%v", judgeKeyIndicatorValuePrefix, *indicatorKey)
			// 针对avg_show_position_1d 做下特殊处理
			if *indicatorKey == "avg_show_position_1d" && judgeKeyIndicatorValuePrefix == "leaf_top_avg" {
				judgeConditionIndicatorKey = fmt.Sprintf("%v_%v", "leaf_top", *indicatorKey)
			} else if *indicatorKey == "avg_show_position_1d" && judgeKeyIndicatorValuePrefix == "leaf_avg" {
				judgeConditionIndicatorKey = fmt.Sprintf("%v_%v", "leaf", *indicatorKey)
			}
		}
		indicatorEntity, isOk := funk.Find(singleProdIndicatorEntityList, func(entity *analysis_pool_diagnosis.IndicatorEntity) bool {
			return entity.Name == *indicatorKey
		}).(*analysis_pool_diagnosis.IndicatorEntity)
		if !isOk {
			if indicatorKey != nil && *indicatorKey != "" {
				indicatorEntity = &analysis_pool_diagnosis.IndicatorEntity{
					Name:  *indicatorKey,
					Value: "",
				}
			} else {
				indicatorEntity = &analysis_pool_diagnosis.IndicatorEntity{}
			}
		}
		judgeConditionIndicatorEntity, isOk := funk.Find(singleProdIndicatorEntityList, func(entity *analysis_pool_diagnosis.IndicatorEntity) bool {
			return entity.Name == judgeConditionIndicatorKey
		}).(*analysis_pool_diagnosis.IndicatorEntity)
		if !isOk {
			judgeConditionIndicatorEntity = &analysis_pool_diagnosis.IndicatorEntity{
				Name:  judgeConditionIndicatorKey,
				Value: "",
			}
		}
		judgeProdCountValue := (allProductCountDetail)[judgeProdCountKey]

		resp.IndicatorCategoryList = append(resp.IndicatorCategoryList, &analysis_pool_diagnosis.DiagnosisIndicatorJudge{
			IndicatorCategory: targetCategory.IndicatorCategory,
			Indicator: &analysis_pool_diagnosis.DiagnosisIndicator{
				Key:  item.Key,
				Name: item.Name,
			},
			IndicatorEntity: indicatorEntity,
			JudgeConditionData: []*analysis_pool_diagnosis.DiagnosisIndicatorJudgeConditionData{
				{
					JudgeCondition:             respJudgeCondition,
					JudgeIndicatorEntity:       judgeConditionIndicatorEntity,
					JudgeIndicatorProductCount: &judgeProdCountValue,
				},
			},
			ProductCount: &productCountStr,
		})
	}

	return resp, nil
}

func getFactorJudgeProdCount(ctx context.Context, originPidList []string, baseStruct *analysis_pool_diagnosis.AnalysisPoolDiagnosisBaseStruct, judgeKey string, factorList []*analysis_pool_diagnosis.DiagnosisFactorInfo) (prodCountMap map[string]string, err error) {
	judgeConditionList, err := biz_info.GetDiagnosisJudgeConditionList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[getFactorJudgeProdCount]调用tcc GetDiagnosisJudgeConditionList失败 err=%v", err)
		return nil, err
	}

	judgeIndicatorValuePrefix := ""
	for _, item := range judgeConditionList {
		if *item.JudgeKey == judgeKey {
			judgeIndicatorValuePrefix = *item.JudgeKeyIndicatorValuePrefix
		}
	}

	baseParams, err := getJudgeProductCountOsParams(ctx, &OsParamsReqStruct{
		StartDate: &baseStruct.StartDate,
		EndDate:   &baseStruct.EndDate,
		App:       baseStruct.App,
	}, originPidList)

	if err != nil {
		logs.CtxError(ctx, "[getFactorJudgeProdCount]获取查询os参数失败，err=%v+", err)
		return nil, err
	}

	tableNameList := make([]string, 0)
	tableNameCqlMap := map[string]map[string]interface{}{}
	for _, factorItem := range factorList {
		if !slices.ContainsString(tableNameList, *factorItem.Indicator.TableName) {
			tableNameList = append(tableNameList, *factorItem.Indicator.TableName)
		}
	}

	for _, tableName := range tableNameList {
		exprCql := sql_parse.NewCQL()
		selectParams := map[string]interface{}{}
		for _, factorItem := range factorList {
			indicatorTableName := *factorItem.Indicator.TableName
			if indicatorTableName != tableName {
				continue
			}
			drillDownIndicatorKey := *factorItem.Indicator.Key
			judgeLogic := factorItem.Indicator.JudgeLogic
			judgeCompareConstant := factorItem.Indicator.CompareConstant
			judgeNotMatchStatus, isOk := funk.Map(factorItem.Indicator.NotMatchStatus, func(x string) string {
				return fmt.Sprintf("'%v'", x)
			}).([]string)
			if !isOk {
				judgeNotMatchStatus = make([]string, 0)
			}
			judgeProdCountKey := fmt.Sprintf("%v_%v", drillDownIndicatorKey, "prod_count")
			judgeIndicatorKey := fmt.Sprintf("%v_%v", drillDownIndicatorKey, "result")
			judgeConditionIndicatorKey := fmt.Sprintf("%v_%v_%v", judgeIndicatorValuePrefix, drillDownIndicatorKey, "result")
			if judgeIndicatorKey != "" && judgeLogic != nil {
				if *judgeLogic == JUDGE_LOGIC_STATUS {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v (%v), 1, 0)) as %v", judgeIndicatorKey, sql_parse.IN, utils.List2String(judgeNotMatchStatus, ","), judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_GT {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.GREATER_THAN, judgeConditionIndicatorKey, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_GE {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.GREATER_EQUAL_THAN, judgeConditionIndicatorKey, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_LT {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.LESS_THAN, judgeConditionIndicatorKey, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_LE {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.LESS_EQUAL_THAN, judgeConditionIndicatorKey, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_EQ {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.EQUAL, judgeConditionIndicatorKey, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_GT {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.GREATER_THAN, *judgeCompareConstant, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_GE {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.GREATER_EQUAL_THAN, *judgeCompareConstant, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_LT {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.LESS_THAN, *judgeCompareConstant, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_LE {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.LESS_EQUAL_THAN, *judgeCompareConstant, judgeProdCountKey),
					})
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_EQ {
					exprCql.SelectAppendColumn(&sql_parse.Column{
						Field: fmt.Sprintf("sum(if(%v %v %v, 1, 0)) as %v", judgeIndicatorKey, sql_parse.EQUAL, *judgeCompareConstant, judgeProdCountKey),
					})
				}
			}
		}
		selectParams["select_params"] = exprCql.ParseSelectClause()
		selectParams["table_name"] = tableName
		sqlParams := utils.MergeMaps(&selectParams, &baseParams)
		tableNameCqlMap[tableName] = sqlParams
	}

	logs.CtxInfo(ctx, "[getFactorJudgeProdCount]查询os api params=%v", tableNameCqlMap)

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()

	for tableName, sqlParams := range tableNameCqlMap {
		prodCountTableName := "product_count_" + tableName
		f.ExeQueryInvokerRaw(sqlParams, apiPathJudgeFilterProductCount, param.SinkTable(prodCountTableName))
	}

	tableProdCountMap := map[string]*map[string]string{}
	for tableName, _ := range tableNameCqlMap {
		prodCountTableName := "product_count_" + tableName
		tmpProdCountMap := map[string]string{}
		tableProdCountMap[prodCountTableName] = &tmpProdCountMap
		f.ExeView(param.SourceTable(prodCountTableName), &tmpProdCountMap)
	}

	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[getFactorJudgeProdCount]调用OneService失败，err=%v+", err)
		return nil, err
	}

	for _, itemProdCountMap := range tableProdCountMap {
		prodCountMap = utils.MergeMapString(&prodCountMap, itemProdCountMap)
	}

	return prodCountMap, nil
}

func getPidListWithDrillDown(ctx context.Context, originPidList []string, baseStruct *analysis_pool_diagnosis.AnalysisPoolDiagnosisBaseStruct, judgeKey string, drillDownFactorList []*analysis_pool_diagnosis.DiagnosisFactorInfo) (pidList []string, err error) {
	allProductId := make([]string, 0)

	judgeConditionList, err := biz_info.GetDiagnosisJudgeConditionList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[getPidListWithDrillDown]调用tcc GetDiagnosisJudgeConditionList失败 err=%v", err)
		return nil, err
	}

	judgeIndicatorValuePrefix := ""
	for _, item := range judgeConditionList {
		if *item.JudgeKey == judgeKey {
			judgeIndicatorValuePrefix = *item.JudgeKeyIndicatorValuePrefix
		}
	}

	baseParams, err := getJudgeProductCountOsParams(ctx, &OsParamsReqStruct{
		StartDate: &baseStruct.StartDate,
		EndDate:   &baseStruct.EndDate,
		App:       baseStruct.App,
	}, originPidList)

	if err != nil {
		logs.CtxError(ctx, "[getPidListWithDrillDown]获取查询os参数失败，err=%v+", err)
		return nil, err
	}

	tableNameList := make([]string, 0)
	tableNameCqlMap := map[string]map[string]interface{}{}
	for _, drillDownFactorItem := range drillDownFactorList {
		if !slices.ContainsString(tableNameList, *drillDownFactorItem.Indicator.TableName) {
			tableNameList = append(tableNameList, *drillDownFactorItem.Indicator.TableName)
		}
	}

	for _, tableName := range tableNameList {
		exprCql := sql_parse.NewCQL()
		selectParams := map[string]interface{}{}
		andConnector := ""
		for _, drillDownFactorItem := range drillDownFactorList {
			indicatorTableName := *drillDownFactorItem.Indicator.TableName
			if indicatorTableName != tableName {
				continue
			}
			drillDownIndicatorKey := *drillDownFactorItem.Indicator.Key
			judgeLogic := drillDownFactorItem.Indicator.JudgeLogic
			judgeCompareConstant := drillDownFactorItem.Indicator.CompareConstant
			judgeNotMatchStatus, isOk := funk.Map(drillDownFactorItem.Indicator.NotMatchStatus, func(x string) string {
				return fmt.Sprintf("'%v'", x)
			}).([]string)
			if !isOk {
				judgeNotMatchStatus = make([]string, 0)
			}
			judgeIndicatorKey := fmt.Sprintf("%v_%v", drillDownIndicatorKey, "result")
			judgeConditionIndicatorKey := fmt.Sprintf("%v_%v_%v", judgeIndicatorValuePrefix, drillDownIndicatorKey, "result")
			if judgeIndicatorKey != "" && judgeLogic != nil {
				if *judgeLogic == JUDGE_LOGIC_STATUS {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v (%v)", andConnector, judgeIndicatorKey, sql_parse.IN, utils.List2String(judgeNotMatchStatus, ",")))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_GT {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.GREATER_THAN, judgeConditionIndicatorKey))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_GE {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.GREATER_EQUAL_THAN, judgeConditionIndicatorKey))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_LT {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.LESS_THAN, judgeConditionIndicatorKey))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_LE {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.LESS_EQUAL_THAN, judgeConditionIndicatorKey))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_THRESHOLD_EQ {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.EQUAL, judgeConditionIndicatorKey))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_GT {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.GREATER_THAN, *judgeCompareConstant))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_GE {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.GREATER_EQUAL_THAN, *judgeCompareConstant))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_LT {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.LESS_THAN, *judgeCompareConstant))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_LE {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.LESS_EQUAL_THAN, *judgeCompareConstant))
					andConnector = "and"
				} else if *judgeLogic == JUDGE_LOGIC_CONSTANT_EQ {
					exprCql.AddRawWhere(fmt.Sprintf("%v %v %v %v", andConnector, judgeIndicatorKey, sql_parse.EQUAL, *judgeCompareConstant))
					andConnector = "and"
				}
			}
		}
		selectParams["judge_filter_params"] = exprCql.ParseRawExpression(exprCql.RawWhereClause)
		selectParams["table_name"] = tableName
		sqlParams := utils.MergeMaps(&selectParams, &baseParams)
		tableNameCqlMap[tableName] = sqlParams
	}

	logs.CtxInfo(ctx, "[getPidListWithDrillDown]查询os api params=%v", tableNameCqlMap)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()

	for tableName, sqlParams := range tableNameCqlMap {
		prodIdTableName := "product_id_" + tableName
		f.ExeQueryInvokerRaw(sqlParams, apiPathJudgeFilterProductId, param.SinkTable(prodIdTableName))
	}

	tableProdIdMap := map[string]*[]string{}
	for tableName, _ := range tableNameCqlMap {
		prodIdTableName := "product_id_" + tableName
		tmpProdIdSlice := make([]string, 0)
		tableProdIdMap[prodIdTableName] = &tmpProdIdSlice
		f.ExeView(param.SourceTable(prodIdTableName), &tmpProdIdSlice)
	}

	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[getPidListWithDrillDown]调用OneService失败，err=%v", err)
		return nil, err
	}

	for _, itemProdCountMap := range tableProdIdMap {
		allProductId = append(allProductId, *itemProdCountMap...)
	}

	pidList = funk.UniqString(allProductId)

	return pidList, nil
}

func getPoolPidList(ctx context.Context, baseStruct *analysis_pool_diagnosis.AnalysisPoolDiagnosisBaseStruct) (pidList []string, err error) {
	params := make(map[string]interface{})
	tmpPidList := make([]string, 0)
	exprCql := sql_parse.NewCQL()
	poolId := baseStruct.PoolId
	pidListStr := baseStruct.ProdIdList
	if pidListStr != nil && *pidListStr != "" {
		tmpPidList = strings.Split(*pidListStr, ",")
	}

	// 货盘id没传 直接使用ProdIdList
	if poolId == nil || *poolId == "" {
		return tmpPidList, nil
	}

	poolIdCql := sql_parse.NewCQL()
	poolIdCql.AddWhere("pool_id", sql_parse.IN, []string{*poolId})
	params["pool_id_param"] = poolIdCql.ParseWhereClause()

	if len(tmpPidList) > 0 {
		exprCql.AddWhere("prod_id", sql_parse.IN, tmpPidList)
	}
	if baseStruct.IndustryId != nil {
		exprCql.AddWhere("industry_id", sql_parse.EQUAL, *baseStruct.IndustryId)
	}
	if baseStruct.LeafCateId != nil {
		exprCql.AddWhere("leaf_cate_id", sql_parse.EQUAL, *baseStruct.LeafCateId)
	}
	filterParamsStr := exprCql.ParseWhereClause()
	if filterParamsStr != "" {
		params["filter_param"] = filterParamsStr
	}

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, apiPathChannelPoolProductId, param.SinkTable("product_id_list"))
	f.ExeView(param.SourceTable("product_id_list"), &pidList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[getPoolPidList]调用OneService失败，err=%v+", err)
		return nil, err
	}
	if len(pidList) > 10000 {
		logs.CtxInfo(ctx, "[getPoolPidList]通过货盘查询商品数量超过1w，限制1w返回，length=%v", len(pidList))
		pidList = pidList[:10000]
	}

	return pidList, nil
}

func getJudgeProductCountOsParams(ctx context.Context, osParamsReqStruct *OsParamsReqStruct, pidList []string) (params map[string]interface{}, err error) {
	params = make(map[string]interface{})

	dateExpr, err := getOsDateExpr(ctx, *osParamsReqStruct.StartDate, *osParamsReqStruct.EndDate)
	if err != nil {
		return nil, err
	}
	params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)

	exprCql := sql_parse.NewCQL()

	if len(pidList) > 0 {
		exprCql.AddWhere("prod_id", sql_parse.IN, pidList)
	}

	params["filter_param"] = exprCql.ParseWhereClause()

	palaceExprCql := sql_parse.NewCQL()
	if osParamsReqStruct.App != nil && *osParamsReqStruct.App != "" {
		palaceExprCql.AddWhere("app_name", sql_parse.EQUAL, *osParamsReqStruct.App)
	}
	params["place_param"] = palaceExprCql.ParseWhereClause()

	return params, nil
}

func getOsDateExpr(ctx context.Context, startDay, endDay string) (dataExpr *sql_parse.Expression, err error) {
	startTime, err := time.Parse(consts.Fmt_Date, startDay)
	if err != nil {
		logs.CtxError(ctx, "[TransformCqlAppendDateExpr]time.Parse startDay = %s Err: %v", startDay, err)
		return nil, err
	}
	endTime, err := time.Parse(consts.Fmt_Date, endDay)
	if err != nil {
		logs.CtxError(ctx, "[TransformCqlAppendDateExpr]time.Parse endDay = %s Err: %v", endDay, err)
		return nil, err
	}

	// 开始进行时间函数解析
	var dateTypeSplitMap map[consts.DateType][]*time_utils.DateSplitResult
	if daysType, ok := ctx.Value(consts.CtxProdPoolTag).(consts.DateType); ok {
		dateTypeSplitMap = time_utils.GetCustomTimeSplit(startTime.Unix(), endTime.Unix(), []consts.DateType{daysType})
	} else {
		dateTypeSplitMap = time_utils.GetCustomTimeSplit(startTime.Unix(), endTime.Unix(), biz_info.GetCtxBizInfoDaysTypeList(ctx))
	}

	dataExpr = &sql_parse.Expression{
		Logic:    sql_parse.OR,
		Children: make([]*sql_parse.Expression, 0),
	}
	for _, splitVList := range dateTypeSplitMap {
		if len(splitVList) == 0 {
			continue
		}

		dates := make([]string, 0)
		for _, v := range splitVList {
			dates = append(dates, v.EndDate)
		}
		tmp := sql_parse.NewCQL()
		tmp.AddWhere("date", sql_parse.IN, dates)
		dataExpr.Children = append(dataExpr.Children, tmp.WhereClause)
	}

	return dataExpr, nil
}

func getIndicatorTableParams(ctx context.Context, indicatorTableParams *IndicatorTableParams) (resp *data_access.IndicatorTableRequest, err error) {
	resp = &data_access.IndicatorTableRequest{}
	currentTime := &data_access.TimeRange{}
	compareTime := &data_access.TimeRange{}
	extraFilter := make([]*data_access.MultiFilter, 0)

	if indicatorTableParams.StartDate != nil {
		currentTime.StartTime, err = time_utils.ParseDateFromStr(*indicatorTableParams.StartDate)
		if err != nil {
			logs.CtxError(ctx, "[getIndicatorTableParams]调用ParseDateFromStr currentTime.StartTime失败 req=%v err=%v", indicatorTableParams, err)
			return nil, err
		}
	}
	if indicatorTableParams.EndDate != nil {
		currentTime.EndTime, err = time_utils.ParseDateEndOfDayFromStr(*indicatorTableParams.EndDate)
		if err != nil {
			logs.CtxError(ctx, "[getIndicatorTableParams]调用ParseDateFromStr currentTime.EndTime失败 req=%v err=%v", indicatorTableParams, err)
			return nil, err
		}
	}
	if indicatorTableParams.CompareStartDate != nil {
		compareTime.StartTime, err = time_utils.ParseDateFromStr(*indicatorTableParams.CompareStartDate)
		if err != nil {
			logs.CtxError(ctx, "[getIndicatorTableParams]调用ParseDateFromStr compareTime.StartTime失败 req=%v err=%v", indicatorTableParams, err)
			return nil, err
		}
	}
	if indicatorTableParams.CompareEndDate != nil {
		compareTime.EndTime, err = time_utils.ParseDateEndOfDayFromStr(*indicatorTableParams.CompareEndDate)
		if err != nil {
			logs.CtxError(ctx, "[getIndicatorTableParams]调用ParseDateFromStr compareTime.EndTime失败 req=%v err=%v", indicatorTableParams, err)
			return nil, err
		}
	}
	if indicatorTableParams.App != nil {
		extraFilter = append(extraFilter, &data_access.MultiFilter{
			FieldName: "app",
			Op:        "=",
			Value:     *indicatorTableParams.App,
			ValueType: "string",
		})
	}
	if indicatorTableParams.PidList != nil {
		extraFilter = append(extraFilter, &data_access.MultiFilter{
			FieldName: "prod_id",
			Op:        "in",
			Value:     *indicatorTableParams.PidList,
			ValueType: "string",
		})
	}

	resp.CurrentTime = currentTime
	resp.CompareTime = compareTime
	resp.Filter = &data_access.Filter{
		ExtraFilter: extraFilter,
	}
	resp.DimensionList = make([]*data_access.DimensionParam, 0)
	resp.DimensionList = append(resp.DimensionList, &data_access.DimensionParam{
		DimensionCode: "prod_id",
	})
	resp.Page = &data_access_common.Page{
		Page:     indicatorTableParams.Page,
		PageSize: indicatorTableParams.PageSize,
	}
	if indicatorTableParams.SortField != nil && indicatorTableParams.SortIsAsc != nil {
		resp.Sort = &data_access_common.Sort{
			Field: *indicatorTableParams.SortField,
			IsAsc: *indicatorTableParams.SortIsAsc,
		}
	}
	return resp, nil
}

func getIndicatorListParams(ctx context.Context, indicatorTableParams *IndicatorTableParams) (resp *data_access.IndicatorListRequest, err error) {
	resp = &data_access.IndicatorListRequest{}

	tabParams, err := getIndicatorTableParams(ctx, indicatorTableParams)
	if err != nil {
		logs.CtxError(ctx, "[getIndicatorListParams]调用getIndicatorTableParams失败 err=%v", err)
		return nil, err
	}

	extraFilter := tabParams.Filter.ExtraFilter

	if indicatorTableParams.PidList != nil {
		tmpPidList := make([]string, 0)
		err := jsoniter.UnmarshalFromString(*indicatorTableParams.PidList, &tmpPidList)
		if err != nil {
			logs.CtxError(ctx, "[getIndicatorListParams]isIndicatorListReq为false json UnmarshalFromString err err=%v", err)
			return nil, err
		}
		// 最大截取前十个
		tmpPidSliceList := make([]string, 0)
		if len(tmpPidList) > 10 {
			tmpPidSliceList = tmpPidList[:10]
		} else {
			tmpPidSliceList = tmpPidList
		}
		pidListStr, err := jsoniter.MarshalToString(&tmpPidSliceList)
		if (err != nil) || (pidListStr == "") {
			logs.CtxError(ctx, "[getIndicatorListParams]isIndicatorListReq为false json marshal err: %v", err)
			return nil, err
		}

		isExistProdIdFilter := false
		for index, item := range extraFilter {
			if item.FieldName == "prod_id" {
				isExistProdIdFilter = true
				extraFilter[index] = &data_access.MultiFilter{
					FieldName: "prod_id",
					Op:        "in",
					Value:     pidListStr,
					ValueType: "string",
				}
			}
		}

		if !isExistProdIdFilter {
			extraFilter = append(extraFilter, &data_access.MultiFilter{
				FieldName: "prod_id",
				Op:        "in",
				Value:     pidListStr,
				ValueType: "string",
			})
		}
	}

	resp.CurrentTime = tabParams.CurrentTime
	resp.CompareTime = tabParams.CompareTime
	resp.Filter = tabParams.Filter
	resp.Filter.ExtraFilter = extraFilter
	return resp, nil
}

func getProdInfoList(ctx context.Context, baseTableParams IndicatorTableParams, requestIndicatorInfoList []*analysis_pool_diagnosis.DiagnosisIndicator) (prodInfoList []*analysis_pool_diagnosis.DiagnosisProductInfo, total int64, err error) {
	total = int64(0)

	requestIndicatorList, mapOk := funk.Map(requestIndicatorInfoList, func(indicatorInfo *analysis_pool_diagnosis.DiagnosisIndicator) string {
		return *indicatorInfo.Key
	}).([]string)
	if !mapOk {
		requestIndicatorList = make([]string, 0)
	}

	indicatorListParams, err := getIndicatorListParams(ctx, &baseTableParams)
	if err != nil {
		logs.CtxError(ctx, "[getProdInfoList]调用getIndicatorTableParams失败 err=%v", err)
		return nil, 0, err
	}

	queryIdIndicatorListMap, err := ecom_smartop_data_access.GetAllQueryIndicatorList(ctx, indicatorListParams)
	if err != nil {
		logs.CtxError(ctx, "[getProdInfoList]调用GetAllQueryIndicatorList失败 indicatorListParams=%v err=%v", indicatorListParams, err)
		return nil, 0, err
	}

	needQueryIdIndicatorListMap := make(map[string][]string)
	allIndicatorMap := make(map[string]*data_access_common.BasicIndicator)
	for queryId, item := range queryIdIndicatorListMap {
		if item != nil && item.Indicators != nil && len(item.Indicators) > 0 {
			for _, item := range item.Indicators {
				if slices.ContainsString(requestIndicatorList, item.Code) {
					needQueryIdIndicatorListMap[queryId] = append(needQueryIdIndicatorListMap[queryId], item.Code)
				}
				if item != nil && item.Code != "" {
					allIndicatorMap[item.Code] = item
				}
			}
		}
	}

	indicatorTableParams, err := getIndicatorTableParams(ctx, &baseTableParams)
	if err != nil {
		logs.CtxError(ctx, "[getProdInfoList]调用getIndicatorTableParams失败 err=%v", err)
		return nil, 0, err
	}

	indicatorTableResp, err := ecom_smartop_data_access.BatchGetIndicatorTable(ctx, needQueryIdIndicatorListMap, indicatorTableParams)

	if err != nil {
		logs.CtxError(ctx, "[getProdInfoList]调用GetIndicatorTable失败 indicatorTableParams=%v err=%v", indicatorTableParams, err)
		return nil, 0, err
	}
	logs.CtxInfo(ctx, "[getProdInfoList]调用GetIndicatorTable indicatorTableResp=%v", indicatorTableResp)

	// 将rpc接口结果转为当前接口输出结果
	productInfoList := make([]*analysis_pool_diagnosis.DiagnosisProductInfo, 0)
	productInfoTabRowList := make([]*data_access.TableRow, 0)
	allTabRow := make([]*data_access.TableRow, 0)
	maxLongTabRow := make([]*data_access.TableRow, 0)
	for _, tableItem := range indicatorTableResp {
		if tableItem != nil && tableItem.Data != nil && len(maxLongTabRow) < len(tableItem.Data.Rows) {
			maxLongTabRow = tableItem.Data.Rows
			if tableItem.Data.Total != nil && *tableItem.Data.Total > total {
				total = *tableItem.Data.Total
			}
		}
	}
	productInfoTabRowList = append(productInfoTabRowList, maxLongTabRow...)

	for queryId, tableItem := range indicatorTableResp {
		if tableItem != nil && tableItem.Data != nil && len(tableItem.Data.Rows) > 0 {
			needQueryIdIndicatorList, ok := needQueryIdIndicatorListMap[queryId]
			// 需要针对 单指标的queryId请求返回数据 做下values的key处理
			if ok && len(needQueryIdIndicatorList) == 1 {
				singleIndicatorRows, ok := funk.Map(tableItem.Data.Rows, func(row *data_access.TableRow) *data_access.TableRow {
					singleIndicatorValues := map[string]*data_access_common.BasicOpValueParam{}
					funk.ForEach(row.Values, func(pKey string, pValue *data_access_common.BasicOpValueParam) {
						if pKey == "value" || pKey == "cmpValue" {
							singKey := fmt.Sprintf("%v.%v", needQueryIdIndicatorList[0], pKey)
							singleIndicatorValues[singKey] = pValue
						} else if pKey == "rateS" || pKey == "rate" {
							singKey := fmt.Sprintf("%v.%v", needQueryIdIndicatorList[0], "rate")
							singleIndicatorValues[singKey] = pValue
						}
					})
					row.Values = singleIndicatorValues
					return row
				}).([]*data_access.TableRow)
				if ok && len(singleIndicatorRows) > 0 {
					allTabRow = append(allTabRow, singleIndicatorRows...)
				}
			} else {
				allTabRow = append(allTabRow, tableItem.Data.Rows...)
			}
		}
	}
	productInfoTabRowList, ok := funk.Map(productInfoTabRowList, func(productInfoTabRowItem *data_access.TableRow) *data_access.TableRow {
		mergeValues := map[string]*data_access_common.BasicOpValueParam{}
		funk.ForEach(productInfoTabRowItem.Values, func(pKey string, pValue *data_access_common.BasicOpValueParam) {
			// 过滤掉prod_id.value
			if pKey != "prod_id.value" {
				mergeValues[pKey] = pValue
			}
		})
		funk.ForEach(allTabRow, func(rowItem *data_access.TableRow) {
			if productInfoTabRowItem != nil && rowItem != nil && *productInfoTabRowItem.Value == *rowItem.Value && productInfoTabRowItem.Values != nil && rowItem.Values != nil {
				funk.ForEach(rowItem.Values, func(pKey string, pValue *data_access_common.BasicOpValueParam) {
					// 过滤掉prod_id.value
					if pKey != "prod_id.value" {
						mergeValues[pKey] = pValue
					}
				})
			}
		})
		productInfoTabRowItem.Values = mergeValues
		return productInfoTabRowItem
	}).([]*data_access.TableRow)
	if !ok {
		logs.CtxError(ctx, "[getProdInfoList]转换productInfoTabRowList失败 productInfoTabRowList=%v", productInfoTabRowList)
		return nil, 0, err
	}

	for _, productInfoTabRowItem := range productInfoTabRowList {
		productInfoNameMap := ProductInfoName{}
		prodId := ""
		prodName := ""
		prodBgUrl := ""
		if productInfoTabRowItem.Name != "" {

			err = json.Unmarshal([]byte(productInfoTabRowItem.Name), &productInfoNameMap)
			if err != nil {
				logs.CtxError(ctx, "[getProdInfoList] json Unmarshal err name=%v err=%v", productInfoTabRowItem.Name, err)
				return nil, 0, err
			}
		}
		if productInfoTabRowItem.Name != "" && productInfoNameMap.IdStr != nil && *productInfoNameMap.IdStr != "" {
			prodId = fmt.Sprintf("%v", *productInfoNameMap.IdStr)
		}
		if productInfoTabRowItem.Name != "" && productInfoNameMap.Name != nil && *productInfoNameMap.Name != "" {
			prodName = fmt.Sprintf("%v", *productInfoNameMap.Name)
		}
		if productInfoTabRowItem.Name != "" && productInfoNameMap.ImgUrl != nil && *productInfoNameMap.ImgUrl != "" {
			prodBgUrl = fmt.Sprintf("%v", *productInfoNameMap.ImgUrl)
		}
		indicatorList := make([]*analysis_pool_diagnosis.IndicatorEntity, 0)
		funk.ForEach(productInfoTabRowItem.Values, func(pKey string, pValue *data_access_common.BasicOpValueParam) {
			curValue := ""
			indicatorKey := ""
			indicatorAbility := ""
			indicatorName := ""
			splitKey := strings.Split(pKey, ".")
			if pValue != nil && pValue.Value != nil {
				curValue = *pValue.Value
			}
			if len(splitKey) > 0 && splitKey[0] != "" {
				indicatorKey = splitKey[0]
			}
			if len(splitKey) > 1 && splitKey[1] != "" {
				indicatorAbility = splitKey[1]
			}
			if allIndicatorMap[indicatorKey] != nil {
				indicatorName = allIndicatorMap[indicatorKey].Name
			}
			// 不在需要请求的指标列表中 不返回
			if !slices.Contains(requestIndicatorList, indicatorKey) {
				return
			}
			curIndicatorInfo, findOk := funk.Find(requestIndicatorInfoList, func(indicatorInfo *analysis_pool_diagnosis.DiagnosisIndicator) bool {
				return *indicatorInfo.Key == indicatorKey
			}).(*analysis_pool_diagnosis.DiagnosisIndicator)
			if !findOk {
				curIndicatorInfo = &analysis_pool_diagnosis.DiagnosisIndicator{}
			}
			findIndicator, findOk := funk.Find(indicatorList, func(indicator *analysis_pool_diagnosis.IndicatorEntity) bool {
				return indicator.Name == indicatorKey
			}).(*analysis_pool_diagnosis.IndicatorEntity)
			if findIndicator != nil && findOk {
				tmpIndicatorList, isOk := funk.Map(indicatorList, func(indicator *analysis_pool_diagnosis.IndicatorEntity) *analysis_pool_diagnosis.IndicatorEntity {
					if indicator.Name == indicatorKey && indicatorAbility == "value" {
						return &analysis_pool_diagnosis.IndicatorEntity{
							Name:          indicatorKey,
							DisplayName:   indicatorName,
							Group:         curIndicatorInfo.Group,
							Priority:      curIndicatorInfo.Priority,
							Value:         curValue,
							OpCode:        pValue.OpCode,
							DataType:      pValue.DataType,
							CycleValue:    indicator.CycleValue,
							CycleOpCode:   indicator.CycleOpCode,
							CycleDataType: indicator.CycleDataType,
						}
					}
					if indicator.Name == indicatorKey && indicatorAbility == "rate" {
						return &analysis_pool_diagnosis.IndicatorEntity{
							Name:          indicatorKey,
							DisplayName:   indicatorName,
							Group:         curIndicatorInfo.Group,
							Priority:      curIndicatorInfo.Priority,
							Value:         indicator.Value,
							OpCode:        indicator.OpCode,
							DataType:      indicator.DataType,
							CycleValue:    curValue,
							CycleOpCode:   pValue.OpCode,
							CycleDataType: pValue.DataType,
						}
					}
					return indicator
				}).([]*analysis_pool_diagnosis.IndicatorEntity)
				if !isOk {
					tmpIndicatorList = indicatorList
				}
				indicatorList = tmpIndicatorList
			} else {
				if indicatorAbility == "value" {
					indicatorList = append(indicatorList, &analysis_pool_diagnosis.IndicatorEntity{
						Name:        indicatorKey,
						DisplayName: indicatorName,
						Group:       curIndicatorInfo.Group,
						Priority:    curIndicatorInfo.Priority,
						Value:       curValue,
						OpCode:      pValue.OpCode,
						DataType:    pValue.DataType,
					})
				}
				if indicatorAbility == "rate" {
					indicatorList = append(indicatorList, &analysis_pool_diagnosis.IndicatorEntity{
						Name:          indicatorKey,
						DisplayName:   indicatorName,
						Group:         curIndicatorInfo.Group,
						Priority:      curIndicatorInfo.Priority,
						CycleValue:    curValue,
						CycleOpCode:   pValue.OpCode,
						CycleDataType: pValue.DataType,
					})
				}
			}
		})

		productInfoList = append(productInfoList, &analysis_pool_diagnosis.DiagnosisProductInfo{
			ProdId:              &prodId,
			ProdName:            &prodName,
			ProdBgUrl:           &prodBgUrl,
			IndicatorEntityList: indicatorList,
		})
	}
	logs.CtxInfo(ctx, "[getProdInfoList]结果 productInfoList=%v, total=%v", productInfoList, total)

	return productInfoList, total, nil
}
