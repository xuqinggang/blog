package analysis_pool_diagnosis_service

const (
	// 搜索场景
	SCENE_SEARCH = "search"
	// 猜喜场景
	SCENE_GYL = "gyl"

	// 指标判定逻辑--状态比对
	JUDGE_LOGIC_STATUS = "status_judge"
	// 指标判定逻辑--阈值比较 大于
	JUDGE_LOGIC_THRESHOLD_GT = "threshold_gt_compare"
	// 指标判定逻辑--阈值比较 大于等于
	JUDGE_LOGIC_THRESHOLD_GE = "threshold_ge_compare"
	// 指标判定逻辑--阈值比较 小于
	JUDGE_LOGIC_THRESHOLD_LT = "threshold_lt_compare"
	// 指标判定逻辑--阈值比较 小于等于
	JUDGE_LOGIC_THRESHOLD_LE = "threshold_le_compare"
	// 指标判定逻辑--阈值比较 等于
	JUDGE_LOGIC_THRESHOLD_EQ = "threshold_eq_compare"
	// 指标判定逻辑--常量比较 大于
	JUDGE_LOGIC_CONSTANT_GT = "constant_gt_compare"
	// 指标判定逻辑--常量比较 大于等于
	JUDGE_LOGIC_CONSTANT_GE = "constant_ge_compare"
	// 指标判定逻辑--常量比较 小于
	JUDGE_LOGIC_CONSTANT_LT = "constant_lt_compare"
	// 指标判定逻辑--常量比较 小于等于
	JUDGE_LOGIC_CONSTANT_LE = "constant_le_compare"
	// 指标判定逻辑--常量比较 等于
	JUDGE_LOGIC_CONSTANT_EQ = "constant_eq_compare"

	// 频道核心货盘商品查询
	apiPathChannelPoolProductId = "7414013296409461769"
	// 搜索商品信息判定异常商品数量查询
	apiPathMainInfoJudgeProductCount = "7411366505822045211"
	// 搜索核心指标判定异常商品数量查询
	apiPathMainIndicatorJudgeProductCount = "7410398001987879962"
	// 搜索诊断获取判定后商品id
	apiPathJudgeFilterProductId = "7418085890418820133"
	// 搜索诊断获取判定后商品数量
	apiPathJudgeFilterProductCount = "7418173024190415899"
)
