package activity_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"context"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"strings"

	"code.byted.org/bytedoc/mongo-go-driver/bson"
	mongo_util "code.byted.org/ecom/smartop_product_analysis/biz/dal/mongo"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/gopkg/logs/v2"
)

func SubmitJupyterTask(ctx context.Context, request *activity_review.CreateActivityReviewRequest, requestBody []byte, jupyter_task_id string) (businessId string, err error) {
	baseURL := "https://openapi-dp.byted.org/openapi/dorado/task/115271324/trigger_run"

	mClient := mongo_util.GetClient()
	defer mClient.Disconnect(context.Background())

	// 检查是够已经有对应的任务，如果有，且任务状态正常（任务运行中或者成功），则直接返回； 否则尝试触发任务
	jupyterColl := mClient.Database(mongo_util.DB_NAME).Collection(mongo_util.COLLECTION_JUPYTER_TASK)
	var jupyterTask JupyterTask
	single := jupyterColl.FindOne(context.Background(), bson.M{"task_id": jupyter_task_id})
	err1 := single.Decode(&jupyterTask)
	if err1 != nil {
		logs.CtxError(ctx, "[SubmitJupyterTask] get jupyter task error, err=%v", err1)
	}
	if jupyterTask.BusinessId != "" && IsJupyterTaskAlive(jupyterTask.Status) {
		businessId = jupyterTask.BusinessId
		return
	}

	// 创建 HTTP POST 请求
	req, err := http.NewRequest("POST", baseURL, strings.NewReader(string(requestBody)))
	if err != nil {
		logs.CtxError(ctx, "[SubmitJupyterTask] create http request error, err=%v", err)
		return
	}
	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("authorization", biz_info.GetActiveDoradoToken(ctx))
	client := &http.Client{}
	res, err := client.Do(req)
	if err != nil {
		logs.CtxError(ctx, "[SubmitJupyterTask] send http request error, err=%v", err)
		return
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		logs.CtxError(ctx, "[SubmitJupyterTask] read http response error, err=%v", err)
		return
	}
	var jupyterRes JupyterRes
	err = json.Unmarshal(body, &jupyterRes)
	if err != nil {
		logs.CtxError(ctx, "[SubmitJupyterTask] unmarshal http response error, err=%v", err)
		return
	}

	businessId = jupyterRes.Data.BusinessId

	var reqStr []byte
	if jupyterTask.BusinessId != "" {
		// 如果之前已经有任务了，更新任务的businessId和instanceId，之后更新任务状态
		jupyterColl.UpdateOne(context.Background(), bson.M{"task_id": jupyter_task_id}, bson.M{"$set": bson.M{
			"business_id": jupyterRes.Data.BusinessId,
			"instance_id": jupyterRes.Data.InstanceId,
			"status":      JUPYTER_TASK_STATUS_NOT_READY,
		}})
		UpdateJupyterTaskStatus(ctx, jupyter_task_id)
	} else {
		reqStr, err = json.Marshal(request.Query)
		if err != nil {
			logs.CtxError(ctx, "[SubmitJupyterTask] save jupyter task marshal request error, err=%v", err)
			return
		}
		jupyterTask = JupyterTask{
			TaskId:      jupyter_task_id,
			Status:      JUPYTER_TASK_STATUS_NOT_READY,
			BusinessId:  jupyterRes.Data.BusinessId,
			InstanceId:  jupyterRes.Data.InstanceId,
			QueryString: string(reqStr),
		}
		jupyterColl.InsertOne(context.Background(), bson.M{
			"task_id":      jupyter_task_id,
			"status":       JUPYTER_TASK_STATUS_NOT_READY,
			"business_id":  jupyterRes.Data.BusinessId,
			"instance_id":  jupyterRes.Data.InstanceId,
			"query_string": string(reqStr),
		})
	}

	var str = ""
	BatchUpdateBizStatus(ctx, jupyterTask, &str)

	return
}
