package activity_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"

	"code.byted.org/bytedoc/mongo-go-driver/bson"
	mongo_util "code.byted.org/ecom/smartop_product_analysis/biz/dal/mongo"
	"code.byted.org/gopkg/logs"
)

const MAX_RETRY_CNT = 5

const RETRY_TIME_INTERVAL = time.Duration(20)

func HandleFreshActivityReview(ctx context.Context, req *activity_review.FreshActivityReviewProgressRequest, retryCnt int) (err error) {
	taskId := req.TaskId
	var task JupyterTask
	task, err = UpdateJupyterTaskStatus(ctx, taskId)
	if err != nil {
		return
	}

	// 如果状态仍旧处于运行中，则在3分钟后重新发起请求
	// 如果状态已经结束，则更新任务状态
	if IsJupyterTaskAlive(task.Status) {
		if retryCnt > MAX_RETRY_CNT {
			return
		} else {
			newCnt := retryCnt + 1

			go func() {
				defer func() {
					if err := recover(); err != nil {
						logs.CtxError(ctx, "[HandleFreshActivityReview] panic while handle retry: %v", err)
					}
				}()

				time.Sleep(RETRY_TIME_INTERVAL * time.Second)
				logs.CtxInfo(ctx, fmt.Sprintf(`Retry for task %s, retry cnt is %d`, taskId, newCnt))
				HandleFreshActivityReview(ctx, req, newCnt)
			}()
		}
		return
	}

	BatchUpdateBizStatus(ctx, task, req.ErrorMsg)
	return
}

// 更新jupyter任务状态
func UpdateJupyterTaskStatus(ctx context.Context, jupyter_task_id string) (jupyterTask JupyterTask, err error) {
	baseURL := "https://openapi-dp.byted.org/openapi/dorado/instance/details"

	mClient := mongo_util.GetClient()
	defer mClient.Disconnect(context.TODO())

	coll := mongo_util.GetClient().Database(mongo_util.DB_NAME).Collection(mongo_util.COLLECTION_JUPYTER_TASK)
	record := coll.FindOne(context.Background(), bson.M{"task_id": jupyter_task_id})
	err = record.Decode(&jupyterTask)
	if err != nil {
		logs.CtxError(ctx, "[UpdateJupyterTaskStatus] get jupyter task error, err=%v", err)
		return
	}
	if jupyterTask.BusinessId == "" {
		logs.CtxInfo(ctx, "[UpdateJupyterTaskStatus] get jupyter but bussiness was empty")
		return
	}

	reqURL, err := url.Parse(baseURL)
	if err != nil {
		logs.CtxError(ctx, "[UpdateJupyterTaskStatus] parse url error, err=%v", err)
		return
	}
	params := url.Values{}
	params.Add("businessId", jupyterTask.BusinessId)
	params.Add("taskId", DoradoTaskId)
	reqURL.RawQuery = params.Encode()

	req, err := http.NewRequest("GET", reqURL.String(), nil)
	if err != nil {
		logs.CtxError(ctx, "[UpdateJupyterTaskStatus] create new request error, err=%v", err)
		return
	}
	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("authorization", biz_info.GetActiveDoradoToken(ctx))
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		logs.CtxError(ctx, "[UpdateJupyterTaskStatus] do request error, err=%v", err)
		return
	}
	defer resp.Body.Close()

	// 读取响应体
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logs.CtxError(ctx, "[UpdateJupyterTaskStatus] read response body error, err=%v", err)
		return
	}

	var statusRes TaskStatusResp
	err = json.Unmarshal(body, &statusRes)
	if err != nil {
		logs.CtxError(ctx, "[UpdateJupyterTaskStatus] unmarshal response body error, err=%v", err)
		return
	}

	if len(statusRes.Data) == 0 {
		logs.CtxInfo(ctx, "[UpdateJupyterTaskStatus] get jupyter task status error")
		return
	}

	status := statusRes.Data[0].Status
	jupyterTask.Status = status
	_, err = coll.UpdateOne(ctx, bson.M{"task_id": jupyter_task_id}, bson.M{"$set": bson.M{"status": status}})
	if err != nil {
		logs.CtxError(ctx, "[UpdateJupyterTaskStatus] update jupyter task status error, err=%v", err)
	}
	return
}
