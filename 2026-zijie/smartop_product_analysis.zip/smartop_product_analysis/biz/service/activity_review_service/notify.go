package activity_review_service

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"code.byted.org/gopkg/logs"

	"code.byted.org/bytedoc/mongo-go-driver/bson"
	mongo_util "code.byted.org/ecom/smartop_product_analysis/biz/dal/mongo"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"

	lark "github.com/larksuite/oapi-sdk-go/v3"
	larkim "github.com/larksuite/oapi-sdk-go/v3/service/im/v1"
)

// 批量更新 jupyter 任务对应的业务任务状态
func BatchUpdateBizStatus(ctx context.Context, jupyterTask JupyterTask, errMsg *string) {

	mClient := mongo_util.GetClient()
	defer mClient.Disconnect(context.Background())
	coll := mongo_util.GetClient().Database(mongo_util.DB_NAME).Collection(mongo_util.COLLECTION_BIZ_TASK)

	var task BizTask

	cursor, err := coll.Find(context.Background(), bson.M{"jupyter_task_id": jupyterTask.TaskId})
	if err != nil {
		logs.CtxError(ctx, "[BatchUpdateBizStatus] error find biz task for jupyter task id: %s，err=%v+", jupyterTask.TaskId, err)
		return
	}

	// 向管理员群组发送消息
	err = SendNotifyToAdminGroup(ctx, jupyterTask)

	// 更新任务状态
	for cursor.Next(context.Background()) {
		cursor.Decode(&task)
		if task.UserEmail != "" {
			if errMsg == nil {
				SendTaskStatus(ctx, task, jupyterTask.Status)
			} else {
				SendTaskStatusWithErrMsg(ctx, task, jupyterTask.Status, *errMsg)
			}
		}
	}

	if err != nil {
		logs.CtxError(ctx, "[BatchUpdateBizStatus] 批量发送消息时出现错误，err=%v+", err)
	}

	return
}

type TaskProgressInfo struct {
	TaskName  string
	Status    JupyterStatus
	JupyterId string
	ErrMsg    string
}

type TaskMessage struct {
	Theme    string
	Title    string
	TaskDesc string
}

// 根据信息拼接通知消息
func createErrMsg(ctx context.Context, errInfo TaskProgressInfo) (content string, err error) {
	allMsgs, err := biz_info.GetActivityReviewLarkMsg(ctx)
	if err != nil {
		logs.CtxError(ctx, "[createErrMsg] get lark message template tcc config error，err=%v", err)
		return
	}

	var taskMsg map[string]string
	switch errInfo.Status {
	case JUPYTER_TASK_STATUS_NOT_READY:
		taskMsg = allMsgs["create"]
	case JUPYTER_TASK_STATUS_SUCCEED:
		taskMsg = allMsgs["success"]
	case JUPYTER_TASK_STATUS_FAILED, JUPYTER_TASK_STATUS_ABORTED:
		taskMsg = allMsgs["fail"]
	default:
		return
	}

	if taskMsg == nil {
		err = fmt.Errorf("[createErrMsg] 缺少必要的配置")
		return
	}

	taskMsg["err_msg"] = errInfo.ErrMsg

	b := map[string]interface{}{
		"type": "template",
		"data": map[string]interface{}{
			"template_id":       "AAq0mfNoGPVzf",
			"template_variable": taskMsg,
		},
	}

	bytes, err := json.Marshal(b)
	if err != nil {
		logs.CtxError(ctx, "[createErrMsg] create lark notify message error，err=%v", err)
		return
	}
	content = strings.ReplaceAll(
		strings.ReplaceAll(
			string(bytes), "{task_name}", errInfo.TaskName),
		"{task_id}", errInfo.JupyterId)

	return
}

func SendNotifyToAdminGroup(ctx context.Context, task JupyterTask) (err error) {

	status, jupyter_id := task.Status, task.TaskId
	if status != JUPYTER_TASK_STATUS_SUCCEED {
		// 如果状态不是成功就不执行后续的通知动作了
		return
	}
	mClient := mongo_util.GetClient()
	defer mClient.Disconnect(context.Background())
	coll := mClient.Database(mongo_util.DB_NAME).Collection(mongo_util.COLLECTION_BIZ_TASK)

	cursor, err := coll.Find(context.Background(), bson.M{"jupyter_task_id": jupyter_id})
	if err != nil {
		logs.CtxError(ctx, "[SendNotifyToAdminGroup] get biz task info error，err=%v", err)
		return
	}

	users := make([][]string, 0)

	var bizTask BizTask
	for cursor.Next(context.Background()) {
		decodeErr := cursor.Decode(&bizTask)
		if decodeErr != nil {
			logs.CtxError(ctx, "[SendNotifyToAdminGroup] decode biz task error，err=%v", decodeErr)
		} else {
			users = append(users, []string{bizTask.UserEmail, bizTask.TaskDesc})
		}
	}

	userStr := ""

	for _, user := range users {
		taskName := user[1]
		if taskName == "" {
			taskName = "未命名任务"
		}
		userStr += fmt.Sprintf("<at email=%s></at> 任务名称：%s\n", user[0], taskName)
	}

	content, err := json.Marshal(map[string]interface{}{
		"type": "template",
		"data": map[string]interface{}{
			"template_id": "AAq0mfNoGPVzf",
			"template_variable": map[string]string{
				"theme": "green",
				"title": "活动复盘 - 分析任务成功",
				"desc":  "*分析结果有效期为30天，请及时查看数据*",
				"info_detail": fmt.Sprintf(
					"活动复盘分析任务完成，请前往[复盘结果页](https://ecop.bytedance.net/dikar-platform/activity-review/result?task_id=%s)查看结果。\n %s",
					task.TaskId, userStr,
				),
			},
		},
	})

	if err != nil {
		logs.CtxError(ctx, "[SendNotifyToAdminGroup] marshal lark notify message error，err=%v", err)
		return
	}
	larkAuth, err := biz_info.GetLarkOpenAuth(ctx)

	if err != nil {
		logs.CtxError(ctx, "[SendNotifyToAdminGroup] get lark auth info tcc config error，err=%v", err)
		return
	}

	appId := larkAuth["app_id"]
	secretKey := larkAuth["secret_token"]

	client := lark.NewClient(appId, secretKey)
	req := larkim.NewCreateMessageReqBuilder().
		ReceiveIdType(`chat_id`).
		Body(larkim.NewCreateMessageReqBodyBuilder().
			ReceiveId("oc_4fac7b3f30e6c812a4e617bbb57a19ef").
			MsgType(`interactive`).
			Content(string(content)).
			Build()).
		Build()

	client.Im.Message.Create(context.Background(), req)

	return
}

func SendTaskStatus(ctx context.Context, task BizTask, status JupyterStatus) (err error) {
	return SendTaskStatusWithErrMsg(ctx, task, status, "")
}

func SendTaskStatusWithErrMsg(ctx context.Context, task BizTask, status JupyterStatus, errMsg string) (err error) {

	mClient := mongo_util.GetClient()
	defer mClient.Disconnect(context.Background())

	notified := (task.NotifyStatus >> int32(status)) & 1
	if notified == 1 {
		return
	}

	taskName := task.TaskDesc
	if taskName == "" {
		taskName = "未命名任务"
	}
	content, err := createErrMsg(ctx, TaskProgressInfo{
		TaskName:  taskName,
		Status:    status,
		JupyterId: task.JupyterTaskId,
		ErrMsg:    errMsg,
	})

	if err != nil {
		logs.CtxError(ctx, "[SendTaskStatus] create lark notify message error，err=%v", err)
		return
	}

	larkAuth, err := biz_info.GetLarkOpenAuth(ctx)

	if err != nil {
		logs.CtxError(ctx, "[SendTaskStatusWithErrMsg] get lark auth info tcc config error，err=%v", err)
		return
	}

	appId := larkAuth["app_id"]
	secretKey := larkAuth["secret_token"]
	// 创建 Client
	client := lark.NewClient(appId, secretKey)

	// 创建请求对象
	req := larkim.NewCreateMessageReqBuilder().
		ReceiveIdType(`email`).
		Body(larkim.NewCreateMessageReqBodyBuilder().
			ReceiveId(task.UserEmail).
			MsgType(`interactive`).
			Content(content).
			Build()).
		Build()

	// 发起请求
	resp, err := client.Im.Message.Create(context.Background(), req)

	// 处理错误
	if err != nil || !resp.Success() {
		logs.CtxError(ctx, "send lark message error，err=%v+", err)
		return
	}

	coll := mClient.Database(mongo_util.DB_NAME).Collection(mongo_util.COLLECTION_BIZ_TASK)
	coll.FindOneAndUpdate(context.Background(), bson.M{"task_id": task.TaskId}, bson.M{"$set": bson.M{"notify_status": task.NotifyStatus | (1 << int32(status))}})

	// 业务处理
	return
}
