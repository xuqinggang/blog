package activity_review_service

import (
	"encoding/json"
	"strings"
)

const (
	EffectModuleSupplyProgress = "供给进度"
)

const (
	ApiGetActivityAnalysisResult                       = "7389562973800399910"
	DoradoTaskId                                       = "115271324"
	ApiPathActivityTime                                = "7424557016183489586"
	ApiPathBigPromotionSupplyProgress                  = "7424791744555926555"
	ApiPathBigPromotionProductMultiAnalysis            = "7429280581491508274"
	ApiPathBigPromotionProductAAAnalysis               = "7429280582212879370"
	ApiPathBigPromotionProductAAAnalysisForBase        = "7437493259980604453"
	ApiPathBigPromotionProductABAnalysisForNonActivity = "7441786463345312794"
	ApiPathActivityReviewOverallProductAnalysis        = "7434055653842338826"
	ApiPathBigPromotionSupplyProductAnalysis           = "7436717457793893403"
)

// 如果为空则返回0
func fallbackZero(v interface{}) interface{} {
	switch t := v.(type) {
	case int:
		return t
	case string:
		if v != nil && len(v.(string)) > 0 {
			return v
		}
		return 0
	}
	return v
}

// 转换boolean 为 0/1
func toBoolStr(v *bool) string {
	if v != nil && *v {
		return "1"
	}

	return "0"
}

// 处理list参数 兜底值也是0
func HandleListParam(l []string) interface{} {
	if l != nil && len(l) > 0 {
		jsonBuf, err := json.Marshal(l)
		if err == nil {
			return strings.Replace(strings.Replace(string(jsonBuf), "'", "\\'", -1), "\"", "'", -1)
		}
	}
	return (0)
}

type JupyterStatus int

const (
	JUPYTER_TASK_STATUS_UNKNOWN JupyterStatus = iota
	JUPYTER_TASK_STATUS_NOT_READY
	JUPYTER_TASK_STATUS_PENDING
	JUPYTER_TASK_STATUS_RUNNING
	JUPYTER_TASK_STATUS_SUCCEED
	JUPYTER_TASK_STATUS_FAILED
	JUPYTER_TASK_STATUS_ABORTED
)

var ALIVE_JUPYTER_TASK_STATUS = []JupyterStatus{
	JUPYTER_TASK_STATUS_NOT_READY,
	JUPYTER_TASK_STATUS_PENDING,
	JUPYTER_TASK_STATUS_RUNNING,
}

func IsJupyterTaskAlive(status JupyterStatus) bool {
	for _, v := range ALIVE_JUPYTER_TASK_STATUS {
		if v == status {
			return true
		}
	}
	return false
}

type BizTask struct {
	UserId        int64  `bson:"user_id"`
	UserEmail     string `bson:"user_email"`
	TaskDesc      string `bson:"task_desc"`
	JupyterTaskId string `bson:"jupyter_task_id"`
	TaskId        string `bson:"task_id"`
	NotifyStatus  int32  `bson:"notify_status"`
}

type JupyterTask struct {
	TaskId      string        `bson:"task_id"`
	BusinessId  string        `bson:"business_id"`
	InstanceId  int64         `bson:"instance_id"`
	Status      JupyterStatus `bson:"status"`
	QueryString string        `bson:"query_string"`
}

type JupyterRes struct {
	Code      int32          `json:"code"`
	Message   string         `json:"message"`
	Data      JupyterResData `json:"data"`
	SkipCodes *string        `json:"skipCodes"`
}

type JupyterResData struct {
	IsOk       bool    `json:"isOk"`
	TaskId     int32   `json:"taskId"`
	BusinessId string  `json:"businessId"`
	InstanceId int64   `json:"instanceId"`
	Message    *string `json:"message"`
}

type TaskStatus struct {
	Status JupyterStatus `json:"status"`
}
type TaskStatusResp struct {
	Data []TaskStatus `json:"data"`
}
