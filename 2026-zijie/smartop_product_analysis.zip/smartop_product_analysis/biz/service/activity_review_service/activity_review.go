package activity_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"context"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"code.byted.org/bytedoc/mongo-go-driver/bson"
	mongo_util "code.byted.org/ecom/smartop_product_analysis/biz/dal/mongo"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/gopkg/logs"
	"github.com/pborman/uuid"
)

type IActivityReviewService interface {
	GetActivityReviewResult(ctx context.Context, taskId string) (resp []*activity_review.ActivityReviewResultItem, err error)
	GetJupyterTaskQueryInfo(ctx context.Context, taskId string) (resp string, err error)
	CreateActivityReview(ctx context.Context, req *activity_review.CreateActivityReviewRequest) (err error, task_id string)
	FreshActivityReview(ctx context.Context, req *activity_review.FreshActivityReviewProgressRequest) (err error)
	GetProductSupplyProgress(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct) (*activity_review.GetActivityReviewProductSupplyProgressData, error)
	GetProductAnalysis(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct) (*activity_review.GetActivityReviewProductAnalysisData, error)
	GetProductAAAnalysis(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct) (*activity_review.GetActivityReviewProductAnalysisData, error)
	GetActivityAndNonActivityProductABAnalysis(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct) (*activity_review.GetActivityReviewProductAnalysisData, error)
}

type ActivityReviewService struct {
	DimensionListDao        dao.IDimensionListDao
	DimensionService        dimension_service.IDimensionService
	ActivityReviewSupplyDao dao.IActivityReviewSupplyDao
}

type StrType struct {
	TaskId string `bson:"task_id"`
	Type   string `bson:"type"`
	Result string `bson:"result"`
}
type BsonType struct {
	TaskId string `bson:"task_id"`
	Type   string `bson:"type"`
	Result bson.M `bson:"result"`
}

func (d *ActivityReviewService) FreshActivityReview(ctx context.Context, req *activity_review.FreshActivityReviewProgressRequest) (err error) {
	return HandleFreshActivityReview(ctx, req, 0)
}

// 创建分析任务
func (d *ActivityReviewService) CreateActivityReview(ctx context.Context, request *activity_review.CreateActivityReviewRequest) (err error, task_id string) {
	user := utils.GetUserInfo(ctx)
	if user == nil || user.Id == nil || user.Email == nil {
		return errors.New("[CreateActivityReview] Can not get user info"), ""
	}

	// 生成业务任务ID
	bizTaskId := uuid.NewUUID().String()

	query := request.Query
	run_date := time.Now().Format("2006-01-02")
	productDims := query.ProductDim
	if productDims == nil {
		productDims = &activity_review.ProductDim{}
	}

	taskDesc := ""
	if query.TaskDesc != nil {
		taskDesc = *query.TaskDesc
	}
	commonParams := map[string]interface{}{
		"run_date":                         run_date,
		"_task_desc":                       taskDesc,
		"activity_tag":                     query.ActivityTag,
		"activity_sub_tag":                 query.ActivitySubTag,
		"activity_id":                      fallbackZero(query.ActivityId),
		"activity_start_pdate":             query.ActivityStartPdate,
		"activity_end_pdate":               query.ActivityEndPdate,
		"is_new_signup":                    toBoolStr(productDims.IsNewSignup),
		"has_subsidy":                      toBoolStr(productDims.HasSubsidy),
		"first_level_cate_name":            HandleListParam(productDims.FirstLevelCateName),
		"complex_brand_s_level":            HandleListParam(productDims.ComplexBrandSLevel),
		"is_sup_purchase_3k_prod":          toBoolStr(productDims.IsSupPurchase_3kProd),
		"is_sup_purchase_k300_prod":        toBoolStr(productDims.IsSupPurchaseK300Prod),
		"is_super_subsidy_white_prod":      toBoolStr(productDims.IsSuperSubsidyWhiteProd),
		"compare_start_pdate":              query.CompareStartPdate,
		"compare_end_pdate":                query.CompareEndPdate,
		"positive_target_channel":          query.PositiveTargetChannel,
		"positive_target_matrix":           query.PositiveTargetMatrix,
		"positive_target_matrix_threshold": query.PositiveTargetMatrixThreshold,
		"product_id_list":                  HandleListParam(query.ProductIdList),
	}
	// 首先使用通用的参数生成任务ID
	requestBody, err := json.Marshal(commonParams)
	if err != nil {
		logs.CtxError(ctx, "[CreateActivityReview] marshal common params for task id generation, err=%v", err)
		return
	}
	hash := md5.Sum([]byte(string(requestBody)))
	task_id = hex.EncodeToString(hash[:])

	// 拼出来完整的请求参数，并发起请求
	commonParams["task_id"] = task_id
	requestBody, err = json.Marshal(map[string]interface{}{
		"params": commonParams,
	})
	if err != nil {
		logs.CtxError(ctx, "[CreateActivityReview] marshal request params err, err=%v", err)
		fmt.Println("Error:", err)
		return
	}

	mClient := mongo_util.GetClient()
	defer mClient.Disconnect(context.Background())

	_, err = SubmitJupyterTask(ctx, request, requestBody, task_id)

	if err != nil {
		logs.CtxError(ctx, "[CreateActivityReview] submit jupyter task error, err=%v", err)
		return
	}
	collection := mClient.Database(mongo_util.DB_NAME).Collection(mongo_util.COLLECTION_BIZ_TASK)
	collection.InsertOne(context.Background(), bson.M{
		"user_id":         *user.Id,
		"user_email":      *user.Email,
		"task_desc":       taskDesc,
		"task_id":         bizTaskId,
		"jupyter_task_id": task_id,
		"status":          0,
	})

	SendTaskStatus(ctx, BizTask{
		UserId:        *user.Id,
		UserEmail:     *user.Email,
		TaskDesc:      taskDesc,
		JupyterTaskId: task_id,
		TaskId:        bizTaskId,
		NotifyStatus:  0,
	}, JUPYTER_TASK_STATUS_NOT_READY)

	return
}

func (d *ActivityReviewService) GetJupyterTaskQueryInfo(ctx context.Context, taskId string) (resp string, err error) {
	client := mongo_util.GetClient()
	defer client.Disconnect(context.Background())

	jupyterColl := client.Database(mongo_util.DB_NAME).Collection(mongo_util.COLLECTION_JUPYTER_TASK)
	cursor := jupyterColl.FindOne(context.Background(), bson.M{
		"task_id": taskId,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetJupyterTaskQueryInfo] get jupyter task info error, err=%v", err)
		return
	}

	var jupyterInfo JupyterTask
	cursor.Decode(&jupyterInfo)
	resp = jupyterInfo.QueryString
	return
}
func (d *ActivityReviewService) GetActivityReviewResult(ctx context.Context, taskId string) (resp []*activity_review.ActivityReviewResultItem, err error) {
	client := mongo_util.GetClient()
	defer client.Disconnect(context.Background())

	coll := client.Database(mongo_util.DB_NAME).Collection(mongo_util.COLLECTION_RESULT)
	cursor, err := coll.Find(
		context.Background(),
		bson.M{
			"task_id": taskId,
		})
	if err != nil {
		logs.CtxError(ctx, "[GetActivityReviewResult] error occurred while find results for task %s, err=%v", taskId, err)
		return
	}

	for cursor.Next(context.Background()) {
		var item BsonType

		decodeErr := cursor.Decode(&item)
		if decodeErr == nil && item.Result != nil {
			result_json, err := json.Marshal(item.Result)
			if err != nil {
				logs.CtxError(ctx, "[GetActivityReviewResult] error occurred while marshal result as BSON_TYPE for task %s type %s, err=%v", taskId, item.Type, err)
			} else {
				resp = append(resp, &activity_review.ActivityReviewResultItem{
					Type:    item.Type,
					Result_: string(result_json),
				})
			}
		} else {
			var item StrType
			decodeErr := cursor.Decode(&item)

			if decodeErr == nil {
				resp = append(resp, &activity_review.ActivityReviewResultItem{
					Type:    item.Type,
					Result_: item.Result,
				})
			} else {
				logs.CtxError(ctx, "[GetActivityReviewResult] error occurred while marshal result as STRING_TYPE for task %s type %s, err=%v", taskId, item.Type, err)
			}
		}
	}

	return resp, nil
}
