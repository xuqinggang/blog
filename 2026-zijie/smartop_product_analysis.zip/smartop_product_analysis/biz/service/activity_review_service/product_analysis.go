package activity_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"strings"
)

var TotalEnumValue = "不被匹配的整体"

func (d *ActivityReviewService) GetProductAnalysis(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct) (resp *activity_review.GetActivityReviewProductAnalysisData, err error) {
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	// 获取业务线的维度信息
	dimMap, dimColMap, err := biz_utils.GetDimMapAndColMapByBiz(ctx, req.BizType)
	if err != nil {
		return nil, err
	}
	//var prodCodeTagBaseDims = make([]*dimensions.SelectedDimensionInfo, 0)

	// 获取分析的维度信息
	groupCols := make([]string, 0)
	dimColEnumCodeMap := make(map[string]map[string]string)
	if len(req.GroupAttrs) > 0 {
		for _, attr := range req.GroupAttrs {
			req.Dimensions = append(req.Dimensions, attr.DimInfo)

			// 获取维度的查询字段名
			dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
			if dimInfo == nil {
				logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
				return resp, errors.New("未查询到维度信息")
			}
			groupCols = append(groupCols, dimInfo.DimColumn)
			//prodCodeTagBaseDims = append(prodCodeTagBaseDims, attr.DimInfo)
			// 查询该维度的枚举值
			if len(attr.DimInfo.SelectedValues) > 0 {
				enumCodeMap := make(map[string]string)
				for _, enum := range attr.DimInfo.SelectedValues {
					enumCodeMap[enum.Code] = enum.Name
				}
				dimColEnumCodeMap[dimInfo.DimColumn] = enumCodeMap
			}
		}
	}
	// 获取invoker的入参
	osParamsReq := base_struct_condition.BigPromotionReviewOsParamsReq{
		BaseStruct:     req,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: groupCols,
	}
	curr, _, _, err := base_struct_condition.GetBigPromotionReviewBaseStructConditionParams(ctx, osParamsReq, 0b001)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return nil, err
	}
	err = setAnalysisExternalParam(ctx, req, &osParamsReq, curr)
	if err != nil {
		return nil, err
	}
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: ApiPathBigPromotionProductMultiAnalysis, BizType: req.BizType, NeedDistribution: true,
		KeyCols: append(groupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.TargetMetaList,
	})
	if err != nil {
		return nil, err
	}
	if len(currTargetList) >= 10000 {
		logs.CtxWarn(ctx, "[GetProductAnalysisMultiDimList]获取的多维组合数量=%v+，超过1w", len(currTargetList))
		return resp, errors.New("MAX_10000_LIMIT_ERROR")
	}
	resp = &activity_review.GetActivityReviewProductAnalysisData{
		FullList: make([]*analysis.MultiDimFullListRow, 0),
	}
	outParentRowMap := make(map[string][]*analysis.MultiDimFullListRow, 0)
	for _, keyTargetList := range currTargetList {
		if len(keyTargetList.KeyColValues) <= len(groupCols) {
			continue
		}

		dimKey := convert.ToString(keyTargetList.KeyColValues[len(groupCols)])
		if len(strings.ReplaceAll(dimKey, "#", "")) == 0 {
			resp.Total = &analysis.MultiDimFullListRow{
				EnumValue:   TotalEnumValue,
				DisplayName: "整体",
				TargetList:  keyTargetList.TargetEntity,
				ProdTagCode: "",
			}
			continue
		}

		maxLen := base_struct_condition.GetDimKeyMaxLen(dimKey)
		enumCode := convert.ToString(keyTargetList.KeyColValues[maxLen])
		displayName := consts.Empty
		enumCodeMap, exist := dimColEnumCodeMap[groupCols[maxLen]]
		if exist {
			displayName = enumCodeMap[enumCode]
		}
		fullRow := &analysis.MultiDimFullListRow{
			EnumValue:   enumCode,
			DisplayName: displayName,
			TargetList:  keyTargetList.TargetEntity,
			DimKey:      dimKey,
			ProdTagCode: "",
		}
		if maxLen == 0 {
			resp.FullList = append(resp.FullList, fullRow)
		} else {
			children, existC := outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)]
			if !existC {
				children = make([]*analysis.MultiDimFullListRow, 0)
			}
			children = append(children, fullRow)
			outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)] = children
		}
	}
	for _, fullRow := range resp.FullList {
		if children, existC := outParentRowMap[fullRow.DimKey]; existC {
			fullRow.Children = children
		}
		if len(fullRow.Children) > 0 {
			for _, subFullRow := range fullRow.Children {
				if subChildren, existSubC := outParentRowMap[subFullRow.DimKey]; existSubC {
					subFullRow.Children = subChildren
				}
			}
		}
	}
	return
}

func setAnalysisExternalParam(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct, osParamsReq *base_struct_condition.BigPromotionReviewOsParamsReq, curr map[string]interface{}) (err error) {
	// 如果用户自定义时间，则分析周期改为自定义时间
	if len(req.StartDate) > 0 && len(req.EndDate) > 0 {
		dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, req.StartDate, req.EndDate)
		if err != nil {
			return err
		}
		curr["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
		curr["date"] = strings.ReplaceAll(req.EndDate, "-", "")
		curr["supply_date_expr"] = fmt.Sprintf(`date between '%s' and '%s'`, req.StartDate, req.EndDate)
	} else {
		// 大促开始时间和结束时间
		supplyDao := new(dao.ActivityReviewSupplyDao)
		activityInfo, err := supplyDao.GetActivityInfoById(ctx, req.MainProjectId, req.ActivityId)
		if err != nil {
			return err
		}
		newest, err := utils.GetNewestDay(ctx, consts.LogicTableBigPromotionSupplyTable, consts.LogicTableUserGrowth)
		//newest = strings.ReplaceAll(newest, "-", "")
		if err != nil {
			return err
		}
		endDateStr := activityInfo.ProjectEndDate
		if activityInfo.ProjectEndDate > newest {
			endDateStr = newest
		}

		dateExpr, _, err := base_struct_condition.GetDateExprWithoutDash(ctx, activityInfo.ProjectStartDate, endDateStr)
		if err != nil {
			return err
		}
		curr["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
		curr["date"] = endDateStr
		curr["supply_date_expr"] = fmt.Sprintf(`date between '%s' and '%s'`, activityInfo.ProjectStartDate, endDateStr)
	}
	if len(osParamsReq.MultiDimension) > 0 {
		_, supportDimColMap, err := biz_utils.GetDimMapAndColMapByBiz(ctx, dimensions.BizType_BigPromotionSupply)
		if err != nil {
			return err
		}
		joinCql := sql_parse.NewCQL()
		//supplyJoinCql := sql_parse.NewCQL()
		//supplyDimensions := make([]string, 0)
		andConnector := ""
		for _, col := range osParamsReq.MultiDimension {
			joinCql.AddRawWhere(fmt.Sprintf("%s a.%s=b.%s", andConnector, col, col))
			andConnector = "and"
			if _, supportExist := supportDimColMap[col]; supportExist {
				//supplyDimensions = append(supplyDimensions, col)
				joinCql.AddRawWhere(fmt.Sprintf("%s a.%s=c.%s", andConnector, col, col))
				//supplyJoinCql.AddRawWhere(fmt.Sprintf("%s a.%s=b.%s", supplyAndConnector, col, col))
				//supplyAndConnector = "and"
			}
		}
		curr["join_param"] = sql_parse.NewCQL().ParseRawExpression(joinCql.RawWhereClause)
		//if len(supplyDimensions) > 0 {
		//	curr["supply_join_param"] = sql_parse.NewCQL().ParseRawExpression(supplyJoinCql.RawWhereClause)
		//}
	}
	return
}
