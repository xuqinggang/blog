package activity_review_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"strings"
)

func (d *ActivityReviewService) GetActivityAndNonActivityProductABAnalysis(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct) (resp *activity_review.GetActivityReviewProductAnalysisData, err error) {
	// 获取业务线的维度信息
	dimMap, dimColMap, err := biz_utils.GetDimMapAndColMapByBiz(ctx, req.BizType)
	if err != nil {
		return nil, err
	}

	//var prodCodeTagBaseDims = make([]*dimensions.SelectedDimensionInfo, 0)
	groupCols := make([]string, 0)
	dimColEnumCodeMap := make(map[string]map[string]string)
	if len(req.GroupAttrs) > 0 {
		for _, attr := range req.GroupAttrs {
			req.Dimensions = append(req.Dimensions, attr.DimInfo)

			// 获取维度的查询字段名
			dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
			if dimInfo == nil {
				logs.CtxError(ctx, "未查询到维度信息,id=%s", attr.DimInfo.Id)
				return resp, errors.New("未查询到维度信息")
			}
			groupCols = append(groupCols, dimInfo.DimColumn)
			//prodCodeTagBaseDims = append(prodCodeTagBaseDims, attr.DimInfo)
			// 查询该维度的枚举值
			if len(attr.DimInfo.SelectedValues) > 0 {
				enumCodeMap := make(map[string]string)
				for _, enum := range attr.DimInfo.SelectedValues {
					enumCodeMap[enum.Code] = enum.Name
				}
				dimColEnumCodeMap[dimInfo.DimColumn] = enumCodeMap
			}
		}
	}
	// 获取invoker的入参
	req.CompareMainProjectId = req.MainProjectId
	req.CompareMainActivityId = req.MainActivityId
	req.CompareActivityId = req.ActivityId
	req.ComparePickPlanIdList = req.PickPlanIdList
	curr, compare, _, err := base_struct_condition.GetBigPromotionReviewBaseStructConditionParams(ctx, base_struct_condition.BigPromotionReviewOsParamsReq{
		BaseStruct:     req,
		DimMap:         dimMap,
		DimColMap:      dimColMap,
		MultiDimension: groupCols,
	}, 0b11)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return nil, err
	}
	err = setABExternalParam(ctx, req, curr, compare)
	if err != nil {
		return nil, err
	}

	//// 查oneService获取数据
	//doc := document.NewEmptyDoc()
	//app := application.NewApp(doc)
	//f := flow.Empty()
	//
	//f.ExeQueryInvokerRaw(curr, ApiPathBigPromotionProductAAAnalysis, param.SinkTable("curr_info")).SetParallel(true).SetMaxParallelNum(10)
	//f.ExeQueryInvokerRaw(compare, ApiPathBigPromotionProductAAAnalysis, param.SinkTable("compare_info")).SetParallel(true).SetMaxParallelNum(10)
	//f.ExeQueryInvokerRaw(overall, ApiPathActivityReviewOverallProductAnalysis, param.SinkTable("overall_info")).SetParallel(true).SetMaxParallelNum(10)
	//f.ExeProduceSql(fmt.Sprintf(""), param.SinkTable("res_data"))
	//data := make([]map[string]interface{}, 0)
	//f.ExeView(param.SourceTable("res_data"), &data)
	//app.Use(f.ToStack(ctx))
	//_, err = app.Run(ctx)
	//if err != nil {
	//	return nil, err
	//}
	currTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: curr, Sql: consts.Empty, ApiPath: ApiPathBigPromotionProductAAAnalysis, BizType: req.BizType,
		KeyCols: append(groupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.TargetMetaList,
		TargetMetaEffectModule: []string{"指标卡", "流量效率分析"},
	})
	if err != nil {
		return nil, err
	}
	compareTargetList, err := base_struct_condition.GetTargetListWithKeyColumn(ctx, base_struct_condition.GetTargetListWithKeyColumnReq{
		Params: compare, Sql: consts.Empty, ApiPath: ApiPathBigPromotionProductABAnalysisForNonActivity, BizType: req.BizType,
		KeyCols: append(groupCols, "dim_key"), FilterTarget: true, FilterTargetNames: req.TargetMetaList,
		TargetMetaEffectModule: []string{"指标卡", "流量效率分析"},
	})
	if err != nil {
		return nil, err
	}
	currTargetList = base_struct_condition.GetTargetCycleRatioListWithKeyColumn(currTargetList, compareTargetList, nil, nil)
	if len(currTargetList) >= 10000 {
		logs.CtxWarn(ctx, "[GetProductAnalysisMultiDimList]获取的多维组合数量=%v+，超过1w", len(currTargetList))
		return resp, errors.New("MAX_10000_LIMIT_ERROR")
	}
	resp = &activity_review.GetActivityReviewProductAnalysisData{
		FullList: make([]*analysis.MultiDimFullListRow, 0),
	}
	outParentRowMap := make(map[string][]*analysis.MultiDimFullListRow, 0)
	for _, keyTargetList := range currTargetList {
		if len(keyTargetList.KeyColValues) <= len(groupCols) {
			continue
		}

		dimKey := convert.ToString(keyTargetList.KeyColValues[len(groupCols)])
		if len(strings.ReplaceAll(dimKey, "#", "")) == 0 {
			resp.Total = &analysis.MultiDimFullListRow{
				EnumValue:   TotalEnumValue,
				DisplayName: "整体",
				TargetList:  keyTargetList.TargetEntity,
				ProdTagCode: "",
			}
			continue
		}

		maxLen := base_struct_condition.GetDimKeyMaxLen(dimKey)
		enumCode := convert.ToString(keyTargetList.KeyColValues[maxLen])
		displayName := consts.Empty
		enumCodeMap, exist := dimColEnumCodeMap[groupCols[maxLen]]
		if exist {
			displayName = enumCodeMap[enumCode]
		}
		fullRow := &analysis.MultiDimFullListRow{
			EnumValue:   enumCode,
			DisplayName: displayName,
			TargetList:  keyTargetList.TargetEntity,
			DimKey:      dimKey,
			ProdTagCode: "",
		}
		if maxLen == 0 {
			resp.FullList = append(resp.FullList, fullRow)
		} else {
			children, existC := outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)]
			if !existC {
				children = make([]*analysis.MultiDimFullListRow, 0)
			}
			children = append(children, fullRow)
			outParentRowMap[base_struct_condition.GetDimKeyParent(dimKey)] = children
		}
	}
	for _, fullRow := range resp.FullList {
		if children, existC := outParentRowMap[fullRow.DimKey]; existC {
			fullRow.Children = children
		}
		if len(fullRow.Children) > 0 {
			for _, subFullRow := range fullRow.Children {
				if subChildren, existSubC := outParentRowMap[subFullRow.DimKey]; existSubC {
					subFullRow.Children = subChildren
				}
			}
		}
	}

	return
}

func setABExternalParam(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct, curr, compare map[string]interface{}) (err error) {
	// 如果用户自定义时间，则分析周期改为自定义时间
	if len(req.StartDate) > 0 && len(req.EndDate) > 0 && len(req.CompareStartDate) > 0 && len(req.CompareEndDate) > 0 {
		curr["supply_date_expr"] = fmt.Sprintf(`date between '%s' and '%s'`, req.StartDate, req.EndDate)
		compare["supply_date_expr"] = curr["supply_date_expr"]
		dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, req.StartDate, req.EndDate)
		if err != nil {
			return err
		}
		curr["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
		compare["date_expr"] = curr["date_expr"]
	} else {
		// 未自定义时间，则使用大促开始时间和结束时间
		supplyDao := new(dao.ActivityReviewSupplyDao)
		activityInfo, err := supplyDao.GetActivityInfoById(ctx, req.MainProjectId, req.ActivityId)
		if err != nil {
			return err
		}
		newest, err := utils.GetNewestDay(ctx, consts.LogicTableBigPromotionSupplyTable, consts.LogicTableUserGrowth)
		//newest = strings.ReplaceAll(newest, "-", "")
		if err != nil {
			return err
		}
		endDateStr := activityInfo.ProjectEndDate
		if activityInfo.ProjectEndDate > newest {
			endDateStr = newest
		}
		curr["supply_date_expr"] = fmt.Sprintf(`date between '%s' and '%s'`, activityInfo.ProjectStartDate, endDateStr)
		//compare["supply_date_expr"] = fmt.Sprintf(`date = '%s'`, endDateStr)
		compare["supply_date_expr"] = curr["supply_date_expr"]
		dateExpr, _, err := base_struct_condition.GetDateExprWithoutDash(ctx, activityInfo.ProjectStartDate, endDateStr)
		if err != nil {
			return err
		}
		curr["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
		compare["date_expr"] = curr["date_expr"]
	}
	return err
}
