package activity_review_service

import (
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/component/index_card"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
)

func (d *ActivityReviewService) GetProductSupplyProgress(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct) (resp *activity_review.GetActivityReviewProductSupplyProgressData, err error) {
	// 获取业务线的维度信息
	dimMap, _, err := biz_utils.GetDimMapAndColMapByBiz(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionMap]获取map失败，err=%v+", err)
		return nil, err
	}
	// 获取invoker的入参
	curr, compare, _, err := base_struct_condition.GetBigPromotionReviewBaseStructConditionParams(ctx, base_struct_condition.BigPromotionReviewOsParamsReq{
		BaseStruct: req,
		DimMap:     dimMap,
	}, 0b011)
	if err != nil {
		logs.CtxError(ctx, "生成invoker sql api入参失败,err:"+err.Error())
		return nil, err
	}
	// 查oneService获取数据
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	indexCardCom := index_card.NewIndexCard(ctx)

	newest, err := utils.GetNewestDay(ctx, consts.LogicTableBigPromotionSupplyTable)
	if err != nil {
		return nil, err
	}
	f.ExeQueryCustom([]param.Source{param.SourceConst(int64(req.BizType)), param.SourceConst(false), param.SourceConst([]string{EffectModuleSupplyProgress})}, dao.GetTargetMetaInfo, param.SinkTable("target_meta"))
	f.ExeQueryInvokerRaw(curr, ApiPathActivityTime, param.SinkTable("activity_time")).
		SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(compare, ApiPathActivityTime, param.SinkTable("compare_activity_time")).
		SetParallel(true).SetMaxParallelNum(10)
	f.ExeQueryInvokerRaw(curr, ApiPathBigPromotionSupplyProgress, param.SinkTable("info")).
		AddParam("date", param.SourceSqlWithType(
			fmt.Sprintf(
				`select 
							case when invest_end_date<"%v" then invest_end_date
							else "%v"
							end as date
						from   activity_time
						where  main_project_id=%v`,
				newest, newest, curr["main_project_id"]), []interface{}{}))
	// 计算对比活动的时间
	f.ExeProduceSql(
		fmt.Sprintf(`
						select 
							getCompareDateByProgress(b.invest_start_date, b.invest_end_date, a.time_progress_percentage) as date,
							b.main_project_id as main_project_id
						from   activity_time as a, compare_activity_time as b 
						where  b.main_project_id=%v and a.main_project_id=%v`, compare["main_project_id"], curr["main_project_id"]),
		param.SinkTable("compare_activity_time")).
		AddNormalUdfFunc("getCompareDateByProgress", framework_udf.GetCompareDateByProgress)
	f.ExeQueryInvokerRaw(compare, ApiPathBigPromotionSupplyProgress, param.SinkTable("compare_info")).
		AddParam("date", param.SourceSqlWithType(
			fmt.Sprintf(
				`select date
						from   compare_activity_time
						where  main_project_id=%v`,
				compare["main_project_id"]), []interface{}{}))
	f.ExeProduceSql(`SELECT * from compare_info union all select 'zjr_mock' as first_vbline_name, 0 as gmv_7d_rate, 0 as shop_register_rate, 0 as prod_cnt_per_shop`, param.SinkTable("compare_info"))
	f.ExeProduceSql(`SELECT 
    							a.*,
								b.gmv_7d_rate as compare_gmv_7d_rate,
    							b.shop_register_rate as compare_shop_register_rate,
    							b.prod_cnt_per_shop as compare_prod_cnt_per_shop 
						FROM info as a
						left join compare_info as b 
						ON a.first_vbline_name=b.first_vbline_name`,
		param.SinkTable("res_data"))
	f.Call(indexCardCom.FlowSplitMetricsToRow(param.SourceTable("res_data"), param.SinkTable("res_data")).
		SetValueColumn("target_value").
		SetTargetNameColumn("target_name").SetDimColumns([]string{"first_vbline_name"}))

	f.ExeProduceSql(fmt.Sprintf(`
						Select
							invest_start_date,
							invest_end_date,
							time_progress_percentage,
							(SELECT
								case when length(c.first_vbline_name)>0 then c.first_vbline_name else '整体' end as display_name,
								case when length(c.first_vbline_name)>0 then c.first_vbline_name else '不被匹配的整体' end as enum_value,
								(SELECT
									a.target_value as value,
									a.target_name as name,
									get_display_value(a.target_value,b.value_type,b.value_unit,b.target_precision) as display_value,
									b.tips as tips,
									b.display_order
									FROM res_data as a
									inner   join target_meta b
									on      a.target_name=b.name
									WHERE a.first_vbline_name=c.first_vbline_name
								) as target_data
							FROM res_data as c
							GROUP BY c.first_vbline_name
							) as supply_data
						FROM activity_time
						`), param.SinkTable("res_data")).SetUdfs(map[string]*onetable.UdfFunction{
		"get_display_value": onetable.NormalFunc(framework_udf.GetBriefMetricDisplayValue), // 格式化展示值
		"length":            onetable.NormalFunc(framework_udf.Length),
	})
	//data := make([]map[string]interface{}, 0)
	//f.ExeView(param.SourceTable("res_data"), &data)
	f.ExeView(param.SourceTable("res_data"), &resp)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		return nil, err
	}

	return
}
