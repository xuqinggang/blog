package feedback_service

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"context"
)

func (f *FeedBackService) AddFeedback(ctx context.Context, req *analysis.AddFeedBackRequest) (resp bool, err error) {
	// 创建事务
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return false, errors.New("获取数据库的事务失败")
	}
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		tx.Rollback()
		return false, err
	}
	err = dao.AddFeedBack(ctx, tx, req, email)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		tx.Rollback()
		return false, err
	}
	tx.Commit()
	return true, nil
}
