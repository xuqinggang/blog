package feedback_service

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"context"
)

type IFeedBackService interface {
	AddFeedback(ctx context.Context, req *analysis.AddFeedBackRequest) (resp bool, err error)
}

type FeedBackService struct {
}
