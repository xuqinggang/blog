package alert_service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/gogo/protobuf/proto"
	"golang.org/x/sync/semaphore"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/common/onetable"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom_product_pack_platform"
	"code.byted.org/ecom/smartop_product_analysis/biz/rpc/ecom_seller_merchant_dc"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/idgenerator"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/summary_utils"
	"code.byted.org/gdp/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_product_pack_platform/kitex_gen/ecom/product/purchase"
	"code.byted.org/overpass/ecom_seller_merchant_dc/kitex_gen/ecom/seller/merchant_dc"
	"code.byted.org/overpass/ecom_smartop_data_alert/kitex_gen/ecom/smartop/data_alert"
	"code.byted.org/overpass/ecom_smartop_data_alert/rpc/ecom_smartop_data_alert"
	"code.byted.org/security/go-polaris/eval"
	"code.byted.org/temai/go_lib/convert"
	"github.com/shopspring/decimal"
	"github.com/thoas/go-funk"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	alert_rule "code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_alert_rule"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
)

type PoolOsParamsStruct struct {
	PoolId   string
	OsParams map[string]interface{}
}

type ProductPackInfoStruct struct {
	ProdId               *string                  `json:"prod_id"`
	ProdName             *string                  `json:"prod_name"`
	IsSeckillProduct     *bool                    `json:"is_seckill_product"`
	IsAllowanceProduct   *bool                    `json:"is_allowance_product"`
	IsBrandTrialProduct  *bool                    `json:"is_brand_trial_product"`
	PurchaseStatus       *bool                    `json:"purchase_status"`
	PurchaseStatusReason *purchase.PurchaseReason `json:"purchase_status_reason"`
	CampaignStockNumSum  *int64                   `json:"campaign_stock_num_sum"`
	NormalStockNumSum    *int64                   `json:"normal_stock_num_sum"`
}

// oneService注册的sqlApiPath
const (
	// 商品id查询
	apiPathProductIdList = "7398022194544034854"
)

func (d *AlertService) GetAlertProdStatusRuleIndicator(ctx context.Context, req *alert_rule.GetAlertProdStatusRuleIndicatorReq) (resp *alert_rule.GetAlertProdStatusRuleIndicatorData, err error) {
	resp = &alert_rule.GetAlertProdStatusRuleIndicatorData{}

	list, err := biz_info.GetAlertProductStatusRuleIndicatorList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetAlertProdStatusRuleIndicators]调用tcc GetAlertProductStatusRuleIndicatorList失败 req=%v err=%v", req, err)
		return nil, err
	}

	resp.IndicatorList = list

	return resp, nil
}

// 查询所有存在商品状态异常的规则
func (d *AlertService) GetRulesWitExceptionProdStatusInfos(ctx context.Context, req *alert_rule.GetRulesWitExceptionProdStatusInfosReq) (resp []*alert_rule.RuleWitExceptionProdInfos, err error) {
	/**
	* 1.1 遍历所有规则，筛出有监控商品状态的规则列表，查询规则下所有商品列表，存为规则id和商品列表的映射
	* 1.2 将所有商品去重组合为待查商品列表并按每组20进行分组调用summary查询分组商品状态，直至查完
	* 1.3 将规则id对应的商品补充状态信息返回
	**/
	weighted := semaphore.NewWeighted(50)
	// 获取所有监控商品状态的预警规则
	analysisPoolAlertRuleDoList, _, err := dao.GetMonitorProductStatusAlertRuleList(ctx, mysql.DB(ctx))
	if err != nil {
		logs.CtxError(ctx, "[GetRulesWitExceptionProdStatusInfos]获取所有监控商品状态的预警规则失败，err=%v+", err)
		return nil, err
	}
	analysisPoolAlertRuleDoList, err = getEffectDataAlertRules(ctx, analysisPoolAlertRuleDoList)
	if err != nil {
		logs.CtxError(ctx, "[GetRulesWitExceptionProdStatusInfos]通过rpc获取预警生效规则失败，err=%v+", err)
		return nil, err
	}

	logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]获取analysisPoolAlertRuleDoList=%v+", convert.ToJSONString(analysisPoolAlertRuleDoList))

	// ppe环境下只处理yuwenbin.yutou@bytedance.com的测试任务
	if env.IsPPE() || os.Getenv("cron_env") == "ppe" {
		analysisPoolAlertRuleDoList = funk.Filter(analysisPoolAlertRuleDoList, func(rule *dao.AnalysisPoolAlertRuleDo) bool {
			return rule.IsAnalyzeProductStatus == 1 && strings.Contains(rule.PushUsers, "yuwenbin.yutou@bytedance.com")
		}).([]*dao.AnalysisPoolAlertRuleDo)
	}

	poolIdList := make([]string, 0)
	for _, v := range analysisPoolAlertRuleDoList {
		if !slices.ContainsString(poolIdList, v.PoolId) {
			poolIdList = append(poolIdList, v.PoolId)
		}
	}

	// poolIdList 获取所有货盘信息
	insightPool, err := dao.BatchGetInsightAnalysisPool(ctx, mysql.DB(ctx), poolIdList)
	if err != nil {
		logs.CtxError(ctx, "[GetRulesWitExceptionProdStatusInfos]批量获取通过规则创建货盘商品失败，err=%v+", err)
		return nil, err
	}
	manualPool, err := dao.BatchGetManualAnalysisPool(ctx, mysql.DB(ctx), poolIdList)
	if err != nil {
		logs.CtxError(ctx, "[GetRulesWitExceptionProdStatusInfos]批量获取通过录入创建货盘商品失败，err=%v+", err)
		return nil, err
	}

	manualPoolIdList := make([]string, 0)
	for _, v := range manualPool {
		manualPoolIdList = append(manualPoolIdList, *v.PoolId)
	}
	logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]获取manualPoolIdList=%v+", convert.ToJSONString(manualPoolIdList))

	// 获取人工录入货盘商品
	manualAnalysisPoolProducts, _, err := dao.BatchGetAnalysisPoolProductList(ctx, mysql.DB(ctx), manualPoolIdList)
	if err != nil {
		logs.CtxError(ctx, "[GetRulesWitExceptionProdStatusInfos]批量获取货盘商品失败，err=%v+", err)
		return nil, err
	}

	insightAnalysisPoolProducts := make([]*dao.AnalysisPoolProductDo, 0)
	if len(insightPool) > 0 {
		insightPoolOsParamsList := make([]PoolOsParamsStruct, 0)
		for _, v := range insightPool {
			insightPoolOsParams, err := getInsightAnalysisPoolProductOsParams(ctx, v, d)
			if err != nil {
				logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]获取OsParams失败, pool=%v, err=%v+", v, err)
				continue
			}
			insightPoolOsParamsList = append(insightPoolOsParamsList, PoolOsParamsStruct{
				PoolId:   *v.PoolId,
				OsParams: insightPoolOsParams,
			})
		}
		logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]获取OsParams，insightPoolOsParamsList=%v+", convert.ToJSONString(insightPoolOsParamsList))

		// 查询OneService 货品行为数据
		doc := document.NewEmptyDoc()
		app := application.NewApp(doc)
		f := flow.Empty()

		for paramsIndex, poolOsParams := range insightPoolOsParamsList {
			prodIdTableName := "product_id" + convert.ToString(paramsIndex)
			poolProdTableName := "pool_product" + convert.ToString(paramsIndex)
			f.ExeQueryInvokerRaw(poolOsParams.OsParams, apiPathProductIdList, param.SinkTable(prodIdTableName)).SetParallel(true).SetMaxParallelNum(5)
			f.ExeQueryCustom([]param.Source{param.SourceTable(prodIdTableName), param.SourceConst(poolOsParams.PoolId)}, getPoolProdInfo, param.SinkTable(poolProdTableName))
		}

		dependSql := make([]string, 0)
		for paramsIndex, _ := range insightPoolOsParamsList {
			poolProdTableName := "pool_product" + convert.ToString(paramsIndex)
			dependSql = append(dependSql, fmt.Sprintf("select product_id, pool_id from %s", poolProdTableName))
		}
		f.ExeProduceSql(strings.Join(dependSql, " union all "), param.SinkTable("pool_product_merge"))
		f.ExeView(param.SourceTable("pool_product_merge"), &insightAnalysisPoolProducts)

		app.Use(f.ToStack(ctx))
		_, err = app.Run(ctx)
		if err != nil {
			logs.CtxError(ctx, "[GetRulesWitExceptionProdStatusInfos]os查询失败，err=%v+", err)
			return nil, err
		}
	}

	// ppe时 规则货盘 最大查询长度1000
	if (env.IsPPE() || os.Getenv("cron_env") == "ppe") && len(insightAnalysisPoolProducts) > 1000 {
		insightAnalysisPoolProducts = insightAnalysisPoolProducts[:1000]
	}

	// 日志记录analysisPoolProducts
	logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]manualAnalysisPoolProducts=%+v", len(manualAnalysisPoolProducts))
	logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]insightAnalysisPoolProducts=%+v", len(insightAnalysisPoolProducts))

	analysisPoolProducts := make([]*dao.AnalysisPoolProductDo, 0)
	analysisPoolProducts = append(analysisPoolProducts, manualAnalysisPoolProducts...)
	analysisPoolProducts = append(analysisPoolProducts, insightAnalysisPoolProducts...)

	staySearchProductIdStrList := make([]string, 0)
	for _, v := range analysisPoolProducts {
		if !slices.ContainsString(staySearchProductIdStrList, v.ProductId) {
			staySearchProductIdStrList = append(staySearchProductIdStrList, v.ProductId)
		}
	}
	staySearchProductIdList := utils.SliceString2Int64(staySearchProductIdStrList)

	logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]调用summary查商品状态 staySearchProductIdList=%v", staySearchProductIdList)

	// 获取商品的信息
	callerInstance := utils.Result[map[int64]*ProductPackInfoStruct](nil)
	productPackInfo := make(map[int64]*ProductPackInfoStruct, 0)

	mutex := new(sync.Mutex)
	asyncCaller := utils.AsyncCaller(func(v any) (map[int64]*ProductPackInfoStruct, error) {
		ids := v.([]int64)
		productHash, err := ecom_product_pack_platform.RPCMGetProduct(ctx, ids)
		if err != nil {
			logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]调用ecom_product_pack_platform.RPCMGetProduct失败 ids=%v err=%v", ids, err)
			return productPackInfo, nil
		}
		mutex.Lock()
		defer mutex.Unlock()
		for key, _ := range productHash {
			product_id := fmt.Sprintf("%v", key)
			product_name := summary_utils.GetProductName(key, productHash)
			purchase_status := summary_utils.GetPurchaseStatus(key, productHash)
			is_seckill_product := summary_utils.GetIsSeckillProduct(key, productHash)
			is_allowance_product := summary_utils.GetIsAllowanceProduct(key, productHash)
			is_brand_trial_product := summary_utils.GetIsBrandTrialProduct(key, productHash)
			campaign_stock_num_sum := summary_utils.GetCampaignStock(key, productHash)
			normal_stock_num_sum := summary_utils.GetNormalStock(key, productHash)
			purchase_status_reason := summary_utils.GetPurchaseStatusReason(key, productHash)

			productPackInfo[key] = &ProductPackInfoStruct{
				PurchaseStatus:       purchase_status,
				PurchaseStatusReason: purchase_status_reason,
				IsSeckillProduct:     is_seckill_product,
				IsAllowanceProduct:   is_allowance_product,
				IsBrandTrialProduct:  is_brand_trial_product,
				CampaignStockNumSum:  campaign_stock_num_sum,
				NormalStockNumSum:    normal_stock_num_sum,
				ProdId:               &product_id,
				ProdName:             product_name,
			}
		}

		return productPackInfo, nil
	}).SetSemaphore(weighted)
	for _, ids := range utils.CutSLice(staySearchProductIdList, 20) {
		callerInstance = asyncCaller.Call(ids)
	}
	if callerInstance == nil {
		logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]调用ecom_product_pack_platform.RPCMGetProduct失败 callerInstance为空 ids=%v", staySearchProductIdList)
		return nil, errors.New("调用ecom_product_pack_platform.RPCMGetProduct失败")
	}
	productPackInfo = callerInstance.Value()
	logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]调用summary查询成功 productPackInfo=%v", productPackInfo)

	alertProdStatusRuleIndicatorList, err := biz_info.GetAlertProductStatusRuleIndicatorList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[getRuleExceptionInfos]调用tcc GetAlertProductStatusRuleIndicatorList失败  err=%v", err)
		return nil, err
	}

	for _, vRule := range analysisPoolAlertRuleDoList {
		alertProductStatusRule := &alert_rule.AlertProductStatusRule{}
		if vRule.AlertProductStatusRule != "" {
			err = json.Unmarshal([]byte(vRule.AlertProductStatusRule), &alertProductStatusRule)
			// err = json.Unmarshal([]byte(poolRuleString), &poolRule)
			if err != nil {
				logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos] json decode error:%v", err)
				continue
			}
		}
		ruleProducts := make([]*dao.AnalysisPoolProductDo, 0)
		for _, vPoolProducts := range analysisPoolProducts {
			// 如果不是该规则下的商品，跳过
			if vRule.PoolId != vPoolProducts.PoolId {
				continue
			}
			ruleProducts = append(ruleProducts, vPoolProducts)
		}
		exceptionInfos, err := getRuleExceptionInfos(ctx, ruleProducts, productPackInfo, alertProductStatusRule, alertProdStatusRuleIndicatorList)
		if err != nil {
			logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos] getRuleExceptionInfos error:%v", err)
			continue
		}
		if err != nil {
			logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos] getRuleExceptionInfos error:%v", err)
			continue
		}

		exceptionInfos, err = genAlertMsgAndCutPid(ctx, vRule, exceptionInfos)
		if err != nil {
			logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos] genAlertMsgAndCutPid error:%v", err)
			continue
		}

		resp = append(resp, &alert_rule.RuleWitExceptionProdInfos{
			RuleId:         &vRule.AlertRuleId,
			ExceptionInfos: exceptionInfos,
		})
	}

	return resp, nil
}

// 生成预警消息id并截取商品
func genAlertMsgAndCutPid(ctx context.Context, rule *dao.AnalysisPoolAlertRuleDo, exceptionInfos map[string]*alert_rule.AlertProdStatusExceptionInfo) (exceptionInfosRes map[string]*alert_rule.AlertProdStatusExceptionInfo, err error) {
	analysisPoolPushMsgList := make([]*dao.AnalysisPoolPushMsgDo, 0)
	exceptionInfosRes = make(map[string]*alert_rule.AlertProdStatusExceptionInfo, 0)
	for k, v := range exceptionInfos {
		// 没有异常信息，跳过
		if v == nil || v.Wrong == nil || !*v.Wrong {
			continue
		}
		productNameList, isOk := funk.Map(v.WrongProds, func(wrongProd *alert_rule.ExceptionProductInfo) string {
			if (wrongProd != nil) && (wrongProd.ProductName != nil) {
				return *wrongProd.ProductName
			}
			return ""
		}).([]string)
		if !isOk {
			productNameList = make([]string, 0)
		}
		productNameList, isOk = funk.Filter(productNameList, func(v string) bool {
			return v != ""
		}).([]string)
		if !isOk {
			productNameList = make([]string, 0)
		}
		productNames := strings.Join(productNameList, ",")
		productIdList, isOk := funk.Map(v.WrongProds, func(wrongProd *alert_rule.ExceptionProductInfo) string {
			if wrongProd != nil {
				return wrongProd.ProductId
			}
			return ""
		}).([]string)
		if !isOk {
			productIdList = make([]string, 0)
		}
		productIdList, isOk = funk.Filter(productIdList, func(v string) bool {
			return v != ""
		}).([]string)
		if !isOk {
			productIdList = make([]string, 0)
		}
		productIds := strings.Join(productIdList, ",")
		alertMsgId, err := idgenerator.GenerateIdString(ctx)
		if err != nil {
			logs.CtxError(ctx, err.Error())
			return nil, err
		}

		analysisPoolPushMsgList = append(analysisPoolPushMsgList, &dao.AnalysisPoolPushMsgDo{
			AlertMsgId:   alertMsgId,
			AlertRuleId:  rule.AlertRuleId,
			PoolId:       rule.PoolId,
			ProductIds:   productIds,
			ProductNames: productNames,
		})

		showProds := v.WrongProds
		if len(showProds) > 5 {
			showProds = showProds[:5]
		}

		exceptionInfosRes[k] = &alert_rule.AlertProdStatusExceptionInfo{
			Wrong:          v.Wrong,
			WrongAbstruct:  v.WrongAbstruct,
			WrongProdCount: v.WrongProdCount,
			WrongProds:     showProds,
			AlertMsgId:     &alertMsgId,
		}
	}
	// 修改每条消息的时间
	analysisPoolPushMsgReq := make([]*dao.AnalysisPoolPushMsgDo, 0)
	baseTime := time.Now()
	for i, v := range analysisPoolPushMsgList {
		analysisPoolPushMsgReq = append(analysisPoolPushMsgReq, &dao.AnalysisPoolPushMsgDo{
			AlertMsgId:   v.AlertMsgId,
			AlertRuleId:  v.AlertRuleId,
			PoolId:       v.PoolId,
			ProductIds:   v.ProductIds,
			ProductNames: v.ProductNames,
			AlertTime:    baseTime.Add(time.Duration(i) * time.Second),
		})
	}

	// 当需要存入的预警消息为空时 直接返回结果
	if len(analysisPoolPushMsgReq) == 0 {
		return exceptionInfosRes, nil
	}

	_, err = dao.BatchCreateAnalysisPoolPushMsg(ctx, mysql.DB(ctx), analysisPoolPushMsgReq)
	if err != nil {
		logs.CtxInfo(ctx, "[GetRulesWitExceptionProdStatusInfos]获取所有监控商品状态的预警规则失败，err=%v+", err)
		return nil, err
	}

	return exceptionInfosRes, nil
}

func getRuleExceptionInfos(ctx context.Context, ruleProducts []*dao.AnalysisPoolProductDo, productPackInfo map[int64]*ProductPackInfoStruct, alertProductStatusRule *alert_rule.AlertProductStatusRule, alertProdStatusRuleIndicatorList []*alert_rule.AlertProdStatusRuleIndicator) (exceptionInfos map[string]*alert_rule.AlertProdStatusExceptionInfo, err error) {
	exceptionInfos = map[string]*alert_rule.AlertProdStatusExceptionInfo{}
	var rules []*alert_rule.AlertProductStatusRuleItem
	if alertProductStatusRule != nil && len(alertProductStatusRule.Rules) > 0 {
		rules = alertProductStatusRule.Rules
	} else {
		defaultIndicatorStr := []string{"campaign_stock", "purchase_status", "campaign"}
		defaultOpStr := []string{"<"}
		defaultValueStr := [][]string{{"100"}, {"0"}, {"BrandTrial"}}
		// 没有alertProductStatusRule的视为老数据 走默认配置
		rules = []*alert_rule.AlertProductStatusRuleItem{
			{
				Indicator: &defaultIndicatorStr[0],
				Op:        &defaultOpStr[0],
				Value:     defaultValueStr[0],
			},
			{
				Indicator: &defaultIndicatorStr[1],
				Value:     defaultValueStr[1],
			},
			{
				Indicator: &defaultIndicatorStr[2],
				Value:     defaultValueStr[2],
			},
		}
	}

	// 拿一下招商的信息
	spuEstimateRule, isOk := funk.Find(rules, func(rule *alert_rule.AlertProductStatusRuleItem) bool {
		return rule.Indicator != nil && *rule.Indicator == "spu_estimate_price_online_tag"
	}).(*alert_rule.AlertProductStatusRuleItem)
	// 存在 活动普惠到手价(单品)比价状态 规则
	sellerMerchantProdInfo := make([]ecom_seller_merchant_dc.SellerMerchantProdInfo, 0)
	if isOk && spuEstimateRule != nil {
		spuEstimateUseActivityRule, isOk := funk.Find(rules, func(rule *alert_rule.AlertProductStatusRuleItem) bool {
			return rule.Indicator != nil && *rule.Indicator == "spu_estimate_use_activity_id"
		}).(*alert_rule.AlertProductStatusRuleItem)
		// 存在指定比价活动 并且有指定比价活动
		if isOk && spuEstimateUseActivityRule.Value != nil && len(spuEstimateUseActivityRule.Value) > 0 {
			rulePidStringList, isOk := funk.Map(ruleProducts, func(vPoolProducts *dao.AnalysisPoolProductDo) string {
				return vPoolProducts.ProductId
			}).([]string)
			if isOk && rulePidStringList != nil && len(rulePidStringList) > 0 {
				prodSellerMerchantApplyRecordList, err := ecom_seller_merchant_dc.RPCGetSellerMerchantApplyRecordList(ctx, spuEstimateUseActivityRule.Value, rulePidStringList)
				if err != nil || len(prodSellerMerchantApplyRecordList) == 0 {
					logs.CtxInfo(ctx, "[getExceptionJudgeResult]调用ecom_seller_merchant_dc.RPCGetSellerMerchantApplyRecordList失败, err=%v", err)
					return nil, err
				}
				logs.CtxInfo(ctx, "[getExceptionJudgeResult]调用ecom_seller_merchant_dc.RPCGetSellerMerchantApplyRecordList结果, v=%v", convert.ToJSONString(prodSellerMerchantApplyRecordList))
				sellerMerchantProdInfo = funk.Reduce(prodSellerMerchantApplyRecordList, func(cur []ecom_seller_merchant_dc.SellerMerchantProdInfo, record *merchant_dc.ApplyRecord) []ecom_seller_merchant_dc.SellerMerchantProdInfo {
					priceTag, exist := record.IndicatorList["price_cmp_result.spu_estimate_price_online_tag"]
					if !exist || priceTag == nil {
						priceTag = &merchant_dc.BriefIndicator{}
					}
					itemId, exist := record.IndicatorList["item_id"]
					if !exist || itemId == nil {
						itemId = &merchant_dc.BriefIndicator{}
					}
					isContainProd := funk.Contains(cur, func(foo ecom_seller_merchant_dc.SellerMerchantProdInfo) bool {
						return itemId != nil && foo.ProductId == itemId.DisplayVal
					})
					if !isContainProd && itemId.Val != nil && priceTag.Val != nil && itemId.Val.StrVal != nil && priceTag.Val.StrVal != nil {
						cur = append(cur, ecom_seller_merchant_dc.SellerMerchantProdInfo{
							ProductId:                 *itemId.Val.StrVal,
							SpuEstimatePriceOnlineTag: *priceTag.Val.StrVal,
						})
					}
					return cur
				}, sellerMerchantProdInfo).([]ecom_seller_merchant_dc.SellerMerchantProdInfo)
			}
		}
	}

	for _, rule := range rules {
		ruleIndicator := ""
		if rule.Indicator != nil {
			ruleIndicator = *rule.Indicator
		}
		indicatorConfig, isOk := funk.Find(alertProdStatusRuleIndicatorList, func(indicatorInfo *alert_rule.AlertProdStatusRuleIndicator) bool {
			return indicatorInfo.Indicator != nil && *indicatorInfo.Indicator == ruleIndicator
		}).(*alert_rule.AlertProdStatusRuleIndicator)
		if !isOk {
			indicatorConfig = &alert_rule.AlertProdStatusRuleIndicator{}
		}
		// 指标为辅助配置 跳过
		if indicatorConfig.AssistIndicator != nil {
			continue
		}
		exceptionInfoItem := &alert_rule.AlertProdStatusExceptionInfo{}

		for _, vPoolProducts := range ruleProducts {
			productId, err := strconv.ParseInt(vPoolProducts.ProductId, 10, 64)
			if err != nil {
				continue
			}
			// pack没返回的不发
			if productPackInfo[productId] == nil {
				continue
			}
			productInfo := productPackInfo[productId]
			sellerMerchantProdInfoItem := ecom_seller_merchant_dc.SellerMerchantProdInfo{}
			if len(sellerMerchantProdInfo) > 0 {
				sellerMerchantProdInfoItemInterface := funk.Find(sellerMerchantProdInfo, func(foo ecom_seller_merchant_dc.SellerMerchantProdInfo) bool {
					return foo.ProductId == vPoolProducts.ProductId
				})
				if sellerMerchantProdInfoItemInterface != nil {
					sellerMerchantProdInfoItem, isOk = sellerMerchantProdInfoItemInterface.(ecom_seller_merchant_dc.SellerMerchantProdInfo)
					if !isOk {
						sellerMerchantProdInfoItem = ecom_seller_merchant_dc.SellerMerchantProdInfo{}
					}
				}
			}
			exprRes, err := getExceptionJudgeResult(ctx, productInfo, sellerMerchantProdInfoItem, rule, rules)
			if err == nil && exprRes == "1" {
				exceptionInfoItem.WrongProds = append(exceptionInfoItem.WrongProds, &alert_rule.ExceptionProductInfo{
					ProductId:   vPoolProducts.ProductId,
					ProductName: productInfo.ProdName,
				})
			}
		}
		if exceptionInfoItem.WrongProds != nil && len(exceptionInfoItem.WrongProds) > 0 {
			wrong := len(exceptionInfoItem.WrongProds) > 0
			wrongAbstruct, err := getExceptionWrongAbstruct(indicatorConfig, rule)
			if err != nil {
				// 兜底使用配置指标名称
				wrongAbstruct = *indicatorConfig.Name
			}
			wrongProdCount := int64(len(exceptionInfoItem.WrongProds))
			exceptionInfoItem.Wrong = &wrong
			exceptionInfoItem.WrongAbstruct = &wrongAbstruct
			exceptionInfoItem.WrongProdCount = &wrongProdCount
		}
		exceptionName := fmt.Sprintf("%v", ruleIndicator)
		exceptionInfos[exceptionName] = exceptionInfoItem
	}
	return exceptionInfos, nil
}

func getExceptionJudgeResult(ctx context.Context, productInfo *ProductPackInfoStruct, sellerMerchantProdInfo ecom_seller_merchant_dc.SellerMerchantProdInfo, rule *alert_rule.AlertProductStatusRuleItem, rules []*alert_rule.AlertProductStatusRuleItem) (res string, err error) {
	type ExprStruct struct {
		CurValue   int64 `alias:"cur_value"`
		JudgeValue int64 `alias:"judge_value"`
	}
	expr := ""
	exprStruct := &ExprStruct{}
	exprRes := "0"
	ruleIndicator := rule.Indicator
	ruleValueList := rule.Value
	if ruleIndicator != nil && *ruleIndicator == "campaign" {
		ruleValue := ruleValueList[0]
		if ruleValue == "ExplosiveSubsidy" {
			if productInfo.IsAllowanceProduct != nil && *productInfo.IsAllowanceProduct {
				exprRes = "0"
			} else {
				exprRes = "1"
			}
		} else if ruleValue == "Seckill" {
			if productInfo.IsSeckillProduct != nil && *productInfo.IsSeckillProduct {
				exprRes = "0"
			} else {
				exprRes = "1"
			}
		} else if ruleValue == "BrandTrial" {
			if productInfo.IsBrandTrialProduct != nil && *productInfo.IsBrandTrialProduct {
				exprRes = "0"
			} else {
				exprRes = "1"
			}
		}
		return exprRes, nil
	}
	if ruleIndicator != nil && *ruleIndicator == "campaign_stock" {
		ruleValue := ruleValueList[0]
		ruleValueInt, err := strconv.ParseInt(ruleValue, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[getExceptionJudgeResult]string转int64失败，err=%v+", err)
			return exprRes, err
		}
		if productInfo.CampaignStockNumSum == nil || rule.Op == nil {
			return exprRes, nil
		}
		exprStruct = &ExprStruct{
			CurValue:   *productInfo.CampaignStockNumSum,
			JudgeValue: ruleValueInt,
		}
		expr = fmt.Sprintf(`cur_value - judge_value %v 0 ? "1" : "0"`, *rule.Op)
	} else if ruleIndicator != nil && *ruleIndicator == "normal_stock" {
		ruleValue := ruleValueList[0]
		ruleValueInt, err := strconv.ParseInt(ruleValue, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[getExceptionJudgeResult]string转int64失败，err=%v+", err)
			return exprRes, err
		}
		if productInfo.NormalStockNumSum == nil || rule.Op == nil {
			return exprRes, nil
		}
		exprStruct = &ExprStruct{
			CurValue:   *productInfo.NormalStockNumSum,
			JudgeValue: ruleValueInt,
		}
		expr = fmt.Sprintf(`cur_value - judge_value %v 0 ? "1" : "0"`, *rule.Op)
	} else if ruleIndicator != nil && *ruleIndicator == "purchase_status" {
		ruleValue := ruleValueList[0]
		ruleValueInt, err := strconv.ParseInt(ruleValue, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[getExceptionJudgeResult]string转int64失败，err=%v+", err)
			return exprRes, err
		}
		banPurchaseStatusReasonRule, isOk := funk.Find(rules, func(ruleItem *alert_rule.AlertProductStatusRuleItem) bool {
			return ruleItem.Indicator != nil && *ruleItem.Indicator == "ban_purchase_status_reason"
		}).(*alert_rule.AlertProductStatusRuleItem)
		if !isOk {
			banPurchaseStatusReasonRule = &alert_rule.AlertProductStatusRuleItem{}
		}
		isBan, isOk := funk.Find(banPurchaseStatusReasonRule.Value, func(value string) bool {
			if productInfo.PurchaseStatusReason == nil {
				return false
			}
			reasonStr := fmt.Sprintf("%v", *productInfo.PurchaseStatusReason)
			return reasonStr == value
		}).(*string)
		if !isOk && isBan != nil {
			exprRes = "0"
			return exprRes, nil
		}
		PurchaseStatusInt := int64(0)
		if productInfo.PurchaseStatus != nil && *productInfo.PurchaseStatus {
			PurchaseStatusInt = int64(1)
		}
		exprStruct = &ExprStruct{
			CurValue:   PurchaseStatusInt,
			JudgeValue: ruleValueInt,
		}
		expr = fmt.Sprintf(`cur_value - judge_value %v 0 ? "1" : "0"`, "==")
	} else if ruleIndicator != nil && *ruleIndicator == "spu_estimate_price_online_tag" && sellerMerchantProdInfo.SpuEstimatePriceOnlineTag != "" {
		ruleValue := ruleValueList[0]
		ruleValueInt, err := strconv.ParseInt(ruleValue, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[getExceptionJudgeResult]string转int64失败，err=%v+", err)
			return exprRes, err
		}
		spuEstimatePriceOnlineTagInt, err := strconv.ParseInt(sellerMerchantProdInfo.SpuEstimatePriceOnlineTag, 10, 64)
		if err != nil {
			logs.CtxError(ctx, "[getExceptionJudgeResult]string转int64失败，err=%v+", err)
			return exprRes, err
		}
		exprStruct = &ExprStruct{
			CurValue:   spuEstimatePriceOnlineTagInt,
			JudgeValue: ruleValueInt,
		}
		expr = fmt.Sprintf(`cur_value - judge_value %v 0 ? "1" : "0"`, "==")
	}

	if exprStruct != nil && expr != "" {
		exprResStruct, err := eval.Execute(expr, exprStruct)
		if err != nil {
			logs.CtxError(ctx, "[getRuleExceptionInfos]执行表达式失败，expr=%v, exprStruct=%v, err=%v", expr, exprStruct, err)
			return exprRes, err
		}
		exprRes = fmt.Sprintf("%v", exprResStruct)
	}

	return exprRes, nil
}

func getExceptionWrongAbstruct(ruleIndicatorConfig *alert_rule.AlertProdStatusRuleIndicator, rule *alert_rule.AlertProductStatusRuleItem) (result string, err error) {
	result = ""
	ruleIndicatorConfigName := ruleIndicatorConfig.Name
	ruleIndicatorConfigTips := ruleIndicatorConfig.Tips
	ruleIndicatorConfigShowType := ruleIndicatorConfig.ShowType
	ruleIndicatorConfigOptions := ruleIndicatorConfig.Options
	ruleValueList := rule.Value
	name := ""
	if ruleIndicatorConfigTips != nil && ruleIndicatorConfigName != nil {
		name = fmt.Sprintf("%v(%v)", *ruleIndicatorConfigName, *ruleIndicatorConfigTips)
	} else if ruleIndicatorConfigName != nil {
		name = *ruleIndicatorConfigName
	}
	if ruleIndicatorConfigShowType != nil && *ruleIndicatorConfigShowType == "threshold_input" {
		ruleValue := ruleValueList[0]
		if rule.Op == nil || ruleIndicatorConfigName == nil {
			return result, nil
		}
		result = fmt.Sprintf("%v %v %v", name, *rule.Op, ruleValue)
		return result, nil
	}
	if ruleIndicatorConfigShowType != nil && *ruleIndicatorConfigShowType == "single_select" {
		ruleValue := ruleValueList[0]
		selectedRuleConfigOption, isOk := funk.Find(ruleIndicatorConfigOptions, func(option *alert_rule.AlertProdStatusRuleIndicatorOption) bool {
			return option.Code != nil && *option.Code == ruleValue
		}).(*alert_rule.AlertProdStatusRuleIndicatorOption)
		if !isOk {
			selectedRuleConfigOption = &alert_rule.AlertProdStatusRuleIndicatorOption{}
		}
		if selectedRuleConfigOption.Name == nil || ruleIndicatorConfigName == nil {
			return result, nil
		}
		result = fmt.Sprintf("商品%v %v %v", name, "为", *selectedRuleConfigOption.Name)
		return result, nil
	}
	if ruleIndicatorConfigShowType != nil && *ruleIndicatorConfigShowType == "bool_single_select" {
		ruleValue := ruleValueList[0]
		selectedRuleConfigOption, isOk := funk.Find(ruleIndicatorConfigOptions, func(option *alert_rule.AlertProdStatusRuleIndicatorOption) bool {
			return option.Code != nil && *option.Code == ruleValue
		}).(*alert_rule.AlertProdStatusRuleIndicatorOption)
		if !isOk {
			selectedRuleConfigOption = &alert_rule.AlertProdStatusRuleIndicatorOption{}
		}
		if selectedRuleConfigOption.Name == nil || ruleIndicatorConfigName == nil {
			return result, nil
		}
		result = fmt.Sprintf("商品%v %v %v", name, "为", *selectedRuleConfigOption.Name)
		return result, nil
	}

	return result, nil
}

func getInsightAnalysisPoolProductOsParams(ctx context.Context, poolInfo *analysis_pool.AnalysisPool, d *AlertService) (params map[string]interface{}, err error) {
	params = make(map[string]interface{})
	bizType := utils.If(poolInfo.BaseStruct.BizType == dimensions.BizType_GreatValueBuy, dimensions.BizType_GreatValueBuy, dimensions.BizType_GrowthProductStrategy)
	dimMap, err := d.DimensionListDao.GetDimensionMap(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[getInsightAnalysisPoolProductOsParams]获取map失败，err=%v+", err)
		return nil, err
	}
	_, newest, err := utils.GetOldestAndNewestDate(ctx, []string{consts.LogicTableBillion}, 31)
	if err != nil {
		logs.CtxError(ctx, "[getInsightAnalysisPoolProductOsParams]查询时间区间信息失败，err=%v+", err)
		return nil, err
	}
	startDate := newest
	endDate := newest

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "[getInsightAnalysisPoolProductOsParams]业务线未发现元信息, bizType = %s", bizType)
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return nil, err
	}
	params["table_name"] = bizInfo.TableName

	// 货盘类型是货品流量洞察多维分析规则
	dimensionsList := make([]*dimensions.SelectedDimensionInfo, 0)

	// if len(poolInfo.BaseStruct.GroupAttrs) == 0 {
	// 	return nil, errors.New("获取多维分析参数失败")
	// }

	dimensionsList = append(dimensionsList, poolInfo.BaseStruct.Dimensions...)

	// 获取分析的维度信息
	var groupCol string
	enumCodeMap := make(map[string]string)
	for _, attr := range poolInfo.BaseStruct.GroupAttrs {
		// 获取维度的查询字段名
		if attr.DimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,DimInfo为空")
			return nil, errors.New("未查询到维度信息,DimInfo为空")
		}
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息")
			return nil, errors.New("未查询到维度信息")
		}
		// 查询该维度的枚举值
		if attr.DimInfo != nil && len(attr.DimInfo.SelectedValues) > 0 {
			for _, enum := range attr.DimInfo.SelectedValues {
				enumCodeMap[enum.Code] = enum.Name
			}
		}
		if attr.NeedDrillDown {
			dimensionsList = append(dimensionsList, &dimensions.SelectedDimensionInfo{
				Id:               attr.DimInfo.Id,
				Name:             attr.DimInfo.Name,
				AttrType:         attr.DimInfo.AttrType,
				SelectedOperator: attr.DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{attr.Value},
				IsGroup:          true,
			})
		} else {
			if len(groupCol) == 0 {
				groupCol = dimInfo.DimColumn
			}
			dimensionsList = append(dimensionsList, attr.DimInfo)
		}
	}
	baseStruct := &dimensions.ProductAnalysisBaseStruct{
		BizType:    bizType,
		StartDate:  startDate,
		EndDate:    endDate,
		Dimensions: dimensionsList,
		GroupAttrs: poolInfo.BaseStruct.GroupAttrs,
	}

	dateExpr, _, err := base_struct_condition.GetDateExpr(ctx, startDate, endDate)
	if err != nil {
		return nil, err
	}
	params["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)

	exprCql, _, _, err := base_struct_condition.GetBaseConditionWithDims(ctx, baseStruct, false, dimMap, false, false)
	if err != nil {
		return nil, err
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}

	if exprCql != nil && exprCql.WhereClause != nil {
		whereStr := sql_parse.NewCQL().ParseExpression(exprCql.WhereClause)
		if len(exprCql.RawWhereClause) > 0 {
			whereStr = whereStr + " " + sql_parse.NewCQL().ParseRawExpression(exprCql.RawWhereClause)
		}
		if len(whereStr) > 0 {
			params["filter_param"] = whereStr
		}
	}

	return params, nil
}

func getPoolProdInfo(ctx context.Context, pordData *onetable.Table, poolId string) ([]dao.AnalysisPoolProductDo, error) {
	poolProdList := make([]dao.AnalysisPoolProductDo, 0)
	productDataMap := pordData.ToRawMap()
	for _, prodV := range productDataMap {
		prodId := prodV["prod_id"]
		prodIdDecimal, isOk := prodId.(decimal.Decimal)
		if !isOk {
			continue
		}
		poolProdList = append(poolProdList, dao.AnalysisPoolProductDo{
			PoolId:    poolId,
			ProductId: fmt.Sprintf("%v", prodIdDecimal),
		})
	}

	return poolProdList, nil
}

func getEffectDataAlertRules(ctx context.Context, analysisPoolAlertRuleDoList []*dao.AnalysisPoolAlertRuleDo) ([]*dao.AnalysisPoolAlertRuleDo, error) {
	result := make([]*dao.AnalysisPoolAlertRuleDo, 0)
	rpcReq := &data_alert.GetRulesByBusinessIdReq{
		BusinessId: consts.AnalysisBusinessId,
		ReqSource:  proto.String(consts.ReqSource),
	}

	logs.CtxInfo(ctx, "[getEffectDataAlertRules] 调用RPC GetRulesByBusinessId args: %v \n", *rpcReq)
	resp, err := ecom_smartop_data_alert.RawCall.GetRulesByBusinessId(ctx, rpcReq)

	if err != nil || resp == nil || resp.Data == nil {
		logs.CtxError(ctx, "[getEffectDataAlertRules] 调用RPC Invoke GetRulesByBusinessId error, err=%s", err.Error())
		return nil, err
	}
	logs.CtxInfo(ctx, "[getEffectDataAlertRules] 调用RPC GetRulesByBusinessId resp: %v \n", convert.ToJSONString(resp))

	for _, alertRule := range analysisPoolAlertRuleDoList {
		isSwitch := false
		for _, item := range resp.Data.Rules {
			if item == nil || item.Rule == nil || len(item.Rule.RuleId) == 0 {
				continue
			}
			if alertRule.AlertRuleId == item.Rule.RuleId && *item.Rule.Switch {
				isSwitch = true
			}
		}
		if isSwitch {
			result = append(result, alertRule)
		}
	}
	return result, nil
}
