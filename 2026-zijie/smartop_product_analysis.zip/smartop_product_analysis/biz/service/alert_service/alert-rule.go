package alert_service

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"code.byted.org/aweme-go/ajson"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/temai/go_portal_sdk/models"
	jsoniter "github.com/json-iterator/go"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	"code.byted.org/temai/go_lib/convert"
	"github.com/gogo/protobuf/proto"
	"github.com/thoas/go-funk"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	alert_rule "code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_alert_rule"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_smartop_data_alert/kitex_gen/ecom/smartop/data_alert"
	"code.byted.org/overpass/ecom_smartop_data_alert/rpc/ecom_smartop_data_alert"
	"github.com/jinzhu/copier"
)

type RuleIdInfo struct {
	AlertRuleId string `json:"alert_rule_id"`
}

type Receiver struct {
	PushUsers              string `json:"push_users"`
	PushGroup              string `json:"push_group"`
	IsAnalyzeProductStatus int32  `json:"is_analyze_product_status"`
}

var ASC_OP_LIST = []string{"<", "<="}

const AND_LOGIC = "and"
const IN_OP = "in"

// 新增预警规则
func (d *AlertService) AddAlertRule(ctx context.Context, req *alert_rule.CreateAnalysisPoolAlertRuleReq, user *models.UserInfo) (string, error) {
	if req.PoolId == "" {
		err := errors.New("[Params] need pool_id")
		logs.CtxWarn(ctx, err.Error())
		return "", err
	}

	// 获取到货盘的规则
	var poolInfoRule string
	ruleErr := mysql.DB(ctx).Raw(`select pool_rule from analysis_pool where pool_id = ? and is_delete = 0`, req.PoolId).Scan(&poolInfoRule).Error
	if ruleErr != nil {
		logs.CtxError(ctx, "[Rds] pool not exist, err=%s", ruleErr.Error())
		return "", ruleErr
	}
	poolStruct := &dimensions.ProductAnalysisBaseStruct{}
	json.Unmarshal([]byte(poolInfoRule), &poolStruct)

	logs.CtxInfo(ctx, "ruleStruct is %v", poolInfoRule)
	_, newCTX, _ := biz_utils.GetBizMetaInfo(ctx, poolStruct.BizType)

	receiveUsers := make([]*data_alert.AlertMsgReceiverUser, 0)
	receiveGroups := make([]*data_alert.AlertMsgReceiverLarkGroup, 0)
	receiveUsers = append(receiveUsers, &data_alert.AlertMsgReceiverUser{
		UserName: "1",
	}) // 需要填一个假的user_name，不然rpc接口会报错

	rpcReq := &data_alert.AddRuleReq{
		AuthorId:    *user.EmployeeId,
		BusinessId:  consts.AnalysisBusinessId,
		AuthorEmail: user.Email,
		AuthorName:  user.UserName,
		Receiver: &data_alert.AlertMsgReceiver{
			Users:      receiveUsers,
			LarkGroups: receiveGroups,
		},
	}
	//req.Rule = alertRuleDaysTypeCompletion(ctx, req.Rule)
	// 将req合并到rawReq
	copier.Copy(&rpcReq, &req)

	if req.Rule != nil && (req.Rule.AlertPrettyRule != nil || req.Rule.AlertIndicator != nil) {
		dimMap, dimMapErr := d.DimensionListDao.GetDimensionMap(ctx, poolStruct.BizType)
		if dimMapErr != nil {
			logs.CtxError(ctx, "[Rds] dimMap error exist, err=%s", dimMapErr.Error())
			return "", dimMapErr
		}
		rpcReq.Rule.SqlRuleConfig = doPrettyAlertParse(newCTX, req.Rule, poolStruct, dimMap)
		rpcReq.Rule.CustomRuleConfig = nil
		rpcReq.Rule.Logic = nil
		rpcReq.EventType = d.getEventType(req)
	} else if len(req.Rule.Rules) > 0 && (req.Rule.Rules[0].AlertPrettyRule != nil || req.Rule.Rules[0].AlertIndicator != nil) {
		for i, sql := range req.Rule.Rules {
			dimMap, dimMapErr := d.DimensionListDao.GetDimensionMap(ctx, poolStruct.BizType)
			if dimMapErr != nil {
				logs.CtxError(ctx, "[Rds] dimMap error exist, err=%s", dimMapErr.Error())
				return "", dimMapErr
			}
			rpcReq.Rule.Rules[i].SqlRuleConfig = doPrettyAlertParse(newCTX, sql, poolStruct, dimMap)
			rpcReq.Rule.Rules[i].CustomRuleConfig = nil
			rpcReq.Rule.Rules[i].Logic = nil
			rpcReq.EventType = d.getEventType(req)
		}
	}

	logs.CtxInfo(ctx, "[RPC] AddRule args: %s \n", ajson.ToString(*rpcReq))
	var (
		err         error
		addRuleResp *data_alert.AddRuleResp
	)

	addRuleResp, err = ecom_smartop_data_alert.RawCall.AddRule(ctx, rpcReq)
	if err != nil || addRuleResp == nil {
		logs.CtxError(ctx, "[RPC] Invoke AddRule error, err=%v", err)
		return "", err
	}

	push_users := ""
	push_group := ""

	if len(req.ReceiveUsers) != 0 {
		// 拼接用户id，用逗号分割
		push_users = strings.Join(req.ReceiveUsers, ",")
	}

	if len(req.ReceiveGroups) != 0 {
		// 拼接群组id，用逗号分割
		push_group = strings.Join(req.ReceiveGroups, ",")
	}

	ruleStr, _ := jsoniter.MarshalToString(req.Rule)
	alertProductStatusRule := ""
	if req.AlertProductStatusRule != nil {
		alertProductStatusRule = *req.AlertProductStatusRule
	}

	// 将数据写入analysis_pool_alert_rule表
	err = mysql.DB(ctx).Exec(`insert into analysis_pool_alert_rule set alert_rule_id = ?, alert_rule_name = ?, pool_id = ?, push_users = ?, push_group = ?, is_analyze_product_status = ?, alert_pretty_rule = ?, alert_product_status_rule = ?`, addRuleResp.RuleId, req.RuleName, req.PoolId, push_users, push_group, req.IsAnalyzeProductStatus, ruleStr, alertProductStatusRule).Error
	if err != nil {
		logs.CtxError(ctx, "[Rds] Insert alert rule error, err=%s", err.Error())
		return "", err
	}

	logs.CtxInfo(ctx, "[Rds] Insert alert rule success, ruleId is %s", addRuleResp.RuleId)

	return addRuleResp.RuleId, nil
	return "", nil
}

func (d *AlertService) getEventType(req *alert_rule.CreateAnalysisPoolAlertRuleReq) *string {
	if req.GetEventType() == base_struct_condition.ProductPlanGuess {
		return proto.String(req.GetEventType())
	}
	return proto.String(strings.Join([]string{req.GetEventType(), base_struct_condition.ApiProdBaseDfTableName, base_struct_condition.ApiProdPoolTableNameV2, base_struct_condition.ProductPlanGuess}, ","))
}

func doPrettyAlertParse(newCTX context.Context, rule *alert_rule.Rule, poolStruct *dimensions.ProductAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo) *data_alert.SQLRuleConfig {
	if rule.AlertPrettyRule != nil && len(rule.AlertPrettyRule.StartDate) == 0 {
		rule.AlertPrettyRule.StartDate = poolStruct.StartDate
	}
	if rule.AlertPrettyRule != nil && len(rule.AlertPrettyRule.EndDate) == 0 {
		rule.AlertPrettyRule.EndDate = poolStruct.EndDate
	}
	if rule.AlertPrettyRule != nil && rule.AlertPrettyRule.BizType == 0 {
		rule.AlertPrettyRule.BizType = poolStruct.BizType
	}
	var sql string
	if poolStruct.BizType == dimensions.BizType_GuessBoostData {
		sql = guessDoostAlertRuleToCql(newCTX, poolStruct, rule, dimMap)
	} else {
		sql = alertRuleToCql(newCTX, poolStruct, rule, dimMap)
	}
	sqlConfig := &data_alert.SQLRuleConfig{
		Id:          "",
		Sql:         sql,
		TimeUnit:    proto.Int64(rule.GetAlertIndicator().GetTimeUnit()),
		CompareType: rule.GetAlertIndicator().GetCompareType(),
		TimeRange:   proto.Int64(rule.GetAlertIndicator().GetTimeRange()),
	}
	return sqlConfig
}

// 根据货盘查询预警规则列表
func (d *AlertService) QueryAlertRulesByPool(ctx context.Context, req *alert_rule.QueryAnalysisPoolAlertRuleListReq) (*alert_rule.QueryAnalysisPoolAlertRuleListData, error) {
	if len(req.GetPoolId()) == 0 {
		err := errors.New("[Params] need pool_id")
		logs.CtxError(ctx, err.Error())
		return nil, err
	}

	// 根据pool_id查询所有的rule_id列表
	ruleIdInfos := make([]*RuleIdInfo, 0)
	ruleIds := make([]string, 0)
	poolID := req.PoolId

	err := mysql.DB(ctx).Raw(`
		select alert_rule_id from analysis_pool_alert_rule where pool_id = ? and is_delete = 0
	`, poolID).Scan(&ruleIdInfos).Error

	poolInfo, poolErr := dao.GetAnalysisPool(ctx, mysql.DB(ctx), req.GetPoolId())

	if err != nil {
		// 查询rule_id列表失败
		logs.CtxError(ctx, "[RDS] Query analysis_pool_alert_rule error, pool_id=%s, err=%s", poolID, err.Error())
		return nil, err
	}

	if poolErr != nil {
		// 查询rule_id列表失败
		logs.CtxError(ctx, "[RDS] Query analysis_pool_alert_rule error, pool_id=%s, err=%s", poolID, poolErr.Error())
		return nil, poolErr
	}

	logs.CtxInfo(ctx, "[RDS] Query analysis_pool_alert_rule success, ruleIdInfos=%v", ruleIdInfos)

	for _, item := range ruleIdInfos {
		if item == nil || item.AlertRuleId == "" {
			continue
		}

		ruleIds = append(ruleIds, item.AlertRuleId)
	}

	// 请求 GetRulesByBusinessId 接口获取规则列表
	rpcReq := &data_alert.GetRulesByBusinessIdReq{
		BusinessId: consts.AnalysisBusinessId,
		RuleName:   req.RuleName,
		Creators:   req.Creators,
		Priority:   req.TaskPriority,
		EventTypes: req.EventTypes,
		PageSize:   400,
		PageNo:     0,
		ReqSource:  proto.String(consts.ReqSource),
	}

	if len(ruleIds) == 1 {
		rpcReq.SetRuleId(proto.String(ruleIds[0]))
	}

	logs.CtxInfo(ctx, "[RPC] GetRulesByBusinessId args: %v \n", *rpcReq)
	resp, err := ecom_smartop_data_alert.RawCall.GetRulesByBusinessId(ctx, rpcReq)

	if err != nil || resp == nil || resp.Data == nil {
		logs.CtxError(ctx, "[RPC] Invoke GetRulesByBusinessId error, err=%v", err)
		return nil, err
	}

	// 根据ruleIds进行过滤
	poolRules := make([]*alert_rule.QueryAnalysisPoolAlertRuleData, 0)
	for _, item := range resp.Data.Rules {
		if item == nil || item.Rule == nil || item.Rule.RuleId == "" || !funk.Contains(ruleIds, item.Rule.RuleId) {
			continue
		}
		kiteItem := &alert_rule.EventRuleItem{}
		copier.Copy(kiteItem, &item)
		listData := &alert_rule.QueryAnalysisPoolAlertRuleData{
			Item: kiteItem,
			Pool: poolInfo,
		}

		poolRules = append(poolRules, listData)
	}
	listRule := &alert_rule.QueryAnalysisPoolAlertRuleListData{
		List: poolRules,
		Pool: poolInfo,
	}

	return listRule, nil
}

func (d *AlertService) QueryAlertRules(ctx context.Context, req *alert_rule.QueryAnalysisPoolAlertRuleListReq) (*alert_rule.QueryAnalysisPoolAlertRuleListData, error) {
	rpcReq := &data_alert.GetRulesByBusinessIdReq{
		BusinessId: consts.AnalysisBusinessId,
		RuleName:   req.RuleName,
		Creators:   req.Creators,
		Priority:   req.TaskPriority,
		EventTypes: req.EventTypes,
		ReqSource:  proto.String(consts.ReqSource),
		PageNo:     0,
		PageSize:   400,
	}

	logs.CtxInfo(ctx, "[RPC] GetRulesByBusinessId args: %v \n", *rpcReq)
	resp, err := ecom_smartop_data_alert.RawCall.GetRulesByBusinessId(ctx, rpcReq)

	if err != nil || resp == nil || resp.Data == nil {
		logs.CtxError(ctx, "[RPC] Invoke GetRulesByBusinessId error, err=%v", err)
		return nil, err
	}
	ruleIds := make([]string, 0)
	poolIds := make([]string, 0)

	ruleMap := make(map[string]dao.AnalysisPoolAlertRuleDo)
	poolMap := make(map[string]*analysis_pool.AnalysisPool)
	pools := make([]analysis_pool.AnalysisPool, 0)
	rulePools := make([]dao.AnalysisPoolAlertRuleDo, 0)
	listDatas := make([]*alert_rule.QueryAnalysisPoolAlertRuleData, 0)

	for _, item := range resp.Data.Rules {
		if item == nil || item.Rule == nil || len(item.Rule.RuleId) == 0 {
			continue
		}

		ruleIds = append(ruleIds, item.Rule.RuleId)
	}

	idErr := mysql.DB(ctx).Raw(`
		select alert_rule_id, pool_id, alert_pretty_rule from analysis_pool_alert_rule where alert_rule_id in ? and is_delete = 0
	`, ruleIds).Scan(&rulePools).Error

	if idErr != nil {
		logs.CtxError(ctx, "[RPC] Query pool failed, err=%v", idErr)
		return nil, idErr
	} else {
		for _, pool := range rulePools {
			if len(pool.AlertRuleId) == 0 {
				continue
			}
			ruleMap[pool.AlertRuleId] = pool
			poolIds = append(poolIds, pool.PoolId)
		}
	}

	poolErr := mysql.DB(ctx).Raw(`
		select pool_id, pool_name from analysis_pool where pool_id in ? and is_delete = 0
	`, poolIds).Scan(&pools).Error

	if poolErr != nil {
		logs.CtxError(ctx, "[RPC] Query pool failed, err=%s", poolErr.Error())
		return nil, poolErr
	} else {
		for _, pool := range pools {
			if pool.PoolId == nil || len(*pool.PoolId) == 0 {
				continue
			}
			poolMap[*pool.PoolId] = &analysis_pool.AnalysisPool{
				PoolId:   proto.String(pool.GetPoolId()),
				PoolName: proto.String(pool.GetPoolName()),
			}
		}
	}

	for _, item := range resp.Data.Rules {
		if item == nil || item.Rule == nil || len(item.Rule.RuleId) == 0 {
			continue
		}
		rule, ruleOK := ruleMap[item.Rule.RuleId]
		if ruleOK {
			_, poolOK := poolMap[rule.PoolId]
			if !poolOK {
				continue
			}
		} else {
			continue
		}

		copyItem := &alert_rule.EventRuleItem{}
		copier.Copy(copyItem, &item)
		if len(rule.AlertPrettyRule) > 0 {
			alertSqlRule := &alert_rule.Rule{}
			json.Unmarshal([]byte(rule.AlertPrettyRule), alertSqlRule)
			copyItem.Rule.Rule = alertSqlRule
		}

		listData := &alert_rule.QueryAnalysisPoolAlertRuleData{
			Item: copyItem,
			Pool: poolMap[rule.PoolId],
		}

		listDatas = append(listDatas, listData)
	}
	listRule := &alert_rule.QueryAnalysisPoolAlertRuleListData{
		List: listDatas,
	}
	return listRule, nil
}

// 查询单个预警规则
func (d *AlertService) GetAlertRuleDetail(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertRuleDetailReq) (*alert_rule.GetAnalysisPoolAlertRuleDetailData, error) {
	rpcReq := data_alert.NewGetRuleByRuleIdReq()

	// 将req深拷贝到rpcReq
	copier.Copy(&rpcReq, &req)

	// 调用 GetRuleByRuleId 接口获取规则详情
	logs.CtxInfo(ctx, "[RPC] GetRuleByRuleId args: %v \n", *rpcReq)
	resp, err := ecom_smartop_data_alert.RawCall.GetRuleByRuleId(ctx, rpcReq)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "[RPC] Invoke GetRuleByRuleId error, err=%v", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[RPC] GetRuleByRuleId resp: %v \n", resp)

	data := &alert_rule.GetAnalysisPoolAlertRuleDetailData{}
	ruleData := &alert_rule.EventRuleItem{}

	// 将rpc的规则详情拷贝到ruleData里面
	copier.Copy(&ruleData, &resp.Data)
	data.RuleData = ruleData

	// 查询receiveUsers和receiveGroups
	ruleInfo := &dao.AnalysisPoolAlertRuleDo{}
	err = mysql.DB(ctx).Raw(`
		select push_users, push_group, is_analyze_product_status, alert_product_status_rule, alert_pretty_rule from analysis_pool_alert_rule where alert_rule_id = ? and is_delete = 0
	`, req.RuleId).Scan(&ruleInfo).Error

	if err != nil {
		// 查询失败
		logs.CtxError(ctx, "[RDS] Query analysis_pool_alert_rule error, rule_id=%s, err=%s", req.RuleId, err.Error())
		return nil, err
	}

	logs.CtxInfo(ctx, "[RDS] Query analysis_pool_alert_rule success")
	if ruleInfo == nil {
		return nil, nil
	}

	if ruleInfo.PushUsers != "" {
		data.ReceiveUsers = strings.Split(ruleInfo.PushUsers, ",")
	}

	if ruleInfo.PushGroup != "" {
		data.ReceiveGroups = strings.Split(ruleInfo.PushGroup, ",")
	}
	if data.RuleData != nil && data.RuleData.Rule != nil {
		if len(ruleInfo.AlertPrettyRule) > 0 {
			alertSqlRule := &alert_rule.Rule{}
			json.Unmarshal([]byte(ruleInfo.AlertPrettyRule), alertSqlRule)
			data.RuleData.Rule.Rule = alertSqlRule
		}
	}

	data.IsAnalyzeProductStatus = proto.Int32(int32(ruleInfo.IsAnalyzeProductStatus))
	data.AlertProductStatusRule = &ruleInfo.AlertProductStatusRule

	return data, nil
}

// 查询数据源列表
func (d *AlertService) ListAlertEventType(ctx context.Context) ([]*data_alert.AlertEventTypeItem, error) {
	req := &data_alert.ListBusinessArcticAlertEventTypeReq{
		BusinessIds: []string{
			consts.AnalysisBusinessId,
		},
	}

	// 调用 ListBusinessArcticAlertEventType 接口获取业务线下的数据源列表
	logs.CtxInfo(ctx, "[RPC] ListBusinessArcticAlertEventType args: %v \n", *req)
	resp, err := ecom_smartop_data_alert.RawCall.ListBusinessArcticAlertEventType(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "[RPC] Invoke ListBusinessArcticAlertEventType error, err=%v", err)
		return nil, err
	}

	for _, business := range resp.BusinessEventTypes {
		if business != nil && business.BusinessId == consts.AnalysisBusinessId {
			// 返回该业务域下的eventType
			return business.Items, nil
		}
	}

	return make([]*data_alert.AlertEventTypeItem, 0), nil
}

// 获取预警维度列表
func (d *AlertService) GetAlertDimensions(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertDimensionsReq) ([]*data_alert.SelectValue, error) {
	rpcReq := &data_alert.GetEventCommonSelectReq{
		BusinessId: consts.AnalysisBusinessId, //「商品分析」业务线，写死
		EventType:  req.EventType,
	}

	// 调用 GetEventCommonSelect 接口获取预警维度列表
	logs.CtxInfo(ctx, "[RPC] GetEventCommonSelect args: %v \n", *rpcReq)
	resp, err := ecom_smartop_data_alert.RawCall.GetEventCommonSelect(ctx, rpcReq)
	if err != nil || resp == nil || resp.Data == nil {
		logs.CtxError(ctx, "[RPC] Invoke GetEventCommonSelect error, err=%v", err)
		return nil, err
	}

	return resp.Data.Selects, nil
}

// 获取数据指标列表
func (d *AlertService) GetAlertIndicators(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertIndicatorsReq) ([]*data_alert.ArcticAlertIndicator, error) {
	rpcReq := &data_alert.GetArcticAlertIndicatorListReq{
		BusinessId: consts.AnalysisBusinessId, //「商品分析」业务线，写死
	}
	rpcReq.Metrics = nil // 将metrics字段置为nil，否者会报错
	copier.Copy(&rpcReq, &req)
	logs.CtxInfo(ctx, "[RPC] GetArcticAlertIndicatorList args: %v \n", *rpcReq)

	// 调用 GetArcticAlertIndicatorList 接口获取预警维度列表
	resp, err := ecom_smartop_data_alert.RawCall.GetArcticAlertIndicatorList(ctx, rpcReq)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "[RPC] Invoke GetArcticAlertIndicatorList error, err=%v", err)
		return nil, err
	}
	// 调用 GetArcticAlertIndicatorList 接口获取预警维度列表
	return resp.Indicators, nil
}

// 删除监控任务
func (d *AlertService) DeleteAlertRule(ctx context.Context, ruleId string) (*data_alert.DeleteRuleResp, error) {
	rpcReq := &data_alert.DeleteRuleReq{
		RuleId: ruleId,
	}

	// 将analysis_pool_alert_rule表中该条规则记录中的is_delete字段置为1
	err := mysql.DB(ctx).Exec(`update analysis_pool_alert_rule set is_delete = ? where alert_rule_id = ?`, 1, ruleId).Error
	if err != nil {
		logs.CtxError(ctx, "[Rds] Delete alert rule error, ruleId=%s, err=%s", ruleId, err.Error())
		return nil, err
	}

	// 调用 DeleteRule 接口删除监控任务
	resp, err := ecom_smartop_data_alert.RawCall.DeleteRule(ctx, rpcReq)
	if err != nil {
		logs.CtxError(ctx, "[RPC] Invoke DeleteRule error, ruleId=%s, err=%s", ruleId, err.Error())
		return nil, err
	}

	return resp, nil
}

func (d *AlertService) UpdateAnalysisPoolAlertRule(ctx context.Context, req *alert_rule.UpdateAnalysisPoolAlertRuleReq) (resp *data_alert.UpdateRuleResp, err error) {
	receiveUsers := make([]*data_alert.AlertMsgReceiverUser, 0)
	receiveGroups := make([]*data_alert.AlertMsgReceiverLarkGroup, 0)
	receiveUsers = append(receiveUsers, &data_alert.AlertMsgReceiverUser{
		UserName: "1",
	}) // 需要填一个假的user_name，不然rpc接口会报错

	var pushUser string
	var pushGroup string

	if req.IsSetRule() {
		req.Rule = alertRuleDaysTypeCompletion(ctx, req.Rule)
	}

	if len(req.ReceiveUsers) != 0 {
		// 拼接用户id，用逗号分割
		pushUser = strings.Join(req.ReceiveUsers, ",")
	}

	if len(req.ReceiveGroups) != 0 {
		// 拼接群组id，用逗号分割
		pushGroup = strings.Join(req.ReceiveGroups, ",")
	}
	var poolInfoRule string
	ruleErr := mysql.DB(ctx).Raw(`select pool_rule from analysis_pool a inner join analysis_pool_alert_rule b on a.pool_id = b.pool_id where b.alert_rule_id = ? and a.is_delete = 0 and b.is_delete = 0`, req.RuleId).Scan(&poolInfoRule).Error
	if ruleErr != nil {
		logs.CtxError(ctx, "[Rds] pool not exist, err=%s", ruleErr.Error())
		return nil, ruleErr
	}

	rpcReq := &data_alert.UpdateRuleReq{
		BusinessId: consts.AnalysisBusinessId,
	}

	copier.Copy(&rpcReq, &req)

	poolStruct := &dimensions.ProductAnalysisBaseStruct{}
	json.Unmarshal([]byte(poolInfoRule), &poolStruct)

	_, newCTX, _ := biz_utils.GetBizMetaInfo(ctx, poolStruct.BizType)

	if req.Rule != nil && (req.Rule.AlertPrettyRule != nil || req.Rule.AlertIndicator != nil) {
		dimMap, dimMapErr := d.DimensionListDao.GetDimensionMap(ctx, poolStruct.BizType)
		if dimMapErr != nil {
			logs.CtxError(ctx, "[Rds] dimMap error exist, err=%s", dimMapErr.Error())
			return nil, dimMapErr
		}
		rpcReq.Rule.SqlRuleConfig = doPrettyAlertParse(newCTX, req.Rule, poolStruct, dimMap)
		rpcReq.Rule.CustomRuleConfig = nil
		rpcReq.Rule.Logic = nil
		rpcReq.EventType = proto.String(strings.Join([]string{req.GetEventType(), base_struct_condition.ApiProdBaseDfTableName, base_struct_condition.ApiProdPoolTableNameV2}, ","))
	} else if len(req.Rule.Rules) > 0 && (req.Rule.Rules[0].AlertPrettyRule != nil || req.Rule.Rules[0].AlertIndicator != nil) {
		for i, sql := range req.Rule.Rules {
			dimMap, dimMapErr := d.DimensionListDao.GetDimensionMap(ctx, poolStruct.BizType)
			if dimMapErr != nil {
				logs.CtxError(ctx, "[Rds] dimMap error exist, err=%s", dimMapErr.Error())
				return nil, dimMapErr
			}
			rpcReq.Rule.Rules[i].SqlRuleConfig = doPrettyAlertParse(newCTX, sql, poolStruct, dimMap)
			rpcReq.Rule.Rules[i].CustomRuleConfig = nil
			rpcReq.Rule.Rules[i].Logic = nil
			rpcReq.EventType = proto.String(strings.Join([]string{req.GetEventType(), base_struct_condition.ApiProdBaseDfTableName, base_struct_condition.ApiProdPoolTableNameV2}, ","))
		}
	}

	// 去掉users字段
	rpcReq.SetReceiver(&data_alert.AlertMsgReceiver{
		Users:      receiveUsers,
		LarkGroups: receiveGroups,
	})
	resp, respErr := ecom_smartop_data_alert.RawCall.UpdateRule(ctx, rpcReq)

	if respErr != nil {
		logs.CtxError(ctx, "[rpc] update data alert error, err=%v", err)
		return nil, err
	}

	ruleStr, _ := jsoniter.MarshalToString(req.Rule)

	alertProductStatusRule := ""
	if req.AlertProductStatusRule != nil {
		alertProductStatusRule = *req.AlertProductStatusRule
	}

	// 将数据写入analysis_pool_alert_rule表
	err = mysql.DB(ctx).Exec(`Update analysis_pool_alert_rule set alert_rule_name = ?, push_users = ?, push_group = ?, is_analyze_product_status = ?, alert_pretty_rule = ?, alert_product_status_rule = ? where alert_rule_id = ?`, req.RuleName, pushUser, pushGroup, req.IsAnalyzeProductStatus, ruleStr, alertProductStatusRule, req.RuleId).Error
	if err != nil {
		logs.CtxError(ctx, "[Rds] update alert rule error, err=%v", err)
		return nil, err
	}
	return resp, respErr

}

func (d *AlertService) UpdateAnalysisPoolAlertRuleStatus(ctx context.Context, req *alert_rule.UpdateAnalysisPoolAlertRuleStatusReq) (*data_alert.UpdateRuleActiveStatusResp, error) {
	rpcReq := &data_alert.UpdateRuleActiveStatusReq{}
	copier.Copy(&rpcReq, &req)
	return ecom_smartop_data_alert.RawCall.UpdateRuleActiveStatus(ctx, rpcReq)
}

func (t *AlertService) AnalysisRuleConvertToAlertRule(ctx context.Context, req *alert_rule.ConvertToAlertRuleReq, supportedFields []string) (*alert_rule.IndicatorNodeValueCondition, bool, error) {
	baseStruct := req.GetBaseStruct()
	bizType := req.GetBizType()

	if baseStruct == nil {
		return nil, true, nil
	}

	condition := &alert_rule.IndicatorNodeValueCondition{}
	var commonConditions []*alert_rule.IndicatorNodeValueCondition

	dimMap, dimErr := t.DimensionListDao.GetDimensionMap(ctx, bizType)
	if dimErr != nil {
		return nil, false, dimErr
	}

	// 基本都是and规则
	for _, item := range baseStruct.Dimensions {
		// 去掉动态规则
		if len(item.SelectedValues) == 0 {
			continue
		}

		dimTmpColumn, dimOK := dimMap[convert.ToInt64(item.Id)]
		if !dimOK {
			return nil, false, nil
		}

		dimColumn := dimTmpColumn.DimColumn
		if !funk.ContainsString(supportedFields, dimColumn) {
			return nil, false, nil
		}

		condition.Logic = AND_LOGIC
		var codes []string
		for _, code := range item.SelectedValues {
			if len(code.GetCode()) > 0 {
				codes = append(codes, code.GetCode())
			}
			if len(code.GetTypeValue()) > 0 {
				codes = append(codes, code.GetTypeValue()...)
			}
		}
		commonCondition := &alert_rule.IndicatorNodeValueCommonCondition{
			Dimension: proto.String(dimColumn),
			Op:        proto.String(IN_OP),
			Values:    codes,
		}
		ruleCondition := &alert_rule.IndicatorNodeValueCondition{
			CommonCondition: commonCondition,
			ConditionType:   0,
			Logic:           AND_LOGIC,
		}
		commonConditions = append(commonConditions, ruleCondition)
	}

	for _, item := range baseStruct.GroupAttrs {
		// 去掉动态规则
		if item.Value == nil {
			continue
		}

		dimTmpColumn, dimOK := dimMap[convert.ToInt64(item.DimInfo.Id)]
		if !dimOK {
			return nil, false, nil
		}

		dimColumn := dimTmpColumn.DimColumn

		if !funk.ContainsString(supportedFields, dimColumn) {
			return nil, false, nil
		}
		condition.Logic = AND_LOGIC
		var codes []string
		if req.GetIsTotal() || !item.NeedDrillDown {
			for _, v := range item.DimInfo.SelectedValues {
				if len(v.GetCode()) > 0 {
					codes = append(codes, v.GetCode())
				}
				if len(v.GetTypeValue()) > 0 {
					codes = append(codes, v.GetTypeValue()...)
				}
			}
		} else {
			if len(item.Value.GetCode()) > 0 {
				codes = append(codes, item.Value.GetCode())
			}
			if len(item.Value.GetTypeValue()) > 0 {
				codes = append(codes, item.Value.GetTypeValue()...)
			}
		}
		commonCondition := &alert_rule.IndicatorNodeValueCommonCondition{
			Dimension: proto.String(dimColumn),
			Op:        proto.String(IN_OP),
			Values:    codes,
		}
		ruleCondition := &alert_rule.IndicatorNodeValueCondition{
			CommonCondition: commonCondition,
			ConditionType:   0,
			Logic:           AND_LOGIC,
		}
		commonConditions = append(commonConditions, ruleCondition)
	}
	condition.Conditions = commonConditions
	condition.ConditionType = -1
	condition.Logic = AND_LOGIC
	return condition, true, nil
}

func alertRuleDaysTypeCompletion(ctx context.Context, rule *alert_rule.Rule) *alert_rule.Rule {
	commonCondition := &alert_rule.IndicatorNodeValueCommonCondition{
		Dimension: proto.String("days_type"),
		Op:        proto.String("in"),
		Values:    []string{"1d"},
	}
	appendCondition := &alert_rule.IndicatorNodeValueCondition{
		CommonCondition: commonCondition,
		ConditionType:   0,
		Logic:           AND_LOGIC,
	}
	if rule.CustomRuleConfig != nil {
		if rule.CustomRuleConfig.Condition != nil && len(rule.CustomRuleConfig.Condition.Conditions) > 0 {
			if isNeedCompletion(rule.GetCustomRuleConfig()) {
				rule.CustomRuleConfig.Condition.Conditions = append(rule.CustomRuleConfig.Condition.Conditions, appendCondition)
			}
		} else if rule.CustomRuleConfig.Condition != nil && rule.CustomRuleConfig.Condition.CommonCondition != nil {
			if isSingleNeedCompletion(rule.CustomRuleConfig.Condition.CommonCondition) {
				commonItem := &alert_rule.IndicatorNodeValueCommonCondition{}
				copier.Copy(commonItem, rule.CustomRuleConfig.Condition.CommonCondition)
				commonAppendCondition := &alert_rule.IndicatorNodeValueCondition{
					CommonCondition: commonItem,
					ConditionType:   0,
					Logic:           AND_LOGIC,
				}
				var conditions []*alert_rule.IndicatorNodeValueCondition
				conditions = append(conditions, appendCondition)
				conditions = append(conditions, commonAppendCondition)
				rule.CustomRuleConfig.Condition.Conditions = conditions
				rule.CustomRuleConfig.Condition.CommonCondition = nil
			} else {
				logs.CtxWarn(ctx, "alertRuleDaysTypeCompletion warn: invalid custom rule config, %v", rule)
			}
		}
	} else {
		if len(rule.Rules) > 0 {
			for _, itemRule := range rule.Rules {
				if itemRule == nil || itemRule.CustomRuleConfig == nil || itemRule.CustomRuleConfig.Condition == nil || len(itemRule.CustomRuleConfig.Condition.Conditions) == 0 {
					continue
				}
				batchConditions := make([]*alert_rule.IndicatorNodeValueCondition, 0)
				copier.Copy(batchConditions, itemRule.CustomRuleConfig.Condition.Conditions)
				if isNeedCompletion(itemRule.GetCustomRuleConfig()) {
					itemRule.CustomRuleConfig.Condition.Conditions = append(batchConditions, appendCondition)
				}
			}
		} else {
			logs.CtxWarn(ctx, "alertRuleDaysTypeCompletion warn: invalid custom rule config, %v", rule)
		}
	}
	logs.CtxInfo(ctx, "rule is %v", rule)
	return rule
}

func isNeedCompletion(rule *alert_rule.CustomRuleConfig) bool {
	needCompletion := true
	for _, condition := range rule.Condition.Conditions {
		if condition.CommonCondition != nil && !isSingleNeedCompletion(condition.CommonCondition) {
			needCompletion = false
		}
	}
	return needCompletion
}

func isSingleNeedCompletion(commonRule *alert_rule.IndicatorNodeValueCommonCondition) bool {
	return commonRule.GetDimension() != "days_type"
}

func guessDoostAlertRuleToCql(ctx context.Context, poolStruct *dimensions.ProductAnalysisBaseStruct, alertRule *alert_rule.Rule, dimMap map[int64]*dao.DimensionInfo) string {
	if poolStruct == nil || alertRule == nil {
		return ""
	}
	// 货盘规则
	req := &dimensions.ProductAnalysisBaseStruct{}
	copier.Copy(&req, &poolStruct)

	// 聚合预警规则
	alertFilter := alertRule.AlertPrettyRule
	if alertFilter != nil && len(alertFilter.Dimensions) > 0 {
		req.Dimensions = append(req.Dimensions, alertFilter.Dimensions...)
	}

	// 查询params
	curr, err := base_struct_condition.GetBaseStructConditionParam(ctx, base_struct_condition.OsParamsReq{
		BaseStruct:     req,
		DimMap:         dimMap,
		DimColMap:      nil,
		MultiDimension: []string{"prod_id"},
	}, base_struct_condition.SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "guessDoostAlertRuleToCql|err:%s", err.Error())
	}

	// 返回SQL
	SQL := `select
            prod_id,
            max(prod_name) prod_name,
            sum(pv) pv_sum,
			sum(oder) order_sum,
			sum(gmv) gmv_sum,
            sum(experi_pv) exp_pv_sum,
			sum(experi_order) exp_order_sum,
			sum(experi_gmv) exp_gmv_sum,
			sum(base_pv) base_pv_sum,
			sum(base_order) base_order_sum,
			sum(base_gmv) base_gmv_sum,
            if(base_pv_sum = 0, 0, exp_pv_sum / base_pv_sum - 1) ab_pv_rate,
            if(
                base_order_sum = 0,
                0,
                exp_order_sum / base_order_sum -1
            ) ab_order_rate,
            if(base_gmv_sum = 0, 0, exp_gmv_sum / base_gmv_sum -1) ab_gmv_rate,
            if(
                base_gmv_sum = 0
                or base_pv_sum = 0
                or exp_pv_sum = 0,
                0,
                (exp_gmv_sum / exp_pv_sum) / (base_gmv_sum / base_pv_sum) - 1
            ) ab_gpm_rate,
            if(
                exp_pv_sum = 0
                or base_pv_sum = 0
                or base_order_sum = 0,
                0,
                (exp_order_sum / exp_pv_sum) / (base_order_sum / base_pv_sum) - 1
            ) ab_opm_rate,
            ${alert_key} as __value__
        from
            (
                select
                    *,
                    if(scene == '', '1', scene) scene_join
                from
                    app_product_plan_guess_new_df
                where
                    date between '${app_product_plan_guess_new_df.start_date}' and '${app_product_plan_guess_new_df.end_date}'
        and ${filter_param}
        and prod_id > 0
        and plan_id > 0
        )
        group by
            prod_id
    	having
        	max(date) == '${app_product_plan_guess_new_df.end_date}'
        order by
            __value__ ${order_by}
        limit
            15000`
	SQL = strings.ReplaceAll(SQL, "${alert_key}", alertRule.GetAlertIndicator().GetIndicatorCode())
	SQL = strings.ReplaceAll(SQL, "${filter_param}", curr["filter_param"].(string))
	SQL = strings.ReplaceAll(SQL, "${order_by}", utils.If(funk.ContainsString(ASC_OP_LIST, alertRule.GetOp()), "asc", "desc"))
	SQL = strings.ReplaceAll(SQL, "\n", "")
	SQL = strings.ReplaceAll(SQL, "\t", "")
	return SQL
}

func alertRuleToCql(ctx context.Context, poolRule *dimensions.ProductAnalysisBaseStruct, alertRule *alert_rule.Rule, dimMap map[int64]*dao.DimensionInfo) string {
	// 1.0 pool_rule 主要是为了生成 货盘条件
	rebuildPool, rebuildErr := groupAttrStructRebuild(ctx, poolRule, dimMap, poolRule.GetIsTotal())
	if rebuildErr != nil {
		logs.CtxInfo(ctx, "rebuildErr is %v", rebuildErr)
	} else {
		str, _ := jsoniter.MarshalToString(rebuildPool)
		logs.CtxInfo(ctx, "rebuild pool is %v", str)
	}

	indicatorRule := utils.If(alertRule.AlertPrettyRule == nil, poolRule, alertRule.AlertPrettyRule)
	indicatorDefaultSelect, indicatorSelectErr := getAlertSupportIndicators(ctx, indicatorRule)
	indicatorThresholdSelect, needAsc := alertRule.GetAlertIndicator().GetIndicatorCode(), funk.ContainsString(ASC_OP_LIST, alertRule.GetOp())

	if indicatorSelectErr != nil {
		logs.CtxError(ctx, "indicatorSelectErr is %v", indicatorSelectErr)
		return ""
	}

	poolRuleReq := base_struct_condition.BaseStructConditionReq{
		BaseStruct:    rebuildPool,
		NeedProdID:    true,
		DimMap:        dimMap,
		IsCompare:     false,
		IsAlertRule:   true,
		CKSettingType: base_struct_condition.CKSettingNone,
	}
	_, poolRuleCql, poolErr := base_struct_condition.GetBaseStructConditionCql(ctx, poolRuleReq)
	if poolRuleCql == nil || poolRuleCql.WhereClause == nil {
		return ""
	}
	logs.CtxInfo(ctx, "poolRuleCql is %v, err is %v", poolRuleCql.Compile(), poolErr)

	alertRuleCql := &sql_parse.CQL{}
	if alertRule.GetAlertPrettyRule() != nil {
		alertRuleReq := base_struct_condition.BaseStructConditionReq{
			BaseStruct:    alertRule.GetAlertPrettyRule(),
			NeedProdID:    false,
			DimMap:        dimMap,
			IsCompare:     false,
			IsAlertRule:   true,
			CKSettingType: base_struct_condition.CKSettingSub,
		}
		_, alertRuleCql, _ = base_struct_condition.GetBaseStructConditionCql(ctx, alertRuleReq)
		if alertRuleCql == nil || alertRuleCql.FromClause == nil {
			return ""
		}
		dataExpr, _ := base_struct_condition.GetAlertDataExpr(alertRuleCql.FromClause.Table)
		alertRuleCql.AddWhereAndValue(dataExpr)
	} else if poolRuleCql != nil {
		dataExpr, _ := base_struct_condition.GetAlertDataExpr(poolRuleCql.FromClause.Table)
		alertRuleCql.AddWhereAndValue(dataExpr)
	}

	if alertRuleCql.WhereClause != nil && len(alertRuleCql.WhereClause.Children) > 0 {
		newWhere := &sql_parse.Expression{}
		newWhere = sql_parse.NewExpressionWithChild(sql_parse.AND, alertRuleCql.WhereClause.Children)
		newWhere.Children = append(newWhere.Children, poolRuleCql.WhereClause)
		poolRuleCql.WhereClause = newWhere
	}

	poolRuleCql.AddSelect(indicatorDefaultSelect)
	poolRuleCql.AddSelect("max(prod_name)")
	poolRuleCql.AddSelect(fmt.Sprintf("%s as __value__", indicatorThresholdSelect))
	poolRuleCql.AddGroupBy("prod_name")
	poolRuleCql.OrderBy(utils.If(needAsc, sql_parse.ASC, sql_parse.DESC), "__value__")
	poolRuleCql.Limit(10000)
	logs.CtxInfo(ctx, "result is %v", poolRuleCql.Compile())

	return poolRuleCql.Compile()
}

func getAlertSupportIndicators(ctx context.Context, rule *dimensions.ProductAnalysisBaseStruct) (string, error) {
	category, _, err := biz_info.GetFilterDimCategory(ctx, rule)
	if err != nil {
		return "", err
	}

	defaultSql := fmt.Sprintf("sum(%s) as pay_ord_cnt,sum(%s) as pay_gmv,sum(%s) as show_pv,sum(%s) as click_pv", consts.GetTableCol("pay_ord_cnt", category, rule.BizType), consts.GetTableCol("pay_gmv", category, rule.BizType), consts.GetTableCol("show_pv", category, rule.BizType), consts.GetTableCol("click_pv", category, rule.BizType))
	return fmt.Sprintf("%s,round(click_pv/show_pv, 5) as ctr,round(pay_ord_cnt/click_pv, 5) as cvr,round(pay_ord_cnt/show_pv, 5) as pvr,round(pay_ord_cnt/show_pv*1000, 5) as opm,round((pay_gmv/toFloat64(show_pv))*1000, 5) as gpm", defaultSql), nil

}

func groupAttrStructRebuild(ctx context.Context, poolRule *dimensions.ProductAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo, isTotal bool) (*dimensions.ProductAnalysisBaseStruct, error) {
	dimensionsList := make([]*dimensions.SelectedDimensionInfo, 0)
	if len(poolRule.Dimensions) > 0 {
		dimensionsList = append(dimensionsList, poolRule.Dimensions...)
	}

	// 获取分析的维度信息

	for _, attr := range poolRule.GroupAttrs {
		// 获取维度的查询字段名
		if attr.DimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息,DimInfo为空")
			return nil, errors.New("未查询到维度信息,DimInfo为空")
		}
		dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "未查询到维度信息 %v", attr.DimInfo.Id)
			return nil, errors.New("未查询到维度信息")
		}
		var codes []*dimensions.EnumElement
		// 查询该维度的枚举值
		if isTotal || !attr.NeedDrillDown {
			codes = append(codes, attr.DimInfo.SelectedValues...)
		} else {
			codes = append(codes, attr.Value)
		}
		dimensionsList = append(dimensionsList, &dimensions.SelectedDimensionInfo{
			Id:               attr.DimInfo.Id,
			Name:             attr.DimInfo.Name,
			AttrType:         attr.DimInfo.AttrType,
			SelectedOperator: attr.DimInfo.SelectedOperator,
			SelectedValues:   codes,
			IsGroup:          true,
		})

		dimensionsListStr, _ := jsoniter.MarshalToString(dimensionsList)
		logs.CtxInfo(ctx, "dimensionsList codes is %v", dimensionsListStr)
	}

	return &dimensions.ProductAnalysisBaseStruct{
		BizType:    poolRule.BizType,
		StartDate:  poolRule.StartDate,
		EndDate:    poolRule.EndDate,
		Dimensions: dimensionsList,
		GroupAttrs: poolRule.GroupAttrs,
	}, nil
}
