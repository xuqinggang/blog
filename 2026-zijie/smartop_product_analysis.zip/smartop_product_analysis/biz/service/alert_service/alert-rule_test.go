package alert_service

import (
	"context"
	"testing"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	alert_rule "code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_alert_rule"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
)

func Test_guessDoostAlertRuleToCql(t *testing.T) {
	type args struct {
		ctx        context.Context
		poolStruct *dimensions.ProductAnalysisBaseStruct
		alertRule  *alert_rule.Rule
		dimMap     map[int64]*dao.DimensionInfo
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := guessDoostAlertRuleToCql(tt.args.ctx, tt.args.poolStruct, tt.args.alertRule, tt.args.dimMap); got != tt.want {
				t.Errorf("guessDoostAlertRuleToCql() = %v, want %v", got, tt.want)
			}
		})
	}
}
