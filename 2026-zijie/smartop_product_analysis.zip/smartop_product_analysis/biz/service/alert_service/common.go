package alert_service

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"

	alert_rule "code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_alert_rule"
	"code.byted.org/overpass/ecom_smartop_data_alert/kitex_gen/ecom/smartop/data_alert"
	"code.byted.org/temai/go_portal_sdk/models"
)

type AlertService struct {
	AlertService     IAlertService
	DimensionListDao dao.IDimensionListDao
}

type IAlertService interface {
	AddAlertRule(ctx context.Context, req *alert_rule.CreateAnalysisPoolAlertRuleReq, user *models.UserInfo) (string, error)
	QueryAlertRulesByPool(ctx context.Context, req *alert_rule.QueryAnalysisPoolAlertRuleListReq) (*alert_rule.QueryAnalysisPoolAlertRuleListData, error)
	QueryAlertRules(ctx context.Context, req *alert_rule.QueryAnalysisPoolAlertRuleListReq) (*alert_rule.QueryAnalysisPoolAlertRuleListData, error)
	GetAlertRuleDetail(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertRuleDetailReq) (*alert_rule.GetAnalysisPoolAlertRuleDetailData, error)
	ListAlertEventType(ctx context.Context) ([]*data_alert.AlertEventTypeItem, error)
	GetAlertDimensions(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertDimensionsReq) ([]*data_alert.SelectValue, error)
	GetAlertIndicators(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertIndicatorsReq) ([]*data_alert.ArcticAlertIndicator, error)
	GetRulesWitExceptionProdStatusInfos(ctx context.Context, req *alert_rule.GetRulesWitExceptionProdStatusInfosReq) ([]*alert_rule.RuleWitExceptionProdInfos, error)
	DeleteAlertRule(ctx context.Context, ruleId string) (*data_alert.DeleteRuleResp, error)
	UpdateAnalysisPoolAlertRule(ctx context.Context, req *alert_rule.UpdateAnalysisPoolAlertRuleReq) (*data_alert.UpdateRuleResp, error)
	UpdateAnalysisPoolAlertRuleStatus(ctx context.Context, req *alert_rule.UpdateAnalysisPoolAlertRuleStatusReq) (*data_alert.UpdateRuleActiveStatusResp, error)
	AnalysisRuleConvertToAlertRule(ctx context.Context, req *alert_rule.ConvertToAlertRuleReq, supportedFields []string) (*alert_rule.IndicatorNodeValueCondition, bool, error)
	GetAlertProdStatusRuleIndicator(ctx context.Context, req *alert_rule.GetAlertProdStatusRuleIndicatorReq) (*alert_rule.GetAlertProdStatusRuleIndicatorData, error)
}
