package lark_service

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/lark"
)

type AccessTokenInfo struct {
	AccessToken        string `json:"access_token"`
	ExpiresTime        int64  `json:"expires_time"`
	RefreshToken       string `json:"refresh_token"`
	RefreshExpiresTime int64  `json:"refresh_expires_time"`
}

type ILarkService interface {
	GetDocContent(ctx context.Context, url string, employeeId *string) (string, error)
	CheckDocPermission(ctx context.Context, docUrl string, employeeId *string) (res *lark.CheckDocPermissionResponseData, err error)
}

type LarkService struct {
}
