package lark_service

import (
	"context"
	"fmt"
	"regexp"

	// "sync"
	"time"

	arctic_utils "code.byted.org/ecom/arctic_lib/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"

	// "code.byted.org/ecom/channel_op_platform_data/biz/tools/utils"
	"code.byted.org/gopkg/logs"
	"github.com/bytedance/sonic"
	larkcore "github.com/larksuite/oapi-sdk-go/v3/core"
	larksheets "github.com/larksuite/oapi-sdk-go/v3/service/sheets/v3"
	// "golang.org/x/sync/semaphore"
)

type LarkSheetValueRange struct {
	Range  string          `json:"range"`
	Values [][]interface{} `json:"values"`
}

type LarkSheetData struct {
	Revision         int                  `json:"revision"`
	SpreadsheetToken string               `json:"spreadsheetToken"`
	ValueRange       *LarkSheetValueRange `json:"valueRange"`
}

type WriteLarkSheetReq struct {
	ValueRange *LarkSheetValueRange `json:"valueRange"`
}

type LarkSheetReadResp struct {
	Code int            `json:"code"`
	Msg  string         `json:"msg"`
	Data *LarkSheetData `json:"data"`
}

type MergeCellsReq struct {
	Range     string `json:"range"`
	MergeType string `json:"mergeType"`
}

type MergeCellsV3Req struct {
	MergeCells []*larksheets.MergeCell `json:"merge_cells"`
}

type BatchSetCellStyleData struct {
	Ranges []string    `json:"ranges"`
	Style  interface{} `json:"style"`
}

type BatchSetCellStyleReq struct {
	Data []*BatchSetCellStyleData `json:"data"`
}

type LarkSheetMultipleValue struct {
	Type   string `json:"type"`
	Values any    `json:"values"`
}

// 获取飞书表格token
func GetLarkSheetToken(ctx context.Context, url string) (string, error) {
	pattern := regexp.QuoteMeta(consts.LarkSheetUrl) + "([a-zA-Z0-9]+)$"
	regex := regexp.MustCompile(pattern)
	match := regex.FindStringSubmatch(url)
	if len(match) < 2 {
		logs.CtxError(ctx, "[GetLarkSheetToken] invalid lark sheet url: %s", url)
		return "", fmt.Errorf("invalid lark sheet url")
	}

	token := match[1] // lark sheet token
	return token, nil
}

// 获取工作表：https://open.larkoffice.com/document/server-docs/docs/sheets-v3/spreadsheet-sheet/query
func GetSheet(ctx context.Context, token string) ([]*larksheets.Sheet, error) {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[GetSheet] lark client not initialized")
		return nil, fmt.Errorf("lark client not initialized")
	}

	req := larksheets.NewQuerySpreadsheetSheetReqBuilder().SpreadsheetToken(token).Build()
	resp, err := larkClient.Sheets.SpreadsheetSheet.Query(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[GetSheet] query sheet error: %s", err.Error())
		return nil, err
	}

	if !resp.Success() {
		logs.CtxError(ctx, "[GetSheet] query sheet failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
		return nil, fmt.Errorf("query sheet failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
	}

	return resp.Data.Sheets, nil
}

// 读取单个范围：https://open.larkoffice.com/document/server-docs/docs/sheets-v3/data-operation/reading-a-single-range
func ReadSheet(ctx context.Context, token string, rangeStr string) (*LarkSheetData, error) {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[ReadSheet] lark client not initialized")
		return nil, fmt.Errorf("lark client not initialized")
	}

	resp, err := larkClient.Get(ctx, fmt.Sprintf("/open-apis/sheets/v2/spreadsheets/%s/values/%s", token, rangeStr), nil, larkcore.AccessTokenTypeTenant)
	if err != nil {
		logs.CtxError(ctx, "[ReadSheet] read sheet error: %s", err.Error())
		return nil, err
	}

	if resp.StatusCode != 200 || len(resp.RawBody) == 0 {
		logs.CtxError(ctx, "[ReadSheet] read sheet failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
		return nil, fmt.Errorf("read sheet failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
	}

	body := &LarkSheetReadResp{}
	err = sonic.Unmarshal(resp.RawBody, body)
	if err != nil {
		logs.CtxError(ctx, "[ReadSheet] unmarshal body error: %s", err.Error())
		return nil, err
	}

	if body.Code != 0 || body.Data == nil {
		logs.CtxError(ctx, "[ReadSheet] read sheet failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
		return nil, fmt.Errorf("read sheet failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
	}

	return body.Data, nil
}

// 向单个范围写入数据：https://open.larkoffice.com/document/server-docs/docs/sheets-v3/data-operation/write-data-to-a-single-range
func WriteSheet(ctx context.Context, token string, rangeStr string, values [][]interface{}) error {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[WriteSheet] lark client not initialized")
		return fmt.Errorf("lark client not initialized")
	}

	resp, err := larkClient.Put(ctx, fmt.Sprintf("/open-apis/sheets/v2/spreadsheets/%s/values", token), &WriteLarkSheetReq{
		ValueRange: &LarkSheetValueRange{
			Range:  rangeStr,
			Values: values,
		},
	}, larkcore.AccessTokenTypeTenant)

	if err != nil {
		logs.CtxError(ctx, "[WriteSheet] write sheet error: %s", err.Error())
		return err
	}

	if resp.StatusCode != 200 || len(resp.RawBody) == 0 {
		logs.CtxError(ctx, "[WriteSheet] write sheet failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
		return fmt.Errorf("write sheet failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
	}

	body := &RawBody{}
	err = sonic.Unmarshal(resp.RawBody, body)
	if err != nil {
		logs.CtxError(ctx, "[WriteSheet] unmarshal body error: %s", err.Error())
		return err
	}

	if body.Code != 0 {
		logs.CtxError(ctx, "[WriteSheet] write sheet failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
		return fmt.Errorf("write sheet failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
	}

	return nil
}

// 批量写入数据（覆盖更新）
func BatchWriteSheet(ctx context.Context, token string, sheetId string, values [][]interface{}) error {
	// 每次写入1000行
	if len(values) > 0 {
		for i := 0; i < ((len(values)-1)/consts.LarkSheetBatchNum)+1; i++ {
			start := i * consts.LarkSheetBatchNum
			end := (i + 1) * consts.LarkSheetBatchNum
			if end > len(values) {
				end = len(values)
			}
			tempValues := values[start:end]

			// 构造range
			startIdx := start + 1
			rangeStr := fmt.Sprintf("%v!A%v:%v%v", sheetId, startIdx, arctic_utils.ConvNumToChars(int64(len(tempValues[0]))), startIdx+len(tempValues)-1)
			err := WriteSheet(ctx, token, rangeStr, tempValues)
			if err != nil {
				return err
			}
		}
	}

	return nil
}

// 合并单元格V3版本（支持多个范围合并）：https://open.larkoffice.com/document/server-docs/docs/sheets-v3/spreadsheet-sheet/merge_cells
func MergeCellsV3(ctx context.Context, token string, sheetId string, req *MergeCellsV3Req) error {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[MergeCellsV3] lark client not initialized")
		return fmt.Errorf("lark client not initialized")
	}

	resp, err := larkClient.Post(ctx, fmt.Sprintf("/open-apis/sheets/v3/spreadsheets/%s/sheets/%s/merge_cells", token, sheetId), req, larkcore.AccessTokenTypeTenant)
	if err != nil {
		logs.CtxError(ctx, "[MergeCellsV3] merge cells error: %s", err.Error())
		return err
	}

	if resp.StatusCode != 200 || len(resp.RawBody) == 0 {
		logs.CtxError(ctx, "[MergeCellsV3] merge cells failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
		return fmt.Errorf("merge cells failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
	}

	body := &RawBody{}
	err = sonic.Unmarshal(resp.RawBody, body)
	if err != nil {
		logs.CtxError(ctx, "[MergeCellsV3] unmarshal body error: %s", err.Error())
		return err
	}
	if body.Code != 0 {
		logs.CtxError(ctx, "[MergeCellsV3] merge cells failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
		return fmt.Errorf("merge cells failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
	}

	return nil
}

// 合并单元格：https://open.larkoffice.com/document/server-docs/docs/sheets-v3/data-operation/merge-cells
func MergeCells(ctx context.Context, token string, rangeStr string) error {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[MergeCells] lark client not initialized")
		return fmt.Errorf("lark client not initialized")
	}

	resp, err := larkClient.Post(ctx, fmt.Sprintf("/open-apis/sheets/v2/spreadsheets/%s/merge_cells", token), &MergeCellsReq{
		Range:     rangeStr,
		MergeType: "MERGE_ALL",
	}, larkcore.AccessTokenTypeTenant)

	if err != nil {
		logs.CtxError(ctx, "[MergeCells] merge cells error: %s", err.Error())
		return err
	}

	if resp.StatusCode != 200 || len(resp.RawBody) == 0 {
		logs.CtxError(ctx, "[MergeCells] merge cells failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
		return fmt.Errorf("merge cells failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
	}

	body := &RawBody{}
	err = sonic.Unmarshal(resp.RawBody, body)
	if err != nil {
		logs.CtxError(ctx, "[MergeCells] unmarshal body error: %s", err.Error())
		return err
	}

	if body.Code != 0 {
		logs.CtxError(ctx, "[MergeCells] merge cells failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
		return fmt.Errorf("merge cells failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
	}

	return nil
}

// // 批量合并单元格（会有限频，推荐使用MergeCellsV3方法实现）
// func BatchMergeCells(ctx context.Context, token string, rangeStrList []string) error {
// 	weighted := semaphore.NewWeighted(10)
// 	// callerInstance := utils.Result[any](nil)

// 	mutex := new(sync.Mutex)
// 	asyncCaller := utils.AsyncCaller(func(v any) (any, error) {
// 		mutex.Lock()
// 		defer mutex.Unlock()
// 		rangeStr, ok := v.(string)
// 		if !ok {
// 			logs.CtxError(ctx, "[BatchMergeCells] 类型转换失败")
// 			return nil, nil
// 		}
// 		err := MergeCells(ctx, token, rangeStr)
// 		if err != nil {
// 			logs.CtxError(ctx, "[BatchMergeCells] merge cells error: %s", err.Error())
// 			return nil, nil
// 		}
// 		return nil, nil
// 	}).SetSemaphore(weighted)

// 	for _, rangeStr := range rangeStrList {
// 		// callerInstance = asyncCaller.Call(rangeStr)
// 		asyncCaller.Call(rangeStr)
// 	}

// 	// if callerInstance == nil {
// 	// 	logs.CtxError(ctx, "[BatchMergeCells] merge cells failed, callerInstance为空")
// 	// 	return fmt.Errorf("merge cells failed, callerInstance为空")
// 	// }

// 	return nil
// }

// 批量设置单元格样式：https://open.larkoffice.com/document/server-docs/docs/sheets-v3/data-operation/batch-set-cell-style
func BatchSetCellStyle(ctx context.Context, token string, data []*BatchSetCellStyleData) error {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[BatchSetCellStyle] lark client not initialized")
		return fmt.Errorf("lark client not initialized")
	}

	resp, err := larkClient.Put(ctx, fmt.Sprintf("/open-apis/sheets/v2/spreadsheets/%s/styles_batch_update", token), &BatchSetCellStyleReq{
		Data: data,
	}, larkcore.AccessTokenTypeTenant)

	if err != nil {
		logs.CtxError(ctx, "[BatchSetCellStyle] batch set cell style error: %s", err.Error())
		return err
	}

	if resp.StatusCode != 200 || len(resp.RawBody) == 0 {
		logs.CtxError(ctx, "[BatchSetCellStyle] batch set cell style failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
		return fmt.Errorf("batch set cell style failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
	}

	body := &RawBody{}
	err = sonic.Unmarshal(resp.RawBody, body)
	if err != nil {
		logs.CtxError(ctx, "[BatchSetCellStyle] unmarshal body error: %s", err.Error())
		return err
	}

	if body.Code != 0 {
		logs.CtxError(ctx, "[BatchSetCellStyle] batch set cell style failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
		return fmt.Errorf("batch set cell style failed, code: %d, msg: %s, requestId: %s", body.Code, body.Msg, resp.RequestId())
	}

	return nil
}

// 导出到飞书表格
func ExportLarkSheet(ctx context.Context, data *[][]any, email string, extra string) (string, error) {
	larkBot, err := GetDefaultLarkBot(ctx)
	if err != nil {
		logs.CtxError(ctx, "[ExportLarkSheet] get default lark bot error: %s", err.Error())
		return "", err
	}
	fileName := GenFileName(ctx, email, extra)
	url, err := larkBot.GenDocWithDatas(ctx, fileName, *data, email)
	if err != nil {
		logs.CtxError(ctx, "[ExportLarkSheet] gen doc with multi sheet datas error: %s", err.Error())
		return "", err
	}
	return url, nil
}

// 生成文件名
func GenFileName(ctx context.Context, curUser string, extra string) string {
	if extra != "" {
		return fmt.Sprintf("%s_%s_%s", time.Now().Format(consts.Fmt_DateTime), curUser, extra)
	}
	return fmt.Sprintf("%s_%s", time.Now().Format(consts.Fmt_DateTime), curUser)
}
