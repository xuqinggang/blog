package lark_service

import (
	"context"
	"encoding/base64"
	"time"

	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/gopkg/retry"
	"code.byted.org/temai/go_lib/convert"
	"github.com/larksuite/oapi-sdk-go/api/core/request"
	"github.com/larksuite/oapi-sdk-go/api/core/response"
	"github.com/larksuite/oapi-sdk-go/core"
	"github.com/larksuite/oapi-sdk-go/core/tools"
	larkim "github.com/larksuite/oapi-sdk-go/v3/service/im/v1"
)

func UploadImage(ctx context.Context, businessId int64, imgStr string, imgName string) (string, error) {
	imgByte, err := base64.StdEncoding.DecodeString(imgStr)
	if err != nil {
		logs.CtxError(ctx, "[UploadImage] DecodeString err[%+v], imgResp.ImgStr[%s]", err, imgStr)
		return "", err
	}

	var imgKey string
	var uploadErr error

	limited := retry.DoSync("UploadImage"+imgName, 3, func(tryingTimes int) (retry bool) {
		imgKey, uploadErr = uploadImage(ctx, businessId, imgByte, imgName)
		if uploadErr != nil {
			logs.CtxWarn(ctx, "[UploadImage] err[%+v] tryingTimes[%d]", err, tryingTimes)
			time.Sleep(time.Second * time.Duration((tryingTimes+1)*30))
			return true
		}
		return false
	})

	if uploadErr != nil {
		logs.CtxError(ctx, "[UploadImage] error:[%v]", uploadErr.Error())
		return "", uploadErr
	}

	if limited || imgKey == "" {
		logs.CtxError(ctx, "[UploadImage] retry limited")
		return "", errors.New("UploadImage retry limited")
	}

	return imgKey, nil
}

func uploadImage(ctx context.Context, businessId int64, image []byte, imageName string) (string, error) {
	coreCtx := core.WrapContext(ctx)
	builder := larkim.NewCreateImageReqBuilder().Body(&larkim.CreateImageReqBody{
		ImageType: convert.ToStringPtr("message"),
		Image:     request.NewFile().SetContent(image).SetName(imageName),
	})
	result, err := GetInstance(businessId).Im.Image.Create(coreCtx, builder.Build())
	// 在遇到问题时，打印 request id，作为 Oncall 的输入，方便解决问题
	logs.CtxInfo(ctx, "request id:%s", coreCtx.GetRequestID())
	logs.CtxInfo(ctx, "HTTP status code:%d", coreCtx.GetHTTPStatusCode())
	logs.CtxInfo(ctx, "HTTP response header:%s", coreCtx.GetHeader())
	if err != nil {
		realErr := err.(*response.Error)
		logs.CtxError(ctx, "err:%+v", realErr)
		return "", err
	} else if result == nil || result.Data == nil || result.Data.ImageKey == nil {
		err = errors.New("图片上传飞书失败")
		return "", err
	}
	logs.CtxInfo(ctx, "result:%+v", tools.Prettify(result))
	return *result.Data.ImageKey, nil
}
