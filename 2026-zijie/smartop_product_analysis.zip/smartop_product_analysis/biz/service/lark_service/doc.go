package lark_service

import (
	"context"
	"fmt"
	"regexp"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/lark"
	"code.byted.org/gopkg/logs/v2"
	"github.com/bytedance/sonic"
	larkcore "github.com/larksuite/oapi-sdk-go/v3/core"
	larkauthen "github.com/larksuite/oapi-sdk-go/v3/service/authen/v1"
	larkdocs "github.com/larksuite/oapi-sdk-go/v3/service/docs/v1"
	larkdrive "github.com/larksuite/oapi-sdk-go/v3/service/drive/v1"
)

// 获取云文档内容：https://open.larkoffice.com/document/docs/docs-v1/get?appId=cli_a6b2866f9dedd00b
func (d *LarkService) GetDocContent(ctx context.Context, url string, employeeId *string) (string, error) {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[GetDocContent] lark client not initialized")
		return "", fmt.Errorf("lark client not initialized")
	}

	regex := regexp.MustCompile("https://bytedance(.*?).larkoffice.com/(docx|wiki)/([a-zA-Z0-9]+)$")
	match := regex.FindStringSubmatch(url)
	if len(match) != 4 {
		logs.CtxError(ctx, "[GetDocContent] invalid lark doc url: %s", url)
		return "", fmt.Errorf("invalid lark doc url: %s", url)
	}

	// 获取用户信息
	if employeeId == nil || *employeeId == "" {
		user := utils.GetUserInfo(ctx)
		if user == nil || user.EmployeeId == nil {
			logs.CtxError(ctx, "[GetDocContent] get user info failed")
			return "", fmt.Errorf("get user info failed")
		}
		employeeId = user.EmployeeId
	}

	// 获取缓存
	cache, err := redis.Get(ctx, fmt.Sprintf("lark_user_token:%s", *employeeId))
	if err != nil {
		logs.CtxError(ctx, "[GetDocContent] get user token failed, err=%v", err)
		return "", err
	}

	var userToken string
	if len(cache) > 0 {
		var accessTokenInfo *AccessTokenInfo
		err = sonic.UnmarshalString(cache, &accessTokenInfo)
		if err != nil {
			logs.CtxError(ctx, "[GetDocContent] unmarshal access token info failed, err=%v", err)
			return "", err
		}
		if accessTokenInfo != nil && accessTokenInfo.AccessToken != "" && accessTokenInfo.ExpiresTime > time.Now().Unix() {
			// 缓存中存在accessToken且没有过期
			userToken = accessTokenInfo.AccessToken
		}
	}

	docToken := match[len(match)-1]
	// 创建请求对象
	req := larkdocs.NewGetContentReqBuilder().
		DocToken(docToken).
		DocType(`docx`).
		ContentType(`markdown`).
		Lang(`zh`).
		Build()
	var resp *larkdocs.GetContentResp
	if userToken != "" {
		resp, err = larkClient.Docs.V1.Content.Get(ctx, req, larkcore.WithUserAccessToken(userToken))
	} else {
		resp, err = larkClient.Docs.V1.Content.Get(ctx, req)
	}
	if err != nil {
		logs.CtxError(ctx, "[GetDocContent] get doc content failed, err=%v", err)
		return "", err
	}
	if !resp.Success() || resp.Data == nil {
		logs.CtxError(ctx, "[GetDocContent] query doc content failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
		return "", fmt.Errorf("query doc content failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
	}

	return *resp.Data.Content, nil
}

// 判断用户云文档权限：https://open.larkoffice.com/document/server-docs/docs/permission/permission-member/auth?appId=cli_a6b2866f9dedd00b
func CheckUserDocPermission(ctx context.Context, url string, userToken *string) (bool, error) {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[CheckUserDocPermission] lark client not initialized")
		return false, fmt.Errorf("lark client not initialized")
	}

	regex := regexp.MustCompile("https://bytedance(.*?).larkoffice.com/(.*?)/([a-zA-Z0-9]+)$")
	matches := regex.FindStringSubmatch(url)
	if len(matches) != 4 {
		logs.CtxError(ctx, "[CheckUserDocPermission] invalid lark doc url: %s", url)
		return false, fmt.Errorf("invalid lark doc url: %s", url)
	}

	docType := matches[2]
	docToken := matches[3]

	// 创建请求对象
	req := larkdrive.NewAuthPermissionMemberReqBuilder().
		Token(docToken).
		Type(docType).
		Action(`view`).
		Build()

	var err error
	var resp *larkdrive.AuthPermissionMemberResp
	if userToken != nil && *userToken != "" {
		resp, err = larkClient.Drive.V1.PermissionMember.Auth(ctx, req, larkcore.WithUserAccessToken(*userToken))
	} else {
		resp, err = larkClient.Drive.V1.PermissionMember.Auth(ctx, req)
	}
	// 发起请求
	if err != nil {
		logs.CtxError(ctx, "[CheckUserDocPermission] check doc permission failed, err: %v", err)
		return false, err
	}
	if !resp.Success() || resp.Data == nil || resp.Data.AuthResult == nil {
		logs.CtxError(ctx, "[CheckUserDocPermission] check doc permission failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
		return false, fmt.Errorf("check doc permission failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
	}
	return *resp.Data.AuthResult, nil
}

// 校验文档权限
func (d *LarkService) CheckDocPermission(ctx context.Context, docUrl string, employeeId *string) (res *lark.CheckDocPermissionResponseData, err error) {
	res = &lark.CheckDocPermissionResponseData{
		HasPermission: false,
	}
	var reason lark.DocNoPermissionReason

	// 1. 获取用户信息
	if employeeId == nil || *employeeId == "" {
		user := utils.GetUserInfo(ctx)
		if user == nil || user.EmployeeId == nil {
			logs.CtxError(ctx, "[CheckDocPermission] get user info failed")
			return nil, fmt.Errorf("获取用户信息失败")
		}
		employeeId = user.EmployeeId
	}

	// 2. 获取缓存
	cache, err := redis.Get(ctx, fmt.Sprintf("lark_user_token:%s", *employeeId))
	if err != nil {
		logs.CtxError(ctx, "[CheckDocPermission] get user token failed, err=%v", err)
		return nil, err
	}
	if len(cache) > 0 {
		// 命中缓存，解析缓存中的accessTokenInfo
		accessTokenInfo := &AccessTokenInfo{}
		err = sonic.UnmarshalString(cache, &accessTokenInfo)
		if err != nil {
			logs.CtxError(ctx, "[CheckDocPermission] unmarshal access token info failed, err=%v", err)
			return nil, err
		}

		// 3. 缓存中是否存在accessToken且未过期
		if accessTokenInfo != nil && accessTokenInfo.AccessToken != "" && accessTokenInfo.ExpiresTime > time.Now().Unix() {
			// 校验应用是否有云文档权限
			res.HasPermission, err = CheckUserDocPermission(ctx, docUrl, &accessTokenInfo.AccessToken)
			if err != nil {
				logs.CtxError(ctx, "[CheckDocPermission] check doc permission failed, err: %v", err)
				return nil, err
			}
			if !res.HasPermission {
				reason = lark.DocNoPermissionReason_NoPermission
				res.Reason = &reason
			}
			return
		}

		// 5. 缓存中是否存在refreshToken且未过期
		if accessTokenInfo != nil && accessTokenInfo.RefreshToken != "" && accessTokenInfo.RefreshExpiresTime > time.Now().Unix() {
			// 刷新 accessToken
			var refreshResp *larkauthen.CreateOidcRefreshAccessTokenRespData
			refreshResp, err = RefreshUserAccessToken(ctx, accessTokenInfo.RefreshToken)
			if err != nil {
				// 刷新失败，返回错误
				logs.CtxError(ctx, "[CheckDocPermission] refresh user access token failed, err: %v", err)
				return nil, err
			}
			if refreshResp != nil {
				// 刷新成功，更新缓存
				if refreshResp.AccessToken != nil {
					accessTokenInfo.AccessToken = *refreshResp.AccessToken
				}
				if refreshResp.ExpiresIn != nil {
					accessTokenInfo.ExpiresTime = time.Now().Unix() + int64(*refreshResp.ExpiresIn) // 转换为秒级时间戳
				}
				if refreshResp.RefreshToken != nil {
					accessTokenInfo.RefreshToken = *refreshResp.RefreshToken
				}
				if refreshResp.RefreshExpiresIn != nil {
					accessTokenInfo.RefreshExpiresTime = time.Now().Unix() + int64(*refreshResp.RefreshExpiresIn) // 转换为秒级时间戳
				}

				cache, err = sonic.MarshalString(accessTokenInfo)
				if err != nil {
					logs.CtxError(ctx, "[CheckDocPermission] marshal access token info failed, err=%v", err)
					return nil, err
				}
				err = redis.Set(ctx, fmt.Sprintf("lark_user_token:%s", *employeeId), cache, 30*24*time.Hour) // refresh_token过期时间通常为30天
				if err != nil {
					logs.CtxError(ctx, "[CheckDocPermission] cache user token failed, err: %v", err)
					return nil, err
				}

				// 校验应用是否有云文档权限
				res.HasPermission, err = CheckUserDocPermission(ctx, docUrl, &accessTokenInfo.AccessToken)
				if err != nil {
					logs.CtxError(ctx, "[CheckDocPermission] check doc permission failed, err: %v", err)
					return nil, err
				}
				if !res.HasPermission {
					reason = lark.DocNoPermissionReason_NoPermission
					res.Reason = &reason
				}
				return
			}
		}
	}

	// 没有缓存使用TenantAccessToken鉴权
	res.HasPermission, err = CheckUserDocPermission(ctx, docUrl, nil)
	if err != nil {
		logs.CtxError(ctx, "[CheckDocPermission] check doc permission failed, err: %v", err)
		return nil, err
	}
	if !res.HasPermission {
		reason = lark.DocNoPermissionReason_NoAuth
		res.Reason = &reason
	}

	return
}
