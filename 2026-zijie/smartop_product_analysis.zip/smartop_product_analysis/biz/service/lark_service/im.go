package lark_service

import (
	"context"
	"encoding/json"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gopkg/logs"
	"github.com/bytedance/sonic"
	larkcore "github.com/larksuite/oapi-sdk-go/v3/core"
	larkcontact "github.com/larksuite/oapi-sdk-go/v3/service/contact/v3"
	larkim "github.com/larksuite/oapi-sdk-go/v3/service/im/v1"
)

type CardEntityData struct {
	TemplateId          string                 `json:"template_id"`
	TemplateVersionName string                 `json:"template_version_name"`
	TemplateVariable    map[string]interface{} `json:"template_variable"`
}

type CardEntity struct {
	Type string         `json:"type"`
	Data CardEntityData `json:"data"`
}

type BatchSendMsgUserReq struct {
	MsgType string     `json:"msg_type"`
	Card    CardEntity `json:"card"`
	OpenIds []string   `json:"open_ids"`
}

type BatchSendMsgUserRespData struct {
	MessageId            string   `json:"message_id"`
	InvalidDepartmentIds []string `json:"invalid_department_ids"`
	InvalidOpenIds       []string `json:"invalid_open_ids"`
	InvalidUserIds       []string `json:"invalid_user_ids"`
	InvalidUnionIds      []string `json:"invalid_union_ids"`
}

type BatchSendMsgUserResp struct {
	Code int                      `json:"code"`
	Msg  string                   `json:"msg"`
	Data BatchSendMsgUserRespData `json:"data"`
}

type CardData struct {
	TemplateId          string                 `json:"template_id"`
	TemplateVersionName *string                `json:"template_version_name,omitempty"`
	TemplateVariable    map[string]interface{} `json:"template_variable,omitempty"`
}

type CardContent struct {
	Type string   `json:"type"`
	Data CardData `json:"data"`
}

func BatchSendMsgToUser(ctx context.Context, users []string, card CardEntity) (sendResp *BatchSendMsgUserResp, err error) {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[BatchSendMsgToUser] lark client not initialized")
		return nil, fmt.Errorf("lark client not initialized")
	}

	resp, err := larkClient.Post(ctx, "/open-apis/message/v4/batch_send/", &BatchSendMsgUserReq{
		MsgType: "interactive",
		Card:    card,
		OpenIds: users,
	}, larkcore.AccessTokenTypeTenant)

	if err != nil {
		logs.CtxError(ctx, "[BatchSendMsgToUser] BatchSendMsgToUser error: %s", err.Error())
		return nil, err
	}

	if resp.StatusCode != 200 || len(resp.RawBody) == 0 {
		logs.CtxError(ctx, "[BatchSendMsgToUser] BatchSendMsgToUser failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
		return nil, fmt.Errorf("merge cells failed, statusCode: %d, body: %s, requestId: %s", resp.StatusCode, string(resp.RawBody), resp.RequestId())
	}

	body := &BatchSendMsgUserResp{}
	err = sonic.Unmarshal(resp.RawBody, body)
	if err != nil {
		logs.CtxError(ctx, "[BatchSendMsgToUser] unmarshal body error: %s", err.Error())
		return nil, err
	}

	if body.Code != 0 {
		logs.CtxError(ctx, "[BatchSendMsgToUser] BatchSendMsgToUser failed, code: %d, msg: %s", body.Code, body.Msg)
		return nil, fmt.Errorf("merge cells failed, code: %d, msg: %s", body.Code, body.Msg)
	}

	return body, nil
}

func BatchTransformOpenId(ctx context.Context, emails []string) (openIds []string, err error) {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[BatchTransformOpenId] lark client not initialized")
		return openIds, fmt.Errorf("lark client not initialized")
	}

	openIds = make([]string, 0)
	if len(emails) == 0 {
		return openIds, nil
	}
	req := larkcontact.NewBatchGetIdUserReqBuilder().
		UserIdType("open_id").
		Body(larkcontact.NewBatchGetIdUserReqBodyBuilder().
			Emails(emails).
			IncludeResigned(false).
			Build()).
		Build()

	resp, err := larkClient.Contact.User.BatchGetId(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[BatchTransformOpenId] BatchGetId error: %s", err.Error())
		return openIds, err
	}
	if !resp.Success() {
		logs.CtxError(ctx, "[BatchTransformOpenId] BatchGetId failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
		return openIds, fmt.Errorf("merge cells failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
	}
	if resp.Data == nil {
		return openIds, nil
	}
	if len(resp.Data.UserList) == 0 {
		return openIds, nil
	}
	for _, user := range resp.Data.UserList {
		if user.UserId != nil {
			openIds = append(openIds, *user.UserId)
		}
	}
	return openIds, nil
}

func BatchTransformOpenIdWithEmployeeId(ctx context.Context, employeeIds []string) (openIds []string, err error) {
	openIds = make([]string, 0)
	if len(employeeIds) == 0 {
		return openIds, nil
	}

	emails := make([]string, 0)
	opUsers, err := utils.RPCBatchGetOpUserByEmployeeIds(ctx, employeeIds)
	if err != nil || len(opUsers) == 0 {
		logs.CtxError(ctx, "[BatchTransformOpenIdWithEmployeeId] BatchGetOpUserByEmployeeIds error: %s", err.Error())
		return openIds, err
	}
	for _, user := range opUsers {
		if user == nil || user.Email == nil {
			continue
		}
		emails = append(emails, *user.Email)
	}
	return BatchTransformOpenId(ctx, emails)
}

// 发送消息卡片
func SendCardMsg(ctx context.Context, email string, card *CardData) error {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[SendCardMsg] lark client not initialized")
		return fmt.Errorf("lark client not initialized")
	}

	if card == nil {
		return fmt.Errorf("card data must not be nil")
	}

	cardContent := CardContent{
		Type: "template",
		Data: *card,
	}

	cardJson, err := json.Marshal(cardContent)
	if err != nil {
		logs.CtxError(ctx, "[SendCardMsg] Marshal cardContent error: %s", err.Error())
		return err
	}

	// 创建请求对象
	req := larkim.NewCreateMessageReqBuilder().
		ReceiveIdType("email").
		Body(larkim.NewCreateMessageReqBodyBuilder().
			ReceiveId(email).
			MsgType("interactive").
			Content(string(cardJson)).
			Build()).
		Build()

	// 发送消息卡片
	resp, err := larkClient.Im.Message.Create(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[SendCardMsg] send card message error: %s", err.Error())
		return err
	}
	if !resp.Success() {
		logs.CtxError(ctx, "[SendCardMsg] send card message failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
		return fmt.Errorf("create message failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
	}
	return nil
}
