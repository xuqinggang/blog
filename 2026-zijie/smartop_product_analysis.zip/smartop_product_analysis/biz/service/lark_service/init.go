package lark_service

import (
	"context"
	"strconv"
	"sync"

	arcticLark "code.byted.org/ecom/arctic_lib/lark"
	"code.byted.org/ecom/arctic_lib/lark/doc"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"
	lark "github.com/larksuite/oapi-sdk-go/v3"
)

var (
	larkClient map[int64]*lark.Client
	once       sync.Once
)

type RawBody struct {
	Code int         `json:"code"`
	Msg  string      `json:"msg"`
	Data interface{} `json:"data"`
}

func Init() {
	once.Do(func() {
		larkClient = make(map[int64]*lark.Client)
		var larkBidConf = map[string]map[string]string{}
		if err := tcc.GetTccConfWithUnmarshalTarget(context.TODO(), "productAnalysisBotLark", &larkBidConf); err != nil {
			panic(err)
		} else if len(larkBidConf) == 0 {
			panic("飞书bot配置为空")
		}
		for businessIdStr, larkConf := range larkBidConf {
			if len(larkConf) < 2 || larkConf["appId"] == "" || larkConf["appSecret"] == "" {
				panic("业务线: " + businessIdStr + ", 飞书bot配置为空")
			}
			businessId, _ := strconv.Atoi(businessIdStr)
			larkClient[int64(businessId)] = lark.NewClient(larkConf["appId"], larkConf["appSecret"])
		}
	})
}

func GetInstance(businessId int64) *lark.Client {
	Init()
	client, exists := larkClient[businessId]
	if !exists || client == nil {
		logs.CtxError(context.Background(), "[GetLarkClient] lark client not initialized for businessId: %v", businessId)
		return nil
	}
	return client
}

func GetLarkConfig(businessId int64) (appId string, appSecret string, err error) {
	var larkBidConf = map[string]map[string]string{}
	if err = tcc.GetTccConfWithUnmarshalTarget(context.TODO(), "productAnalysisBotLark", &larkBidConf); err != nil {
		return "", "", err
	}

	config, exist := larkBidConf[convert.ToString(businessId)]
	if !exist {
		return "", "", err
	}

	return config["appId"], config["appSecret"], nil
}

func GetDefaultClientConfig() (string, string, error) {
	return GetLarkConfig(1000)
}

func GetDefaultLarkClient() *lark.Client {
	return GetInstance(1000)
}

// GetDefaultLarkBot 获取流量洞察机器人的默认实例
func GetDefaultLarkBot(ctx context.Context) (instance *arcticLark.LarkBot, err error) {
	appID, appSecret, err := GetDefaultClientConfig()
	if err == nil && appID != "" && appSecret != "" {
		instance := arcticLark.NewLarkBot(ctx, appID, appSecret, "", "")
		instance.SetFolderToken(DEFAULT_EXPORT_LARK_FOLDER)
		instance.SetLarkSheetBot(doc.NewSheetBotWithHeartbeat(appID, appSecret))
		return &instance, nil
	}
	return nil, err
}

const DEFAULT_EXPORT_LARK_FOLDER = "RevxfjSJRlaPZodB70Ncpdr2nuB"
