package lark_service

import (
	"context"
	"errors"
	"fmt"
	"time"

	"code.byted.org/ecom/common/utils"
	utils2 "code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/lang/gg/gptr"
	larkevent "github.com/larksuite/oapi-sdk-go/v3/event"
	"github.com/larksuite/oapi-sdk-go/v3/event/dispatcher"
	larkws "github.com/larksuite/oapi-sdk-go/v3/ws"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/gopkg/logs"
	"github.com/bytedance/sonic"
	lark "github.com/larksuite/oapi-sdk-go/v3"
	larkcore "github.com/larksuite/oapi-sdk-go/v3/core"
	larkapproval "github.com/larksuite/oapi-sdk-go/v3/service/approval/v4"
)

const (
	MarketOperationAppId     = "cli_a834ec7d32fc1013"
	MarketOperationAppSecret = "o0bfsnAwqkOFUGu75Zrkoc1chg3SiJ4A"

	MarketOperationApprovalCode = "ABA2F449-CDB6-44E4-AC78-AEB71D8F56BC"

	EventStatusPending  = "PENDING"
	EventStatusApproved = "APPROVED"
	EventStatusRejected = "REJECTED"
	EventStatusCANCELED = "CANCELED"
)

var larkCli *lark.Client

func MarketLarkInit() {
	// 创建 Client
	larkCli = lark.NewClient(MarketOperationAppId, MarketOperationAppSecret,
		lark.WithLogLevel(larkcore.LogLevelDebug),
		lark.WithReqTimeout(3*time.Second),
		lark.WithEnableTokenCache(true))

	//activityService := activity_service.ActivityService{}

	// 订阅事件：https://open.larkoffice.com/document/server-docs/event-subscription-guide/event-subscription-configure-/request-url-configuration-case#d286cc88
	eventHandler := dispatcher.NewEventDispatcher("", "").
		OnCustomizedEvent("approval_instance", func(ctx context.Context, event *larkevent.EventReq) error {
			//approvalCallback, err := activityService.ActivityApprovalCallback(ctx, &activity.ApprovalCallbackRequest{
			//	Event:     &activity.ApprovalCallbackEvent{
			//		Type:         nil,
			//		ApprovalCode: ,
			//		InstanceCode: nil,
			//		Status:       nil,
			//		Uuid:         nil,
			//	},
			//	Base:      nil,
			//})
			//if err != nil {
			//	return err
			//}
			fmt.Printf("[ OnCustomizedEvent access ], type: message, data: %s\n", string(event.Body))
			return nil
		})

	cli := larkws.NewClient(MarketOperationAppId, MarketOperationAppSecret,
		larkws.WithEventHandler(eventHandler),
		larkws.WithLogLevel(larkcore.LogLevelDebug),
	)

	// 启动客户端
	err := cli.Start(context.Background())
	if err != nil {
		panic(err)
	}
}

func CreateActivityApprovalInstance(ctx context.Context, email, uuid string, form interface{}) (string, error) {
	larkOpenId := GetLarkOpenId(ctx, email)
	if larkOpenId == "" {
		logs.CtxError(ctx, "[CreateApprovalInstance] get lark user id failed")
		return "", errors.New("getLarkOpenId failed")
	}

	formStr, _ := sonic.MarshalString(form)

	req := larkapproval.NewCreateInstanceReqBuilder().
		InstanceCreate(larkapproval.NewInstanceCreateBuilder().
			ApprovalCode(MarketOperationApprovalCode).
			OpenId(larkOpenId).
			Form(formStr).
			Uuid(uuid).
			Build()).
		Build()

	resp, err := larkCli.Approval.Instance.Create(ctx, req)
	if err != nil || !resp.Success() || resp.Data == nil || resp.Data.InstanceCode == nil {
		logs.CtxError(ctx, "[CreateApprovalInstance] Instance Create failed,form=%v, resp.Code=%v, resp.Msg=%v, err=%v",
			formStr, resp.Code, resp.Msg, err)
		return "", errors.New("createApprovalInstance failed")
	}

	logs.CtxInfo(ctx, "[CreateApprovalInstance] resp=%s", utils.JSONF(resp))
	return *resp.Data.InstanceCode, nil
}

func CancelApprovalInstance(ctx context.Context, approvalCode, instanceCode string) error {
	larkOpenId := GetLarkOpenId(ctx, gptr.Indirect(utils2.GetUserInfo(ctx).Email))
	if larkOpenId == "" {
		logs.CtxError(ctx, "[CreateApprovalInstance] get lark user id failed")
		return errors.New("getLarkOpenId failed")
	}

	req := larkapproval.NewCancelInstanceReqBuilder().
		InstanceCancel(larkapproval.NewInstanceCancelBuilder().
			ApprovalCode(MarketOperationApprovalCode).
			InstanceCode(instanceCode).
			UserId(larkOpenId).
			Build()).
		Build()

	resp, err := larkCli.Approval.Instance.Cancel(ctx, req)
	if err != nil || !resp.Success() {
		logs.CtxError(ctx, "[CancelApprovalInstance] Instance Cancel failed, resp.Code=%v, resp.Msg=%v, err=%v",
			resp.Code, resp.Msg, err)
		return errors.New("cancelApprovalInstance failed")
	}

	logs.CtxInfo(ctx, "[CancelApprovalInstance] resp=%s", utils.JSONF(resp))
	return nil
}

// GetInstanceDetail 获取审核实例详情
func GetInstanceDetail(ctx context.Context, instanceCode string) (*larkapproval.GetInstanceRespData, error) {
	req := larkapproval.NewGetInstanceReqBuilder().
		InstanceId(instanceCode).
		Locale("zh-CN").
		Build()

	instance, err := larkCli.Approval.V4.Instance.Get(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetInstanceDetail|failed, err=%v", err)
		return nil, err
	}
	if !instance.Success() {
		logs.CtxError(ctx, "GetInstanceDetail|failed, Code=%d, Msg=%s", instance.Code, instance.Msg)
		return nil, errors.New(instance.Msg)
	}

	return instance.Data, err
}

func ApproveInstanceTask(ctx context.Context, instanceCode string, task []*larkapproval.InstanceTask, openID, comment string) error {
	cc := co.NewConcurrent(ctx)
	for _, v := range task {
		taskID := *v.Id
		cc.GoV2(func() error {
			req := larkapproval.NewApproveTaskReqBuilder().
				UserIdType("open_id").
				TaskApprove(larkapproval.NewTaskApproveBuilder().
					ApprovalCode(MarketOperationApprovalCode).
					InstanceCode(instanceCode).
					UserId(openID).
					Comment(comment).
					TaskId(taskID).
					Build()).
				Build()
			resp, err := larkCli.Approval.V4.Task.Approve(ctx, req)
			if err != nil {
				logs.CtxError(ctx, "ApproveInstanceTask|Approve, err=%v", err)
				return err
			}
			if !resp.Success() {
				logs.CtxError(ctx, "ApproveInstanceTask|Approve failed, Code=%d, Msg=%s", resp.Code, resp.Msg)
				return errors.New(resp.Msg)
			}
			return nil
		})
	}
	return cc.WaitV2()
}

func RejectInstanceTask(ctx context.Context, instanceCode string, task []*larkapproval.InstanceTask, openID, comment string) error {
	cc := co.NewConcurrent(ctx)
	for _, v := range task {
		taskID := *v.Id
		cc.GoV2(func() error {
			req := larkapproval.NewRejectTaskReqBuilder().
				UserIdType("open_id").
				TaskApprove(larkapproval.NewTaskApproveBuilder().
					ApprovalCode(MarketOperationApprovalCode).
					InstanceCode(instanceCode).
					UserId(openID).
					Comment(comment).
					TaskId(taskID).
					Build()).
				Build()
			resp, err := larkCli.Approval.V4.Task.Reject(ctx, req)
			if err != nil {
				logs.CtxError(ctx, "RejectInstanceTask|Reject, err=%v", err)
				return err
			}
			if !resp.Success() {
				logs.CtxError(ctx, "RejectInstanceTask|Reject failed, Code=%d, Msg=%s", resp.Code, resp.Msg)
				return errors.New(resp.Msg)
			}
			return nil
		})
	}
	return cc.WaitV2()
}
