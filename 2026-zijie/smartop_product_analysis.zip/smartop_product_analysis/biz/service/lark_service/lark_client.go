package lark_service

import (
	"context"

	"code.byted.org/ecom/common/utils"

	"code.byted.org/aweme-go/ajson"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	larkcontact "github.com/larksuite/oapi-sdk-go/v3/service/contact/v3"
)

func GetLarkOpenId(ctx context.Context, email string) string {
	if env.IsBoe() {
		email = "zhangruiwen.raven@bytedance.com"
	}
	if email == "" {
		logs.CtxError(ctx, "[GetLarkOpenId] get user email failed")
		return ""
	}

	req := larkcontact.NewBatchGetIdUserReqBuilder().
		UserIdType("open_id").
		Body(larkcontact.NewBatchGetIdUserReqBodyBuilder().
			Emails([]string{email}).
			Build()).
		Build()

	resp, err := larkCli.Contact.User.BatchGetId(ctx, req)
	logs.CtxDebug(ctx, "[GetLarkOpenId] BatchGetId resp=%s", utils.JSONF(resp))

	if err != nil || !resp.Success() {
		logs.CtxError(ctx, "[GetLarkOpenId] BatchGetId failed, resp.Code=%v, resp.Msg=%v, err=%v",
			resp.Code, resp.Msg, err)
		return ""
	}

	if resp.Data != nil {
		for _, v := range resp.Data.UserList {
			if v != nil && v.UserId != nil {
				return *v.UserId
			}
		}
	}

	return ""
}

// GetUserByEmail 通过email查询飞书user_id
func GetUserByEmail(ctx context.Context, emails []string) ([]string, error) {
	if len(emails) <= 0 {
		return nil, nil
	}
	batchGetIdReq := larkcontact.NewBatchGetIdUserReqBuilder().
		UserIdType("user_id").
		Body(larkcontact.NewBatchGetIdUserReqBodyBuilder().Emails(emails).Build()).
		Build()
	rpcResp, err := larkCli.Contact.User.BatchGetId(ctx, batchGetIdReq)
	if err != nil {
		logs.CtxInfo(ctx, "GetUserByEmail|BatchGetId email:%s, err:%s", ajson.ToString(emails), err.Error())
		return nil, err
	}
	if rpcResp == nil || rpcResp.Data == nil || len(rpcResp.Data.UserList) <= 0 {
		logs.CtxInfo(ctx, "GetUserByEmail|BatchGetId resp is nil resp:%v", rpcResp)
		return nil, nil
	}

	return toLarkUserId(rpcResp.Data.UserList), nil
}

func toLarkUserId(infos []*larkcontact.UserContactInfo) []string {
	userIDS := make([]string, 0)
	for _, v := range infos {
		if v == nil || v.UserId == nil {
			continue
		}
		userIDS = append(userIDS, *v.UserId)
	}
	return userIDS
}
