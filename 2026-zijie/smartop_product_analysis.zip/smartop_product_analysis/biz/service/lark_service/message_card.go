package lark_service

type MessageCardData[T any] struct {
	TemplateID       string `json:"template_id"`
	TemplateVariable T      `json:"template_variable"`
}

type MessageCardRequestData[T any] struct {
	Type string             `json:"type"`
	Data MessageCardData[T] `json:"data"`
}
