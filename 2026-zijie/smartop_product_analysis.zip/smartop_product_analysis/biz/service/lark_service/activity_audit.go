package lark_service

import (
	"fmt"
	"strings"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/temai/go_lib/convert"
)

const (
	activityAuditUuidFormat = "%d#%d#%d" // activity_id#updatater_id#time
)

func ActivityToForm(activity *dao.Activity, planId int64) interface{} {
	startAt := time.Unix(activity.StartTimestamp, 0).Format("2006-01-02 15:04:05")
	endAt := time.Unix(activity.EndTimestamp, 0).Format("2006-01-02 15:04:05")
	name, desc := "-", "-"

	if activity.Name != "" {
		name = activity.Name
	}
	if activity.Description != "" {
		desc = activity.Description
	}
	form := []map[string]interface{}{
		{
			"id":    "activity_name",
			"type":  "textarea",
			"value": name,
		},
		{
			"id":    "activity_desc",
			"type":  "textarea",
			"value": desc,
		},
		{
			"id":    "start_at",
			"type":  "input",
			"value": startAt,
		},
		{
			"id":    "end_at",
			"type":  "input",
			"value": endAt,
		},
		{
			"id":    "activity_detail",
			"type":  "input",
			"value": "https://ecop.bytedance.net/mall-home-admin/market-regulation/activity?cjSiteCode=St12403140000002",
		},
	}
	return form
}

func GetActivityAuditUuid(activityId, updaterId int64) string {
	return fmt.Sprintf(activityAuditUuidFormat, activityId, updaterId, time.Now().Unix())
}

func ParseActivityUuid(uuid string) (activityId int64, updaterId int64) {
	strItems := strings.Split(uuid, "#")
	if len(strItems) != 3 {
		return 0, 0
	}
	activityIdStr := strItems[0]
	updaterIdStr := strItems[1]
	return convert.ToInt64(activityIdStr), convert.ToInt64(updaterIdStr)
}

func initEmail(auditors []string) []string {
	resp := make([]string, 0)
	for _, v := range auditors {
		resp = append(resp, v+"@bytedance.com")
	}
	return resp
}
