package lark_service

import (
	"context"
	"fmt"

	"code.byted.org/gopkg/logs/v2"
	larkauthen "github.com/larksuite/oapi-sdk-go/v3/service/authen/v1"
)

// 获取 user_access_token：https://open.larkoffice.com/document/authentication-management/access-token/get-user-access-token
func GetUserAccessToken(ctx context.Context, code string) (*larkauthen.CreateOidcAccessTokenRespData, error) {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[GetUserAccessToken] lark client not initialized")
		return nil, fmt.Errorf("lark client not initialized")
	}

	// 创建请求对象
	req := larkauthen.NewCreateOidcAccessTokenReqBuilder().
		Body(larkauthen.NewCreateOidcAccessTokenReqBodyBuilder().
			GrantType(`authorization_code`).
			Code(code).
			Build()).
		Build()

	// 发起请求
	resp, err := larkClient.Authen.OidcAccessToken.Create(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[GetUserAccessToken] get user access token failed, err: %v", err)
		return nil, err
	}
	if !resp.Success() || resp.Data == nil {
		logs.CtxError(ctx, "[GetUserAccessToken] get user access token failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
		return nil, fmt.Errorf("get user access token failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
	}
	return resp.Data, nil
}

// 刷新 user_access_token：https://open.larkoffice.com/document/authentication-management/access-token/refresh-user-access-token
func RefreshUserAccessToken(ctx context.Context, refreshToken string) (*larkauthen.CreateOidcRefreshAccessTokenRespData, error) {
	larkClient := GetDefaultLarkClient()
	if larkClient == nil {
		logs.CtxError(ctx, "[RefreshUserAccessToken] lark client not initialized")
		return nil, fmt.Errorf("lark client not initialized")
	}

	// 创建请求对象
	req := larkauthen.NewCreateOidcRefreshAccessTokenReqBuilder().
		Body(larkauthen.NewCreateOidcRefreshAccessTokenReqBodyBuilder().
			GrantType(`refresh_token`).
			RefreshToken(refreshToken).
			Build()).
		Build()

	// 发起请求
	resp, err := larkClient.Authen.OidcRefreshAccessToken.Create(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[RefreshUserAccessToken] refresh user access token failed, err: %v", err)
		return nil, err
	}
	if !resp.Success() || resp.Data == nil {
		logs.CtxError(ctx, "[RefreshUserAccessToken] refresh user access token failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
		return nil, fmt.Errorf("refresh user access token failed, code: %d, msg: %s, requestId: %s", resp.Code, resp.Msg, resp.RequestId())
	}
	return resp.Data, nil
}
