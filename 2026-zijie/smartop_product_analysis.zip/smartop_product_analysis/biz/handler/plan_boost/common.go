package plan_boost

import (
	analysis_pool_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/analysis_pool"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
)

var (
	PlanHistorySumApi = "7476083879036617779"
	PLanAAApi         = "7477132173011600410"
)

type BoostAnalysisHandler struct {
	AnalysisService     analysis_service.IAnalysisService
	AnalysisPoolHandler *analysis_pool_handler.AnalysisPoolHandler
}
