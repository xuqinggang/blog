package plan_boost

import (
	"context"
	"strconv"

	"code.byted.org/aweme-go/ajson"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/boost_plan_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_mall_boost/kitex_gen/ecom/mall/boost"
	"code.byted.org/overpass/ecom_mall_boost/kitex_gen/ecom/mall/supply_common"
	"code.byted.org/overpass/ecom_mall_boost/rpc/ecom_mall_boost"
)

func (d *BoostAnalysisHandler) InitPlanAnalysisPool(ctx context.Context, req *analysis.InitPlanAnalysisPoolRequest) (resp *analysis.InitPlanAnalysisPoolResponse) {
	resp = &analysis.InitPlanAnalysisPoolResponse{
		BaseResp: &base.BaseResp{},
	}

	defer func() {
		logs.CtxInfo(ctx, "InitPlanAnalysisPool|req:%s, resp:%s", ajson.ToString(req), ajson.ToString(resp))
	}()

	// 参数校验
	err := checkInitPlanAnalysisPoolParams(req)
	if err != nil {
		logs.CtxError(ctx, "InitPlanAnalysisPool|checkParams err:%s", err.Error())
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		return
	}

	// 查询计划信息
	planDetail, err := d.getPlan(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "InitPlanAnalysisPool|getPlan err:%s", err.Error())
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		return
	}

	// 查询计划对应货盘
	var boostPlanService boost_plan_service.IBoostPlanService
	boostPlanService = &boost_plan_service.BoostPlanService{}
	planID := planDetail.Plan.Id
	planName := *planDetail.Plan.Name
	poolId, err := boostPlanService.GetPoolIDByPlanID(ctx, planID, planName)
	if err != nil {
		logs.CtxError(ctx, "InitPlanAnalysisPool|GetPoolIDByPlanID err:%s", err.Error())
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		return
	}

	// 存在直接返回
	if poolId != "" && poolId != "0" {
		resp.Data = poolId
		return resp
	}

	// 不存在创建货盘返回
	scene := planDetail.Plan.Signal.Type
	sceneName := planDetail.Plan.Signal.TypeName
	createPoolReq := boostPlanService.GetCreatePoolReq(ctx, planID, int32(scene), planName, sceneName)
	createResp, err := d.AnalysisPoolHandler.HandleCreateAnalysisPool(ctx, createPoolReq)
	if err != nil {
		logs.CtxError(ctx, "InitPlanAnalysisPool|HandleCreateAnalysisPool err:%s", err.Error())
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		return
	}
	if createResp == nil {
		logs.CtxError(ctx, "InitPlanAnalysisPool|HandleCreateAnalysisPool resp nil")
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage("HandleCreateAnalysisPool resp nil")
		return
	}
	if createResp.Data == "" || createResp.Data == "0" {
		logs.CtxError(ctx, "InitPlanAnalysisPool|HandleCreateAnalysisPool resp blank")
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage("HandleCreateAnalysisPool resp blank")
		return
	}
	resp.Data = createResp.Data
	return resp
}

func (d *BoostAnalysisHandler) getPlan(ctx context.Context, req *analysis.InitPlanAnalysisPoolRequest) (*boost.PlanDetail, error) {
	pid, _ := strconv.ParseInt(req.PlanId, 10, 64)
	planResp, err := ecom_mall_boost.RawCall.GetPlanByParams(ctx, &boost.GetPlanByParamsRequest{
		Page: &supply_common.PageInfo{
			Page:     0,
			PageSize: 1,
		},
		Ids:        []int64{pid},
		NeedSignal: true,
	})
	if err != nil {
		return nil, errors.New(err.Error())
	}
	if planResp == nil || len(planResp.Plans) <= 0 || planResp.Plans[0].Plan == nil {
		return nil, errors.New("plan not exist")
	}
	if planResp.Plans[0].Plan.Signal == nil {
		return nil, errors.New("plan signal nil ")
	}
	return planResp.Plans[0], nil
}

func checkInitPlanAnalysisPoolParams(req *analysis.InitPlanAnalysisPoolRequest) error {
	if req == nil {
		return errors.New("checkInitPlanAnalysisPoolParams|req is nil")
	}
	if req.PlanId == "" || req.PlanId == "0" {
		return errors.New("checkInitPlanAnalysisPoolParams|planID <= 0")
	}
	return nil
}
