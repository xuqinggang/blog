package plan_boost

import (
	"context"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"code.byted.org/gopkg/logs"
	"github.com/jinzhu/copier"
)

func (d *BoostAnalysisHandler) GetBoostPlanCoreOverview(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreOverviewResponse, err error) {
	resp = &analysis.GetProductAnalysisCoreOverviewResponse{}
	resp.BaseResp = base.NewBaseResp()
	req.BaseReq.GroupAttrs = nil
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	cc := co.NewConcurrent(ctx)
	//aaCoreIndex := make([]*analysis.TargetCategoryList, 0)
	historyAllCoreIndex := make([]*analysis.TargetCategoryList, 0)
	historyReq := &analysis.GetProductAnalysisBaseRequest{}
	copier.CopyWithOption(historyReq, *req, copier.Option{DeepCopy: true})

	// 获取扶持品AA数据
	//cc.GoV2(func() error {
	//	req.BaseReq.TargetMetaList = []string{"pv_avg_aa", "gmv_avg_aa", "order_avg_aa", "gpm_avg_aa", "opm_avg_aa"}
	//	aaCoreIndex, err = analysis_service.GetPlanBoostCoreOverview(ctx, req.BaseReq, PLanAAApi)
	//	return err
	//})
	// 获取扶持历史累计数据
	cc.GoV2(func() error {
		historyReq.BaseReq.TargetMetaList = []string{"pv_histy_sum", "gmv_histy_sum", "order_histy_sum"}
		historyAllCoreIndex, err = analysis_service.GetPlanBoostCoreOverview(ctx, historyReq.BaseReq, PlanHistorySumApi)
		return err
	})
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "GetBoostPlanCoreOverview|获取核心指标失败, err:"+err.Error())
		return nil, err
	}
	//resp.Data = append(aaCoreIndex, historyAllCoreIndex...)
	resp.Data = historyAllCoreIndex

	// 不返回大盘相关对比数据
	for _, v := range resp.Data {
		if v == nil {
			continue
		}
		for _, vv := range v.TargetList {
			if vv.Extra == nil {
				continue
			}
			vv.Extra.PercentFlag = true
		}
	}
	return
}
