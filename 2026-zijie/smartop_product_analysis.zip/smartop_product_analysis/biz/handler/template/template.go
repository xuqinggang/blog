package template

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/template_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"context"
)

type TemplateHandler struct {
	TemplateService template_service.ITemplateService
}

func (t *TemplateHandler) HandleCreateTemplate(ctx context.Context, req *dimensions.CreateOrUpdateTemplateRequest) (resp *dimensions.CreateOrUpdateTemplateResponse, err error) {
	resp = &dimensions.CreateOrUpdateTemplateResponse{}
	resp.BaseResp = base.NewBaseResp()
	resp, err = t.TemplateService.CreateTemplate(ctx, req)
	return
}

func (t *TemplateHandler) HandleUpdateTemplate(ctx context.Context, req *dimensions.CreateOrUpdateTemplateRequest) (resp *dimensions.CreateOrUpdateTemplateResponse, err error) {
	resp = &dimensions.CreateOrUpdateTemplateResponse{}
	resp.BaseResp = base.NewBaseResp()
	resp, err = t.TemplateService.UpdateTemplate(ctx, req)
	return
}

func (t *TemplateHandler) HandleDeleteTemplate(ctx context.Context, req *dimensions.DeleteTemplateRequest) (resp *dimensions.DeleteTemplateResponse, err error) {
	resp = &dimensions.DeleteTemplateResponse{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.TemplateService.DeleteTemplate(ctx, req)
	return
}

func (t *TemplateHandler) HandleGetTemplateList(ctx context.Context, req *dimensions.GetTemplateListRequest) (resp *dimensions.GetTemplateListResponse, err error) {
	resp = &dimensions.GetTemplateListResponse{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.TemplateService.GetTemplateList(ctx, req)
	return
}

func (t *TemplateHandler) HandleGetTemplateDetail(ctx context.Context, req *dimensions.GetTemplateDetailRequest) (resp *dimensions.GetTemplateDetailResponse, err error) {
	resp = &dimensions.GetTemplateDetailResponse{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.TemplateService.GetTemplateDetail(ctx, req)
	return
}

// 废弃
func (t *TemplateHandler) GenreateTemplateCache(ctx context.Context) (resp *base.BaseResponse, err error) {
	resp = &base.BaseResponse{}
	resp.BaseResp = base.NewBaseResp()
	resp, err = t.TemplateService.GenreateTemplateCache(ctx)
	return
}
