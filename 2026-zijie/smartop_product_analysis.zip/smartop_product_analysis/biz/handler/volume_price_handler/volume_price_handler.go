package volume_price_handler

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/volume_price_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

type VolumePriceHandler struct {
	VolumePriceService volume_price_service.IVolumePriceService
}

func volumePriceReqInit(req *dimensions.ProductAnalysisBaseStruct) {
	req.CompareStartDate = req.StartDate
	req.CompareEndDate = req.EndDate
}

func (d *VolumePriceHandler) GetVolumePriceMarketFunnelTarget(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *volume_price.GetVolumePriceMarketFunnelTargetResponse, err error) {
	resp = volume_price.NewGetVolumePriceMarketFunnelTargetResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &volume_price.GetVolumePriceMarketFunnelTargetData{}
	volumePriceReqInit(req.BaseReq)
	// 获取业务线元信息
	bizMetaInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizMetaInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}

	if len(bizMetaInfo.DefaultFunnelMeta) > 0 {
		resp.Data.RatioOption = bizMetaInfo.DefaultFunnelMeta[0].RatioOption
	}
	resp.Data.TargetList, err = d.VolumePriceService.GetVolumePriceMarketFunnelTarget(ctx, req)
	return
}

func (d *VolumePriceHandler) GetVolumePriceLibraList(ctx context.Context, req *volume_price.GetVolumePriceLibraListRequest) (resp *volume_price.GetVolumePriceLibraListResponse, err error) {
	resp = volume_price.NewGetVolumePriceLibraListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &volume_price.GetVolumePriceLibraListData{}
	resp.Data.LibraList, err = d.VolumePriceService.GetVolumePriceLibraList(ctx, req, nil)
	return
}

func (d *VolumePriceHandler) GetVolumePriceLibraVersionList(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *volume_price.GetVolumePriceLibraVersionListResponse, err error) {
	resp = volume_price.NewGetVolumePriceLibraVersionListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &volume_price.GetVolumePriceLibraVersionListData{}
	volumePriceReqInit(req.BaseReq)
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data.LibraList, err = d.VolumePriceService.GetVolumePriceLibraVersionList(ctx, req)
	return
}

func (d *VolumePriceHandler) GetVolumePriceMultiDimFullList(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisMultiDimFullListResponse, err error) {
	resp = analysis.NewGetProductAnalysisMultiDimFullListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetProductAnalysisMultiDimFullListData{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	volumePriceReqInit(req.BaseReq)
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.VolumePriceService.GetVolumePriceMultiDimFullList(ctx, req)
	return
}

func (d *VolumePriceHandler) GetVolumePriceMarketFunnelTargetDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	volumePriceReqInit(req.BaseReq)
	resp.Data, err = d.VolumePriceService.GetVolumePriceMarketFunnelTargetDownload(ctx, req)
	return
}

func (d *VolumePriceHandler) GetVolumePriceLibraVersionListDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	volumePriceReqInit(req.BaseReq)
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.VolumePriceService.GetVolumePriceLibraVersionListDownload(ctx, req)
	return
}

func (d *VolumePriceHandler) GetVolumePriceMultiDimFullListDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	volumePriceReqInit(req.BaseReq)
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.VolumePriceService.GetVolumePriceMultiDimFullListDownload(ctx, req)
	return
}

func (d *VolumePriceHandler) GetVolumePriceVersionHierarchicalList(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalListRequest) (resp *volume_price.GetVolumePriceLibraVersionListResponse, err error) {
	resp = volume_price.NewGetVolumePriceLibraVersionListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &volume_price.GetVolumePriceLibraVersionListData{}
	volumePriceReqInit(req.BaseReq)
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data.LibraList, err = d.VolumePriceService.GetVolumePriceVersionHierarchicalList(ctx, req)
	return
}

func (d *VolumePriceHandler) GetVolumePriceVersionHierarchicalListDownload(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	volumePriceReqInit(req.BaseReq)
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.VolumePriceService.GetVolumePriceVersionHierarchicalListDownload(ctx, req)
	return
}

func (d *VolumePriceHandler) GetVolumePriceVersionHierarchicalConfig(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalConfigRequest) (resp *volume_price.GetVolumePriceVersionHierarchicalConfigResponse, err error) {
	resp = volume_price.NewGetVolumePriceVersionHierarchicalConfigResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &volume_price.GetVolumePriceVersionHierarchicalConfigData{OperatorList: volume_price_service.DefaultOperatorMap[req.TargetType]}
	return resp, nil
}

func (d *VolumePriceHandler) GetExperimentCombination(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.GetExperimentCombinationResponse, err error) {
	resp = volume_price.NewGetExperimentCombinationResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.VolumePriceService.GetExperimentCombination(ctx, req)
	return
}

func (d *VolumePriceHandler) GetReversalExperimentCoreData(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.GetReversalExperimentCoreDataResponse, err error) {
	resp = volume_price.NewGetReversalExperimentCoreDataResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	volumePriceReqInit(req.BaseReq)
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	// 校验评估对象
	if ok, stCode, msg, ctx = d.CheckCombinationExist(ctx, req); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.VolumePriceService.GetReversalExperimentCoreData(ctx, req)
	return
}

// CheckCombinationExist 校验分析对象是否存在
func (d *VolumePriceHandler) CheckCombinationExist(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	// 校验传入的分析对象是否存在
	combination, err := d.GetExperimentCombination(ctx, req)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return false, stcodes.StatusCodeDefaultError, "获取评估对象失败", ctx
	}
	var combinationMap = make(map[string]*volume_price.ExperimentCombination)
	if combination != nil && combination.Data != nil {
		for _, object := range combination.Data.Combinations {
			combinationMap[object.Code] = object
		}
	}
	for _, combine := range req.Combination {
		if _, ok := combinationMap[combine.Code]; !ok {
			return false, stcodes.StatusCacheNotExistError, "评估对象缓存失效，请重新选择评估对象", ctx
		} else { // 校验对象的实验组ID和对照组ID是否相同
			if combine.ExprGroupId != combinationMap[combine.Code].ExprGroupId || combine.CompareGroupId != combinationMap[combine.Code].CompareGroupId {
				return false, stcodes.StatusCacheNotExistError, "选择的评估对象实验组和对照组相同，请联系管理员修改评估对象", ctx
			}
		}
	}
	return true, stcodes.StatusCodeSuccess, "", ctx
}

func (d *VolumePriceHandler) GetReversalExperimentDetail(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.GetReversalExperimentDetailResponse, err error) {
	resp = volume_price.NewGetReversalExperimentDetailResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	volumePriceReqInit(req.BaseReq)
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, _, _, err = d.VolumePriceService.GetReversalExperimentDetail(ctx, req, true)
	if resp != nil && resp.Data != nil {
		for _, row := range resp.Data.Rows {
			row.TargetList = volume_price_service.FilterNotShowTarget(row.TargetList)
		}
	}
	return
}

func (d *VolumePriceHandler) GetVolumePriceBilateralLibra(ctx context.Context, req *volume_price.GetVolumePriceBilateralLibraRequest) (resp *volume_price.GetVolumePriceBilateralLibraResponse, err error) {
	resp = volume_price.NewGetVolumePriceBilateralLibraResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.VolumePriceService.GetVolumePriceBilateralLibra(ctx, req)
	return resp, err
}

func (d *VolumePriceHandler) SaveVolumePriceBilateralLibra(ctx context.Context, req *volume_price.SaveVolumePriceBilateralLibraRequest) (resp *volume_price.SaveVolumePriceBilateralLibraResponse, err error) {
	resp = volume_price.NewSaveVolumePriceBilateralLibraResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.VolumePriceService.SaveVolumePriceBilateralLibra(ctx, req)
	return resp, err
}

func (d *VolumePriceHandler) SaveExprObject(ctx context.Context, req *volume_price.SaveExprObjectRequest) (resp *volume_price.SaveExprObjectResponse, err error) {
	resp = volume_price.NewSaveExprObjectResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.VolumePriceService.SaveExprObject(ctx, req)
	return resp, err
}

func (d *VolumePriceHandler) GetReversalExperimentCoreDataDownload(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	volumePriceReqInit(req.BaseReq)
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.VolumePriceService.GetReversalExperimentCoreDataDownload(ctx, req)
	return resp, err
}

func (d *VolumePriceHandler) GetReversalExperimentDetailDownload(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	volumePriceReqInit(req.BaseReq)
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.VolumePriceService.GetReversalExperimentDetailDownload(ctx, req)
	return resp, err
}
