package feedback

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/feedback_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
)

type FeedbackHandler struct {
	FeedbackService feedback_service.IFeedBackService
}

func (f *FeedbackHandler) HandleAddFeedBack(ctx context.Context, req *analysis.AddFeedBackRequest) (resp *analysis.AddFeedBackResponse, err error) {
	resp = &analysis.AddFeedBackResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = f.FeedbackService.AddFeedback(ctx, req)
	return
}
