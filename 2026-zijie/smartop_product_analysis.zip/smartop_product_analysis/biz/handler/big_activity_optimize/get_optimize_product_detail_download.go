package big_activity_optimize

import (
	"context"

	"code.byted.org/aweme-go/ajson"
	"code.byted.org/ecom/arctic_lib/lark"
	export_service "code.byted.org/ecom/smartop_product_analysis/biz/service/export_data/common"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
)

func (d *BigActivityOptimize) GetOptimizeProductDetailDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetOptimizeProductDetailDownloadResponse, err error) {
	resp = &great_value_buy.GetOptimizeProductDetailDownloadResponse{
		BaseResp: &base.BaseResp{},
	}

	defer func() {
		logs.CtxInfo(ctx, "GetOptimizeProductDetailDownload|req:%s, resp:%s", ajson.ToString(req), ajson.ToString(resp))
	}()

	// 查询数据
	req.PageReq = &base.PageInfo{PageNum: 1, PageSize: 20000}
	data, err := d.GetOptimizeProductDetail(ctx, req)
	if err != nil {
		return nil, err
	}
	if data == nil || data.Data == nil {
		return nil, errors.New("内部异常，返回nil数据")
	}

	// 查询email
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		return resp, err
	}
	if email == "" {
		return resp, errors.New("未查询到用户邮箱")
	}

	err = export_service.ExportLarkDocV2(ctx, toLarkData(data.Data.Prods), email, nil, nil)
	if err != nil {
		return resp, err
	}
	resp.Data = true
	return resp, nil
}

func toLarkData(records []*great_value_buy.GetOptimizeProductDetail) []lark.SheetData {
	// 表头
	head := make([]interface{}, 0)
	head = append(head, []interface{}{"商品ID", "商品名称", "可优化项", "关联CRM任务"}...)
	if len(records) > 0 {
		for _, v := range records[0].TargetList {
			head = append(head, v.DisplayName)
		}
	}
	datas := make([][]interface{}, 0)
	datas = append(datas, head)
	for _, v := range records {
		if v == nil {
			continue
		}
		if v.ProductInfo == nil || v.OptimizeItem == nil || v.CrmTask == nil {
			continue
		}
		temp := make([]interface{}, 0)
		temp = append(temp, []interface{}{v.ProductInfo.Id, v.ProductInfo.Name, v.OptimizeItem.Name, v.CrmTask.Name}...)
		for _, vv := range v.TargetList {
			temp = append(temp, vv.DisplayValue)
		}
		datas = append(datas, temp)
	}

	return []lark.SheetData{
		{
			Title: "可优化项商品明细导出",
			Data:  datas,
		},
	}
}

//func appendBaseInfo(head []interface{}, elems []interface{}) []interface{} {
//	head = append(head)
//	head = append(head)
//	head = append(head)
//	head = append(head)
//	return head
//}
