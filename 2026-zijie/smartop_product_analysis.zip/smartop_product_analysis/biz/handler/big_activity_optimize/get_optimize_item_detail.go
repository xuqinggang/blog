package big_activity_optimize

import (
	"context"

	"code.byted.org/aweme-go/ajson"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/great_value_buy_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
)

func (d *BigActivityOptimize) GetOptimizeItemDetail(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetOptimizeItemDetailResponse, err error) {
	resp = &great_value_buy.GetOptimizeItemDetailResponse{
		BaseResp: &base.BaseResp{},
	}

	defer func() {
		logs.CtxInfo(ctx, "GetOptimizeItemDetail|req:%s, resp:%s", ajson.ToString(req), ajson.ToString(resp))
	}()

	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	// 查询name信息
	configs, err := d.GreatValueBuyService.GetGreatValueBuyDiagnosisConfig(ctx, &great_value_buy.GetGreatValueBuyDiagnosisConfigDataRequest{BizType: dimensions.BizType_BigActivityCore})
	if err != nil {
		return nil, err
	}
	if configs == nil || configs.OptimizeActionConfig == nil || len(configs.OptimizeActionConfig.OptimizeItems) <= 0 {
		return nil, errors.New("可优化项配置为空")
	}

	// 构建参数
	return great_value_buy_service.GetOptimizeItemDetail(ctx, d.GreatValueBuyService, req, configs.OptimizeActionConfig)
}
