package big_activity_optimize

import "code.byted.org/ecom/smartop_product_analysis/biz/service/great_value_buy_service"

type BigActivityOptimize struct {
	GreatValueBuyService great_value_buy_service.IGreatValueBuyService
}
