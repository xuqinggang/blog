package big_activity_optimize

import (
	"context"
	"reflect"
	"testing"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/great_value_buy_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
)

func TestBigActivityOptimize_GetOptimizeItemDetail(t *testing.T) {
	type fields struct {
		GreatValueBuyService great_value_buy_service.IGreatValueBuyService
	}
	type args struct {
		ctx context.Context
		req *great_value_buy.GetGreatValueBuyCommonRequest
	}
	tests := []struct {
		name     string
		fields   fields
		args     args
		wantResp *great_value_buy.GetOptimizeItemDetailResponse
		wantErr  bool
	}{
		{
			name: "111",
			args: args{
				ctx: context.Background(),
				req: &great_value_buy.GetGreatValueBuyCommonRequest{
					BaseReq: &dimensions.ProductAnalysisBaseStruct{
						BizType:          dimensions.BizType_BigActivityCore,
						StartDate:        "",
						EndDate:          "",
						CompareStartDate: "",
						CompareEndDate:   "",
						Dimensions:       nil,
						ThresholdAttrs:   nil,
						ThresholdExpr:    nil,
						GroupAttrs:       nil,
						UvFlag:           nil,
						TargetMetaList:   nil,
						CompareType:      nil,
						IsTotal:          nil,
					},
					NeedTrend:             false,
					NeedCycle:             false,
					NeedSync:              false,
					TargetGranularityList: nil,
					DiagnosisTargetList:   nil,
					TargetTypeList:        nil,
					TargetDrillType:       0,
					SelectSkuIdList:       nil,
					CommonSelectList:      nil,
					OptimizeItems:         nil,
					CrmActions:            nil,
					CoreTreeType:          nil,
					DependentTargetList:   nil,
					NeedTotal:             false,
					PageReq:               nil,
					OrderBy:               nil,
					OverallCommonReq:      nil,
					Base:                  nil,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &BigActivityOptimize{
				GreatValueBuyService: tt.fields.GreatValueBuyService,
			}
			gotResp, err := d.GetOptimizeItemDetail(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetOptimizeItemDetail() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotResp, tt.wantResp) {
				t.Errorf("GetOptimizeItemDetail() gotResp = %v, want %v", gotResp, tt.wantResp)
			}
		})
	}
}

func TestBigActivityOptimize_GetOptimizeProductDetail(t *testing.T) {
	type fields struct {
		GreatValueBuyService great_value_buy_service.IGreatValueBuyService
	}
	type args struct {
		ctx context.Context
		req *great_value_buy.GetGreatValueBuyCommonRequest
	}
	tests := []struct {
		name     string
		fields   fields
		args     args
		wantResp *great_value_buy.GetOptimizeProductDetailResponse
		wantErr  bool
	}{
		{
			name: "111",
			args: args{
				ctx: context.Background(),
				req: &great_value_buy.GetGreatValueBuyCommonRequest{
					BaseReq: &dimensions.ProductAnalysisBaseStruct{
						BizType:          dimensions.BizType_BigActivityCore,
						StartDate:        "",
						EndDate:          "",
						CompareStartDate: "",
						CompareEndDate:   "",
						Dimensions:       nil,
						ThresholdAttrs:   nil,
						ThresholdExpr:    nil,
						GroupAttrs:       nil,
						UvFlag:           nil,
						TargetMetaList:   nil,
						CompareType:      nil,
						IsTotal:          nil,
					},
					NeedTrend:             false,
					NeedCycle:             false,
					NeedSync:              false,
					TargetGranularityList: nil,
					DiagnosisTargetList:   nil,
					TargetTypeList:        nil,
					TargetDrillType:       0,
					SelectSkuIdList:       nil,
					CommonSelectList:      nil,
					OptimizeItems:         nil,
					CrmActions:            nil,
					CoreTreeType:          nil,
					DependentTargetList:   nil,
					NeedTotal:             false,
					PageReq:               nil,
					OrderBy:               nil,
					OverallCommonReq:      nil,
					Base:                  nil,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &BigActivityOptimize{
				GreatValueBuyService: tt.fields.GreatValueBuyService,
			}
			gotResp, err := d.GetOptimizeProductDetail(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetOptimizeProductDetail() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotResp, tt.wantResp) {
				t.Errorf("GetOptimizeProductDetail() gotResp = %v, want %v", gotResp, tt.wantResp)
			}
		})
	}
}
