package activity_review

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/activity_review_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/logs"
)

type ActivityReviewHandler struct {
	ActivityReviewService activity_review_service.IActivityReviewService
}

func (d *ActivityReviewHandler) FreshActivityReview(ctx context.Context, req *activity_review.FreshActivityReviewProgressRequest) (resp *activity_review.FreshActivityReviewProgressResponse, err error) {
	resp = &activity_review.FreshActivityReviewProgressResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	err = d.ActivityReviewService.FreshActivityReview(ctx, req)
	return
}

func (d *ActivityReviewHandler) CreateActivityReview(ctx context.Context, req *activity_review.CreateActivityReviewRequest) (resp *activity_review.CreateActivityReviewResponse, err error) {
	resp = &activity_review.CreateActivityReviewResponse{}
	resp.SetData(&activity_review.CreateActivityReviewResponseData{})
	resp.SetBaseResp(base.NewBaseResp())

	err, task_id := d.ActivityReviewService.CreateActivityReview(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "Create activity review task，err=%v+", err)
		return
	}
	resp.Data.TaskId = task_id
	return
}

func (d *ActivityReviewHandler) GetActivityReviewResult(ctx context.Context, req *activity_review.GetActivityReviewResultRequest) (resp *activity_review.GetActivityReviewResultResponse, err error) {
	resp = &activity_review.GetActivityReviewResultResponse{}
	resp.SetData(&activity_review.ActivityReviewResult_{})
	resp.SetBaseResp(base.NewBaseResp())

	// var data activity_review_service.TempType
	resp.Data.Results, err = d.ActivityReviewService.GetActivityReviewResult(ctx, req.TaskId)
	if err != nil {
		return
	}
	resp.Data.QueryInfo, err = d.ActivityReviewService.GetJupyterTaskQueryInfo(ctx, req.TaskId)

	return
}

func (d *ActivityReviewHandler) GetActivityReviewProductSupplyResult(ctx context.Context, req *activity_review.GetActivityReviewProductSupplyProgressRequest) (resp *activity_review.GetActivityReviewProductSupplyProgressResponse, err error) {
	resp = &activity_review.GetActivityReviewProductSupplyProgressResponse{}
	resp.SetData(&activity_review.GetActivityReviewProductSupplyProgressData{})
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBigPromotionBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ActivityReviewService.GetProductSupplyProgress(ctx, req.BaseReq)
	if err != nil {
		return
	}
	return resp, nil
}

func (d *ActivityReviewHandler) GetActivityReviewProductAnalysis(ctx context.Context, req *activity_review.GetActivityReviewProductAnalysisRequest) (resp *activity_review.GetActivityReviewProductAnalysisResponse, err error) {
	resp = &activity_review.GetActivityReviewProductAnalysisResponse{}
	resp.SetData(&activity_review.GetActivityReviewProductAnalysisData{})
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBigPromotionBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ActivityReviewService.GetProductAnalysis(ctx, req.BaseReq)
	if err != nil {
		return
	}
	return resp, nil
}

func (d *ActivityReviewHandler) GetActivityReviewProductAAAnalysis(ctx context.Context, req *activity_review.GetActivityReviewProductAnalysisRequest) (resp *activity_review.GetActivityReviewProductAAAnalysisResponse, err error) {
	resp = &activity_review.GetActivityReviewProductAAAnalysisResponse{}
	//resp.SetData(&activity_review.ProductAnalysisHierarchicalInfo{})
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBigPromotionBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ActivityReviewService.GetProductAAAnalysis(ctx, req.BaseReq)
	if err != nil {
		return
	}
	return resp, nil
}

func (d *ActivityReviewHandler) GetActivityReviewActivityAndNonActivityProductABAnalysis(ctx context.Context, req *activity_review.GetActivityReviewProductAnalysisRequest) (resp *activity_review.GetActivityReviewProductAAAnalysisResponse, err error) {
	resp = &activity_review.GetActivityReviewProductAAAnalysisResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBigPromotionBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ActivityReviewService.GetActivityAndNonActivityProductABAnalysis(ctx, req.BaseReq)
	if err != nil {
		return
	}
	return resp, nil
}
