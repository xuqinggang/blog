package lark_handler

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/lark"
)

type LarkHandler struct {
	LarkService lark_service.ILarkService
}

func (d *LarkHandler) GetDocContent(ctx context.Context, req *lark.GetDocContentRequest) (resp *lark.GetDocContentResponse, err error) {
	resp = lark.NewGetDocContentResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.LarkService.GetDocContent(ctx, req.DocUrl, nil)
	if err != nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		return
	}
	return resp, nil
}

func (d *LarkHandler) CheckDocPermission(ctx context.Context, req *lark.CheckDocPermissionRequest) (resp *lark.CheckDocPermissionResponse, err error) {
	resp = lark.NewCheckDocPermissionResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.LarkService.CheckDocPermission(ctx, req.DocUrl, nil)
	if err != nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		return
	}
	return resp, nil
}
