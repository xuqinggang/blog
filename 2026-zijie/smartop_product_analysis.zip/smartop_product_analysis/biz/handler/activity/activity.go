package activity_handler

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/activity_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/jsonx"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_mall_boost/kitex_gen/ecom/mall/boost"
	"code.byted.org/overpass/ecom_mall_boost/rpc/ecom_mall_boost"
	"code.byted.org/temai/go_portal_sdk/models"
)

type ActivityHandler struct {
	ActivityService *activity_service.ActivityService
}

func (d *ActivityHandler) CreateActivity(ctx context.Context, req *activity.CreateActivityRequest) (*activity.CreateActivityResponse, error) {
	userInfo := utils.GetUserInfo(ctx)
	if !ValidateUser(ctx, userInfo) {
		logs.CtxWarn(ctx, "[CreateActivity] invalid user")
		return nil, errors.New("暂无权限")
	}
	if userInfo != nil {
		req.OperatorId = userInfo.EmployeeId
	}

	resp, err := d.ActivityService.ICreateActivity(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "CreateActivity failed, err: %v ", err)
		return resp, err
	}
	resp.BaseResp = base.NewBaseResp()
	return resp, nil
}

func (d *ActivityHandler) UpdateActivity(ctx context.Context, req *activity.UpdateActivityRequest) (*activity.UpdateActivityResponse, error) {
	userInfo := utils.GetUserInfo(ctx)
	if !ValidateUser(ctx, userInfo) {
		logs.CtxWarn(ctx, "[UpdateActivity] invalid user")
		return nil, errors.New("暂无权限")
	}

	req.OperatorId = userInfo.EmployeeId

	resp, err := d.ActivityService.IUpdateActivity(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "UpdateActivity failed, err: %v ", err)
		return resp, err
	}
	resp.BaseResp = base.NewBaseResp()
	return resp, nil
}

func (d *ActivityHandler) GetActivityList(ctx context.Context, req *activity.GetActivityListRequest) (resp *activity.GetActivityListResponse, err error) {
	defer func() {
		logs.CtxInfo(ctx, "[GetActivityList] Req:%s, Resp:%s", jsonx.ToString(req), jsonx.ToString(resp))
		if err != nil {
			logs.CtxError(ctx, "[GetActivityList] Err:%s", err.Error())
		}
	}()

	resp = activity.NewGetActivityListResponse()
	if resp.Data == nil {
		resp.Data = activity.NewGetActivityListData()
	}
	if resp.BaseResp == nil {
		resp.BaseResp = base.NewBaseResp()
	}

	// 获取活动数据
	bizData, err := d.ActivityService.IGetActivityList(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "GetActivityList failed, err: %v ", err)
		return resp, err
	}
	resp.SetData(bizData)
	return resp, nil
}

func (d *ActivityHandler) TakeOfflineActivity(ctx context.Context, req *activity.TakeOfflineActivityRequest) (*activity.TakeOfflineActivityResponse, error) {
	userInfo := utils.GetUserInfo(ctx)
	if !ValidateUser(ctx, userInfo) {
		logs.CtxWarn(ctx, "[TakeOfflineActivity] invalid user")
		return nil, errors.New("暂无权限")
	}

	req.OperatorId = userInfo.EmployeeId

	resp, err := d.ActivityService.ITakeOfflineActivity(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "TakeOfflineActivity failed, err: %v ", err)
		return resp, err
	}
	resp.BaseResp = base.NewBaseResp()
	return resp, nil
}

func (d *ActivityHandler) ApprovalActivity(ctx context.Context, req *activity.ApprovalActivityReq) (*activity.ApprovalActivityResp, error) {
	userInfo := utils.GetUserInfo(ctx)
	if !ValidateUser(ctx, userInfo) {
		logs.CtxWarn(ctx, "[ApprovalActivity] invalid user")
		return nil, errors.New("暂无权限")
	}

	resp, err := d.ActivityService.ApprovalActivity(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "ApprovalActivity failed, err: %v ", err)
		return resp, err
	}
	resp.BaseResp = base.NewBaseResp()
	return resp, nil
}

func (d *ActivityHandler) ActivityApprovalCallback(ctx context.Context, req *activity.ApprovalCallbackRequest) (*activity.ApprovalCallbackResponse, error) {
	userInfo := utils.GetUserInfo(ctx)
	if !ValidateUser(ctx, userInfo) {
		logs.CtxWarn(ctx, "[TakeOfflineActivity] invalid user")
		return nil, errors.New("暂无权限")
	}

	resp, err := d.ActivityService.ActivityApprovalCallback(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "TakeOfflineActivity failed, err: %v ", err)
		return resp, err
	}
	return resp, nil
}

// tcc验证用户权限
func ValidateUser(ctx context.Context, userInfo *models.UserInfo) (res bool) {
	defer func() {
		if userInfo != nil {
			logs.CtxInfo(ctx, "Validate User, Res:%v, UID:%d", res, userInfo.Id)
		}
	}()
	if userInfo == nil || userInfo.Id == nil || userInfo.Email == nil {
		logs.CtxError(ctx, "[validateUser] GetUserInfo failed, user: %s", jsonx.ToString(userInfo))
		return
	}

	auditorsResp, err := ecom_mall_boost.RawCall.GetBizAuditors(ctx, &boost.GetBizAuditorsReq{
		BizCode: activity_service.BoostAuditorBizCode,
	})
	if err != nil || auditorsResp == nil {
		logs.CtxError(ctx, "[validateUser] GetBizAuditors failed, err: %v", err)
		return
	}
	for _, bizAuditor := range auditorsResp.Auditors {
		if bizAuditor != "" && bizAuditor == *userInfo.Email {
			return res
		}
	}
	res = true
	return
}
