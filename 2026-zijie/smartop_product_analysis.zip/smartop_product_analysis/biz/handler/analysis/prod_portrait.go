package analysis

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
)

type ProdPortraitHandler struct {
	ProdPortraitService prod_portrait.IProdPortraitService
}

func (p *ProdPortraitHandler) GetProdPortrait(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp *analysis.GetProdPortraitResponse, err error) {
	resp = &analysis.GetProdPortraitResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckProdPortraitBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.ProdPortraitService.GetProdPortrait(ctx, req)
	return
}

func (p *ProdPortraitHandler) GetPordDetailList(ctx context.Context, req *analysis.GetPordDetailListRequest) (resp *analysis.GetProductAnalysisMultiDimProductListResponse, err error) {
	resp = &analysis.GetProductAnalysisMultiDimProductListResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckProdPortraitBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.ProdPortraitService.GetPordDetailList(ctx, req)
	return
}

func (p *ProdPortraitHandler) GetEchoDisplayDims(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp *analysis.GetEchoDisplayDimsResponse, err error) {
	resp = &analysis.GetEchoDisplayDimsResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckProdPortraitBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.ProdPortraitService.GetEchoDisplayDims(ctx, req)
	return
}

func (p *ProdPortraitHandler) GetProdDetailDimensions(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp *dimensions.GetDimensionListResponse, err error) {
	resp = &dimensions.GetDimensionListResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckProdPortraitBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.ProdPortraitService.GetProdDetailDimensions(ctx, req)
	return
}
