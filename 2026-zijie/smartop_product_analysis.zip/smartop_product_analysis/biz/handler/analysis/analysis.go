package analysis

import (
	"context"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"github.com/bytedance/sonic"
)

type AnalysisHandler struct {
	AnalysisService analysis_service.IAnalysisService
}

func (d *AnalysisHandler) GetProductAnalysisMultiDimList(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisMultiDimListResponse, err error) {
	resp = analysis.NewGetProductAnalysisMultiDimListResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	if len(req.BaseReq.GroupAttrs) == 0 {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage("多维分析的参数为空")
		return resp, nil
	}
	if req.IsTotal {
		if req.BaseReq.Dimensions == nil {
			req.BaseReq.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		}
		for _, attr := range req.BaseReq.GroupAttrs {
			req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, attr.DimInfo)
		}
		coreOverview, err := d.AnalysisService.GetCoreTargetEntity(ctx, req.BaseReq, req.NeedTrend)
		if err != nil {
			return resp, err
		}
		if len(coreOverview) > 0 {
			for _, c := range coreOverview {
				if c.Extra != nil && c.Extra.DistributionFlag {
					c.Extra.DistributionValue = 1
				}
			}
			// 整体的货补数据暂时填充0值，后面独立接口后修复这个问题
			if utils.IsCostUser(ctx) {
				coreOverview = append(coreOverview, []*analysis.TargetCardEntity{{
					Name:             "UserCost",
					DisplayName:      "人补成本",
					Value:            0,
					DisplayValue:     "-",
					CycleChangeRatio: 0,
					Extra: &analysis.TargetCardExtraInfo{
						IsLargerAdvantage: true,
					},
				}, {
					Name:             "ProductCost",
					DisplayName:      "货补成本",
					Value:            0,
					DisplayValue:     "-",
					CycleChangeRatio: 0,
					Extra: &analysis.TargetCardExtraInfo{
						IsLargerAdvantage: true,
					},
				}, {
					Name:             "TotalUgCost",
					DisplayName:      "总成本",
					Value:            0,
					DisplayValue:     "-",
					CycleChangeRatio: 0,
					Extra: &analysis.TargetCardExtraInfo{
						IsLargerAdvantage: true,
					},
				}}...)
			}
		}

		var wholeProdTagCode string
		if len(req.BaseReq.GroupAttrs) > 0 {
			wholeProdTagCode, err = sonic.MarshalString(&dimensions.SelectedDimensionInfo{
				Id:               req.BaseReq.GroupAttrs[0].DimInfo.Id,
				Name:             req.BaseReq.GroupAttrs[0].DimInfo.Name,
				AttrType:         req.BaseReq.GroupAttrs[0].DimInfo.AttrType,
				SelectedOperator: req.BaseReq.GroupAttrs[0].DimInfo.SelectedOperator,
				SelectedValues:   []*dimensions.EnumElement{{Code: "", Name: "整体"}},
			})
		}
		resp.Data = []*analysis.MultiDimListRow{
			{
				DisplayName: "整体",
				TargetList:  coreOverview,
				ProdTagCode: wholeProdTagCode,
			},
		}
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisMultiDimList(ctx, req.BaseReq, req.NeedTrend)
	return
}

func (d *AnalysisHandler) GetProductAnalysisCoreConclusion(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreConclusionResponse, err error) {
	resp = analysis.NewGetProductAnalysisCoreConclusionResponse()
	resp.BaseResp = base.NewBaseResp()
	req.BaseReq.GroupAttrs = nil
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisCoreConclusion(ctx, req.BaseReq)
	return
}

func (d *AnalysisHandler) GetProductAnalysisMultiDimConclusion(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisMultiDimConclusionResponse, err error) {
	resp = analysis.NewGetProductAnalysisMultiDimConclusionResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	if len(req.BaseReq.GroupAttrs) == 0 {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage("多维分析的参数为空")
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisMultiDimConclusion(ctx, req.BaseReq)
	return
}

func (d *AnalysisHandler) GetProductAnalysisCoreOverview(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreOverviewResponse, err error) {
	resp = &analysis.GetProductAnalysisCoreOverviewResponse{}
	resp.BaseResp = base.NewBaseResp()
	req.BaseReq.GroupAttrs = nil
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisCoreOverview(ctx, req.BaseReq, true)
	return
}

func (d *AnalysisHandler) GetProductAnalysisCoreHierarchical(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreHierarchicalResponse, err error) {
	resp = &analysis.GetProductAnalysisCoreHierarchicalResponse{}
	resp.BaseResp = base.NewBaseResp()
	req.BaseReq.GroupAttrs = nil
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisCoreHierarchical(ctx, req.BaseReq)
	return
}

// GetProductAnalysisMultiDimProductList 商品明细
func (d *AnalysisHandler) GetProductAnalysisMultiDimProductList(ctx context.Context, req *analysis.GetProductAnalysisMultiDimProductListRequest) (resp *analysis.GetProductAnalysisMultiDimProductListResponse, err error) {
	resp = &analysis.GetProductAnalysisMultiDimProductListResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisMultiDimProductList(ctx, req)
	return
}

func (d *AnalysisHandler) GetProductAnalysisCoreTarget(ctx context.Context, req *analysis.GetProductAnalysisCoreTargetRequest) (resp *analysis.GetProductAnalysisCoreTargetResponse, err error) {
	resp = &analysis.GetProductAnalysisCoreTargetResponse{}
	resp.BaseResp = base.NewBaseResp()
	req.BaseReq.GroupAttrs = nil
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisCoreTarget(ctx, req)
	return
}

func (d *AnalysisHandler) GetProductAnalysisMultiDimFullList(ctx context.Context, req *analysis.GetProductAnalysisMultiDimFullListRequest) (resp *analysis.GetProductAnalysisMultiDimFullListResponse, err error) {
	resp = &analysis.GetProductAnalysisMultiDimFullListResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisMultiDimFullList(ctx, req, analysis_service.AppendParams{})
	if err != nil && strings.Contains(err.Error(), "MAX_10000_LIMIT_ERROR") {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusShowInfoWarn.Int())
		resp.GetBaseResp().SetStatusMessage("您的多维分析组合超过了10000条的上限，请减少分析维度枚举数量后再探查")
		return resp, nil
	}
	return
}

func (d *AnalysisHandler) GetProductAnalysisMultiDimTrend(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisMultiDimTrendResponse, err error) {
	resp = &analysis.GetProductAnalysisMultiDimTrendResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	// 获取整体
	var total []*analysis.GetProductAnalysisMultiDimTrendInfo
	if len(req.BaseReq.GroupAttrs) > 0 && req.BaseReq.GroupAttrs[0].NeedDrillDown == false {
		req.IsTotal = true
		total, err = d.AnalysisService.GetProductAnalysisMultiDimTrend(ctx, req)
		if err != nil {
			return resp, err
		}
	}

	req.IsTotal = false
	trendList, err := d.AnalysisService.GetProductAnalysisMultiDimTrend(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = &analysis.GetProductAnalysisMultiDimTrendData{}
	if len(total) > 0 {
		resp.Data.TrendList = append(total, trendList...)
	} else {
		resp.Data.TrendList = trendList
	}
	return
}

func (d *AnalysisHandler) GetProductAnalysisMultiDimProdCostData(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetMultiDimExtraTargetListResponse, err error) {
	resp = &analysis.GetMultiDimExtraTargetListResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisMultiDimProdCostData(ctx, req)
	return
}

func (d *AnalysisHandler) GetProductReportTable(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *analysis.GetProductReportTableResponse, err error) {
	resp = &analysis.GetProductReportTableResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductReportTable(ctx, req)
	if err != nil && strings.Contains(err.Error(), "MAX_10000_LIMIT_ERROR") {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusShowInfoWarn.Int())
		resp.GetBaseResp().SetStatusMessage("您的多维分析组合超过了10000条的上限，请减少分析维度枚举数量后再探查")
		return resp, nil
	}
	return
}

func (d *AnalysisHandler) GetProductReportTableSubscribe(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *analysis.GetProductAnalysisSubscribeResponse, err error) {
	resp = &analysis.GetProductAnalysisSubscribeResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	ctx = context.WithValue(ctx, consts.CtxTemplateFlag, "true")
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductReportTableSubscribe(ctx, req)
	if err != nil && strings.Contains(err.Error(), "MAX_10000_LIMIT_ERROR") {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusShowInfoWarn.Int())
		resp.GetBaseResp().SetStatusMessage("您的多维分析组合超过了10000条的上限，请减少分析维度枚举数量后再探查")
		return resp, nil
	}
	return
}

func (d *AnalysisHandler) GetProductReportTableDownload(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductReportTableDownload(ctx, req)
	if err != nil && strings.Contains(err.Error(), "MAX_10000_LIMIT_ERROR") {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusShowInfoWarn.Int())
		resp.GetBaseResp().SetStatusMessage("您的多维分析组合超过了10000条的上限，请减少分析维度枚举数量后再探查")
		return resp, nil
	}
	return
}

func (d *AnalysisHandler) GetProductAnalysisDefaultFunnelMate(ctx context.Context, req *analysis.GetProductAnalysisDefaultFunnelMateRequest) (resp *analysis.GetProductAnalysisDefaultFunnelMateResponse, err error) {
	resp = &analysis.GetProductAnalysisDefaultFunnelMateResponse{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AnalysisService.GetProductAnalysisDefaultFunnelMate(ctx, req.BizType)
	return
}

func (d *AnalysisHandler) GetProductAnalysisProdCnt(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisProdCntResponse, err error) {
	resp = &analysis.GetProductAnalysisProdCntResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisProdCnt(ctx, req)
	return
}

func (d *AnalysisHandler) GetProductAnalysisUVCore(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreOverviewResponse, err error) {
	resp = &analysis.GetProductAnalysisCoreOverviewResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisUVCore(ctx, req)
	return
}

func (d *AnalysisHandler) GetProductAnalysisMultiDimUvTargets(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetMultiDimExtraTargetListResponse, err error) {
	resp = &analysis.GetMultiDimExtraTargetListResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.GetProductAnalysisMultiDimUvTargets(ctx, req)
	return
}

func (d *AnalysisHandler) InflectionPointInsight(ctx context.Context, req *analysis.InflectionPointInsightRequest) (resp *analysis.InflectionPointInsightResponse, err error) {
	resp = &analysis.InflectionPointInsightResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckInflectionInsightBaseParams(ctx, req.GetProductLabels()); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.InflectionPointInsight(ctx, req)
	return
}

func (d *AnalysisHandler) InflectionPointInsightDownload(ctx context.Context, req *analysis.InflectionPointInsightDownloadRequest) (resp *analysis.InflectionPointInsightDownloadResponse, err error) {
	resp = &analysis.InflectionPointInsightDownloadResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckInflectionInsightBaseParams(ctx, req.GetProductLabels()); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AnalysisService.InflectionPointInsightDownload(ctx, req)
	return
}

func (d *AnalysisHandler) GetSimilarProduct(ctx context.Context, req *analysis.GetSimilarProductRequest) (resp *analysis.GetSimilarProductResponse, err error) {
	resp = &analysis.GetSimilarProductResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckGetSimilarProductBaseParams(ctx, req); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	resp.Data, err = d.AnalysisService.GetSimilarProduct(ctx, req)
	return
}

func (d *AnalysisHandler) GetSimilarProductDownload(ctx context.Context, req *analysis.GetSimilarProductDownloadRequest) (resp *analysis.GetSimilarProductDownloadResponse, err error) {
	resp = &analysis.GetSimilarProductDownloadResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckGetSimilarProductBaseParams(ctx, &analysis.GetSimilarProductRequest{
		BaseReq:                 req.BaseReq,
		SeedProdIds:             req.SeedProdIds,
		SeedPoolIds:             req.SeedPoolIds,
		SimilarProdIds:          req.SimilarProdIds,
		SimilarPoolIds:          req.SimilarPoolIds,
		SeedFilterDimensions:    req.SeedFilterDimensions,
		SimilarFilterDimensions: req.SimilarFilterDimensions,
	}); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	resp.Data, err = d.AnalysisService.GetSimilarProductDownload(ctx, req)
	return
}

func (d *AnalysisHandler) CreateGetSimilarProductPool(ctx context.Context, req *analysis.CreateGetSimilarProductPoolRequest) (resp *analysis.CreateGetSimilarProductPoolResponse, err error) {
	resp = &analysis.CreateGetSimilarProductPoolResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckGetSimilarProductBaseParams(ctx, &analysis.GetSimilarProductRequest{
		BaseReq:                 req.BaseReq,
		SeedProdIds:             req.SeedProdIds,
		SeedPoolIds:             req.SeedPoolIds,
		SimilarProdIds:          req.SimilarProdIds,
		SimilarPoolIds:          req.SimilarPoolIds,
		SeedFilterDimensions:    req.SeedFilterDimensions,
		SimilarFilterDimensions: req.SimilarFilterDimensions,
	}); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	resp.Data, err = d.AnalysisService.CreateGetSimilarProductPool(ctx, req)
	if err != nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}
