package analysis

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
)

type PriceAnalysis struct {
	PriceAnalysisService price_analysis_service.IPriceAnalysisService
}

func (p *PriceAnalysis) GetPriceInsightCoreOverview(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp = &analysis.GetPriceInsightCoreOverviewResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetPriceInsightCoreOverview(ctx, req)
	return
}

func (p *PriceAnalysis) GetPriceInsightHierarchicalTrend(ctx context.Context, req *analysis.GetPriceInsightHierarchicalTrendRequest) (resp *analysis.GetPriceInsightHierarchicalTrendResponse, err error) {
	resp = &analysis.GetPriceInsightHierarchicalTrendResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetPriceInsightHierarchicalTrend(ctx, req)
	return
}

func (p *PriceAnalysis) GetMultipleRatioTable(ctx context.Context, req *analysis.GetMultipleRatioTableRequest) (resp *analysis.GetMultipleRatioTableResponse, err error) {
	resp = &analysis.GetMultipleRatioTableResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetMultipleRatioTable(ctx, req)
	return
}

func (p *PriceAnalysis) GetPriceInsightBubbleChart(ctx context.Context, req *analysis.GetPriceInsightBubbleChartRequest) (resp *analysis.GetPriceInsightBubbleChartResponse, err error) {
	resp = &analysis.GetPriceInsightBubbleChartResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetPriceInsightBubbleChart(ctx, req)
	return
}

func (p *PriceAnalysis) GetPriceInsightMeta(ctx context.Context, req *analysis.GetPriceInsightMetaRequest) (resp *analysis.GetPriceInsightMetaResponse, err error) {
	resp = &analysis.GetPriceInsightMetaResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetPriceInsightMeta(ctx, req.BaseReq)
	return
}

func (p *PriceAnalysis) GetOrderResponsibilityDistributed(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp *analysis.GetOrderResponsibilityDistributedResponse, err error) {
	resp = &analysis.GetOrderResponsibilityDistributedResponse{
		Data: &analysis.GetOrderResponsibilityDistributedData{},
	}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data.TargetList, err = p.PriceAnalysisService.GetOrderResponsibilityDistributed(ctx, req)
	return
}

func (p *PriceAnalysis) GetOrderResponsibilityCoreOverview(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetOrderResponsibilityCoreOverviewResponse, err error) {
	resp = &analysis.GetOrderResponsibilityCoreOverviewResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetOrderResponsibilityCoreOverview(ctx, req.BaseReq)
	return
}

func (p *PriceAnalysis) GetOrderResponsibilityChange(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp *analysis.GetOrderResponsibilityChangeResponse, err error) {
	resp = &analysis.GetOrderResponsibilityChangeResponse{
		Data: &analysis.GetOrderResponsibilityChangeData{},
	}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data.Info, err = p.PriceAnalysisService.GetOrderResponsibilityChange(ctx, req)
	return
}

func (p *PriceAnalysis) GetOrderResponsibilityTargetList(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp *analysis.GetOrderResponsibilityCoreOverviewResponse, err error) {
	resp = &analysis.GetOrderResponsibilityCoreOverviewResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetOrderResponsibilityTargetList(ctx, req, true)
	return
}

func (p *PriceAnalysis) GetOrderResponsibilityIndustryList(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetOrderResponsibilityIndustryListResponse, err error) {
	resp = &analysis.GetOrderResponsibilityIndustryListResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetOrderResponsibilityIndustryList(ctx, req)
	return
}

func (p *PriceAnalysis) GetOrderResponsibilityBubbleChart(ctx context.Context, req *analysis.GetOrderResponsibilityBubbleChartRequest) (resp *analysis.GetPriceInsightBubbleChartResponse, err error) {
	resp = &analysis.GetPriceInsightBubbleChartResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = p.PriceAnalysisService.GetOrderResponsibilityBubbleChart(ctx, req)
	return
}