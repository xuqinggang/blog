package attribution

import (
	great_value_buy_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/great_value_buy"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/aggregate"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"context"
)

func (d *AttributionHandler) GuessAllTreeDownload(ctx context.Context, greatValueBuyHandler *great_value_buy_handler.GreatValueBuyHandler, req *aggregate.AllTreeDownloadRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()

	// 参数校验
	if req == nil {
		return
	}

	if req.TreeReq != nil && req.TreeReq.BaseReq != nil && req.TreeReq.BaseReq.BizType > 0 {
		// 归因树下载
		var ctResp *great_value_buy.GetGreatValueBuyAttributionCoreTreeResponse
		ctResp, err = greatValueBuyHandler.GetGreatValueBuyAttributionCoreTree(ctx, req.TreeReq)
		if err != nil {
			return
		}
		err = d.AttributionService.GetGreatBuyCoreTreeDownload(ctx, req.TreeReq, ctResp)
		return
	}

	// 命题诊断下载
	ovResp, err := d.GetGuessCoreOverview(ctx, req.DiagnosisReq)
	if err != nil {
		return
	}
	err = d.AttributionService.GuessAllTreeDownload(ctx, req.DiagnosisReq, ovResp)
	return
}
