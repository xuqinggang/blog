package attribution

import (
	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"context"
	"github.com/mohae/deepcopy"
	"sort"
	"time"
)

const (
	BizTypeBlank = 0
)

func (d *AttributionHandler) GetGuessCoreOverview(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionCommonCoreOverviewResponse, err error) {
	resp = analysis.NewGetAttributionCommonCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetAttributionCommonCoreOverviewData{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty

	// 准备bizType
	bizType := req.BaseReq.BizType
	if bizType == BizTypeBlank {
		req.BaseReq.BizType = dimensions.BizType_AttributionCoreGuessV2
	}
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	// 兜底返回
	if bizType == -1 {
		return resp, nil
	}

	// 单命题诊断
	if bizType != BizTypeBlank {
		resp.Data.TargetList, err = d.AttributionService.GetGuessCoreOverview(ctx, req)
		return
	}

	// 全部命题聚合top5
	resp.Data.TargetList, err = d.GetTop5Metric(ctx, req)
	return
}

func (d *AttributionHandler) GetTop5Metric(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) ([]*analysis.TargetCardEntity, error) {
	// 查询命题列表
	bizType := dimensions.BizType_AttributionCoreGuessV2
	data, err := d.AttributionService.GetAttributionAnalysisBizList(ctx, &analysis.GetAttributionAnalysisBizListRequest{
		ObjectBizType: &bizType,
	})
	if err != nil {
		return nil, err
	}

	// 解析涉及的业务线
	bizTypes := parseBizTypes(data)
	if len(bizTypes) == 0 {
		return nil, errors.New("top5异常指标查询，涉及业务线不存在")
	}

	// 并发获取各业务线指标
	cc := co.NewConcurrent(ctx)
	targets := make([][]*analysis.TargetCardEntity, len(bizTypes))
	for k, v := range bizTypes {
		kTemp := k
		var ok bool
		var reqCopy *analysis.GetAttributionCommonBaseRequest
		if reqCopy, ok = deepcopy.Copy(req).(*analysis.GetAttributionCommonBaseRequest); !ok {
			continue
		}
		reqCopy.BaseReq.BizType = v
		cc.GoV2(func() error {
			tm := time.Now()
			targets[kTemp], err = d.AttributionService.GetGuessCoreOverview(ctx, reqCopy)
			logs.CtxWarn(ctx, "[GetTop5Metric] bizId:%d, cost:%d", reqCopy.BaseReq.BizType, time.Since(tm)/time.Second)
			return err
		})
	}
	err = cc.WaitV2()
	if err != nil {
		logs.CtxError(ctx, "GetGuessCoreOverview err=%v", err)
		return nil, err
	}

	// 聚合取top5指标
	return parseTop5Metric(targets), nil
}

func parseTop5Metric(targets [][]*analysis.TargetCardEntity) []*analysis.TargetCardEntity {
	resp := make([]*analysis.TargetCardEntity, 0)
	for _, v := range targets {
		if v == nil || len(v) == 0 {
			continue
		}
		resp = append(resp, v...)
	}

	// 排序
	sort.SliceStable(resp, func(i, j int) bool {
		// 前置校验
		if resp[i] == nil || resp[i].Extra == nil || resp[i].ComparePeriodData == nil {
			return false
		}
		if resp[j] == nil || resp[j].Extra == nil || resp[j].ComparePeriodData == nil {
			return false
		}

		// 默认展示优先
		if resp[i].Extra.IsDefaultShow == false {
			return false
		}
		if resp[j].Extra.IsDefaultShow == false {
			return true
		}

		// 增幅不存在场景。todo 测一下
		if resp[i].ComparePeriodData.CompareChangeRatio == consts.MagicNumber {
			return false
		}
		if resp[j].ComparePeriodData.CompareChangeRatio == consts.MagicNumber {
			return true
		}

		// aa增幅倒排top5（结合是否越大越好）
		iRatio := resp[i].ComparePeriodData.CompareChangeRatio
		if resp[i].Extra.IsLargerAdvantage == false {
			iRatio *= -1
		}
		jRatio := resp[j].ComparePeriodData.CompareChangeRatio
		if resp[j].Extra.IsLargerAdvantage == false {
			jRatio *= -1
		}
		return iRatio < jRatio
	})

	if len(resp) >= 5 {
		return resp[:5]
	}
	return resp
}

func parseBizTypes(data *analysis.GetAttributionAnalysisBizListItem) []dimensions.BizType {
	bizTypes := make([]dimensions.BizType, 0)
	bizTypeMap := make(map[dimensions.BizType]interface{})
	if data == nil {
		return bizTypes
	}
	if len(data.BizList) <= 0 {
		return bizTypes
	}
	for _, biz := range data.BizList[0].SupportBizModules {
		if biz == nil {
			continue
		}
		if biz.BizType != nil && *biz.BizType > BizTypeBlank {
			bizTypeMap[*biz.BizType] = nil
		}
		fillBizTypeMap(bizTypeMap, biz.Children)
	}

	for biz, _ := range bizTypeMap {
		bizTypes = append(bizTypes, biz)
	}
	return bizTypes
}

func fillBizTypeMap(typeMap map[dimensions.BizType]interface{}, children []*analysis.GetAttributionMetaInfo) {
	if typeMap == nil {
		return
	}
	for _, child := range children {
		if child == nil {
			continue
		}
		typeMap[child.BizType] = nil
	}
	return
}
