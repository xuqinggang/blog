package attribution

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/attribution_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"context"
	"reflect"
	"testing"
)

func Test_parseTop5Metric(t *testing.T) {
	type args struct {
		targets [][]*analysis.TargetCardEntity
	}
	tests := []struct {
		name string
		args args
		want []*analysis.TargetCardEntity
	}{
		// 比较数值
		{
			name: "111",
			args: args{
				targets: [][]*analysis.TargetCardEntity{{
					&analysis.TargetCardEntity{
						Extra: &analysis.TargetCardExtraInfo{
							IsLargerAdvantage: true,
							IsDefaultShow:     true,
						},
						ComparePeriodData: &analysis.ComparePeriodData{
							CompareChangeRatio: 0.30,
						},
					},
				}, {
					&analysis.TargetCardEntity{
						Extra: &analysis.TargetCardExtraInfo{
							IsLargerAdvantage: true,
							IsDefaultShow:     true,
						},
						ComparePeriodData: &analysis.ComparePeriodData{
							CompareChangeRatio: 0.10,
						},
					},
				}},
			},
		},
		// 是否默认展示
		{
			name: "111",
			args: args{
				targets: [][]*analysis.TargetCardEntity{{
					&analysis.TargetCardEntity{
						Extra: &analysis.TargetCardExtraInfo{
							IsLargerAdvantage: true,
							IsDefaultShow:     false,
						},
						ComparePeriodData: &analysis.ComparePeriodData{
							CompareChangeRatio: 0.0,
						},
					},
				}, {
					&analysis.TargetCardEntity{
						Extra: &analysis.TargetCardExtraInfo{
							IsLargerAdvantage: true,
							IsDefaultShow:     true,
						},
						ComparePeriodData: &analysis.ComparePeriodData{
							CompareChangeRatio: 0.10,
						},
					},
				}},
			},
		},
		// 是否越大越好
		{
			name: "111",
			args: args{
				targets: [][]*analysis.TargetCardEntity{{
					&analysis.TargetCardEntity{
						Extra: &analysis.TargetCardExtraInfo{
							IsLargerAdvantage: false,
							IsDefaultShow:     true,
						},
						ComparePeriodData: &analysis.ComparePeriodData{
							CompareChangeRatio: 0.30,
						},
					},
				}, {
					&analysis.TargetCardEntity{
						Extra: &analysis.TargetCardExtraInfo{
							IsLargerAdvantage: true,
							IsDefaultShow:     true,
						},
						ComparePeriodData: &analysis.ComparePeriodData{
							CompareChangeRatio: 0.10,
						},
					},
				}},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := parseTop5Metric(tt.args.targets); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("parseTop5Metric() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestAttributionHandler_GetGuessCoreOverview(t *testing.T) {
	type fields struct {
		AttributionService attribution_service.IAttributionService
	}
	type args struct {
		ctx context.Context
		req *analysis.GetAttributionCommonBaseRequest
	}
	tests := []struct {
		name     string
		fields   fields
		args     args
		wantResp *analysis.GetAttributionCommonCoreOverviewResponse
		wantErr  bool
	}{
		{
			name: "11",
			args: args{
				ctx: context.Background(),
				req: &analysis.GetAttributionCommonBaseRequest{
					BaseReq: &analysis.AttributionCommonBaseStruct{
						BizType:          dimensions.BizType_AttributionCore,
						ObjectBizType:    nil,
						InsightType:      0,
						StartDate:        "",
						EndDate:          "",
						CompareStartDate: "",
						CompareEndDate:   "",
						SyncType:         nil,
						Dimensions:       nil,
						GroupAttrs:       nil,
						ThresholdAttrs:   nil,
						ThresholdExpr:    nil,
						NeedTrend:        nil,
						PvIncrType:       nil,
						OrderBy:          nil,
					},
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &AttributionHandler{
				AttributionService: tt.fields.AttributionService,
			}
			gotResp, err := d.GetGuessCoreOverview(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetGuessCoreOverview() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotResp, tt.wantResp) {
				t.Errorf("GetGuessCoreOverview() gotResp = %v, want %v", gotResp, tt.wantResp)
			}
		})
	}
}
