package attribution

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/attribution_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
)

type AttributionHandler struct {
	AttributionService attribution_service.IAttributionService
}

func (d *AttributionHandler) GetAttributionCommonCoreOverview(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionCommonCoreOverviewResponse, err error) {
	resp = analysis.NewGetAttributionCommonCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetAttributionCommonCoreOverviewData{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data.TargetList, err = d.AttributionService.GetAttributionCommonCoreOverview(ctx, req)
	return
}

func (d *AttributionHandler) GetAttributionCommonProdList(ctx context.Context, req *analysis.GetAttributionCommonPageRequest) (resp *analysis.GetAttributionCommonProdListResponse, err error) {
	resp = analysis.NewGetAttributionCommonProdListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetAttributionCommonProdList{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AttributionService.GetAttributionCommonProdList(ctx, req, true)
	return
}

func (d *AttributionHandler) GetAttributionTreeMetaList(ctx context.Context, req *analysis.GetAttributionTreeMetaListRequest) (resp *analysis.GetAttributionTreeMetaListResponse, err error) {
	resp = analysis.NewGetAttributionTreeMetaListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AttributionService.GetAttributionTreeMetaList(ctx, req)
	return
}

func (d *AttributionHandler) GetAttributionCommonProdListDownload(ctx context.Context, req *analysis.GetAttributionCommonPageRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AttributionService.GetAttributionCommonProdListDownload(ctx, req)
	return
}

func (d *AttributionHandler) GetAttributionCoreTree(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionCoreTreeResponse, err error) {
	resp = analysis.NewGetAttributionCoreTreeResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetAttributionCoreTreeData{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AttributionService.GetAttributionCoreTree(ctx, req.BaseReq)
	return
}

func (d *AttributionHandler) GetAttributionFlowChange(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionFlowChangeResponse, err error) {
	resp = analysis.NewGetAttributionFlowChangeResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetAttributionFlowChangeData{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AttributionService.GetAttributionFlowChange(ctx, req.BaseReq)
	return
}

func (d *AttributionHandler) GetAttributionMetaInfo(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionMetaInfoResponse, err error) {
	resp = analysis.NewGetAttributionMetaInfoResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetAttributionMetaInfoItem{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AttributionService.GetAttributionMetaInfo(ctx, req.BaseReq)
	return
}

func (d *AttributionHandler) GetAttributionCommonCoreOverviewDownload(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AttributionService.GetAttributionCommonCoreOverviewDownload(ctx, req)
	return
}

func (d *AttributionHandler) GetAttributionProdPriceDistribution(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionProdPriceDistributionResponse, err error) {
	resp = analysis.NewGetAttributionProdPriceDistributionResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AttributionService.GetAttributionProdPriceDistribution(ctx, req.BaseReq)
	return
}

func (d *AttributionHandler) GetProductDetail(ctx context.Context, req *analysis.GetProductDetailRequest) (resp *analysis.GetProductDetailResponse, err error) {
	resp = analysis.NewGetProductDetailResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AttributionService.GetProductDetail(ctx, req)
	return
}

func (d *AttributionHandler) GetProductDetailBy360(ctx context.Context, req *analysis.GetProductDetailRequest) (resp *analysis.GetProductDetailBy360Response, err error) {
	resp = analysis.NewGetProductDetailBy360Response()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AttributionService.GetProductDetailBy360(ctx, req)
	return
}

func (d *AttributionHandler) GetAttributionABtestList(ctx context.Context, req *analysis.GetAttributionABtestListRequest) (resp *analysis.GetAttributionABtestListResponse, err error) {
	resp = analysis.NewGetAttributionABtestListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetAttributionABtestList{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp, err = d.AttributionService.GetAttributionABtestList(ctx, req)
	return resp, err
}

func (d *AttributionHandler) GetAttributionABtestListDownload(ctx context.Context, req *analysis.GetAttributionABtestListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = false
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp, err = d.AttributionService.GetAttributionABtestListDownload(ctx, req)
	return resp, err
}

func (d *AttributionHandler) GetAttributionABtestProdList(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) (resp *analysis.GetAttributionABtestListResponse, err error) {
	resp = analysis.NewGetAttributionABtestListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &analysis.GetAttributionABtestList{}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp, err = d.AttributionService.GetAttributionABtestProdList(ctx, req)
	return resp, err
}

func (d *AttributionHandler) GetAttributionABtestProdListDownload(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = false
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp, err = d.AttributionService.GetAttributionABtestProdListDownload(ctx, req)
	return resp, err
}

func (d *AttributionHandler) GetAttributionAnalysisBizList(ctx context.Context, req *analysis.GetAttributionAnalysisBizListRequest) (resp *analysis.GetAttributionAnalysisBizListResponse, err error) {
	resp = analysis.NewGetAttributionAnalysisBizListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AttributionService.GetAttributionAnalysisBizList(ctx, req)
	return resp, err
}

func (d *AttributionHandler) GetAttributionMultiDimAnalysis(ctx context.Context, req *analysis.GetAttributionMultiDimAnalysisRequest) (resp *analysis.GetAttributionMultiDimAnalysisResponse, err error) {
	resp = &analysis.GetAttributionMultiDimAnalysisResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.AttributionService.GetAttributionMultiDimAnalysis(ctx, req)
	return resp, err
}
