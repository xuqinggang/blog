package prod_review

import (
	multi_dim_table_service "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_table_domain/service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_review_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
)

type ProductReviewHandler struct {
	DimensionService     dimension_service.IDimensionService
	ProductReviewService product_review_service.IProductReviewService
	MultiDimTableService multi_dim_table_service.IMultiDimTableService
}

func (d *ProductReviewHandler) CreateAndUpdateProdReviewStrategy(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewStrategyRequest) (resp *prod_review.CreateAndUpdateProdReviewStrategyResponse, err error) {
	resp = &prod_review.CreateAndUpdateProdReviewStrategyResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductReviewService.ICreateAndUpdateProdReviewStrategy(ctx, req)
	if err != nil {
		return
	}

	return
}

func (d *ProductReviewHandler) GetProdReviewStrategyList(ctx context.Context, req *prod_review.GetProdReviewStrategyListRequest) (resp *prod_review.GetProdReviewStrategyListResponse, err error) {
	resp = &prod_review.GetProdReviewStrategyListResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductReviewService.IGetProductReviewStrategyList(ctx, req, nil)
	if err != nil {
		return
	}

	return
}

func (d *ProductReviewHandler) CreateAndUpdateProdReviewBizProject(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewBizProjectRequest) (resp *prod_review.CreateAndUpdateProdReviewBizProjectResponse, err error) {
	resp = &prod_review.CreateAndUpdateProdReviewBizProjectResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductReviewService.ICreateAndUpdateProdReviewBizProject(ctx, req)
	if err != nil {
		return
	}

	return
}

func (d *ProductReviewHandler) GetProdReviewBizProjectList(ctx context.Context, req *prod_review.GetProdReviewBizProjectListRequest) (resp *prod_review.GetProdReviewBizProjectListResponse, err error) {
	resp = &prod_review.GetProdReviewBizProjectListResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductReviewService.IGetProductReviewBizProjectList(ctx, req, nil)
	if err != nil {
		return
	}

	return
}

func (d *ProductReviewHandler) CreateAndUpdateProdReviewReport(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewReportRequest) (resp *prod_review.CreateAndUpdateProdReviewReportResponse, err error) {
	resp = &prod_review.CreateAndUpdateProdReviewReportResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductReviewService.ICreateAndUpdateProdReviewReport(ctx, req)
	if err != nil {
		return
	}

	return
}

func (d *ProductReviewHandler) GetProdReviewReportList(ctx context.Context, req *prod_review.GetProdReviewReportListRequest) (resp *prod_review.GetProdReviewReportListResponse, err error) {
	resp = &prod_review.GetProdReviewReportListResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductReviewService.IGetProductReviewReportList(ctx, req)
	if err != nil {
		return
	}

	return
}

func (d *ProductReviewHandler) GetProductReviewStrategyTypeList(ctx context.Context, req *prod_review.GetProdReviewStrategyTypeListRequest) (resp *prod_review.GetProdReviewStrategyTypeListResponse, err error) {
	resp = &prod_review.GetProdReviewStrategyTypeListResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductReviewService.IGetProductReviewStrategyTypeList(ctx, req)
	if err != nil {
		return
	}

	return
}

func (d *ProductReviewHandler) GetLibraInfo(ctx context.Context, req *prod_review.GetLibraInfoRequest) (resp *prod_review.GetLibraInfoResponse, err error) {
	resp = &prod_review.GetLibraInfoResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductReviewService.IGetLibraInfo(ctx, req)
	if err != nil {
		return
	}

	return
}

func (d *ProductReviewHandler) GetBizConfig(ctx context.Context, req *common_request.BizConfigRequest) (resp *common_response.BizConfigResponse, err error) {
	resp = &common_response.BizConfigResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	resp.Data, err = d.ProductReviewService.ICommonGetBizConfig(ctx, req)
	if err != nil {
		resp.BaseResp.StatusCode = stcodes.StatusCodeDefaultError.Int()
		resp.BaseResp.StatusMessage = err.Error()
		return
	}
	return
}

func (d *ProductReviewHandler) ProductValueClassify(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisItemDataResponse, err error) {
	resp = common_response.NewCommonAnalysisItemDataResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = common_response.NewItemDataList()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ProductReviewService.ProductValueClassify(ctx, req)
	return
}

func (d *ProductReviewHandler) ProductFourQuadrantAnalysis(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisItemDataResponse, err error) {
	resp = common_response.NewCommonAnalysisItemDataResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = common_response.NewItemDataList()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ProductReviewService.ProductFourQuadrantAnalysis(ctx, req)
	if err != nil {
		resp.BaseResp.StatusCode = stcodes.StatusCodeDefaultError.Int()
		resp.BaseResp.StatusMessage = err.Error()
		return
	}
	return
}

func (d *ProductReviewHandler) GetBubbleChart(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisUnifiedDataResponse, err error) {
	resp = common_response.NewCommonAnalysisUnifiedDataResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = common_response.NewUnifiedData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ProductReviewService.GetBubbleChart(ctx, req)
	if err != nil {
		resp.BaseResp.StatusCode = stcodes.StatusCodeDefaultError.Int()
		resp.BaseResp.StatusMessage = err.Error()
		return
	}
	return
}

func (d *ProductReviewHandler) BubbleChartDownload(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisDownloadResponse, err error) {
	resp = common_response.NewCommonAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ProductReviewService.BubbleChartDownload(ctx, req)
	if err != nil {
		resp.BaseResp.StatusCode = stcodes.StatusCodeDefaultError.Int()
		resp.BaseResp.StatusMessage = err.Error()
		return
	}
	return
}
