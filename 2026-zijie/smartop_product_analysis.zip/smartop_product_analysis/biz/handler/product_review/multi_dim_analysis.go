package prod_review

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_review_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/ecom/smartop_product_analysis/mw"
)

func (d *ProductReviewHandler) CommonAnalysisMultiDimTable(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisMultiDimTableResponse, err error) {
	resp = common_response.NewCommonAnalysisMultiDimTableResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = common_response.NewMultiDimTableData()
	if req == nil || req.BizExtraInfo == nil || req.BizExtraInfo.ProdReviewParams == nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeParamError.String())
		return resp, nil
	}

	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	if req.CompareReq != nil {
		if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.CompareReq); !ok {
			resp.GetBaseResp().SetStatusCode(stCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
			return resp, nil
		}
	}
	resp.Data, _, err = d.MultiDimTableService.ICommonAnalysisMultiDimTable(ctx, req)
	return
}

func (d *ProductReviewHandler) CommonAnalysisMultiDimTableDownload(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisDownloadResponse, err error) {
	resp = common_response.NewCommonAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = false
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	if req.BizExtraInfo.ProdReviewParams != nil && req.BizExtraInfo.ProdReviewParams.ModuleName == prod_review.ModuleName_SpecialItemMultiDimAnalysis {
		if req.CompareReq != nil {
			if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.CompareReq); !ok {
				resp.GetBaseResp().SetStatusCode(stCode.Int())
				resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
				return resp, nil
			}
		}
	}
	if req.BizExtraInfo.ProdReviewParams != nil && req.BizExtraInfo.ProdReviewParams.ModuleName == prod_review.ModuleName_AllowanceTarget {
		targetTable := d.CommonAnalysisTargetTable(ctx, req)
		if targetTable.BaseResp != nil && targetTable.BaseResp.StatusCode != 0 {
			resp.GetBaseResp().SetStatusCode(targetTable.BaseResp.StatusCode)
			resp.GetBaseResp().SetStatusMessage(targetTable.BaseResp.StatusMessage)
			return resp, nil
		}
		resp.Data, err = product_review_service.CommonAnalysisTargetTableDownload(ctx, req, targetTable.Data)
	} else {
		resp.Data, err = d.MultiDimTableService.ICommonAnalysisMultiDimTableDownload(ctx, req)
	}

	return
}
