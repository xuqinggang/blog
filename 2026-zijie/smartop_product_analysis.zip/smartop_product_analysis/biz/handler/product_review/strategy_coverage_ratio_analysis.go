package prod_review

import (
	"context"
	"errors"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
)

func (d *ProductReviewHandler) StrategyCoverageRatioExtraInfo(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp map[string]string, err error) {
	if req == nil || req.BaseReq == nil {
		return nil, errors.New("StrategyCoverageRatioAnalysis req is nil")
	}
	resp, err = d.ProductReviewService.IGetStrategyCoverageRatio(ctx, req)
	return
}