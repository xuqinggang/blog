package prod_review

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
)

func (d *ProductReviewHandler) CommonAnalysisItemData(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisItemDataResponse, err error) {
	resp = common_response.NewCommonAnalysisItemDataResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = common_response.NewItemDataList()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.ProductReviewService.ICommonAnalysisItemData(ctx, req)
	return
}
