package prod_review

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"strconv"
)

func (d *ProductReviewHandler) CommonAnalysisTargetTable(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisTargetTableResponse) {
	resp = &common_response.CommonAnalysisTargetTableResponse{BaseResp: base.NewBaseResp()}

	// 参数校验，初始化上下文
	if req == nil || req.BizExtraInfo == nil || req.BizExtraInfo.ProdReviewParams == nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeParamError.String())
		return resp
	}
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp
	}

	// 查询默认展示字段
	targetMeteInfo, err := new(dao.AttributeDao).GetTargetMetaInfo(ctx, int64(req.BaseReq.BizType), []int64{1}, "目标分析")
	if err != nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		return resp
	}
	if len(targetMeteInfo) <= 0 {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage("未配置目标字段元信息")
		return resp
	}
	req.BaseReq.TargetMetaList = toMetaList(targetMeteInfo)
	req.CompareReq.TargetMetaList = toMetaList(targetMeteInfo)

	// 获取维度枚举
	dimId := int64(10426)
	if len(req.BaseReq.GroupAttrs) > 0 && req.BaseReq.GroupAttrs[0].DimInfo != nil {
		dimId, _ = strconv.ParseInt(req.BaseReq.GroupAttrs[0].DimInfo.Id, 10, 64)
	}
	enum, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(dimId))
	if err != nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage(fmt.Sprintf("维度枚举获取失败，err:%s", err.Error()))
		return resp
	}
	if enum == nil || len(enum.Values) <= 0 {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage(fmt.Sprintf("维度枚举获取为空"))
		return resp
	}
	req.BaseReq.GroupAttrs = toGroupAttrs(dimId, enum.Values)
	req.CompareReq.GroupAttrs = toGroupAttrs(dimId, enum.Values)

	return d.ProductReviewService.ICommonAnalysisTargetTable(ctx, req)
}

func toGroupAttrs(dimId int64, enums []*dimensions.EnumElement) []*dimensions.SelectedMultiDimensionInfo {
	return []*dimensions.SelectedMultiDimensionInfo{
		{
			DimInfo: &dimensions.SelectedDimensionInfo{
				Id: strconv.FormatInt(dimId, 10),
				//Name:           dim.ShowName,
				AttrType:       3,
				SelectedValues: toSelected(enums),
			},
		},
	}
}

func toSelected(enums []*dimensions.EnumElement) []*dimensions.EnumElement {
	resp := make([]*dimensions.EnumElement, 0)
	for _, enum := range enums {
		resp = append(resp, &dimensions.EnumElement{
			Code: enum.Code,
			Name: enum.Name,
		})
	}
	return resp
}

func toMetaList(metas []*dao.TargetMetaInfo) []string {
	resp := make([]string, 0)
	for _, v := range metas {
		if v == nil {
			continue
		}
		resp = append(resp, v.Name)
	}
	return resp
}
