package product_select

import (
	"context"
	"errors"

	activity_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/activity"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_select_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/product_select"
	"code.byted.org/gopkg/logs"
)

type ProductSelectHandler struct {
	ProductSelectService product_select_service.IProductSelectService
}

func (d *ProductSelectHandler) CreateAndUpdateProductSelectTask(ctx context.Context, req *product_select.CreateAndUpdateProductSelectTaskRequest) (resp *product_select.CreateAndUpdateProductSelectTaskResponse, err error) {
	resp = &product_select.CreateAndUpdateProductSelectTaskResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductSelectService.ICreateAndUpdateProductSelectTask(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "CreateAndUpdateProductSelectTask ICreateAndUpdateProductSelectTask error, %s", err.Error())
		return
	}

	return
}

func (d *ProductSelectHandler) GetProductSelectTaskList(ctx context.Context, req *product_select.GetProductSelectTaskListRequest) (resp *product_select.GetProductSelectTaskListResponse, err error) {
	resp = &product_select.GetProductSelectTaskListResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductSelectService.IGetProductSelectTaskList(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetProductSelectTaskList IGetProductSelectTaskList error, %s", err.Error())
		return
	}

	return
}

func (d *ProductSelectHandler) GetProductSelectTaskDetail(ctx context.Context, req *product_select.GetProductSelectTaskDetailRequest) (resp *product_select.GetProductSelectTaskDetailResponse, err error) {
	resp = &product_select.GetProductSelectTaskDetailResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductSelectService.IGetProductSelectTaskDetail(ctx, req)
	if err != nil {
		return
	}

	return
}

func (d *ProductSelectHandler) GetProdDetailList(ctx context.Context, req *product_select.GetProdDetailListRequest) (resp *product_select.GetProdDetailListResponse, err error) {
	resp = &product_select.GetProdDetailListResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductSelectService.IGetProdDetailList(ctx, req)
	if err != nil {
		return
	}

	return
}

func (d *ProductSelectHandler) GetProductSelectAdministratorConfig(ctx context.Context, req *product_select.GetProductSelectAdministratorConfigRequest) (resp *product_select.GetProductSelectAdministratorConfigResponse, err error) {
	resp = &product_select.GetProductSelectAdministratorConfigResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductSelectService.IGetProductSelectAdministratorConfig(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetProductSelectAdministratorConfig IGetProductSelectAdministratorConfig error, %s", err.Error())
		return
	}

	return
}

func (d *ProductSelectHandler) GetProductSelectTaskPreviewResult(ctx context.Context, req *product_select.GetProductSelectTaskPreviewResultRequest) (resp *product_select.GetProductSelectTaskPreviewResultResponse, err error) {
	resp = &product_select.GetProductSelectTaskPreviewResultResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp, err = d.ProductSelectService.IGetProductSelectTaskPreviewResult(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetProductSelectTaskPreviewResult IGetProductSelectTaskPreviewResult error, %s", err.Error())
		return
	}

	return
}

// GetUserPrivilege 获取用户权限信息的处理器方法
func (d *ProductSelectHandler) GetUserPrivilege(ctx context.Context, req *product_select.GetUserPrivilegeRequest) (resp *product_select.GetUserPrivilegeResponse, err error) {
	resp = &product_select.GetUserPrivilegeResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	// 从上下文获取用户信息
	userInfo := utils.GetUserInfo(ctx)
	logs.CtxInfo(ctx, "GetUserPrivilege userInfo=%+v", userInfo)

	// 验证用户身份
	if !activity_handler.ValidateUser(ctx, userInfo) {
		logs.CtxWarn(ctx, "GetUserPrivilege ValidateUser error, userInfo=%+v", userInfo)
		return nil, errors.New("暂无权限")
	}
	if userInfo != nil {
		req.EmployeeId = userInfo.EmployeeId
	}

	// 调用服务层获取用户权限
	resp, err = d.ProductSelectService.IGetUserPrivilege(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "GetUserPrivilege error, %s", err.Error())
		return
	}

	logs.CtxInfo(ctx, "GetUserPrivilege success, employeeId=%s, privilegeType=%v", req.EmployeeId, resp.GetPrivilegeType())
	return
}
