package ai_analysis_handler

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_conclusion_service"

	// "code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	// "code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"github.com/jinzhu/copier"
)

type AIAnalysisHandler struct {
	AIAnalysisService   ai_analysis_service.IAIAnalysisService
	AIConclusionService ai_conclusion_service.IAIConclusionService
}

func (d *AIAnalysisHandler) AIConclusion(ctx context.Context, req *ai_analysis.AIConclusionRequest) (resp *ai_analysis.AIResponse, err error) {
	resp = ai_analysis.NewAIResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AIConclusionService.AIConclusion(ctx, req, nil)
	return
}

func (d *AIAnalysisHandler) AIConclusionStream(req *ai_analysis.AIConclusionRequest, stream ai_analysis_service.StreamServer) (err error) {
	_, err = d.AIConclusionService.AIConclusion(stream.Context(), req, &stream)
	if err != nil {
		d.sendErrorEvent(stream, err)
		return
	}
	return
}

func (d *AIAnalysisHandler) CreateAnalysisFramework(ctx context.Context, req *ai_analysis.CreateAnalysisFrameworkRequest) (resp *ai_analysis.CreateAnalysisFrameworkResponse, err error) {
	resp = ai_analysis.NewCreateAnalysisFrameworkResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIAnalysisService.CreateFramework(ctx, req)
	return
}

func (d *AIAnalysisHandler) GetAnalysisFramework(ctx context.Context, req *ai_analysis.GetAnalysisFrameworkRequest) (resp *ai_analysis.GetAnalysisFrameworkResponse, err error) {
	resp = ai_analysis.NewGetAnalysisFrameworkResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AIAnalysisService.GetFramework(ctx, req)
	return
}

func (d *AIAnalysisHandler) DeleteAnalysisFramework(ctx context.Context, req *ai_analysis.DeleteAnalysisFrameworkRequest) (resp *ai_analysis.DeleteAnalysisFrameworkResponse, err error) {
	resp = ai_analysis.NewDeleteAnalysisFrameworkResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIAnalysisService.DeleteFramework(ctx, req)
	return
}

func (d *AIAnalysisHandler) UpdateAnalysisFramework(ctx context.Context, req *ai_analysis.UpdateAnalysisFrameworkRequest) (resp *ai_analysis.UpdateAnalysisFrameworkResponse, err error) {
	resp = ai_analysis.NewUpdateAnalysisFrameworkResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIAnalysisService.UpdateFramework(ctx, req)
	return
}

func (d *AIAnalysisHandler) CreateSession(ctx context.Context, req *ai_analysis.CreateSessionRequest) (resp *ai_analysis.CreateSessionResponse, err error) {
	resp = ai_analysis.NewCreateSessionResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.SessionId, err = d.AIAnalysisService.CreateSession(ctx, req.ShareSessionId, req.Name, nil)
	return
}

func (d *AIAnalysisHandler) GetSessionList(ctx context.Context, req *ai_analysis.GetSessionListRequest) (resp *ai_analysis.GetSessionListResponse, err error) {
	resp = ai_analysis.NewGetSessionListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AIAnalysisService.GetSessionList(ctx, req)
	return
}

func (d *AIAnalysisHandler) GetSessionInfo(ctx context.Context, req *ai_analysis.GetSessionInfoRequest) (resp *ai_analysis.GetSessionInfoResponse, err error) { // ignore_security_alert
	resp = ai_analysis.NewGetSessionInfoResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AIAnalysisService.GetSessionInfo(ctx, req.SessionId)
	return
}

func (d *AIAnalysisHandler) DeleteSession(ctx context.Context, req *ai_analysis.DeleteSessionRequest) (resp *ai_analysis.DeleteSessionResponse, err error) { // ignore_security_alert
	resp = ai_analysis.NewDeleteSessionResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIAnalysisService.DeleteSession(ctx, req.SessionId)
	return
}

func (d *AIAnalysisHandler) UpdateSessionName(ctx context.Context, req *ai_analysis.UpdateSessionNameRequest) (resp *ai_analysis.UpdateSessionNameResponse, err error) { // ignore_security_alert
	resp = ai_analysis.NewUpdateSessionNameResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIAnalysisService.UpdateSessionName(ctx, req.SessionId, req.Name)
	return
}

func (d *AIAnalysisHandler) GetSessionMessages(ctx context.Context, req *ai_analysis.GetSessionMessagesRequest) (resp *ai_analysis.GetSessionMessagesResponse, err error) {
	resp = ai_analysis.NewGetSessionMessagesResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = &ai_analysis.GetSessionMessagesResponseData{}
	resp.Data.Messages, err = d.AIAnalysisService.GetChatMessages(ctx, req.SessionId, true)
	return
}

func (d *AIAnalysisHandler) Feedback(ctx context.Context, req *ai_analysis.FeedbackRequest) (resp *ai_analysis.FeedbackResponse, err error) {
	resp = ai_analysis.NewFeedbackResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIAnalysisService.CreateFeedback(ctx, req)
	return
}

func (d *AIAnalysisHandler) sendErrorEvent(stream ai_analysis_service.StreamServer, err error) {
	_ = stream.Send(&ai_analysis.AIStreamResponse{
		Event: "error",
		Data:  err.Error(),
	})
}

func (d *AIAnalysisHandler) AnalysisStream(req *ai_analysis.AIAnalysisRequest, stream ai_analysis_service.StreamServer) (err error) {
	ctx := stream.Context()
	commonBaseReq := &ai_analysis_service.CommonBaseStruct{}

	switch req.Type {
	case ai_analysis.AIAnalysisType_ProductAnalysis:
		// 反序列化req.BaseReq
		var baseReq *dimensions.ProductAnalysisBaseStruct
		if err = json.Unmarshal([]byte(req.BaseReq), &baseReq); err != nil || baseReq == nil {
			d.sendErrorEvent(stream, err)
			return
		}

		// 校验baseReq参数是否合法
		var ok bool
		var msg string
		ok, _, msg, ctx = mw.CheckBaseStructStreamParams(ctx, baseReq, &req.EmployeeId)
		if !ok {
			// 参数校验不通过，发送错误事件和消息
			err = errors.New(msg)
			d.sendErrorEvent(stream, err)
			return
		}

		// 拷贝baseReq到commonBaseReq
		err = copier.Copy(commonBaseReq, baseReq)
		if err != nil {
			d.sendErrorEvent(stream, err)
			return
		}
	case ai_analysis.AIAnalysisType_Diagnosis:
		// 反序列化req.BaseReq
		var baseReq *analysis.AttributionCommonBaseStruct
		if err = json.Unmarshal([]byte(req.BaseReq), &baseReq); err != nil || baseReq == nil {
			d.sendErrorEvent(stream, err)
			return
		}

		// 校验baseReq参数是否合法
		var ok bool
		var msg string
		ok, _, msg, ctx = mw.CheckAttributionStreamParams(ctx, baseReq, &req.EmployeeId)
		if !ok {
			// 参数校验不通过，发送错误事件和消息
			err = errors.New(msg)
			d.sendErrorEvent(stream, err)
			return
		}

		// 拷贝baseReq到commonBaseReq
		err = copier.Copy(commonBaseReq, baseReq)
		if err != nil {
			d.sendErrorEvent(stream, err)
			return
		}
	default:
		err = fmt.Errorf("invalid analysis type %v", req.Type)
		d.sendErrorEvent(stream, err)
		return
	}

	err = d.AIAnalysisService.AIAnalysis(ctx, &ai_analysis_service.CommonReq{
		Query:             req.Query,
		EmployeeId:        req.EmployeeId,
		BaseReq:           commonBaseReq,
		BizType:           req.BizType,
		SessionId:         req.SessionId,
		Data:              req.Data,
		CheckpointId:      req.CheckpointId,
		ShareSessionId:    req.ShareSessionId,
		QueryId:           req.QueryId,
		AnalysisFramework: req.AnalysisFramework,
		Files:             req.Files,
	}, &stream)
	if err != nil {
		d.sendErrorEvent(stream, err)
		return
	}

	return
}

// PS: 本地开发调试专用，勿删！！！
func (d *AIAnalysisHandler) Analysis(ctx context.Context, req *ai_analysis.AIAnalysisRequest) (resp *ai_analysis.AIResponse, err error) {
	resp = ai_analysis.NewAIResponse()
	resp.BaseResp = base.NewBaseResp()
	commonBaseReq := &ai_analysis_service.CommonBaseStruct{}

	switch req.Type {
	case ai_analysis.AIAnalysisType_ProductAnalysis:
		var baseReq *dimensions.ProductAnalysisBaseStruct
		if err = json.Unmarshal([]byte(req.BaseReq), &baseReq); err != nil || baseReq == nil {
			return
		}
		// var ok bool
		// var stCode stcodes.StCode
		// var msg string
		// ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, baseReq)
		// if !ok {
		// 	resp.GetBaseResp().SetStatusCode(stCode.Int())
		// 	resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		// 	return
		// }
		err = copier.Copy(commonBaseReq, baseReq)
		if err != nil {
			return
		}
	case ai_analysis.AIAnalysisType_Diagnosis:
		var baseReq *analysis.AttributionCommonBaseStruct
		if err = json.Unmarshal([]byte(req.BaseReq), &baseReq); err != nil || baseReq == nil {
			return
		}
		// var ok bool
		// var stCode stcodes.StCode
		// var msg string
		// ok, stCode, msg, ctx = mw.CheckAttributionStructParams(ctx, baseReq)
		// if !ok {
		// 	resp.GetBaseResp().SetStatusCode(stCode.Int())
		// 	resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		// 	return
		// }
		err = copier.Copy(commonBaseReq, baseReq)
		if err != nil {
			return
		}
	default:
		return nil, fmt.Errorf("invalid analysis type %v", req.Type)
	}

	err = d.AIAnalysisService.AIAnalysis(ctx, &ai_analysis_service.CommonReq{
		Query:             req.Query,
		EmployeeId:        req.EmployeeId,
		BaseReq:           commonBaseReq,
		BizType:           req.BizType,
		SessionId:         req.SessionId,
		Data:              req.Data,
		CheckpointId:      req.CheckpointId,
		ShareSessionId:    req.ShareSessionId,
		QueryId:           req.QueryId,
		AnalysisFramework: req.AnalysisFramework,
		Files:             req.Files,
	}, nil)
	return
}
