package analysis_pool_diagnosis

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_diagnosis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_diagnosis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
)

type AnalysisPoolDiagnosisHandler struct {
	AnalysisPoolDiagnosisService analysis_pool_diagnosis_service.IAnalysisPoolDiagnosisService
}

func (t *AnalysisPoolDiagnosisHandler) HandleGetDiagnosisJudgeConditionList(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisJudgeConditionListReq) (resp *analysis_pool_diagnosis.GetDiagnosisJudgeConditionListResp, err error) {
	resp = &analysis_pool_diagnosis.GetDiagnosisJudgeConditionListResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolDiagnosisService.GetDiagnosisJudgeConditionList(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolDiagnosisHandler) HandleGetDiagnosisIndicatorCategoryJudge(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeReq) (resp *analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeResp, err error) {
	resp = &analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolDiagnosisService.GetDiagnosisIndicatorCategoryJudge(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolDiagnosisHandler) HandleGetDiagnosisFactorList(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisFactorListReq) (resp *analysis_pool_diagnosis.GetDiagnosisFactorListResp, err error) {
	resp = &analysis_pool_diagnosis.GetDiagnosisFactorListResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolDiagnosisService.GetDiagnosisFactorList(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolDiagnosisHandler) HandleQueryDiagnosisProductList(ctx context.Context, req *analysis_pool_diagnosis.QueryDiagnosisProductListReq) (resp *analysis_pool_diagnosis.QueryDiagnosisProductListResp, err error) {
	resp = &analysis_pool_diagnosis.QueryDiagnosisProductListResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolDiagnosisService.QueryDiagnosisProductList(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolDiagnosisHandler) HandleQueryDiagnosisFlowSpaceProductList(ctx context.Context, req *analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListReq) (resp *analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListResp, err error) {
	resp = &analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolDiagnosisService.QueryDiagnosisFlowSpaceProductList(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}
