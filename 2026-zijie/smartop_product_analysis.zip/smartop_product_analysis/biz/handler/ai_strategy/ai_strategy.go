package ai_strategy_handler

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_strategy_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
)

type AIStrategyHandler struct {
	AIStrategyService ai_strategy_service.IAIStrategyService
}

func (d *AIStrategyHandler) AIStrategyGen(ctx context.Context, req *ai_analysis.AIStrategyGenRequest) (resp *ai_analysis.AIResponse, err error) {
	resp = ai_analysis.NewAIResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AIStrategyService.AIStrategyGen(ctx, req)
	return
}

func (d *AIStrategyHandler) FlightAnalysis(ctx context.Context, req *ai_analysis.FlightAnalysisRequest) (resp *ai_analysis.AIResponse, err error) {
	resp = ai_analysis.NewAIResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AIStrategyService.FlightAnalysis(ctx, req)
	return
}

func (d *AIStrategyHandler) CreateStrategy(ctx context.Context, req *ai_analysis.CreateStrategyRequest) (resp *ai_analysis.CreateStrategyResponse, err error) {
	resp = ai_analysis.NewCreateStrategyResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIStrategyService.CreateStrategy(ctx, req)
	return
}

func (d *AIStrategyHandler) UpdateStrategy(ctx context.Context, req *ai_analysis.UpdateStrategyRequest) (resp *ai_analysis.UpdateStrategyResponse, err error) {
	resp = ai_analysis.NewUpdateStrategyResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIStrategyService.UpdateStrategy(ctx, req)
	return
}

func (d *AIStrategyHandler) GetStrategyDetail(ctx context.Context, req *ai_analysis.GetStrategyDetailRequest) (resp *ai_analysis.GetStrategyDetailResponse, err error) {
	resp = ai_analysis.NewGetStrategyDetailResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AIStrategyService.GetStrategyDetail(ctx, req)
	return
}

func (d *AIStrategyHandler) ImportFlightConclusion(ctx context.Context, req *ai_analysis.ImportFlightConclusionRequest) (resp *ai_analysis.ImportFlightConclusionResponse, err error) {
	resp = ai_analysis.NewImportFlightConclusionResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIStrategyService.ImportFlightConclusion(ctx, req)
	return
}

func (d *AIStrategyHandler) CreateStrategyConfig(ctx context.Context, req *ai_analysis.CreateStrategyConfigRequest) (resp *ai_analysis.CreateStrategyConfigResponse, err error) {
	resp = ai_analysis.NewCreateStrategyConfigResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIStrategyService.CreateStrategyConfig(ctx, req)
	return
}

func (d *AIStrategyHandler) CreateStrategyConfigFlightRelation(ctx context.Context, req *ai_analysis.CreateStrategyConfigFlightRelationRequest) (resp *ai_analysis.CreateStrategyConfigFlightRelationResponse, err error) {
	resp = ai_analysis.NewCreateStrategyConfigFlightRelationResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIStrategyService.CreateStrategyConfigFlightRelation(ctx, req)
	return
}

func (d *AIStrategyHandler) RejectStrategyConfig(ctx context.Context, req *ai_analysis.RejectStrategyConfigRequest) (resp *ai_analysis.RejectStrategyConfigResponse, err error) {
	resp = ai_analysis.NewRejectStrategyConfigResponse()
	resp.BaseResp = base.NewBaseResp()
	err = d.AIStrategyService.RejectStrategyConfig(ctx, req)
	return
}
