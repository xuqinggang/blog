package great_value_buy

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/great_value_buy_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/ecom/smartop_product_analysis/mw"

	"context"
)

type GreatValueBuyHandler struct {
	GreatValueBuyService great_value_buy_service.IGreatValueBuyService
}

func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisConfig(ctx context.Context, req *great_value_buy.GetGreatValueBuyDiagnosisConfigDataRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisConfigResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyDiagnosisConfigResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisConfig(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetGreatValueBuyProdSQL(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyProdSQLResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyProdSQLResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyProdSQL(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetGreatValueBuySupplyAnalysis(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuySupplyAnalysisResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuySupplyAnalysisResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = great_value_buy.NewGetGreatValueBuySupplyAnalysisData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuySupplyAnalysis(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetGreatValueBuyAttributionCoreTree(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyAttributionCoreTreeResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyAttributionCoreTreeResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = great_value_buy.NewGetGreatValueBuyAttributionCoreTreeDataList()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyAttributionCoreTree(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisMultiDimension(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisMultiDimensionResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyDiagnosisMultiDimensionResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = great_value_buy.NewGetGreatValueBuyDiagnosisMultiDimensionData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisMultiDimension(ctx, req)
	return resp, err
}
func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisCommonCoreOverview(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisCommonCoreOverviewResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyDiagnosisCommonCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = great_value_buy.NewGetGreatValueBuyDiagnosisCommonCoreOverviewData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisCommonCoreOverview(ctx, req)
	return resp, err
}
func (d *GreatValueBuyHandler) GetGreatValueBuyMultiDimensionTable(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyMultiDimensionResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyMultiDimensionResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = great_value_buy.NewGetGreatValueBuyMultiDimensionData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyMultiDimensionTable(ctx, req)
	return resp, err
}
func (d *GreatValueBuyHandler) GetGreatValueBuyMultiDimensionTableDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyMultiDimensionTableDownload(ctx, req)
	return resp, err
}
func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisProductList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductListResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyDiagnosisProductListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = great_value_buy.NewGetGreatValueBuyDiagnosisProductData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisProductList(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisProductListTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductListTrendResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyDiagnosisProductListTrendResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = great_value_buy.NewGetGreatValueBuyDiagnosisProductListTrendData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisProductListTrend(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisProductListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisProductListDownload(ctx, req)
	return resp, err
}

func (d GreatValueBuyHandler) GetGreatValueBuyMultiDimTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyMultiDimTrendResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyMultiDimTrendResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyMultiDimTrend(ctx, req)
	return resp, err
}

func (d GreatValueBuyHandler) GetGreatValueBuyDiagnosisQueryList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQueryAnalysisResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyQueryAnalysisResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisQueryList(ctx, req)
	return resp, err
}

func (d GreatValueBuyHandler) GetGreatValueBuyDiagnosisQuerySearchWords(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQuerySearchWordsResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyQuerySearchWordsResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisQuerySearchWords(ctx, req)
	return resp, err
}

func (d GreatValueBuyHandler) GetGreatValueBuyDiagnosisQueryProdList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQueryProdAnalysisResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyQueryProdAnalysisResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisQueryProdList(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisQueryListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisQueryListDownload(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisQueryProdListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = analysis.NewGetProductAnalysisDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisQueryProdListDownload(ctx, req)
	return resp, err
}

// GetGreatValueBuyDiagnosisQuerySearchCntTrend
func (d *GreatValueBuyHandler) GetGreatValueBuyDiagnosisQuerySearchCntTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisQuerySearchCntTrendResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyDiagnosisQuerySearchCntTrendResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyDiagnosisQuerySearchCntTrend(ctx, req)
	return resp, err
}

// GetGreatValueBuyCommonDiagnosisConclusion
func (d *GreatValueBuyHandler) GetGreatValueBuyCommonDiagnosisConclusion(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyCommonConclusionResponse, err error) {
	resp = great_value_buy.NewGetGreatValueBuyCommonConclusionResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetGreatValueBuyCommonDiagnosisConclusion(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) GetOptimizeActionInfo(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetOptimizeActionInfoResponse, err error) {
	resp = great_value_buy.NewGetOptimizeActionInfoResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.GreatValueBuyService.GetOptimizeActionInfo(ctx, req)
	return resp, err
}

func (d *GreatValueBuyHandler) SendAttributionReport(ctx context.Context, req *great_value_buy.SendAttributionReportRequest) (resp *great_value_buy.SendAttributionReportResponse, err error) {
	resp = great_value_buy.NewSendAttributionReportResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.OriginReq.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	err = d.GreatValueBuyService.SendAttributionReport(ctx, req)
	return resp, err
}
