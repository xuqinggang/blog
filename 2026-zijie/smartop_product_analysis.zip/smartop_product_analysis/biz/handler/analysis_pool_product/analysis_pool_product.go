package analysis_pool_product

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_product_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_product"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
)

// AnalysisPoolProductHandler 分析池商品处理器
type AnalysisPoolProductHandler struct {
	AnalysisPoolProductService analysis_pool_product_service.IAnalysisPoolProductService
}

func (t *AnalysisPoolProductHandler) HandleGetAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.GetAnalysisPoolProductListReq) (resp *analysis_pool_product.GetAnalysisPoolProductListResp, err error) {
	resp = &analysis_pool_product.GetAnalysisPoolProductListResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolProductService.GetAnalysisPoolProductList(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolProductHandler) HandleQueryAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.QueryAnalysisPoolProductListReq) (resp *analysis_pool_product.QueryAnalysisPoolProductListResp, err error) {
	resp = &analysis_pool_product.QueryAnalysisPoolProductListResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolProductService.QueryAnalysisPoolProductList(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolProductHandler) HandleGetPoolProductTrend(ctx context.Context, req *analysis_pool_product.GetPoolProductTrendReq) (resp *analysis_pool_product.GetPoolProductTrendResp, err error) {
	resp = &analysis_pool_product.GetPoolProductTrendResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolProductService.GetPoolProductTrend(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolProductHandler) HandleGetDataAvailableDateRange(ctx context.Context, req *analysis_pool_product.GetDataAvailableDateRangeReq) (resp *analysis_pool_product.GetDataAvailableDateRangeResp, err error) {
	resp = &analysis_pool_product.GetDataAvailableDateRangeResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolProductService.GetDataAvailableDateRange(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolProductHandler) HandleOpAnalysisPoolProduct(ctx context.Context, req *analysis_pool_product.OpAnalysisPoolProductReq) (resp *analysis_pool_product.OpAnalysisPoolProductResp, err error) {
	resp = &analysis_pool_product.OpAnalysisPoolProductResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.IsOk, err = t.AnalysisPoolProductService.OpAnalysisPoolProduct(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolProductHandler) HandleGetProductMultiDim(ctx context.Context, req *analysis_pool_product.GetProductMultiDimReq) (resp *analysis_pool_product.GetProductMultiDimResp, err error) {
	resp = &analysis_pool_product.GetProductMultiDimResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.DimListData, resp.ProductData, err = t.AnalysisPoolProductService.GetProductMultiDim(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolProductHandler) HandleDownloadProductMultiDim(ctx context.Context, req *analysis_pool_product.DownloadProductMultiDimReq) (resp *analysis_pool_product.DownloadProductMultiDimResp, err error) {
	resp = &analysis_pool_product.DownloadProductMultiDimResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.IsOk, err = t.AnalysisPoolProductService.DownloadProductMultiDim(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolProductHandler) HandleDownloadAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.DownloadAnalysisPoolProductListReq) (*analysis_pool_product.DownloadAnalysisPoolProductListResp, error) {
	resp := &analysis_pool_product.DownloadAnalysisPoolProductListResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.IsOk = true

	// 调用service层，获取TOS链接（不再直接返回CSV内容）
	isOK, err := t.AnalysisPoolProductService.DownloadAnalysisPoolProductList(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.IsOk = false
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
		return resp, err
	}
	resp.IsOk = isOK

	return resp, nil
}
