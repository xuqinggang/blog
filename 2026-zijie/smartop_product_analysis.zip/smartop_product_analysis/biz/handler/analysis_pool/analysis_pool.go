package analysis_pool

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dorado_task"
)

type AnalysisPoolHandler struct {
	AnalysisPoolService analysis_pool_service.IAnalysisPoolService
}

func (t *AnalysisPoolHandler) HandleCreateAnalysisPool(ctx context.Context, req *analysis_pool.CreateAnalysisPoolReq) (resp *analysis_pool.CreateAnalysisPoolResp, err error) {
	resp = &analysis_pool.CreateAnalysisPoolResp{}
	resp.BaseResp = base.NewBaseResp()

	// 创建规则货盘时，需要检验一下结构体是否合规，同时把维度信息写入ctx
	if req.BaseStruct != nil {
		ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
		if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseStruct); !ok {
			resp.GetBaseResp().SetStatusCode(stCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
			return resp, nil
		}
	}

	resp.Data, err = t.AnalysisPoolService.CreateAnalysisPool(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolHandler) HandleUpdateAnalysisPool(ctx context.Context, req *analysis_pool.UpdateAnalysisPoolReq) (resp *analysis_pool.UpdateAnalysisPoolResp, err error) {
	resp = &analysis_pool.UpdateAnalysisPoolResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.AnalysisPoolId, err = t.AnalysisPoolService.UpdateAnalysisPool(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolHandler) HandleDeleteAnalysisPool(ctx context.Context, req *analysis_pool.DeleteAnalysisPoolReq) (resp *analysis_pool.DeleteAnalysisPoolResp, err error) {
	resp = &analysis_pool.DeleteAnalysisPoolResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolService.DeleteAnalysisPool(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolHandler) HandleQueryAnalysisPoolList(ctx context.Context, req *analysis_pool.QueryAnalysisPoolListReq) (resp *analysis_pool.QueryAnalysisPoolListResp, err error) {
	resp = &analysis_pool.QueryAnalysisPoolListResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolService.QueryAnalysisPoolList(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolHandler) HandleQueryAnalysisPoolDetail(ctx context.Context, req *analysis_pool.QueryAnalysisPoolDetailReq) (resp *analysis_pool.QueryAnalysisPoolDetailResp, err error) {
	resp = &analysis_pool.QueryAnalysisPoolDetailResp{}
	resp.BaseResp = base.NewBaseResp()

	// 创建规则货盘时，需要检验一下结构体是否合规，同时把维度信息写入ctx
	if req.BaseStruct != nil {
		ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
		if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseStruct); !ok {
			resp.GetBaseResp().SetStatusCode(stCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
			return resp, nil
		}
	}

	resp.Data, err = t.AnalysisPoolService.QueryAnalysisPoolDetail(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolHandler) HandleCreateAnalysisPoolApplicationRecord(ctx context.Context, req *analysis_pool.CreateAnalysisPoolApplicationRecordReq) (resp *analysis_pool.CreateAnalysisPoolApplicationRecordResp, err error) {
	resp = &analysis_pool.CreateAnalysisPoolApplicationRecordResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AnalysisPoolService.CreateAnalysisPoolApplicationRecord(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}

func (t *AnalysisPoolHandler) HandleGetDoradoAnalysisPoolApplicationHiveCallBack(ctx context.Context, req *dorado_task.GetDoradoTaskRunningCallBackRequest) (resp *dorado_task.GetDoradoTaskRunningCallBackResponse, err error) {

	logs.CtxInfo(ctx, "[HandleGetDoradoAnalysisPoolApplicationHiveCallBack]req = %s", convert.ToString(req))
	resp = &dorado_task.GetDoradoTaskRunningCallBackResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	err = t.AnalysisPoolService.GetDoradoAnalysisPoolApplicationHiveCallBack(ctx, req)
	return resp, err
}
