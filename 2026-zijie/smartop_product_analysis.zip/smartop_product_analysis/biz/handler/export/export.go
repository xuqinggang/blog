package export

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/export_data"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
	"strings"
)

type ExportHandler struct {
	ExportService export_data.IExportService
}

func (e *ExportHandler) HandleGetProductAnalysisCoreOverviewDownload(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetProductAnalysisCoreOverviewDownload(ctx, req.BaseReq)
	return
}

func (e *ExportHandler) HandleGetProductAnalysisMultiDimProductListDownload(ctx context.Context, req *analysis.GetProductAnalysisMultiDimProductListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetProductAnalysisMultiDimProductListDownload(ctx, req)
	return
}

func (e *ExportHandler) HandleGetProductAnalysisMultiDimListDownload(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetProductAnalysisMultiDimDownload(ctx, req.BaseReq)
	if err != nil && strings.Contains(err.Error(), "MAX_10000_LIMIT_ERROR") {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage("您的分析结果数据超过了10000条的上限，不支持导出，请减少分析维度枚举数量后再导出～")
		return resp, nil
	}
	return
}

func (e *ExportHandler) HandleGetPriceAACoreOverviewDownload(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetPriceAACoreOverviewDownload(ctx, req.BaseReq)
	return
}

func (e *ExportHandler) HandleGetPriceAABizIncomeTargetCardDownload(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetPriceAABizIncomeTargetCardDownload(ctx, req)
	return
}

func (e *ExportHandler) HandleGetMultipleRatioTableDownload(ctx context.Context, req *analysis.GetMultipleRatioTableRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetMultipleRatioTableDownload(ctx, req)
	return
}

func (e *ExportHandler) HandleGetOrderResponsibilityCoreOverviewDownload(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetOrderResponsibilityCoreOverviewDownload(ctx, req)
	return
}

func (e *ExportHandler) HandleGetOrderResponsibilityTargetListDownload(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetOrderResponsibilityTargetListDownload(ctx, req)
	return
}

func (e *ExportHandler) HandleGetOrderResponsibilityIndustryListDownload(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetOrderResponsibilityIndustryListDownload(ctx, req)
	return
}

func (e *ExportHandler) HandleGetPordDetailListDownload(ctx context.Context, req *analysis.GetPordDetailListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp = &analysis.GetProductAnalysisDownloadResponse{}
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckProdPortraitBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = e.ExportService.GetPordDetailListDownload(ctx, req)
	return
}
