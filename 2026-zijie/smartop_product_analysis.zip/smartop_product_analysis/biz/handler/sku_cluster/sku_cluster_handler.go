package sku_cluster_handler

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/sku_cluster_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
)

type SkuClusterHandler struct {
	SkuClusterService sku_cluster_service.ISkuClusterService
}

func (s *SkuClusterHandler) GetSkuClusterCommonMultiDimFullList(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (
	resp *sku_cluster.GetSkuClusterCommonMultiDimFullListResponse, err error) {
	resp = sku_cluster.NewGetSkuClusterCommonMultiDimFullListResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = sku_cluster.NewGetSkuClusterCommonMultiDimData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = s.SkuClusterService.GetSkuClusterCommonMultiDimFullList(ctx, req)
	return resp, err
}

func (s *SkuClusterHandler) GetSkuClusterCommonMultiDimTrend(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (
	resp *analysis.GetProductAnalysisMultiDimTrendResponse, err error) {
	resp = analysis.NewGetProductAnalysisMultiDimTrendResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = analysis.NewGetProductAnalysisMultiDimTrendData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = s.SkuClusterService.GetSkuClusterCommonMultiDimTrend(ctx, req)
	return resp, err
}

func (s *SkuClusterHandler) GetSkuClusterCommonMultiDimFullListDownload(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (
	resp *sku_cluster.GetSkuClusterCommonMultiDimFullListDownloadResponse, err error) {
	resp = sku_cluster.NewGetSkuClusterCommonMultiDimFullListDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = s.SkuClusterService.GetSkuClusterCommonMultiDimFullListDownload(ctx, req)
	return resp, nil
}

func (s *SkuClusterHandler) GetSkuClusterCommonCoreOverview(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (
	resp *sku_cluster.GetSkuClusterCommonCoreOverviewResponse, err error) {
	resp = sku_cluster.NewGetSkuClusterCommonCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = sku_cluster.NewGetSkuClusterCommonCoreOverviewData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = s.SkuClusterService.GetSkuClusterCommonCoreOverview(ctx, req)
	return resp, nil
}

func (s *SkuClusterHandler) GetSkuClusterFlowTrend(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (
	resp *sku_cluster.GetSkuClusterFlowTrendResponse, err error) {
	resp = sku_cluster.NewGetSkuClusterFlowTrendResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = sku_cluster.NewGetSkuClusterFlowTrendData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = s.SkuClusterService.GetSkuClusterFlowTrend(ctx, req)
	return resp, nil
}

func (s *SkuClusterHandler) GetSkuClusterStabilityMultiDimFullList(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (
	resp *sku_cluster.GetSkuClusterStabilityResponse, err error) {
	resp = sku_cluster.NewGetSkuClusterStabilityResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = sku_cluster.NewGetSkuClusterStabilityData()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = s.SkuClusterService.GetSkuClusterStabilityMultiDimFullList(ctx, req)
	return resp, err
}

func (s *SkuClusterHandler) GetSkuClusterStabilityMultiDimFullListDownload(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (
	resp *sku_cluster.GetSkuClusterCommonMultiDimFullListDownloadResponse, err error) {
	resp = sku_cluster.NewGetSkuClusterCommonMultiDimFullListDownloadResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = s.SkuClusterService.GetSkuClusterStabilityMultiDimFullListDownload(ctx, req)
	return resp, nil
}
