package alert

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/alert_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	alert_rule "code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_alert_rule"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/gogo/protobuf/proto"
	"github.com/jinzhu/copier"
)

type AlertHandler struct {
	AlertService alert_service.IAlertService
}

// 新增预警规则
func (d *AlertHandler) HandleAddRule(ctx context.Context, req *alert_rule.CreateAnalysisPoolAlertRuleReq) (resp *alert_rule.CreateAnalysisPoolAlertRuleResp, err error) {
	resp = &alert_rule.CreateAnalysisPoolAlertRuleResp{}
	data := &alert_rule.CreateAnalysisPoolAlertRuleData{}
	resp.Data = data
	resp.SetBaseResp(base.NewBaseResp())

	user := utils.GetUserInfo(ctx)

	if user == nil {
		// 获取用户信息失败
		err = errors.New("[User] Can not get user info")
		logs.CtxError(ctx, err.Error())

		resp.GetBaseResp().SetStatusCode(stcodes.StatusUserInfoError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusUserInfoError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	}

	ruleId, err := d.AlertService.AddAlertRule(ctx, req, user)
	if ruleId == "" || err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())

		if err != nil {
			resp.GetBaseResp().SetExtra(map[string]string{
				"error": err.Error(),
			})
		}

		return resp, err
	}

	data.RuleId = &ruleId

	resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeSuccess.Int())
	resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeSuccess.String())

	return resp, nil
}

// 根据货盘查询预警规则列表
func (d *AlertHandler) HandleQueryRuleByPool(ctx context.Context, req *alert_rule.QueryAnalysisPoolAlertRuleListReq) (resp *alert_rule.QueryAnalysisPoolAlertRuleListResp, err error) {
	resp = &alert_rule.QueryAnalysisPoolAlertRuleListResp{}
	resp.SetBaseResp(base.NewBaseResp())

	var rule *alert_rule.QueryAnalysisPoolAlertRuleListData

	if req.IsSetPoolId() && len(req.GetPoolId()) > 0 {
		rule, err = d.AlertService.QueryAlertRulesByPool(ctx, req)
	} else {
		rule, err = d.AlertService.QueryAlertRules(ctx, req)
	}

	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	}
	resp.Data = rule

	resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeSuccess.Int())
	resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeSuccess.String())

	return resp, nil
}

// 查询单个预警规则
func (d *AlertHandler) HandleGetAlertRuleDetail(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertRuleDetailReq) (resp *alert_rule.GetAnalysisPoolAlertRuleDetailResp, err error) {
	resp = &alert_rule.GetAnalysisPoolAlertRuleDetailResp{}
	resp.SetBaseResp(base.NewBaseResp())

	data, err := d.AlertService.GetAlertRuleDetail(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	}

	resp.Data = data
	resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeSuccess.Int())
	resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeSuccess.String())

	return resp, nil
}

// 获取预警维度列表
func (d *AlertHandler) HandleGetAlertDimensions(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertDimensionsReq) (resp *alert_rule.GetAnalysisPoolAlertDimensionsResp, err error) {
	resp = &alert_rule.GetAnalysisPoolAlertDimensionsResp{}
	data := &alert_rule.GetAnalysisPoolAlertDimensionsData{}
	resp.Data = data
	resp.SetBaseResp(base.NewBaseResp())

	dimensions, err := d.AlertService.GetAlertDimensions(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	}

	respDimensions := make([]*alert_rule.SelectValue, 0)
	copier.Copy(&respDimensions, &dimensions)
	data.Dimensions = respDimensions
	resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeSuccess.Int())
	resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeSuccess.String())

	return resp, nil
}

// 查询数据源列表
func (d *AlertHandler) HandleListAlertEventType(ctx context.Context, req *alert_rule.LisAnalysisPoolEventTypeReq) (resp *alert_rule.LisAnalysisPoolEventTypeResp, err error) {
	resp = &alert_rule.LisAnalysisPoolEventTypeResp{}
	data := &alert_rule.LisAnalysisPoolEventTypeData{}
	resp.Data = data
	resp.SetBaseResp(base.NewBaseResp())

	items, err := d.AlertService.ListAlertEventType(ctx)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	}

	respItems := make([]*alert_rule.AlertEventTypeItem, 0)
	copier.Copy(&respItems, &items)
	data.Items = respItems
	resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeSuccess.Int())
	resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeSuccess.String())

	return resp, nil
}

// 获取数据指标列表
func (d *AlertHandler) HandleGetAlertIndicators(ctx context.Context, req *alert_rule.GetAnalysisPoolAlertIndicatorsReq) (resp *alert_rule.GetAnalysisPoolAlertIndicatorsResp, err error) {
	resp = &alert_rule.GetAnalysisPoolAlertIndicatorsResp{}
	data := &alert_rule.GetAnalysisPoolAlertIndicatorsData{}
	resp.Data = data
	resp.SetBaseResp(base.NewBaseResp())

	indicators, err := d.AlertService.GetAlertIndicators(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	}

	respIndicators := make([]*alert_rule.ArcticAlertIndicator, 0)
	copier.Copy(&respIndicators, &indicators)
	data.Indicators = respIndicators
	resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeSuccess.Int())
	resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeSuccess.String())

	return resp, nil
}

// 查询所有存在商品状态异常的规则
func (d *AlertHandler) HandleGetRulesWitExceptionProdStatusInfos(ctx context.Context, req *alert_rule.GetRulesWitExceptionProdStatusInfosReq) (resp *alert_rule.GetRulesWitExceptionProdStatusInfosResp, err error) {
	resp = &alert_rule.GetRulesWitExceptionProdStatusInfosResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.AlertService.GetRulesWitExceptionProdStatusInfos(ctx, req)
	return
}

// 删除监控任务
func (d *AlertHandler) DeleteAlertRule(ctx context.Context, req *alert_rule.DeleteAlertRuleReq) (resp *alert_rule.DeleteAlertRuleResp, err error) {
	resp = &alert_rule.DeleteAlertRuleResp{}
	resp.SetBaseResp(base.NewBaseResp())

	_, err = d.AlertService.DeleteAlertRule(ctx, req.RuleId)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	}

	return resp, nil
}

func (t *AlertHandler) HandleUpdateAnalysisPoolAlertRule(ctx context.Context, req *alert_rule.UpdateAnalysisPoolAlertRuleReq) (resp *alert_rule.UpdateAnalysisPoolAlertRuleResp, err error) {
	resp = &alert_rule.UpdateAnalysisPoolAlertRuleResp{}
	resp.BaseResp = base.NewBaseResp()
	ruleResp, ruleErr := t.AlertService.UpdateAnalysisPoolAlertRule(ctx, req)
	if ruleErr != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	} else {
		if ruleResp.AccessDeny {
			resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
			resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
			resp.GetBaseResp().SetExtra(map[string]string{
				"error": "没有操作权限",
			})
		}
	}
	return resp, nil
}

func (t *AlertHandler) HandleUpdateAnalysisPoolAlertRuleStatus(ctx context.Context, req *alert_rule.UpdateAnalysisPoolAlertRuleStatusReq) (resp *alert_rule.UpdateAnalysisPoolAlertRuleStatusResp, err error) {
	resp = &alert_rule.UpdateAnalysisPoolAlertRuleStatusResp{}
	resp.BaseResp = base.NewBaseResp()
	ruleResp, ruleErr := t.AlertService.UpdateAnalysisPoolAlertRuleStatus(ctx, req)
	if ruleErr != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})

		return resp, err
	} else {
		if ruleResp.AccessDeny {
			resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
			resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
			resp.GetBaseResp().SetExtra(map[string]string{
				"error": "没有操作权限",
			})
		}
	}
	return resp, nil
}

func (t *AlertHandler) HandleConvertToAlertRule(ctx context.Context, req *alert_rule.ConvertToAlertRuleReq) (resp *alert_rule.ConvertToAlertRuleResp, err error) {
	resp = &alert_rule.ConvertToAlertRuleResp{}
	resp.BaseResp = base.NewBaseResp()

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	eventType := bizInfo.TableName

	arcticReq := &alert_rule.GetAnalysisPoolAlertDimensionsReq{
		EventType: proto.String(eventType),
	}
	arcticDimensions, arcticErr := t.AlertService.GetAlertDimensions(ctx, arcticReq)
	var arcticFields []string
	if arcticErr != nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": arcticErr.Error(),
		})
	} else {
		if len(arcticDimensions) == 0 {
			return resp, nil
		}
		for _, dimension := range arcticDimensions {
			if dimension == nil || len(dimension.Value) == 0 {
				continue
			}
			arcticFields = append(arcticFields, dimension.Value)
		}
	}

	condition, convertResult, err := t.AlertService.AnalysisRuleConvertToAlertRule(ctx, req, arcticFields)

	if err != nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeDefaultError.String())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": arcticErr.Error(),
		})
	} else if !convertResult {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusUnSupportedAlertFields.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusUnSupportedAlertFields.String())
	} else {
		resp.Data = condition
	}

	return resp, err
}

func (t *AlertHandler) HandleGetAlertProdStatusRuleIndicator(ctx context.Context, req *alert_rule.GetAlertProdStatusRuleIndicatorReq) (resp *alert_rule.GetAlertProdStatusRuleIndicatorResp, err error) {
	resp = &alert_rule.GetAlertProdStatusRuleIndicatorResp{}
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = t.AlertService.GetAlertProdStatusRuleIndicator(ctx, req)
	if err != nil {
		// 服务调用失败
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeDefaultError.Int())
		resp.GetBaseResp().SetStatusMessage(err.Error())
		resp.GetBaseResp().SetExtra(map[string]string{
			"error": err.Error(),
		})
	}
	return
}
