package price_aa_analysis

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_aa_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
)

type AnalysisAAHandler struct {
	PriceAAService price_aa_service.IPriceAAService
}

func (d *AnalysisAAHandler) GetPriceAACoreOverview(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp = analysis.NewGetPriceInsightCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.PriceAAService.GetPriceAACoreOverview(ctx, req.BaseReq, consts.Empty)
	return
}

func (d *AnalysisAAHandler) GetPriceAAFlowStandardCoreOverview(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp = analysis.NewGetPriceInsightCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.PriceAAService.GetPriceAAFlowStandardCoreOverview(ctx, req.BaseReq, consts.Empty)
	return
}

func (d *AnalysisAAHandler) GetPriceAAFlowDiffStandardCard(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp = analysis.NewGetPriceInsightCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	if len(req.BaseReq.Dimensions) == 0 {
		req.BaseReq.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, req.Dimensions...)
	resp.Data, err = d.PriceAAService.GetPriceAAFlowStandardCoreOverview(ctx, req.BaseReq, req.Channel)
	return
}

func (d *AnalysisAAHandler) GetPriceAAMarketCoreOverview(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp = analysis.NewGetPriceInsightCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.PriceAAService.GetPriceAAMarketCoreOverview(ctx, req.BaseReq)
	return
}

func (d *AnalysisAAHandler) GetPriceAABizIncomeTrend(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetPriceAABizIncomeTrendResponse, err error) {
	resp = analysis.NewGetPriceAABizIncomeTrendResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.PriceAAService.GetPriceAABizIncomeTrend(ctx, req)
	return
}

func (d *AnalysisAAHandler) GetPriceAABizIncomeTargetCard(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp = analysis.NewGetPriceInsightCoreOverviewResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	if len(req.BaseReq.Dimensions) == 0 {
		req.BaseReq.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
	}
	req.BaseReq.Dimensions = append(req.BaseReq.Dimensions, req.Dimensions...)

	resp.Data, err = d.PriceAAService.GetPriceAACoreOverview(ctx, req.BaseReq, req.Channel)
	return
}

func (d *AnalysisAAHandler) GetPriceAABizIncomeDiffDistributed(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetPriceAAMultiPieChartResponse, err error) {
	resp = analysis.NewGetPriceAAMultiPieChartResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.PriceAAService.GetPriceAABizIncomeDiffDistributed(ctx, req)
	return
}

func (d *AnalysisAAHandler) GetPriceAASupplyCntList(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceAASupplyCntListResponse, err error) {
	resp = analysis.NewGetPriceAASupplyCntListResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.PriceAAService.GetPriceAASupplyCntList(ctx, req.BaseReq)
	return
}

func (d *AnalysisAAHandler) GetPriceAASupplyDistributed(ctx context.Context, req *analysis.GetPriceAASupplyDistributedRequest) (resp *analysis.GetPriceAASupplyCntListResponse, err error) {
	resp = analysis.NewGetPriceAASupplyCntListResponse()
	resp.BaseResp = base.NewBaseResp()
	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckPriceBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}
	resp.Data, err = d.PriceAAService.GetPriceAASupplyDistributed(ctx, req)
	return
}