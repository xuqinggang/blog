package dimension

import (
	need_dump_dimension_service "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/need_dump_dimension_domain/service"
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/cronjob"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/dynamic_enum"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
)

type DimensionHandler struct {
	DimensionService         dimension_service.IDimensionService
	NeedDumpDimensionService need_dump_dimension_service.NeedDumpDimensionService
}

func (d *DimensionHandler) HandlerGetDimensionList(ctx context.Context, req *dimensions.GetDimensionListRequest) (resp *dimensions.GetDimensionListResponse, err error) {
	resp = &dimensions.GetDimensionListResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	resp.Data = &dimensions.GetDimensionListData{
		UserDimensions:    make([]*dimensions.DimensionInfo, 0),
		ProductDimensions: make([]*dimensions.DimensionInfo, 0),
		PlaceDimensions:   make([]*dimensions.DimensionInfo, 0),
		DefaultGroupAttrs: make([]*dimensions.SelectedMultiDimensionInfo, 0),
	}

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeParamError.String())
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return resp, err
	}
	resp.Data.ThresholdAttrMeta = bizInfo.ThresholdAttrMeta
	if len(resp.Data.ThresholdAttrMeta) > 0 {
		for _, t := range resp.Data.ThresholdAttrMeta {
			if t.Type == dimensions.ThresholdType_BIGSALE_HOT_SCORE_THRESHOLD && len(t.ValueList) == 0 {
				// 获取大促爆发分动态枚举
				enumData, err := dynamic_enum.GetOsTableList(ctx, consts.LogicTableBigSaleHotScoreTable, "7444433573609800731", nil, nil)
				if err != nil {
					return resp, err
				}
				if len(enumData) > 0 {
					t.ValueList = make([]*dimensions.TargetElementValue, 0)
					for _, enum := range enumData {
						t.ValueList = append(t.ValueList, &dimensions.TargetElementValue{
							Id:   enum.Code,
							Name: enum.Name,
						})
					}
				}
			}
		}
	}

	for _, group := range bizInfo.DefaultGroupAttrs {
		if len(group.SelectedValues) == 0 {
			groupDim, err := d.DimensionService.GetDimensionByID(ctx, convert.ToInt64(group.Id))
			if err != nil {
				return nil, err
			}
			if groupDim != nil {
				group.SelectedValues = make([]*dimensions.EnumElement, 0)
				for i, v := range groupDim.Values {
					if i >= biz_info.GetMultiDimEnumMaxNum(ctx) {
						break
					}
					group.SelectedValues = append(group.SelectedValues, v)
				}
			}
		}
		resp.Data.DefaultGroupAttrs = append(resp.Data.DefaultGroupAttrs, &dimensions.SelectedMultiDimensionInfo{
			DimInfo: group,
		})
	}

	// 补充维度列表
	dimList, err := d.DimensionService.GetDimensionList(ctx, req.BizType)
	if err != nil {
		return resp, err
	}

	//// 剔除不展示的规则
	//newDimList := make([]*dimensions.DimensionInfo, 0)
	//for _, dimInfo := range dimList {
	//	if dimInfo == nil {
	//		continue
	//	}
	//	if consts.NoShowDimMap[dimInfo.Id] {
	//		continue
	//	}
	//	newDimList = append(newDimList, dimInfo)
	//}
	//dimList = newDimList

	if len(dimList) > 0 {
		for _, dim := range dimList {
			switch dim.DimensionCategory {
			case dimensions.DimensionAttributeType_User:
				resp.Data.UserDimensions = append(resp.Data.UserDimensions, dim)
			case dimensions.DimensionAttributeType_Product:
				resp.Data.ProductDimensions = append(resp.Data.ProductDimensions, dim)
			case dimensions.DimensionAttributeType_Place:
				resp.Data.PlaceDimensions = append(resp.Data.PlaceDimensions, dim)
			case dimensions.DimensionAttributeType_Order:
				resp.Data.OrderDimensions = append(resp.Data.OrderDimensions, dim)
			default:
				return
			}
		}
	}

	return resp, nil
}

func (d *DimensionHandler) GenerateDimensionWithNlp(ctx context.Context, req *dimensions.GenerateDimensionWithNlpRequest) (resp *dimensions.GenerateDimensionWithNlpResponse, err error) {
	resp = dimensions.NewGenerateDimensionWithNlpResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data, err = d.DimensionService.GenerateDimensionWithNlp(ctx, req)
	return
}

func (d *DimensionHandler) GetReadyTime(ctx context.Context, req *dimensions.GetDataReadyTimeRequest) (resp *dimensions.GetDataReadyTimeResponse, err error) {
	resp = &dimensions.GetDataReadyTimeResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	resp.Data, err = d.DimensionService.GetReadyTime(ctx, req.BizType)
	return
}

func (d *DimensionHandler) GetDimensionPageEnumList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) (resp *dimensions.GetDimensionPageEnumListResponse, err error) {
	resp = &dimensions.GetDimensionPageEnumListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	// 补充维度列表
	data, err := d.DimensionService.GetDimensionPageEnumList(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) GetPriceHybridTagEnumList(ctx context.Context, req *dimensions.GetPriceHybridTagEnumListRequest) (resp *dimensions.GetPriceHybridTagEnumListResponse, err error) {
	resp = &dimensions.GetPriceHybridTagEnumListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	// 补充维度列表
	data, err := d.DimensionService.GetPriceHybridTagEnumList(ctx, req.BizType)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) GetProductAnalysisBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp = &dimensions.GetProductAnalysisBizListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	// 补充维度列表
	data, err := d.DimensionService.GetProductAnalysisBizList(ctx, "商品分析")
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) GetProductAnalysisTargetMetaList(ctx context.Context, req *dimensions.GetProductAnalysisTargetMetaListRequest) (resp *dimensions.GetProductAnalysisTargetMetaListResponse, err error) {
	resp = &dimensions.GetProductAnalysisTargetMetaListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	// 补充维度列表
	data, err := d.DimensionService.GetProductAnalysisTargetMetaList(ctx, req.BizType, false)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) UpdatePoolStatus(ctx context.Context, req *dimensions.UpdatePoolStatusRequest) (resp *dimensions.UpdatePoolStatusResponse, err error) {
	resp = &dimensions.UpdatePoolStatusResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	// 补充维度列表
	err = cronjob.StartPoolSyncExecute(ctx)
	if err != nil {
		return resp, err
	}
	return resp, nil
}

func (d *DimensionHandler) GetAttributionTreeBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp = &dimensions.GetProductAnalysisBizListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	data, err := d.DimensionService.GetAttributionTreeBizList(ctx, "异动归因")
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) GetGuessDressBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp = &dimensions.GetProductAnalysisBizListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	// 补充维度列表
	data, err := d.DimensionService.GetProductAnalysisBizList(ctx, "猜喜")
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) GetGreatValueBuyBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp = &dimensions.GetProductAnalysisBizListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	// 补充维度列表
	data, err := d.DimensionService.GetProductAnalysisBizList(ctx, "超值购专项")
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) GetGuessAttributionBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp = &dimensions.GetProductAnalysisBizListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	// 补充维度列表
	data, err := d.DimensionService.GetProductAnalysisBizList(ctx, "猜喜异动归因")
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) GetDiagnosisBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp = &dimensions.GetProductAnalysisBizListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	effectModule := "异动归因"
	switch req.BizModule {
	case dimensions.BizModule_AbnormalAttribution:
		effectModule = "异动归因"
	case dimensions.BizModule_Guess:
		effectModule = "猜喜异动归因"
	case dimensions.BizModule_GreatValueBuy:
		effectModule = "超值购专项"
	case dimensions.BizModule_BigActivity:
		effectModule = "大促视图"
	case dimensions.BizModule_ProdPoolReview:
		effectModule = "货盘复盘"
	case dimensions.BizModule_ProdPoolReviewGreatValueBuy:
		effectModule = "货盘复盘-超值购"
	case dimensions.BizModule_ProdPoolReviewMarket:
		effectModule = "货盘复盘-商城加补"
	case dimensions.BizModule_ProdPoolReviewCore:
		effectModule = "货盘复盘-大盘"
	case dimensions.BizModule_ProdPoolReviewBigPromotion:
		effectModule = "货盘复盘-大促"
	case dimensions.BizModule_ProdPoolReviewSeckill:
		effectModule = "货盘复盘-秒杀"
	case dimensions.BizModule_ProdPoolReviewGovSubsidy:
		effectModule = "货盘复盘-政府补贴"
	case dimensions.BizModule_ProdPoolReviewGuess:
		effectModule = "货盘复盘-猜喜"
	case dimensions.BizModule_ProdPoolReviewSearch:
		effectModule = "货盘复盘-搜索"
	case dimensions.BizModule_GuessAbnormalAttribution:
		effectModule = "猜喜诊断归因"
	case dimensions.BizModule_MarketingEngine:
		effectModule = "外嵌营销引擎"
	case dimensions.BizModule_ProdPoolReviewLibraMetricGroup:
		effectModule = "货盘复盘-经分"
	default:
		effectModule = "异动归因"
	}
	// 补充维度列表
	data, err := d.DimensionService.GetProductAnalysisBizList(ctx, effectModule)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimensionHandler) RegisterNeedDumpDimension(ctx context.Context, req *dimensions.RegisterNeedDumpDimensionRequest) (resp *dimensions.RegisterNeedDumpDimensionResponse, err error) {
	resp = &dimensions.RegisterNeedDumpDimensionResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	// 补充维度列表
	data, err := d.NeedDumpDimensionService.CreateNeedDumpDimensionRecord(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data.Data
	return resp, nil
}

func (d *DimensionHandler) GetRegisterNeedDumpDimensionStatus(ctx context.Context, req *dimensions.GetDumpDimensionStatusRequest) (resp *dimensions.DumpDimensionStatusResponse, err error) {
	resp = &dimensions.DumpDimensionStatusResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	// 补充维度列表
	data, err := d.NeedDumpDimensionService.GetNeedDumpDimensionStatus(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data.Data
	return resp, nil
}
