package multi_dim_trend_handler

import (
	multi_dim_trend_service "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_trend_domain/service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/mw"
	"context"
)

type MultiDimTrendHandler struct {
	MultiDimTrendService multi_dim_trend_service.IMultiDimTrendService
}

func (d *MultiDimTrendHandler) CommonAnalysisMultiDimTrend(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonMultiDimTrendResponse, err error) {
	resp = common_response.NewCommonMultiDimTrendResponse()
	resp.BaseResp = base.NewBaseResp()
	resp.Data = common_response.NewUnifiedData()
	if req == nil || req.BizExtraInfo == nil {
		resp.GetBaseResp().SetStatusCode(stcodes.StatusCodeParamError.Int())
		resp.GetBaseResp().SetStatusMessage(stcodes.StatusCodeParamError.String())
		return resp, nil
	}

	ok, stCode, msg := true, stcodes.StatusCodeSuccess, consts.Empty
	if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.BaseReq); !ok {
		resp.GetBaseResp().SetStatusCode(stCode.Int())
		resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
		return resp, nil
	}

	if req.CompareReq != nil {
		if ok, stCode, msg, ctx = mw.CheckBaseStructParams(ctx, req.CompareReq); !ok {
			resp.GetBaseResp().SetStatusCode(stCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.If(len(msg) > 0, msg, stCode.String()))
			return resp, nil
		}
	}
	resp.Data, _, err = d.MultiDimTrendService.ICommonAnalysisMultiDimTrend(ctx, req)
	return
}
