package dorado_task_handler

import (
	analysis_pool_product_service "code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_dump_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dorado_task"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

type DoradoTaskHandler struct {
	AnalysisPoolDumpService analysis_pool_product_service.IAnalysisPoolDumpService
}

func (d *DoradoTaskHandler) HandlerGetDoradoDumpLoadHiveTaskRunningCallBack(ctx context.Context, req *dorado_task.GetDoradoTaskRunningCallBackRequest) (resp *dorado_task.GetDoradoTaskRunningCallBackResponse, err error) {
	logs.CtxInfo(ctx, "[HandlerGetDoradoDumpLoadHiveTaskRunningCallBack]req = %s", convert.ToString(req))
	resp = &dorado_task.GetDoradoTaskRunningCallBackResponse{}
	resp.SetBaseResp(base.NewBaseResp())

	err = d.AnalysisPoolDumpService.UpdateDoradoTaskStatus(ctx, req)
	return resp, err
}
