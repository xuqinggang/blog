package subscription

import (
	"context"

	subscription_service "code.byted.org/ecom/smartop_product_analysis/biz/service/subscription"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/subscription"
)

type SubscriptionHandler struct {
	SubscriptionService subscription_service.ISubscriptionService
}

// 订阅配置 - 获取订阅通用配置
func (t *SubscriptionHandler) GetSubscriptionConfig(ctx context.Context, req *subscription.GetSubscriptionConfigRequest) (resp *subscription.GetSubscriptionConfigResponse, err error) {
	return t.SubscriptionService.GetSubscriptionConfig(ctx, req)
}

// 订阅管理 - 用户的所有订阅
func (t *SubscriptionHandler) GetUserSubscriptionList(ctx context.Context, req *subscription.GetUserSubscriptionListRequest) (resp *subscription.GetUserSubscriptionListResponse, err error) {
	return t.SubscriptionService.GetUserSubscriptionList(ctx, req)
}

// 订阅管理 - 推送预览
func (t *SubscriptionHandler) PreviewUserSubscription(ctx context.Context, req *subscription.PreviewUserSubscriptionRequest) (err error) {

	return t.SubscriptionService.PreviewUserSubscription(ctx, req)
}

// 订阅管理 - 保存/更新/暂停推送
func (t *SubscriptionHandler) SaveUserSubscription(ctx context.Context, req *subscription.SaveUserSubscriptionRequest) (resp *subscription.SaveUserSubscriptionResponse, err error) {

	return t.SubscriptionService.SaveUserSubscription(ctx, req)
}

// 订阅管理 - 删除推送
func (t *SubscriptionHandler) DeleteUserSubscription(ctx context.Context, req *subscription.DeleteUserSubscriptionRequest) (err error) {

	return t.SubscriptionService.DeleteUserSubscription(ctx, req)
}

// 订阅管理 - 保存订阅配置信息
func (t *SubscriptionHandler) SaveSubscriptionFilterConfig(ctx context.Context, req *subscription.SaveSubscriptionFilterConfigRequest) (resp *subscription.SaveSubscriptionFilterConfigResponse, err error) {
	return t.SubscriptionService.SaveSubscriptionFilterConfig(ctx, req)
}

// 订阅管理 - 获取订阅配置信息
func (t *SubscriptionHandler) GetSubscriptionFilterConfig(ctx context.Context, req *subscription.GetSubscriptionFilterConfigRequest) (resp *subscription.GetSubscriptionFilterConfigResponse, err error) {
	return t.SubscriptionService.GetSubscriptionFilterConfig(ctx, req)
}
