package file_handler

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/file_service"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/file"
)

type FileHandler struct {
	FileService file_service.IFileService
}

func (d *FileHandler) UploadFile(ctx context.Context, req *file.UploadFileRequest) (resp *file.UploadFileResponse, err error) {
	resp = &file.UploadFileResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	resp.Url, resp.ObjKey, err = d.FileService.UploadFile(ctx, req)
	return
}
