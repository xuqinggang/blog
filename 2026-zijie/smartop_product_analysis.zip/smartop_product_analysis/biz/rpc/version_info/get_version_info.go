package version_info

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/client/callopt"
	meta_rpc "code.byted.org/overpass/data_abtest_meta_rpc/kitex_gen/meta_rpc"
	"code.byted.org/overpass/data_abtest_meta_rpc/rpc/data_abtest_meta_rpc"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

func GetVersionInfoByFlightId(ctx context.Context, flightId int64) map[int64]*meta_rpc.Version {
	if flightId == 0 {
		return nil
	}
	req := &meta_rpc.VersionsByFidReq{
		Fid: flightId,
	}
	resp, err := data_abtest_meta_rpc.RawCall.GetVersionsByFid(ctx, req, callopt.WithCluster("meta_rpc"))
	if err != nil {
		logs.CtxError(ctx, "GetVersionsByFid error=%v", err)
		return nil
	}
	return resp.Versions
}

func GetVersionInfo(ctx context.Context, versionIds []int64) map[int64]*meta_rpc.Flight {
	if len(versionIds) == 0 {
		return nil
	}
	req := meta_rpc.NewFlightsByFidsReq()
	req.Fids = versionIds
	resp, err := data_abtest_meta_rpc.RawCall.GetFlightsByFids(ctx, req, callopt.WithCluster("meta_rpc"))
	if err != nil {
		logs.CtxError(ctx, "GetVersionInfo error=%v", err)
		return nil
	}
	if resp != nil && len(resp.GetFlights()) > 0 {
		return resp.GetFlights()
	}
	return nil
}

func GetLibraBasicInfo(ctx context.Context, fightIDs ...int64) map[int64]*basic_info.LibraBasicInfo {
	ret := make(map[int64]*basic_info.LibraBasicInfo)
	fMap := GetVersionInfo(ctx, fightIDs)
	if len(fMap) == 0 {
		return ret
	}
	for _, id := range fightIDs {
		basicInfo := &basic_info.LibraBasicInfo{}
		if data, ok := fMap[id]; ok {
			basicInfo.FlightId = convert.ToString(data.Id)
			basicInfo.FlightName = data.DisplayName
			basicInfo.FlightStartTime = time_utils.TimestampSecondToDate(data.StartTime)
			basicInfo.FlightEndTime = time_utils.TimestampSecondToDate(data.EndTime)

			switch data.Status {
			case meta_rpc.FlightStatus_EXPIRED:
				basicInfo.FlightStatus = "已过期"
			case meta_rpc.FlightStatus_PROCESSING:
				basicInfo.FlightStatus = "进行中"
			case meta_rpc.FlightStatus_READY:
				basicInfo.FlightStatus = "待调度"
			case meta_rpc.FlightStatus_TESTING:
				basicInfo.FlightStatus = "测试中"
			case meta_rpc.FlightStatus_SUSPEND:
				basicInfo.FlightStatus = "已暂停"
			case meta_rpc.FlightStatus_RELEASED:
				basicInfo.FlightStatus = "满足预期"
			case meta_rpc.FlightStatus_OTHER:
				basicInfo.FlightStatus = "其它"
			default:
				basicInfo.FlightStatus = "-"
			}
			switch data.GetFlightType() { // 实验类型转换
			case meta_rpc.FlightType_STRATEGY:
				basicInfo.FlightType = "服务端实验"
			case meta_rpc.FlightType_PRODUCT:
				basicInfo.FlightType = "普通客户端实验"
			case meta_rpc.FlightType_AD_USER:
				basicInfo.FlightType = "广告用户实验"
			case meta_rpc.FlightType_AD_ADVERTISER:
				basicInfo.FlightType = "广告主实验"
			case meta_rpc.FlightType_AD_PLAN:
				basicInfo.FlightType = "广告计划实验"
			case meta_rpc.FlightType_INTERLEAVING:
				basicInfo.FlightType = "搜索实验"
			case meta_rpc.FlightType_AB_CLIENT_SDK:
				basicInfo.FlightType = "AB客户端SDK实验"
			case meta_rpc.FlightType_SETTINGS_CLIENT_SDK:
				basicInfo.FlightType = "Settings SDK实验"
			case meta_rpc.FlightType_SETTINGS_LOCAL_AB:
				basicInfo.FlightType = "Settings本地分流实验"
			case meta_rpc.FlightType_REGRESSION:
				basicInfo.FlightType = "自动搜参实验"
			case meta_rpc.FlightType_SETTINGS_NORMAL_CLIENT:
				basicInfo.FlightType = "Settings普通客户端实验"
			case meta_rpc.FlightType_OTHER:
				basicInfo.FlightType = "其它"
			default:
				basicInfo.FlightType = "-"
			}
			basicInfo.FlightLink = "https://data.bytedance.net/libra/flight/" + convert.ToString(id) + "/edit"
			basicInfo.FlightOwners = data.Owners
			ret[id] = basicInfo
		}
	}
	return ret
}
