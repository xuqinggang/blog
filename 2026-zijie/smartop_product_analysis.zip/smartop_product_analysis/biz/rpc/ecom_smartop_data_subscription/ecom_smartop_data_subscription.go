package ecom_smartop_data_subscription

import (
	"context"
	"sync"

	"code.byted.org/aweme-go/dsync"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/subscription"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_smartop_data_subcription/kitex_gen/ecom/smartop/data_subcription"
	"code.byted.org/overpass/ecom_smartop_data_subcription/rpc/ecom_smartop_data_subcription"
	"code.byted.org/temai/go_lib/convert"
)

func PreviewSubscription(ctx context.Context, req *subscription.PreviewUserSubscriptionRequest) (err error) {
	if req == nil || req.Task == nil {
		return errors.New("缺少参数信息")
	}
	subPreviewReq := &data_subcription.SubscribeTriggerReq{
		SendSelf: convert.ToBoolPtr(true),
		IndicatorGroupConfig: &data_subcription.IndicatorConfigListData{
			BusinessId: convert.ToInt64Ptr(int64(req.Task.BusinessId)),
		},
		ExtraInfo: convert.ToStringPtr(convert.ToJSONString(req.Task)),
	}

	resp, errRpc := ecom_smartop_data_subcription.RawCall.SubscribeTrigger(ctx, subPreviewReq)
	if errRpc != nil || resp == nil || resp.BaseResp == nil {
		logs.CtxError(ctx, "call ecom_smartop_data_subcription.SubscribeTrigger failed, req=%v, err:%v", req, errRpc)
		err = errors.New("发送预览失败，请稍后重试")
		return
	}
	if resp.BaseResp.StatusCode != 0 {
		logs.CtxError(ctx, "call ecom_smartop_data_subcription.SubscribeTrigger failed, req=%v, resp:%v", req, resp)
		err = errors.New("发起预览失败: " + resp.BaseResp.StatusMessage)
		return
	}
	if resp.Code != 0 {
		logs.CtxError(ctx, "call ecom_smartop_data_subcription.SubscribeTrigger failed, req=%v, resp:%v", req, resp)
		err = errors.New("发起预览失败: " + resp.Msg)
		return
	}

	return
}

func SaveSubscription(ctx context.Context, reqList map[subscription.DateType]*data_subcription.SaveSubscribeConfigRpcReq) (subCenterId map[subscription.DateType]int64, err error) {
	pool := dsync.NewGoPool(len(reqList))
	subCenterId = make(map[subscription.DateType]int64)
	var mu = sync.Mutex{}
	for dt := range reqList {
		req := reqList[dt]
		tmpIdx := dt
		if err = pool.Go(ctx, func() {
			resp, errRpc := ecom_smartop_data_subcription.RawCall.SaveSubscribeConfigRpc(ctx, req)
			if errRpc != nil || resp == nil {
				logs.CtxError(ctx, "call ecom_smartop_data_subcription.SaveSubscribeConfigRpc failed, req=%v, err:%v", req, errRpc)
				err = errors.New("保存订阅失败，请稍后重试")
				return
			}
			if resp.BaseResp != nil && resp.BaseResp.StatusCode != 0 {
				logs.CtxError(ctx, "call ecom_smartop_data_subcription.SaveSubscribeConfigRpc failed, req=%v, resp:%v", req, resp)
				err = errors.New("保存订阅失败: " + resp.BaseResp.StatusMessage)
				return
			}
			if resp.Code != 0 {
				logs.CtxError(ctx, "call ecom_smartop_data_subcription.SaveSubscribeConfigRpc failed, req=%v, resp:%v", req, resp)
				err = errors.New("保存订阅失败: " + resp.Msg)
				return
			}
			if resp.Data == nil {
				logs.CtxError(ctx, "call ecom_smartop_data_subcription.SaveSubscribeConfigRpc failed, req=%v, resp.Data = nil", req, resp)
				err = errors.New("保存订阅失败: 无有效信息返回")
				return
			}

			mu.Lock()
			defer mu.Unlock()

			subCenterId[tmpIdx] = resp.Data.SubscribeId
		}); err != nil {
			return
		}
	}

	pool.Wait()

	return
}

func BusinessTrigger(ctx context.Context, req *data_subcription.BusinessTriggerReq) (err error) {
	resp, errRpc := ecom_smartop_data_subcription.RawCall.BusinessTrigger(ctx, req)
	if errRpc != nil || resp == nil || resp.BaseResp == nil {
		logs.CtxError(ctx, "call ecom_smartop_data_subcription.BusinessTrigger failed, req=%v, err:%v", req, errRpc)
		err = errors.New("发送预览失败，请稍后重试")
		return
	}
	if resp.BaseResp.StatusCode != 0 {
		logs.CtxError(ctx, "call ecom_smartop_data_subcription.BusinessTrigger failed, req=%v, resp:%v", req, resp)
		err = errors.New("发起预览失败: " + resp.BaseResp.StatusMessage)
		return
	}

	return
}
