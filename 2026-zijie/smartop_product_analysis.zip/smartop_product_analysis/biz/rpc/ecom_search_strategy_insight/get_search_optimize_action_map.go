package ecom_search_strategy_insight

import (
	"code.byted.org/gopkg/logs"
	search_rpc "code.byted.org/overpass/ecom_search_strategy_insight_rpc/kitex_gen/ecom/search/strategy_insight_rpc"
	"code.byted.org/overpass/ecom_search_strategy_insight_rpc/rpc/ecom_search_strategy_insight_rpc"
	"context"
)

func GetSearchOptimizeActionMap(ctx context.Context) map[string]string {
	req := search_rpc.NewGetSugLabelReq()
	resp, err := ecom_search_strategy_insight_rpc.RawCall.GetSugLabel(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "getSearchOptimizeActionMap error=%v", err)
		return nil
	}
	if resp != nil && len(resp.Data) > 0 {
		return resp.Data
	}
	return nil
}
