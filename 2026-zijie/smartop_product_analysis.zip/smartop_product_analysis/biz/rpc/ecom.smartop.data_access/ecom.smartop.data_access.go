package ecom_smartop_data_access

import (
	"context"
	"sync"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gopkg/logs"
	"code.byted.org/overpass/ecom_smartop_data_access/kitex_gen/ecom/smartop/data_access"
	"code.byted.org/overpass/ecom_smartop_data_access/rpc/ecom_smartop_data_access"
	"github.com/jinzhu/copier"
	"golang.org/x/sync/semaphore"
)

var (
	// 搜索核心指标
	queryIdList = []string{
		// 搜索核心指标
		"searchProductAnalyzeCoreIndicatorDetail",
		// 商品基础信息
		"searchProductAnalyzeProductBaseInfoDetail",
		// 商品质量分
		"searchProductAnalyzeProductQualityScoreDetail",
		// 商品价格力
		"searchProductAnalyzeProductPricePowerDetail",
		// 商品后验质量
		"searchProductAnalyzeProductPosteriorQualityDetail",
		// // 商品流量空间
		"searchProductAnalyzeProductFlowDetail",
	}
)

func BatchGetIndicatorTable(ctx context.Context, queryIdIndicatorListMap map[string][]string, baseReq *data_access.IndicatorTableRequest) (resp map[string]*data_access.IndicatorTableResponse, err error) {
	logs.CtxInfo(ctx, "调用 BatchGetIndicatorTable baseReq=%v, queryIdIndicatorListMap=%v", baseReq, queryIdIndicatorListMap)
	if baseReq == nil {
		baseReq = &data_access.IndicatorTableRequest{}
	}
	weighted := semaphore.NewWeighted(1)
	resp = make(map[string]*data_access.IndicatorTableResponse)
	callerInstance := utils.Result[map[string]*data_access.IndicatorTableResponse](nil)
	mutex := new(sync.Mutex)
	asyncCaller := utils.AsyncCaller(func(v any) (map[string]*data_access.IndicatorTableResponse, error) {
		mutex.Lock()
		defer mutex.Unlock()
		rpcReq, ok := v.(*data_access.IndicatorTableRequest)
		if !ok {
			logs.CtxInfo(ctx, "[BatchGetIndicatorTable] 类型转换失败")
			return resp, nil
		}
		logs.CtxInfo(ctx, "[BatchGetIndicatorTable] call ecom_smartop_data_access.IndicatorTable req=%v", rpcReq)
		indicatorTableResp, err := ecom_smartop_data_access.RawCall.IndicatorTable(ctx, rpcReq)
		if err != nil || indicatorTableResp == nil {
			logs.CtxInfo(ctx, "[BatchGetIndicatorTable] call ecom_smartop_data_access.IndicatorTable failed, req:%v, err:%v", rpcReq, err)
		}
		resp[rpcReq.QueryId] = indicatorTableResp
		return resp, nil
	}).SetSemaphore(weighted)

	for queryId, indicatorList := range queryIdIndicatorListMap {
		req := &data_access.IndicatorTableRequest{}
		copier.Copy(&req, &baseReq)
		req.QueryId = queryId
		req.IndicatorList = indicatorList
		callerInstance = asyncCaller.Call(req)
	}
	if callerInstance == nil {
		logs.CtxInfo(ctx, "[BatchGetIndicatorTable]批量调用ecom_smartop_data_access.IndicatorTable失败 callerInstance为空 queryIdIndicatorListMap=%v ,baseReq=%v", queryIdIndicatorListMap, baseReq)
		return resp, nil
	}

	resp = callerInstance.Value()
	logs.CtxInfo(ctx, "[BatchGetIndicatorTable] resp=%v", resp)

	return resp, nil
}

func GetIndicatorTable(ctx context.Context, req *data_access.IndicatorTableRequest) (resp *data_access.IndicatorTableResponse, err error) {
	logs.CtxInfo(ctx, "call ecom_smartop_data_access.IndicatorTable req=%v", req)

	resp, err = ecom_smartop_data_access.RawCall.IndicatorTable(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "call ecom_smartop_data_access.IndicatorTable failed, err:%v", err)
		return nil, err
	}

	logs.CtxInfo(ctx, "call ecom_smartop_data_access.IndicatorTable resp=%v", resp)
	return resp, nil
}

func GetAllQueryIndicatorList(ctx context.Context, baseReq *data_access.IndicatorListRequest) (resp map[string]*data_access.IndicatorListData, err error) {
	resp = make(map[string]*data_access.IndicatorListData)
	weighted := semaphore.NewWeighted(1)
	callerInstance := utils.Result[map[string]*data_access.IndicatorListData](nil)
	mutex := new(sync.Mutex)

	asyncCaller := utils.AsyncCaller(func(v any) (map[string]*data_access.IndicatorListData, error) {
		mutex.Lock()
		defer mutex.Unlock()
		rpcReq, ok := v.(*data_access.IndicatorListRequest)
		if !ok {
			logs.CtxInfo(ctx, "[GetAllQueryIndicatorList] 类型转换失败")
			return resp, nil
		}
		logs.CtxInfo(ctx, "[GetAllQueryIndicatorList]call ecom_smartop_data_access.IndicatorList rpcReq=%v", rpcReq)
		indicatorListResp, err := ecom_smartop_data_access.RawCall.IndicatorList(ctx, rpcReq)
		if err != nil || indicatorListResp == nil {
			logs.CtxInfo(ctx, "[GetAllQueryIndicatorList]call ecom_smartop_data_access.IndicatorList failed, err:%v", err)
			resp[rpcReq.QueryId] = &data_access.IndicatorListData{}
		} else {
			resp[rpcReq.QueryId] = indicatorListResp.Data
		}
		return resp, nil
	}).SetSemaphore(weighted)

	// 循环 queryIdList
	for _, queryId := range queryIdList {
		req := &data_access.IndicatorListRequest{}
		copier.Copy(&req, &baseReq)
		req.QueryId = queryId
		callerInstance = asyncCaller.Call(req)
	}
	if callerInstance == nil {
		logs.CtxInfo(ctx, "[GetAllQueryIndicatorList]批量调用ecom_smartop_data_access.IndicatorList 失败 callerInstance为空 baseReq=%v", baseReq)
		return resp, nil
	}

	resp = callerInstance.Value()
	logs.CtxInfo(ctx, "[GetAllQueryIndicatorList] resp=%v", resp)
	return resp, nil
}
