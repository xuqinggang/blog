package ecom_seller_merchant_dc

import (
	"context"
	"strconv"
	"time"

	"code.byted.org/gopkg/logs"
	"code.byted.org/overpass/ecom_seller_merchant_dc/kitex_gen/ecom/seller/merchant_dc"
	"code.byted.org/overpass/ecom_seller_merchant_dc/rpc/ecom_seller_merchant_dc"
)

type SellerMerchantProdInfo struct {
	ProductId                 string
	SpuEstimatePriceOnlineTag string
}

const (
	spuEstimatePriceCmpIndicatorCode = "price_cmp_result.spu_estimate_price_online_tag"
)

func buildReq(activityIds []string, productIds []string) *merchant_dc.GetApplyRecordListV2Request {
	endTime := time.Now().Unix()
	endTimeStr := strconv.FormatInt(endTime, 10)
	req := &merchant_dc.GetApplyRecordListV2Request{
		IndicatorSetCode: "item_sign_record",
		MustConditionList: []*merchant_dc.SearchNode{
			{
				Comparer: merchant_dc.Terms,
				Candidate: &merchant_dc.IndicatorCandidate{
					IndicatorCode: "activity_id",
					// 招商子活动id
					TargetVals: activityIds,
				},
			},
			{
				Comparer: merchant_dc.Terms,
				Candidate: &merchant_dc.IndicatorCandidate{
					IndicatorCode: "item_id",
					// 商品id列表
					TargetVals: productIds,
				},
			},
			{
				Comparer: merchant_dc.Terms,
				Candidate: &merchant_dc.IndicatorCandidate{
					IndicatorCode: "status",
					// 状态为 招商活动报名成功
					TargetVals: []string{"6"},
				},
			},
			{
				Comparer: merchant_dc.GT,
				Candidate: &merchant_dc.IndicatorCandidate{
					IndicatorCode: "end_time",
					TargetVals:    []string{endTimeStr},
				},
			},
		},
		Page:     1,
		PageSize: 100,
		CodeList: []string{
			"id",
			"item_id",
			// 普惠到手价(单品)比价状态
			spuEstimatePriceCmpIndicatorCode,
			"end_time",
		},
	}
	return req
}

func RPCGetSellerMerchantApplyRecordList(ctx context.Context, activityIds []string, productIds []string) (applyRecordList []*merchant_dc.ApplyRecord, err error) {
	req := buildReq(activityIds, productIds)
	resp, err := ecom_seller_merchant_dc.RawCall.GetApplyRecordListV2(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "call ecom_product_pack_platform.GetApplyRecordListV2 failed, err:%v", err)
		return nil, err
	}
	return resp.ApplyRecordList, nil
}
