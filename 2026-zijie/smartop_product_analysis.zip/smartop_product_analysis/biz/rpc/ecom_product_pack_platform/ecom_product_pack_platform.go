package ecom_product_pack_platform

import (
	"context"

	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_product_pack_platform/kitex_gen/ecom/product/pack_platform"
	"code.byted.org/overpass/ecom_product_pack_platform/rpc/ecom_product_pack_platform"
	"github.com/gogo/protobuf/proto"
)

const (
	packViewName                     = "smartop_analysis_alert"
	packPlatformMaxRequestProductNum = 20
)

func buildReq(productIds []int64) *pack_platform.MGetProductRequest {
	req := &pack_platform.MGetProductRequest{
		Ids:  productIds,
		View: packViewName,
		SceneParams: &pack_platform.MGetSceneParams{
			PurchaseParams:  nil,
			MarketingParams: nil,
		},
		HasPromotionIds: false,
		RequestInfo: &pack_platform.RequestInfo{
			AppId:          1128,
			AppVersion:     290800,
			DeviceId:       791287338113736,
			DevicePlatform: "android",
			UserId:         1900393939340320,
			OsVersion:      "16.1.1",
			EcomSceneId:    proto.String("1031"),
			ParamAuthorId:  proto.Int64(0),
			SaasSdkVersion: proto.Int64(280800),
		},
	}
	return req
}

func RPCMGetProduct(ctx context.Context, productIds []int64) (productMapByReqIds map[int64]*pack_platform.ProductItem, err error) {
	productMapByReqIds = make(map[int64]*pack_platform.ProductItem)
	req := buildReq(productIds)

	if len(productIds) == 0 {
		return nil, errors.New("MGetProduct productIds is empty")
	}

	if len(productIds) > packPlatformMaxRequestProductNum {
		return nil, errors.New("MGetProduct productIds num > 20")
	}

	resp, err := ecom_product_pack_platform.RawCall.MGetProduct(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "call ecom_product_pack_platform.MGetProduct failed, err:%v", err)
		return nil, err
	}

	for _, v := range resp.ProductInfoList {
		if v == nil {
			continue
		}
		productMapByReqIds[v.GetId()] = v
	}
	logs.CtxDebug(ctx, "productMapByReqIds=%v", productMapByReqIds)
	return productMapByReqIds, nil
}
