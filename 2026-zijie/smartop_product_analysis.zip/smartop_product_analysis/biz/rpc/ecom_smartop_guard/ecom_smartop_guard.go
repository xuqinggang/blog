package ecom_smartop_guard

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"context"

	"code.byted.org/gopkg/logs"
	"code.byted.org/overpass/ecom_smartop_guard/kitex_gen/ecom/smartop/guard"
	"code.byted.org/overpass/ecom_smartop_guard/rpc/ecom_smartop_guard"
)

// GetDimensionsByUser 获取用户维度列表
func GetDimensionsByUser(ctx context.Context, employeeId string, userBizType int64) ([]*guard.DimensionNew, error) {
	logs.CtxInfo(ctx, "[GetDimensionsByUser] start, employeeId:%s", employeeId)

	req := guard.NewGetDimensionsByUserRequest()
	req.EmployeeId = employeeId
	req.BizType = userBizType

	resp, err := ecom_smartop_guard.RawCall.GetDimensionsByUser(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionsByUser] failed, employeeId:%s, err:%v", employeeId, err)
		return nil, err
	}

	dimensions := make([]*guard.DimensionNew, 0)
	for _, dimension := range resp.Dimensions {
		if dimension == nil {
			continue
		}
		if dimension.Code == "Dm12512090000001" || dimension.Code == "Dm12512090000002" || dimension.Code == "Dm12512090000501" || dimension.Code == "Dm12512090001001" {
			dimensions = append(dimensions, dimension)
		}
	}

	logs.CtxInfo(ctx, "[GetDimensionsByUser] end, employeeId:%s, resp:%+v", employeeId, resp)
	return dimensions, nil
}

// GetUserDimension 获取单个用户维度
func GetUserDimension(ctx context.Context, employeeId string, dimensionCode string) (*guard.GetUserDimensionResponse, error) {
	req := guard.NewGetUserDimensionRequest()
	req.EmployeeId = employeeId
	req.DimensionCode = dimensionCode
	resp, err := utils.GetUserDimensionWithCache(ctx, employeeId)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "call GetUserDimensionWithCache failed, err:%v", err)
		return nil, err
	}
	return resp, nil
}
