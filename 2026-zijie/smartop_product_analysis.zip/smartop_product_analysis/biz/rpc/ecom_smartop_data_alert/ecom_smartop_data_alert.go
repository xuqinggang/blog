package ecom_smartop_data_alert

import (
	"context"

	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"

	"code.byted.org/overpass/ecom_smartop_data_alert/kitex_gen/ecom/smartop/data_alert"
	"code.byted.org/overpass/ecom_smartop_data_alert/rpc/ecom_smartop_data_alert"
)

var (
	businessId = "__test_business__"
	eventType  = "app_govern_voc_hotword_cal_5m_byday"
)

// 根据监控任务id批量查询监控任务详情
func GetRulesByRuleIds(ctx context.Context, req *data_alert.GetRulesByRuleIdsReq) ([]*data_alert.RuleSimpleInfo, error) {
	logs.CtxInfo(ctx, "[调用RPC GetRulesByRuleIds] req:%s", convert.ToJSONString(req))
	resp, err := ecom_smartop_data_alert.RawCall.GetRulesByRuleIds(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[调用RPC GetRulesByRuleIds] err:%v", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[调用RPC GetRulesByRuleIds]] resp:%s", convert.ToJSONString(resp))

	return resp.Rules, nil
}

// 获取监控任务所有指标
func GetAllAlertMetrics(ctx context.Context, param *data_alert.GetAllAlertMetricsReq) (*data_alert.GetAllAlertMetricsData, error) {
	req := &data_alert.GetAllAlertMetricsReq{
		BusinessId: businessId,
		EventType:  &eventType,
	}

	logs.CtxInfo(ctx, "[调用RPC GetAllAlertMetrics] req:%s", convert.ToJSONString(req))
	resp, err := ecom_smartop_data_alert.RawCall.GetAllAlertMetrics(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[调用RPC GetAllAlertMetrics] err:%v", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[调用RPC GetAllAlertMetrics]] resp:%s", convert.ToJSONString(resp))

	return resp.Data, nil
}

// 添加监控任务
func AddRule(ctx context.Context, req *data_alert.AddRuleReq) (*string, error) {
	req.BusinessId = businessId
	req.Receiver = &data_alert.AlertMsgReceiver{
		// userName传1 取消预警系统默认的发送的飞书消息
		Users:      []*data_alert.AlertMsgReceiverUser{{UserName: "1"}},
		LarkGroups: make([]*data_alert.AlertMsgReceiverLarkGroup, 0),
	}

	logs.CtxInfo(ctx, "[调用RPC AddRule] req:%s", convert.ToJSONString(req))
	resp, err := ecom_smartop_data_alert.RawCall.AddRule(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[调用RPC AddRule] err:%v", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[调用RPC AddRule]] resp:%s", convert.ToJSONString(resp))

	return &resp.RuleId, nil
}

// 更新监控任务
func UpdateRule(ctx context.Context, req *data_alert.UpdateRuleReq) (*bool, error) {
	req.BusinessId = businessId
	req.Receiver = &data_alert.AlertMsgReceiver{
		// userName传1 取消预警系统默认的发送的飞书消息
		Users:      []*data_alert.AlertMsgReceiverUser{{UserName: "1"}},
		LarkGroups: make([]*data_alert.AlertMsgReceiverLarkGroup, 0),
	}

	logs.CtxInfo(ctx, "[调用RPC UpdateRule] req:%s", convert.ToJSONString(req))
	resp, err := ecom_smartop_data_alert.RawCall.UpdateRule(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[调用RPC UpdateRule] err:%v", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[调用RPC UpdateRule]] resp:%s", convert.ToJSONString(resp))

	return &resp.AccessDeny, nil
}

// 更新监控任务启用状态
func UpdateRuleActiveStatus(ctx context.Context, req *data_alert.UpdateRuleActiveStatusReq) (*bool, error) {
	logs.CtxInfo(ctx, "[调用RPC UpdateRuleActiveStatus] req:%s", convert.ToJSONString(req))
	resp, err := ecom_smartop_data_alert.RawCall.UpdateRuleActiveStatus(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[调用RPC UpdateRuleActiveStatus] err:%v", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[调用RPC UpdateRuleActiveStatus]] resp:%s", convert.ToJSONString(resp))

	return &resp.IsActive, nil
}
