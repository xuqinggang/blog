package ecom_smartop_data_img

import (
	"context"

	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_smartop_data_img/kitex_gen/ecom/smartop/data_img"
	"code.byted.org/overpass/ecom_smartop_data_img/rpc/ecom_smartop_data_img"
	"code.byted.org/temai/go_lib/convert"
)

func CreateScreenShot(ctx context.Context, req *data_img.ScreenShotRequest) (imgContent []*data_img.ScreenShotImg, err error) {
	resp, errRPc := ecom_smartop_data_img.RawCall.ScreenShot(ctx, req)
	if errRPc != nil {
		logs.CtxError(ctx, "ecom_smartop_data_img.ScreenShot: req=%v, err=%v", convert.ToJSONString(req), errRPc)
		err = errRPc
		return
	} else if resp.BaseResp != nil && resp.BaseResp.StatusCode != 0 {
		logs.CtxError(ctx, "ecom_smartop_data_img.ScreenShot: req=%v, resp.Code=%v, resp.Msg=%v",
			convert.ToJSONString(req), resp.BaseResp.StatusCode, resp.BaseResp.StatusMessage)
		err = errors.New("调用截图服务失败, 异常信息: " + resp.BaseResp.StatusMessage)
		return
	} else if len(resp.ImgList) == 0 {
		logs.CtxError(ctx, "ecom_smartop_data_img.ScreenShot: req=%v, err:截图图片列表为空", convert.ToJSONString(req))
		err = errors.New("调用截图服务失败: 截图图片列表为空")
		return
	}

	imgContent = resp.ImgList

	return
}
