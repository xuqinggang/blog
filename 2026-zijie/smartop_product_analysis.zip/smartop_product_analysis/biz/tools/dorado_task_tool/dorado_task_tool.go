package dorado_task_tool

import (
	mongo_util "code.byted.org/ecom/smartop_product_analysis/biz/dal/mongo"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/gopkg/logs"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
)

var DoradoHostKey = "https://openapi-dp.byted.org/openapi/dorado"
var CoralHostKey = "http://openapi-dp.byted.org/openapi/new_coralng"

const DoradoVolcType = "dorado"

type DoradoServiceImpl struct {
}

type TriggerRunResponse struct {
	Code      int32          `json:"code"`
	Message   string         `json:"message"`
	Data      TriggerRunData `json:"data"`
	SkipCodes *string        `json:"skipCodes"`
}

type TriggerRunData struct {
	IsOk       bool    `json:"isOk"`
	TaskId     int32   `json:"taskId"`
	BusinessId string  `json:"businessId"`
	InstanceId int64   `json:"instanceId"`
	Message    *string `json:"message"`
}

func TriggerRun(ctx context.Context, taskId int64, params map[string]interface{}) (int64, error) {
	baseURL := DoradoHostKey + fmt.Sprintf("/task/%d/trigger_run", taskId)

	mClient := mongo_util.GetClient()
	defer mClient.Disconnect(context.Background())

	requestBody, err := json.Marshal(map[string]interface{}{
		"params": params,
	})
	// 创建 HTTP POST 请求
	req, err := http.NewRequest("POST", baseURL, strings.NewReader(string(requestBody)))
	if err != nil {
		logs.CtxError(ctx, "[TriggerRun] create http request error, err=%v", err)
		return 0, err
	}
	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("authorization", biz_info.GetDoradoToken(ctx))
	client := &http.Client{}
	res, err := client.Do(req)
	if err != nil {
		logs.CtxError(ctx, "[TriggerRun] send http request error, err=%v", err)
		return 0, err
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		logs.CtxError(ctx, "[TriggerRun] read http response error, err=%v", err)
		return 0, err
	}
	var triggerRunRes TriggerRunResponse
	err = json.Unmarshal(body, &triggerRunRes)
	if err != nil {
		logs.CtxError(ctx, "[TriggerRun] unmarshal http response error, err=%v", err)
		return 0, err
	}
	return triggerRunRes.Data.InstanceId, nil
}
