package tos

import (
	"bytes"
	"context"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"image"
	"image/jpeg"
	"io"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/idgenerator"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs/v2"
	tos_sdk "code.byted.org/gopkg/tos"
)

var (
	tosClient *tos_sdk.Tos
)

const MaxImgSize = 10 * 1024 * 1024

// 初始化TOS客户端
func Init() {
	var err error
	ctx := context.Background()
	tosConfig, err := biz_info.GetTosConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, "[TOS] Init tos client failed, err=%v", err)
		panic(err)
	}

	var credentials tos_sdk.Credentials
	if env.IsBoe() {
		// 如果在 BOE 环境使用个人秘钥，Secret Key 必须填。
		credentials = &tos_sdk.StaticCredentials{
			SecretKey: tosConfig.SecretKey,
			AccessKey: tosConfig.AccessKey,
		}
	} else {
		// 如果在线上环境使用 Bucket 专用秘钥，SecretKey 可以不用填
		credentials = &tos_sdk.BucketAccessKeyCredentials{
			BucketName: tosConfig.BucketName,
			AccessKey:  tosConfig.AccessKey,
		}
	}

	// 注意: CN的BOE环境，自2022年2月24起，新创建的桶需要使用“个人秘钥访问”, 调用方法请参考：TOS 帐号“个人密钥”和“Bucket 专用密钥” SDK 调用方法介绍。
	tosClient, err = tos_sdk.NewTos(tos_sdk.WithBucket(tosConfig.BucketName),
		tos_sdk.WithCredentials(credentials), tos_sdk.WithRemotePSM(tosConfig.RemotePsm))
	if err != nil {
		logs.CtxError(ctx, "[TOS] Init tos client failed, err=%v", err)
		panic(err)
	}
}

func BuildOpenBucketURL(tosPath string) string {
	if env.IsBoe() {
		return fmt.Sprintf("https://tosv.boe.byted.org/obj/product-insights-boe/%s", tosPath)
	}

	return fmt.Sprintf("https://tosv.byted.org/obj/product-insights/%s", tosPath)
}

// 上传文件到TOS
func Put(ctx context.Context, key string, value []byte) error {
	if len(value) == 0 || tosClient == nil {
		return nil
	}
	return tosClient.PutObject(ctx, key, int64(len(value)), bytes.NewReader(value))
}

// 返回 Reader 支持按行读取，不需要把所有的数据全部读到内存里面
func GetReader(ctx context.Context, key string) (r io.ReadCloser, err error) {
	if len(key) == 0 {
		return
	}
	var obj *tos_sdk.ObjectInfo
	if obj, err = tosClient.GetObject(ctx, key); err != nil {
		logs.CtxError(ctx, "[TOS] TOS:GetReader: failed to call GetObject, key=%s, err=%v", key, err)
		return
	} else if obj != nil {
		r = obj.R
	}
	return
}

// 将记录转换为JSON格式并上传到TOS
func UploadRecordsAsJson(ctx context.Context, records [][]interface{}, dir *string) (objKey string, err error) {
	if len(records) == 0 || tosClient == nil {
		return
	}

	// 将二维数组转换成列模式
	columnsMap := utils.TransposeToColumnsMap(records)

	// 转换为JSON字符串
	jsonStr, err := json.Marshal(columnsMap)
	if err != nil {
		logs.CtxError(ctx, "[TOS] UploadRecordsAsJson failed to call Marshal, err=%v", err)
		return
	}

	id, err := idgenerator.GenerateIdString(ctx)
	if err != nil {
		logs.CtxError(ctx, "[TOS] Generate tos objKey failed, err=%v", err)
		return
	}
	if dir != nil && len(*dir) > 0 {
		objKey = fmt.Sprintf("%s/%s.json", *dir, id)
	} else {
		objKey = fmt.Sprintf("%s.json", id)
	}

	// 上传
	if err = Put(ctx, objKey, jsonStr); err != nil {
		logs.CtxError(ctx, "[TOS] UploadRecordsAsJson failed, err=%v", err)
		objKey = ""
	}

	return
}

// 将记录转换为CSV格式并上传到TOS
func UploadRecordsAsCSV(ctx context.Context, records [][]string, dir *string) (objKey string, err error) {
	if len(records) == 0 || tosClient == nil {
		return
	}

	// 转CSV格式
	var buf bytes.Buffer
	writer := csv.NewWriter(&buf)
	defer writer.Flush()
	// 一次性写入所有数据 (自动处理 Flush)
	err = writer.WriteAll(records)
	if err != nil {
		logs.CtxError(ctx, "[TOS] UploadRecordsAsCSV failed to call WriteAll, err=%v", err)
		return
	}

	id, err := idgenerator.GenerateIdString(ctx)
	if err != nil {
		logs.CtxError(ctx, "[TOS] Generate tos objKey failed, err=%v", err)
		return
	}
	if dir != nil && len(*dir) > 0 {
		objKey = fmt.Sprintf("%s/%s.csv", *dir, id)
	} else {
		objKey = fmt.Sprintf("%s.csv", id)
	}

	// 上传
	if err = Put(ctx, objKey, buf.Bytes()); err != nil {
		logs.CtxError(ctx, "[TOS] UploadRecordsAsCSV failed, err=%v", err)
		objKey = ""
	}

	return
}

// 压缩文件
func CompressImage(imgBytes []byte, targetSize int64) ([]byte, error) {
	if int64(len(imgBytes)) <= targetSize {
		return imgBytes, nil
	}

	img, _, err := image.Decode(bytes.NewReader(imgBytes))
	if err != nil {
		return nil, fmt.Errorf("image.Decode failed: %w", err)
	}

	quality := int(float64(targetSize) / float64(len(imgBytes)) * 100)
	if quality > 90 {
		quality = 90
	} else if quality < 10 {
		quality = 10
	}

	var buf bytes.Buffer
	for {
		buf.Reset()
		err = jpeg.Encode(&buf, img, &jpeg.Options{Quality: quality})
		if err != nil {
			return nil, err
		}

		if int64(buf.Len()) <= targetSize {
			return buf.Bytes(), nil
		}

		quality -= 10
		if quality <= 0 {
			return nil, fmt.Errorf("无法压缩到目标大小")
		}
	}
}

// 上传图片到TOS
func UploadImage(ctx context.Context, bytes []byte, fileExt string) (objKey string, err error) {
	if len(bytes) == 0 || tosClient == nil {
		return
	}

	uploadBytes := bytes
	if len(bytes) > MaxImgSize {
		logs.CtxInfo(ctx, "[TOS] UploadImage image too large, start compression, original_size=%d", len(bytes))
		var compressedBytes []byte
		compressedBytes, err = CompressImage(bytes, MaxImgSize)
		if err != nil {
			logs.CtxError(ctx, "[TOS] UploadImage image compression failed, err=%v", err)
			return
		} else {
			logs.CtxInfo(ctx, "[TOS] UploadImage image compression success, compressed_size=%d", len(compressedBytes))
			uploadBytes = compressedBytes
		}
	}

	id, err := idgenerator.GenerateIdString(ctx)
	if err != nil {
		logs.CtxError(ctx, "[TOS] Generate tos objKey failed, err=%v", err)
		return
	}
	objKey = fmt.Sprintf("upload/img/%s%s", id, fileExt)
	if err = Put(ctx, objKey, uploadBytes); err != nil {
		logs.CtxError(ctx, "[TOS] UploadImage failed, err=%v", err)
		objKey = ""
	}
	return
}

// 上传CSV文件到TOS
func UploadCsv(ctx context.Context, bytes []byte, fileExt string) (objKey string, err error) {
	if len(bytes) == 0 || tosClient == nil {
		return
	}

	uploadBytes := bytes

	id, err := idgenerator.GenerateIdString(ctx)
	if err != nil {
		logs.CtxError(ctx, "[TOS] Generate tos objKey failed, err=%v", err)
		return
	}
	objKey = fmt.Sprintf("upload/csv/%s%s", id, fileExt)
	if err = Put(ctx, objKey, uploadBytes); err != nil {
		logs.CtxError(ctx, "[TOS] UploadCsv failed, err=%v", err)
		objKey = ""
	}
	return
}
