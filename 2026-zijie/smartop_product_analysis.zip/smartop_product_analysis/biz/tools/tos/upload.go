package tos

import (
	"bytes"
	"context"
	"fmt"

	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/tos"
	"code.byted.org/inf/infsecc"
	"code.byted.org/overpass/dp_invoker_engine/kitex_gen/dp/invoker/engine"
	"code.byted.org/overpass/dp_invoker_engine/rpc/dp_invoker_engine"
)

const PSM = "ecom.smartop.product_analysis"

// TOSClient TOS客户端封装
type TOSClient struct {
	client *tos.Tos
	opts   *TOSOptions
}

// TOSOptions TOS配置选项
type TOSOptions struct {
	AccessKey string
	SecretKey string
	Bucket    string
}

// NewTOSClient 创建新的TOS客户端
func NewTOSClient(opts *TOSOptions) (*TOSClient, error) {
	client, err := tos.NewTos(tos.WithBucket(opts.Bucket),
		tos.WithCredentials(&tos.BucketAccessKeyCredentials{
			BucketName: opts.Bucket,
			AccessKey:  opts.AccessKey,
		}), tos.WithRemotePSM(PSM))
	if err != nil {
		logs.Error("NewTOSClient failed: %v", err)
		return nil, fmt.Errorf("创建TOS客户端失败: %w", err)
	}

	return &TOSClient{
		client: client,
		opts:   opts,
	}, nil
}

// UploadFile 上传文件到TOS
func (t *TOSClient) UploadFile(ctx context.Context, path string, content []byte) (string, error) {
	// 上传文件
	reader := bytes.NewReader(content)
	err := t.client.PutObject(ctx, path, reader.Size(), reader)
	if err != nil {
		return "", fmt.Errorf("上传文件到TOS失败: %v", err)
	}

	// 生成访问URL
	url := GeneratePresignedURL(path)

	return url, nil
}

// GeneratePresignedURL 生成预签名URL，有效期1天
func GeneratePresignedURL(key string) string {
	return fmt.Sprintf("https://tosv.byted.org/obj/ecom-smartop/%s", key)
}

// UploadDumpRowToTOS Dump方式上传
func UploadDumpRowToTOS(ctx context.Context, paramsStr, path, apiId string) (string, error) {
	dpsToken, err := infsecc.GetToken(false)

	outPut := fmt.Sprintf("tos:///ecom-smartop/%s?accessKey=G344501U4D08SB3P290Y", path)
	req := &engine.WithParamsDumpReq{
		Request: &engine.WithParamsReq{
			ApiID:  apiId,
			Params: paramsStr,
			Option: []*engine.Option{
				{
					Id:   100,
					Val:  0,
					Val_: dpsToken,
				},
			},
		},
		Output:  outPut,
		Format:  "CSVWithNames",
		Timeout: 120,
	}

	resp, err := dp_invoker_engine.RawCall.QueryWithParamsDump(ctx, req)

	if err != nil {
		logs.CtxError(ctx, "QueryWithParamsDump failed, err: %v", err)
		return "", err
	}
	logs.CtxInfo(ctx, "QueryWithParamsDump succeed, resp: %v", resp)

	// 生成访问URL
	url := GeneratePresignedURL(path)
	return url, nil
}

// GetDefaultTOSClient 获取默认TOS客户端
func GetDefaultTOSClient() (*TOSClient, error) {
	// 这里使用默认配置，实际应该从配置文件或环境变量中读取
	opts := &TOSOptions{
		AccessKey: "G344501U4D08SB3P290Y",                     // 实际应从配置获取
		SecretKey: "88sYWj1qpAVrcFAUQ0YwlCGgB6NwwoZ89c9QdZw6", // 实际应从配置获取
		Bucket:    "ecom-smartop",                             // 示例bucket名
	}

	return NewTOSClient(opts)
}
