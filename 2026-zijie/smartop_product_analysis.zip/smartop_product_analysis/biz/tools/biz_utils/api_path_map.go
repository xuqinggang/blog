package biz_utils

import "code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"

type ProdPortraitApiPathData struct {
	ProdDetailPath  string
	ProdOverallPath string
	PieGraphPath    string
	Top9EnumPath    string
}

// 逻辑表已经达到上限，新建新的api
var prodDetailV2ApiPathData = &ProdPortraitApiPathData{
	ProdDetailPath:  "7506765733242635299",
	ProdOverallPath: "7503889345452000283",
	PieGraphPath:    "7506733322706453556",
	Top9EnumPath:    "7506723594395796520",
}

var prodDetailV3ApiPathData = &ProdPortraitApiPathData{
	ProdDetailPath:  "7571822358500049930",
	ProdOverallPath: "7571818176091096115",
	PieGraphPath:    "7506733322706453556",
	Top9EnumPath:    "7506723594395796520",
}

// 迁移新集群的api
var prodDetailBucketApiPathData = &ProdPortraitApiPathData{
	ProdDetailPath:  "7547646243451765800",
	ProdOverallPath: "7547636208793371648",
	PieGraphPath:    "7547645780388037647",
	Top9EnumPath:    "7547645657637536803",
}

// marketingEngineApiPathData is the api path data for marketing engine.
var marketingEngineApiPathData = &ProdPortraitApiPathData{
	ProdDetailPath:  "7597654835764249646",
	ProdOverallPath: "7597654752091997234",
	PieGraphPath:    "7597654644202030107",
	Top9EnumPath:    "7597654480062039090",
}

var ApiPathMap = map[dimensions.BizType]*ProdPortraitApiPathData{
	dimensions.BizType_VolumePrice: {
		ProdDetailPath:  "7444886720778208283",
		ProdOverallPath: "7446241341882844170",
	},
	dimensions.BizType_GuessBoostData: {
		ProdDetailPath:  "7487813335765795891",
		ProdOverallPath: "7487813335765795891",
	},
	dimensions.BizType_MarketProjectProduct:  prodDetailV2ApiPathData,
	dimensions.BizType_GreatValueBuyBigLink:  prodDetailV2ApiPathData,
	dimensions.BizType_GrowthProductStrategy: prodDetailV3ApiPathData,

	dimensions.BizType_ProdSelectAlgorithm:          prodDetailV3ApiPathData,
	dimensions.BizType_ProdSelectZeroChannelSubsidy: prodDetailV3ApiPathData,
	dimensions.BizType_ProdSelectManual:             prodDetailV3ApiPathData,
}

var ApiPathMapByEffectiveModule = map[string]*ProdPortraitApiPathData{
	"大促视图":          prodDetailV2ApiPathData,
	"货盘复盘-大盘":     prodDetailBucketApiPathData,
	"货盘复盘-商城加补": prodDetailBucketApiPathData,
	"货盘复盘-超值购":   prodDetailBucketApiPathData,
	"货盘复盘-秒杀":     prodDetailBucketApiPathData,
	"货盘复盘-大促":     prodDetailBucketApiPathData,
	"货盘复盘-政府补贴": prodDetailBucketApiPathData,
	"货盘复盘-猜喜":     prodDetailBucketApiPathData,
	"货盘复盘-搜索":     prodDetailBucketApiPathData,
	"外嵌营销引擎":      marketingEngineApiPathData,
}
