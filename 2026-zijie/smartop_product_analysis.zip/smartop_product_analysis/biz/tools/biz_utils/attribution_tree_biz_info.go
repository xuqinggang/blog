package biz_utils

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
)

type AttributionTreeBizInfo struct {
	ObjectBizType        dimensions.BizType                                   `json:"object_biz_type"`
	ObjectBizName        string                                               `json:"object_biz_name"`
	MultiDimOsTableName  string                                               `json:"multi_dim_os_table_name"`
	ReasonOsTableName    string                                               `json:"reason_os_table_name"`
	FlowChangeOsApi      string                                               `json:"flow_change_os_api"`
	AttributionTreeOsApi string                                               `json:"attribution_tree_os_api"`
	AttributionCntOsApi  string                                               `json:"attribution_cnt_os_api"`
	AttributionTreeMeta  *analysis.AttributionTreeMeta                        `json:"attribution_tree_meta"`
	FlowChangeMeta       *analysis.FlowChangeMeta                             `json:"flow_change_meta"`
	ReasonMeta           []*analysis.GetAttributionTreeMetaData               `json:"reason_meta"`
	BillionConfigMeta    *great_value_buy.GetGreatValueBuyDiagnosisConfigData `json:"billion_config_meta"`
}

type AttributionTreeDimIdMeta struct {
	GroupAttrs []int64 `json:"group_attrs"`
	Dimensions []int64 `json:"dimensions"`
}

type FlowChangeMetaDimIdMeta struct {
	GroupRelations []*DimIdDepend `thrift:"group_relations,1" frugal:"1,default,list<DimDepend>" json:"group_relations"`
	Dimensions     []int64        `thrift:"dimensions,2" frugal:"2,default,list<dimensions.DimensionInfo>" json:"dimensions"`
}

type DimIdDepend struct {
	MainDim  int64 `json:"main_dim"`
	ChildDim int64 `json:"child_dim"`
}

type ReasonDimIdMeta struct {
	Name            string                             `json:"name"`
	Children        []*analysis.GetAttributionMetaInfo `json:"children"`
	BizType         *dimensions.BizType                `json:"biz_type,omitempty"`
	Dimensions      []int64                            `json:"dimensions"`
	DrillDim        []*DimIdDepend                     `json:"drill_dim"`
	HasDetailTable  bool                               `json:"has_detail_table"`
	NeedConnectTree bool                               `json:"need_connect_tree"`
}
type DrillDimension struct {
	DimensionName string  `json:"dimension_name"`
	DrillList     []int64 `json:"drill_list"`
}
type GetGreatValueBuyDiagnosisTopicDimList struct {
	TargetType great_value_buy.GetGreatValueBuyDiagnosisTopicTargetType `json:"target_type"`
	DrillList  []int64                                                  `json:"drill_list"`
}
type BillionConfigMetaDimIdMeta struct {
	TreeDrill                 []*DrillDimension                                           `json:"tree_drill"`
	TopicList                 []*great_value_buy.GetGreatValueBuyDiagnosisTopic           `json:"topic_list"`
	CommonDiagnosisTargetList []*great_value_buy.GetGreatValueBuyDiagnosisTopicTargetInfo `json:"common_diagnosis_target_list"`
	TargetConfig              *great_value_buy.GetGreatValueBuyTargetConfig               `json:"target_config"`
	OptimizeActionConfig      *great_value_buy.OptimizeActionConfig                       `json:"optimize_action_config"`
	TopicDimList              []*GetGreatValueBuyDiagnosisTopicDimList                    `json:"topic_dim_list"`
}

func GetAttributionTreeBizInfoByBizType(ctx context.Context, bizType dimensions.BizType) (*AttributionTreeBizInfo, error) {
	bizInfoList, err := GetAttributionTreeBizInfo(ctx, &bizType)
	if err != nil {
		return nil, err
	}
	for _, info := range bizInfoList {
		if info.ObjectBizType == bizType {
			return info, nil
		}
	}
	return nil, errors.New("[GetAttributionTreeBizInfoByBizType]未找到这个bizType对应的元信息")
}

func GetAttributionTreeBizInfo(ctx context.Context, bizType *dimensions.BizType) ([]*AttributionTreeBizInfo, error) {
	daoAttrBizInfo, err := new(dao.AttributionTreeBizDao).GetAttributionTreeBizInfoList(ctx, bizType)
	if err != nil {
		return nil, err
	}
	var resList = make([]*AttributionTreeBizInfo, 0)
	for _, item := range daoAttrBizInfo {
		var res = &AttributionTreeBizInfo{
			ObjectBizType:        item.ObjectBizType,
			ObjectBizName:        item.ObjectBizName,
			MultiDimOsTableName:  item.MultiDimOsTableName,
			ReasonOsTableName:    item.ReasonOsTableName,
			FlowChangeOsApi:      item.FlowChangeOsApi,
			AttributionTreeOsApi: item.AttributionTreeOsApi,
			AttributionCntOsApi:  item.AttributionCntOsApi,
			AttributionTreeMeta: &analysis.AttributionTreeMeta{
				GroupAttrs: make([]*dimensions.DimensionInfo, 0),
				Dimensions: make([]*dimensions.DimensionInfo, 0),
			},
			FlowChangeMeta: &analysis.FlowChangeMeta{
				GroupRelations: make([]*analysis.DimDepend, 0),
				Dimensions:     make([]*dimensions.DimensionInfo, 0),
			},
			ReasonMeta:        make([]*analysis.GetAttributionTreeMetaData, 0),
			BillionConfigMeta: &great_value_buy.GetGreatValueBuyDiagnosisConfigData{},
		}

		// 从ctx中读取dimMap
		dimMap := biz_info.GetCtxIDLBizInfoAllDimMap(ctx)
		//var dimIdList = make([]int64, 0)
		//for id := range dimMap {
		//	dimIdList = append(dimIdList, id)
		//}
		//object := &dimension_service.DimensionService{DimensionListDao: new(dao.DimensionListDao), DimensionEnumDao: new(dao.DimensionEnumDao)}
		//dimMapIdl, err := object.GetDimensionMapByIDList(ctx, dimIdList)
		//if err != nil {
		//	logs.CtxError(ctx, "[GetAttributionTreeBizInfo]获取IDL版DimMap失败, err:%v", err.Error())
		//	return nil, err
		//}
		if item.AttributionTreeMeta != "" {
			// 解析归因树元信息
			var treeDimIdMeta = &AttributionTreeDimIdMeta{}
			err = sonic.UnmarshalString(item.AttributionTreeMeta, &treeDimIdMeta)
			if err != nil {
				logs.CtxError(ctx, "[GetAttributionTreeBizInfo]treeDimIdMeta反序列化失败,err: %v", err.Error())
				return nil, err
			}
			res.AttributionTreeMeta.Dimensions = TranDimId2Info(treeDimIdMeta.Dimensions, dimMap)
			res.AttributionTreeMeta.GroupAttrs = TranDimId2Info(treeDimIdMeta.GroupAttrs, dimMap)
		}
		if item.FlowChangeMeta != "" {
			// 解析流量变化元信息
			var flowChangeMeta = &FlowChangeMetaDimIdMeta{}
			err = sonic.UnmarshalString(item.FlowChangeMeta, &flowChangeMeta)
			if err != nil {
				logs.CtxError(ctx, "[GetAttributionTreeBizInfo]flowChangeMeta反序列化失败,err: %v", err.Error())
				return nil, err
			}
			res.FlowChangeMeta.Dimensions = TranDimId2Info(flowChangeMeta.Dimensions, dimMap)
			res.FlowChangeMeta.GroupRelations = TranDimDepend(flowChangeMeta.GroupRelations, dimMap)
		}
		if item.ReasonMeta != "" {
			// 解析原因元信息
			var reasonMeta = make([]*ReasonDimIdMeta, 0)
			err = sonic.UnmarshalString(item.ReasonMeta, &reasonMeta)
			if err != nil {
				logs.CtxError(ctx, "[GetAttributionTreeBizInfo]reasonMeta反序列化失败,err: %v", err.Error())
				return nil, err
			}
			res.ReasonMeta = TranReasonMeta(reasonMeta, dimMap)
		}
		// 解析billion配置
		if item.BillionConfigMeta != "" {
			var billionConfigMeta = &BillionConfigMetaDimIdMeta{}
			err = sonic.UnmarshalString(item.BillionConfigMeta, &billionConfigMeta)
			if err != nil {
				logs.CtxError(ctx, "[GetAttributionTreeBizInfo]billionConfigMeta反序列化失败,err: %v", err.Error())
				return nil, err
			}
			res.BillionConfigMeta = TranBilllionConfigMeta(billionConfigMeta, dimMap)
		} else {
			res.BillionConfigMeta = &great_value_buy.GetGreatValueBuyDiagnosisConfigData{}
		}
		resList = append(resList, res)
	}
	return resList, nil
}

func TranDimId2Info(dimList []int64, dimMap map[string]*dimensions.DimensionInfo) []*dimensions.DimensionInfo {
	var res = make([]*dimensions.DimensionInfo, 0)
	for _, dimId := range dimList {
		if dim, ok := dimMap[convert.ToString(dimId)]; ok {
			res = append(res, dim)
		}
	}
	return res
}

func TranDimDepend(dimIdDepend []*DimIdDepend, dimMap map[string]*dimensions.DimensionInfo) []*analysis.DimDepend {
	var res = make([]*analysis.DimDepend, 0)
	for _, dimId := range dimIdDepend {
		var depend = &analysis.DimDepend{}
		if dim, ok := dimMap[convert.ToString(dimId.MainDim)]; ok {
			depend.MainDim = dim
		}
		if dim, ok := dimMap[convert.ToString(dimId.ChildDim)]; ok {
			depend.ChildDim = dim
		}
		res = append(res, depend)
	}
	return res
}

func TranReasonMeta(reasonIdMeta []*ReasonDimIdMeta, dimMap map[string]*dimensions.DimensionInfo) []*analysis.GetAttributionTreeMetaData {
	res := make([]*analysis.GetAttributionTreeMetaData, 0)
	for _, reason := range reasonIdMeta {
		reasonMeta := &analysis.GetAttributionTreeMetaData{
			Name:            reason.Name,
			Children:        reason.Children,
			BizType:         reason.BizType,
			Dimensions:      TranDimId2Info(reason.Dimensions, dimMap),
			DrillDim:        TranDimDepend(reason.DrillDim, dimMap),
			HasDetailTable:  reason.HasDetailTable,
			NeedConnectTree: reason.NeedConnectTree,
		}
		res = append(res, reasonMeta)
	}
	return res
}

func TranBilllionConfigMeta(reason *BillionConfigMetaDimIdMeta, dimMap map[string]*dimensions.DimensionInfo) *great_value_buy.GetGreatValueBuyDiagnosisConfigData {
	TreeDrillValue := make([]*great_value_buy.DrillDimension, 0)
	for _, item := range reason.TreeDrill {
		TreeDrillValue = append(TreeDrillValue, &great_value_buy.DrillDimension{
			DimensionName: item.DimensionName,
			DrillList:     TranDimId2Info(item.DrillList, dimMap),
		})
	}
	TopicDimDrillValue := make([]*great_value_buy.GetGreatValueBuyDiagnosisTopicDimList, 0)
	for _, item := range reason.TopicDimList {
		TopicDimDrillValue = append(TopicDimDrillValue, &great_value_buy.GetGreatValueBuyDiagnosisTopicDimList{
			TargetType: item.TargetType,
			DrillList:  TranDimId2Info(item.DrillList, dimMap),
		})
	}

	reasonMeta := &great_value_buy.GetGreatValueBuyDiagnosisConfigData{
		TopicList:                 reason.TopicList,
		CommonDiagnosisTargetList: reason.CommonDiagnosisTargetList,
		TargetConfig:              reason.TargetConfig,
		TreeDrill:                 TreeDrillValue,
		OptimizeActionConfig:      reason.OptimizeActionConfig,
		TopicDimList:              TopicDimDrillValue,
	}
	return reasonMeta
}
