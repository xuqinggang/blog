package biz_utils

import (
	"bytes"
	"context"
	"encoding/gob"
	"encoding/json"
	"fmt"
	"reflect"
	"sort"
	"strings"
	"time"

	"github.com/sanity-io/litter"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/basic_info"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/jsonx"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/kite/kitex/pkg/connpool"
	"code.byted.org/overpass/cmp_ecom_shop_info/kitex_gen/cmp/ecom/shop_info"
	"code.byted.org/overpass/cmp_ecom_shop_info/rpc/cmp_ecom_shop_info"
	"code.byted.org/overpass/cmp_srv_goods/kitex_gen/cmp/srv/goods"
	"code.byted.org/overpass/cmp_srv_goods/rpc/cmp_srv_goods"
	"code.byted.org/overpass/common/option/calloption"
	"code.byted.org/overpass/common/option/clientoption"
	"code.byted.org/overpass/dp_invoker_engine/rpc/dp_invoker_engine"
	"code.byted.org/temai/go_lib/convert"
)

// SupplementLogicTableIdMap 补充LogicTableIdMap内容. 从GetProductSelectBizTypeApiConfig获取配置，并补充到LogicTableIdMap
func SupplementLogicTableIdMap() {
	ctx := context.Background()
	// 获取产品选择业务类型的API配置
	apiConfig, err := biz_info.GetProductSelectBizTypeApiConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, "SupplementLogicTableIdMap: failed to get product select biz type api config, err: %v", err)
		return
	}
	if apiConfig == nil {
		return
	}

	logs.CtxInfo(ctx, "SupplementLogicTableIdMap: got product select biz type api config, BizType2Api: %s", jsonx.ToString(apiConfig.BizType2Api))

	// 遍历BizType2Api映射
	for bizTypeStr, apiPath := range apiConfig.BizType2Api {
		// 将字符串转换为dimensions.BizType
		bizTypeInt := convert.ToInt64(bizTypeStr)
		bizType := dimensions.BizType(bizTypeInt)

		// 检查LogicTableIdMap中, 是否已存在该业务类型
		if _, exists := consts.LogicTableIdMap[bizType]; !exists {
			// 如果不存在, 添加新的映射
			consts.LogicTableIdMap[bizType] = []string{apiPath}
			logs.CtxInfo(ctx, "SupplementLogicTableIdMap: added new biz type '%d' with api path '%s'", bizType, apiPath)
		}
	}
}

func InitOneserviceClient() {
	opts := []clientoption.Option{
		clientoption.WithPSM("dp.invoker.engine"),
		clientoption.WithRPCTimeout(300 * time.Second),
		clientoption.WithLongConnection(connpool.IdleConfig{
			MaxIdlePerAddress: 100,
			MaxIdleGlobal:     100,
			MaxIdleTimeout:    600 * time.Second,
		}),
	}
	if env.IsPPE() {
		opts = append(opts, clientoption.WithCluster("ppe_default"))
	}
	dp_invoker_engine.InitDefaultClientOptions(opts...)
}

func SearchShopByIdOrName(ctx context.Context, shopId *int64, shopName *string, pageNo, pageSize int64) ([]basic_info.ShopBasicInfo, error) {
	req := &shop_info.GetShopInfoListRequest{
		Limit:  pageSize,
		Offset: (pageNo - 1) * pageSize,
	}
	if shopId != nil {
		req.ShopId = convert.ToStringPtr(convert.ToString(shopId))
	}
	if shopName != nil {
		req.ShopName = shopName
	}
	shopResp, err := cmp_ecom_shop_info.RawCall.GetShopInfoList(ctx, req, calloption.WithRPCTimeout(time.Second*5))
	if err != nil {
		logs.CtxError(ctx, "SearchShop return error, shopId:%v, shopName:%v, err:%v", shopId, shopName, err)
		return nil, err
	}
	if shopResp == nil {
		logs.CtxError(ctx, "SearchShop return nil, shopId:%v, shopName:%v", shopId, shopName)
		return nil, errors.New("店铺信息查询为空")
	}

	ret := make([]basic_info.ShopBasicInfo, 0)
	for _, item := range shopResp.Data {
		ret = append(ret, basic_info.ShopBasicInfo{
			Id:   item.GetShopId(),
			Name: item.GetShopName(),
		})
	}
	return ret, nil
}

// SearchBrandInfoByIdOrName 根据商品维表查询，搜索词为空时,查询范围是最近七天，否则为整表，品牌名取对应ID品牌最新一天的品牌名
func SearchBrandInfoByIdOrName(ctx context.Context, keyWord string, pageNo, pageSize int64, brandList []int64) ([]basic_info.BrandBasicInfo, error) {
	var params = map[string]interface{}{
		"key_word": keyWord,
		"limit":    pageSize,
		"offset":   (pageNo - 1) * pageSize,
	}
	newest, err := utils.GetNewestDay(ctx, consts.LogicTableDimensionArctic)
	if err != nil {
		return nil, err
	}
	newestTime, err := time.Parse(consts.FmtDate, newest)
	if err != nil {
		return nil, err
	}
	//if keyWord == "" {
	params["date_filter"] = true
	params["start_date"] = newestTime.AddDate(0, 0, -7).Format(consts.Fmt_Date)
	params["end_date"] = newest
	//}
	if len(brandList) > 0 {
		var sb strings.Builder
		sb.WriteString("brand_id in(")
		for i, id := range brandList {
			if i > 0 {
				sb.WriteString(",")
			}
			sb.WriteString(convert.ToString(id))
		}
		sb.WriteString(")")
		params["filter_param"] = sb.String()
	}

	var brandInfoList = make([]basic_info.BrandBasicInfo, 0)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, "7402093424712631306", param.SinkTable("brand_info"))
	f.ExeView(param.SourceTable("brand_info"), &brandInfoList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return brandInfoList, nil
}

func SearchProdInfoByIdOrName(ctx context.Context, keyWord string, pageNo, pageSize int64) ([]*basic_info.ProductBasicInfo, error) {
	var params = map[string]interface{}{
		"limit":  pageSize,
		"offset": (pageNo - 1) * pageSize,
	}
	if len(keyWord) > 0 {
		params["key_word"] = keyWord
	}
	newest, err := utils.GetNewestDay(ctx, consts.LogicTableAttributionInsightProdDi)
	if err != nil {
		return nil, err
	}
	params["date"] = newest
	var prodInfoList = make([]*basic_info.ProductBasicInfo, 0)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, "7412475459037889546", param.SinkTable("prod_info"))
	f.ExeView(param.SourceTable("prod_info"), &prodInfoList)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return prodInfoList, nil
}

func SearchInvestActivityInfoByIdOrName(ctx context.Context, keyWord string, pageNo, pageSize int64) ([]*dimensions.EnumElement, error) {
	var params = map[string]interface{}{
		"key_word": keyWord,
		"limit":    pageSize,
		"offset":   (pageNo - 1) * pageSize,
	}
	var activityList = make([]*dimensions.EnumElement, 0)
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, "7431842096014722057", param.SinkTable("activity_info"))
	f.ExeView(param.SourceTable("activity_info"), &activityList)
	app.Use(f.ToStack(ctx))
	_, err := app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return activityList, nil
}

func GetProductInfoByIdListSlice(ctx context.Context, productIds []int64) ([]*basic_info.ProductBasicInfo, error) {
	resSlice := utils.CutSLice(productIds, 50)
	basics := make([]*basic_info.ProductBasicInfo, 0)
	for _, v := range resSlice {
		items, err := GetProductInfoByIdList(ctx, v)
		if err != nil {
			logs.CtxError(ctx, "GetProductInfoByIdListSlice|err:%s", err.Error())
			continue
		}
		basics = append(basics, items...)
	}
	return basics, nil
}

func GetProductInfoByIdList(ctx context.Context, productIds []int64) ([]*basic_info.ProductBasicInfo, error) {
	goodsParamReq := make([]*goods.GetProductInfoParam, 0)
	for _, id := range productIds {
		goodsParamReq = append(goodsParamReq, &goods.GetProductInfoParam{
			ProductId: id,
		})
	}
	// 需要查询商品图片列表
	options := &goods.GetProductOption{
		NeedProductPic: true,
	}
	goodsReq := &goods.BatchGetProductRequest{
		Param:  goodsParamReq,
		Option: options,
	}
	var productInfoList = make([]*basic_info.ProductBasicInfo, 0)
	if len(goodsParamReq) == 0 {
		return productInfoList, nil
	}
	// 查询商品信息
	productResp, err := cmp_srv_goods.RawCall.BatchGetProduct2C(ctx, goodsReq)
	if productResp != nil {
		logs.CtxInfo(ctx, "商品信息为: "+litter.Sdump(productResp))
	}
	if err != nil || productResp == nil || len(productResp.Products) == 0 {
		logs.CtxWarn(ctx, "[GetProductInfoByIdList]获取商品详情失败,prodIds = %v", litter.Sdump(productIds))
		return productInfoList, nil
		//if err == nil {
		//	err = errors.New("调用下游BatchGetProduct2C获取商品信息失败")
		//}
		//logs.CtxError(ctx, "获取商品信息失败,err:"+err.Error())
		//return nil, err
	}
	for _, product := range productResp.Products {
		var imageList = make([]*goods.PicInfo, 0)
		if len(product.GetImgList()) == 0 {
			imageList = append(imageList, product.GetMainImg())
		} else {
			imageList = product.GetImgList()
		}
		productInfoList = append(productInfoList, &basic_info.ProductBasicInfo{
			Id:        fmt.Sprintf("%v", product.GetProductId()),
			Name:      product.GetName(),
			Images:    GetImgUrlList(ctx, imageList),
			MainImage: product.GetMainImg().GetUrl(),
		})
	}
	logs.CtxInfo(ctx, "商品信息列表为: "+litter.Sdump(productInfoList))
	return productInfoList, nil
}

func GetImgUrlList(ctx context.Context, images []*goods.PicInfo) []string {
	var res = make([]string, 0)
	for _, image := range images {
		res = append(res, image.GetUrl())
	}
	return res
}

// IsUseGrowthProductStrategyTable 是否需要映射回大盘
func IsUseGrowthProductStrategyTable(bizType dimensions.BizType) bool {
	bizTypeList := []dimensions.BizType{dimensions.BizType_GrowthProductStrategy, dimensions.BizType_A1GrowthProductStrategy, dimensions.BizType_A2GrowthProductStrategy,
		dimensions.BizType_A3GrowthProductStrategy, dimensions.BizType_BGrowthProductStrategy, dimensions.BizType_GuessProduct}
	for _, bizId := range bizTypeList {
		if bizId == bizType {
			return true
		}
	}
	return false
}

func SearchActivityDimensionsList(ctx context.Context, apiPath string, keyWord string, dependId string, pageNo, pageSize int64) ([]*dimensions.EnumElement, int64, error) {
	newest, err := utils.GetNewestDay(ctx, consts.LogicTableBigPromotionActivityInfoTable)
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, 0, err
	}
	ret := make([]*dimensions.EnumElement, 0)
	var params = map[string]interface{}{
		"key_word":  keyWord,
		"limit":     pageSize,
		"offset":    (pageNo - 1) * pageSize,
		"depend_id": dependId,
	}
	var list = make([]map[string]string, 0)
	params["date"] = newest
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("activity_review_dimensions_list"))
	f.ExeView(param.SourceTable("activity_review_dimensions_list"), &list)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, 0, err
	}
	if len(list) > 0 {
		for _, info := range list {
			if len(info["project_start_date"]) > 0 {
				subset := map[string]interface{}{
					"project_start_date": info["project_start_date"],
					"project_end_date":   info["project_end_date"],
					"base_start_date":    info["base_start_date"],
					"base_end_date":      info["base_end_date"],
				}
				// Serialize the subset map to JSON
				extraInfo, err := json.Marshal(subset)
				if err != nil {
					logs.CtxError(ctx, "Failed to marshal JSON: "+err.Error())
					return nil, 0, err
				}
				ret = append(ret, &dimensions.EnumElement{
					Code:      info["code"],
					Name:      info["name"],
					ExtraInfo: string(extraInfo),
				})
			} else {
				ret = append(ret, &dimensions.EnumElement{
					Code: info["code"],
					Name: info["name"],
				})
			}
		}
	}
	return ret, int64(len(ret)) + 0, nil
}

// GetAnalysisBizType 获取实际分析的bizType
func GetAnalysisBizType(bizType dimensions.BizType, dependBizType int64) dimensions.BizType {
	if dependBizType <= 0 {
		return bizType
	}
	return dimensions.BizType(dependBizType)
}

func GetEnumSearchPage(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest, appendParams map[string]interface{}, tableId, apiPath, totalApiPath string) ([]*dimensions.EnumElement, int64, error) {
	ret := make([]*dimensions.EnumElement, 0)

	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 20
	}

	var params = make(map[string]interface{})
	if len(req.EnumCodeList) > 0 {
		pageNum = 1
		pageSize = int64(len(req.EnumCodeList))
		params["enum_code_list"] = req.EnumCodeList
	}
	if req.SearchEnumName != nil && len(*req.SearchEnumName) > 0 {
		params["key_word"] = *req.SearchEnumName
	}

	newest, err := utils.GetNewestDay(ctx, tableId)
	if err != nil {
		return nil, 0, err
	}
	params["limit"] = pageSize
	params["offset"] = (pageNum - 1) * pageSize
	params["date"] = newest

	if len(appendParams) > 0 {
		for k, v := range appendParams {
			params[k] = v
		}
	}

	var totalInfo = make(map[string]int64)

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("res_data"))
	f.ExeView(param.SourceTable("res_data"), &ret)
	if len(totalApiPath) > 0 {
		f.ExeQueryInvokerRaw(params, totalApiPath, param.SinkTable("total_data"))

		f.ExeView(param.SourceTable("total_data"), &totalInfo)
	}
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, 0, err
	}

	total := int64(len(ret))
	if len(totalApiPath) > 0 {
		total = totalInfo["total"]
	}
	return ret, total, nil
}

func SortTargetList(targetList []*analysis.TargetCardEntity) {
	sort.Slice(targetList, func(i, j int) bool {
		return targetList[i].DisplayOrder < targetList[j].DisplayOrder
	})
}

type PartitionInfo struct {
	PartitionName string `json:"partition_name"`
	ProdCnt       int64  `json:"prod_cnt"`
}

// CheckPartitionExist 校验分区是否存在
func CheckPartitionExist(ctx context.Context, appendParams map[string]interface{}, tableId, apiPath string) (map[string]bool, error) {
	var params = make(map[string]interface{})
	newest, err := utils.GetNewestDay(ctx, tableId)
	if err != nil {
		return nil, err
	}
	params["date"] = newest

	if len(appendParams) > 0 {
		for k, v := range appendParams {
			params[k] = v
		}
	}

	var partitionInfo = make([]*PartitionInfo, 0)

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("res_data"))
	f.ExeView(param.SourceTable("res_data"), &partitionInfo)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	var existInfo = make(map[string]bool)
	for _, info := range partitionInfo {
		if info.ProdCnt > 0 {
			existInfo[info.PartitionName] = true
		}
	}
	return existInfo, nil
}

// DeepCopy 深拷贝到指定目标对象 ，如果src为nil，直接返回nil
func DeepCopy(src, dst interface{}) error {
	if src == nil || (reflect.ValueOf(src).Kind() == reflect.Ptr && reflect.ValueOf(src).IsNil()) {
		dstVal := reflect.ValueOf(dst)
		if dstVal.Kind() == reflect.Ptr && dstVal.Elem().CanSet() {
			dstVal.Elem().Set(reflect.Zero(dstVal.Elem().Type()))
		}
		return nil
	}
	var buf bytes.Buffer
	enc := gob.NewEncoder(&buf)
	dec := gob.NewDecoder(&buf)

	if err := enc.Encode(src); err != nil {
		return err
	}

	return dec.Decode(dst)
}
