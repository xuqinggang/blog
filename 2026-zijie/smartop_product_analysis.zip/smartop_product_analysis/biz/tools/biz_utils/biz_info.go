package biz_utils

import (
	"context"
	"strconv"

	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"github.com/bytedance/sonic"
)

type BizMetaInfo struct {
	BizType                  dimensions.BizType                  `json:"biz_type"`
	BizName                  string                              `json:"biz_name"`
	MaxRangeDay              int64                               `json:"max_range_day"`    // 最大时间跨度（天）
	SelectRangeDay           int64                               `json:"select_range_day"` // 最大可选时间（天）
	DateRangeInfo            []*dimensions.DateRange             `json:"date_range_info"`  // 时间选择范围信息
	TableName                string                              `json:"table_name"`       // os逻辑表
	LogicTableList           []string                            `json:"logic_table_list"` // 在线关联的逻辑表列表
	OsApi                    string                              `json:"os_api"`           // os api
	TableID                  string                              `json:"table_id"`         // os逻辑表ID
	ThresholdAttrMeta        []*dimensions.ThresholdAttrMeta     `json:"threshold_attr_meta"`
	DefaultGroupAttrs        []*dimensions.SelectedDimensionInfo `json:"default_group_attrs"`          // 默认的多维分析数据
	DaysTypeList             []consts.DateType                   `json:"days_type_list"`               // 支持分析的days_type
	UserDimensionCode        string                              `json:"user_dimension_code"`          // 业务线支持的角色ID列表
	RequiredDimInfo          []*dimensions.SelectedDimensionInfo `json:"required_dim_info"`            // 必须的筛选项
	EffectModule             string                              `json:"effect_module"`                // 表现的模块
	MultiDimApiID            string                              `json:"multi_dim_api_id"`             // 多维分析api id
	TargetCardApiID          string                              `json:"target_card_api_id"`           // 指标卡api id
	TargetCardOverallApiID   string                              `json:"target_card_overall_api_id"`   // 指标卡大盘api id
	ProdListApiID            string                              `json:"prod_list_api_id"`             // 商品列表 api id
	TargetCardUvApiID        string                              `json:"target_card_uv_api_id"`        //  UV指标卡 api id
	ProdDetailExportType     int64                               `json:"prod_detail_export_type"`      // 商品画像导出模式
	ProdPortraitDims         []int64                             `json:"prod_portrait_dims"`           // 商品画像顶部筛选维度
	ProdPortraitPieGraphDims []int64                             `json:"prod_portrait_pie_graph_dims"` // 商品画像饼图维度
	ConclusionTargetMap      map[string][]string                 `json:"conclusion_target_map"`        // 结论指标清单
	HiddenModule             []string                            `json:"hidden_module"`                // 隐藏模块
	DefaultFunnelMeta        []*analysis.CoreOverviewFunnelData  `json:"default_funnel_meta"`          // 默认的漏洞图配置
	DependBizID              int64                               `json:"depend_biz_id"`
	DataDelayDay             int64                               `json:"data_delay_day"` // 业务线数据延迟天数
}

func GetBizMetaInfo(ctx context.Context, bizType dimensions.BizType) (*BizMetaInfo, context.Context, error) {
	daoBizInfo, err := new(dao.DimensionBizListDao).GetBizInfo(ctx, bizType)
	if err != nil {
		return nil, ctx, err
	}
	bizMetaInfo, err := transBizDao2BizMeta(ctx, daoBizInfo)
	if err != nil {
		return nil, ctx, err
	}

	if bizMetaInfo != nil {
		daysTypeListTmp := biz_info.GetCtxBizInfoDaysTypeList(ctx)
		if len(daysTypeListTmp) > 0 {
			bizMetaInfo.DaysTypeList = daysTypeListTmp
		}
		ctx = context.WithValue(ctx, consts.CtxBizInfoOSApiID, bizMetaInfo.OsApi)
		ctx = context.WithValue(ctx, consts.CtxBizInfoOSTableName, bizMetaInfo.TableName)
		ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, bizMetaInfo.DaysTypeList)
		ctx = context.WithValue(ctx, consts.CtxBizMetaInfo, bizMetaInfo)
	}
	return bizMetaInfo, ctx, nil
}

func GetBizMetaInfoMap(ctx context.Context) (map[dimensions.BizType]*BizMetaInfo, error) {
	bizMap := make(map[dimensions.BizType]*BizMetaInfo)

	daoBizList, err := new(dao.DimensionBizListDao).GetBizList(ctx)
	if err != nil {
		return nil, err
	}

	if len(daoBizList) > 0 {
		for _, info := range daoBizList {
			bizMetaInfo, err := transBizDao2BizMeta(ctx, info)
			if err != nil {
				return nil, err
			}

			bizMap[bizMetaInfo.BizType] = bizMetaInfo
		}
	}

	return bizMap, nil
}

func transBizDao2BizMeta(ctx context.Context, daoInfo *dao.BizInfo) (*BizMetaInfo, error) {
	ret := &BizMetaInfo{}
	if daoInfo == nil {
		return ret, nil
	}
	ret.BizType = daoInfo.BizType
	ret.BizName = daoInfo.BizName
	ret.MaxRangeDay = daoInfo.MaxRangeDay
	ret.DataDelayDay = daoInfo.DataDelayDay
	ret.ProdDetailExportType = daoInfo.ProdDetailExportType
	ret.LogicTableList = make([]string, 0)

	if len(daoInfo.LogicTableList) > 0 {
		err := sonic.UnmarshalString(daoInfo.LogicTableList, &ret.LogicTableList)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]LogicTableList = %s, err = %v+", daoInfo.LogicTableList, err)
			return nil, err
		}
	}

	if len(daoInfo.DateRangeInfo) > 0 {
		err := sonic.UnmarshalString(daoInfo.DateRangeInfo, &ret.DateRangeInfo)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]DateRangeInfo = %s, err = %v+", daoInfo.DateRangeInfo, err)
			return nil, err
		}
	}
	if len(ret.DateRangeInfo) > 0 {
		for _, d := range ret.DateRangeInfo {
			if d.DateType == base.DateType_DAY {
				ret.SelectRangeDay = d.MaxDateRange
			}
		}
	}
	ret.TableName = daoInfo.OsTableName
	conf, _ := tcc.GetBigLinkClusterSwitchConf(ctx)
	if conf != nil && conf.Switch && ret.BizType == dimensions.BizType_GreatValueBuyBigLink {
		ret.TableName = conf.NewLogicTableName
	}
	ret.OsApi = daoInfo.OsApiID
	ret.TableID = daoInfo.OsTableID
	ret.TargetCardUvApiID = daoInfo.TargetCardUvApiID
	if len(daoInfo.ThresholdAttrMeta) > 0 {
		err := sonic.UnmarshalString(daoInfo.ThresholdAttrMeta, &ret.ThresholdAttrMeta)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]ThresholdAttrMeta = %s, err = %v+", daoInfo.ThresholdAttrMeta, err)
			return nil, err
		}
	}

	if len(daoInfo.DefaultGroupAttrs) > 0 {
		err := sonic.UnmarshalString(daoInfo.DefaultGroupAttrs, &ret.DefaultGroupAttrs)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]DefaultGroupAttrs = %s, err = %v+", daoInfo.DefaultGroupAttrs, err)
			return nil, err
		}
	}

	if len(daoInfo.DaysTypeList) > 0 {
		err := sonic.UnmarshalString(daoInfo.DaysTypeList, &ret.DaysTypeList)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]DaysTypeList = %s, err = %v+", daoInfo.DaysTypeList, err)
			return nil, err
		}
	}

	ret.UserDimensionCode = daoInfo.UserDimensionCode
	ret.EffectModule = daoInfo.EffectModule

	if len(daoInfo.RequiredDimInfo) > 0 {
		err := sonic.UnmarshalString(daoInfo.RequiredDimInfo, &ret.RequiredDimInfo)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]RequiredDimInfo = %s, err = %v+", daoInfo.RequiredDimInfo, err)
			return nil, err
		}
	}

	ret.MultiDimApiID = daoInfo.MultiDimApiID
	ret.TargetCardApiID = daoInfo.TargetCardApiID
	ret.TargetCardOverallApiID = daoInfo.TargetCardOverallApiID
	ret.ProdListApiID = daoInfo.ProdListApiID
	ret.DependBizID = daoInfo.DependBizID

	if len(daoInfo.ConclusionTargetMap) > 0 {
		err := sonic.UnmarshalString(daoInfo.ConclusionTargetMap, &ret.ConclusionTargetMap)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]ConclusionTargetMap = %s, err = %v+", daoInfo.ConclusionTargetMap, err)
			return nil, err
		}
	}

	if len(daoInfo.HiddenModule) > 0 {
		err := sonic.UnmarshalString(daoInfo.HiddenModule, &ret.HiddenModule)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]HiddenModule = %s, err = %v+", daoInfo.HiddenModule, err)
			return nil, err
		}
	}

	if len(daoInfo.DefaultFunnelMeta) > 0 {
		err := sonic.UnmarshalString(daoInfo.DefaultFunnelMeta, &ret.DefaultFunnelMeta)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]DefaultFunnelMeta = %s, err = %v+", daoInfo.DefaultFunnelMeta, err)
			return nil, err
		}
	}

	if len(daoInfo.ProdPortraitDims) > 0 {
		err := sonic.UnmarshalString(daoInfo.ProdPortraitDims, &ret.ProdPortraitDims)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]ProdPortraitDims = %s, err = %v+", daoInfo.ProdPortraitDims, err)
			return nil, err
		}
	}

	if len(daoInfo.ProdPortraitPieGraphDims) > 0 {
		err := sonic.UnmarshalString(daoInfo.ProdPortraitPieGraphDims, &ret.ProdPortraitPieGraphDims)
		if err != nil {
			logs.CtxError(ctx, "[transBizDao2BizMeta]ProdPortraitPieGraphDims = %s, err = %v+", daoInfo.ProdPortraitPieGraphDims, err)
			return nil, err
		}
	}

	return ret, nil
}

// GetDimMapAndColMapByBiz 根据业务线获取维度map
func GetDimMapAndColMapByBiz(ctx context.Context, bizType dimensions.BizType) (dimMap map[int64]*dao.DimensionInfo, dimColMap map[string]*dao.DimensionInfo, err error) {
	dimColMapKey := consts.CtxBizInfoDimColMapPrefix + strconv.Itoa(int(bizType))
	dimMapKey := consts.CtxBizInfoDimMapPrefix + strconv.Itoa(int(bizType))
	if ctx.Value(dimColMapKey) != nil && ctx.Value(dimMapKey) != nil {
		dimMap = ctx.Value(dimMapKey).(map[int64]*dao.DimensionInfo)
		dimColMap = ctx.Value(dimColMapKey).(map[string]*dao.DimensionInfo)
		return
	}
	dimensionListDao := new(dao.DimensionListDao)
	dimList, err := dimensionListDao.GetDimensionList(ctx, bizType)
	if err != nil {
		logs.CtxError(ctx, "[GetDimMapAndColMapByBiz]获取map失败，err=%v+", err)
		return nil, nil, err
	}
	dimMap = make(map[int64]*dao.DimensionInfo)
	dimColMap = make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	context.WithValue(ctx, dimMapKey, dimMap)
	context.WithValue(ctx, dimColMapKey, dimColMap)
	return
}

func GetBizMetaInfoFromContext(ctx context.Context) *BizMetaInfo {
	if ret, ok := ctx.Value(consts.CtxBizMetaInfo).(*BizMetaInfo); ok {
		return ret
	}
	return nil
}
