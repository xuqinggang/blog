package prod_review_tool

import (
	"code.byted.org/aweme-go/ajson"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_table_domain/extension/common"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/ab"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/dal/db/model"
	"code.byted.org/ecom/smartop_product_analysis/dal/db/query"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/times"
	"code.byted.org/gopkg/logs"
	"context"
	"fmt"
	"strings"
	"time"
)

type TargetIndex struct {
	Destination        float64             // 目标
	DestinationDisplay string              // 目标展示值
	FieldConfig        *dao.TargetMetaInfo // 指标配置
}

func GetSubQuerySql(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, addFilterDimensions []*dimensions.SelectedDimensionInfo,
	dimMap map[int64]*dao.DimensionInfo, startDate, endDate string) string {
	for _, dimItem := range addFilterDimensions {
		// 统一动态维度
		if _, ok := consts.DimensionIdDynamicDimensionInfoMap[dimItem.Id]; ok {
			querySql, _ := base_struct_condition.GetPackageProdCql(ctx, req.BizType, addFilterDimensions, startDate, endDate, dimMap, true)
			return querySql.Compile()
		}
		// 招商活动
		if dimItem.Id == consts.ActivityIdRelationByDay || dimItem.Id == consts.SignupStatusCodeRelationByDay {
			querySql, _ := base_struct_condition.GetActivityAggCQL(ctx, req.BizType, addFilterDimensions, dimMap, startDate, endDate)
			return querySql.Compile()
		}
	}
	return ""
}

// GetTargetConfig 指定时间，查询目标配置。map-key格式：指标_大组 or 指标_类目，year：2024、month：08
func GetTargetConfig(ctx context.Context, bizId int32, tm int64) (wholeMap map[string]*TargetIndex, classMap map[string]map[string]*TargetIndex, categoryMap map[string]map[string]*TargetIndex, err error) {
	// 查询目标配置
	details, err := query.TargetIndexDetails(ctx).WithContext(ctx).Where(
		query.TargetIndexDetails(ctx).BizID.Eq(bizId),
		query.TargetIndexDetails(ctx).Valid.Eq(1),
		query.TargetIndexDetails(ctx).Year.Eq(times.Format(time.Unix(tm, 0), "2006")),
		query.TargetIndexDetails(ctx).Month.Eq(times.Format(time.Unix(tm, 0), "01")),
	).Find()
	if err != nil {
		return
	}

	// 查询指标配置
	targetAttrs := make([]*dao.TargetMetaInfo, 0)
	targetAttrs, err = GetTargetAttributes(ctx, bizId)
	if err != nil {
		return
	}

	return toResp(ctx, details, targetAttrs)
}

func GetTargetAttributes(ctx context.Context, bizId int32) ([]*dao.TargetMetaInfo, error) {
	var res = make([]*dao.TargetMetaInfo, 0)
	err := mysql.DB(ctx).Raw(`
		select  attribute_name as name,
				display_name,
				tips,
				display_order,
				target_precision,
				calc_agg_method,
				calc_agg_expr,
				calc_type,
				value_type,
				value_unit,
				attribute_type,
				is_compute_percent = 1  as is_compute_percent,
				is_larger_advantage = 1  as is_larger_advantage,
				is_potential_customer_target = 1 as is_potential_customer_target,
				is_distribution = 1 as is_distribution,
				is_target_distribution = 1 as is_target_distribution, 
				need_second_query = 1 as need_second_query,
				is_use_pp = 1 as is_use_pp,
				effect_module,
				is_default_show = 1  as is_default_show,
				is_show = 1 as is_show
		from    target_attribute_info
		where   biz_id = ?
		and     is_delete=0`, bizId).Scan(&res).Error
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	logs.CtxInfo(ctx, "GetTargetAttributes|bizId:%d, res:%s", bizId, ajson.ToString(res))
	return res, nil
}

func toResp(ctx context.Context, details []*model.TargetIndexDetails, attrs []*dao.TargetMetaInfo) (map[string]*TargetIndex, map[string]map[string]*TargetIndex, map[string]map[string]*TargetIndex, error) {
	wholeMap := make(map[string]*TargetIndex)
	classMap := make(map[string]map[string]*TargetIndex)
	categoryMap := make(map[string]map[string]*TargetIndex)

	// 指标配置信息
	cfgMap := make(map[string]*dao.TargetMetaInfo)
	for _, v := range attrs {
		if v == nil {
			continue
		}
		cfgMap[v.Name] = v
	}

	for _, detail := range details {
		if detail == nil {
			continue
		}
		if detail.Dimension == "" {
			wholeMap[detail.IdxName] = toIndexInfo(ctx, detail.Destination, cfgMap[detail.IdxName])
		} else if detail.Dimension == common.DimensionClass {
			if classMap[detail.IdxName] == nil {
				classMap[detail.IdxName] = make(map[string]*TargetIndex)
			}
			classMap[detail.IdxName][detail.DimensionCode] = toIndexInfo(ctx, detail.Destination, cfgMap[detail.IdxName])
		} else if detail.Dimension == common.DimensionCategory {
			if categoryMap[detail.IdxName] == nil {
				categoryMap[detail.IdxName] = make(map[string]*TargetIndex)
			}
			categoryMap[detail.IdxName][detail.DimensionCode] = toIndexInfo(ctx, detail.Destination, cfgMap[detail.IdxName])
		}
	}
	return wholeMap, classMap, categoryMap, nil
}

func toIndexInfo(ctx context.Context, destination float64, info *dao.TargetMetaInfo) *TargetIndex {
	var displayValue string
	var err error
	if info != nil {
		displayValue, err = framework_udf.GetBriefMetricDisplayValue(destination, info.ValueType, info.ValueUnit, info.TargetPrecision)
		if err != nil {
			logs.CtxError(ctx, "GetTargetConfig|error:%s", err.Error())
		}
	}

	// 展示value兜底
	if displayValue == "" {
		displayValue = fmt.Sprintf("%v", destination)
	}

	return &TargetIndex{
		Destination:        destination,
		DestinationDisplay: displayValue,
		FieldConfig:        info,
	}
}

func AnalysisRowToMultiRow(ctx context.Context, req *common_request.CommonAnalysisRequest, rows []*analysis.MultiDimFullListRow) []*common_response.RowData {
	multiDimRows := make([]*common_response.RowData, 0)
	for _, row := range rows {
		if row == nil {
			continue
		}
		multiDimRow := &common_response.RowData{
			DimensionName:  row.DisplayName,
			DimensionCode:  row.EnumValue,
			TargetList:     row.TargetList,
			ChildrenRows:   AnalysisRowToMultiRow(ctx, req, row.Children),
			DimensionValue: row.DimKey,
			ProdTagCode:    row.ProdTagCode,
		}
		multiDimRows = append(multiDimRows, multiDimRow)
	}
	return multiDimRows
}

// 计算显著性
func CalSignificance(ctx context.Context, baseTargetMap map[string]*analysis.TargetCardEntity, expTargetMap map[string]*analysis.TargetCardEntity) (map[string]bool, map[string]struct{}) {
	res := make(map[string]bool)
	processTargetMap := make(map[string]struct{})

	if baseTargetMap == nil || expTargetMap == nil {
		return res, processTargetMap
	}

	for targetName, target := range expTargetMap {
		if target == nil || targetName == "" {
			logs.CtxError(ctx, "[calSignificance] target is empty")
			continue
		}

		var isSignificance bool
		var err error

		numberTargetName, isNumber := strings.CutPrefix(target.Name, consts.SignificancePrefixVariance)
		rateTargetName, isRate := strings.CutPrefix(target.Name, consts.SignificancePrefixRate)

		if isNumber && numberTargetName != "" {

			cntProcessTargetName := consts.SignificancePrefixCnt + numberTargetName
			avgProcessTargetName := consts.SignificancePrefixAvg + numberTargetName
			varianceProcessTargetName := consts.SignificancePrefixVariance + numberTargetName

			baseSignificanceCnt, baseHasCnt := baseTargetMap[cntProcessTargetName]
			baseSignificanceAvg, baseHasAvg := baseTargetMap[avgProcessTargetName]
			baseSignificanceVariance, baseHasVariance := baseTargetMap[varianceProcessTargetName]

			expSignificanceCnt, expHasCnt := expTargetMap[cntProcessTargetName]
			expSignificanceAvg, expHasAvg := expTargetMap[avgProcessTargetName]
			expSignificanceVariance, expHasVariance := expTargetMap[varianceProcessTargetName]

			if !(baseHasCnt && baseHasAvg && baseHasVariance && expHasCnt && expHasAvg && expHasVariance) ||
				baseSignificanceCnt == nil || expSignificanceCnt == nil ||
				baseSignificanceAvg == nil || expSignificanceAvg == nil ||
				baseSignificanceVariance == nil || expSignificanceVariance == nil {
				logs.CtxError(ctx, "[calSignificance] SignificanceNumberType95Judge params invalid")
				continue
			}

			isSignificance, err = ab.SignificanceNumberType95Judge(&ab.SignificanceNumberParam{
				BaseAvg:      baseSignificanceAvg.Value,
				ExpAvg:       expSignificanceAvg.Value,
				BaseVariance: baseSignificanceVariance.Value,
				ExpVariance:  expSignificanceVariance.Value,
				BaseCnt:      baseSignificanceCnt.Value,
				ExpCnt:       expSignificanceCnt.Value,
			})

			if err != nil {
				logs.CtxError(ctx, "[calSignificance] targetName=%s, err: %v", target.Name, err)
				continue
			}

			// 过程指标名返回给方法外层便于剔除
			processTargetMap[cntProcessTargetName] = struct{}{}
			processTargetMap[avgProcessTargetName] = struct{}{}
			processTargetMap[varianceProcessTargetName] = struct{}{}

			res[numberTargetName] = isSignificance
		} else if isRate && rateTargetName != "" {
			cntProcessTargetName := consts.SignificancePrefixCnt + rateTargetName
			rateProcessTargetName := consts.SignificancePrefixRate + rateTargetName

			baseSignificanceCnt, baseHasCnt := baseTargetMap[cntProcessTargetName]
			baseSignificanceRatio, baseHasRatio := baseTargetMap[rateProcessTargetName]

			expSignificanceCnt, expHasCnt := expTargetMap[cntProcessTargetName]
			expSignificanceRatio, expHasRatio := expTargetMap[rateProcessTargetName]

			if !(baseHasCnt && baseHasRatio && expHasCnt && expHasRatio) ||
				baseSignificanceCnt == nil || expSignificanceCnt == nil ||
				baseSignificanceRatio == nil || expSignificanceRatio == nil {
				logs.CtxError(ctx, "[calSignificance] SignificanceRatioType95Judge params invalid")
				continue
			}

			isSignificance, err = ab.SignificanceRatioType95Judge(&ab.SignificanceRatioParam{
				BaseRatio: baseSignificanceRatio.Value,
				ExpRatio:  expSignificanceRatio.Value,
				BaseCnt:   baseSignificanceCnt.Value,
				ExpCnt:    expSignificanceCnt.Value,
			})

			if err != nil {
				logs.CtxError(ctx, "[calSignificance] targetName=%s, err: %v", target.Name, err)
				continue
			}

			// 过程指标名返回给方法外层便于剔除
			processTargetMap[cntProcessTargetName] = struct{}{}
			processTargetMap[rateProcessTargetName] = struct{}{}

			res[rateTargetName] = isSignificance
		}
	}

	return res, processTargetMap
}
