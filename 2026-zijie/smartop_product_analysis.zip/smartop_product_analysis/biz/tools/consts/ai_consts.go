package consts

const (
	SyncMapSessionIdKey          = "session_id"
	SyncMapDataListKey           = "data_list"
	SyncMapTodoListKey           = "todo_list"
	SyncMapMetricGroupKey        = "metric_groups"
	SyncMapStrategyConfigListKey = "strategy_config_list"
	SyncMapStrategyDetailKey     = "strategy_detail"
	SyncMapFlightInfoKey         = "flight_info"
	SyncMapParentMessageIdKey    = "parent_message_id"
)
