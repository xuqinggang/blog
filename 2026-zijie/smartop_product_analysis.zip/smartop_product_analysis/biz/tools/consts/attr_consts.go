package consts

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
)

const (
	AttrNamePayOrdCnt = "pay_ord_cnt"
	AttrNameOPM       = "opm"
	AttrNameShowPV    = "show_pv"
	AttrNameClickPV   = "click_pv"
	AttrNamePayUV     = "pay_uv"
	AttrNamePayGMV    = "pay_gmv"

	AttrNameShowProdCnt      = "show_prod_cnt"
	AttrNameProdPayShowRate  = "prod_pay_show_rate"
	AttrNamePayProdAvgOrdCnt = "prod_avg_ord_cnt"
)

var AttrNameTableColMap = map[string]map[dimensions.FilterDimCategory]string{
	AttrNamePayOrdCnt: {
		dimensions.FilterDimCategory_None:       "unfreeprod_pay_ord_cnt_1d",
		dimensions.FilterDimCategory_NewUser:    "newuser_unfreeprod_pay_ord_cnt_1d",
		dimensions.FilterDimCategory_RecallUser: "recalluser_unfreeprod_pay_ord_cnt_1d",
	},
	AttrNameShowPV: {
		dimensions.FilterDimCategory_None:       "prod_show_cnt_1d",
		dimensions.FilterDimCategory_NewUser:    "if(ecom_content_user_life_cycle_new in ('平台潜客','未知'),prod_show_cnt_1d,0)",
		dimensions.FilterDimCategory_RecallUser: "if(ecom_content_user_life_cycle_new in ('流失用户','成长期沉默','成熟期沉默'),prod_show_cnt_1d,0)",
	},
	AttrNameOPM: {
		dimensions.FilterDimCategory_None: "opm",
	},
	AttrNamePayUV: {
		dimensions.FilterDimCategory_None:       "pay_user_sketch_1d",
		dimensions.FilterDimCategory_NewUser:    "newuser_pay_user_sketch_1d",
		dimensions.FilterDimCategory_RecallUser: "recalluser_pay_user_sketch",
	},
	AttrNamePayGMV: {
		dimensions.FilterDimCategory_None:       "pay_ord_amt_1d",
		dimensions.FilterDimCategory_NewUser:    "newuser_pay_ord_amt_1d",
		dimensions.FilterDimCategory_RecallUser: "recalluser_pay_ord_amt_1d",
	},
	AttrNameClickPV: {
		dimensions.FilterDimCategory_None:       "prod_clk_cnt_1d",
		dimensions.FilterDimCategory_NewUser:    "if(ecom_content_user_life_cycle_new in ('平台潜客','未知'),prod_clk_cnt_1d,0) as click_pv",
		dimensions.FilterDimCategory_RecallUser: "if(ecom_content_user_life_cycle_new in ('流失用户','成长期沉默','成熟期沉默'),prod_clk_cnt_1d,0) as click_pv",
	},
}

var standardBizTableColMap = map[dimensions.BizType]map[string]string{
	dimensions.BizType_GreatValueBuy: {
		AttrNamePayOrdCnt: "pay_ord_cnt_1d",
	},
	dimensions.BizType_ProdSeckill: {
		AttrNamePayOrdCnt: "pay_ord_cnt_1d",
	},
	dimensions.BizType_MorningMarketProduct: {
		AttrNamePayOrdCnt: "pay_ord_cnt_1d",
	},
	dimensions.BizType_DouyineCommerce: {
		AttrNamePayOrdCnt: "unfreeprod_pay_ord_cnt",
		AttrNameShowPV:    "prod_show_pv",
		AttrNameClickPV:   "prod_click_pv",
		AttrNamePayGMV:    "unfreeprod_pay_amt",
	},
	dimensions.BizType_DouyineMallCommerce: {
		AttrNamePayOrdCnt: "unfreeprod_pay_ord_cnt",
		AttrNameShowPV:    "prod_show_pv",
		AttrNameClickPV:   "prod_click_pv",
		AttrNamePayGMV:    "unfreeprod_pay_amt",
	},
	dimensions.BizType_BrandTrial: {
		AttrNamePayOrdCnt: "v2_pay_ord_cnt_1d",
		AttrNameShowPV:    "prod_show_cnt_1d",
		AttrNameClickPV:   "prod_clk_cnt_1d",
		AttrNamePayGMV:    "v2_pay_ord_amt_1d",
	},
	dimensions.BizType_MatchingBrain: {
		AttrNamePayOrdCnt: "td_pay_order",
		AttrNameShowPV:    "prod_show_cnt_1d",
		AttrNameClickPV:   "pick_prod_cnt_1d",
		AttrNamePayGMV:    "cl_pay_amt_1d",
	},
	dimensions.BizType_MixProduct: {
		AttrNamePayOrdCnt: "caliber_attr_pay_ord_cnt_1d",
		AttrNameShowPV:    "show_pv_1d",
		AttrNameClickPV:   "click_pv_1d",
		AttrNamePayGMV:    "caliber_attr_pay_amt_1d",
	},
}

func GetTableCol(name string, category dimensions.FilterDimCategory, bizType dimensions.BizType) string {
	if bizColMap := standardBizTableColMap[bizType]; bizColMap != nil {
		if col := bizColMap[name]; len(col) > 0 {
			return col
		}
	}

	cateNameMap := AttrNameTableColMap[name]
	if len(cateNameMap) > 0 {
		var outName string
		outName, exist := cateNameMap[category]
		if !exist {
			outName = cateNameMap[dimensions.FilterDimCategory_None]
		}
		return outName
	}

	return name
}
