package consts

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/product_select"
)

// 维度ID列表
const (
	IsNewPayCntDim    = "10001" // 是否新客首购商品
	IsRecallPayCntDim = "10002" // 是否流失召回首购商品

	BTMFirstEntranceDim  = "10006" // btm一级入口
	BTMSecondEntranceDim = "10007" // btm二级入口

	UserDemoGroupDim = "10020" // 八大人群
	GenderDim        = "10023" // 性别

	IndustryDim   = "10025" // 一级类目
	FirstCateDim  = "10026" // 一级类目
	SecondCateDim = "10027" // 二级类目
	LeafCateDim   = "10028" // 叶子类目

	PriceRangeDim = "10031" // 绝对值价格带

	BillionChannelDim  = "10046" // 频道ID/名称
	BillionActivityDim = "10047" // 活动ID/名称
	ProdIDDim          = "10048" // 商品ID
	ProdIDSingleDim    = "10117" // 商品ID - d单选

	OutPriceChangeTypeDim = "10050" // 站外价格力
	XdPriceChangeTypeDim  = "10051" // 站内价格力
	VblineGroupABDim      = "10059" // A/B 组
	FirstAVblineDim       = "10060" // A组一级行业
	SecondAVblineDim      = "10061" // A组二级行业
	SecondBVblineDim      = "10062" // B组二级行业

	FourthAGroupProdDim = "10064" // 是否A组任务包商品
	FourthBGroupProdDim = "10065" // 是否B组任务包商品

	IsRcmdPoolProdDim   = "10085" // 是否猜喜底池商品
	FirstMgtCateDim     = "10086" // 一级管理类目
	SecondMgtCateDim    = "10087" // 二级管理类目
	ThirdMgtCateDim     = "10088" // 三级管理类目
	FirstVblineCodeDim  = "10089" // 一级子赛道
	SecondVblineCodeDim = "10090" // 二级子赛道
	ThirdVblineCodeDim  = "10091" // 三级子赛道
	FourthVblineCodeDim = "10092" // 四级子赛道
	LeafVblineCodeDim   = "10093" // 叶子子赛道

	FirstVblineIDDim  = "10414" // 一级子赛道
	SecondVblineIDDim = "10415"
	ThirdVblineIDDim  = "10418"
	FourthVblineIDDim = "10419"

	CustomProductPool = "10102" // 自定义货盘
	PushConvertType   = "10231"
	PushAuditTag      = "10232"

	MainProjectId  = "91003"
	MainActivityId = "91001"
	ActivityId     = "91002"
	PickPlanIdList = "91008"

	SearchShowProd = "10298"

	IsNewSupplyLink      = "10345"
	IsOfflineSupplyLink  = "10346"
	IsNoChangeSupplyLink = "10347"

	InvestmentSelectProd = "10365" // 招商选品集ID
	RecruitProd          = "10444" // 招募策略ID
	FlowControlSignalId  = "10462"
	FlowControlPlanId    = "10463"

	PlanScene                     = "10353"
	MarketProject                 = "10384"
	ActivityIdRelationByDay       = "10248" // 活动ID
	SignupStatusCodeRelationByDay = "10249" // 活动报名状态

	AlgorithmFeatureSignId   = "10496"          // 算法特征标识Id(新)
	AlgorithmFeatureSignName = "feature_status" // 算法特征标识名称
)

var BusinessType2BizType = map[product_select.BusinessType]dimensions.BizType{
	product_select.BusinessType_ZeroSubsidyExplode:        dimensions.BizType_ProdSelectAlgorithm,
	product_select.BusinessType_ZeroSubsidyChannelExplode: dimensions.BizType_ProdSelectZeroChannelSubsidy,
}

var BizType2BusinessType = map[dimensions.BizType]product_select.BusinessType{
	dimensions.BizType_ProdSelectAlgorithm:          product_select.BusinessType_ZeroSubsidyExplode,
	dimensions.BizType_ProdSelectZeroChannelSubsidy: product_select.BusinessType_ZeroSubsidyChannelExplode,
}

var TaskPreviewType2Title = map[product_select.TaskPreviewType]string{
	product_select.TaskPreviewType_BrandLevelDistribution: "品牌等级分布",
	product_select.TaskPreviewType_ShopLevelDistribution:  "店铺类型分布",
	product_select.TaskPreviewType_IndustryDistribution:   "行业分布",
	product_select.TaskPreviewType_OPGroupDistribution:    "频道大组分布",
}

type RejectDimInfo struct {
	SourceEnumCode string
	TargetDim      []*dimensions.DimSimpleElement
}

var DynamicRejectDims = map[string][]string{
	FirstCateDim:  {IndustryDim},
	SecondCateDim: {FirstCateDim, IndustryDim},
	LeafCateDim:   {SecondCateDim, FirstCateDim, IndustryDim},
}

var StaticRejectDims = map[string]map[string]RejectDimInfo{
	IsNewPayCntDim: {
		"1": {TargetDim: []*dimensions.DimSimpleElement{{Id: IsRecallPayCntDim, Code: "0"}}},
		"0": {TargetDim: []*dimensions.DimSimpleElement{{Id: IsRecallPayCntDim, Code: "1"}}},
	},
	IsRecallPayCntDim: {
		"1": {TargetDim: []*dimensions.DimSimpleElement{{Id: IsNewPayCntDim, Code: "0"}}},
		"0": {TargetDim: []*dimensions.DimSimpleElement{{Id: IsNewPayCntDim, Code: "1"}}},
	},
	UserDemoGroupDim: {
		"年轻中高消费力男性": {TargetDim: []*dimensions.DimSimpleElement{{Id: GenderDim, Code: "male"}}},
		"年轻低消费力男性":  {TargetDim: []*dimensions.DimSimpleElement{{Id: GenderDim, Code: "male"}}},
		"年长中高消费力男性": {TargetDim: []*dimensions.DimSimpleElement{{Id: GenderDim, Code: "male"}}},
		"年长低消费力男性":  {TargetDim: []*dimensions.DimSimpleElement{{Id: GenderDim, Code: "male"}}},
		"年轻中高消费力女性": {TargetDim: []*dimensions.DimSimpleElement{{Id: GenderDim, Code: "female"}}},
		"年长中高消费力女性": {TargetDim: []*dimensions.DimSimpleElement{{Id: GenderDim, Code: "female"}}},
		"年轻低消费力女性":  {TargetDim: []*dimensions.DimSimpleElement{{Id: GenderDim, Code: "female"}}},
		"年长低消费力女性":  {TargetDim: []*dimensions.DimSimpleElement{{Id: GenderDim, Code: "female"}}},
	},
	GenderDim: {
		"male": {
			TargetDim: []*dimensions.DimSimpleElement{
				{Id: UserDemoGroupDim, Code: "年轻中高消费力男性"},
				{Id: UserDemoGroupDim, Code: "年轻低消费力男性"},
				{Id: UserDemoGroupDim, Code: "年长中高消费力男性"},
				{Id: UserDemoGroupDim, Code: "年长低消费力男性"},
			},
		},
		"female": {
			TargetDim: []*dimensions.DimSimpleElement{
				{Id: UserDemoGroupDim, Code: "年轻中高消费力女性"},
				{Id: UserDemoGroupDim, Code: "年长中高消费力女性"},
				{Id: UserDemoGroupDim, Code: "年轻低消费力女性"},
				{Id: UserDemoGroupDim, Code: "年长低消费力女性"},
			},
		},
	},
}
