package consts

import "code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"

var BizAATableMap = map[dimensions.BizType]string{
	dimensions.BizType_ProdReviewMarket:        "app_product_insight_bucket_prod_review_aa_di",
	dimensions.BizType_ProdReviewGreatValueBuy: "app_product_insight_prod_review_zero_subsidy_bucket_di",
	dimensions.BizType_ProdReviewCore:          "app_product_insight_prod_review_common_aa_di",
	dimensions.BizType_ProdReviewBigPromotion:  "app_product_insight_prod_review_common_aa_di",
	dimensions.BizType_ProdReviewGovSubsidy:    "app_product_insight_prod_review_common_aa_di",
	dimensions.BizType_ProdReviewGuess:         "app_product_insight_prod_review_common_aa_di",
	dimensions.BizType_ProdReviewSearch:        "app_product_insight_prod_review_common_aa_di",
	dimensions.BizType_ProdReviewSeckill:       "app_product_insight_prod_review_common_aa_di",
}
var BizABTableMap = map[dimensions.BizType]string{
	dimensions.BizType_ProdReviewMarket:       "app_product_insight_prod_review_ab_di",
	dimensions.BizType_ProdReviewCore:         "app_product_insight_prod_review_common_ab_di",
	dimensions.BizType_ProdReviewBigPromotion: "app_product_insight_prod_review_common_ab_di",
	dimensions.BizType_ProdReviewGovSubsidy:   "app_product_insight_prod_review_common_ab_di",
	dimensions.BizType_ProdReviewGuess:        "app_product_insight_prod_review_common_ab_di",
	dimensions.BizType_ProdReviewSearch:       "app_product_insight_prod_review_common_ab_di",
	dimensions.BizType_ProdReviewSeckill:      "app_product_insight_prod_review_common_ab_di",
}
