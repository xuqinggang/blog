package consts

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/pkg/errors"
)

const ProductID = "prod_id"
const SkuID = "sku_id"
const PSM = "ecom.smartop.product_analysis"
const VersionId = "version_id"

const MagicNumber = 0.123456789

const (
	PoolSourceProductSelectCenter = 0
	PoolSourceChannel             = 1
)

const (
	CtxBizInfoOSApiID          = "ctx_biz_info_os_api_id"
	CtxBizInfoOSTableName      = "ctx_biz_info_os_table_name"
	CtxBizInfoUseProdTableFlag = "ctx_use_prod_table_flag"
	CtxBizInfoDimCategory      = "ctx_biz_info_dim_category"
	CtxBizInfoDaysTypeList     = "ctx_biz_info_days_type_list"
	CtxExportModuleName        = "ctx_export_module_name"
	CtxTemplateFlag            = "ctx_template_flag"
	CtxProdPoolTag             = "ctx_prod_pool_tag"
	CtxBizInfoAllDimMap        = "ctx_all_dim_map"
	CtxBizInfoAllDimColMap     = "ctx_all_dim_col_map"
	CtxAllDatePoolFlag         = "ctx_all_date_pool_flag"
	CtxBizInfoDimMapPrefix     = "ctx_biz_dim_map_prefix_"
	CtxBizInfoDimColMapPrefix  = "ctx_biz_dim_col_map_prefix_"
	CtxDimMapIDLType           = "ctx_dim_map_idl_type"
	CtxApiID                   = "ctx_api_id"
	CtxBizMetaInfo             = "ctx_biz_meta_info"
	CtxUserInfo                = "ctx_user_info"
	CtxSyncMap                 = "ctx_sync_map"
	CtxBizInfoDimMap           = "ctx_dim_map"
	CtxBizInfoDimColMap        = "ctx_dim_col_map"

	// 价格力相关
	CtxBizInfoPriceComparisonType = "ctx_price_comparison_type" // 比价类型，新阶梯/B店混比
	// 价格力变化AA对比
	CtxBizInfoPriceAAInOutType  = "ctx_price_aa_in_out_type" // 站内、站外类型
	CtxBizInfoPriceAAChangeName = "ctx_price_aa_change_name" // 价格力改价前后数据

	CtxRedisCluster = "ctx_redis_cluster"

	CtxEinoState = "ctx_eino_state"
)

type ClusterName int64

const (
	ClusterName_ProductAnalysis          ClusterName = 1
	ClusterName_GrowthExperimentPlatform ClusterName = 2
)

const (
	Negetive_Infinity = "NEGATIVE_INFINITY" // 负无穷（<=）
	Positive_Infinity = "POSITIVE_INFINITY" // 正无穷（>=）

	Show_Type_Multi_Select                   = "multi_select"                   // 复选框
	Show_Type_Single_Select                  = "single_select"                  // 单选框
	Show_Type_Bool_Single_Select             = "bool_single_select"             // 是/否 类型单选框
	Show_Type_Amount_Range_Input             = "amount_range_input"             // 金额范围输入框
	Show_Type_Number_Range_Input             = "number_range_input"             // 数值范围输入框
	Show_Type_Ratio_Range_Input              = "ratio_range_input"              // 比率（%）范围输入框
	Show_Type_Text_Arr_Input                 = "text_array_input"               // 文本数组输入框
	Show_Type_Basic_info_Search_Input        = "basic_info_search_input"        // 基础数据动态框
	Show_Type_Basic_info_Search_Single_Input = "basic_info_search_single_input" // 基础数据动态单选框
)

// haveEnumCodeShowTypeList 需要枚举值code的展示类型列表，如：单选、复选
var HaveEnumCodeShowTypeList = []string{Show_Type_Bool_Single_Select, Show_Type_Multi_Select, Show_Type_Single_Select, Show_Type_Basic_info_Search_Input, Show_Type_Basic_info_Search_Single_Input}

// haveEnumRangeShowTypeList 需要枚举值范围的展示类型列表，如：金额范围输入框
var HaveEnumRangeShowTypeList = []string{Show_Type_Amount_Range_Input, Show_Type_Number_Range_Input, Show_Type_Ratio_Range_Input}

const (
	Fmt_date      = "20060102"
	FmtDateHHMMSS = "20060102030405"
	Fmt_Date      = "2006-01-02"
	Fmt_DateTime  = "2006-01-02 15:04:05"
	Fmt_TimeHour  = "15:04"
	FmtWeekDay    = "01/02"
	FmtMonth      = "2006-01"
)

var GuessDefaultTargets = []string{"pay_gmv", "pay_ord_cnt", "show_pv", "click_pv", "ctr", "cvr", "pvr", "opm", "gpm", "show_prod_cnt", "pay_prod_cnt", "prod_pay_show_rate"}

const (
	HTTPCodeSuccess = 200
)

const (
	RepeatInsertError = 1062
)

const (
	AppIdJumanji           = 6340   // 抖音盒子
	AppIdLivePlatform      = 1729   // 直播中台
	AppIdMerchantsPlatform = 3910   // 商家中台
	AppIdServicePlatform   = 4532   // 客服中台
	AppIdAweme             = 1128   // 抖音主站
	AppIdDoudianPc         = 1215   // 抖店PC
	AppIdDoudian           = 3102   // 抖店APP
	AppIdDouyinLite        = 2329   // 抖音极速版
	AppIdEcomCompass       = 4499   // 抖音罗盘
	AppIdMidPlatform       = 499471 // 电商B端应用（中台应用）
	AppIdCompassStrategy   = 317523 // 罗盘策略
	AppIdBuying            = 2631   // 百应平台（老）
	AppIdArctic            = 8218   // 北冰洋
	AppIdLeGou             = 561124 // 乐购
)

const (
	SubAppIdAwemeBuyin       = 11280001 // 抖音子应用 - 联盟移动端
	SubAppIdDoudianPcA1032   = 12150001 // 抖点PC子应用 - 招商官网
	SubAppIdAwemeMix         = 11280002 // 抖音子应用 - MIX
	SubAppIdEcomCompassA1441 = 44990001 // 抖音罗盘子应用 - 达人版
	SubAppIdEcomCompassA6187 = 44990002 // 抖音罗盘子应用 - 商家版
)

const (
	FmtDate      = "20060102"
	FmtDateSlash = "2006-01-02"
)

var (
	CheckParamError     = errors.New("check param failed")
	RecordNotFoundError = errors.New("record not found")
)

var WeekDayMap = map[string]string{
	"Monday":    "周一",
	"Tuesday":   "周二",
	"Wednesday": "周三",
	"Thursday":  "周四",
	"Friday":    "周五",
	"Saturday":  "周六",
	"Sunday":    "周日",
}

const Sep = "###"
const Comma = ","
const Empty = ""

const CateSep = ">"
const CateDisplayNameSep = "/"
const MidLine = "-"
const IsTrueString = "1"
const IsFalseString = "0"
const ThreeEqualsSymbols = "==="

const (
	OperatorTypeIn          = "IN"
	OperatorTypeNotIn       = "NOT IN"
	OperatorTypeArrayHas    = "ARRAY HAS"
	OperatorTypeLike        = "LIKE"
	ParamTypeString         = "string"
	OperatorTypeArrayHasAll = "ARRAY HAS ALL"
	OperatorTypeArrayHasAny = "ARRAY HAS ANY"
)

// 橙蕉权限ID
const (
	PostCostUserDimension = "Dm12408080000001"

	ProductAnalysisDataAuth = "smartop_product_analisys_data_auth"
)

var Dim2DisplayNameMap = map[string]string{
	"is_novice_village":                "是否新手村",
	"is_support_insure":                "是否运费险",
	"btm_first_level_entrance_name":    "btm一级入口",
	"btm_second_level_entrance_name":   "btm二级入口",
	"is_fake_deal":                     "是否虚假交易",
	"is_hard_currency":                 "是否硬通",
	"user_demo_group":                  "八大人群",
	"consumption_level_new":            "L等级",
	"age":                              "年龄",
	"gender":                           "性别",
	"ecom_content_user_life_cycle_new": "用户生命周期",
	"industry_id":                      "行业大类",
	"first_level_cate_id":              "一级类目",
	"second_level_cate_id":             "二级类目",
	"leaf_cate_id":                     "叶子类目",
	"complex_brand_s_level":            "品牌S等级",
	"product_price_belt":               "图谱价格带",
	"price_range":                      "绝对值价格带",
	"free_ship_type":                   "包邮类型",
	"spu_deliver_time":                 "发货时间",
	"shop_settle_type":                 "店铺类型",
	"content_type":                     "体裁",
	"app_name":                         "APP名称",
	"homepage_type":                    "商城入口",
	"is_billion_prod":                  "是否百亿补贴",
	"channel_pay_layer_p1d":            "频道支付用户分层",
	"first_level_source":               "一级流量来源",
	"second_level_source":              "二级流量来源",
	"first_module":                     "一级模块",
	"second_module":                    "二级模块",
	"is_sup_purchase_3k_prod":          "是否K3000",
	"billion_industry":                 "超值购行业",
	"pay_ord_cnt_belt":                 "商品支付订单数分层",
	"show_pv_belt":                     "曝光PV分层",
}

// LogicTable os逻辑表ID
const (
	LogicTableActivity        = "7369809143646946355" // 活动ID维表
	LogicTableProdCate        = "7369833547995137050" // 商品类目维表
	LogicTableUserGrowth      = "7376605269800829990" // 用增逻辑表
	LogicTableBillion         = "7376629471203329075" // 百亿补贴逻辑表
	LogicTableSeckill         = "7407730932704216090" // 秒杀逻辑表
	LogicTableMorningMarket   = "7424068188926641190" // 早晚市逻辑表
	LogicTableDimensionArctic = "7376604697987187750" // 商品属性维表(北冰洋集群，用增表需要关联该维表)
	LogicTableInvestActivity  = "7431842094798423078" // 招商活动维表
	LogicTableBrandTrial      = "7444138378095887370" // 品牌试用

	LogicTableOrdPriceTable            = "7392183633617945610" // 订单价格力
	LogicTableOrdPriceUserTable        = "7395496987056981018" // 订单价格力 - 用户属性
	LogicTableSkuPriceTable            = "7392183851298112539" // SKU价格力
	LogicTableSkuChannelShowPriceTable = "7392188427308926002" // 曝光价格力

	LogicTableSkuPriceChangeTable  = "7392190912299910195" // SKU改价表
	LogicTableProdPriceChangeTable = "7392191167422661641" // 商品改价表
	LogicTableProdChannelFlowTable = "7392228349067772966" // 商品分渠道曝光表

	LogicTableAttributionProdVersionDi = "7412631907332146226" // 异动归因-实验命中
	LogicTableAttributionInsightProdDi = "7412822215193838602" // 异动归因-商品粒度
	LogicTableAttributionGuess         = "7441103590099305482" // 异动归因-猜喜归因树

	LogicTableInterveneActionLabelTable     = "7414034543222506522" // 活动干预表
	LogicTableBigPromotionSupplyTable       = "7424105375084921894" // 活动干预表
	LogicTableBigPromotionActivityInfoTable = "7424108617126708233" // 招商活动信息表

	LogicTableDouyinCommerce     = "7437416085776778250" // 独立端商品表
	LogicTableDouyinMallCommerce = "7438990568115455002" // 独立端商城商品表

	LogicTableSkuClusterBase = "7441125309266527259" //

	LogicTableVolumePriceProdVidFlowTable   = "7441143596532778021" // 量价模型-商品流量 + AB diff表
	LogicTableVolumePriceProdLoadStatsTable = "7439924665197347877" // 量价模型-商品粒度多业务过程监控表

	LogicTableLoadUserVidProdTable         = "7457444748987597851" // 双边实验-用户-商品粒度表
	LogicTableLoadUserVidRecordTable       = "7457742701321045043" // 双边实验-进组用户表
	LogicTableLoadClusterVidTable          = "7457472113788666931" // 双边实验-进组簇表-簇分片
	LogicTableLoadClusterVidShopShardTable = "7457471996431975433" // 量价模型-进组簇表-店铺分片

	LogicTableBigSaleHotScoreTable = "7444119013753390118" // 大促爆发分逻辑表
	LogicTablePushPool             = "7447109459479987251" // 电商push商品池
	LogicTableXPDNProdAuthorTable  = "7446382917787436041" // 选品大脑商品达人指标表

	LogicTableMarketingEngine   = "7592953868317705242" // 营销引擎逻辑表
	LogicTableMarketingEngineUV = "7592982359109059630" // 营销引擎uv逻辑表

	LogicTableAppPrmMixProdStatsTable       = "7449718856274265125" // mix动态维度维表
	LogicTableMixProdDynamicDimensionsTable = "7450040404650525723" // mix动态维度维表

	LogicTableGuessDressFlowCube = "7448899854899659814" // 猜喜服饰看板流量多维cube表
	LogicTableGuessTrendProdData = "7452920273487152137" // 猜喜服饰看板趋势品明细表

	LoginTableSkuClusterCore = "7458261068624757797"

	LoginTableGreatValueBuySearch                    = "7478658037922743332"
	LoginTableGreatValueBuySearchQuery               = "7483819667920815158" // 搜索query信息表
	LoginTableGreatValueBuySearchQueryProdList       = "7494129552139093033" // 搜索query词下超值购prodid平铺表
	LoginTableGreatValueBuySearchDig                 = "7486317875817448483" //搜索优化动作表
	LoginTableGreatValueBuySearchKeyInSupply         = "7501575460254483519" //高优供给表
	LoginTableGreatValueBuySearchKeyInSupplyProdList = "7505274164585022473" //高优供给表
	LoginTableGreatValueBuyBigLink                   = "7490856049637901339" // 聚合链接

	GuessBoostData = "7474608809734964274" // 猜喜扶持效果逻辑表

	AggDynamicDimensionTable                = "7501682177487193103" // 聚合动态维度表
	AggDynamicDimensionBucketTable          = "7595888282307707955"
	DynamicDimensionProdRelationDfTable     = "7501643738733691944"
	DynamicDimensionProdRelationTableBucket = "7545357412962796594"
	DynamicDimensionUserRelationTable       = "7598030117989876745"

	LoginTableBigActivity         = "7502067169740604450" // 大促视图逻辑表
	LoginTableBigActivityProdBase = "7514666650256360486" // 大促视图商品维表
	LoginTableBigActivityAggre    = "7532348605613605914"

	ProdReviewAA             = "7542477600799654922"
	ProdReviewAB             = "7542814674585158656"
	ProdReviewGreatValueByAA = "7548755115725849627" // 超值购复盘
	ProdReviewCommonAA       = "7553927999272354843"
	ProdBucketDf             = "7576261864598864947"

	ProductSelectZeroSubsidy = "7569208952647386158"

	BillionSupplyTable      = "7566117185727235099" // 超值购供给分析货品表
	SimGroupTable           = "7572473189469635593" // 靶向组清单表
	BillionOrderUserTable   = "7566179481677808691" // 超值购订单用户表
	BillionRepayTable       = "7566181856861815846" // 超值购复访复购表
	BillionImpLeafCateTable = "7566579987726337034" // 超值购叶子类目品牌表

	LibraMetricGroupInfo = "7600628589855294514"
)

// Api Path
const (
	BaseApiPathTargetCard = "7369884979809109018"

	OrdPriceResponsibilityDistributed  = "7389522606887584777"
	OrdPriceResponsibilityCoreOverview = "7389598704094708774"
	OrdPriceResponsibilityChange       = "7389608784592667685"
	OrdPriceResponsibilityTargetList   = "7389916986773357618"
	OrdPriceResponsibilityIndustryList = "7390277470831805450"
	OrdPriceResponsibilityBubbleChart  = "7396929971635176486"

	PriceAAApiCoreOverview                    = "7386653533392684042"
	PriceAAApiEntityCnt                       = "7386966194043044915"
	PriceAAApiFlowStandardCoreOverview        = "7386986005884175411"
	PriceAAApiFlowStandardCoreOverviewChannel = "7387759240116552755"

	PriceAAApiFlowStandardCoreOverviewTrend = "7387237021334455305"
	PriceAAApiMarketCoreOverview            = "7387314985753379877"
	PriceAAApiBizIncomeTrend                = "7387321318565364787"
	PriceAAApiBizIncomeDiffDistributed      = "7387685921321124902"

	PriceAAApiSupplyMarketCnt      = "7387769164380816394"
	PriceAAApiSupplyFilterCnt      = "7388039587731358747"
	PriceAAApiSupplyMarketMultiDim = "7388048643036627994"
	PriceAAApiSupplyFilterMultiDim = "7388049151562482698"

	ActivityReviewApiActivityTime = "7424557016183489586"

	SkuPriceChangeTableName        = "app_product_price_sku_price_power_change_flow_stats_di"
	ProdPriceChangeTableName       = "app_product_price_prod_price_power_change_flow_stats_di"
	OrdPricePowerTableName         = "app_product_insight_ord_price_power_di"
	OrdPricePowerWithUserTableName = "app_product_user_insight_ord_price_power_di"
	ProdPriceChannelFlowTableName  = "app_product_price_prod_channel_flow_trd_stats_di"
	SkuPricePowerTableName         = "app_product_insight_sku_price_power_df"
)

var PricePowerList = []string{"均价", "优价", "高价", "无同款"}
var PricePriorityList = []int64{0, 1, 2}

type PriceAASupplyCntType int64

const (
	PriceAASupplyCntType_Market             PriceAASupplyCntType = 1
	PriceAASupplyCntType_PriceChange        PriceAASupplyCntType = 2
	PriceAASupplyCntType_PriceChange_Filter PriceAASupplyCntType = 3
)

type PriceAASupplyCntInfo struct {
	Name string
	Tips string
}

var PriceAASupplyCntTypeNameMap = map[PriceAASupplyCntType]PriceAASupplyCntInfo{
	PriceAASupplyCntType_Market:             {"大盘商品", "指大盘全部比价覆盖的品，包括均价、优价、高价、无同款商品"},
	PriceAASupplyCntType_PriceChange:        {"发生价格力变化的商品", "指发生如下价格力变化的商品：非高价变高价、高价变非高价、高价变无同款"},
	PriceAASupplyCntType_PriceChange_Filter: {"符合筛选条件的商品", ""},
}

var LogicTableIdMap = map[dimensions.BizType][]string{
	// 超值购
	dimensions.BizType_GreatValueBuy: {LogicTableActivity, LogicTableProdCate, LogicTableBillion, LogicTableDimensionArctic},
	// 超值购-酒类
	dimensions.BizType_GreatValueBuyLiquor: {LogicTableActivity, LogicTableProdCate, LogicTableBillion, LogicTableDimensionArctic},
	// 用增
	dimensions.BizType_GrowthProductStrategy: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic},
	// 品牌试用
	dimensions.BizType_BrandTrial: {LogicTableBrandTrial},
	// A1-用增
	dimensions.BizType_A1GrowthProductStrategy: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic},
	// A2-用增
	dimensions.BizType_A2GrowthProductStrategy: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic},
	// A3-用增
	dimensions.BizType_A3GrowthProductStrategy: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic},
	// B-用增
	dimensions.BizType_BGrowthProductStrategy: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic},
	// 秒杀
	dimensions.BizType_ProdSeckill: {LogicTableProdCate, LogicTableSeckill, LogicTableDimensionArctic},
	// 猜喜
	dimensions.BizType_GuessProduct: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic},
	// 早市
	dimensions.BizType_MorningMarketProduct: {LogicTableProdCate, LogicTableMorningMarket, LogicTableDimensionArctic},
	// 独立端 - 全端
	dimensions.BizType_DouyineCommerce: {LogicTableDouyinCommerce},
	// 独立端 - 商城
	dimensions.BizType_DouyineMallCommerce: {LogicTableDouyinMallCommerce},
	// 选品大脑
	dimensions.BizType_MatchingBrain: {LogicTableXPDNProdAuthorTable},
	// 营销引擎
	dimensions.BizType_MarketingEngine: {LogicTableMarketingEngine, LogicTableMarketingEngineUV},
	// sku价格力
	dimensions.BizType_PriceTrendSku: {LogicTableSkuPriceTable, LogicTableOrdPriceTable, LogicTableOrdPriceUserTable},
	// 订单价格力
	dimensions.BizType_PriceTrendOrder: {LogicTableOrdPriceTable, LogicTableOrdPriceUserTable},
	// 曝光价格力
	dimensions.BizType_PriceTrendShow: {LogicTableSkuChannelShowPriceTable},
	// 价格力变化AA分析
	dimensions.BizType_PriceAACompare: {LogicTableSkuPriceChangeTable, LogicTableProdPriceChangeTable, LogicTableProdChannelFlowTable, LogicTableOrdPriceTable, LogicTableSkuPriceTable, LogicTableSkuChannelShowPriceTable},

	// 异动归因-整体
	dimensions.BizType_AttributionCore: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic, LogicTableAttributionProdVersionDi, LogicTableAttributionInsightProdDi},
	// 活动复盘
	dimensions.BizType_ActivityReview: {LogicTableBigPromotionSupplyTable, LogicTableUserGrowth, LogicTableProdCate, LogicTableDimensionArctic},

	// 量价模型
	dimensions.BizType_VolumePrice:        {LogicTableVolumePriceProdVidFlowTable, LogicTableVolumePriceProdLoadStatsTable, LogicTableLoadUserVidRecordTable},
	dimensions.BizType_ReversalExperiment: {LogicTableLoadUserVidProdTable, LogicTableLoadUserVidRecordTable, LogicTableLoadClusterVidTable, LogicTableLoadClusterVidShopShardTable},
	// 异动归因-猜喜
	dimensions.BizType_AttributionCoreGuess:   {LogicTableAttributionGuess, LogicTableDimensionArctic, LogicTableAttributionInsightProdDi},
	dimensions.BizType_AttributionCoreGuessV2: {ProdReviewCommonAA, ProdBucketDf},
	// Mix商品
	dimensions.BizType_MixProduct: {LogicTableAppPrmMixProdStatsTable},

	// 猜喜服饰看板大盘
	dimensions.BizType_GuessDress: {LogicTableAttributionGuess, LogicTableGuessDressFlowCube, LogicTableGuessTrendProdData},
	// 猜喜服饰看板A1
	dimensions.BizType_GuessDressA1: {LogicTableAttributionGuess, LogicTableGuessDressFlowCube, LogicTableGuessTrendProdData},
	// 猜喜服饰看板B组
	dimensions.BizType_GuessDressB: {LogicTableAttributionGuess, LogicTableGuessDressFlowCube, LogicTableGuessTrendProdData},

	// SKU簇洞察
	dimensions.BizType_SkuClusterCore:              {LoginTableSkuClusterCore},
	dimensions.BizType_SkuClusterBasicConstitution: {LoginTableSkuClusterCore},
	dimensions.BizType_SkuClusterScaleAndMount:     {LoginTableSkuClusterCore},
	dimensions.BizType_SkuClusterCoverage:          {LoginTableSkuClusterCore},
	dimensions.BizType_SkuClusterSupplyQuality:     {LoginTableSkuClusterCore},
	dimensions.BizType_SkuClusterSupplyInsight:     {LoginTableSkuClusterCore},
	dimensions.BizType_SkuClusterStability:         {LoginTableSkuClusterCore},
	dimensions.BizType_SkuClusterFlow:              {LoginTableSkuClusterCore},
	dimensions.BizType_SkuClusterFlowInsight:       {LoginTableSkuClusterCore},

	// 猜喜服饰看板B组
	dimensions.BizType_GuessBoostData: {GuessBoostData},

	// 超值购专项
	//todo add  LoginTableGreatValueBuySearchDig
	dimensions.BizType_GreatValueBuySearch:  {LoginTableGreatValueBuySearch, LoginTableGreatValueBuySearchQuery, LoginTableGreatValueBuySearchDig, LoginTableGreatValueBuySearchQueryProdList, LoginTableGreatValueBuySearchKeyInSupply, LoginTableGreatValueBuySearchKeyInSupplyProdList},
	dimensions.BizType_GreatValueBuyBigLink: {LoginTableGreatValueBuyBigLink},

	// 相似品
	dimensions.BizType_SimilarProduct: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic},

	// 大促视图

	dimensions.BizType_BigActivityCore: {LoginTableBigActivityAggre},
	// 市集活动
	dimensions.BizType_MarketProjectProduct: {LogicTableProdCate, LogicTableUserGrowth, LogicTableDimensionArctic},

	// 复盘-大盘
	dimensions.BizType_ProdReviewCore: {ProdReviewCommonAA},
	// 复盘-大促
	dimensions.BizType_ProdReviewBigPromotion: {ProdReviewCommonAA},
	// 复盘-秒杀
	dimensions.BizType_ProdReviewSeckill: {ProdReviewCommonAA},
	// 复盘-政府补贴
	dimensions.BizType_ProdReviewGovSubsidy: {ProdReviewCommonAA},
	// 复盘-猜喜
	dimensions.BizType_ProdReviewGuess: {ProdReviewCommonAA},
	// 复盘-搜索
	dimensions.BizType_ProdReviewSearch: {ProdReviewCommonAA},

	// 复盘-市集
	dimensions.BizType_ProdReviewMarket: {ProdReviewAA, ProdReviewAB},

	// 复盘-超值购
	dimensions.BizType_ProdReviewGreatValueBuy: {ProdReviewGreatValueByAA},

	// 超值购供给分析
	dimensions.BizType_BillionSupply: {BillionSupplyTable, SimGroupTable, BillionOrderUserTable, BillionRepayTable, BillionImpLeafCateTable},

	// 商城经分
	dimensions.BizType_ProdReviewLibraMetricGroup: {LibraMetricGroupInfo},
}

type DateType string

const (
	DateType_DAY   DateType = "1d"
	DateType_WEEK  DateType = "cw"
	DateType_MONTH DateType = "cm"

	DateType_LAST_SEVEN_DAYS DateType = "7d"
	DateType_LAST_ONE_MONTH  DateType = "30d"

	DateType_SINCE_0527 DateType = "0527"
)

const (
	CacheFuncNameCoreOverviewPrefix     = "Cache_GetProductAnalysisCoreOverview_"
	CacheFuncNameCoreHierarchicalPrefix = "Cache_GetProductAnalysisCoreHierarchical_"
	CacheFuncNameCoreConclusionPrefix   = "Cache_GetProductAnalysisCoreConclusion_"
)

// Lark相关
const (
	LarkSheetUrl      = "https://bytedance.larkoffice.com/sheets/"
	LarkWikiUrl       = "https://bytedance.larkoffice.com/wiki/"
	LarkDocxUrl       = "https://bytedance.larkoffice.com/docx/"
	LarkSheetBatchNum = 1000  // Lark Sheet单次写入数据行数：https://open.larkoffice.com/document/server-docs/docs/sheets-v3/data-operation/write-data-to-a-single-range
	MaxExportLen      = 99999 // 最大导出数据量
)

const (
	AnalysisBusinessId = "product_analysis" //「商品分析」业务线Id
	ReqSource          = "analysis"
)

type ProdTagCodeParam struct {
	Col   string `json:"col"`
	Value string `json:"value"`
}

var NotDistributedPerfectShardBizTypeList = []int64{
	int64(dimensions.BizType_MorningMarketProduct), int64(dimensions.BizType_MatchingBrain),
}

var NewClusterBizTypeList = []dimensions.BizType{
	dimensions.BizType_ProdReviewMarket,
	dimensions.BizType_ProdReviewCore,
	dimensions.BizType_ProdReviewGreatValueBuy,
	dimensions.BizType_BigActivityCore,
	dimensions.BizType_ProdReviewGovSubsidy,
	dimensions.BizType_ProdReviewGuess,
	dimensions.BizType_ProdReviewSearch,
	dimensions.BizType_ProdReviewMarket,
	dimensions.BizType_ProdReviewBigPromotion,
	dimensions.BizType_ProdReviewSeckill,
}

const (
	SignificancePrefixVariance = "significance_variance_"
	SignificancePrefixCnt      = "significance_cnt_"
	SignificancePrefixAvg      = "significance_avg_"
	SignificancePrefixRate     = "significance_rate_"
)

const (
	DynamicDimensionProdRelationPartitionMarketProject        = "market_project"         // 市集项目
	DynamicDimensionProdRelationPartitionInvestmentSelectProd = "investment_select_prod" // 招商选品集
	DynamicDimensionProdRelationPartitionFlowControl          = "flow_control"           // 流量调控
	DynamicDimensionProdRelationPartitionRecruitProd          = "recruit_prod"           // 招募策略
)
const (
	PackageDynamicDimensionProdRelationPartitionInvestmentSelectProd = "investment_prod_new" // 招商选品集
	PackageDynamicDimensionProdRelationPartitionSelectProd360        = "select_prod_360"     // 360选品包
	PackageDynamicDimensionProdRelationPartitionCrowdPackage         = "crowd_package"       // 人群包
	PackageDynamicDimensionProdRelationPartitionRecruitProd          = "recruit_prod"        // 招募策略
)

type DynamicDimensionInfo struct {
	PartitionName   string
	IsRelationByDay bool
}
type PackageDynamicDimensionInfo struct {
	PartitionName string
	DynamicDim    *dimensions.SelectedDimensionInfo
}

var DynamicDimensionProdRelationPartitionMap = map[string]bool{
	DynamicDimensionProdRelationPartitionMarketProject:        true,
	DynamicDimensionProdRelationPartitionInvestmentSelectProd: true,
	DynamicDimensionProdRelationPartitionFlowControl:          true,
	DynamicDimensionProdRelationPartitionRecruitProd:          true,
}

var PackageDynamicDimensionProdRelationPartitionMap = map[string]bool{
	PackageDynamicDimensionProdRelationPartitionInvestmentSelectProd: true,
	PackageDynamicDimensionProdRelationPartitionSelectProd360:        true,
	PackageDynamicDimensionProdRelationPartitionCrowdPackage:         true,
	PackageDynamicDimensionProdRelationPartitionRecruitProd:          true,
}

var DimensionIdDynamicDimensionInfoMap = map[string]DynamicDimensionInfo{
	FlowControlPlanId: {
		PartitionName:   DynamicDimensionProdRelationPartitionFlowControl,
		IsRelationByDay: true,
	},
	FlowControlSignalId: {
		PartitionName:   DynamicDimensionProdRelationPartitionFlowControl,
		IsRelationByDay: true,
	},
	RecruitProd: {
		PartitionName:   DynamicDimensionProdRelationPartitionRecruitProd,
		IsRelationByDay: true,
	},
	InvestmentSelectProd: {
		PartitionName:   DynamicDimensionProdRelationPartitionInvestmentSelectProd,
		IsRelationByDay: false,
	},
}

const (
	PackageInvestmentSelectProdDimId = "10424"
	PackageSelectProd360DimId        = "10615"
	PackageCrowdPackageDimId         = "10616"
	PackageRecruitProdDimId          = "10614"
)

var PackageDynamicDimensionInfoMap = map[string]PackageDynamicDimensionInfo{
	// 	招商选品集
	PackageInvestmentSelectProdDimId: {
		PartitionName: "prod_id",
	},
	// 	360选品包
	PackageSelectProd360DimId: {
		PartitionName: "prod_id",
	},
	// 人群包
	PackageCrowdPackageDimId: {
		PartitionName: "user_id",
	},
	// 	招募策略
	PackageRecruitProdDimId: {
		PartitionName: "prod_id",
	},
}

var NoDaysTypeTable = []string{
	"dm_prm_tool_coupon_order_for_insight_bucket_di",
}
