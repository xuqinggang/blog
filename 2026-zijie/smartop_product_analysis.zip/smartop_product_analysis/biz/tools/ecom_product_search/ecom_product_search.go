package ecom_product_search

import (
	"code.byted.org/gopkg/lang/strings"
	"code.byted.org/overpass/common/option/calloption"
	"code.byted.org/overpass/ecom_product_search/kitex_gen/ecom/product/search"
	"code.byted.org/overpass/ecom_product_search/rpc/ecom_product_search"
	"code.byted.org/overpass/ecom_smartop_industry/kitex_gen/ecom/smartop/industry"
	"code.byted.org/overpass/ecom_smartop_industry/rpc/ecom_smartop_industry"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"time"

	"code.byted.org/gopkg/logs"
)

const timeout = 5

func GetProductBrief(ctx context.Context, productID string) (*industry.GetProductBriefInfoData, error) {
	resp, err := ecom_smartop_industry.GetProductBrief(ctx, productID)
	if err != nil {
		logs.CtxError(ctx, "GetProductBrief Err %v+", err)
		return nil, err
	}
	return resp.Data, nil
}

func SearchProductList(ctx context.Context, keyword string, pageNum, pageSize int64) (productList []*search.ProductSearch2BInfo, err error) {
	req := &search.ProductSearch2BRequest{
		Cond: &search.ProductSearch2BStruct{
			Page: pageNum,
			Size: pageSize,
		},
	}
	if strings.IsNumeric(keyword) {
		req.Cond.ProductIds = []int64{convert.ToInt64(keyword)}
	} else {
		req.Cond.Names = []string{keyword}
	}
	resp, err := ecom_product_search.RawCall.ProductSearch2B(ctx, req, calloption.WithRPCTimeout(timeout*time.Second))
	if err != nil {
		logs.CtxError(ctx, "[SearchProductList] ProductSearch2B failed, err = %+v", err)
		return nil, err
	}
	if resp == nil || len(resp.GetData()) == 0 {
		return nil, nil
	}
	return productList, nil
}
