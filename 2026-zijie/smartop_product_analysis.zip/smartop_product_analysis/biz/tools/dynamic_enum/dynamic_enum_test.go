package dynamic_enum

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"reflect"
	"testing"
)

func TestTransErr(t *testing.T) {
	dynamicEnum := &DynamicEnum{}
	ctx := context.Background()
	if method, hasMethod := reflect.TypeOf(dynamicEnum).MethodByName("Demo"); hasMethod &&
		method.Type.NumOut() == 2 && method.Type.NumIn() == 2 {
		methodParams := []reflect.Value{reflect.ValueOf(dynamicEnum), reflect.ValueOf(ctx)}
		if err, errOk := method.Func.Call(methodParams)[1].Interface().(error); !errOk || err != nil {
			fmt.Println(errOk)
			fmt.Println(err)
		}

		if enums, ok := method.Func.Call(methodParams)[0].Interface().([]*dimensions.EnumElement); ok && len(enums) > 0 {
			fmt.Println(enums)
		}
	}
}

func TestGenerateCateEnum(t *testing.T) {
	ctx := context.Background()
	GenerateCateEnum(ctx, []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.IndustryDim), DimColumn: "industry_id"},
	}, "cate_level = 1", &dimensions.GetDimensionPageEnumListRequest{
		DimensionId: "10026",
		PageInfo: &base.PageInfo{
			PageNum:  1,
			PageSize: 10,
		},
	})
}
