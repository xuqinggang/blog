package dynamic_enum

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"context"
)

var (
	ZeroSubsidyTableID = "7548755115725849627"
)

// GetBillionClassName 获取超值购大组
func (d *DynamicEnum) GetBillionClassName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, ZeroSubsidyTableID, "7550204998991266867", nil, nil)
}

// GetImpChnlName 获取重点类目
func (d *DynamicEnum) GetImpChnlName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, ZeroSubsidyTableID, "7550200333532791817", nil, nil)
}
