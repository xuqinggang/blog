package dynamic_enum

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
)

var (
	BillionSupplyTableID = "7566117185727235099"
)

// 获取超值购运营
func (d *DynamicEnum) GetBillionNameName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, BillionSupplyTableID, "7566195699960874010", nil, nil)
}

// 获取超值购用户类目
func (d *DynamicEnum) GetUserCate(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, BillionSupplyTableID, "7566197118948426778", nil, nil)
}