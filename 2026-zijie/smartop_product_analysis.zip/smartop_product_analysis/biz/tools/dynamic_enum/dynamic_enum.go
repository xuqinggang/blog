package dynamic_enum

import (
	"code.byted.org/ecom/smartop_product_analysis/dal/db/model"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/overpass/com_commop_product360/rpc/com_commop_product360"
	"code.byted.org/overpass/ecom_kunlun_crowdmeta/kitex_gen/ecom/bytedance/kunlun/open"
	"code.byted.org/overpass/ecom_kunlun_crowdmeta/rpc/ecom_kunlun_crowdmeta"
	"context"
	"encoding/json"
	"fmt"
	"reflect"
	"strconv"
	"strings"

	"code.byted.org/gopkg/lang/conv"

	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/application"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/param"
	"code.byted.org/ecom/smartop_arctic_framework_sdk/src/runtime/document"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/base_struct_condition"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_v2/flow"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/facility/math"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_ecop_matching_brain/kitex_gen/ecom/ecop/matching_brain"
	"code.byted.org/overpass/ecom_ecop_matching_brain/rpc/ecom_ecop_matching_brain"
	"code.byted.org/temai/go_lib/convert"
)

type DynamicEnum struct {
	NeedDumpDimensionDao dao.NeedDumpDimensionDao
}

func GetEnumByMethod(ctx context.Context, funcName string) ([]*dimensions.EnumElement, error) {
	dynamicEnum := &DynamicEnum{}
	if method, hasMethod := reflect.TypeOf(dynamicEnum).MethodByName(funcName); hasMethod &&
		method.Type.NumOut() == 2 && method.Type.NumIn() == 2 {
		methodParams := []reflect.Value{reflect.ValueOf(dynamicEnum), reflect.ValueOf(ctx)}
		if err, errOk := method.Func.Call(methodParams)[1].Interface().(error); errOk && err != nil {
			logs.CtxError(ctx, "interface to error Fail, err=%v+", err)
			return nil, err
		}

		if enums, ok := method.Func.Call(methodParams)[0].Interface().([]*dimensions.EnumElement); ok && len(enums) > 0 {
			return enums, nil
		}
	} else {
		logs.CtxWarn(ctx, "[GetEnumByMethod]DynamicEnum DynamicFuncName Fail, name=%s", funcName)
	}

	return nil, nil
}

func (d *DynamicEnum) Demo(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return nil, nil
}

var dimBTMEntranceTableId = "7371860244646970419"

func (d *DynamicEnum) GetBTMFirstLevelEntrance(ctx context.Context) ([]*dimensions.EnumElement, error) {
	newest, err := utils.GetNewestDay(ctx, dimBTMEntranceTableId)
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, err
	}

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	fl.ExeQueryInvokerRaw(map[string]interface{}{"date": newest}, "7371886364771517449", param.SinkTable("data_res"))
	var ret []*dimensions.EnumElement
	fl.ExeView(param.SourceTable("data_res"), &ret)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetBTMFirstLevelEntrance]引擎调用失败，err=%v+", err)
		return ret, err
	}
	return ret, nil
}

func (d *DynamicEnum) GetBTMSecondLevelEntrance(ctx context.Context) ([]*dimensions.EnumElement, error) {
	newest, err := utils.GetNewestDay(ctx, dimBTMEntranceTableId)
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, err
	}

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	fl.ExeQueryInvokerRaw(map[string]interface{}{"date": newest}, "7371860671664833587", param.SinkTable("data_res"))
	var ret []*dimensions.EnumElement
	fl.ExeView(param.SourceTable("data_res"), &ret)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetBTMSecondLevelEntrance]引擎调用失败，err=%v+", err)
		return ret, err
	}
	return ret, nil
}

func (d *DynamicEnum) GetIndustryList(ctx context.Context) ([]*dimensions.EnumElement, error) {
	newest, err := utils.GetNewestDay(ctx, cateTableID)
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, err
	}

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	fl.ExeQueryInvokerRaw(map[string]interface{}{"date": newest}, "7370745182716806181", param.SinkTable("data_res"))
	var ret []*dimensions.EnumElement
	fl.ExeView(param.SourceTable("data_res"), &ret)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetIndustryList]引擎调用失败，err=%v+", err)
		return ret, err
	}
	return ret, nil
}

var cateTableID = "7369833547995137050"
var cateAppID = "7369832911383626803"
var cateTableName = "smartop_product_analysis_dim_prd_cate_df"

type dependCode struct {
	Id       string `json:"id"`
	Code     string `json:"code"`
	CurrCode string `json:"curr_code"`
}

var NeedPageEnumSearchList = []string{
	"GetFirstCateList",
	"GetSecondCateList",
	"GetThirdCateList",
	"GetLeafCateList",
	"GetShopNameList",
	"GetBrandNameList",
	"GetProductPoolList",
	"GetMorningMarketPool",
	"GetProdNameList",
	"GetInvestActivityList",
	"GetBrainPoolList",
	"GetMainActivityList",
	"GetActivityListForActivityReview",
	"GetMainProjectList",
	"GetPickPlanList",
	"GetSkuClusterNameList",
	"GetMixDynamicDimensionOriginTypeValues",
	"GetMixDynamicDimensionCoudanComeCouponValues",
	"GetMixDynamicDimensionRenderTypeValues",
	"GetMixActivityName",
	"GetMixPageName",
	"GetMixModuleName",
	"GetMixBTMPreName",
	"GetInvestmentSelectProd",
	"GetBigActivityList",
	"GetMarketProjectList",
	"GetRecruitProd",
	"SearchRecruitEnums",
	"SearchInvestmentSelectEnums",
	"SearchProd360tEnums",
	"SearchCrowdsEnums",
	"GetMetricList",
	"GetMetricFlightList",
	"GetMetricGroupList",
}

func (d *DynamicEnum) GetFirstCateList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	return GenerateCateEnum(ctx, []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.IndustryDim), DimColumn: "industry_id"},
	}, "cate_level = 1", req)
}

func (d *DynamicEnum) GetSecondCateList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	return GenerateCateEnum(ctx, []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.IndustryDim), DimColumn: "industry_id"},
		{ID: convert.ToInt64(consts.FirstCateDim), DimColumn: "first_level_cate_id"},
	}, "cate_level = 2", req)
}

func (d *DynamicEnum) GetThirdCateList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	return GenerateCateEnum(ctx, []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.IndustryDim), DimColumn: "industry_id"},
		{ID: convert.ToInt64(consts.FirstCateDim), DimColumn: "first_level_cate_id"},
		{ID: convert.ToInt64(consts.SecondCateDim), DimColumn: "second_level_cate_id"},
	}, "cate_level = 2", req)
}

func (d *DynamicEnum) GetLeafCateList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	return GenerateCateEnum(ctx, []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.IndustryDim), DimColumn: "industry_id"},
		{ID: convert.ToInt64(consts.FirstCateDim), DimColumn: "first_level_cate_id"},
		{ID: convert.ToInt64(consts.SecondCateDim), DimColumn: "second_level_cate_id"},
	}, "is_leaf = 1", req)
}

func (d *DynamicEnum) GetFirstLocation(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableUserGrowth, "7408520159297635338", nil, nil)
}

func (d *DynamicEnum) GetSecondLocation(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableUserGrowth, "7408838347310892083", nil, nil)
}

func (d *DynamicEnum) GetGovProvince(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableUserGrowth, "7486681932223300660", nil, nil)
}

func (d *DynamicEnum) GetP0Pool(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableDimensionArctic, "7408853189069407283", nil, nil)
}

func (d *DynamicEnum) GetSecondManageCategory(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableDimensionArctic, "7442218221811418122", nil, nil)
}

func (d *DynamicEnum) GetVolumePriceP0Pool(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableDimensionArctic, "7441096322796635174", nil, nil)
}

func (d *DynamicEnum) GetVolumePriceSeedSource(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableDimensionArctic, "7441105905543840818", nil, nil)
}

func (d *DynamicEnum) GetPerfSecondVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableAttributionGuess, "7446990066611667977", nil, nil)
}

func (d *DynamicEnum) GetPerfThirdVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableAttributionGuess, "7462665708581766170", nil, nil)
}

func GenerateCateEnum(ctx context.Context, dependDims []dao.DimensionInfo, rawWhere string, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	newest, err := utils.GetNewestDay(ctx, cateTableID)
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, 0, err
	}
	dependEnumCols := make([]string, 0)
	for _, d := range dependDims {
		dependEnumCols = append(dependEnumCols, d.DimColumn)
	}
	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()

	subCql := sql_parse.NewCQL().
		Select("cate_id", "case when cate_level = 2 then concat(cate_name,'(',first_level_cate_name,')') when cate_level >= 3 then concat(cate_name, '(', first_level_cate_name,'/',second_level_cate_name,')') else cate_name end as cate_name").
		AddSelect(dependEnumCols...).From(cateTableName).AddWhere("p_date", sql_parse.EQUAL, newest).
		AddWhere("cate_status", sql_parse.EQUAL, 1).
		AddWhere("length(cate_name)", sql_parse.GREATER_THAN, 0).AddWhere("cate_id", sql_parse.GREATER_THAN, 0)
	cql := sql_parse.NewCQL().
		Select("cate_id as code, cate_name as name").AddSelect(dependEnumCols...).
		FromCql(subCql).GroupBy("cate_id", "cate_name").AddGroupBy(dependEnumCols...).
		SetPageInfo(req.PageInfo.PageNum, req.PageInfo.PageSize).SetSortInfo("cate_id", true)
	totalCql := sql_parse.NewCQL().From(cateTableName).
		Select("count(distinct cate_id) as total").
		AddWhere("p_date", sql_parse.EQUAL, newest)
	if len(rawWhere) > 0 {
		subCql.AddRawWhere("and " + rawWhere)
		totalCql.AddRawWhere("and " + rawWhere)
	}
	if req.SearchEnumName != nil && len(*req.SearchEnumName) > 0 {
		subCql.AddWhereSearchValue(*req.SearchEnumName, "cate_name")
		totalCql.AddWhereSearchValue(*req.SearchEnumName, "cate_name")
	} else if req.SearchEnumNameList != nil && len(req.SearchEnumNameList) > 0 {
		// 和search_enum_name互斥，通过 like 关键字进行模糊搜索
		var conditions []string
		for _, enum := range req.SearchEnumNameList {
			conditions = append(conditions, fmt.Sprintf("cate_name like '%%%s%%'", enum))
		}
		subCql.AddRawWhere("and (" + strings.Join(conditions, " or ") + ")")
		totalCql.AddRawWhere("and (" + strings.Join(conditions, " or ") + ")")
	}
	if len(req.EnumCodeList) > 0 {
		cateIds := make([]int64, 0)
		for _, enum := range req.EnumCodeList {
			intValue, err := strconv.ParseInt(enum, 10, 64)
			if err != nil {
				continue
			}
			cateIds = append(cateIds, intValue)
		}
		//cateIds, err := ameda.StringsToInt64s(req.EnumCodeList)
		if len(cateIds) == 0 {
			logs.CtxError(ctx, "[GenerateCateEnum]StringsToInt64s Err: %v", err)
			return nil, 0, errors.New("传入枚举类目ID异常")
		}
		subCql.AddWhere("cate_id", sql_parse.IN, cateIds)
		totalCql.AddWhere("cate_id", sql_parse.IN, cateIds)
	}
	if len(req.DependDims) > 0 {
		for _, dependDim := range req.DependDims {
			var searchCol string
			switch dependDim.Id {
			case consts.IndustryDim:
				searchCol = "industry_id"
			case consts.FirstCateDim:
				searchCol = "first_level_cate_id"
			case consts.SecondCateDim:
				searchCol = "second_level_cate_id"
			default:
				continue
			}
			dependEnums := make([]string, 0)
			if len(dependDim.SelectedValues) > 0 {
				for _, e := range dependDim.SelectedValues {
					if len(e.Code) > 0 {
						dependEnums = append(dependEnums, e.Code)
					}
				}
			}
			if len(dependEnums) > 0 {
				subCql.AddWhere(searchCol, base_struct_condition.TransOperator(dependDim.SelectedOperator), dependEnums)
				totalCql.AddWhere(searchCol, base_struct_condition.TransOperator(dependDim.SelectedOperator), dependEnums)
			}
		}
	}

	sql := cql.Compile()
	fmt.Print(sql)

	fl.ExeQueryInvokerSql(cateAppID, cql.Compile(), param.SinkTable("enum_list"))
	fl.ExeQueryInvokerSql(cateAppID, totalCql.Compile(), param.SinkTable("enum_total"))

	dependSql := make([]string, 0)
	for _, dimInfo := range dependDims {
		fl.ExeProduceSql(
			fmt.Sprintf("select '%d' as id, %s as code from enum_list where str_len(%s)>0 group by %s",
				dimInfo.ID, dimInfo.DimColumn, dimInfo.DimColumn, dimInfo.DimColumn),
			param.SinkTable(fmt.Sprintf("depend_code_%s", dimInfo.DimColumn)),
		)
		dependSql = append(dependSql, fmt.Sprintf("select b.code as curr_code, a.id as id, a.code as code from depend_code_%s a join enum_list b on a.code = b.%s",
			dimInfo.DimColumn, dimInfo.DimColumn))
	}
	fl.ExeProduceSql(strings.Join(dependSql, " union all "), param.SinkTable("depend_code_list"))
	fl.ExeProduceSql(`select code, name from enum_list`, param.SinkTable("data_res"))

	var dependList []*dependCode
	fl.ExeView(param.SourceTable("depend_code_list"), &dependList)
	var ret []*dimensions.EnumElement
	fl.ExeView(param.SourceTable("data_res"), &ret)
	var totalInfo = make(map[string]int64)
	fl.ExeView(param.SourceTable("enum_total"), &totalInfo)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GenerateCateEnum]引擎调用失败，err=%v+", err)
		return ret, 0, err
	}

	if len(ret) == 1 && len(ret[0].Code) == 0 {
		return nil, totalInfo["total"], err
	}

	if len(ret) > 0 {
		for _, r := range ret {
			r.DependCode = make([]*dimensions.DimSimpleElement, 0)
			for _, d := range dependList {
				if r.Code == d.CurrCode {
					r.DependCode = append(r.DependCode, &dimensions.DimSimpleElement{
						Id:   d.Id,
						Code: d.Code,
					})
				}
			}
		}
	}

	return ret, totalInfo["total"], nil
}

// GetActivityList 获取活动枚举
func (d *DynamicEnum) GetActivityList(ctx context.Context) ([]*dimensions.EnumElement, error) {
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, dimensions.BizType_GreatValueBuy)
	if err != nil {
		return nil, err
	}
	if bizInfo == nil {
		return nil, errors.New("bizInfo empty")
	}
	oldest, newest, err := utils.GetOldestAndNewestDate(ctx, []string{"7369809143646946355"}, convert.ToInt(bizInfo.MaxRangeDay))
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, err
	}

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	fl.ExeQueryInvokerSql("7369802237821862950", fmt.Sprintf(`
        select
            activity_id as code,
            activity_name as name
        from
            dim_prm_platform_invest_activity_info_df
        where
            p_date = '%s'
            and is_super_subsidy = 1
            and activity_end_date >= '%s'
            and length(channel_name) > 0
            and is_test_activity = 0
            and is_has_prod_object = 1
        group by
            activity_id,
            activity_name
    `, strings.ReplaceAll(newest, "-", ""), strings.ReplaceAll(oldest, "-", "")), param.SinkTable("dim_prm_platform_invest_activity_info_df"))

	var ret []*dimensions.EnumElement
	fl.ExeView(param.SourceTable("dim_prm_platform_invest_activity_info_df"), &ret)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetActivityList]引擎调用失败，err=%v+", err)
		return ret, err
	}
	return ret, nil
}

func GetOsTableList(ctx context.Context, logicTableID, apiPath string, dependDims []dao.DimensionInfo, appendParams map[string]interface{}) ([]*dimensions.EnumElement, error) {
	newest, err := utils.GetNewestDay(ctx, logicTableID)
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, err
	}

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	params := make(map[string]interface{})
	params["date"] = newest
	if len(appendParams) > 0 {
		for k, v := range appendParams {
			params[k] = v
		}
	}
	fl.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("enum_list"))

	var dependList []*dependCode
	if len(dependDims) > 0 {
		dependSql := make([]string, 0)
		for _, dimInfo := range dependDims {
			fl.ExeProduceSql(
				fmt.Sprintf("select '%d' as id, %s as code from enum_list where str_len(%s)>0 group by %s",
					dimInfo.ID, dimInfo.DimColumn, dimInfo.DimColumn, dimInfo.DimColumn),
				param.SinkTable(fmt.Sprintf("depend_code_%s", dimInfo.DimColumn)),
			)
			dependSql = append(dependSql, fmt.Sprintf("select b.code as curr_code, a.id as id, a.code as code from depend_code_%s a join enum_list b on a.code = b.%s",
				dimInfo.DimColumn, dimInfo.DimColumn))
		}
		fl.ExeProduceSql(strings.Join(dependSql, " union all "), param.SinkTable("depend_code_list"))
		fl.ExeView(param.SourceTable("depend_code_list"), &dependList)
	}

	fl.ExeProduceSql(`select code, name from enum_list`, param.SinkTable("data_res"))
	var ret []*dimensions.EnumElement
	fl.ExeView(param.SourceTable("data_res"), &ret)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GenerateCateEnum]引擎调用失败，err=%v+", err)
		return ret, err
	}

	if len(ret) == 1 && len(ret[0].Code) == 0 {
		return nil, errors.New("获取枚举code错误")
	}

	if len(ret) > 0 && len(dependList) > 0 {
		for _, r := range ret {
			r.DependCode = make([]*dimensions.DimSimpleElement, 0)
			for _, d := range dependList {
				if r.Code == d.CurrCode {
					r.DependCode = append(r.DependCode, &dimensions.DimSimpleElement{
						Id:   d.Id,
						Code: d.Code,
					})
				}
			}
		}
	}

	return ret, nil
}

func (d *DynamicEnum) GetFirstMgtCate(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7392949738506667035", "7392949740113052722", nil, nil)
}

func (d *DynamicEnum) GetSecondMgtCate(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7392949738506667035", "7392952099518170150", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstMgtCateDim), DimColumn: "first_mgt_cate_code"},
	}, nil)
}

func (d *DynamicEnum) GetThirdMgtCate(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7392949738506667035", "7392952099518039078", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstMgtCateDim), DimColumn: "first_mgt_cate_code"},
		{ID: convert.ToInt64(consts.SecondMgtCateDim), DimColumn: "second_mgt_cate_code"},
	}, nil)
}

var DimVblineLogicTableID = "7392970899185599498"

func (d *DynamicEnum) GetAFirstVblineList(ctx context.Context) ([]*dimensions.EnumElement, error) {
	ret, err := GetOsTableList(ctx, DimVblineLogicTableID, "7392970902469739557", nil, nil)
	if err == nil {
		for _, enum := range ret {
			if enum.DependCode == nil {
				enum.DependCode = make([]*dimensions.DimSimpleElement, 0)
			}
			enum.DependCode = append(enum.DependCode, &dimensions.DimSimpleElement{
				Id:   consts.VblineGroupABDim,
				Code: "A",
			})
		}
	}
	return ret, err
}

func (d *DynamicEnum) GetASecondVblineList(ctx context.Context) ([]*dimensions.EnumElement, error) {
	ret, err := GetOsTableList(ctx, DimVblineLogicTableID, "7392967636839056410", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineCodeDim), DimColumn: "first_vbline_code"},
	}, nil)
	if err == nil {
		for _, enum := range ret {
			if enum.DependCode == nil {
				enum.DependCode = make([]*dimensions.DimSimpleElement, 0)
			}
			enum.DependCode = append(enum.DependCode, &dimensions.DimSimpleElement{
				Id:   consts.VblineGroupABDim,
				Code: "A",
			})
		}
	}
	return ret, err
}

func (d *DynamicEnum) GetBSecondVblineList(ctx context.Context) ([]*dimensions.EnumElement, error) {
	ret, err := GetOsTableList(ctx, DimVblineLogicTableID, "7392969282830746675", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineCodeDim), DimColumn: "first_vbline_code"},
	}, nil)
	if err == nil {
		for _, enum := range ret {
			if enum.DependCode == nil {
				enum.DependCode = make([]*dimensions.DimSimpleElement, 0)
			}
			enum.DependCode = append(enum.DependCode, &dimensions.DimSimpleElement{
				Id:   consts.VblineGroupABDim,
				Code: "B",
			})
		}
	}
	return ret, err
}

func (d *DynamicEnum) GetFirstVblineCode(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7392960301177603109", nil, nil)
}

func (d *DynamicEnum) GetSecondVblineCode(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7392973116839887909", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineCodeDim), DimColumn: "first_vbline_code"},
	}, nil)
}

func (d *DynamicEnum) GetFirstVblineID(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7543498323492078630", nil, nil)
}

func (d *DynamicEnum) GetSecondVblineID(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7543498040129176603", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineIDDim), DimColumn: "first_vbline_id"},
	}, nil)
}

func (d *DynamicEnum) GetThirdVblineID(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7544947873608205362", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineIDDim), DimColumn: "first_vbline_id"},
		{ID: convert.ToInt64(consts.SecondVblineIDDim), DimColumn: "second_vbline_id"},
	}, nil)
}

func (d *DynamicEnum) GetFourthVblineID(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7544953839149925426", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineIDDim), DimColumn: "first_vbline_id"},
		{ID: convert.ToInt64(consts.SecondVblineIDDim), DimColumn: "second_vbline_id"},
		{ID: convert.ToInt64(consts.ThirdVblineIDDim), DimColumn: "third_vbline_id"},
	}, nil)
}

func (d *DynamicEnum) GetLeafVblineID(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7544953560081925130", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineIDDim), DimColumn: "first_vbline_id"},
		{ID: convert.ToInt64(consts.SecondVblineIDDim), DimColumn: "second_vbline_id"},
		{ID: convert.ToInt64(consts.ThirdVblineIDDim), DimColumn: "third_vbline_id"},
		{ID: convert.ToInt64(consts.FourthVblineIDDim), DimColumn: "fourth_vbline_id"},
	}, nil)
}

func (d *DynamicEnum) GetThirdVblineCode(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7392964455082066994", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineCodeDim), DimColumn: "first_vbline_code"},
		{ID: convert.ToInt64(consts.SecondVblineCodeDim), DimColumn: "second_vbline_code"},
	}, nil)
}

func (d *DynamicEnum) GetFourthVblineCode(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7392973116856665097", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineCodeDim), DimColumn: "first_vbline_code"},
		{ID: convert.ToInt64(consts.SecondVblineCodeDim), DimColumn: "second_vbline_code"},
		{ID: convert.ToInt64(consts.ThirdVblineCodeDim), DimColumn: "third_vbline_code"},
	}, nil)
}

func (d *DynamicEnum) GetLeafVblineCode(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, DimVblineLogicTableID, "7392973281923466278", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.FirstVblineCodeDim), DimColumn: "first_vbline_code"},
		{ID: convert.ToInt64(consts.SecondVblineCodeDim), DimColumn: "second_vbline_code"},
		{ID: convert.ToInt64(consts.ThirdVblineCodeDim), DimColumn: "third_vbline_code"},
		{ID: convert.ToInt64(consts.FourthVblineCodeDim), DimColumn: "fourth_vbline_code"},
	}, nil)
}

func (d *DynamicEnum) GetBrainPoolList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	var ret = make([]*dimensions.EnumElement, 0)
	if len(req.EnumCodeList) > 0 {
		var poolIdList = make([]string, 0)
		for _, code := range req.EnumCodeList {
			poolIdList = append(poolIdList, code)
		}
		// 全量拉取选品大脑货盘，前端调整分页大小保证全量展示
		prodData, err := ecom_ecop_matching_brain.RawCall.ListBrainProdPallet(ctx, &matching_brain.ListBrainProdPalletReq{
			PalletId: poolIdList,
		})
		if err != nil {
			logs.CtxError(ctx, "[GetBrainPoolList]获取选品大脑货盘列表失败，err:", err.Error())
			return nil, 0, err
		}
		for _, poolData := range prodData.Data {
			ret = append(ret, &dimensions.EnumElement{
				Code:         poolData.GetPalletId(),
				Name:         poolData.GetPalletName(),
				CreateUserId: poolData.GetCreatorId(),
				LinkUrl:      poolData.GetBrainDetailUrl(),
			})
		}
		return ret, int64(len(ret)), nil
	}

	// 全量拉取选品大脑货盘，前端调整分页大小保证全量展示
	allProdData, err := ecom_ecop_matching_brain.RawCall.ListBrainProdPallet(ctx, &matching_brain.ListBrainProdPalletReq{})
	if err != nil {
		logs.CtxError(ctx, "[GetBrainPoolList]获取选品大脑货盘列表失败，err:", err.Error())
		return nil, 0, err
	}
	if allProdData == nil {
		logs.CtxError(ctx, "[GetBrainPoolList]选品大脑货盘列表接口返回值为nil")
		return ret, 0, nil
	}
	for _, poolData := range allProdData.Data {
		ret = append(ret, &dimensions.EnumElement{
			Code:         poolData.GetPalletId(),
			Name:         poolData.GetPalletName(),
			CreateUserId: poolData.GetCreatorId(),
			LinkUrl:      poolData.GetBrainDetailUrl(),
		})
	}
	return ret, int64(len(ret)), nil
}

func (d *DynamicEnum) GetAuthorVerticalList(ctx context.Context) ([]*dimensions.EnumElement, error) {
	var ret = make([]*dimensions.EnumElement, 0)
	var params = map[string]interface{}{}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, "7434825523437569062", param.SinkTable("author_vertical"))
	f.ExeView(param.SourceTable("author_vertical"), &ret)
	app.Use(f.ToStack(ctx))
	_, err := app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return ret, nil
}

func (d *DynamicEnum) GetIndustryCategoryList(ctx context.Context) ([]*dimensions.EnumElement, error) {
	var ret = make([]*dimensions.EnumElement, 0)
	var params = map[string]interface{}{}
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, "7435914282623091763", param.SinkTable("industry_category"))
	f.ExeView(param.SourceTable("industry_category"), &ret)
	app.Use(f.ToStack(ctx))
	_, err := app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, err
	}
	return ret, nil
}

func (d *DynamicEnum) GetMorningMarketPool(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	ret := make([]*dimensions.EnumElement, 0)
	var dimIdInteger = convert.ToInt64(req.DimensionId)
	var source int64 = 0
	if dimIdInteger == 93002 {
		source = 1
	}
	if len(req.EnumCodeList) > 0 {
		var poolIdList = make([]int64, 0)
		for _, code := range req.EnumCodeList {
			poolIdList = append(poolIdList, convert.ToInt64(code))
		}
		poolMetaList, err := dao.GetPoolMetaList(ctx, &dimIdInteger, req.PageInfo, poolIdList, nil, source)
		if err != nil {
			return ret, 0, err
		}
		for _, info := range poolMetaList {
			ret = append(ret, &dimensions.EnumElement{
				Code: convert.ToString(info.PoolId),
				Name: info.PoolName,
			})
		}
		return ret, int64(len(ret)), nil
	}

	poolMetaList, err := dao.GetPoolMetaList(ctx, &dimIdInteger, req.PageInfo, nil, req.SearchEnumName, source)
	if err != nil {
		return ret, 0, err
	}
	for _, info := range poolMetaList {
		ret = append(ret, &dimensions.EnumElement{
			Code: convert.ToString(info.PoolId),
			Name: info.PoolName,
		})
	}
	poolCnt, err := dao.GetPoolMetaNum(ctx, dimIdInteger)
	if err != nil {
		return ret, 0, err
	}
	return ret, poolCnt, nil
}

func (d *DynamicEnum) GetInvestActivityList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	ret := make([]*dimensions.EnumElement, 0)
	if len(req.EnumCodeList) > 0 {
		enumList, err := biz_utils.SearchInvestActivityInfoByIdOrName(ctx, "", 1, 10000)
		if err != nil {
			return ret, 0, err
		}
		return enumList, int64(len(enumList)), nil
	}
	if req.SearchEnumName == nil || len(*req.SearchEnumName) == 0 {
		return ret, 0, nil
	}
	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 20
	}
	enumList, err := biz_utils.SearchInvestActivityInfoByIdOrName(ctx, *req.SearchEnumName, pageNum, pageSize)
	if err != nil {
		return ret, 0, err
	}
	return enumList, int64(len(enumList)), nil
}

func (d *DynamicEnum) GetProdNameList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	ret := make([]*dimensions.EnumElement, 0)

	if len(req.EnumCodeList) > 0 {
		codeList := make([]int64, 0)
		for _, code := range req.EnumCodeList {
			codeList = append(codeList, convert.ToInt64(code))
		}
		productInfoList, err := biz_utils.GetProductInfoByIdList(ctx, codeList)
		if err != nil {
			return ret, 0, err
		}
		if len(productInfoList) > 0 {
			for _, info := range productInfoList {
				ret = append(ret, &dimensions.EnumElement{
					Code: info.Id,
					Name: info.Name,
				})
			}
		}
		return ret, int64(len(ret)), nil
	}
	if req.SearchEnumName == nil {
		req.SearchEnumName = convert.ToStringPtr("")
	}
	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 20
	}

	productInfoList, err := biz_utils.SearchProdInfoByIdOrName(ctx, *req.SearchEnumName, pageNum, pageSize)
	if err != nil {
		return ret, 0, err
	}
	if len(productInfoList) > 0 {
		for _, info := range productInfoList {
			ret = append(ret, &dimensions.EnumElement{
				Code: convert.ToString(info.Id),
				Name: info.Name,
			})
		}
	}
	return ret, int64(len(ret)), nil
}

func (d *DynamicEnum) GetShopNameList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	ret := make([]*dimensions.EnumElement, 0)

	if len(req.EnumCodeList) > 0 {
		for _, code := range req.EnumCodeList {
			if id := convert.ToInt64(code); id > 0 {
				shopsWithShopId, err := biz_utils.SearchShopByIdOrName(ctx, &id, nil, 0, 1)
				if err != nil {
					return ret, 0, err
				}
				if len(shopsWithShopId) > 0 {
					for _, info := range shopsWithShopId {
						ret = append(ret, &dimensions.EnumElement{
							Code: info.Id,
							Name: info.Name,
						})
					}
				}
			}
		}
		return ret, int64(len(ret)), nil
	}

	if req.SearchEnumName == nil || len(*req.SearchEnumName) == 0 {
		return ret, 0, nil
	}

	if id := convert.ToInt64(req.SearchEnumName); id > 0 && req.PageInfo.PageNum == 1 {
		shopsWithShopId, err := biz_utils.SearchShopByIdOrName(ctx, &id, nil, 0, 1)
		if err != nil {
			return ret, 0, err
		}
		if len(shopsWithShopId) > 0 {
			for _, info := range shopsWithShopId {
				ret = append(ret, &dimensions.EnumElement{
					Code: info.Id,
					Name: info.Name,
				})
			}
		}
	}

	shopsWithShopName, err := biz_utils.SearchShopByIdOrName(ctx, nil, req.SearchEnumName, int64(req.PageInfo.PageNum), int64(req.PageInfo.PageSize))
	if err != nil {
		return ret, 0, err
	}
	if len(shopsWithShopName) > 0 {
		for _, info := range shopsWithShopName {
			ret = append(ret, &dimensions.EnumElement{
				Code: info.Id,
				Name: info.Name,
			})
		}
	}

	return ret, int64(len(ret)), nil
}

func (d *DynamicEnum) GetSkuClusterNameList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	ret := make([]*dimensions.EnumElement, 0)

	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 20
	}

	var params = make(map[string]interface{})
	if len(req.EnumCodeList) > 0 {
		pageNum = 1
		pageSize = int64(len(req.EnumCodeList))
		params["cids"] = req.EnumCodeList
	}
	if req.SearchEnumName != nil && len(*req.SearchEnumName) > 0 {
		params["key_word"] = *req.SearchEnumName
	}

	apiPath := "7441125309597991962"
	newest, err := utils.GetNewestDay(ctx, consts.LogicTableSkuClusterBase)
	if err != nil {
		return nil, 0, err
	}
	if len(params) == 0 {
		apiPath = "7443739931102495781"
		newest, err = utils.GetNewestDay(ctx, consts.LogicTableVolumePriceProdVidFlowTable)
		if err != nil {
			return nil, 0, err
		}
	}
	params["limit"] = pageSize
	params["offset"] = (pageNum - 1) * pageSize
	params["date"] = newest

	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	f := flow.Empty()
	f.ExeQueryInvokerRaw(params, apiPath, param.SinkTable("res_data"))
	f.ExeView(param.SourceTable("res_data"), &ret)
	app.Use(f.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return nil, 0, err
	}
	return ret, int64(len(ret)), nil
}

func (d *DynamicEnum) GetBrandNameList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	ret := make([]*dimensions.EnumElement, 0)

	if len(req.EnumCodeList) > 0 {
		var brandIdList = make([]int64, 0)
		for _, code := range req.EnumCodeList {
			if id := convert.ToInt64(code); id > 0 {
				brandIdList = append(brandIdList, id)
			}
		}
		brandInfoList, err := biz_utils.SearchBrandInfoByIdOrName(ctx, "", 1, 10000, brandIdList)
		if err != nil {
			return ret, 0, err
		}
		if len(brandInfoList) > 0 {
			for _, info := range brandInfoList {
				ret = append(ret, &dimensions.EnumElement{
					Code: info.Id,
					Name: info.Name,
				})
			}
		}
		return ret, int64(len(ret)), nil
	}
	if req.SearchEnumName == nil || len(*req.SearchEnumName) == 0 {
		return ret, 0, nil
	}
	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 20
	}
	brandInfoList, err := biz_utils.SearchBrandInfoByIdOrName(ctx, *req.SearchEnumName, pageNum, pageSize, nil)
	if err != nil {
		return ret, 0, err
	}
	if len(brandInfoList) > 0 {
		for _, info := range brandInfoList {
			ret = append(ret, &dimensions.EnumElement{
				Code: info.Id,
				Name: info.Name,
			})
		}
	}
	return ret, int64(len(ret)), nil
}

// PriceResponsibilityMapping 价格力订单分工映射
type PriceResponsibilityMapping struct {
	ResponsibilityAll    string `json:"responsibility_all"`
	ResponsibilityFirst  string `json:"responsibility_first"`
	ResponsibilitySecond string `json:"responsibility_second"`
}

func GetResponsibilityFirstList(ctx context.Context, responsibilityAll string) ([]string, error) {
	res, err := GetPriceResponsibilityMapping(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetPriceResponsibilityMapping，err:"+err.Error())
		return nil, err
	}

	firstList := make([]string, 0)
	for _, r := range res {
		if len(responsibilityAll) > 0 && responsibilityAll != r.ResponsibilityAll {
			continue
		}
		firstList = append(firstList, r.ResponsibilityFirst)
	}
	return slices.DistinctString(firstList), nil
}

func GetResponsibilityFirstListWithSub(ctx context.Context) ([]string, error) {
	res, err := GetPriceResponsibilityMapping(ctx)
	if err != nil {
		logs.CtxError(ctx, "GetPriceResponsibilityMapping，err:"+err.Error())
		return nil, err
	}

	firstCntMap := make(map[string]int64, 0)
	for _, r := range res {
		firstCntMap[r.ResponsibilityFirst] += 1
	}

	firstList := make([]string, 0)
	for k, v := range firstCntMap {
		if v > 1 {
			firstList = append(firstList, k)
		}
	}
	return slices.DistinctString(firstList), nil
}

func GetPriceResponsibilityMapping(ctx context.Context) ([]*PriceResponsibilityMapping, error) {
	newest, err := utils.GetNewestDay(ctx, "7390286445023462426")
	if err != nil {
		logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
		return nil, err
	}

	// 启动引擎 发车
	doc := document.NewEmptyDoc()
	app := application.NewApp(doc)
	fl := flow.Empty()
	fl.ExeQueryInvokerRaw(map[string]interface{}{"date": newest}, "7390298665933407258", param.SinkTable("data_res"))
	var ret []*PriceResponsibilityMapping
	fl.ExeView(param.SourceTable("data_res"), &ret)
	app.Use(fl.ToStack(ctx))
	_, err = app.Run(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GenerateCateEnum]引擎调用失败，err=%v+", err)
		return ret, err
	}
	return ret, nil
}

func (d *DynamicEnum) GetProductPoolList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	analysisPoolDoList := make([]*dao.AnalysisPoolDo, 0)
	pageSize := int(req.PageInfo.PageSize)
	offset := int(req.PageInfo.PageNum-1) * pageSize
	if len(req.EnumCodeList) > 0 {
		tx := mysql.DB(ctx)
		// 通过id查询货盘
		err := tx.Table("analysis_pool").Where("is_delete", 0).
			Where("pool_id in ?", req.EnumCodeList).
			Order("id DESC").Find(&analysisPoolDoList).Error
		// Where("JSON_EXTRACT(pool_rule,'$.biz_type') = ?", req.GetBizType()).
		if err != nil {
			return nil, 0, err
		}
	} else {
		var poolName string
		if req.SearchEnumName != nil {
			poolName = *req.SearchEnumName
		}
		tx := mysql.DB(ctx)
		// 查询货盘
		err := tx.Table("analysis_pool").Where("is_delete", 0).
			Where("pool_name like ?", "%"+poolName+"%").
			Order("id DESC").Find(&analysisPoolDoList).Error
		if len(analysisPoolDoList) == 0 {
			err = tx.Table("analysis_pool").Where("is_delete", 0).
				Where("pool_id like ?", "%"+poolName+"%").
				Order("id DESC").Find(&analysisPoolDoList).Error
		}
		// Where("JSON_EXTRACT(pool_rule,'$.biz_type') = ?", req.GetBizType()).
		if err != nil {
			return nil, 0, err
		}
	}

	newRes := make([]*dao.AnalysisPoolDo, 0)
	for _, pool := range analysisPoolDoList {
		if pool.PoolType == 0 { // 手动录入
			newRes = append(newRes, pool)
		} else if pool.PoolType == 1 {
			var poolRule *dimensions.ProductAnalysisBaseStruct
			_ = json.Unmarshal([]byte(pool.PoolRule), &poolRule)
			// 规则货盘需要有类型
			if poolRule == nil {
				continue
			}
			bizType := req.GetBizType()
			if bizType == dimensions.BizType_AttributionCore ||
				bizType == dimensions.BizType_AttributionCoreGuess {
				bizType = dimensions.BizType_GrowthProductStrategy
			}
			if poolRule.GetBizType() != bizType {
				continue
			}
			newRes = append(newRes, pool)
		}
	}
	res := make([]*dimensions.EnumElement, 0)
	for _, pool := range newRes[math.MinInt(len(newRes), offset):math.MinInt(len(newRes), offset+pageSize)] {
		elem := &dimensions.EnumElement{
			Code:         pool.PoolId,
			Name:         pool.PoolName,
			CreateUserId: pool.CreateUserId,
		}
		res = append(res, elem)
	}
	return res, int64(len(newRes)), nil
}

// GetMainProjectList 获取主项目列表
func (d *DynamicEnum) GetMainProjectList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	// ret := make([]*dimensions.EnumElement, 0)

	if req.SearchEnumName == nil {
		req.SearchEnumName = conv.StringPtr("")
	}
	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 100
	}
	return biz_utils.SearchActivityDimensionsList(ctx, "7424185101342229541", *req.SearchEnumName, "", pageNum, pageSize)
	// return biz_utils.SearchGeneralAttrListByIdOrName(ctx, "7414032782323663899", "main_project", *req.SearchEnumName, pageNum, pageSize)
}

// GetMainActivityList 获取主活动列表
func (d *DynamicEnum) GetMainActivityList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	// ret := make([]*dimensions.EnumElement, 0)
	// if req.SearchEnumName == nil || len(*req.SearchEnumName) == 0 {
	// 	return ret, 0, nil
	// }
	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 100
	}

	dependId := ""
	if len(req.DependDims) > 0 {
		dependId = req.DependDims[0].Id
	}
	if req.SearchEnumName == nil {
		req.SearchEnumName = conv.StringPtr("")
	}
	// dependId := req.DependDims
	return biz_utils.SearchActivityDimensionsList(ctx, "7424417814217376805", *req.SearchEnumName, dependId, pageNum, pageSize)
	// return biz_utils.SearchGeneralAttrListByIdOrName(ctx, "7414032782323663899", "main_activity", *req.SearchEnumName, pageNum, pageSize)
}

// GetActivityListForActivityReview 获取活动列表，用于活动复盘
func (d *DynamicEnum) GetActivityListForActivityReview(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	// ret := make([]*dimensions.EnumElement, 0)
	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 100
	}
	dependId := ""
	if len(req.DependDims) > 0 {
		dependId = string(req.DependDims[0].Id)
	}
	if req.SearchEnumName == nil {
		req.SearchEnumName = conv.StringPtr("")
	}
	return biz_utils.SearchActivityDimensionsList(ctx, "7424429274205078565", *req.SearchEnumName, dependId, pageNum, pageSize)
	// return biz_utils.SearchGeneralAttrListByIdOrName(ctx, "7414032782323663899", "activity", *req.SearchEnumName, pageNum, pageSize)
}

// GetPickPlanList 获取企划列表，用于活动复盘
func (d *DynamicEnum) GetPickPlanList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {

	var pageSize, pageNum int64
	if req.PageInfo != nil {
		pageSize = int64(req.PageInfo.PageSize)
		pageNum = int64(req.PageInfo.PageNum)
	} else {
		pageNum = 1
		pageSize = 100
	}
	dependId := ""
	if len(req.DependDims) > 0 {
		dependId = req.DependDims[0].Id
	}
	if req.SearchEnumName == nil {
		req.SearchEnumName = conv.StringPtr("")
	}
	return biz_utils.SearchActivityDimensionsList(ctx, "7424447088987079706", *req.SearchEnumName, dependId, pageNum, pageSize)
	// return biz_utils.SearchGeneralAttrListByIdOrName(ctx, "7414032782323663899", "activity", *req.SearchEnumName, pageNum, pageSize)
}

// GetPushAuditTagList push商品池审核标签
func (d *DynamicEnum) GetPushAuditTagList(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTablePushPool, "7447410792934212617", nil, nil)
}

// 选品大脑-人品撮合动作一级来源
func (d *DynamicEnum) GetAuthProdMatchFirstSource(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableXPDNProdAuthorTable, "7446836059071120410", nil, nil)
}

// 选品大脑-人品撮合动作二级来源
func (d *DynamicEnum) GetAuthProdMatchSecondSource(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableXPDNProdAuthorTable, "7446939716223566886", nil, nil)
}

// 选品大脑-人品撮合动作三级来源
func (d *DynamicEnum) GetAuthProdMatchThirdSource(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableXPDNProdAuthorTable, "7446938767568438282", nil, nil)
}

// 选品大脑-人品撮合动作四级来源
func (d *DynamicEnum) GetAuthProdMatchForthSource(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, consts.LogicTableXPDNProdAuthorTable, "7446974347685692425", nil, nil)
}

// mix商品动态维度
func (d *DynamicEnum) GetMixDynamicDimensionOriginTypeValues(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dim_key"] = "origin_type"
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.LogicTableMixProdDynamicDimensionsTable, "7450040410044515354", "7450044227737633842")
}

// mix商品动态维度
func (d *DynamicEnum) GetMixDynamicDimensionCoudanComeCouponValues(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dim_key"] = "coudan_come_coupon"
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.LogicTableMixProdDynamicDimensionsTable, "7450040410044515354", "7450044227737633842")
}

// mix商品动态维度
func (d *DynamicEnum) GetMixDynamicDimensionRenderTypeValues(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dim_key"] = "render_type"
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.LogicTableMixProdDynamicDimensionsTable, "7450040410044515354", "7450044227737633842")
}

// mix商品活动列表
func (d *DynamicEnum) GetMixActivityName(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.LogicTableAppPrmMixProdStatsTable, "7451576625411507210", consts.Empty)
}

// mix商品排期页面
func (d *DynamicEnum) GetMixPageName(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.LogicTableAppPrmMixProdStatsTable, "7451577047740154918", consts.Empty)
}

// mix商品模块
func (d *DynamicEnum) GetMixModuleName(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.LogicTableAppPrmMixProdStatsTable, "7451575029692646437", consts.Empty)
}

// mix商品btm_pre
func (d *DynamicEnum) GetMixBTMPreName(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.LogicTableAppPrmMixProdStatsTable, "7451579619855172635", consts.Empty)
}

func (d *DynamicEnum) GetSkuClusterFirstVblineCode(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7458261068624757797", "7467737623411344410", nil, nil)
}

func (d *DynamicEnum) GetSkuClusterSecondVblineCode(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7458261068624757797", "7467738121904407579", []dao.DimensionInfo{
		{ID: convert.ToInt64(10270), DimColumn: "first_vbline_id"},
	}, nil)
}

// 超值购专项-搜索-陈森

// 一级子塞道
func (d *DynamicEnum) GetSearchFirstVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7478658037922743332", "7478959760033760268", nil, nil)
}

// 二级子塞道
func (d *DynamicEnum) GetSearchSecondVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7478658037922743332", "7478960425095152676", nil, nil)
}

// 三级子塞道
func (d *DynamicEnum) GetSearchThirdVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7478658037922743332", "7478960425095267364", nil, nil)
}

// 搜索渠道维度
func (d *DynamicEnum) GetSearchChanel(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, "7478658037922743332", "7478960096874103827", nil, nil)
}

// GetRecruitProd 招募策略ID
func (d *DynamicEnum) GetRecruitProd(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "recruit_prod"
	enumElement, total, err := biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionTable, "7501657758362567732", "7501657860238083072")
	return enumElement, total, err
}

// SearchRecruitEnums 获取招募策略ID（不区分是否注册）
func (d *DynamicEnum) SearchRecruitEnums(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "package_dim_recruit"
	enumElement, total, err := biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionTable, "7595883398263014409", "7595885845446476827")
	enumElementMap := make(map[string]*dimensions.EnumElement)
	enumCodeList := make([]string, 0)
	for _, enum := range enumElement {
		enumElementMap[enum.Code] = enum
		enumCodeList = append(enumCodeList, enum.Code)
	}
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, 0, errors.New("获取数据库的事务失败")
	}
	dimensionsStatus, err := d.NeedDumpDimensionDao.BatchGetByEntityIDsAndType(ctx, tx, enumCodeList, int32(dimensions.RegisterDimensionType_RecruitProd))
	if err != nil {
		return nil, 0, err
	}
	dimensionsStatusMap := make(map[string]int32)
	for _, status := range dimensionsStatus {
		dimensionsStatusMap[status.EntityID] = status.AnalysisStatus
	}

	for _, enum := range enumElement {
		if status, ok := dimensionsStatusMap[enum.Code]; ok {
			enum.ExtraInfo = convert.ToJSONString(map[string]interface{}{
				"sync_status": status,
			})
		} else {
			enum.ExtraInfo = convert.ToJSONString(map[string]interface{}{
				"sync_status": int32(dimensions.AnalysisStatus_UnRegister),
			})
		}
	}
	return enumElement, total, err
}

// SearchInvestmentSelectEnums 获取招商选品集ID（不区分是否注册）
func (d *DynamicEnum) SearchInvestmentSelectEnums(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "package_dim_investment_select"
	enumElement, total, err := biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionTable, "7595883398263014409", "7595885845446476827")
	enumElementMap := make(map[string]*dimensions.EnumElement)
	enumCodeList := make([]string, 0)
	for _, enum := range enumElement {
		enumElementMap[enum.Code] = enum
		enumCodeList = append(enumCodeList, enum.Code)
	}
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, 0, errors.New("获取数据库的事务失败")
	}
	dimensionsStatus, err := d.NeedDumpDimensionDao.BatchGetByEntityIDsAndType(ctx, tx, enumCodeList, int32(dimensions.RegisterDimensionType_InvestmentSelectProd))
	if err != nil {
		return nil, 0, err
	}
	dimensionsStatusMap := make(map[string]int32)
	for _, status := range dimensionsStatus {
		dimensionsStatusMap[status.EntityID] = status.AnalysisStatus
	}

	for _, enum := range enumElement {
		if status, ok := dimensionsStatusMap[enum.Code]; ok {
			enum.ExtraInfo = convert.ToJSONString(map[string]interface{}{
				"sync_status": status,
			})
		} else {
			enum.ExtraInfo = convert.ToJSONString(map[string]interface{}{
				"sync_status": int32(dimensions.AnalysisStatus_UnRegister),
			})
		}
	}
	return enumElement, total, err
}

// SearchProd360tEnums 获取360选品集ID（不区分是否注册）
func (d *DynamicEnum) SearchProd360tEnums(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	enumElements := make([]*dimensions.EnumElement, 0)
	// 读注册数据
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, 0, errors.New("获取数据库的事务失败")
	}
	enumCodeList := make([]string, 0)
	if req.SearchEnumName != nil && *req.SearchEnumName != "" {
		enumCodeList = append(enumCodeList, *req.SearchEnumName)
	}
	if req.PageInfo == nil {
		req.PageInfo = &base.PageInfo{
			PageNum:  1,
			PageSize: 5,
		}
	}
	dimensionsInfo, total, err := d.NeedDumpDimensionDao.GetNeedDumpDimensionList(ctx, tx, &dao.NeedDumpDimensionQueryParams{
		EntityIDs:      enumCodeList,
		DimensionTypes: []int32{int32(dimensions.RegisterDimensionType_SelectProd360)},
		PageNum:        int(req.PageInfo.PageNum),
		PageSize:       int(req.PageInfo.PageSize),
	})
	if err != nil {
		return nil, 0, err
	}
	if req.SearchEnumName == nil || *req.SearchEnumName == "" {
		for _, info := range dimensionsInfo {
			enumElements = append(enumElements, &dimensions.EnumElement{
				Code: info.EntityID,
				Name: info.EntityName,
				ExtraInfo: convert.ToJSONString(map[string]interface{}{
					"sync_status": info.AnalysisStatus,
				}),
			})
		}
	} else {
		dimensionsInfoMap := make(map[string]*model.NeedDumpProdUserDimension)
		for _, info := range dimensionsInfo {
			dimensionsInfoMap[info.EntityID] = info
		}
		if info := dimensionsInfoMap[*req.SearchEnumName]; info != nil {
			enumElements = append(enumElements, &dimensions.EnumElement{
				Code: info.EntityID,
				Name: info.EntityName,
				ExtraInfo: convert.ToJSONString(map[string]interface{}{
					"sync_status": info.AnalysisStatus,
				}),
			})
		} else {
			// 读RPC数据
			productPoolIds := make([]int64, 0)
			productPoolIds = append(productPoolIds, convert.ToInt64(*req.SearchEnumName))
			poolIdInfos, err := com_commop_product360.QueryProductPoolByIds(ctx, productPoolIds)
			if err != nil {
				logs.CtxError(ctx, "获取选品中心商品包元数据失败,err:"+err.Error())
				return nil, 0, err
			}
			if poolIdInfo := poolIdInfos.TProductPools[0]; poolIdInfo != nil {
				enumElements = append(enumElements, &dimensions.EnumElement{
					Code: convert.ToString(poolIdInfo.Id),
					Name: poolIdInfo.Name,
					ExtraInfo: convert.ToJSONString(map[string]interface{}{
						"sync_status": int32(dimensions.AnalysisStatus_UnRegister),
					}),
				})
			}
			total = 1
		}
	}
	return enumElements, total, nil
}

// SearchCrowdsEnums 获取人群ID（不区分是否注册）
func (d *DynamicEnum) SearchCrowdsEnums(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	enumElements := make([]*dimensions.EnumElement, 0)
	// 读注册数据
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, 0, errors.New("获取数据库的事务失败")
	}
	enumCodeList := make([]string, 0)
	if req.SearchEnumName != nil && *req.SearchEnumName != "" {
		enumCodeList = append(enumCodeList, *req.SearchEnumName)
	}
	if req.PageInfo == nil {
		req.PageInfo = &base.PageInfo{
			PageNum:  1,
			PageSize: 5,
		}
	}
	dimensionsInfo, total, err := d.NeedDumpDimensionDao.GetNeedDumpDimensionList(ctx, tx, &dao.NeedDumpDimensionQueryParams{
		EntityIDs:      enumCodeList,
		DimensionTypes: []int32{int32(dimensions.RegisterDimensionType_CrowdPackage)},
		PageNum:        int(req.PageInfo.PageNum),
		PageSize:       int(req.PageInfo.PageSize),
	})
	if err != nil {
		return nil, 0, err
	}
	if req.SearchEnumName == nil || *req.SearchEnumName == "" {
		for _, info := range dimensionsInfo {
			enumElements = append(enumElements, &dimensions.EnumElement{
				Code: info.EntityID,
				Name: info.EntityName,
				ExtraInfo: convert.ToJSONString(map[string]interface{}{
					"sync_status": info.AnalysisStatus,
				}),
			})
		}
	} else {
		dimensionsInfoMap := make(map[string]*model.NeedDumpProdUserDimension)
		for _, info := range dimensionsInfo {
			dimensionsInfoMap[info.EntityID] = info
		}
		if info := dimensionsInfoMap[*req.SearchEnumName]; info != nil {
			enumElements = append(enumElements, &dimensions.EnumElement{
				Code: info.EntityID,
				Name: info.EntityName,
				ExtraInfo: convert.ToJSONString(map[string]interface{}{
					"sync_status": info.AnalysisStatus,
				}),
			})
		} else {
			// 读RPC数据
			crowdIds := []string{*req.SearchEnumName}
			crowdMetaResp, err := ecom_kunlun_crowdmeta.RawCall.BatchGetCrowdMeta(ctx, &open.BatchGetCrowdMetaRequest{CrowdIds: crowdIds})
			if err != nil {
				logs.CtxError(ctx, "获取人群元数据失败,err:"+err.Error())
				return nil, 0, err
			}
			if crowdMeta := crowdMetaResp.CrowdMetas[0]; crowdMeta != nil {
				enumElements = append(enumElements, &dimensions.EnumElement{
					Code: crowdMeta.CrowdId,
					Name: crowdMeta.CrowdName,
					ExtraInfo: convert.ToJSONString(map[string]interface{}{
						"sync_status": int32(dimensions.AnalysisStatus_UnRegister),
					}),
				})
			}
			total = 1
		}
	}
	return enumElements, total, nil
}

// GetInvestmentSelectProd 招商选品集ID
func (d *DynamicEnum) GetInvestmentSelectProd(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "investment_select_prod"
	enumElement, total, err := biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionTable, "7501657758362567732", "7501657860238083072")
	// 获取底表分区
	entityIds := make([]string, 0)
	for _, elem := range enumElement {
		entityIds = append(entityIds, elem.Code)
	}
	// 查询动态维度状态
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, 0, errors.New("获取数据库的事务失败")
	}
	needDumpDims := make([]*model.NeedDumpDimensionInfo, 0)
	err = tx.Table("need_dump_dimension_info").Where("is_delete = ?", 0).
		Where("dimension_type = ?", 1).Where("entity_id in (?)", entityIds).Find(&needDumpDims).Error
	if err != nil {
		logs.CtxWarn(ctx, "GetInvestmentSelectProd find current entity_id err=%v", err.Error())
		return nil, 0, err
	}
	needCheckIds := make([]string, 0)
	idStatusMap := make(map[string]int, 0)
	for _, entityId := range entityIds { // 初始化状态
		idStatusMap[entityId] = 0 // 都是未同步
	}
	for _, item := range needDumpDims {
		if item.Status == 2 { // 同步中，需要check底表是否有数据
			needCheckIds = append(needCheckIds, item.EntityID)
			idStatusMap[item.EntityID] = 2 // 都是未同步
		}
		if item.Status == 1 { // 同步完成
			idStatusMap[item.EntityID] = 1
		}
	}
	if len(needCheckIds) > 0 {
		needCheckIdsStr := strings.Join(needCheckIds, ",")
		appendParams["entity_id_list"] = needCheckIdsStr
		resMap, err := biz_utils.CheckPartitionExist(ctx, appendParams, consts.DynamicDimensionProdRelationDfTable, "7501959061764703266")
		if err != nil {
			logs.CtxWarn(ctx, "GetInvestmentSelectProd CheckPartitionExist err=%v", err.Error())
			return nil, 0, err
		}
		for _, entityId := range needCheckIds {
			if res, ok := resMap[entityId]; ok && res { // 存在分区，同步完成
				idStatusMap[entityId] = 1
				// 同时更新数据库中的状态
				err = tx.Exec(`
				update need_dump_dimension_info set status = 1 where entity_id =? and dimension_type =?
				`, entityId, 1).Error
				if err != nil {
					tx.Rollback()
					logs.CtxWarn(ctx, "GetInvestmentSelectProd Update Status err=%v", err.Error())
					return nil, 0, err
				}
			}
		}
		tx.Commit()
	}
	// 返回状态
	for _, item := range enumElement {
		if status, ok := idStatusMap[item.Code]; ok {
			extraInfo := map[string]interface{}{
				"investment_status": status,
			}
			extraJson, _ := json.Marshal(extraInfo)
			item.ExtraInfo = string(extraJson)
		}
	}
	return enumElement, total, err
}

// GetBigActivityList 大促项目
func (d *DynamicEnum) GetBigActivityList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "big_activity_list"
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionTable, "7501657758362567732", "7501657860238083072")
}

// GetDynamicDimension 动态维度获取，统一接口
func (d *DynamicEnum) GetDynamicDimension(ctx context.Context, dimensionType string) ([]*dimensions.EnumElement, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = dimensionType
	return GetOsTableList(ctx, consts.AggDynamicDimensionTable, "7502323257429820451", nil, appendParams)
}

// GetPerfFirstVbline 获取业绩口径一级子赛道
func (d *DynamicEnum) GetPerfFirstVbline(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "perf_first_vbline")
}

// GetPerfSecondVbline 获取业绩口径一级子赛道
func (d *DynamicEnum) GetPerfSecondVbline(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "perf_second_vbline")
}

// GetDynamicPerfFirstVblineName 获取业绩口径一级子赛道
func (d *DynamicEnum) GetDynamicPerfFirstVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_perf_first_vbline_name")
}

// GetDynamicPerfSecondVblineName 获取业绩口径一级子赛道
func (d *DynamicEnum) GetDynamicPerfSecondVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_perf_second_vbline_name")
}

// GetDynamicPerfThirdVblineName 获取业绩口径三级子赛道
func (d *DynamicEnum) GetDynamicPerfThirdVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_perf_third_vbline_name")
}

// GetDynamicFirstLocationName 获取一级坑位
func (d *DynamicEnum) GetDynamicFirstLocationName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_first_location")
}

// GetDynamicSecondLocationName 获取二级坑位
func (d *DynamicEnum) GetDynamicSecondLocationName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_second_location")
}

// GetDynamicStrSecondManageCategory 获取二级管理类目
func (d *DynamicEnum) GetDynamicStrSecondManageCategory(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_str_second_mgt_cate")
}

// GetDynamicFirstCateName 获取一级类目名称
func (d *DynamicEnum) GetDynamicFirstCateName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_first_level_cate_name")
}

// GetDynamicSecondCateName 获取二级类目名称
func (d *DynamicEnum) GetDynamicSecondCateName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_second_level_cate_name")
}

// GetDynamicThirdCateName 获取三级类目名称
func (d *DynamicEnum) GetDynamicThirdCateName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_third_level_cate_name")
}

// GetDynamicFirstVblineName 获取一级子赛道
func (d *DynamicEnum) GetDynamicFirstVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_first_vbline_name")
}

// GetDynamicSecondVblineName 获取二级子赛道
func (d *DynamicEnum) GetDynamicSecondVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_second_vbline_name")
}

// GetDynamicThirdVblineName 获取三级子赛道
func (d *DynamicEnum) GetDynamicThirdVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_third_vbline_name")
}

// GetDynamicFourthVblineName 获取四级子赛道
func (d *DynamicEnum) GetDynamicFourthVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return d.GetDynamicDimension(ctx, "name_fourth_vbline_name")
}

// GetMarketProjectList 市集项目
func (d *DynamicEnum) GetMarketProjectList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "market_project"
	return biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionTable, "7501657758362567732", "7501657860238083072")
}

// GetDynamicDimensionBucket 动态维度获取bucket，统一接口
func (d *DynamicEnum) GetDynamicDimensionBucket(ctx context.Context, dimensionType string) ([]*dimensions.EnumElement, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = dimensionType
	return GetOsTableList(ctx, consts.AggDynamicDimensionBucketTable, "7595883398263014409", nil, appendParams)
}

// GetMetricList 指标组指标
func (d *DynamicEnum) GetMetricList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "libra_metric_info"
	enumElement, total, err := biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionBucketTable, "7595883398263014409", "7595885845446476827")
	return enumElement, total, err
}

// GetMetricFlightList 指标组实验枚举
func (d *DynamicEnum) GetMetricFlightList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "libra_metric_flight_info"
	enumElement, total, err := biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionBucketTable, "7595883398263014409", "7595885845446476827")
	return enumElement, total, err
}

// GetMetricGroupList 指标组
func (d *DynamicEnum) GetMetricGroupList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) ([]*dimensions.EnumElement, int64, error) {
	appendParams := make(map[string]interface{})
	appendParams["dimension_type"] = "libra_metric_group_info"
	enumElement, total, err := biz_utils.GetEnumSearchPage(ctx, req, appendParams, consts.AggDynamicDimensionBucketTable, "7595883398263014409", "7595885845446476827")
	return enumElement, total, err
}
