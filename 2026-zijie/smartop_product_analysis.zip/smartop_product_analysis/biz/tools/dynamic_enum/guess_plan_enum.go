package dynamic_enum

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/temai/go_lib/convert"
)

var (
	PlanGuessTableID = "7474608809734964274"
)

func (d *DynamicEnum) GetPlanName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, PlanGuessTableID, "7474838928068068402", nil, nil)
}

func (d *DynamicEnum) GetPlanSignal(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, PlanGuessTableID, "7474846724696130597", nil, nil)
}

func (d *DynamicEnum) GetFirstVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, PlanGuessTableID, "7474877681734108197", nil, nil)
}

func (d *DynamicEnum) GetSecondVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, PlanGuessTableID, "7474878449962845234", nil, nil)
}

func (d *DynamicEnum) GetThirdVblineName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, PlanGuessTableID, "7474880613070292019", nil, nil)
}

func (d *DynamicEnum) GetPlanSceneName(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, PlanGuessTableID, "7486408036374823946", nil, nil)
}

func (d *DynamicEnum) GetPlanNameByScene(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, PlanGuessTableID, "7487935117554435109", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.PlanScene), DimColumn: "scene_join"},
	}, nil)
}

func (d *DynamicEnum) GetSignalNameByScene(ctx context.Context) ([]*dimensions.EnumElement, error) {
	return GetOsTableList(ctx, PlanGuessTableID, "7487935309624230963", []dao.DimensionInfo{
		{ID: convert.ToInt64(consts.PlanScene), DimColumn: "scene_join"},
	}, nil)
}
