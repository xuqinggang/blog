package errs

import (
	"fmt"
	"io"
)

const (
	Common int64 = 10000 //  通用错误
	Http   int64 = 11000 //  api 相关错误

	Product int64 = 20000
	Layer   int64 = 30000

	Db int64 = 90000 // 90000 - 91000
)

// return code
const (
	RetOK = 0

	RetParamInvalid        = Common + 1
	RetInternalError       = Common + 2
	RetJsonMarshalFailed   = Common + 3
	RetJsonUnMarshalFailed = Common + 4
	RetTccFailed           = Common + 5
	RetTccSceneNotExist    = Common + 6

	RetHttpRequestFailed = Http + 1
	RetHttpBadRequest    = Http + 2
	RetHttpUnauthorized  = Http + 3

	RetDBFailed       = Db + 1
	RetDBDeleteFailed = Db + 2
	RetDBQueryIsEmpty = Db + 3

	RetDBDeleteProductPool       = Db + 10
	RetDBSummaryMetricError      = Db + 20
	RetDBPoolProductMetricError  = Db + 21
	RetDBPoolNicknameMetricError = Db + 22

	RetUnknown = 99999
)

// Err SDK错误值
var (
	ErrParamInvalid        = New(RetParamInvalid, "param invalid")
	ErrInternalError       = New(RetInternalError, "internal error")
	ErrJsonMarshalFailed   = New(RetJsonMarshalFailed, "json marshal failed")
	ErrJsonUnMarshalFailed = New(RetJsonUnMarshalFailed, "json unmarshal failed")
	ErrTccFailed           = New(RetTccFailed, "tcc config failed")
	ErrTccSceneNotExist    = New(RetTccSceneNotExist, "tcc scene config is not exist")

	ErrHTTPRequestFailed = New(RetHttpRequestFailed, "api request failed")
	ErrHTTPBadRequest    = New(RetHttpBadRequest, "400 Bad Request")
	ErrHTTPUnauthorized  = New(RetHttpUnauthorized, "401 Unauthorized")

	ErrDBFailed       = New(RetDBFailed, "db failed")
	ErrDBDeleteFailed = New(RetDBDeleteFailed, "db delete failed")

	ErrUnknown = New(RetUnknown, "err unknown")
)

// Error 错误码结构 包含 错误码类型 错误码 错误信息
type Error struct {
	Code int64
	Msg  string
	Desc string
	err  error
}

// New 创建一个error
func New(code int64, msg string) error {
	err := &Error{
		Code: code,
		Msg:  msg,
	}

	return err
}

const (
	Success = "success"
)

// Error 实现error接口，返回error描述
func (e *Error) Error() string {
	if e == nil {
		return Success
	}
	var errMsg string
	if e.err != nil {
		errMsg = e.err.Error()
	}
	return fmt.Sprintf("code:%d, msg:%s, error[%s]", e.Code, e.Msg, errMsg)
}

// Wrap 包装错误
func (e *Error) Wrap(err error) error {
	e.err = err
	return e
}

// Unwrap 解包装
func (e *Error) Unwrap() error {
	return e.err
}

// Format 实现fmt.Formatter接口
func (e *Error) Format(s fmt.State, verb rune) {
	switch verb {
	case 'v':
		io.WriteString(s, e.Error())
	case 's':
		io.WriteString(s, e.Error())
	case 'q':
		fmt.Fprintf(s, "%q", e.Error())
	default:
		// unknown format
		fmt.Fprintf(s, "%%!%c(errs.Error=%s)", verb, e.Error())
	}
}

// Newf 创建一个error，msg支持格式化字符串
func Newf(errType, code int64, format string, params ...interface{}) error {
	msg := fmt.Sprintf(format, params...)
	return &Error{
		Code: code,
		Msg:  msg,
	}
}

// NewWrapErr 创建一个error，支持err嵌套
func NewWrapErr(code int64, msg string, err error) error {
	return &Error{
		Code: code,
		Msg:  msg,
		err:  err,
	}
}

// Code 通过error获取error code
func Code(e error) int32 {
	if e == nil {
		return 0
	}
	err, ok := e.(*Error)
	if !ok {
		return RetUnknown
	}
	if err == nil {
		return 0
	}
	return int32(err.Code)
}

// Msg 通过error获取error msg
func Msg(e error) string {
	if e == nil {
		return Success
	}
	err, ok := e.(*Error)
	if !ok {
		return e.Error()
	}
	if err == nil {
		return Success
	}
	return err.Msg
}
