package framework_udf

// GetMaxStr 字符串max聚合函数
func GetMaxStr(rows []string) (string, error) {
	if len(rows) > 0 {
		return rows[0], nil
	}
	return "", nil
}
