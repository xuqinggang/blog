package framework_udf

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"code.byted.org/aweme-go/hstruct/cast"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"github.com/leekchan/accounting"
	"github.com/shopspring/decimal"
)

// GetFullMetricDisplayValue valueType int 整型，double 保留小数，valueUnit 指标单位 eg："人"、"次"
// 返回值形式: 2,000,000人
func GetFullMetricDisplayValue(value interface{}, valueType, valueUnit string, targetPrecision int) (string, error) {
	if value == nil {
		return "0", nil
	}
	// 开发框架数据的类型为decimal.Decimal，没法用cast直接转型，这里尝试把value转为Float64
	if temp, ok := value.(decimal.Decimal); ok {
		value, _ = temp.Float64()
	}
	ac := &accounting.Accounting{Precision: targetPrecision} // Precision 小数精度

	if valueType == "int" {
		return DeleteZeroSuffix(ac.FormatMoney(value)) + valueUnit, nil
	} else if valueType == "double" && valueUnit == "%" {
		return DeleteZeroSuffix(strconv.FormatFloat(cast.ToFloat64(value)*100, 'f', targetPrecision, 64)) + valueUnit, nil
	} else if valueType == "double" {
		return DeleteZeroSuffix(ac.FormatMoney(value)) + valueUnit, nil
	} else {
		return "unknown_format_type", nil
	}
}

func GetBriefMetricDisplayValueNoErr(value interface{}, valueType, valueUnit string, targetPrecision int) string {
	displayValue, _ := GetBriefMetricDisplayValue(value, valueType, valueUnit, targetPrecision)
	return displayValue
}

// GetBriefMetricDisplayValue valueType int 整型，double 保留小数，valueUnit 指标单位 eg："人"、"次";此方法不会有error，为了兼容框架的udf，添加了一个error的返回值
// 返回值形式: 200万人
func GetBriefMetricDisplayValue(value interface{}, valueType, valueUnit string, targetPrecision int) (string, error) {
	if value == nil {
		return "0", nil
	}
	// 开发框架数据的类型为decimal.Decimal，没法用cast直接转型，这里尝试把value转为Float64
	if temp, ok := value.(decimal.Decimal); ok {
		value, _ = temp.Float64()
	}
	ac := &accounting.Accounting{Precision: targetPrecision} // Precision 小数精度
	if valueType == "int" {
		num := cast.ToInt64(value)
		numAbs := num
		if num < 0 {
			numAbs = -num
		}
		var unit int64 = 10000
		if numAbs >= unit {
			if numAbs/unit >= unit { // 亿级
				// return DeleteZeroSuffix(strconv.FormatFloat(float64(num)/float64(unit*unit), 'f', targetPrecision, 64)) + "亿" + valueUnit, nil
				return DeleteZeroSuffix(ac.FormatMoney(float64(num)/float64(unit*unit))) + "亿" + valueUnit, nil
			} else { // 万级
				// return DeleteZeroSuffix(strconv.FormatFloat(float64(num)/float64(unit), 'f', targetPrecision, 64)) + "万" + valueUnit, nil
				return DeleteZeroSuffix(ac.FormatMoney(float64(num)/float64(unit))) + "万" + valueUnit, nil
			}
		}
		return fmt.Sprintf("%v%v", DeleteZeroSuffix(ac.FormatMoney(num)), valueUnit), nil
	} else if valueType == "double" && (valueUnit == "%" || valueUnit == "pp") {
		return DeleteZeroSuffix(strconv.FormatFloat(cast.ToFloat64(value)*100, 'f', targetPrecision, 64)) + valueUnit, nil
	} else if valueType == "double" {
		num := cast.ToFloat64(value)
		var unit float64 = 10000
		numAbs := math.Abs(num)
		if numAbs >= unit {
			if numAbs/unit >= unit { // 亿级
				// return DeleteZeroSuffix(strconv.FormatFloat(num/(unit*unit), 'f', targetPrecision, 64)) + "亿" + valueUnit, nil
				return DeleteZeroSuffix(ac.FormatMoney(num/(unit*unit))) + "亿" + valueUnit, nil
			} else { // 万级
				// return DeleteZeroSuffix(strconv.FormatFloat(num/unit, 'f', targetPrecision, 64)) + "万" + valueUnit, nil
				return DeleteZeroSuffix(ac.FormatMoney(num/unit)) + "万" + valueUnit, nil
			}
		} else if numAbs < float64(1)/unit && numAbs > 0 { // 大于0且小于万分之一的数，转科学计数法
			return fmt.Sprintf("%.4E", num), nil
		}
		// return DeleteZeroSuffix(strconv.FormatFloat(num, 'f', targetPrecision, 64)) + valueUnit, nil
		return DeleteZeroSuffix(ac.FormatMoney(num)) + valueUnit, nil
	} else if valueType == "string" {
		return convert.ToString(value), nil
	} else {
		return "unknown_format_type", nil
	}
}

// DeleteZeroSuffix 去除结尾的0
func DeleteZeroSuffix(num string) string {
	// 如果不包含小数点，是整数的情况下，则直接返回
	if !strings.Contains(num, ".") {
		return num
	}
	outFlag := true
	for outFlag {
		if strings.HasSuffix(num, "0") {
			num = strings.TrimSuffix(num, "0")
		} else {
			outFlag = false
			break
		}
	}
	if strings.HasSuffix(num, ".") {
		num = strings.TrimSuffix(num, ".")
	}
	return num
}

var year2000 = time.Date(2000, 0, 0, 0, 0, 0, 0, time.Local)

func CustomDate(dateStr string) (string, error) {
	dateTime, err := time.Parse(consts.Fmt_Date, dateStr)
	if err != nil {
		dateTime, err = time.Parse(consts.FmtDate, dateStr)
		if err != nil {
			if ts := convert.ToInt64(dateStr); ts > 0 && ts > year2000.Unix() {
				dateTime = time.Unix(ts, 0)
				return dateTime.Format("01-02(") + consts.WeekDayMap[dateTime.Weekday().String()] + ")", nil
			}
			return "", err
		}
		return dateTime.Format("01-02(") + consts.WeekDayMap[dateTime.Weekday().String()] + ")", nil
	}
	return dateTime.Format("01-02(") + consts.WeekDayMap[dateTime.Weekday().String()] + ")", nil
}

// GetDimensionDisplayName 根据维度英文名拿到对应的中文名，配置的常量中匹配到则返回中文名，匹配不到则返回中文名
func GetDimensionDisplayName(dim string) (string, error) {
	if _, ok := consts.Dim2DisplayNameMap[dim]; ok {
		return consts.Dim2DisplayNameMap[dim], nil
	}
	return dim, nil
}

// CustomDateByDateType 日、周、月的格式化
func CustomDateByDateType(dateStr string, dateType int64) (string, error) {
	switch dateType {
	case int64(base.DateType_DAY):
		dateTime, err := time.Parse(consts.Fmt_Date, dateStr)
		if err != nil {
			return "", err
		}
		return dateTime.Format("01-02(") + consts.WeekDayMap[dateTime.Weekday().String()] + ")", nil
	case int64(base.DateType_WEEK):
		dateTime, err := time.Parse(consts.Fmt_Date, dateStr)
		if err != nil {
			return "", err
		}
		weekEndDate := dateTime.AddDate(0, 0, 6)
		return fmt.Sprintf("%s-%s", dateTime.Format(consts.FmtWeekDay), weekEndDate.Format(consts.FmtWeekDay)), nil
	case int64(base.DateType_MONTH):
		dateTime, err := time.Parse(consts.Fmt_Date, dateStr)
		if err != nil {
			return "", err
		}
		return dateTime.Format(consts.FmtMonth), nil
		// months := []string{"一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"}
		// month := dateTime.Month() // Month 返回 time.Month 类型，其底层是 int
		// return months[month-1], nil
	default:
		return "", errors.New("输入的日期类型不符合标准")
	}
}

// GetCompareDateByProgress 根据进度计算对比日期，日期格式20160102
func GetCompareDateByProgress(startDateStr string, endDateStr string, progress float64) (string, error) {
	startDate, err := time.Parse(consts.FmtDate, startDateStr)
	endDate, err := time.Parse(consts.FmtDate, endDateStr)
	if err != nil {
		return "", err
	}
	// 计算两个时间之间的时间差
	duration := endDate.Sub(startDate)
	// 计算进度
	progressDuration := time.Duration(float64(duration) * progress)
	// 计算目标时间
	targetDate := startDate.Add(progressDuration)
	// 格式化目标时间
	targetDateStr := targetDate.Format("20060102")
	return targetDateStr, nil
}

// Length 计算字符串长度
func Length(str string) (int, error) {
	return utf8.RuneCountInString(str), nil
}
