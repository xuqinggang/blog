package sql_parse

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/temai/go_lib/convert"
	"fmt"
	"reflect"
)

// CQL DSL Model
type CQL struct {
	EngineType         EngineType
	WithClause         []*WithItem
	SelectClause       []*Column
	FromClause         *Table
	WhereClause        *Expression
	RawWhereClause     []*RawWhereExpression
	JoinClause         *JoinItem
	GroupByClause      []*Column
	Rollup             bool
	Cube               bool
	HavingClause       *Expression
	OrderByClause      []*OrderItem
	LimitByClause      *LimitByItem
	LimitClause        *LimitItem
	UnionClause        *UnionItem
	err                []error
	ClickHouseSettings []string
}

type RawWhereExpression string

type EngineType int

func NewCQL() (rcvr *CQL) {
	rcvr = &CQL{}
	return
}

func (rcvr *CQL) Select(items ...string) *CQL {
	rcvr.SelectClause = make([]*Column, 0)
	for _, item := range items {
		rcvr.SelectClause = append(rcvr.SelectClause, &Column{Field: item})
	}
	return rcvr
}

func (rcvr *CQL) RemoveSelect(items ...string) *CQL {
	if len(rcvr.SelectClause) == 0 {
		return rcvr
	}
	rcvr.SelectClause = slices.Filter(rcvr.SelectClause, func(v *Column) bool {
		return !slices.Contains(items, v.Field)
	}).([]*Column)
	return rcvr
}

func (rcvr *CQL) AddSelect(items ...string) *CQL {
	if rcvr.SelectClause == nil {
		rcvr.SelectClause = make([]*Column, 0)
	}
	for _, item := range items {
		rcvr.SelectClause = append(rcvr.SelectClause, &Column{Field: item})
	}
	return rcvr
}

func (rcvr *CQL) SelectAppendColumn(items ...*Column) *CQL {
	if rcvr.SelectClause == nil {
		rcvr.SelectClause = make([]*Column, 0)
	}
	for _, item := range items {
		rcvr.SelectClause = append(rcvr.SelectClause, item)
	}
	return rcvr
}

func (rcvr *CQL) SelectWithColumn(items ...*Column) *CQL {
	rcvr.SelectClause = items
	return rcvr
}

func (rcvr *CQL) From(table string) *CQL {
	rcvr.FromClause = &Table{Table: table}
	return rcvr
}

func (rcvr *CQL) FromCql(cql *CQL) *CQL {
	rcvr.FromClause = &Table{TemporaryTable: cql}
	return rcvr
}

func (rcvr *CQL) Join(table string, using ...string) *CQL {
	Using := make([]*Column, 0)

	for _, c := range using {
		Using = append(Using, &Column{Field: c})
	}

	rcvr.JoinClause = &JoinItem{
		Table:    &Table{Table: table},
		Using:    Using,
		JoinType: LEFT,
	}

	return rcvr
}

func (rcvr *CQL) JoinWithType(table string, joinType JoinType, using ...string) *CQL {
	Using := make([]*Column, 0)

	for _, c := range using {
		Using = append(Using, &Column{Field: c})
	}

	rcvr.JoinClause = &JoinItem{
		Table:    &Table{Table: table},
		Using:    Using,
		JoinType: joinType,
	}

	return rcvr
}

func (rcvr *CQL) FromWithTable(table *Table) *CQL {
	rcvr.FromClause = table
	return rcvr
}

func (rcvr *CQL) Where(expr *Expression) *CQL {
	rcvr.WhereClause = expr
	return rcvr
}

func (rcvr *CQL) SetSortInfo(sortField string, isAsc bool) *CQL {
	ordeType := DESC
	if isAsc {
		ordeType = ASC
	}
	return rcvr.OrderBy(ordeType, sortField)
}

func (rcvr *CQL) SetSortInfoList(isAsc bool, sortFields ...string) *CQL {
	ordeType := DESC
	if isAsc {
		ordeType = ASC
	}
	return rcvr.OrderBy(ordeType, sortFields...)
}

func (rcvr *CQL) SetPageInfo(pageNo, pageSize int32) *CQL {
	return rcvr.LimitOffset(convert.ToInt64((pageNo-1)*pageSize), convert.ToInt64(pageSize))
}

// AddWhereSearchValue 查表检索关键字 - like
func (rcvr *CQL) AddWhereSearchValue(keyWord string, fields ...string) *CQL {
	return rcvr.AddWhereValueWithOperator(keyWord, LIKE, STRING, fields...)
}

// AddWhereSearchValueWithFuzzy 查表检索关键字 - fuzzy_like
func (rcvr *CQL) AddWhereSearchValueWithFuzzy(keyWord string, fields ...string) *CQL {
	return rcvr.AddWhereValueWithOperator(keyWord, FUZZY_LIKE, STRING, fields...)
}

// AddWhereValueWithOperator 查表检索关键字
func (rcvr *CQL) AddWhereValueWithOperator(keyWord string, operator ArithmeticOperatorEnum, valueType ValueType, fields ...string) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}
	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, GetExpressionWithOperator(keyWord, operator, valueType, fields...))
	return rcvr
}

// AddSubQueryWhere
func (rcvr *CQL) AddSubQueryWhere(field string, operator ArithmeticOperatorEnum, subQuery *CQL) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}
	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, &Expression{
		Condition: &Condition{
			Column: &Column{
				Field: field,
			},
			Operator: operator,
			SubQuery: subQuery,
		},
	})
	return rcvr
}

// AddWhere 同AddWhereValueWithOperatorV2
func (rcvr *CQL) AddWhere(field string, operator ArithmeticOperatorEnum, value interface{}) *CQL {
	if rcvr == nil {
		return rcvr
	}
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}
	if operator == IS_NULL || operator == IS_NOT_NULL {
		rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, GetExpressionWithOperator(consts.Empty, operator, STRING, field))
		return rcvr
	}
	valueV := reflect.ValueOf(value)
	if valueV.Kind() == 0 {
		rcvr.err = append(rcvr.err, fmt.Errorf("field %s, array is nil", field))
		return rcvr
	}
	typeV := valueV.Type()
	if typeV.Kind() == reflect.Array || typeV.Kind() == reflect.Slice {
		if operator != IN && operator != NOT_IN && operator != BETWEEN && operator != HAS_ANY && operator != HAS_ANY_NOT {
			rcvr.err = append(rcvr.err, fmt.Errorf("illegal filed type: %s", field))
			return rcvr
		}
		return rcvr.addWhereArrayValue(field, operator, value)
	}

	v, err := convert.ToStringE(value)
	if err != nil {
		rcvr.err = append(rcvr.err, fmt.Errorf("illegal filed type: %s", field))
		return rcvr
	}

	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, GetExpressionWithOperator(v, operator, getValueType(value), field))
	return rcvr
}

// AddWhereRawCond 原生Sql
func (rcvr *CQL) AddWhereRawCond(cond string, value ...interface{}) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}
	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, NewRawExpression(cond, value...))
	return rcvr
}

// addWhereArrayValue 添加where条件 in (expr1, expr2)
func (rcvr *CQL) addWhereArrayValue(field string, op ArithmeticOperatorEnum, values interface{}) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}
	valueV := reflect.ValueOf(values)
	conditionValues := make([]*FieldValue, 0)
	if valueV.Kind() == 0 || valueV.Len() == 0 {
		rcvr.err = append(rcvr.err, fmt.Errorf("field %s, array is nil", field))
		return rcvr
	}
	valueType := getValueType(valueV.Index(0).Interface())
	for i := 0; i < valueV.Len(); i++ {
		conditionValues = append(conditionValues, &FieldValue{
			ValueType: valueType,
			Value:     convert.ToString(valueV.Index(i).Interface()),
		})
	}

	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, &Expression{
		Condition: &Condition{
			Column: &Column{
				Field: field,
			},
			Operator: op,
			Values:   conditionValues,
		},
	})

	return rcvr
}

// AddRawWhereAndValue 添加where条件 - and
func (rcvr *CQL) AddRawWhereAndValue(whereEle ...*RawWhereExpression) *CQL {
	if rcvr.RawWhereClause == nil {
		rcvr.RawWhereClause = make([]*RawWhereExpression, 0)
	}
	if len(whereEle) > 0 {
		rcvr.RawWhereClause = append(rcvr.RawWhereClause, whereEle...)
	}
	return rcvr
}

// AddWhereAndValue 添加where条件 - and
func (rcvr *CQL) AddWhereAndValue(whereEle ...*Expression) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}
	if len(whereEle) > 0 {
		for _, w := range whereEle {
			if w != nil && (w.Condition != nil || len(w.Children) > 0) {
				rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, w)
			}
		}
	}
	return rcvr
}

// AddWhereInValue 添加where条件 in (expr1, expr2)
func (rcvr *CQL) AddWhereInValue(valueType ValueType, column string, values []string) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}

	conditionValues := make([]*FieldValue, 0)
	for _, v := range values {
		conditionValues = append(conditionValues, &FieldValue{
			ValueType: valueType,
			Value:     v,
		})
	}

	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, &Expression{
		Condition: &Condition{
			Column: &Column{
				Field: column,
			},
			Operator: IN,
			Values:   conditionValues,
		},
	})

	return rcvr
}

// AddWhereNotInValue 添加where条件 not in (expr1, expr2)
func (rcvr *CQL) AddWhereNotInValue(valueType ValueType, column string, values []string) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}

	conditionValues := make([]*FieldValue, 0)
	for _, v := range values {
		conditionValues = append(conditionValues, &FieldValue{
			ValueType: valueType,
			Value:     v,
		})
	}

	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, &Expression{
		Condition: &Condition{
			Column: &Column{
				Field: column,
			},
			Operator: NOT_IN,
			Values:   conditionValues,
		},
	})

	return rcvr
}

// AddWhereIsNull 添加where条件 is null
func (rcvr *CQL) AddWhereIsNull(column string) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}

	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, &Expression{
		Condition: &Condition{
			Column: &Column{
				Field: column,
			},
			Operator: IS_NULL,
			Values:   nil,
		},
	})

	return rcvr
}

// AddWhereIsNotNull 添加where条件 is not null
func (rcvr *CQL) AddWhereIsNotNull(column string) *CQL {
	if rcvr.WhereClause == nil {
		rcvr.WhereClause = GetAndExpression()
	}

	rcvr.WhereClause.Children = append(rcvr.WhereClause.Children, &Expression{
		Condition: &Condition{
			Column: &Column{
				Field: column,
			},
			Operator: IS_NOT_NULL,
			Values:   nil,
		},
	})

	return rcvr
}

func (rcvr *CQL) AddRawWhere(items ...string) *CQL {
	if len(rcvr.RawWhereClause) == 0 {
		rcvr.RawWhereClause = make([]*RawWhereExpression, 0)
	}
	for _, item := range items {
		t := RawWhereExpression(item)
		rcvr.RawWhereClause = append(rcvr.RawWhereClause, &t)
	}
	return rcvr
}

func (rcvr *CQL) GroupBy(items ...string) *CQL {
	rcvr.GroupByClause = make([]*Column, 0)
	for _, item := range items {
		rcvr.GroupByClause = append(rcvr.GroupByClause, &Column{Field: item})
	}

	return rcvr
}

func (rcvr *CQL) AddGroupBy(items ...string) *CQL {
	if rcvr.GroupByClause == nil {
		rcvr.GroupByClause = make([]*Column, 0)
	}

	for _, item := range items {
		rcvr.GroupByClause = append(rcvr.GroupByClause, &Column{Field: item})
	}

	return rcvr
}

func (rcvr *CQL) GroupByAppendColumns(items ...*Column) *CQL {
	if rcvr.GroupByClause == nil {
		rcvr.GroupByClause = make([]*Column, 0)
	}

	// 为了适配ch中的rollup方法，需要把新加的字段放到group by的最前面
	groupByList := make([]*Column, 0)
	for _, item := range items {
		groupByList = append(groupByList, item)
	}
	rcvr.GroupByClause = append(groupByList, rcvr.GroupByClause...)

	return rcvr
}

func (rcvr *CQL) GroupByWithColumn(items []*Column) *CQL {
	rcvr.GroupByClause = make([]*Column, 0)
	for _, item := range items {
		rcvr.GroupByClause = append(rcvr.GroupByClause, item)
	}

	return rcvr
}

func (rcvr *CQL) WithRollup() *CQL {
	rcvr.Rollup = true
	return rcvr
}

func (rcvr *CQL) WithCube() *CQL {
	rcvr.Cube = true
	return rcvr
}

func (rcvr *CQL) OrderByWithItem(items []*OrderItem) *CQL {
	rcvr.OrderByClause = make([]*OrderItem, 0)
	for _, item := range items {
		rcvr.OrderByClause = append(rcvr.OrderByClause, item)
	}
	return rcvr
}

func (rcvr *CQL) OrderBy(OrderType OrderType, items ...string) *CQL {
	rcvr.OrderByClause = make([]*OrderItem, 0)
	for _, item := range items {
		rcvr.OrderByClause = append(rcvr.OrderByClause, &OrderItem{
			SelectItem: &Column{Field: item},
			OrderType:  OrderType,
		})
	}
	return rcvr
}

func (rcvr *CQL) LimitWithItem(item LimitItem) *CQL {
	rcvr.LimitClause = &item
	return rcvr
}

func (rcvr *CQL) Limit(size int64) *CQL {
	rcvr.LimitClause = NewLimitWithSize(size)
	return rcvr
}

func (rcvr *CQL) LimitOffset(offset int64, size int64) *CQL {
	rcvr.LimitClause = NewLimitWithOffset(offset, size)
	return rcvr
}

func (rcvr *CQL) LimitBy(size int64, items ...string) *CQL {
	rcvr.LimitByClause = &LimitByItem{Size: size}
	columns := make([]*Column, 0)
	for _, item := range items {
		columns = append(columns, &Column{Field: item})
	}
	rcvr.LimitByClause.SelectItems = columns
	return rcvr
}

func Union(ut UnionType, cqls []CQL) *CQL {
	result := NewCQL()
	var unionItem = NewUnionItem()
	unionItem.UnionType = ut
	result.UnionClause = unionItem

	var children = make([]CQL, 0)
	for _, cql := range cqls {
		children = append(children, cql)
	}

	result.UnionClause.Children = children

	return result
}

func (rcvr *CQL) AddClickHouseSettings(settings ...string) *CQL {
	rcvr.ClickHouseSettings = append(rcvr.ClickHouseSettings, settings...)
	return rcvr
}

func (rcvr *CQL) AddHavingValueWithOperator(keyWord string, operator ArithmeticOperatorEnum, valueType ValueType, fields ...string) *CQL {
	if rcvr.HavingClause == nil {
		rcvr.HavingClause = GetAndExpression()
	}
	rcvr.HavingClause.Children = append(rcvr.HavingClause.Children, GetExpressionWithOperator(keyWord, operator, valueType, fields...))
	return rcvr
}

func (rcvr *CQL) AddHavingValueWithExpression(expression *Expression) *CQL {
	if rcvr.HavingClause == nil {
		rcvr.HavingClause = GetAndExpression()
	}
	rcvr.HavingClause.Children = append(rcvr.HavingClause.Children, expression)
	return rcvr
}

// Table Model
type Table struct {
	Alias          string
	Db             string
	Table          string
	TemporaryTable *CQL
}

type ColumnType int

const (
	PlainColumnType ColumnType = iota
	AggregateColumnType
	AlgebraicColumnType
	IfColumnType
	ConstantColumnType
)

type Column struct {
	ColumnType ColumnType
	// PlainColumnType
	Table string
	Field string
	Alias string

	// ConstantColumnType, 所见即所得的常量值,例如,null,直接就是"null"
	ConstantValue string

	// BaseColumn 基类, 用于实现类似 sum(func(BaseColumn)) 这种业务场景
	BaseColumn *Column
	// AggregateColumnType
	AggregateMethod AggregateMethod
	// AlgebraicColumnType
	OperatorEnum AlgebraicOperatorEnum
	Children     []Column
	// IfColumnType
	IfExpression *Expression
	TrueItem     *Column
	FalseItem    *Column
}

type WithItem struct {
	SubQuery     string
	SubQueryName string
}

type JoinType int

const (
	INNER JoinType = iota
	// OUTER
	LEFT
	RIGHT
)

type JoinItem struct {
	Table    *Table
	JoinType JoinType
	Left     *Column
	Right    *Column
	Using    []*Column
}

type OrderType int

const (
	DESC OrderType = iota
	ASC
)

type OrderItem struct {
	SelectItem *Column
	OrderType  OrderType
}

func NewOrderItem(item *Column, t OrderType) (rcvr *OrderItem) {
	rcvr = &OrderItem{}
	rcvr.OrderType = t
	rcvr.SelectItem = item
	return
}

func (rcvr *OrderItem) GetSelectItem() *Column {
	return rcvr.SelectItem
}

func (rcvr *OrderItem) SetSelectItem(selectItem *Column) {
	rcvr.SelectItem = selectItem
}

type Long int64

type LimitItem struct {
	Size   int64
	Offset int64
}

type LimitByItem struct {
	Size        int64
	SelectItems []*Column
}

func NewLimitWithItem() (rcvr *LimitItem) {
	rcvr = &LimitItem{}
	return
}

func NewLimitWithSize(size int64) (rcvr *LimitItem) {
	rcvr = &LimitItem{}
	rcvr.Size = size
	return
}

func NewLimitWithOffset(offset int64, size int64) (rcvr *LimitItem) {
	rcvr = &LimitItem{}
	rcvr.Offset = offset
	rcvr.Size = size
	return
}

func (rcvr *LimitItem) GetOffset() int64 {
	return rcvr.Offset
}

func (rcvr *LimitItem) GetPageNum() int64 {
	return rcvr.Offset / rcvr.Size
}

func (rcvr *LimitItem) GetPageSize() int64 {
	return rcvr.Size
}
func (rcvr *LimitItem) GetSize() int64 {
	return rcvr.Size
}

type UnionType string

const (
	DISTINCT UnionType = "distinct"
	ALL      UnionType = "all"
)

// UnionItem 多表 Join 模型
type UnionItem struct {
	UnionType UnionType
	Children  []CQL
}

func NewUnionItem() (rcvr *UnionItem) {
	rcvr = &UnionItem{}
	return
}

type Expression struct {
	Logic     LogicOperatorEnum
	Children  []*Expression
	Condition *Condition
	Raw       *RawExpr
}

type RawExpr struct {
	Cond  string
	Value []interface{}
}

func NewExpression() (rcvr *Expression) {
	rcvr = &Expression{}
	return
}

func NewRawExpression(cond string, value ...interface{}) (rcvr *Expression) {
	return &Expression{
		Condition: &Condition{Operator: Raw},
		Raw: &RawExpr{
			Cond:  cond,
			Value: value,
		},
	}
}

func NewExpressionWithCondition(cond *Condition) (rcvr *Expression) {
	rcvr = &Expression{}
	rcvr.Condition = cond
	return
}

func NewExpressionWithChild(logic LogicOperatorEnum, child []*Expression) (rcvr *Expression) {
	rcvr = &Expression{}
	rcvr.Children = child
	rcvr.Logic = logic
	return
}

type LogicOperatorEnum int

const (
	AND LogicOperatorEnum = iota
	OR
	EXCEPT
	NOT
)

type FieldValue struct {
	ValueType ValueType
	Value     string
}

type FieldInfo struct {
	ValueType ValueType
	Name      string
}

type ValueType string

const (
	STRING ValueType = "string"
	LONG   ValueType = "long"
	DOUBLE ValueType = "double"
	BOOL   ValueType = "bool"
)

type Condition struct {
	Column   *Column
	Operator ArithmeticOperatorEnum
	// valueCondition: id in (1,2,3)
	Values []*FieldValue
	// composedCondition: id in (select id from xxx)
	SubQuery *CQL
	Raw      string
}

type ArithmeticOperatorEnum string

const (
	EQUAL              ArithmeticOperatorEnum = "="
	NOT_EQUALS         ArithmeticOperatorEnum = "!="
	GREATER_EQUAL_THAN ArithmeticOperatorEnum = ">="
	LESS_EQUAL_THAN    ArithmeticOperatorEnum = "<="
	GREATER_THAN       ArithmeticOperatorEnum = ">"
	LESS_THAN          ArithmeticOperatorEnum = "<"
	BETWEEN            ArithmeticOperatorEnum = "between"
	IN                 ArithmeticOperatorEnum = "in"
	NOT_IN             ArithmeticOperatorEnum = "not in"
	LIKE               ArithmeticOperatorEnum = "like"
	LEFT_LIKE          ArithmeticOperatorEnum = " like"
	RIGHT_LIKE         ArithmeticOperatorEnum = "like "
	FUZZY_LIKE         ArithmeticOperatorEnum = "fuzzy_like"
	NOT_LIKE           ArithmeticOperatorEnum = "not like"
	RAW_LIKE           ArithmeticOperatorEnum = "raw_like"
	IS_NULL            ArithmeticOperatorEnum = "is null"
	IS_NOT_NULL        ArithmeticOperatorEnum = "is not null"
	HAS                ArithmeticOperatorEnum = "has"
	HAS_NOT            ArithmeticOperatorEnum = "has not"
	HAS_ANY            ArithmeticOperatorEnum = "hasAny"
	HAS_ANY_NOT        ArithmeticOperatorEnum = "hasAny not"
	Raw                ArithmeticOperatorEnum = "raw"
	GLOBAL_IN          ArithmeticOperatorEnum = "global in"
)

type AggregateMethod string

const (
	SUM            AggregateMethod = "sum"
	AVG            AggregateMethod = "avg"
	MAX            AggregateMethod = "max"
	MIN            AggregateMethod = "min"
	COUNT          AggregateMethod = "count"
	HLL_SKETCH     AggregateMethod = "hllSketch"
	COUNT_DISTINCT AggregateMethod = "count(distinct "
)

type AlgebraicOperatorEnum string

const (
	ADDITION       AlgebraicOperatorEnum = "+"
	SUBTRACTION    AlgebraicOperatorEnum = "-"
	MULTIPLICATION AlgebraicOperatorEnum = "*"
	DIVISION       AlgebraicOperatorEnum = "/"
)

// Concat rcvr + (1 / (2 + 3) )
func (rcvr *Column) Concat(operatorEnum AlgebraicOperatorEnum, items ...Column) *Column {
	if len(rcvr.Children) == 0 {
		rcvr.Children = make([]Column, 0)
	}

	if rcvr.OperatorEnum == "" {
		rcvr.OperatorEnum = operatorEnum
	}

	// rcvr / (1 + 2)
	if rcvr.OperatorEnum == operatorEnum {

		for _, item := range items {
			rcvr.Children = append(rcvr.Children, item)
		}
		return rcvr

	} else {
		// new a Column
		children := make([]Column, 0)
		// add current item to Children
		children = append(children, *rcvr)
		for _, item := range items {
			// set BaseColumn, for algebraic and agg usage
			i2 := item
			item.BaseColumn = &i2

			children = append(children, item)
		}

		return &Column{
			ColumnType:   AlgebraicColumnType,
			OperatorEnum: operatorEnum,
			Children:     children,
		}
	}
}

func (rcvr *CQL) AddWithClause(subQuery string, subQueryName string) *CQL {
	if rcvr.WithClause == nil {
		rcvr.WithClause = make([]*WithItem, 0)
	}
	rcvr.WithClause = append(rcvr.WithClause, &WithItem{SubQuery: subQuery, SubQueryName: subQueryName})
	return rcvr
}
