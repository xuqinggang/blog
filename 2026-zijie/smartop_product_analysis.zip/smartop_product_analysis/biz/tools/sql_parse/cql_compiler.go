package sql_parse

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"runtime"
	"strings"

	"code.byted.org/gopkg/logs"
	"code.byted.org/security/go-polaris/sql"
	"github.com/bytedance/gopkg/util/logger"

	"code.byted.org/temai/go_lib/convert"
)

func (rcvr *CQL) CompileE(ctx context.Context) (sql string, retErr error) {
	defer func() {
		if err := recover(); err != nil {
			// 打印调用栈信息
			buf := make([]byte, 2048)
			n := runtime.Stack(buf, false)
			stackInfo := fmt.Sprintf("%s", buf[:n])
			logs.CtxError(ctx, "[CQL] rcvr=%v, error:\n%v \npanic recovered: \n%v", convert.ToJSONString(rcvr), err, stackInfo)
			retErr = fmt.Errorf("%+v", err)
		}
	}()
	if len(rcvr.err) > 0 {
		return "", rcvr.err[0]
	}
	return rcvr.Compile(), retErr
}

func (rcvr *CQL) Compile() string {
	if rcvr == nil {
		return ""
	}
	if rcvr.UnionClause != nil {
		return rcvr.parseUnion().String()
	}
	var sb *bytes.Buffer = newStringBuilder()
	sb.WriteString(rcvr.ParseWithClause())
	sb.WriteString(rcvr.parseSelectClause())
	sb.WriteString(rcvr.ParseFromClause())
	sb.WriteString(rcvr.ParseJoinClause())
	sb.WriteString(rcvr.parseWhereClause())
	sb.WriteString(rcvr.ParseRawWhereClause())
	sb.WriteString(rcvr.ParseGroupByClause())
	sb.WriteString(rcvr.ParseHavingClause())
	sb.WriteString(rcvr.ParseOrderClause())
	sb.WriteString(rcvr.ParseLimitByClause())
	sb.WriteString(rcvr.ParseLimitClause())
	sb.WriteString(rcvr.ParseClickHouseSettings())

	return sb.String()
}

func agg2string(agg AggregateMethod) string {
	return string(agg)
}

// algebraic2string 算术运算
func (rcvr *CQL) algebraic2string(operatorEnum AlgebraicOperatorEnum) string {
	return string(operatorEnum)
}

func parseFieldValueList(values []*FieldValue) []string {
	result := make([]string, 0)
	for _, v := range values {
		// STRING类型的用单引号包起来: string.format("'%s'")
		switch v.ValueType {
		case STRING:
			// if strings.Contains(v.Value, "'") { // 包含单引号，就用双引号
			//	result = append(result, fmt.Sprintf("\"%s\"", FormatDBSearchStrWithoutQuotes(v.Value)))
			// } else {
			//	result = append(result, fmt.Sprintf("%s", sql.EscapeSQLData(v.Value)))
			// }
			result = append(result, sql.EscapeSQLData(v.Value))
		case LONG, DOUBLE:
			if _, err := convert.ToFloat64E(v.Value); err != nil {
				logger.Warnf("[parseFieldValueList] err vaule, %w", err)
			}
			result = append(result, v.Value)
		default:
			logger.Warnf("[parseFieldValueList] err vaule, %v", v.ValueType)
		}
	}
	return result
}

func (rcvr *CQL) between(bb *bytes.Buffer, cond Condition) *bytes.Buffer {
	if len(cond.Values) != 2 {
		rcvr.err = append(rcvr.err, errors.New("values size of between should be 2"))
		return bb
	}
	args := parseFieldValueList(cond.Values)
	// bb 定义 Buffer 指针类型
	bb.WriteString(" (")
	bb = rcvr.parsePlainColumn(bb, cond.Column)
	bb.WriteString(" ")
	bb.WriteString(mathOperator2string(cond.Operator))
	bb.WriteString(" ")
	bb.WriteString(args[0])
	bb.WriteString(" and ")
	bb.WriteString(args[1])
	bb.WriteString(" )")
	// 获得拼接后的字符串
	return bb
}

func mathOperator2string(op ArithmeticOperatorEnum) string {
	return string(op)
}

func (rcvr *CQL) commonOperator(sb *bytes.Buffer, cond Condition) *bytes.Buffer {
	sb.WriteString(" ")
	rcvr.parsePlainColumn(sb, cond.Column)
	sb.WriteString(" ")
	sb.WriteString(mathOperator2string(cond.Operator))
	sb.WriteString(" ")

	if len(cond.Values) > 1 {
		sb.WriteString("(")
	}

	sb.WriteString(list2string(parseFieldValueList(cond.Values)))
	if len(cond.Values) > 1 {
		sb.WriteString(")")
	}
	return sb
}

func (rcvr *CQL) in(sb *bytes.Buffer, condition Condition) *bytes.Buffer {
	sb.WriteString(" ")
	rcvr.parsePlainColumn(sb, condition.Column)
	sb.WriteString(" ")
	sb.WriteString(mathOperator2string(condition.Operator))
	sb.WriteString(" (")
	if condition.Values != nil && len(condition.Values) > 0 {
		sb.WriteString(list2string(parseFieldValueList(condition.Values)))
	} else if condition.SubQuery != nil {
		sb.WriteString(condition.SubQuery.Compile())
	} else {
		rcvr.err = append(rcvr.err, errors.New("condition's values and subQuery can't be null at same time"))
		return sb
	}
	sb.WriteString(")")
	return sb
}

func (rcvr *CQL) fuzzyLike(sb *bytes.Buffer, cond Condition) *bytes.Buffer {
	sb.WriteString(" fuzzy_like(")
	rcvr.parsePlainColumn(sb, cond.Column)
	sb.WriteString(", '")
	if len(cond.Values) != 1 {
		rcvr.err = append(rcvr.err, errors.New("fuzzy_like should has and only has one value"))
		return sb
	}
	v := cond.Values[0].Value
	sb.WriteString(FormatDBFuzzyLikeSearchStr(v))
	sb.WriteString("') ")
	return sb
}

func (rcvr *CQL) like(sb *bytes.Buffer, cond Condition) *bytes.Buffer {
	sb.WriteString(" ")
	rcvr.parsePlainColumn(sb, cond.Column)
	sb.WriteString(" ")

	if len(cond.Values) != 1 {
		rcvr.err = append(rcvr.err, errors.New("like should only has one value"))
		return sb
	}
	v := cond.Values[0].Value
	if cond.Operator == RAW_LIKE {
		sb.WriteString("like")
		sb.WriteString(" ")
		sb.WriteString(sql.EscapeSQLData(v))
	} else {
		sb.WriteString(mathOperator2string(cond.Operator))
		if cond.Operator == LIKE || cond.Operator == LEFT_LIKE {
			sb.WriteString(" '%")
		} else {
			sb.WriteString(" '")
		}

		sb.WriteString(FormatDBLikeSearchStr(v))
		if cond.Operator == LIKE || cond.Operator == RIGHT_LIKE {
			sb.WriteString("%' ")
		} else {
			sb.WriteString("' ")
		}
	}
	return sb
}

func (rcvr *CQL) nullable(sb *bytes.Buffer, cond Condition) *bytes.Buffer {
	sb.WriteString(" ")
	rcvr.parsePlainColumn(sb, cond.Column)
	sb.WriteString(" ")
	sb.WriteString(mathOperator2string(cond.Operator))
	return sb
}

func (rcvr *CQL) has(sb *bytes.Buffer, cond Condition) *bytes.Buffer {
	sb.WriteString(" has(")
	rcvr.parsePlainColumn(sb, cond.Column)
	sb.WriteString(", ")
	if len(cond.Values) != 1 {
		rcvr.err = append(rcvr.err, errors.New("has operator should has and only has one value"))
		return sb
	}
	sb.WriteString(parseFieldValueList(cond.Values)[0])
	sb.WriteString(")")
	sb.WriteString(" = 1 ")
	return sb
}

func (rcvr *CQL) hasNot(sb *bytes.Buffer, cond Condition) *bytes.Buffer {
	sb.WriteString(" has(")
	rcvr.parsePlainColumn(sb, cond.Column)
	sb.WriteString(", ")
	if len(cond.Values) != 1 {
		rcvr.err = append(rcvr.err, errors.New("hasNot operator should has and only has one value"))
		return sb
	}
	sb.WriteString(parseFieldValueList(cond.Values)[0])
	sb.WriteString(")")
	sb.WriteString(" = 0 ")
	return sb
}

func (rcvr *CQL) hasAny(sb *bytes.Buffer, cond Condition) *bytes.Buffer {
	sb.WriteString(" hasAny(")
	rcvr.parsePlainColumn(sb, cond.Column)
	sb.WriteString(", ")
	if len(cond.Values) > 0 {
		sb.WriteString("[")
		sb.WriteString(list2string(parseFieldValueList(cond.Values)))
		sb.WriteString("]")
	} else {
		rcvr.err = append(rcvr.err, errors.New("hasAny condition value is empty"))
		return sb
	}
	sb.WriteString(")")
	sb.WriteString(" = 1 ")
	return sb
}

func (rcvr *CQL) hasAnyNot(sb *bytes.Buffer, cond Condition) *bytes.Buffer {
	sb.WriteString(" hasAny(")
	rcvr.parsePlainColumn(sb, cond.Column)
	sb.WriteString(", ")
	if len(cond.Values) > 0 {
		sb.WriteString("[")
		sb.WriteString(list2string(parseFieldValueList(cond.Values)))
		sb.WriteString("]")
	} else {
		rcvr.err = append(rcvr.err, errors.New("hasAny condition value is empty"))
		return sb
	}
	sb.WriteString(")")
	sb.WriteString(" = 0 ")
	return sb
}

func (rcvr *CQL) raw(sb *bytes.Buffer, raw RawExpr) *bytes.Buffer {
	build(sb, raw.Cond, raw.Value...)
	return sb
}

func FormatDBLikeSearchStr(input string) string {
	input = strings.ReplaceAll(input, "\\", "\\\\")
	input = strings.ReplaceAll(input, "%", "\\\\%")
	input = strings.ReplaceAll(input, "_", "\\\\_")
	// TODO. 等待验证
	// input = strings.ReplaceAll(input, "'", "\\'")
	input = strings.ReplaceAll(input, "'", "")
	return input
}

func FormatDBFuzzyLikeSearchStr(input string) string {
	input = strings.ReplaceAll(input, "\\", "\\\\")
	input = strings.ReplaceAll(input, "%", "\\%")
	input = strings.ReplaceAll(input, "_", "\\_")
	input = strings.ReplaceAll(input, "'", "\\'")
	return input
}

func list2string(list []string) string {
	return strings.Join(list, ",")
}

func (rcvr *CQL) logic2string(logic LogicOperatorEnum) string {
	switch logic {
	case AND:
		return "and"
	case OR:
		return "or"
	case EXCEPT:
		return "except"
	case NOT:
		return "not"
	default:
		return ""
	}
}

func (rcvr *CQL) order2string(ot OrderType) string {
	switch ot {
	case ASC:
		return "asc"
	case DESC:
		return "desc"
	default:
		rcvr.err = append(rcvr.err, fmt.Errorf("DFOrderType %d not supported yet", ot))
		return ""
	}
}

func (rcvr *CQL) parseCondition(sb *bytes.Buffer, expression *Expression) *bytes.Buffer {
	switch expression.Condition.Operator {
	case IN, NOT_IN, GLOBAL_IN:
		return rcvr.in(sb, *expression.Condition)
	case BETWEEN:
		return rcvr.between(sb, *expression.Condition)
	case FUZZY_LIKE:
		return rcvr.fuzzyLike(sb, *expression.Condition)
	case LIKE, LEFT_LIKE, RIGHT_LIKE, RAW_LIKE:
		return rcvr.like(sb, *expression.Condition)
	case IS_NULL, IS_NOT_NULL:
		return rcvr.nullable(sb, *expression.Condition)
	case HAS:
		return rcvr.has(sb, *expression.Condition)
	case HAS_NOT:
		return rcvr.hasNot(sb, *expression.Condition)
	case HAS_ANY:
		return rcvr.hasAny(sb, *expression.Condition)
	case HAS_ANY_NOT:
		return rcvr.hasAnyNot(sb, *expression.Condition)
	case Raw:
		return rcvr.raw(sb, *expression.Raw)
	default:
		return rcvr.commonOperator(sb, *expression.Condition)
	}
}

func (rcvr *CQL) parseRawExpression(sb *bytes.Buffer, expression []*RawWhereExpression) *bytes.Buffer {
	if sb == nil {
		sb = newStringBuilder()
	}
	if expression == nil {
		return sb
	}
	for _, ex := range expression {
		sb.WriteString(" " + convert.ToString(ex) + " ")
	}
	return sb
}

func (rcvr *CQL) ParseRawExpression(expression []*RawWhereExpression) string {
	return rcvr.parseRawExpression(nil, expression).String()
}

func (rcvr *CQL) ParseExpression(expression *Expression) string {
	return rcvr.parseExpression(nil, expression).String()
}

func (rcvr *CQL) ParseAllWhereExpression() string {
	if rcvr == nil {
		return ""
	}
	var whereStr string
	if rcvr.WhereClause != nil {
		whereStr = rcvr.ParseExpression(rcvr.WhereClause)
	}
	var rawWhere string
	if len(rcvr.RawWhereClause) > 0 {
		rawWhere = rcvr.ParseRawExpression(rcvr.RawWhereClause)
	}
	if len(rawWhere) > 0 {
		if len(whereStr) == 0 && strings.HasPrefix(strings.TrimLeft(rawWhere, " "), "and ") {
			whereStr = strings.Replace(rawWhere, "and ", " ", 1)
		} else {
			whereStr = whereStr + " " + rawWhere
		}
	}
	return whereStr
}

func (rcvr *CQL) parseExpression(sb *bytes.Buffer, expression *Expression) *bytes.Buffer {
	if sb == nil {
		sb = newStringBuilder()
	}
	if expression == nil {
		return sb
	}
	// leaf node
	if len(expression.Children) == 0 {
		if expression.Condition == nil {
			rcvr.err = append(rcvr.err, fmt.Errorf("condition values and children Values can't be null at same time"))
			return sb
		}

		return rcvr.parseCondition(sb, expression)
	}

	// recursive parse childs
	logic := rcvr.logic2string(expression.Logic)

	if expression.Logic == NOT {
		sb.WriteString(" (")
		sb.WriteString(logic)
	}

	if len(expression.Children) > 1 || expression.Logic != AND {
		sb.WriteString(" (")
	}

	first := true

	for _, expr := range expression.Children {
		if !first {
			sb.WriteString(" ")
			sb.WriteString(logic)
			sb.WriteString(" ")
		}
		first = false
		sb = rcvr.parseExpression(sb, expr)
	}

	if expression.Logic == NOT {
		sb.WriteString(" ))")
	} else if len(expression.Children) > 1 || expression.Logic != AND {
		sb.WriteString(" )")
	}

	return sb
}

func newStringBuilder() *bytes.Buffer {
	return &bytes.Buffer{}
}

func (kql *CQL) ParseFromClause() string {
	if kql.FromClause == nil {
		return ""
	}
	sb := newStringBuilder()
	sb.WriteString(" from ")

	temporaryTable := kql.FromClause.TemporaryTable
	if temporaryTable != nil {
		sb.WriteString("(")
		sb.WriteString(temporaryTable.Compile())
		sb.WriteString(")")
	} else {
		if kql.FromClause.Db != "" {
			sb.WriteString(kql.FromClause.Db)
			sb.WriteString(".")
		}

		sb.WriteString(kql.FromClause.Table)
	}

	if kql.FromClause.Alias != "" {
		sb.WriteString(" as ")
		sb.WriteString(kql.FromClause.Alias)
	}

	return sb.String()
}

func (kql *CQL) ParseGroupByClause() string {
	if len(kql.GroupByClause) == 0 {
		return ""
	}
	sb := newStringBuilder()
	sb.WriteString(" group by ")
	if kql.Rollup {
		sb.WriteString(" rollup (")
	} else if kql.Cube {
		sb.WriteString(" cube (")
	}
	first := true
	for _, item := range kql.GroupByClause {
		if !first {
			sb.WriteString(", ")
		}
		first = false
		kql.parsePlainColumn(sb, item)
	}
	if kql.Rollup || kql.Cube {
		sb.WriteString(")")
	}
	return sb.String()
}

func (kql *CQL) ParseHavingClause() string {
	if kql.HavingClause == nil || (len(kql.HavingClause.Children) == 0 && kql.HavingClause.Condition == nil) {
		return ""
	}
	sb := newStringBuilder()
	sb.WriteString(" having ")
	return kql.parseExpression(sb, kql.HavingClause).String()
}

func (kql *CQL) ParseJoinClause() string {
	if kql.JoinClause == nil || kql.JoinClause.Table == nil {
		return ""
	}
	sb := newStringBuilder()
	sb.WriteString(" ")
	sb.WriteString(kql.join2string(kql.JoinClause.JoinType))
	sb.WriteString(" ")
	temporaryTable := kql.JoinClause.Table.TemporaryTable
	if temporaryTable != nil {
		sb.WriteString("(")
		sb.WriteString(temporaryTable.Compile())
		sb.WriteString(")")
	} else {
		tb := kql.JoinClause.Table
		if tb.Db != "" {
			sb.WriteString(tb.Db)
			sb.WriteString(".")
		}
		sb.WriteString(tb.Table)
	}

	if kql.JoinClause.Table.Alias != "" {
		sb.WriteString(" as ")
		sb.WriteString(kql.JoinClause.Table.Alias)
	}

	var using = kql.JoinClause.Using
	var usingLen = len(using)

	if usingLen > 0 {

		sb.WriteString(" using ( ")

		for idx, column := range using {
			sb.WriteString(column.Field)
			if idx != usingLen-1 {
				sb.WriteString(",")
			}
		}

		sb.WriteString(" ) ")

	} else {
		sb.WriteString(" on ")
		kql.parsePlainColumn(sb, kql.JoinClause.Left)
		sb.WriteString(" = ")
		kql.parsePlainColumn(sb, kql.JoinClause.Right)
	}

	return sb.String()
}

func (kql *CQL) ParseLimitClause() string {
	if kql.LimitClause == nil {
		return ""
	}
	if kql.LimitClause.GetOffset() == 0 {
		return fmt.Sprintf(" limit %d", kql.LimitClause.GetSize())
	}
	return fmt.Sprintf(" limit %d, %d ", kql.LimitClause.GetOffset(), kql.LimitClause.GetSize())
}

func (kql *CQL) ParseLimitByClause() string {
	if kql.LimitByClause == nil || kql.LimitByClause.Size == 0 || len(kql.LimitByClause.SelectItems) == 0 {
		return ""
	}
	sb := newStringBuilder()
	sb.WriteString(fmt.Sprintf(" limit %d by ", kql.LimitByClause.Size))
	first := true
	for _, item := range kql.LimitByClause.SelectItems {
		if item == nil {
			continue
		}
		if !first {
			sb.WriteString(", ")
		}
		first = false
		sb.WriteString(item.Field)
	}
	return sb.String()
}

func (kql *CQL) ParseClickHouseSettings() string {
	if len(kql.ClickHouseSettings) == 0 {
		return ""
	}
	return " SETTINGS " + strings.Join(kql.ClickHouseSettings, ", ")
}

func (kql *CQL) ParseOrderClause() string {
	if len(kql.OrderByClause) == 0 {
		return ""
	}
	sb := newStringBuilder()
	sb.WriteString(" order by ")
	first := true
	for _, o := range kql.OrderByClause {
		if !first {
			sb.WriteString(", ")
		}
		first = false
		kql.parseSelectItem(sb, o.GetSelectItem())
		sb.WriteString(" ")
		sb.WriteString(kql.order2string(o.OrderType))
	}
	return sb.String()
}

func (kql *CQL) parseUnion() *bytes.Buffer {
	var sb *bytes.Buffer = newStringBuilder()
	if kql.UnionClause == nil {
		return sb
	}

	unionItem := kql.UnionClause
	first := true
	for _, child := range unionItem.Children {
		if !first {
			sb.WriteString(" union ")
			sb.WriteString(string(unionItem.UnionType))
			sb.WriteString(" ")
		}
		first = false
		sb.WriteString(child.Compile())
	}
	if kql.LimitClause != nil {
		sb.WriteString(kql.ParseLimitClause())
	}
	return sb
}

func (kql *CQL) ParseWhereClause() string {
	if kql.WhereClause == nil || (len(kql.WhereClause.Children) == 0 && kql.WhereClause.Condition == nil) {
		return ""
	}
	sb := newStringBuilder()
	return kql.parseExpression(sb, kql.WhereClause).String()
}

func (kql *CQL) parseWhereClause() string {

	if kql.WhereClause == nil || (len(kql.WhereClause.Children) == 0 && kql.WhereClause.Condition == nil) {
		return ""
	}
	sb := newStringBuilder()
	sb.WriteString(" where ")
	return kql.parseExpression(sb, kql.WhereClause).String()
}

func (kql *CQL) ParseRawWhereClause() string {
	if kql.RawWhereClause == nil || (len(kql.RawWhereClause) == 0) {
		return ""
	}
	sb := newStringBuilder()
	if kql.WhereClause == nil || (len(kql.WhereClause.Children) == 0 && kql.WhereClause.Condition == nil) {
		sb.WriteString(" where ")
	}
	return kql.parseRawExpression(sb, kql.RawWhereClause).String()
}

func (rcvr *CQL) join2string(join JoinType) string {
	switch join {
	case LEFT:
		return "left join"
	case RIGHT:
		return "right join"
	case INNER:
		return "inner join"
	// case OUTER:
	//	return "outer join"
	default:
		rcvr.err = append(rcvr.err, fmt.Errorf("JoinType %d not supported yet", join))
		return ""
	}
}

// ParseWithClause 解析 With 子句
func (kql *CQL) ParseWithClause() string {
	var sb *bytes.Buffer = newStringBuilder()
	if len(kql.WithClause) == 0 {
		return ""
	}
	sb.WriteString("with ")
	var first = true
	for _, item := range kql.WithClause {
		if !first {
			sb.WriteString(", ")
		}
		first = false
		sb = kql.parseWithItem(sb, item)
	}
	return sb.String()
}

// parseSelectClause 解析 Select 子句
func (kql *CQL) parseSelectClause() string {
	var sb *bytes.Buffer = newStringBuilder()
	if kql.SelectClause == nil {
		return ""
	}
	sb.WriteString("select ")
	var first = true
	for _, item := range kql.SelectClause {
		if !first {
			sb.WriteString(", ")
		}
		first = false
		sb = kql.parseSelectItem(sb, item)
	}
	return sb.String()
}

// ParseSelectClause 解析 Select 子句
func (kql *CQL) ParseSelectClause() string {
	var sb *bytes.Buffer = newStringBuilder()
	if kql.SelectClause == nil {
		return ""
	}
	var first = true
	for _, item := range kql.SelectClause {
		if !first {
			sb.WriteString(", ")
		}
		first = false
		sb = kql.parseSelectItem(sb, item)
	}
	return sb.String()
}

func (rcvr *CQL) parseSelectItem(sb *bytes.Buffer, item *Column) *bytes.Buffer {
	if item == nil {
		return sb
	}

	sb = rcvr.recursiveParseColumn(sb, item)

	if item.Alias == "" {
		return sb
	}

	sb.WriteString(" as ")
	sb.WriteString(item.Alias)
	return sb
}

func (rcvr *CQL) parseWithItem(sb *bytes.Buffer, item *WithItem) *bytes.Buffer {
	if item == nil {
		return sb
	}

	sb.WriteString("( ")
	sb.WriteString(item.SubQuery)
	sb.WriteString(" )")
	sb.WriteString(" as ")
	sb.WriteString(item.SubQueryName)
	sb.WriteString(" ")
	return sb
}

// parseAggregateColumn 解析聚合列
func (rcvr *CQL) parseAggregateColumn(sb *bytes.Buffer, item *Column) *bytes.Buffer {
	if item == nil {
		return sb
	}
	if item.ColumnType != AggregateColumnType {
		return sb
	}

	aggregateMethod := item.AggregateMethod
	if aggregateMethod == "" {
		return sb
	}

	sb.WriteString(agg2string(aggregateMethod))
	sb.WriteString("(")
	// 下降解析 BaseColumn
	sb = rcvr.recursiveParseColumn(sb, item.BaseColumn)
	sb.WriteString(")")
	// 如果是count(distinct ... ),需要补上最后的的括号
	if aggregateMethod == COUNT_DISTINCT {
		sb.WriteString(")")
	}

	return sb
}

// parseAlgebraicColumn 解析代数表达式，比如(sum(a) + count(b)) / (count(c) + count(d))
func (rcvr *CQL) parseAlgebraicColumn(sb *bytes.Buffer, item *Column) *bytes.Buffer {
	if item == nil {
		return sb
	}
	if item.ColumnType != AlgebraicColumnType {
		return sb
	}

	// 叶子节点
	if len(item.Children) == 0 {
		return rcvr.parseSelectItem(sb, item.BaseColumn)
	}

	// 非叶子节点
	sb.WriteString(" (")
	first := true
	for i, _ := range item.Children {
		if !first {
			sb.WriteString(" ")
			sb.WriteString(string(item.OperatorEnum))
			sb.WriteString(" ")
		}
		first = false
		rcvr.parseSelectItem(sb, &item.Children[i])
	}
	sb.WriteString(")")
	return sb
}

func (rcvr *CQL) parseIfSelectColumn(sb *bytes.Buffer, item *Column) *bytes.Buffer {
	if item == nil {
		return sb
	}
	if item.ColumnType != IfColumnType {
		return sb
	}

	sb.WriteString(" if(")
	rcvr.parseExpression(sb, item.IfExpression)
	sb.WriteString(", ")
	rcvr.parseSelectItem(sb, item.TrueItem)
	sb.WriteString(", ")
	rcvr.parseSelectItem(sb, item.FalseItem)
	sb.WriteString(")")
	return sb
}

func (rcvr *CQL) parsePlainColumn(bb *bytes.Buffer, column *Column) *bytes.Buffer {
	if column.Table != "" {
		bb.WriteString(column.Table)
		bb.WriteString(".")
	}
	bb.WriteString(column.Field)
	return bb
}

func (rcvr *CQL) parseConstantColumn(sb *bytes.Buffer, item *Column) *bytes.Buffer {
	if item == nil {
		return sb
	}
	if item.ColumnType != ConstantColumnType {
		return sb
	}
	sb.WriteString(fmt.Sprintf(" %s", item.ConstantValue))
	return sb
}

func (rcvr *CQL) recursiveParseColumn(sb *bytes.Buffer, item *Column) *bytes.Buffer {
	if item == nil {
		return sb
	}

	if item.ColumnType == PlainColumnType {
		return rcvr.parsePlainColumn(sb, item)
	}

	if item.ColumnType == AlgebraicColumnType {
		return rcvr.parseAlgebraicColumn(sb, item)
	}

	if item.ColumnType == AggregateColumnType {
		return rcvr.parseAggregateColumn(sb, item)
	}

	if item.ColumnType == IfColumnType {
		return rcvr.parseIfSelectColumn(sb, item)
	}

	if item.ColumnType == PlainColumnType {
		return rcvr.parsePlainColumn(sb, item)
	}

	if item.ColumnType == ConstantColumnType {
		return rcvr.parseConstantColumn(sb, item)
	}
	rcvr.err = append(rcvr.err, errors.New("ColumnType Not implemented yet!"))
	return sb
}

func FormatDBSearchStrWithoutQuotes(data string) string {
	buf := bytes.NewBuffer(nil)
	for _, c := range data {
		switch c {
		case 0x00:
			buf.WriteByte('\\')
			buf.WriteByte('0')
		// case '\'':
		//	buf.WriteByte('\\')
		//	buf.WriteByte('\'')
		case '"':
			buf.WriteByte('\\')
			buf.WriteByte('"')
		case 0x08:
			buf.WriteByte('\\')
			buf.WriteByte('b')
		case 0x0A:
			buf.WriteByte('\\')
			buf.WriteByte('n')
		case 0x0D:
			buf.WriteByte('\\')
			buf.WriteByte('r')
		case 0x09:
			buf.WriteByte('\\')
			buf.WriteByte('t')
		case 0x1A:
			buf.WriteByte('\\')
			buf.WriteByte('Z')
		case '\\':
			buf.WriteByte('\\')
			buf.WriteByte('\\')
		// case '%':
		//	buf.WriteByte('\\')
		//	buf.WriteByte('%')
		// case '_':
		//	buf.WriteByte('\\')
		//	buf.WriteByte('_')
		default:
			buf.WriteRune(c)
		}
	}
	return buf.String()
}
