package sql_parse

import (
	"context"
	"fmt"
	"testing"
)

var ctx = context.Background()

func TestWithClause(t *testing.T) {
	cql := NewCQL().Select("abc").From("table").
		AddWhere("name", FUZZY_LIKE, "lihua").
		AddWithClause("selec abc from dfdfd", "subQuery1").
		AddWithClause("selec abc from dfdfd", "subQuery2")

	println(cql.Compile())
}

func TestHavingLimitBy(t *testing.T) {
	cql := NewCQL().Select("abc").From("table").
		AddWhere("name", FUZZY_LIKE, "lihua").
		GroupBy("abc").
		AddHavingValueWithOperator("123", GREATER_THAN, LONG, "abc").
		LimitBy(50, "abc", "cde")
	println(cql.Compile())
}

func TestAddWhereValueWithOperatorV2(t *testing.T) {
	cql := NewCQL().Select("abc").From("table").
		AddWhere("name", FUZZY_LIKE, "lihua").
		AddWhere("age", EQUAL, 18).
		AddWhere("id", IN, []int64{1, 2, 3}).
		AddWhere("number", NOT_IN, []string{"a", "b", "c"})
	println(cql.Compile())
}

func TestRawCond(t *testing.T) {
	var a []string
	cql := NewCQL().Select("abc").From("table").
		AddWhere("cid", EQUAL, 10086).
		addWhereArrayValue("aa", IN, a).
		AddWhereRawCond("org in (?) and hasAny(name, ?) and product_id in (?) and author_id in (?) ",
			[]string{"1", "2"}, "测试", nil, 5).
		AddWhereRawCond("fuzzy_like(name, ?)", "女装")
	println(cql.Compile())
}
func TestBuild(t *testing.T) {
	cql := NewCQL().Select(Build("uniq([?])", []string{"a", "b"})).From("table").
		AddWhere("cid", EQUAL, 10086).
		AddWhereRawCond("org in (?) and hasAny(name, ?) and product_id in (?) and author_id in (?) ",
			[]string{"1", "2"}, "测试", []int64{3, 4}, 5).
		AddWhereRawCond("fuzzy_like(name, ?)", "女装")
	println(cql.Compile())
}

func TestAddWhereValueWithOperatorV2Err(t *testing.T) {
	cql := NewCQL().Select("abc").From("table").
		AddWhere("name", EQUAL, []int64{1})
	println(cql.Compile())
	_, err := cql.CompileE(ctx)
	println(err.Error())
}

func TestCQLCompilerSymbol(t *testing.T) {
	b := "sefefwf\"dsf'wefewf"
	fmt.Println(b)
}

func TestCQLCompilerSimple(t *testing.T) {
	C := NewCQL()
	sql := C.Select("c1", "c2").From("table1").Where(NewExpressionWithChild(AND, []*Expression{
		{
			Condition: &Condition{
				Column: &Column{
					Field: "a",
				},
				Operator: GREATER_THAN,
				Values: []*FieldValue{
					{Value: "1", ValueType: LONG},
				},
			},
		},
		{
			Condition: &Condition{
				Column: &Column{
					Field: "b",
				},
				Operator: LEFT_LIKE,
				Values: []*FieldValue{
					{Value: "B", ValueType: STRING},
				},
			},
		},
		{
			Condition: &Condition{
				Column: &Column{
					Field: "b",
				},
				Operator: LEFT_LIKE,
				Values: []*FieldValue{
					{Value: "B", ValueType: STRING},
				},
			},
		},
	})).addWhereArrayValue("a", IN, nil).Compile()

	fmt.Println(sql)

	want := "select c1, c2 from table1 where  ( a > 1 and  b  like '%B'  )"
	if sql != want {
		t.Errorf("CQL Compile failed, want:%s, actual:%s", want, sql)
	}
}

func TestCQLCompilerFuzzyLike(t *testing.T) {
	C := NewCQL()
	sql := C.Select("c1", "c2").From("table1").Where(NewExpressionWithChild(AND, []*Expression{
		{
			Condition: &Condition{
				Column: &Column{
					Field: "a",
				},
				Operator: GREATER_THAN,
				Values: []*FieldValue{
					{Value: "1", ValueType: LONG},
				},
			},
		},
		{
			Condition: &Condition{
				Column: &Column{
					Field: "b",
				},
				Operator: FUZZY_LIKE,
				Values: []*FieldValue{
					{Value: "B", ValueType: STRING},
				},
			},
		},
	})).Compile()

	fmt.Println(sql)

	want := "select c1, c2 from table1 where  ( a > 1 and  fuzzy_like(b, 'B')  )"
	if sql != want {
		t.Errorf("CQL Compile failed, want:%s, actual:%s", want, sql)
	}
}

func TestCQLCompiler(t *testing.T) {
	ifExpression := NewExpressionWithCondition(&Condition{
		Column: &Column{
			Field: "age",
		},
		Operator: GREATER_THAN,
		Values: []*FieldValue{
			{Value: "18", ValueType: LONG},
		},
	})

	trueColumnItem := &Column{
		Field: "uid",
	}

	falseColumnItem := &Column{
		ColumnType:    ConstantColumnType,
		ConstantValue: "null",
	}

	countDistinctIf := &Column{
		ColumnType:      AggregateColumnType,
		AggregateMethod: COUNT_DISTINCT,
		BaseColumn: &Column{
			ColumnType:   IfColumnType,
			IfExpression: ifExpression,
			TrueItem:     trueColumnItem,
			FalseItem:    falseColumnItem,
		},
	}

	sumGmv := &Column{
		ColumnType:      AggregateColumnType,
		AggregateMethod: SUM,
		BaseColumn: &Column{
			Field: "gmv",
		},
	}

	countUid := &Column{
		ColumnType:      AggregateColumnType,
		AggregateMethod: COUNT_DISTINCT,
		BaseColumn: &Column{
			Field: "user_id",
		},
	}

	item := &Column{
		ColumnType: AlgebraicColumnType,
		Alias:      "avgGmv",
	}

	avgGmv := item.Concat(DIVISION, *sumGmv, *countUid)

	kql := NewCQL()
	kql = kql.SelectAppendColumn(
		countDistinctIf,
		&Column{
			Field: "f1",
			Alias: "F1",
		},
		sumGmv, countUid, avgGmv,
	).FromWithTable(&Table{
		Db:    "db1",
		Table: "table1",
	}).Where(NewExpressionWithChild(AND, []*Expression{
		{
			Condition: &Condition{
				Column: &Column{
					Field: "a",
				},
				Operator: GREATER_THAN,
				Values: []*FieldValue{
					{Value: "1", ValueType: LONG},
				},
			},
		},
		{
			Condition: &Condition{
				Column: &Column{
					Field: "b",
				},
				Operator: EQUAL,
				Values: []*FieldValue{
					{Value: "B", ValueType: STRING},
				},
			},
		},
	}))

	sql := kql.Compile()
	fmt.Println(sql)

	want := "select count(distinct ( if( age > 18, uid,  null))), f1 as F1, sum(gmv), count(distinct (user_id)),  (sum(gmv) / count(distinct (user_id))) as avgGmv from db1.table1 where  ( a > 1 and  b = 'B' )"
	if sql != want {
		t.Errorf("CQL Compile failed, want:%s, actual:%s", want, sql)
	}
}

func TestCQLCompilerHasAny(t *testing.T) {
	C := NewCQL()
	sql := C.Select("c1", "c2").From("table1").Where(NewExpressionWithChild(AND, []*Expression{
		{
			Condition: &Condition{
				Column: &Column{
					Field: "a",
				},
				Operator: GREATER_THAN,
				Values: []*FieldValue{
					{Value: "1", ValueType: LONG},
				},
			},
		},
		{
			Condition: &Condition{
				Column: &Column{
					Field: "b",
				},
				Operator: HAS_ANY,
				Values: []*FieldValue{
					{Value: "c", ValueType: STRING},
					{Value: "d", ValueType: STRING},
				},
			},
		},
	})).Compile()

	fmt.Println(sql)

	want := "select c1, c2 from table1 where  ( a > 1 and  hasAny(b, ['c','d']) = 1  )"
	if sql != want {
		t.Errorf("CQL Compile failed, want:%s, actual:%s", want, sql)
	}
}

func TestCQLCompilerHasAnyNot(t *testing.T) {
	C := NewCQL()
	sql := C.Select("c1", "c2").From("table1").Where(NewExpressionWithChild(AND, []*Expression{
		{
			Condition: &Condition{
				Column: &Column{
					Field: "a",
				},
				Operator: GREATER_THAN,
				Values: []*FieldValue{
					{Value: "1", ValueType: LONG},
				},
			},
		},
		{
			Condition: &Condition{
				Column: &Column{
					Field: "b",
				},
				Operator: HAS_ANY_NOT,
				Values: []*FieldValue{
					{Value: "c", ValueType: STRING},
					{Value: "d", ValueType: STRING},
				},
			},
		},
	})).Compile()

	fmt.Println(sql)

	want := "select c1, c2 from table1 where  ( a > 1 and  hasAny(b, ['c','d']) = 0  )"
	if sql != want {
		t.Errorf("CQL Compile failed, want:%s, actual:%s", want, sql)
	}
}
