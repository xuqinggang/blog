package sql_parse

import (
	"code.byted.org/gopkg/lang/sets"
	"code.byted.org/temai/go_lib/convert"
	"errors"
)

type FieldCombine struct {
	Field     string
	Operator  ArithmeticOperatorEnum
	ValueType ValueType
	Values    []string
}

func GetAndExpression() *Expression {
	return &Expression{
		Logic:    AND,
		Children: make([]*Expression, 0),
	}
}

func (e *Expression) AddExpressionWithOperator(keyWord string, operator ArithmeticOperatorEnum, valueType ValueType, fields ...string) *Expression {
	if len(e.Children) == 0 {
		e.Children = make([]*Expression, 0)
	}

	e.Children = append(e.Children, GetExpressionWithOperator(keyWord, operator, valueType, fields...))
	return e
}

func (e *Expression) AddExpressionWithIn(values []string, valueType ValueType, fields ...string) *Expression {
	if len(e.Children) == 0 {
		e.Children = make([]*Expression, 0)
	}

	e.Children = append(e.Children, GetExpressionWithIn(values, valueType, fields...))
	return e
}

func (e *Expression) AddExpressionWithBetween(values []string, valueType ValueType, fields ...string) *Expression {
	if len(e.Children) == 0 {
		e.Children = make([]*Expression, 0)
	}

	e.Children = append(e.Children, GetExpressionWithBetween(values, valueType, fields...))
	return e
}

func GetExpressionWithIn(values []string, valueType ValueType, fields ...string) *Expression {
	subExpr := make([]*Expression, 0)
	fieldValues := make([]*FieldValue, 0)
	for _, v := range values {
		fieldValues = append(fieldValues, &FieldValue{
			ValueType: valueType,
			Value:     v,
		})
	}

	for _, field := range fields {
		subExpr = append(subExpr, &Expression{
			Condition: &Condition{
				Column: &Column{
					Field: field,
				},
				Operator: IN,
				Values:   fieldValues,
			},
		})
	}

	if len(subExpr) == 1 {
		return subExpr[0]
	}

	return &Expression{
		Logic:    OR,
		Children: subExpr,
	}
}

func GetExpressionWithBetween(values []string, valueType ValueType, fields ...string) *Expression {
	subExpr := make([]*Expression, 0)
	fieldValues := make([]*FieldValue, 0)
	for _, v := range values {
		fieldValues = append(fieldValues, &FieldValue{
			ValueType: valueType,
			Value:     v,
		})
	}

	for _, field := range fields {
		subExpr = append(subExpr, &Expression{
			Condition: &Condition{
				Column: &Column{
					Field: field,
				},
				Operator: BETWEEN,
				Values:   fieldValues,
			},
		})
	}

	if len(subExpr) == 1 {
		return subExpr[0]
	}

	return &Expression{
		Logic:    OR,
		Children: subExpr,
	}
}

func GetExpressionWithOperator(keyWord string, operator ArithmeticOperatorEnum, valueType ValueType, fields ...string) *Expression {
	subExpr := make([]*Expression, 0)
	for _, field := range fields {
		subExpr = append(subExpr, &Expression{
			Condition: &Condition{
				Column: &Column{
					Field: field,
				},
				Operator: operator,
				Values: []*FieldValue{
					{
						ValueType: valueType,
						Value:     keyWord,
					},
				},
			},
		})
	}

	if len(subExpr) == 1 {
		return subExpr[0]
	}

	return &Expression{
		Logic:    OR,
		Children: subExpr,
	}
}

func GetExpressionWithOperatorV2(values []string, operator ArithmeticOperatorEnum, valueType ValueType, fields ...string) *Expression {
	subExpr := make([]*Expression, 0)
	fieldValues := make([]*FieldValue, 0)
	for _, v := range values {
		fieldValues = append(fieldValues, &FieldValue{
			ValueType: valueType,
			Value:     v,
		})
	}

	for _, field := range fields {
		subExpr = append(subExpr, &Expression{
			Condition: &Condition{
				Column: &Column{
					Field: field,
				},
				Operator: operator,
				Values:   fieldValues,
			},
		})
	}

	if len(subExpr) == 1 {
		return subExpr[0]
	}

	return &Expression{
		Logic:    OR,
		Children: subExpr,
	}
}

// GetExpressionWithMultiFieldCombine (item1=1 and item2 = 2) or (item1 = 3 and item2 = 4)
func GetExpressionWithMultiFieldCombine(fieldCombines ...*FieldCombine) (*Expression, error) {
	err := checkMultiSliceCombine(fieldCombines)
	if err != nil {
		return nil, err
	}

	subExpr := make([]*Expression, 0)
	rowLen := len(fieldCombines[0].Values)
	fieldLen := len(fieldCombines)
	for rowIndex := 0; rowIndex < rowLen; rowIndex++ {
		rowAndExpr := &Expression{
			Logic: AND,
		}
		rowAndExprChildren := make([]*Expression, 0)
		for fieldIndex := 0; fieldIndex < fieldLen; fieldIndex++ {
			rowAndExprChildren = append(rowAndExprChildren, &Expression{
				Condition: &Condition{
					Column: &Column{
						Field: fieldCombines[fieldIndex].Field,
					},
					Operator: fieldCombines[fieldIndex].Operator,
					Values: []*FieldValue{
						{
							ValueType: fieldCombines[fieldIndex].ValueType,
							Value:     fieldCombines[fieldIndex].Values[rowIndex],
						},
					},
				},
			})
		}
		rowAndExpr.Children = rowAndExprChildren
		subExpr = append(subExpr, rowAndExpr)
	}

	return &Expression{
		Logic:    OR,
		Children: subExpr,
	}, nil
}

// checkMultiSliceCombine 长度一致性校验以及非空校验
func checkMultiSliceCombine(combines []*FieldCombine) error {
	if len(combines) == 0 {
		return errors.New("len(combines) can not be 0")
	}

	for _, combine := range combines {
		if combine == nil {
			return errors.New("combine can not be nil")
		}
	}

	valueLen := -1
	for _, combine := range combines {
		if combine.Values == nil {
			return errors.New("combine.Values can not be nil")
		}

		curLen := len(combine.Values)
		if valueLen == -1 {
			valueLen = curLen
		} else if valueLen != curLen {
			return errors.New("len(combine.Values) is not consistent")
		}
	}
	return nil
}

func getValueType(in interface{}) ValueType {
	valueType := STRING
	i := convert.Indirect(in)
	switch i.(type) {
	case int, int8, int16, int32, int64:
		valueType = LONG
	case float32, float64:
		valueType = DOUBLE
	}
	return valueType
}

// RemoveRowKeyWhere 精准拼接rowKeyExps时，移除cql中重复的筛选条件
func RemoveRowKeyWhere(cql *CQL, rowKeyList []string) {
	if cql != nil && cql.WhereClause != nil {
		rowKeySet := sets.NewStringSetFromSlice(rowKeyList)
		children := make([]*Expression, 0)
		for _, expr := range cql.WhereClause.Children {
			if expr != nil && expr.Condition != nil && expr.Condition.Column != nil {
				if rowKeySet.Contains(expr.Condition.Column.Field) {
					continue
				}
			}
			children = append(children, expr)
		}
		cql.WhereClause.Children = children
	}
}
