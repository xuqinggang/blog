package sql_parse

import (
	"fmt"
	"testing"
)

func TestGetExpressionWithMultiFieldCombine(t *testing.T) {
	field1 := &FieldCombine{
		Field:     "name",
		Operator:  LIKE,
		ValueType: STRING,
		Values:    []string{"杭州", "北京", "沈阳"},
	}

	field2 := &FieldCombine{
		Field:     "type",
		Operator:  EQUAL,
		ValueType: LONG,
		Values:    []string{"123", "456", "789"},
	}

	expression, _ := GetExpressionWithMultiFieldCombine(field1, field2)
	cql := NewCQL()
	sql := cql.
		Select("item1", "item2").
		From("table1").
		AddWhereValueWithOperator("浙江省", EQUAL, STRING, "province").
		AddWhereAndValue(expression).Compile()
	fmt.Println(sql)

	want := "select item1, item2 from table1 where  ( province = '浙江省' and  ( ( name like '%杭州%'  and  type = 123 ) or  ( name like '%北京%'  and  type = 456 ) or  ( name like '%沈阳%'  and  type = 789 ) ) )"
	if sql != want {
		t.Errorf("CQL Compile failed, want:%s, actual:%s", want, sql)
	}

	_, err := GetExpressionWithMultiFieldCombine(&FieldCombine{
		Field:     "name",
		Operator:  EQUAL,
		ValueType: LONG,
		Values:    nil,
	})
	fmt.Printf("err :%v\n", err)
	if err == nil {
		t.Errorf("should throw error")
	}

	_, err = GetExpressionWithMultiFieldCombine(&FieldCombine{
		Field:     "name",
		Operator:  EQUAL,
		ValueType: LONG,
		Values:    []string{"123"},
	}, &FieldCombine{
		Field:     "type",
		Operator:  EQUAL,
		ValueType: STRING,
		Values:    []string{"杭州", "北京"},
	})
	fmt.Printf("err : %v\n", err)
	if err == nil {
		t.Errorf("should throw error")
	}

}
