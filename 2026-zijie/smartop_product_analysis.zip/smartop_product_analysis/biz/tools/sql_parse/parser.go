package sql_parse

import (
	"bytes"
	"database/sql/driver"
	"fmt"
	"gorm.io/gorm/utils"
	"reflect"
	"strconv"
	"strings"
	"time"
	"unicode"
)

const (
	tmFmtWithMS = "2006-01-02 15:04:05.999"
	tmFmtZero   = "0000-00-00 00:00:00"
	nullStr     = "NULL"
)

func Build(sql string, value ...interface{}) string {
	return build(bytes.NewBuffer(nil), sql, value...)
}

func isPrintable(s []byte) bool {
	for _, r := range s {
		if !unicode.IsPrint(rune(r)) {
			return false
		}
	}
	return true
}

var convertibleTypes = []reflect.Type{reflect.TypeOf(time.Time{}), reflect.TypeOf(false), reflect.TypeOf([]byte{})}

func build(builder *bytes.Buffer, sql string, vars ...interface{}) string {
	idx := 0
	for _, v := range []byte(sql) {
		if v == '?' && idx < len(vars) {
			if _, ok := vars[idx].(driver.Valuer); ok {
				builder.WriteString(parserValue(vars[idx]))
			} else {
				switch rv := reflect.ValueOf(vars[idx]); rv.Kind() {
				case reflect.Slice, reflect.Array:
					if rv.Len() == 0 {
						builder.WriteString(parserValue(nil))
					} else {
						for i := 0; i < rv.Len(); i++ {
							if i > 0 {
								builder.WriteByte(',')
							}
							builder.WriteString(parserValue(rv.Index(i).Interface()))
						}
					}
				default:
					builder.WriteString(parserValue(vars[idx]))
				}
			}
			idx++
			continue
		}
		builder.WriteByte(v)
	}
	return builder.String()
}
func parserValue(v interface{}) string {
	escaper := "'"
	switch v := v.(type) {
	case bool:
		return strconv.FormatBool(v)
	case time.Time:
		if v.IsZero() {
			return escaper + tmFmtZero + escaper
		}
		return escaper + v.Format(tmFmtWithMS) + escaper

	case *time.Time:
		if v != nil {
			if v.IsZero() {
				return escaper + tmFmtZero + escaper
			}
			return escaper + v.Format(tmFmtWithMS) + escaper

		}
		return nullStr
	case driver.Valuer:
		reflectValue := reflect.ValueOf(v)
		if v != nil && reflectValue.IsValid() && ((reflectValue.Kind() == reflect.Ptr && !reflectValue.IsNil()) || reflectValue.Kind() != reflect.Ptr) {
			r, _ := v.Value()
			return parserValue(r)
		}
		return nullStr
	case fmt.Stringer:
		reflectValue := reflect.ValueOf(v)
		if v != nil && reflectValue.IsValid() && ((reflectValue.Kind() == reflect.Ptr && !reflectValue.IsNil()) || reflectValue.Kind() != reflect.Ptr) {
			return escaper + strings.Replace(fmt.Sprintf("%v", v), escaper, "\\"+escaper, -1) + escaper
		}
		return nullStr
	case []byte:
		if isPrintable(v) {
			return escaper + strings.Replace(string(v), escaper, "\\"+escaper, -1) + escaper
		}
		return escaper + "<binary>" + escaper
	case int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64:
		return utils.ToString(v)
	case float64, float32:
		return fmt.Sprintf("%.6f", v)
	case string:
		return escaper + strings.Replace(v, escaper, "\\"+escaper, -1) + escaper
	default:
		rv := reflect.ValueOf(v)
		if v == nil || !rv.IsValid() || rv.Kind() == reflect.Ptr && rv.IsNil() {
			return nullStr
		}
		if valuer, ok := v.(driver.Valuer); ok {
			v, _ = valuer.Value()
			return parserValue(v)
		}
		if rv.Kind() == reflect.Ptr && !rv.IsZero() {
			return parserValue(reflect.Indirect(rv).Interface())
		}

		for _, t := range convertibleTypes {
			if rv.Type().ConvertibleTo(t) {
				return parserValue(rv.Convert(t).Interface())
			}
		}
		return escaper + strings.Replace(fmt.Sprint(v), escaper, "\\"+escaper, -1) + escaper
	}
}
