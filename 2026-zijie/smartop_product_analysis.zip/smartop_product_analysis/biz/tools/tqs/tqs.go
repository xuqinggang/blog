package tqs

import (
	"context"
	"fmt"
	"time"

	"code.byted.org/dp/gotqs"
	"code.byted.org/dp/gotqs/client"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc"
	"code.byted.org/gopkg/logs"
	"code.byted.org/inf/infsecc"
	"github.com/bytedance/sonic"
)

// 公共变量
var (
	timeout   = 2 * time.Hour   // 查询超时时间，只对同步任务有用，对异步任务无效
	cluster   = "default"       // 国际化cluster为 maliva
	tqsClient *client.TqsClient // tqs客户端
)

const (
	TqsInitSettingsKey = "tqs_init_settings" // tqs初始化配置tcc key
)

type TqsInitSettings struct {
	AppId    string `json:"app_id"`
	AppKey   string `json:"app_key"`
	UserName string `json:"user_name"`
}

type TqsQueryResult struct {
	Result [][]string `json:"result"`
	Url    string     `json:"url"`
	UrlGBK string     `json:"url_gbk"`
}

// 获取tqs初始化配置
func GetTqsInitSetting(ctx context.Context) (*TqsInitSettings, error) {
	key := TqsInitSettingsKey
	value, err := tcc.GetTccConf(ctx, key)
	if err != nil {
		logs.CtxError(ctx, "[TQS] get tcc conf failed, key:%s, err:%v", key, err)
		return nil, err
	}

	settings := &TqsInitSettings{}
	err = sonic.UnmarshalString(value, settings)
	if err != nil {
		logs.CtxError(ctx, "[TQS] unmarshal string failed, key:%s, err:%v", key, err)
		return nil, err
	}

	return settings, nil
}

// 初始化tqs客户端
func Init() {
	var err error
	ctx := context.Background()
	settings, err := GetTqsInitSetting(ctx)
	if err != nil || settings == nil {
		logs.CtxError(ctx, "[TQS] get tqs init setting failed, err:%v", err)
		return
	}

	tqsClient, err = gotqs.MakeTqsClient(ctx, settings.AppId, settings.AppKey, settings.UserName, timeout, cluster)
	if err != nil {
		panic(err)
	}

	logs.Info("[TQS] init tqs client success")
}

// 同步查询
func QuerySync(ctx context.Context, sql string, withToken bool) (*TqsQueryResult, error) {
	// 生成token
	token, err := infsecc.GetToken(true)
	if err != nil {
		logs.CtxError(ctx, "[TQS] get token error: %s", err.Error())
		return nil, err
	}

	result := &TqsQueryResult{}

	logs.CtxInfo(ctx, "[TQS] query sql: %s, userName: %s", sql, tqsClient.ClientConf.UserName)

	conf := map[string]interface{}{
		"mapreduce.job.queuename": "root.panda_hl_ecom_sophon_consumer", // 队列名称
		"yarn.cluster.name":       "panda-hl",                           // 集群名称
	}
	if withToken {
		conf["tqs.inf.sec.token"] = token // PSM鉴权
	}
	// 执行查询
	status, jobPreview, err := gotqs.SyncQuery(ctx, tqsClient, sql, conf)

	if err != nil {
		logs.CtxError(ctx, "[TQS] query sync error: %s", err.Error())
		return result, err
	}

	if status != "Completed" {
		logs.CtxError(ctx, "[TQS] query status is not completed, status: %s", status)
		return result, fmt.Errorf("query status is not completed")
	}

	// FetchQueryResultsByUrl 可获取全部数据
	fullResult, fullResultErr := tqsClient.FetchQueryResultsByUrl(ctx, jobPreview.Url)
	if fullResultErr != nil {
		logs.CtxError(ctx, "[TQS] fetch query results by url error: %s", fullResultErr.Error())
		return result, fullResultErr
	}

	result.Result = fullResult
	result.Url = jobPreview.Url
	result.UrlGBK = jobPreview.UrlGBK
	return result, nil
}

// 异步查询
func QueryAsync(ctx context.Context, sql string, withToken bool) (*TqsQueryResult, error) {
	// 生成token
	token, err := infsecc.GetToken(true)
	if err != nil {
		logs.CtxError(ctx, "[TQS] get token error: %s", err.Error())
		return nil, err
	}

	result := &TqsQueryResult{}

	conf := map[string]interface{}{
		"mapreduce.job.queuename": "root.panda_hl_ecom_sophon_consumer", // 队列名称
		"yarn.cluster.name":       "panda-hl",                           // 集群名称
	}
	if withToken {
		conf["tqs.inf.sec.token"] = token // PSM鉴权
	}
	// 执行异步查询，获取jobId
	jobId, err := gotqs.AsyncQuery(ctx, tqsClient, sql, conf)

	if err != nil {
		logs.CtxError(ctx, "[TQS] query async error: %s", err.Error())
		return result, err
	}

	if jobId == 0 {
		logs.CtxError(ctx, "[TQS] job id is empty")
		return result, fmt.Errorf("job id is empty")
	}

	// 根据jobId轮询，获取结果
	status, jobPreview, _, err := gotqs.SyncQueryWithJobId(ctx, tqsClient, jobId)
	if err != nil {
		logs.CtxError(ctx, "[TQS] query async error: %s", err.Error())
		return result, err
	}

	if status != "Completed" {
		logs.CtxError(ctx, "[TQS] query status is not completed, status: %s", status)
		return result, fmt.Errorf("query status is not completed")
	}

	// FetchQueryResultsByUrl 可获取全部数据
	fullResult, fullResultErr := tqsClient.FetchQueryResultsByUrl(ctx, jobPreview.Url)
	if fullResultErr != nil {
		logs.CtxError(ctx, "[TQS] fetch query results by url error: %s", fullResultErr.Error())
		return result, fullResultErr
	}

	result.Result = fullResult
	result.Url = jobPreview.Url
	result.UrlGBK = jobPreview.UrlGBK
	return result, nil
}
