package extension_tool

import (
	"context"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
)

var ExtensionImplBizDependMap = map[dimensions.BizType]dimensions.BizType{
	dimensions.BizType_ProdReviewBigPromotion: dimensions.BizType_ProdReviewCore,
	dimensions.BizType_ProdReviewSeckill:      dimensions.BizType_ProdReviewCore,
	dimensions.BizType_ProdReviewGovSubsidy:   dimensions.BizType_ProdReviewCore,
	dimensions.BizType_ProdReviewGuess:        dimensions.BizType_ProdReviewCore,
	dimensions.BizType_ProdReviewSearch:       dimensions.BizType_ProdReviewCore,
}

func BuildIdentity(ctx context.Context, req *common_request.CommonAnalysisRequest) string {
	if req == nil || req.BaseReq == nil {
		return ""
	}
	bizType := req.BaseReq.BizType
	if _, ok := ExtensionImplBizDependMap[req.BaseReq.BizType]; ok {
		bizType = ExtensionImplBizDependMap[req.BaseReq.BizType]
	}

	bizInfo, _, err := biz_utils.GetBizMetaInfo(ctx, bizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "BuildIdentity 业务线未发现元信息, bizType = %s", convert.ToJSONString(bizType))
		return ""
	}
	moduleName := ""
	if req.BizExtraInfo == nil {
		logs.CtxError(ctx, "BuildIdentity BizExtraInfo 为空")
		return ""
	}
	if strings.Contains(bizInfo.EffectModule, "货盘复盘") && bizType != dimensions.BizType_ProdReviewLibraMetricGroup {
		// 货盘复盘场景下，moduleName 从 ProdReviewParams 中获取
		if req.BizExtraInfo.ProdReviewParams == nil {
			return ""
		}
		moduleName = req.BizExtraInfo.ProdReviewParams.ModuleName.String()
	} else {
		// 非货盘复盘场景下，moduleName 从 BizExtraInfo 中获取
		moduleName = req.BizExtraInfo.ModuleName.String()
	}

	identity := bizType.String() + "_" + moduleName
	return identity
}

func BuildDefaultBizIdentity(req *common_request.CommonAnalysisRequest) string {
	if req == nil || req.BizExtraInfo.ProdReviewParams == nil {
		return ""
	}

	moduleName := req.BizExtraInfo.ProdReviewParams.ModuleName.String()
	identity := moduleName
	return identity
}
