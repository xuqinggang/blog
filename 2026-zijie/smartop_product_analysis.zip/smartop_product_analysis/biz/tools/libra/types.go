package libra

type FlightDetailResp struct {
	Code    int               `json:"code"`
	Data    *FlightDetailData `json:"data,omitempty"`
	Message string            `json:"message"`
}

type FlightDetailData struct {
	Flight  Flight   `json:"flight"`
	Flights []Flight `json:"flights"`
}

type Flight struct {
	ID                   int64                 `json:"id"`                     // 实验id
	InheritType          int                   `json:"inherit_type"`           // 分流类型，0:uid, 1:did, 2:rid, 3:union, 4:uuid, 5:cdid, 6:ssid, 7:webid, 8:pkid, 9:纯uid分流
	Status               int                   `json:"status"`                 // 实验状态，0:已结束, 1:进行中, 2:待调度, 3:调试中, 4:已暂停, 91同0
	Name                 string                `json:"name"`                   // 实验名称
	Description          string                `json:"description"`            // 实验描述
	StartTime            string                `json:"start_time"`             // 实验开始时间，格式为yyyy-MM-dd HH:mm:ss
	EndTime              string                `json:"end_time"`               // 实验结束时间，格式为yyyy-MM-dd HH:mm:ss
	Expectation          string                `json:"expectation"`            // 实验目标
	Versions             []Version             `json:"versions"`               // 实验分组
	AppID                int                   `json:"app_id"`                 // 实验关联的appid
	AppName              string                `json:"app_name"`               // 实验关联的app名称
	ProductID            int                   `json:"product_id"`             // 实验关联的productid
	ProductName          string                `json:"product_name"`           // 实验关联的product名称
	Product              string                `json:"product"`                // 实验关联的product
	WatchingMetricGroups []WatchingMetricGroup `json:"watching_metric_groups"` // 实验关联的监控指标分组
}

type Version struct {
	Config      string  `json:"config"`       // 实验分组配置
	Description string  `json:"description"`  // 实验分组描述
	ID          int64   `json:"id"`           // 实验分组id
	Name        string  `json:"name"`         // 实验分组名称
	Status      int     `json:"status"`       // 状态， 0:已关闭, 1:有效
	Type        int     `json:"type"`         // 实验分组类型，0:对照组, 1:实验组
	UserTag     string  `json:"user_tag"`     // 实验组用户分群名称
	Weight      int     `json:"weight"`       // 流量权重比，仅针对流量不均等实验有意义，权重比值0 ~ 1000，实验每个version的weight加起来一定等于1000
	RealTraffic float64 `json:"real_traffic"` // 实验分组实际流量占比，0 ~ 100
}

type WatchingMetricGroup struct {
	MetricGroupID   int64         `json:"metric_group_id"`   // 指标组id
	MetricGroupName string        `json:"metric_group_name"` // 指标组名称
	MetricGroupType string        `json:"metric_group_type"` // 指标组类型
	Dimensions      []interface{} `json:"dimensions"`        // 指标组维度
}

type MetricGroupDetailResp struct {
	Code    int                    `json:"code"`
	Data    *MetricGroupDetailData `json:"data,omitempty"`
	Message string                 `json:"message"`
}

type MetricGroupDetailData struct {
	ID          int64        `json:"id"`                   // 指标组id
	Name        string       `json:"name"`                 // 指标组名称
	Status      int          `json:"status"`               // 指标组状态，1表示正常，0表示下线
	Description string       `json:"description"`          // 指标组描述
	Metrics     []Metric     `json:"metrics"`              // 指标组指标列表
	Dimensions  []*Dimension `json:"dimensions,omitempty"` // 指标组维度列表
}

type Metric struct {
	ID          int64  `json:"id"`           // 指标id
	Name        string `json:"name"`         // 指标名称
	Description string `json:"description"`  // 指标描述
	Key         string `json:"key"`          // 指标key
	BenefitType int    `json:"benefit_type"` // 指标类型，0表示负向，1表示正向
}

type Dimension struct {
	ID        int64       `json:"id"`                   // 维度id
	Name      string      `json:"name"`                 // 维度名称
	Desc      string      `json:"desc"`                 // 维度描述
	DimValues []*DimValue `json:"dim_values,omitempty"` // 维度值列表
}

type DimValue struct {
	ID     int64  `json:"id"`      // 维度值id
	Name   string `json:"name"`    // 维度值名称
	Desc   string `json:"desc"`    // 维度值描述
	DimKey string `json:"dim_key"` // 维度key
	DimID  int64  `json:"dim_id"`  // 维度id
}

type DimValueListResp struct {
	Code    int         `json:"code"`
	Data    []*DimValue `json:"data,omitempty"`
	Message string      `json:"message"`
}

type FlightBaseUserResp struct {
	Message string              `json:"message"`
	Code    int                 `json:"code"`
	Data    *FlightBaseUserData `json:"data,omitempty"`
}

type FlightBaseUserData struct {
	SumBaseuser  int64      `json:"sum_baseuser"`  // 实验进组人数总和
	HashStrategy string     `json:"hash_strategy"` // 分流方式, uid/did/uuid等
	Baseuser     []Baseuser `json:"baseuser"`      // 实验进组人数列表
}

type Baseuser struct {
	Baseuser int64  `json:"baseuser"` // 进组人数
	Vname    string `json:"vname"`    // 实验分组名称
	Vid      int64  `json:"vid"`      // 实验分组id
}
