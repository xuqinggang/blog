package libra

import (
	"context"
	"encoding/json"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/gopkg/logs/v2"
	"github.com/volcengine/dataopen-sdk-go/client"
)

var (
	LibraClient *client.ClientStruct
)

func Init() {
	ctx := context.Background()
	libraConfig, err := biz_info.GetLibraConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, "[libra] Init libra client failed, err=%v", err)
		panic(err)
	}
	LibraClient = client.Client(libraConfig.AppId, libraConfig.AppSecret, libraConfig.Url, "")
}

// 获取实验详情：https://data.bytedance.net/dataopen/libra/document/2232
func GetFlightDetail(ctx context.Context, flightId int64) (*FlightDetailResp, error) {
	headers := map[string]string{
		"X-Real-Operator": "huangdonglu.jackson",
	}
	params := make(map[string]client.ParamsValueType)
	body := make(map[string]interface{})
	res, err := LibraClient.Request(fmt.Sprintf("/dataopen/open-apis/libra/openapi/v1/open/flight/%d/view/", flightId), "GET", headers, params, body)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetFlightDetail failed, err=%v", err)
		return nil, err
	}

	// 使用JSON序列化/反序列化（推荐）
	flightDetailResp := &FlightDetailResp{}
	jsonData, err := json.Marshal(res)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetFlightDetail JSON marshal failed, err=%v", err)
		return nil, err
	}
	err = json.Unmarshal(jsonData, flightDetailResp)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetFlightDetail JSON unmarshal failed, err=%v", err)
		return nil, err
	}

	return flightDetailResp, nil
}

// 查看实验进组人数：https://data.bytedance.net/dataopen/libra/document/2276
func GetFlightBaseUser(ctx context.Context, flightId int64) (*FlightBaseUserResp, error) {
	headers := map[string]string{
		"X-Real-Operator": "huangdonglu.jackson",
	}
	params := make(map[string]client.ParamsValueType)
	body := make(map[string]interface{})
	res, err := LibraClient.Request(fmt.Sprintf("/dataopen/open-apis/libra/openapi/v1/open/flight/%d/get-baseuser/", flightId), "GET", headers, params, body)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetFlightBaseUser failed, err=%v", err)
		return nil, err
	}

	flightBaseUserResp := &FlightBaseUserResp{}
	jsonData, err := json.Marshal(res)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetFlightBaseUser JSON marshal failed, err=%v", err)
		return nil, err
	}
	err = json.Unmarshal(jsonData, flightBaseUserResp)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetFlightBaseUser JSON unmarshal failed, err=%v", err)
		return nil, err
	}

	return flightBaseUserResp, nil
}

// 查询指标组详情：https://data.bytedance.net/dataopen/datatester/document/2381
func GetMetricGroupDetail(ctx context.Context, appId int64, metricGroupId int64) (*MetricGroupDetailResp, error) {
	headers := map[string]string{
		"X-Real-Operator": "huangdonglu.jackson",
	}
	params := map[string]client.ParamsValueType{
		"with_dim_values": "true",
	}
	body := make(map[string]interface{})
	res, err := LibraClient.Request(fmt.Sprintf("/dataopen/open-apis/datatester/openapi/v3/apps/%d/metric_groups/%d", appId, metricGroupId), "GET", headers, params, body)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetMetricGroupDetail failed, err=%v", err)
		return nil, err
	}

	metricGroupDetailResp := &MetricGroupDetailResp{}
	jsonData, err := json.Marshal(res)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetMetricGroupDetail JSON marshal failed, err=%v", err)
		return nil, err
	}
	err = json.Unmarshal(jsonData, metricGroupDetailResp)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetMetricGroupDetail JSON unmarshal failed, err=%v", err)
		return nil, err
	}

	return metricGroupDetailResp, nil
}

// 查询维度值列表：https://data.bytedance.net/dataopen/datatester/explorer/2382?appId=cli_4e44459327133fbd
func GetDimValueList(ctx context.Context, appId string, dimId int64) (*DimValueListResp, error) {
	headers := map[string]string{
		"X-Real-Operator": "huangdonglu.jackson",
	}
	params := map[string]client.ParamsValueType{
		"dim_id": dimId,
	}
	body := make(map[string]interface{})
	res, err := LibraClient.Request(fmt.Sprintf("/dataopen/open-apis/datatester/openapi/v3/apps/%s/metric_groups/dim-values/list", appId), "GET", headers, params, body)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetDimValueList failed, err=%v", err)
		return nil, err
	}

	dimValueListResp := &DimValueListResp{}
	jsonData, err := json.Marshal(res)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetDimValueList JSON marshal failed, err=%v", err)
		return nil, err
	}
	err = json.Unmarshal(jsonData, dimValueListResp)
	if err != nil {
		logs.CtxError(ctx, "[libra] GetDimValueList JSON unmarshal failed, err=%v", err)
		return nil, err
	}

	return dimValueListResp, nil
}
