package base_struct_condition

import (
	"fmt"
	"github.com/valyala/fasttemplate"
	"testing"
)

func TestGetDimKeyParent(t *testing.T) {
	//ctx := context.Background()
	s := fasttemplate.ExecuteString("order_xd_{{price_flag_power_tag_name}}", "{{", "}}", map[string]interface{}{
		"price_flag_power_tag_name": "price_hybrid_power_tag_name",
	})
	fmt.Printf("%s", s)
}
