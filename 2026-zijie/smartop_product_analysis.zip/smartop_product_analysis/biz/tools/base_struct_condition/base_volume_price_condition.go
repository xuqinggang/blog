package base_struct_condition

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"context"
	"fmt"
	"strings"
)

// GetVolumePriceBaseStructConditionParams 通过基础结构抽象，获取查询的sql结构体 - 包含基础、大盘、趋势图
func GetVolumePriceBaseStructConditionParams(ctx context.Context, req OsParamsReq) (curr, trend map[string]interface{}, err error) {
	curr, err = GetVolumePriceConditionSimpleParam(ctx, req, SQLCalcType_Curr)
	if err != nil {
		return
	}
	trend, err = GetVolumePriceConditionSimpleParam(ctx, req, SQLCalcType_Trend)
	return
}

func GetVolumePriceConditionSimpleParam(ctx context.Context, req OsParamsReq, calcType SQLCalcType) (param map[string]interface{}, err error) {
	param = make(map[string]interface{})
	startDate, endDate := GetDateRange(req.BaseStruct, calcType == SQLCalcType_Compare)
	param["start_date"] = startDate
	param["end_date"] = endDate
	param["compare_start_date"] = req.BaseStruct.CompareStartDate
	param["compare_end_date"] = req.BaseStruct.CompareEndDate
	param["date_range"] = time_utils.DateDiffAbs(startDate, endDate) + 1

	// 大盘不需要下面的筛选项
	if calcType == SQLCalcType_Overall {
		return
	}

	param["biz_type"] = int64(req.BaseStruct.BizType)

	// 解析所选维度过滤信息
	exprCql, _, lastVCql, err := GetBaseConditionWithDims(ctx, req.BaseStruct, calcType == SQLCalcType_Compare, req.DimMap, false, false)
	if err != nil {
		return
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}

	if lastVCql != nil {
		exprCql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, lastVCql)
	}

	whereStr := exprCql.ParseAllWhereExpression()
	if len(whereStr) > 0 {
		param["filter_param"] = whereStr
	}

	if calcType == SQLCalcType_Trend {
		req.MultiDimension = append(req.MultiDimension, "date")
	}

	if len(req.MultiDimension) > 0 {
		subSelect := make([]string, 0)
		for _, d := range req.MultiDimension {
			if dimInfo, exist := req.DimColMap[d]; exist && len(dimInfo.DimExpr) > 0 {
				subSelect = append(subSelect, fmt.Sprintf("%s as %s", dimInfo.DimExpr, d))
			} else {
				subSelect = append(subSelect, d)
			}
		}

		param["sub_select"] = strings.Join(subSelect, ",")
		param["dimension"] = strings.Join(req.MultiDimension, ",")
	}
	return
}
