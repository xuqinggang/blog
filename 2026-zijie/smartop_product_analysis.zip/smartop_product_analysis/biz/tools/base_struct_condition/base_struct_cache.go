package base_struct_condition

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	b64 "encoding/base64"
	"github.com/bytedance/sonic"
)

func GetCacheResp[T any](ctx context.Context, prefix string, req *dimensions.ProductAnalysisBaseStruct, resp T) (ret T, err error) {
	base64Str := b64.StdEncoding.EncodeToString([]byte(convert.ToJSONString(req)))
	value, err := redis.Get(ctx, prefix+base64Str)
	if err != nil {
		logs.CtxError(ctx, "Redis.Get Error, err = %v", err)
		return resp, err
	}

	if len(value) == 0 {
		return ret, err
	}

	respStr, err := b64.StdEncoding.DecodeString(value)
	if err != nil {
		logs.CtxError(ctx, "b64.StdEncoding.DecodeString Error, err = %v", err)
		return resp, err
	}
	logs.CtxError(ctx, "命中了? key=%s, v=%s", base64Str, value)
	err = sonic.UnmarshalString(string(respStr), &resp)
	if err != nil {
		logs.CtxError(ctx, "sonic.UnmarshalString Error, err = %v", err)
		return resp, err
	}
	logs.CtxError(ctx, "命中了! key=%s, resp=%s", base64Str, convert.ToJSONString(resp))
	return resp, nil
}
