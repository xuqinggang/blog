package base_struct_condition

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	tcc "code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/cluster_migration"
	"code.byted.org/gopkg/jsonx"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_ecop_matching_brain/kitex_gen/ecom/ecop/matching_brain"
	"code.byted.org/overpass/ecom_ecop_matching_brain/rpc/ecom_ecop_matching_brain"
	"code.byted.org/overpass/ecom_marketing_promotion_growth_data_platform/kitex_gen/ecom/marketing/promotion_growth_data_platform"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
	"github.com/jinzhu/copier"
	"github.com/sanity-io/litter"
	"github.com/valyala/fasttemplate"
)

const duLiDuanPoolCode = "10118"

func GenerateTemplateMap(ctx context.Context) (map[string]interface{}, error) {
	templateMap := make(map[string]interface{})
	templateMap["price_power_tag_name"] = "price_power_tag_name"
	if biz_info.GetCtxBizInfoPriceComparisonType(ctx) == dimensions.PriceComparisonType_Hybrid {
		templateMap["price_power_tag_name"] = "price_hybrid_power_tag_name"
	}

	// 订单来源场域的条件体替换
	orderChannelMap, err := biz_info.GetOrderSourceChannelMetaInfoMap(ctx, true)
	if err != nil {
		logs.CtxError(ctx, "[GenerateTemplateMap]GetOrderSourceChannelMetaInfoMap Err, %v", err)
		return templateMap, err
	}
	for k, v := range orderChannelMap {
		templateMap[fmt.Sprintf("%s_express", k)] = v.Express
	}

	// 价格力变化的条件体替换
	priceChangeTypeMap, err := biz_info.GetOutXdPriceChangeTypeMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GenerateTemplateMap]GetOutXdPriceChangeTypeMap Err, %v", err)
		return templateMap, err
	}
	for k, v := range priceChangeTypeMap {
		templateMap[fmt.Sprintf("%s_express", k)] = v
	}

	return templateMap, nil
}

// GetDimCondition 获取维度下条件结构体
func GetDimCondition(ctx context.Context, reqDims []*dimensions.SelectedDimensionInfo, dimMap map[int64]*dao.DimensionInfo, dateExpr *sql_parse.Expression) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	//.AddWhere("1", sql_parse.EQUAL, 1) // 预占条件防止有and开头的情况
	if len(reqDims) == 0 {
		return nil, errors.New("dim info empty")
	}
	for _, reqDim := range reqDims {
		dimInfo := dimMap[convert.ToInt64(reqDim.Id)]
		if dimInfo == nil {
			logs.CtxError(ctx, "[GetDimCondition]未查询到维度信息,id=%s", reqDim.Id)
			return nil, errors.New("未查询到维度信息")
		}
		if consts.Show_Type_Text_Arr_Input == dimInfo.ShowType {
			if len(reqDim.SelectedValues) == 0 || len(reqDim.SelectedValues[0].TypeValue) == 0 {
				continue
			}

			v, err := TransValue(ctx, dimInfo.EnumDataType, reqDim.SelectedValues[0].TypeValue...)
			if err != nil {
				return nil, err
			}
			if dimInfo.ID == 10661 {
				cql.AddWhereRawCond("(vid1 in (?) or vid2 in (?))", v, v)
			} else {
				cql.AddWhere(dimInfo.DimColumn, sql_parse.IN, v)
			}
			continue
		}

		dimKey := dimInfo.DimColumn
		if len(dimInfo.DimExpr) > 0 {
			dimKey = dimInfo.DimExpr
		}

		templateMap, err := GenerateTemplateMap(ctx)
		if err != nil {
			return nil, err
		}
		if strings.Contains(dimKey, "{{") {
			dimKey = fasttemplate.ExecuteString(dimKey, "{{", "}}", templateMap)
		}

		if slices.ContainsString(consts.HaveEnumCodeShowTypeList, dimInfo.ShowType) {
			if len(reqDim.SelectedValues) == 0 {
				continue
			}

			values := make([]string, 0)
			for _, reqEnum := range reqDim.SelectedValues {
				if len(reqEnum.Code) > 0 {
					if strings.Contains(reqEnum.Code, "{{") && strings.Contains(reqEnum.Code, "}}") {

						cql.AddRawWhere(" and " + fasttemplate.ExecuteString(reqEnum.Code, "{{", "}}", templateMap))
					} else {
						values = append(values, reqEnum.Code)
					}
				}
			}
			if len(values) > 0 {
				if dimInfo.ProcessType == "数组类型" || dimInfo.ID == convert.ToInt64(consts.PushAuditTag) {
					var notStr string
					if reqDim.SelectedOperator == base.OperatorType_NOT_IN {
						notStr = "not"
					}
					if dimInfo.EnumDataType == "long" {
						cql.AddRawWhere(fmt.Sprintf(" and %s hasAny(%s, [%s])", notStr, dimKey, strings.Join(values, ",")))
					} else {
						cql.AddRawWhere(fmt.Sprintf(" and %s hasAny(%s, ['%s'])", notStr, dimKey, strings.Join(values, "','")))
					}
					continue
				}
				//if dimInfo.ID == convert.ToInt64(consts.BillionActivityDim) {
				//	var notStr string
				//	if reqDim.SelectedOperator == base.OperatorType_NOT_IN {
				//		notStr = "not"
				//	}
				//	cql.AddRawWhere(fmt.Sprintf(" and %s hasAny(%s, ['%s'])", notStr, dimKey, strings.Join(values, "','")))
				//	continue
				//}
				if dimInfo.ID == convert.ToInt64(consts.IsNewPayCntDim) || dimInfo.ID == convert.ToInt64(consts.IsRecallPayCntDim) {
					newRecallCql := sql_parse.NewCQL().Select(consts.ProductID).From(biz_info.GetCtxBizInfoTableName(ctx) + " new_recall").AddWhereAndValue(dateExpr)
					if values[0] == consts.IsTrueString {
						newRecallCql.AddRawWhere(" and " + dimInfo.DimExpr)
					} else {
						newRecallCql.AddRawWhere(fmt.Sprintf(" and not (%s)", dimInfo.DimExpr))
					}
					cql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, newRecallCql)
					continue
				}

				if dimInfo.ShowType == consts.Show_Type_Bool_Single_Select {
					reqDim.SelectedOperator = base.OperatorType_IN
				}

				if sql_parse.ValueType(dimInfo.EnumDataType) == sql_parse.BOOL {
					if values[0] == consts.IsTrueString {
						cql.AddRawWhere(" and " + dimInfo.DimExpr)
					} else {
						cql.AddRawWhere(fmt.Sprintf(" and not (%s)", dimInfo.DimExpr))
					}
				} else {
					v, err := TransValue(ctx, dimInfo.EnumDataType, values...)
					if err != nil {
						return nil, err
					}
					cql.AddWhere(dimKey, TransOperator(reqDim.SelectedOperator), v)
				}
			}
		}

		if slices.ContainsString(consts.HaveEnumRangeShowTypeList, dimInfo.ShowType) {
			if len(reqDim.SelectedValues) == 0 || len(reqDim.SelectedValues[0].TypeValue) != 2 {
				logs.CtxError(ctx, "[GetDimCondition]维度枚举值错误,req=%s", convert.ToJSONString(reqDim))
				continue
			}

			startV := reqDim.SelectedValues[0].TypeValue[0]
			endV := reqDim.SelectedValues[0].TypeValue[1]
			if startV != consts.Negetive_Infinity {
				v, err := TransValue(ctx, dimInfo.EnumDataType, startV)
				if err != nil {
					return nil, err
				}
				cql.AddWhere(dimKey, sql_parse.GREATER_EQUAL_THAN, v)
			}
			if endV != consts.Positive_Infinity {
				v, err := TransValue(ctx, dimInfo.EnumDataType, endV)
				if err != nil {
					return nil, err
				}
				cql.AddWhere(dimKey, sql_parse.LESS_EQUAL_THAN, v)
			}
		}
	}

	return cql, nil
}

// GetProductLastDayValCQL 通过商品的最新一天的属性，货品商品id信息
func GetProductLastDayValCQL(ctx context.Context, reqDims []*dimensions.SelectedDimensionInfo, dimMap map[int64]*dao.DimensionInfo, date, aliasSuf string, isAlertRule bool) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	bizMetaInfo := biz_utils.GetBizMetaInfoFromContext(ctx)
	prodBaseTable := ApiProdBaseDfTableName
	if bizMetaInfo != nil && bizMetaInfo.EffectModule == "大促视图" {
		tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
		if err != nil {
			return nil, err
		}
		prodBaseTable = tableConf.ProdTableName
	}
	cql.Select("prod_id as prod_id").From(utils.AddTableNameAlias(prodBaseTable, "prod_base_df"+aliasSuf))
	exprCql, err := GetDimCondition(ctx, reqDims, dimMap, nil)
	if err != nil {
		return nil, err
	}

	if isAlertRule {
		cql.AddWhere("date", sql_parse.EQUAL, fmt.Sprintf("${%s.end_date}", prodBaseTable)).AddRawWhereAndValue(exprCql.RawWhereClause...).AddWhereAndValue(exprCql.WhereClause)
	} else {
		cql.AddWhere("date", sql_parse.EQUAL, date).AddRawWhereAndValue(exprCql.RawWhereClause...).AddWhereAndValue(exprCql.WhereClause)
	}
	return cql, err
}

// GetProductPoolCQLAgg 独立端特殊的商品池关联逻辑
func GetProductPoolCQLAgg(bizMetaInfo *biz_utils.BizMetaInfo, reqDims []*dimensions.SelectedDimensionInfo, startDate, endDate string, isAlertRule bool) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	tableName := ApiProdPoolTableNameV2
	// if newClusterBizList contain biz, then use new table
	if slices.Contains(consts.NewClusterBizTypeList, bizMetaInfo.BizType) {
		tableName = ApiProdPoolTableNameBucket
	}
	cql.Select("prod_id as prod_id").From(utils.AddTableNameAlias(tableName, "agg_pool"))
	if isAlertRule {
		cql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, fmt.Sprintf("${%s.start_date}", tableName)).AddWhere("date", sql_parse.LESS_EQUAL_THAN, fmt.Sprintf("${%s.end_date}", tableName))
	} else {
		cql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate)
	}
	cql.AddWhere("source", sql_parse.EQUAL, ProdSelectTag)
	for _, dim := range reqDims {
		var poolIDList = make([]string, 0)
		for _, enum := range dim.SelectedValues {
			poolIDList = append(poolIDList, enum.Code)
		}
		if dim.SelectedOperator == base.OperatorType_NOT_IN {
			cql.AddWhere("pool_id", sql_parse.NOT_IN, poolIDList)
		} else {
			cql.AddWhere("pool_id", sql_parse.IN, poolIDList)
		}
	}
	return cql, err
}

// GetProductPoolCQL 商品池维度筛选
func GetProductPoolCQL(bizMetaInfo *biz_utils.BizMetaInfo, reqDims []*dimensions.SelectedDimensionInfo, startDate, endDate string, isAlertRule bool) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	tableName := ApiProdPoolTableNameV2
	// if newClusterBizList contain biz, then use new table
	if slices.Contains(consts.NewClusterBizTypeList, bizMetaInfo.BizType) {
		tableName = ApiProdPoolTableNameBucket
	}
	cql.Select("prod_id as prod_id", "date as date").From(utils.AddTableNameAlias(tableName, "prod_pool_di"))
	if isAlertRule {
		cql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, fmt.Sprintf("${%s.start_date}", tableName)).AddWhere("date", sql_parse.LESS_EQUAL_THAN, fmt.Sprintf("${%s.end_date}", tableName))
	} else {
		cql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate)
	}
	cql.AddWhere("source", sql_parse.EQUAL, ProdSelectTag)
	for _, dim := range reqDims {
		var poolIDList = make([]string, 0)
		for _, enum := range dim.SelectedValues {
			poolIDList = append(poolIDList, enum.Code)
		}
		if dim.SelectedOperator == base.OperatorType_NOT_IN {
			cql.AddWhere("pool_id", sql_parse.NOT_IN, poolIDList)
		} else {
			cql.AddWhere("pool_id", sql_parse.IN, poolIDList)
		}
	}
	return cql, err
}

func GetActivityAggCQL(ctx context.Context, bizType dimensions.BizType, reqDims []*dimensions.SelectedDimensionInfo, dimMap map[int64]*dao.DimensionInfo, startDate, endDate string) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	tableName := ApiActivityTableName
	if slices.Contains(consts.NewClusterBizTypeList, bizType) {
		tableName = ApiActivityTableNameBucket
	}
	cql.Select("prod_id as prod_id", "date as date").From(utils.AddTableNameAlias(tableName, "activity_di"))
	cql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate)
	exprCql, err := GetDimCondition(ctx, reqDims, dimMap, nil)
	if err != nil {
		return nil, err
	}
	cql.AddRawWhereAndValue(exprCql.RawWhereClause...).AddWhereAndValue(exprCql.WhereClause)
	return cql, err
}

func GetActivityPoolCQL(ctx context.Context, bizType dimensions.BizType, reqDims []*dimensions.SelectedDimensionInfo, dimMap map[int64]*dao.DimensionInfo) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	newestDate, err := utils.GetNewestDay(ctx, consts.LogicTableInvestActivity)
	if err != nil {
		return nil, err
	}
	tableName := ApiActivityTableName
	if slices.Contains(consts.NewClusterBizTypeList, bizType) {
		tableName = ApiActivityTableNameBucket
	}
	cql.Select("prod_id as prod_id").From(utils.AddTableNameAlias(tableName, "activity_di"))
	// 招商活动统一看最新一天
	cql.AddWhere("date", sql_parse.EQUAL, newestDate)
	exprCql, err := GetDimCondition(ctx, reqDims, dimMap, nil)
	if err != nil {
		return nil, err
	}
	cql.AddRawWhereAndValue(exprCql.RawWhereClause...).AddWhereAndValue(exprCql.WhereClause)
	return cql, err
}

func GetProdSelectOncePoolCQL(ctx context.Context, reqDims []*dimensions.SelectedDimensionInfo) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	cql.Select("prod_id as prod_id").From(utils.AddTableNameAlias(ApiProdOncePoolTableName, "long_prod_pool_di"))
	for _, dim := range reqDims {
		var poolIDList = make([]string, 0)
		for _, enum := range dim.SelectedValues {
			poolIDList = append(poolIDList, enum.Code)
		}
		if dim.SelectedOperator == base.OperatorType_NOT_IN {
			cql.AddWhere("pool_id", sql_parse.NOT_IN, poolIDList)
		} else {
			cql.AddWhere("pool_id", sql_parse.IN, poolIDList)
		}
	}
	return cql, err
}

func GetJoinTableSQL(ctx context.Context, reqDims []*dimensions.SelectedDimensionInfo, dimMap map[int64]*dao.DimensionInfo, startDate, endDate, logicTableName string) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	cql.Select("prod_id as prod_id").From(utils.AddTableNameAlias(logicTableName, "join_table"))
	cql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate)
	exprCql, err := GetDimCondition(ctx, reqDims, dimMap, nil)
	if err != nil {
		return nil, err
	}
	cql.AddRawWhereAndValue(exprCql.RawWhereClause...).AddWhereAndValue(exprCql.WhereClause)
	return cql, err
}

func GetOncePoolCQL(ctx context.Context, bizMetaInfo *biz_utils.BizMetaInfo, reqDims []*dimensions.SelectedDimensionInfo) (cql *sql_parse.CQL, err error) {
	tx := mysql.DB(ctx).Begin()
	if tx.Error != nil {
		logs.CtxError(ctx, tx.Error.Error())
		return nil, errors.New("获取数据库的事务失败")
	}
	// 读取mysql元信息表拿到最新时间
	meta, err := dao.GetPoolMaxDt(ctx, tx, consts.PoolSourceChannel)
	if err != nil {
		logs.CtxError(ctx, "[GetOncePoolCQL]获取频道商品包RDS元信息数据失败,err:"+err.Error())
		tx.Rollback()
		return nil, err
	}
	tx.Commit()
	var dataReadyDay string
	dataReadyDay = time.Now().Format("2006-01-02")
	if len(meta) > 0 {
		dataReadyDay = meta[0].DT
	}
	tableName := ApiProdPoolTableNameV2
	// if newClusterBizList contain biz, then use new table
	if slices.Contains(consts.NewClusterBizTypeList, bizMetaInfo.BizType) {
		tableName = ApiProdPoolTableNameBucket
	}
	cql = sql_parse.NewCQL()
	cql.Select("prod_id as prod_id").From(utils.AddTableNameAlias(tableName, "prod_pool_di_once"))
	cql.AddWhere("date", sql_parse.EQUAL, dataReadyDay)
	cql.AddWhere("source", sql_parse.EQUAL, ChannelTag)
	for _, dim := range reqDims {
		var poolIDList = make([]string, 0)
		for _, enum := range dim.SelectedValues {
			poolIDList = append(poolIDList, enum.Code)
		}
		if dim.SelectedOperator == base.OperatorType_NOT_IN {
			cql.AddWhere("pool_id", sql_parse.NOT_IN, poolIDList)
		} else {
			cql.AddWhere("pool_id", sql_parse.IN, poolIDList)
		}
	}
	return cql, err
}

type BaseStructConditionReq struct {
	BaseStruct       *dimensions.ProductAnalysisBaseStruct
	IsCompare        bool
	NotSyncBaseMulti bool
	NeedProdID       bool
	CKSettingType    CKSettingType
	MultiDimColumns  []string
	SubSelectList    []string
	BaseSelectList   []string
	DimColMap        map[string]*dao.DimensionInfo
	DimMap           map[int64]*dao.DimensionInfo
	IsAlertRule      bool
}

func AppendAccGlobalInCql(ctx context.Context, selectCql, whereCql, newWhereCql, baseExprCql, lastVCql *sql_parse.CQL, startDate, endDate string, bizType dimensions.BizType) (*sql_parse.CQL, error) {
	selectCql.FromClause.TemporaryTable.From(biz_info.GetCtxBizInfoTableName(ctx) + " thr_acc")
	selectCql.FromClause.TemporaryTable.WhereClause = newWhereCql.WhereClause
	if len(newWhereCql.RawWhereClause) > 0 {
		selectCql.FromClause.TemporaryTable.RawWhereClause = newWhereCql.RawWhereClause
	}
	if lastVCql != nil {
		selectCql.FromClause.TemporaryTable.AddSubQueryWhere(consts.ProductID, sql_parse.IN, lastVCql)
	}
	//if needPv {
	//	selectCql.FromClause.TemporaryTable.AddWhere(consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), bizType), sql_parse.GREATER_THAN, 0)
	//}

	dateExpr, _, err := GetDateExpr(ctx, startDate, endDate)
	if err != nil {
		return nil, err
	}
	selectCql.FromClause.TemporaryTable.AddWhereAndValue(dateExpr)
	selectCql.WhereClause = whereCql.WhereClause
	selectCql.AddClickHouseSettings("distributed_product_mode = 'local', distributed_perfect_shard = 1")
	baseExprCql.AddSubQueryWhere("prod_id", sql_parse.IN, selectCql)
	return baseExprCql, nil
}

func AppendTopGlobalInCql(ctx context.Context, selectCql, whereCql, baseExprCql, lastVCql *sql_parse.CQL, startDate, endDate string) (*sql_parse.CQL, error) {
	selectCql.FromClause.TemporaryTable.From(biz_info.GetCtxBizInfoTableName(ctx) + " the_top")
	selectCql.FromClause.TemporaryTable.WhereClause = whereCql.WhereClause
	if len(whereCql.RawWhereClause) > 0 {
		selectCql.FromClause.TemporaryTable.RawWhereClause = whereCql.RawWhereClause
	}
	if lastVCql != nil {
		selectCql.FromClause.TemporaryTable.AddSubQueryWhere(consts.ProductID, sql_parse.IN, lastVCql)
	}
	//if needPv {
	//	selectCql.FromClause.TemporaryTable.AddWhere(consts.GetTableCol(consts.AttrNameShowPV, biz_info.GetCtxBizInfoDimCategory(ctx), bizType), sql_parse.GREATER_THAN, 0)
	//}
	dateExpr, _, err := GetDateExpr(ctx, startDate, endDate)
	if err != nil {
		return nil, err
	}
	selectCql.FromClause.TemporaryTable.AddWhereAndValue(dateExpr)
	baseExprCql.AddSubQueryWhere("prod_id", sql_parse.GLOBAL_IN, selectCql)
	return baseExprCql, nil
}

func GetThresholdAttrs(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (selectCql, whereCql *sql_parse.CQL, ok bool) {
	selectCql = sql_parse.NewCQL()
	whereCql = sql_parse.NewCQL()

	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}

	bizInfoThrMap := make(map[dimensions.ThresholdType]map[string]*dimensions.TargetElementValue)
	for _, attr := range bizInfo.ThresholdAttrMeta {
		thrMap := make(map[string]*dimensions.TargetElementValue)
		for _, v := range attr.ValueList {
			thrMap[v.GetId()] = v
		}
		bizInfoThrMap[attr.Type] = thrMap
	}
	noWhere := false
	if len(req.ThresholdAttrs) > 0 {
		keyList := make([]string, 0)
		for _, attr := range req.ThresholdAttrs {
			keyList = append(keyList, attr.Key)
		}
		accWhere := make([]*sql_parse.Expression, 0)
		for _, attr := range req.ThresholdAttrs {
			thrMap := bizInfoThrMap[attr.Type]
			if thrMap == nil {
				continue
			}
			attrThrInfo := thrMap[attr.Key]
			if attrThrInfo == nil {
				continue
			}
			switch attr.Type {
			case dimensions.ThresholdType_TOP_THRESHOLD:
				noWhere = true
				selectSubCql := sql_parse.NewCQL().Select(consts.ProductID).GroupBy(consts.ProductID)
				selectSubCql.AddSelect(fmt.Sprintf("%s as top_%s", attrThrInfo.Formula, attrThrInfo.Id))
				selectSubCql.OrderBy(sql_parse.DESC, fmt.Sprintf("top_%s", attrThrInfo.Id)).Limit(*attr.TopN)
				selectSubCql.AddClickHouseSettings("distributed_product_mode = 'local', distributed_perfect_shard = 1")
				selectCql.Select(consts.ProductID).FromCql(selectSubCql)
			//case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
			//	selectCql.AddSelect(fmt.Sprintf("sum(%s) as %s", consts.GetTableCol(consts.AttrNamePayOrdCnt, category, req.BizType), consts.AttrNamePayOrdCnt))
			//	selectCql.AddSelect(fmt.Sprintf("sum(%s) as %s", consts.GetTableCol(consts.AttrNameShowPV, category, req.BizType), consts.AttrNameShowPV))
			//	selectCql.AddSelect(fmt.Sprintf("sum(%s) over (order by %s desc rows between unbounded preceding and 1 preceding) as top_sum_%s", attr.Key, attr.Key, attr.Key))
			//	selectCql.AddSelect(fmt.Sprintf("sum(%s) over () total_%s", attr.Key, attr.Key))
			//	whereCql.AddWhere(fmt.Sprintf("top_sum_%s/total_%s*100", attr.Key, attr.Key), sql_parse.LESS_EQUAL_THAN, &attr.TopN)
			case dimensions.ThresholdType_ACC_THRESHOLD:
				if attr.AccThreshold == nil {
					continue
				}
				selectSubCql := sql_parse.NewCQL().Select(consts.ProductID).GroupBy(consts.ProductID)
				for _, v := range thrMap {
					if slices.ContainsString(keyList, v.Id) {
						selectSubCql.AddSelect(fmt.Sprintf("%s as threshold_%s", v.Formula, v.Id))
					}
				}
				selectSubCql.AddClickHouseSettings("distributed_product_mode = 'local', distributed_perfect_shard = 1")
				selectCql.Select(consts.ProductID).FromCql(selectSubCql)
				accWhere = append(accWhere,
					sql_parse.GetExpressionWithOperator(
						convert.ToString(attr.AccThreshold.Threshold),
						TransOperator(attr.AccThreshold.Operator),
						sql_parse.DOUBLE, fmt.Sprintf("threshold_%s", attr.Key)))
			case dimensions.ThresholdType_BIGSALE_HOT_SCORE_THRESHOLD:
				newest, err := utils.GetNewestDay(ctx, consts.LogicTableBigSaleHotScoreTable)
				if err != nil {
					logs.CtxError(ctx, "获取底表就绪时间失败，err:"+err.Error())
					return
				}

				selectCql.Select(consts.ProductID).
					From("app_prod_feat_model_based_bigsale_hit_score_df as bigsale_hit_score").
					AddWhere("date", sql_parse.EQUAL, newest).
					AddWhere("score", TransOperator(attr.AccThreshold.Operator), attr.AccThreshold.Threshold)
				return selectCql, nil, true
			default:
				return selectCql, whereCql, false
			}
		}
		if len(accWhere) > 0 {
			if req.ThresholdExpr != nil && *req.ThresholdExpr == base.LogicalExprType_OR {
				whereCql.WhereClause = &sql_parse.Expression{
					Logic:    sql_parse.OR,
					Children: accWhere,
				}
			} else {
				whereCql.WhereClause = &sql_parse.Expression{
					Logic:    sql_parse.AND,
					Children: accWhere,
				}
			}
		}
	}
	return selectCql, whereCql, len(selectCql.SelectClause) > 0 && (noWhere || (whereCql.WhereClause != nil && len(whereCql.WhereClause.Children) > 0))
}

type OsParamsReq struct {
	BaseStruct     *dimensions.ProductAnalysisBaseStruct
	DimMap         map[int64]*dao.DimensionInfo
	DimColMap      map[string]*dao.DimensionInfo
	MultiDimension []string
	OrderBy        *base.OrderByInfo
	PageInfo       *base.PageInfo
	UvFlag         *bool
	TrendPreFlag   *bool // 用来区分趋势图采样后大于7天时，取前半段还是后半段
}

// GetBaseStructConditionParams 通过基础结构抽象，获取查询的sql结构体 - 包含基础、对比周期、趋势图
func GetBaseStructConditionParams(ctx context.Context, req OsParamsReq) (curr, compare, trend, trendSuffix, overall map[string]interface{}, err error) {
	curr, err = GetBaseStructConditionParam(ctx, req, SQLCalcType_Curr)
	if err != nil {
		logs.CtxError(ctx, "GetBaseStructConditionParams SQLCalcType_Curr error, %s", err.Error())
		return
	}
	compare, err = GetBaseStructConditionParam(ctx, req, SQLCalcType_Compare)
	if err != nil {
		logs.CtxError(ctx, "GetBaseStructConditionParams SQLCalcType_Compare error, %s", err.Error())
		return
	}
	req.TrendPreFlag = utils.GetBoolPtr(true)
	trend, err = GetBaseStructConditionParam(ctx, req, SQLCalcType_Trend)
	if err != nil {
		logs.CtxError(ctx, "GetBaseStructConditionParams SQLCalcType_Trend error, %s", err.Error())
		return
	}
	dateRange := time_utils.DateDiffAbs(req.BaseStruct.StartDate, req.BaseStruct.EndDate) + 1
	if dateRange > 4 {
		req.TrendPreFlag = utils.GetBoolPtr(false)
		trendSuffix, err = GetBaseStructConditionParam(ctx, req, SQLCalcType_Trend)
		if err != nil {
			logs.CtxError(ctx, "GetBaseStructConditionParams SQLCalcType_Trend error, %s", err.Error())
			return
		}
	}
	overall, err = GetBaseStructConditionParam(ctx, req, SQLCalcType_Overall)
	if err != nil {
		logs.CtxError(ctx, "GetBaseStructConditionParams SQLCalcType_Overall error, %s", err.Error())
		return
	}
	return
}

func GetBaseStructConditionParam(ctx context.Context, req OsParamsReq, calcType SQLCalcType) (param map[string]interface{}, err error) {
	if req.BaseStruct == nil {
		return nil, errors.New("[GetBaseStructConditionParam]BaseStruct为空，请检查入参")
	}
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseStruct.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}

	param = make(map[string]interface{})
	param["calc_type"] = calcType
	param["origin_start_date"] = req.BaseStruct.StartDate
	param["origin_end_date"] = req.BaseStruct.EndDate
	startDate, endDate := GetDateRange(req.BaseStruct, calcType == SQLCalcType_Compare)
	logs.CtxInfo(ctx, "GetBaseStructConditionParam GetDateRange %s, %s, %s", jsonx.ToString(startDate), jsonx.ToString(endDate), jsonx.ToString(req.BaseStruct))
	if req.BaseStruct.BizType == 0 {
		return param, nil
	}
	param["start_date"] = startDate
	param["end_date"] = endDate
	param["compare_start_date"] = req.BaseStruct.CompareStartDate
	param["compare_end_date"] = req.BaseStruct.CompareEndDate
	param["date_range"] = time_utils.DateDiffAbs(startDate, endDate) + 1
	param["date_range_compare"] = time_utils.DateDiffAbs(req.BaseStruct.CompareStartDate, req.BaseStruct.CompareEndDate) + 1

	// 如果是不需要完美分片的业务线，则直接置true
	if slices.ContainsInt64(consts.NotDistributedPerfectShardBizTypeList, int64(req.BaseStruct.BizType)) {
		param["not_distributed_perfect_shard"] = consts.IsTrueString
	}

	var dateExpr, dateExpr2, dateExpr3, dateExpr4 *sql_parse.Expression
	if calcType == SQLCalcType_Trend {
		dateExpr, dateExpr2, dateExpr3, dateExpr4, err = GetTrendDateExpr(ctx, startDate, endDate)
		if err != nil {
			return nil, err
		}
		if req.TrendPreFlag != nil && !*req.TrendPreFlag {
			if dateExpr2 == nil {
				return nil, errors.New("后半段时期表达式dateExpr为空，请检查")
			}
			param["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr2)
			param["date_expr_no_days_type"] = sql_parse.NewCQL().ParseExpression(dateExpr4)
		} else {
			param["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
			param["date_expr_no_days_type"] = sql_parse.NewCQL().ParseExpression(dateExpr3)
		}
	} else {
		// 商品池类型只能用1d分区
		if req.BaseStruct != nil && req.DimMap != nil {
			for _, reqDim := range req.BaseStruct.Dimensions {
				dimInfo := req.DimMap[convert.ToInt64(reqDim.Id)]
				if dimInfo == nil {
					logs.CtxError(ctx, "[GetBaseStructConditionParam]未查询到维度信息,id=%s", reqDim.Id)
					return nil, errors.New("未查询到维度信息，请检查")
				}
				if dimInfo.ProcessType == "商品池类型" {
					ctx = context.WithValue(ctx, consts.CtxProdPoolTag, consts.DateType_DAY)
					break
				}
			}
		}
		dateExpr, dateExpr2, err = GetDateExpr(ctx, startDate, endDate)
		logs.CtxInfo(ctx, "GetBaseStructConditionParam GetDateExpr %s, %s, %s", jsonx.ToString(startDate), jsonx.ToString(endDate), jsonx.ToString(dateExpr))
		param["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)
		param["date_expr_no_days_type"] = sql_parse.NewCQL().ParseExpression(dateExpr2)
	}
	if err != nil {
		return nil, err
	}

	param["biz_type"] = int64(req.BaseStruct.BizType)

	// 是否是潜客
	category, _, err := biz_info.GetFilterDimCategory(ctx, req.BaseStruct)
	if err != nil {
		return
	}
	param["user_type"] = int64(category)

	if req.UvFlag != nil && *req.UvFlag {
		param["uv_flag"] = true
	} else {
		param["uv_flag"] = false
	}

	// 表名筛选
	param["table_name"] = bizInfo.TableName

	// 大盘不需要下面的筛选项
	if calcType == SQLCalcType_Overall {
		//if req.BaseStruct.BizType == dimensions.BizType_GrowthProductStrategy {
		//	param["table_name"] = biz_info.ApiProdBaseScenarioTableName
		//}
		return
	}

	// 分页和排序逻辑
	if req.OrderBy != nil {
		var orderByField, orderType string
		if req.OrderBy.IsDesc {
			orderType = "desc"
		} else {
			orderType = "asc"
		}
		if req.OrderBy.ColumnName != nil {
			orderByField = *req.OrderBy.ColumnName
		} else if req.OrderBy.Field != nil {
			switch *req.OrderBy.Field {
			case base.OrderByField_ShowPv:
				if req.BaseStruct.BizType == dimensions.BizType_AttributionCoreGuess {
					orderByField = "guess_show_pv"
				} else {
					orderByField = "show_pv"
				}
			case base.OrderByField_PayOrderNum:
				orderByField = "pay_ord_cnt"
			case base.OrderByField_BrandLevel:
				orderByField = "complex_brand_s_level"
			case base.OrderByField_GMV:
				orderByField = "gmv"
			default:
				orderByField = consts.Empty
			}
		} else {
			return nil, errors.New("order by字段传参有问题，请检查")
		}

		param["order_by"] = fmt.Sprintf("%v %v,prod_id", orderByField, orderType)
	}

	if req.PageInfo != nil {
		param["limit"] = req.PageInfo.PageSize
		param["offset"] = req.PageInfo.PageSize * (req.PageInfo.PageNum - 1)
	}

	// 解析所选维度过滤信息
	exprCql, _, lastVCql, err := GetBaseConditionWithDims(ctx, req.BaseStruct, calcType == SQLCalcType_Compare, req.DimMap, false, false)
	if err != nil {
		return
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}

	addLastV := true
	if len(req.BaseStruct.ThresholdAttrs) > 0 {
		thrSelectCql, thrWhereCql, ok := GetThresholdAttrs(ctx, req.BaseStruct)
		if ok {
			// 解析所选维度过滤信息
			newWhereCql, _, _, err := GetBaseConditionWithDims(ctx, GetBaseReqWithoutGroupAttrs(req.BaseStruct), calcType == SQLCalcType_Compare, req.DimMap, false, false)
			if err != nil {
				return nil, err
			}
			if newWhereCql == nil {
				newWhereCql = sql_parse.NewCQL()
			}
			switch req.BaseStruct.ThresholdAttrs[0].Type {
			case dimensions.ThresholdType_ACC_THRESHOLD:
				addLastV = false
				exprCql, err = AppendAccGlobalInCql(ctx, thrSelectCql, thrWhereCql, newWhereCql, exprCql, lastVCql, convert.ToString(param["start_date"]), convert.ToString(param["end_date"]), req.BaseStruct.BizType)
				if err != nil {
					return nil, err
				}
				//param["threshold_select_param"] = thrSelectCql.ParseSelectClause()
			case dimensions.ThresholdType_TOP_THRESHOLD:
				addLastV = false
				exprCql, err = AppendTopGlobalInCql(ctx, thrSelectCql, newWhereCql, exprCql, lastVCql, convert.ToString(param["start_date"]), convert.ToString(param["end_date"]))
				if err != nil {
					return nil, err
				}
				param["not_distributed_perfect_shard"] = consts.IsTrueString
			case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
				addLastV = false
				//exprCql, err = AppendGlobalInCql(ctx, thrSelectCql, thrWhereCql, exprCql, lastVCql, convert.ToString(param["start_date"]), convert.ToString(param["end_date"]))
				//if err != nil {
				//	return nil, err
				//}
			case dimensions.ThresholdType_BIGSALE_HOT_SCORE_THRESHOLD:
				exprCql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, thrSelectCql)
			default:
				logs.CtxError(ctx, "[GetBaseStructConditionParam]ThresholdAttrs Empty, req=%s", convert.ToJSONString(req))
			}
		}
	}

	if addLastV && lastVCql != nil {
		exprCql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, lastVCql)
	}

	whereStr := exprCql.ParseAllWhereExpression()
	if len(whereStr) > 0 {
		bizMetaInfo := biz_utils.GetBizMetaInfoFromContext(ctx)
		if bizMetaInfo != nil && (bizMetaInfo.EffectModule == "大促视图" ||
			strings.Contains(bizMetaInfo.EffectModule, "货盘复盘")) {
			for _, replaceKey := range BigactSignStatusReplaceList {
				replaceValue, exist := BigactSignStatusReplaceMap[replaceKey]
				if !exist {
					logs.CtxError(ctx, "未找到大促报名状态替换值，key=%s", replaceKey)
					continue
				}
				whereStr = strings.ReplaceAll(whereStr, replaceKey, replaceValue)
			}
		}
		param["filter_param"] = whereStr
	}

	dimensionJoinArr := make([]string, 0)
	if calcType == SQLCalcType_Trend {
		req.MultiDimension = append(req.MultiDimension, "date")
		dimensionJoinArr = append(dimensionJoinArr, "date")
	}

	if len(req.MultiDimension) > 0 {
		subSelect := make([]string, 0)
		for _, d := range req.MultiDimension {
			if dimInfo, exist := req.DimColMap[d]; exist && len(dimInfo.DimExpr) > 0 {
				subSelect = append(subSelect, fmt.Sprintf("%s as %s", dimInfo.DimExpr, d))
			} else {
				subSelect = append(subSelect, d)
			}
			dimensionJoinArr = append(dimensionJoinArr, d)
		}

		param["sub_select"] = strings.Join(subSelect, ",")
		param["dimension"] = strings.Join(req.MultiDimension, ",")
		param["dimension_join_on"] = GenerateDimKeyJoinOn(dimensionJoinArr)
	}
	return
}

// GetBaseStructConditionCql 通过基础结构抽象，获取查询的CQL结构体
func GetBaseStructConditionCql(ctx context.Context, req BaseStructConditionReq) (cql *sql_parse.CQL, sub *sql_parse.CQL, err error) {
	subCql := &sql_parse.CQL{}
	baseCql := &sql_parse.CQL{}

	subCql.From(biz_info.GetCtxBizInfoTableName(ctx))
	if req.NeedProdID {
		subCql.Select("prod_id").GroupBy("prod_id")
	}
	// 多维分析填充
	if len(req.MultiDimColumns) > 0 {
		req.MultiDimColumns = slices.DistinctString(req.MultiDimColumns)
		subSelect := make([]string, 0)
		for _, d := range req.MultiDimColumns {
			if dimInfo, exist := req.DimColMap[d]; exist && len(dimInfo.DimExpr) > 0 {
				subSelect = append(subSelect, fmt.Sprintf("%s as %s", dimInfo.DimExpr, d))
			} else {
				subSelect = append(subSelect, d)
			}
		}
		subCql.AddSelect(subSelect...).AddGroupBy(req.MultiDimColumns...)
		if !req.NotSyncBaseMulti {
			baseCql.AddSelect(req.MultiDimColumns...).AddGroupBy(req.MultiDimColumns...)
		}
	}

	// 分析指标
	if len(req.SubSelectList) > 0 {
		subCql.AddSelect(req.SubSelectList...)
	}

	if len(req.BaseSelectList) > 0 {
		baseCql.AddSelect(req.BaseSelectList...)
	}
	// 获取日期范围
	startDate, endDate := GetDateRange(req.BaseStruct, req.IsCompare)
	// 解析所选维度过滤信息
	subExprCql, _, lastVCql, err := GetBaseConditionWithDims(ctx, req.BaseStruct, req.IsCompare, req.DimMap, false, req.IsAlertRule)
	if err != nil {
		return nil, nil, err
	}

	addLastV := true
	needShard := true
	// 解析指标阈值信息
	if len(req.BaseStruct.ThresholdAttrs) > 0 {
		thrSelectCql, thrWhereCql, ok := GetThresholdAttrs(ctx, req.BaseStruct)
		if ok {
			newWhereCql, _, _, err := GetBaseConditionWithDims(ctx, GetBaseReqWithoutGroupAttrs(req.BaseStruct), req.IsCompare, req.DimMap, false, req.IsAlertRule)
			if err != nil {
				return nil, nil, err
			}
			if newWhereCql == nil {
				newWhereCql = sql_parse.NewCQL()
			}
			switch req.BaseStruct.ThresholdAttrs[0].Type {
			case dimensions.ThresholdType_ACC_THRESHOLD:
				//subCql.SelectClause = append(subCql.SelectClause, thrSelectCql.SelectClause...)
				//baseCql.AddWhereAndValue(thrWhereCql.WhereClause)
				addLastV = false
				subExprCql, err = AppendAccGlobalInCql(ctx, thrSelectCql, thrWhereCql, newWhereCql, subExprCql, lastVCql, startDate, endDate, req.BaseStruct.BizType)
				if err != nil {
					return nil, nil, err
				}
			case dimensions.ThresholdType_TOP_THRESHOLD:
				addLastV = false
				needShard = false
				subExprCql, err = AppendTopGlobalInCql(ctx, thrSelectCql, newWhereCql, subExprCql, lastVCql, startDate, endDate)
				if err != nil {
					return nil, nil, err
				}
			case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
				addLastV = false
				//subExprCql, err = AppendGlobalInCql(ctx, thrSelectCql, thrWhereCql, subExprCql, lastVCql, startDate, endDate)
				//if err != nil {
				//	return nil, err
				//}
			case dimensions.ThresholdType_BIGSALE_HOT_SCORE_THRESHOLD:
				subExprCql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, thrSelectCql)
			default:
				logs.CtxError(ctx, "[GetBaseStructConditionCql]ThresholdAttrs empty: %s", convert.ToJSONString(req))
			}
		}
	}

	if addLastV && lastVCql != nil {
		subExprCql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, lastVCql)
	}

	//subCql.AddWhereRawCond("date between ? and ?", startDate, endDate)
	if req.IsAlertRule {
		dataExpr, alertErr := GetAlertDataExpr(biz_info.GetCtxBizInfoTableName(ctx))
		if alertErr != nil {
			logs.CtxError(ctx, "[GetBaseStructConditionCql]dataExpr error: %s", alertErr)
		}
		subCql.AddWhereAndValue(dataExpr)
	} else {
		subCql, err = TransformCqlAppendDateExpr(ctx, subCql, startDate, endDate)
	}
	if err != nil {
		return nil, nil, err
	}
	if subExprCql.WhereClause != nil {
		subCql.AddWhereAndValue(subExprCql.WhereClause.Children...)
	}
	subCql.AddRawWhereAndValue(subExprCql.RawWhereClause...)

	baseCql.FromCql(subCql)

	if req.CKSettingType != CKSettingNone {
		switch req.CKSettingType {
		case CKSettingSub:
			subCql.AddClickHouseSettings("distributed_product_mode = 'local'")
			if needShard {
				subCql.AddClickHouseSettings("distributed_perfect_shard = 1")
			}
		default:
			baseCql.AddClickHouseSettings("distributed_product_mode = 'local'")
			if needShard {
				baseCql.AddClickHouseSettings("distributed_perfect_shard = 1")
			}
		}
	}

	if baseCql != nil {
		logs.CtxInfo(ctx, "[GetBaseStructConditionCql]获取CQL成功 baseCql=%s", baseCql.Compile())
	}
	return baseCql, subCql, nil
}

func GetDateRange(baseStruct *dimensions.ProductAnalysisBaseStruct, isCompare bool) (startDate, endDate string) {
	return utils.If(isCompare, baseStruct.CompareStartDate, baseStruct.StartDate), utils.If(isCompare, baseStruct.CompareEndDate, baseStruct.EndDate)
}

func GetBaseConditionWithDims(ctx context.Context, baseStruct *dimensions.ProductAnalysisBaseStruct, isCompare bool, dimMap map[int64]*dao.DimensionInfo, addLastV bool, isAlertRule bool) (cql, baseExprCql, lastVCql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	if len(baseStruct.Dimensions) > 0 {
		prodValLastDayDims := make([]*dimensions.SelectedDimensionInfo, 0)
		prodValNewestDayDims := make([]*dimensions.SelectedDimensionInfo, 0)
		prodBaseDims := make([]*dimensions.SelectedDimensionInfo, 0)
		prodPoolDims := make([]*dimensions.SelectedDimensionInfo, 0)    // 商品池（按天关联）
		prodPoolDimsAgg := make([]*dimensions.SelectedDimensionInfo, 0) // 商品池（多天去重）
		activityDims := make([]*dimensions.SelectedDimensionInfo, 0)    // 招商活动（最新一天快照关联）
		activityDimsAgg := make([]*dimensions.SelectedDimensionInfo, 0) // 招商活动（按天关联）
		OncePoolDims := make([]*dimensions.SelectedDimensionInfo, 0)    // 单次关联商品包
		brainDims := make([]*dimensions.SelectedDimensionInfo, 0)
		brainSubDims := make([]*dimensions.SelectedDimensionInfo, 0)
		pushPoolDims := make([]*dimensions.SelectedDimensionInfo, 0) // push商品维度
		prodSelectOnceDims := make([]*dimensions.SelectedDimensionInfo, 0)
		marketActivityDims := make([]*dimensions.SelectedDimensionInfo, 0) // 市集活动维度（按天关联）
		var algorithmFeatureSignDim *dimensions.SelectedDimensionInfo      // 算法特征标识
		var marketProjectDim *dimensions.SelectedDimensionInfo             // 市集项目ID

		investmentSelectProdDims := make([]*dimensions.SelectedDimensionInfo, 0)
		recruitProdDimsByDay := make([]*dimensions.SelectedDimensionInfo, 0)
		DynamicDimensionsMap := make(map[string]map[bool][]*dimensions.SelectedDimensionInfo, 0)
		PackageDynamicDimensionsMap := make(map[string]*consts.PackageDynamicDimensionInfo, 0)

		var prodPoolDim *dimensions.SelectedDimensionInfo
		var prodSearchShowDim *dimensions.SelectedDimensionInfo // 搜索有曝光商品
		var supplyChangeDim *dimensions.SelectedDimensionInfo   // 搜索有曝光商品
		bizMetaInfo := biz_utils.GetBizMetaInfoFromContext(ctx)
		if bizMetaInfo == nil {
			logs.CtxError(ctx, "[GetBaseStructConditionCql]未查询到bizMetaInfo")
			return nil, nil, nil, errors.New("未查询到bizMetaInfo")
		}
		for _, reqDim := range baseStruct.Dimensions {
			dimInfo := dimMap[convert.ToInt64(reqDim.Id)]
			if dimInfo == nil {
				logs.CtxError(ctx, "[GetBaseStructConditionCql]未查询到维度信息,id=%s", reqDim.Id)
				return nil, nil, nil, errors.New("未查询到维度信息")
			}
			switch dimInfo.ProcessType {
			case "商品池类型":
				// 没有添加枚举值时，不要添加到维度筛选中
				if len(reqDim.SelectedValues) > 0 {
					//poolIdList := make([]int64, 0)
					//for _, id := range reqDim.SelectedValues {
					//	poolIdList = append(poolIdList, convert.ToInt64(id))
					//}
					//poolMetaList, err := dao.GetPoolMetaList(ctx, nil, nil, poolIdList)
					//if err != nil {
					//	logs.CtxError(ctx, err.Error())
					//	return nil, nil, nil, err
					//}
					prodPoolDims = append(prodPoolDims, reqDim)
				}
			case "商品ID外部子查询":
				if len(reqDim.SelectedValues) == 0 || len(reqDim.SelectedValues[0].TypeValue) == 0 {
					logs.CtxWarn(ctx, "[GetBaseStructConditionCql]商品ID外部子查询,未发现sql，reqDim=%s", convert.ToJSONString(reqDim))
					continue
				}
				subSqlKey := reqDim.SelectedValues[0].TypeValue[0]
				if baseStruct.CompareType != nil &&
					*baseStruct.CompareType == dimensions.CompareType_MarketingPromotionGrowthLibraCompare && isCompare {
					if len(reqDim.SelectedValues[0].TypeValue) < 2 {
						logs.CtxError(ctx, "[GetBaseStructConditionCql]商品ID外部子查询,未发现对比SQL，reqDim=%s", convert.ToJSONString(reqDim))
						return nil, nil, nil, errors.New("商品ID外部子查询,未发现对比SQL")
					}
					subSqlKey = reqDim.SelectedValues[0].TypeValue[1]
				}
				rdsVal, err := redis.GrowthExperimentClient.WithContext(ctx).Get(subSqlKey).Result()
				if err != nil || len(rdsVal) == 0 {
					logs.CtxError(ctx, "获取增长数据平台子查询SQL失败,subSqlKey:%s, err:%v+", subSqlKey, err)
					return nil, nil, nil, errors.New("获取增长数据平台子查询SQL失败")
				}
				var params = &promotion_growth_data_platform.ProductCostSqlParam{}
				err = sonic.UnmarshalString(rdsVal, params)
				if err != nil {
					logs.CtxError(ctx, "获取增长数据平台子查询SQL失败,转化JSON失败 rdsVal = %s, err = %v+", rdsVal, err)
					return nil, nil, nil, errors.New("获取增长数据平台子查询SQL失败")
				}
				logs.CtxInfo(ctx, "获取增长数据平台子查询SQL成功，%s", params.SubSql)
				cql.AddRawWhere(fmt.Sprintf(" and prod_id in (%s)", params.SubSql))
			case "最新属性筛选":
				prodValNewestDayDims = append(prodValNewestDayDims, reqDim)
			case "招商活动":
				if len(reqDim.SelectedValues) > 0 {
					activityDims = append(activityDims, reqDim)
				}
			case "最新一天商品池类型":
				if len(reqDim.SelectedValues) > 0 {
					OncePoolDims = append(OncePoolDims, reqDim)
				}
			case "单次商品池类型":
				if len(reqDim.SelectedValues) > 0 {
					prodSelectOnceDims = append(prodSelectOnceDims, reqDim)
				}
			case "选品大脑维度":
				if len(reqDim.SelectedValues) > 0 {
					brainDims = append(brainDims, reqDim)
				}
			case "选品大脑子查询":
				if len(reqDim.SelectedValues) == 0 {
					logs.CtxWarn(ctx, "[GetBaseStructConditionCql]选品大脑子查询,未发现sql，reqDim=%s", convert.ToJSONString(reqDim))
					continue
				}
				brainSubDims = append(brainSubDims, reqDim)
			case "Push商品维度":
				if len(reqDim.SelectedValues) > 0 {
					pushPoolDims = append(pushPoolDims, reqDim)
				}
			case "多天聚合商品池类型":
				if len(reqDim.SelectedValues) > 0 {
					prodPoolDimsAgg = append(prodPoolDimsAgg, reqDim)
				}
			case "按天关联招商活动":
				if len(reqDim.SelectedValues) > 0 {
					activityDimsAgg = append(activityDimsAgg, reqDim)
				}
			case "市集活动-货品分析":
				if len(reqDim.SelectedValues) > 0 {
					marketActivityDims = append(marketActivityDims, reqDim)
				}
			default:
				if dimInfo.IsProdIDAttr == 1 {
					if len(reqDim.SelectedValues) > 0 {
						prodValLastDayDims = append(prodValLastDayDims, reqDim)
					}
				} else if reqDim.Id == consts.CustomProductPool && len(reqDim.SelectedValues) > 0 {
					prodPoolDim = reqDim
				} else if reqDim.Id == consts.SearchShowProd {
					prodSearchShowDim = reqDim
					//} else if (reqDim.Id == consts.InvestmentSelectProd) && len(reqDim.SelectedValues) > 0 {
					//	investmentSelectProdDims = append(investmentSelectProdDims, reqDim)
					//} else if reqDim.Id == consts.RecruitProd && len(reqDim.SelectedValues) > 0 {
					//	recruitProdDimsByDay = append(recruitProdDimsByDay, reqDim)
					//} else if (reqDim.Id == consts.FlowControlSignalId || reqDim.Id == consts.FlowControlPlanId) &&
					//	len(reqDim.SelectedValues) > 0 {
					//	flowControlProdDimsByDay = append(flowControlProdDimsByDay, reqDim)
				} else if dynamicInfo, ok := consts.DimensionIdDynamicDimensionInfoMap[reqDim.Id]; ok &&
					len(reqDim.SelectedValues) > 0 {
					if DynamicDimensionsMap[dynamicInfo.PartitionName] == nil {
						DynamicDimensionsMap[dynamicInfo.PartitionName] = make(map[bool][]*dimensions.SelectedDimensionInfo, 0)
					}
					DynamicDimensionsMap[dynamicInfo.PartitionName][dynamicInfo.IsRelationByDay] =
						append(DynamicDimensionsMap[dynamicInfo.PartitionName][dynamicInfo.IsRelationByDay], reqDim)
				} else if packageDynamicInfo, ok := consts.PackageDynamicDimensionInfoMap[reqDim.Id]; ok &&
					len(reqDim.SelectedValues) > 0 {
					if PackageDynamicDimensionsMap[reqDim.Id] == nil {
						PackageDynamicDimensionsMap[reqDim.Id] = &consts.PackageDynamicDimensionInfo{}
						PackageDynamicDimensionsMap[reqDim.Id].DynamicDim = reqDim
					}
					if len(PackageDynamicDimensionsMap[reqDim.Id].DynamicDim.SelectedValues) == 0 {
						PackageDynamicDimensionsMap[reqDim.Id].DynamicDim.SelectedValues = make([]*dimensions.EnumElement, 0)
					}
					PackageDynamicDimensionsMap[reqDim.Id].DynamicDim.SelectedValues = append(PackageDynamicDimensionsMap[reqDim.Id].DynamicDim.SelectedValues, reqDim.SelectedValues...)
					PackageDynamicDimensionsMap[reqDim.Id].PartitionName = packageDynamicInfo.PartitionName
				} else if reqDim.Id == consts.IsNoChangeSupplyLink ||
					reqDim.Id == consts.IsOfflineSupplyLink ||
					reqDim.Id == consts.IsNewSupplyLink {
					supplyChangeDim = reqDim
				} else if reqDim.Id == consts.MarketProject && len(reqDim.SelectedValues) > 0 {
					marketProjectDim = reqDim
				} else if reqDim.Id == consts.AlgorithmFeatureSignId && len(reqDim.SelectedValues) > 0 {
					algorithmFeatureSignDim = reqDim
				} else {
					prodBaseDims = append(prodBaseDims, reqDim)
				}
			}
		}
		var startDate, endDate string
		if baseStruct.CompareStartDate < baseStruct.StartDate {
			startDate = baseStruct.CompareStartDate
			endDate = baseStruct.EndDate
		} else {
			startDate = baseStruct.StartDate
			endDate = baseStruct.CompareEndDate
		}
		// 一次性商品池

		// 多天商品去重关联，对比周期也用当前周期的去重商品包
		if len(prodPoolDimsAgg) > 0 {
			ctx = context.WithValue(ctx, consts.CtxProdPoolTag, consts.DateType_DAY)
			var poolCQL *sql_parse.CQL
			if _, ok := ctx.Value(consts.CtxAllDatePoolFlag).(string); ok {
				poolCQL, err = GetProductPoolCQLAgg(bizMetaInfo, prodPoolDimsAgg, startDate, endDate, isAlertRule)
			} else {
				poolCQL, err = GetProductPoolCQLAgg(bizMetaInfo, prodPoolDimsAgg, baseStruct.StartDate, baseStruct.EndDate, isAlertRule)
			}
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("prod_id", sql_parse.IN, poolCQL)
		}

		// 按天关联的商品池
		if len(prodPoolDims) > 0 {
			ctx = context.WithValue(ctx, consts.CtxProdPoolTag, consts.DateType_DAY)
			var poolCQL *sql_parse.CQL
			if _, ok := ctx.Value(consts.CtxAllDatePoolFlag).(string); ok {
				poolCQL, err = GetProductPoolCQL(bizMetaInfo, prodPoolDims, startDate, endDate, isAlertRule)
			} else if isCompare {
				poolCQL, err = GetProductPoolCQL(bizMetaInfo, prodPoolDims, baseStruct.CompareStartDate, baseStruct.CompareEndDate, false)
			} else {
				poolCQL, err = GetProductPoolCQL(bizMetaInfo, prodPoolDims, baseStruct.StartDate, baseStruct.EndDate, isAlertRule)
			}
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("(prod_id, date)", sql_parse.IN, poolCQL)
		}

		var (
			dateExpr *sql_parse.Expression
			err      error
		)

		if !isAlertRule && len(baseStruct.StartDate) > 0 {
			dateExpr, _, err = GetDateExpr(ctx, utils.If(isCompare, baseStruct.CompareStartDate, baseStruct.StartDate),
				utils.If(isCompare, baseStruct.CompareEndDate, baseStruct.EndDate))
			if err != nil {
				return nil, nil, nil, err
			}
		} else if isAlertRule {
			dateExpr, err = GetAlertDataExpr(biz_info.GetCtxBizInfoTableName(ctx))
			if err != nil {
				return nil, nil, nil, err
			}
		}

		if len(prodValLastDayDims) > 0 {
			newestDay := utils.If(isCompare, baseStruct.CompareEndDate, baseStruct.EndDate)
			if bizMetaInfo != nil && bizMetaInfo.EffectModule == "大促视图" { // 大盘，yoy都用最新一天数据
				tableConf, err := tcc.GetBigActClusterSwitchConf(ctx)
				if err != nil {
					logs.CtxError(ctx, "获取大促视图逻辑表配置失败, err=%v", err)
					return nil, nil, nil, err
				}
				newestDay, _ = utils.GetNewestDay(ctx, tableConf.LogicTableProdBase)
			}
			lastVCql, err = GetProductLastDayValCQL(ctx, prodValLastDayDims, dimMap, newestDay, consts.Empty, isAlertRule)
			if err != nil {
				return nil, nil, nil, err
			}
			if addLastV {
				cql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, lastVCql)
			}
		}

		if len(prodValNewestDayDims) > 0 {
			newestDay, err := utils.GetNewestDay(ctx, consts.LogicTableDimensionArctic)
			if err != nil {
				return nil, nil, nil, err
			}
			newestVCql, err := GetProductLastDayValCQL(ctx, prodValNewestDayDims, dimMap, newestDay, "_newest", isAlertRule)
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, newestVCql)
		}

		if prodPoolDim != nil {
			productIds, poolCql, err := GetProductPoolExpr(ctx, prodPoolDim, baseStruct, dimMap)
			if err != nil {
				return nil, nil, nil, err
			}
			if len(productIds) > 0 { // 人工入录
				cql.AddWhere(consts.ProductID, sql_parse.IN, productIds)
			} else if poolCql != nil { // 规则货盘
				bizMetaInfo := biz_utils.GetBizMetaInfoFromContext(ctx)
				if baseStruct.GetBizType() == dimensions.BizType_AttributionCoreGuess ||
					baseStruct.GetBizType() == dimensions.BizType_AttributionSupply ||
					baseStruct.GetBizType() == dimensions.BizType_AttributionQuality ||
					baseStruct.GetBizType() == dimensions.BizType_AttributionFlow ||
					baseStruct.GetBizType() == dimensions.BizType_SimilarProduct ||
					(bizMetaInfo != nil && bizMetaInfo.EffectModule == "大促视图") {
					poolTemp := sql_parse.NewCQL()
					tableName := "app_product_insight_usr_prod_scenario_flow_trd_stats_new_di_arctic"
					if bizMetaInfo != nil && bizMetaInfo.EffectModule == "大促视图" {
						tableName = bizMetaInfo.TableName
					}
					poolTemp.Select("prod_id as prod_id").From(utils.AddTableNameAlias(tableName, "ttt"))
					poolTemp.AddWhereAndValue(poolCql.WhereClause, dateExpr).AddRawWhereAndValue(poolCql.RawWhereClause...)
					poolTemp.AddClickHouseSettings("distributed_product_mode = 'local',distributed_perfect_shard=1")
					cql.AddSubQueryWhere("prod_id", sql_parse.IN, poolTemp)
				} else {
					cql.AddWhereAndValue(poolCql.WhereClause).AddRawWhereAndValue(poolCql.RawWhereClause...)
				}

			}
		}
		// 招商选品集ID,按照最新一天数据关联
		if len(investmentSelectProdDims) > 0 && bizMetaInfo != nil {
			packageProdRelatedByLastDay, _ := GetPackageProdCql(ctx, bizMetaInfo.BizType,
				investmentSelectProdDims, startDate, endDate, dimMap, false)
			cql.AddSubQueryWhere("prod_id", sql_parse.IN, packageProdRelatedByLastDay)
		}
		// 招商选品集ID(按天关联)
		if len(recruitProdDimsByDay) > 0 && bizMetaInfo != nil {
			packageProdRelatedByDay, _ := GetPackageProdCql(ctx, bizMetaInfo.BizType,
				recruitProdDimsByDay, startDate, endDate, dimMap, true)
			cql.AddSubQueryWhere("(prod_id, date)", sql_parse.IN, packageProdRelatedByDay)
		}
		if len(DynamicDimensionsMap) > 0 && bizMetaInfo != nil {
			for _, dynamicDims := range DynamicDimensionsMap {
				relationByDayDims := dynamicDims[true]
				relationLastDayDims := dynamicDims[false]
				if len(relationByDayDims) > 0 {
					relatedByDayCql, _ := GetPackageProdCql(ctx, bizMetaInfo.BizType,
						relationByDayDims, startDate, endDate, dimMap, true)
					cql.AddSubQueryWhere("(prod_id, date)", sql_parse.IN, relatedByDayCql)
				}
				if len(relationLastDayDims) > 0 {
					relatedLastDayCql, _ := GetPackageProdCql(ctx, bizMetaInfo.BizType,
						relationLastDayDims, startDate, endDate, dimMap, false)
					cql.AddSubQueryWhere("prod_id", sql_parse.IN, relatedLastDayCql)
				}
			}
		}
		if len(PackageDynamicDimensionsMap) > 0 {
			for dimId, dynamicDim := range PackageDynamicDimensionsMap {
				dimInfo, ok := dimMap[convert.ToInt64(dimId)]
				if !ok {
					logs.CtxError(ctx, "包动态维度 获取动态维度信息失败, dimId=%s", dimId)
					continue
				}
				isRelationByDay := dimInfo.IsProdIDAttr == 1
				relationDim := dynamicDim.DynamicDim
				if isRelationByDay {
					relatedByDayCql, _ := GetPackageDynamicDimensionProdCql(ctx, bizMetaInfo.BizType,
						relationDim, startDate, endDate, dimMap, true, dynamicDim.PartitionName)
					cql.AddSubQueryWhere("("+dynamicDim.PartitionName+", date)", sql_parse.IN, relatedByDayCql)
				} else {
					relatedLastDayCql, _ := GetPackageDynamicDimensionProdCql(ctx, bizMetaInfo.BizType,
						relationDim, startDate, endDate, dimMap, false, dynamicDim.PartitionName)
					cql.AddSubQueryWhere(dynamicDim.PartitionName, sql_parse.IN, relatedLastDayCql)
				}
			}
		}

		if prodSearchShowDim != nil {
			searchShow := sql_parse.NewCQL()
			searchShow.Select("prod_id as prod_id").From(utils.AddTableNameAlias("app_product_insight_usr_prod_search_scenario_flow_trd_stats_di", "ttt"))
			searchShow.AddWhereAndValue(dateExpr).AddRawWhere("and prod_show_cnt_1d > 0")
			searchShow.AddClickHouseSettings("distributed_product_mode = 'local',distributed_perfect_shard=1")
			cql.AddSubQueryWhere("prod_id", sql_parse.IN, searchShow)
		}

		if len(prodBaseDims) > 0 {
			baseExprCql, err = GetDimCondition(ctx, prodBaseDims, dimMap, dateExpr)
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddWhereAndValue(baseExprCql.WhereClause).AddRawWhereAndValue(baseExprCql.RawWhereClause...)
		}
		if len(activityDims) > 0 {
			activityCql, err := GetActivityPoolCQL(ctx, baseStruct.BizType, activityDims, dimMap)
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("prod_id", sql_parse.IN, activityCql)
		}
		if len(activityDimsAgg) > 0 {
			var activityCql *sql_parse.CQL
			if isCompare {
				activityCql, err = GetActivityAggCQL(ctx, baseStruct.BizType, activityDimsAgg, dimMap, baseStruct.CompareStartDate, baseStruct.CompareEndDate)
			} else {
				activityCql, err = GetActivityAggCQL(ctx, baseStruct.BizType, activityDimsAgg, dimMap, baseStruct.StartDate, baseStruct.EndDate)
			}
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("(prod_id, date)", sql_parse.IN, activityCql)
		}
		if len(prodSelectOnceDims) > 0 {
			prodSelectOnceCql, err := GetProdSelectOncePoolCQL(ctx, prodSelectOnceDims)
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("prod_id", sql_parse.IN, prodSelectOnceCql)
		}
		if len(brainSubDims) > 0 {
			var poolIdList = make([]string, 0)
			for _, enum := range brainSubDims[0].SelectedValues {
				poolIdList = append(poolIdList, enum.Code)
			}
			// 全量拉取选品大脑货盘，前端做搜索和分页
			allProdData, err := ecom_ecop_matching_brain.RawCall.ListBrainProdPallet(ctx, &matching_brain.ListBrainProdPalletReq{
				PalletId: poolIdList,
			})
			if err != nil {
				logs.CtxError(ctx, "[GetBaseStructConditionCql]获取选品大脑货盘列表失败，err:", err.Error())
				return nil, nil, nil, err
			}
			if allProdData == nil {
				logs.CtxError(ctx, "[GetBaseStructConditionCql]选品大脑货盘列表接口返回值为nil")
				return nil, nil, nil, errors.New("[GetBaseStructConditionCql]选品大脑货盘列表接口返回值为nil")
			}
			logs.CtxInfo(ctx, "获取选品大脑货盘成功，%s", litter.Sdump(allProdData.Data))
			var subSql string
			if len(brainDims) > 0 {
				subCql := sql_parse.NewCQL()
				exprCql, err := GetDimCondition(ctx, brainDims, dimMap, nil)
				if err != nil {
					return nil, nil, nil, errors.New("[GetBaseStructConditionCql]选品大脑")
				}
				subCql.AddRawWhereAndValue(exprCql.RawWhereClause...).AddWhereAndValue(exprCql.WhereClause)
				subSql = "and " + sql_parse.NewCQL().ParseExpression(exprCql.WhereClause)
			}
			for _, poolData := range allProdData.Data {
				cql.AddRawWhere(fmt.Sprintf(" and prod_id in (%s %s)", poolData.GetLogicSql(), subSql))
			}
		}

		if len(brainDims) > 0 {
			var startDate, endDate string
			if isCompare {
				startDate = baseStruct.CompareStartDate
				endDate = baseStruct.CompareEndDate
			} else {
				startDate = baseStruct.StartDate
				endDate = baseStruct.EndDate
			}
			brainCql, err := GetJoinTableSQL(ctx, brainDims, dimMap, startDate, endDate, ApiBrainTableName)
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("prod_id", sql_parse.IN, brainCql)
		}
		if len(OncePoolDims) > 0 {
			onceCql, err := GetOncePoolCQL(ctx, bizMetaInfo, OncePoolDims)
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("prod_id", sql_parse.IN, onceCql)
		}
		if len(pushPoolDims) > 0 { // push商品维度处理
			startDate := utils.If(isCompare, baseStruct.CompareStartDate, baseStruct.StartDate)
			endDate := utils.If(isCompare, baseStruct.CompareEndDate, baseStruct.EndDate)
			pushCql, err := GetPushPoolCQL(ctx, pushPoolDims, dimMap, dateExpr, startDate, endDate)
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("prod_id", sql_parse.IN, pushCql)
		}
		if supplyChangeDim != nil {
			supplyCql, err := GetSupplySkuPoolCQL(ctx, supplyChangeDim, baseStruct.StartDate, baseStruct.EndDate, baseStruct.CompareStartDate, baseStruct.CompareEndDate)
			if err != nil {
				return nil, nil, nil, err
			}
			cql.AddSubQueryWhere("sku_id", sql_parse.IN, supplyCql)
		}
		if marketProjectDim != nil {
			table := DynamicDimensionProdRelationTableName
			if slices.Contains(consts.NewClusterBizTypeList, bizMetaInfo.BizType) {
				table = DynamicDimensionProdRelationTableBucket
			}
			marketProjectCql := sql_parse.NewCQL()
			marketProjectCql.Select("prod_id as prod_id,date as date").
				From(utils.AddTableNameAlias(table, "market_project"))
			entityIds := make([]string, 0)
			for _, selectItem := range marketProjectDim.SelectedValues {
				entityIds = append(entityIds, selectItem.Code)
			}
			var startDate, endDate string
			if isCompare {
				startDate = baseStruct.CompareStartDate
				endDate = baseStruct.CompareEndDate
			} else {
				startDate = baseStruct.StartDate
				endDate = baseStruct.EndDate
			}
			marketProjectCql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate).
				AddWhere("entity_id", sql_parse.IN, entityIds).
				AddWhere("dimension_type", sql_parse.EQUAL, consts.DynamicDimensionProdRelationPartitionMarketProject).
				AddClickHouseSettings("distributed_product_mode = 'local',distributed_perfect_shard=1")
			cql.AddSubQueryWhere("(prod_id,date)", sql_parse.IN, marketProjectCql)
		}
		if len(marketActivityDims) > 0 {
			marketActivityCql := sql_parse.NewCQL()
			marketActivityCql.Select("prod_id as prod_id,date as date").From(utils.AddTableNameAlias(MarketActivityTempTableName, "market_activity_table"))
			exprCql, err := GetDimCondition(ctx, marketActivityDims, dimMap, dateExpr)
			if err != nil {
				return nil, nil, nil, err
			}
			marketActivityCql.AddWhereAndValue(exprCql.WhereClause, dateExpr).AddRawWhereAndValue(exprCql.RawWhereClause...)
			cql.AddSubQueryWhere("(prod_id,date)", sql_parse.IN, marketActivityCql)
		}

		if algorithmFeatureSignDim != nil {
			exprCql := sql_parse.NewCQL()
			// 算法特征圈选 使用 每个商品的算法特征标识和目标算法特征标识值做 位与操作 结果大于0 表示包含
			if len(algorithmFeatureSignDim.SelectedValues) > 0 && algorithmFeatureSignDim.SelectedValues[0].ExtraInfo == "equal" {
				exprCql = exprCql.AddRawWhere(fmt.Sprintf(" and bitAnd(%s, %s) = %s", algorithmFeatureSignDim.Name, algorithmFeatureSignDim.SelectedValues[0].Code, algorithmFeatureSignDim.SelectedValues[0].Code))
			} else if len(algorithmFeatureSignDim.SelectedValues) > 0 && algorithmFeatureSignDim.SelectedValues[0].ExtraInfo == "exist" {
				exprCql = exprCql.AddRawWhere(fmt.Sprintf(" and bitAnd(%s, %s) > 0", algorithmFeatureSignDim.Name, algorithmFeatureSignDim.SelectedValues[0].Code))
			}

			cql.AddRawWhereAndValue(exprCql.RawWhereClause...).AddWhereAndValue(exprCql.WhereClause)
		}
	}
	logs.CtxInfo(ctx, "cql %s, %s", cql, baseExprCql)
	return cql, baseExprCql, lastVCql, nil
}

func TransValue(ctx context.Context, dataType string, v ...string) (outV interface{}, err error) {
	if len(v) == 0 {
		logs.CtxError(ctx, "[TransValue]无有效枚举值，v=%s", convert.ToJSONString(v))
		return nil, errors.New("无有效枚举值")
	}

	switch sql_parse.ValueType(dataType) {
	case sql_parse.DOUBLE:
		var floatV []float64
		for _, subV := range v {
			f, errF := convert.ToFloat64E(subV)
			if errF == nil {
				floatV = append(floatV, f)
			}
		}
		if len(floatV) == 0 {
			logs.CtxError(ctx, "[TransValue]floatV 无有效枚举值，v=%s", convert.ToJSONString(v))
			return nil, errors.New("无有效枚举值")
		}

		if len(floatV) == 1 {
			return floatV[0], nil
		} else {
			return floatV, nil
		}
	case sql_parse.LONG:
		var intV []int64
		for _, subV := range v {
			i, errI := convert.ToInt64E(subV)
			if errI == nil {
				intV = append(intV, i)
			}
		}
		if len(intV) == 0 {
			logs.CtxError(ctx, "[TransValue]intV 无有效枚举值，v=%s", convert.ToJSONString(v))
			return nil, errors.New("无有效枚举值")
		}
		if len(intV) == 1 {
			return intV[0], nil
		} else {
			return intV, nil
		}
	default:
		logs.CtxInfo(ctx, "[TransValue]string类型，v=%s", convert.ToJSONString(v))
	}

	if len(v) == 1 {
		return v[0], nil
	}

	return v, nil
}

func TransOperator(op base.OperatorType) sql_parse.ArithmeticOperatorEnum {
	switch op {
	case base.OperatorType_IN:
		return sql_parse.IN
	case base.OperatorType_NOT_IN:
		return sql_parse.NOT_IN
	case base.OperatorType_GREATER_EQUAL_THAN:
		return sql_parse.GREATER_EQUAL_THAN
	case base.OperatorType_LESS_EQUAL_THAN:
		return sql_parse.LESS_EQUAL_THAN
	case base.OperatorType_GREATER_THAN:
		return sql_parse.GREATER_THAN
	case base.OperatorType_LESS_THAN:
		return sql_parse.LESS_THAN
	}

	return sql_parse.IN
}

// UpdateTargetDisplayName 更新指标展示名称
func UpdateTargetDisplayName(target *analysis.TargetCardEntity, transName *biz_info.TransDisplayName) *analysis.TargetCardEntity {
	if target == nil || transName == nil {
		return target
	}

	if len(transName.RenameMap) > 0 {
		if newName, exist := transName.RenameMap[target.DisplayName]; exist {
			target.DisplayName = newName
		}
	}

	if len(transName.RemoveNames) > 0 && slices.ContainsString(transName.RemoveNames, target.Name) {
		return nil
	}

	return target
}

// NeedAggregateProdId 是否需要先根据prod_id聚合（目前只有卡指标阈值<TopN,累计贡献，具体阈值>才需要先聚合到prod_id）
func NeedAggregateProdId(baseStruct *dimensions.ProductAnalysisBaseStruct) bool {
	if baseStruct == nil {
		return false
	}
	if len(baseStruct.ThresholdAttrs) == 0 && len(baseStruct.Dimensions) == 0 {
		return true
	}
	//var flag = true
	//for _, threshold := range baseStruct.ThresholdAttrs {
	//	if threshold.AccThreshold != nil || threshold.TopN != nil {
	//		flag = false
	//		break
	//	}
	//}
	return false
}
func GetDimKeyMaxLen(dimKey string) int {
	dimArr := strings.Split(dimKey, "###")
	maxLen := len(dimArr) - 1
	for i, d := range dimArr {
		if len(d) == 0 {
			maxLen = i - 1
			break
		}
	}
	return maxLen
}
func GetDimKeyParent(dimKey string) string {
	dimArr := strings.Split(dimKey, "###")
	out := make([]string, 0)
	maxLen := GetDimKeyMaxLen(dimKey)
	for i, d := range dimArr {
		if i < maxLen {
			out = append(out, d)
		} else {
			out = append(out, consts.Empty)
		}
	}
	return strings.Join(out, "###")
}

func GenerateDimKey(cols []string, prefix string) string {
	if len(cols) == 0 {
		return "'' as dim_key"
	}
	return utils.If(len(cols) == 1,
		fmt.Sprintf("%s%s as dim_key", prefix, cols[0]),
		fmt.Sprintf("concat(%s) as dim_key", strings.Join(AppendPrefix(cols, prefix), ",'###',")))
}

func GenerateDimKeyJoinOn(cols []string) string {
	retArr := make([]string, 0)
	cols = slices.DistinctString(cols)
	for _, col := range cols {
		retArr = append(retArr, fmt.Sprintf(" t1.%s = t2.%s ", col, col))
	}
	return strings.Join(retArr, " and ")
}

func GenerateCastString(cols []string, prefix string) []string {
	ret := make([]string, 0)
	for _, c := range cols {
		ret = append(ret, fmt.Sprintf("if(length(cast(%s as String)) > 0, cast(%s as String), '未知空数据') as %s%s", c, c, prefix, c))
	}
	return ret
}

func AppendPrefixSelf(cols []string, prefix string) []string {
	ret := make([]string, 0)
	for _, c := range cols {
		ret = append(ret, fmt.Sprintf("%s%s as %s", prefix, c, c))
	}
	return ret
}

func AppendPrefix(cols []string, prefix string) []string {
	ret := make([]string, 0)
	for _, c := range cols {
		ret = append(ret, prefix+c)
	}
	return ret
}

func GetTrendDateExpr(ctx context.Context, startDay, endDay string) (dateExpr1, dateExpr2, dateExpr3, dateExpr4 *sql_parse.Expression, err error) {
	startTime, err := time.Parse(consts.Fmt_Date, startDay)
	if err != nil {
		logs.CtxError(ctx, "[TransformCqlAppendDateExpr]time.Parse startDay = %s Err: %v", startDay, err)
		return nil, nil, nil, nil, err
	}
	endTime, err := time.Parse(consts.Fmt_Date, endDay)
	if err != nil {
		logs.CtxError(ctx, "[TransformCqlAppendDateExpr]time.Parse endDay = %s Err: %v", endDay, err)
		return nil, nil, nil, nil, err
	}

	dates := time_utils.GetTrendDateByPointNum(startTime.Unix(), endTime.Unix(), 7)
	var subDates1, subDates2 = make([]string, 0), make([]string, 0)
	if len(dates) > 4 {
		subDates1 = append(subDates1, dates[:len(dates)/2]...)
		subDates2 = append(subDates2, dates[len(dates)/2:]...)
		cql1 := sql_parse.NewCQL().AddWhere("date", sql_parse.IN, subDates1).AddWhere("days_type", sql_parse.EQUAL, "1d")
		cql2 := sql_parse.NewCQL().AddWhere("date", sql_parse.IN, subDates2).AddWhere("days_type", sql_parse.EQUAL, "1d")
		cql3 := sql_parse.NewCQL().AddWhere("date", sql_parse.IN, subDates1)
		cql4 := sql_parse.NewCQL().AddWhere("date", sql_parse.IN, subDates2)
		return cql1.WhereClause, cql2.WhereClause, cql3.WhereClause, cql4.WhereClause, nil
	} else {
		cql1 := sql_parse.NewCQL().AddWhere("date", sql_parse.IN, dates).AddWhere("days_type", sql_parse.EQUAL, "1d")
		cql3 := sql_parse.NewCQL().AddWhere("date", sql_parse.IN, dates)
		return cql1.WhereClause, nil, cql3.WhereClause, nil, nil
	}
}

func GetDateExprWithoutDash(ctx context.Context, startTimeStr, endTimeStr string) (dataExpr, dateExpr2 *sql_parse.Expression, err error) {
	startTime, err := time.Parse(consts.Fmt_date, startTimeStr)
	if err != nil {
		logs.CtxError(ctx, "[TransformCqlAppendDateExpr]time.Parse startDay = %s Err: %v", startTimeStr, err)
		return nil, nil, err
	}
	endTime, err := time.Parse(consts.Fmt_date, endTimeStr)
	if err != nil {
		logs.CtxError(ctx, "[TransformCqlAppendDateExpr]time.Parse endDay = %s Err: %v", endTimeStr, err)
		return nil, nil, err
	}
	return GetDateExprFromTime(ctx, startTime, endTime)
}

func GetDateExpr(ctx context.Context, startDay, endDay string) (dataExpr, dateExpr2 *sql_parse.Expression, err error) {
	startTime, err := time.Parse(consts.Fmt_Date, startDay)
	if err != nil {
		logs.CtxError(ctx, "[TransformCqlAppendDateExpr]time.Parse startDay = %s Err: %v", startDay, err)
		return nil, nil, err
	}
	endTime, err := time.Parse(consts.Fmt_Date, endDay)
	if err != nil {
		logs.CtxError(ctx, "[TransformCqlAppendDateExpr]time.Parse endDay = %s Err: %v", endDay, err)
		return nil, nil, err
	}

	return GetDateExprFromTime(ctx, startTime, endTime)
}

func GetDateExprFromTime(ctx context.Context, startTime, endTime time.Time) (dataExpr, dateExpr2 *sql_parse.Expression, err error) {
	// 开始进行时间函数解析
	var dateTypeSplitMap map[consts.DateType][]*time_utils.DateSplitResult
	if daysType, ok := ctx.Value(consts.CtxProdPoolTag).(consts.DateType); ok {
		dateTypeSplitMap = time_utils.GetCustomTimeSplit(startTime.Unix(), endTime.Unix(), []consts.DateType{daysType})
	} else {
		dateTypeSplitMap = time_utils.GetCustomTimeSplit(startTime.Unix(), endTime.Unix(), biz_info.GetCtxBizInfoDaysTypeList(ctx))
	}

	dataExpr = &sql_parse.Expression{
		Logic:    sql_parse.OR,
		Children: make([]*sql_parse.Expression, 0),
	}
	dateExpr2 = &sql_parse.Expression{
		Logic:    sql_parse.OR,
		Children: make([]*sql_parse.Expression, 0),
	}
	for dateType, splitVList := range dateTypeSplitMap {
		if len(splitVList) == 0 {
			continue
		}

		dates := make([]string, 0)
		for _, v := range splitVList {
			dates = append(dates, v.EndDate)
		}
		tmp := sql_parse.NewCQL()
		tmp2 := sql_parse.NewCQL()
		tmp.AddWhere("date", sql_parse.IN, dates).AddWhere("days_type", sql_parse.EQUAL, string(dateType))
		tmp2.AddWhere("date", sql_parse.IN, dates)
		dataExpr.Children = append(dataExpr.Children, tmp.WhereClause)
		dateExpr2.Children = append(dateExpr2.Children, tmp2.WhereClause)
	}

	return dataExpr, dateExpr2, nil
}

func GetAlertDataExpr(tableName string) (dataExpr *sql_parse.Expression, err error) {
	dataExpr = &sql_parse.Expression{
		Logic:    sql_parse.OR,
		Children: make([]*sql_parse.Expression, 0),
	}

	dateType := "1d"
	tmp := sql_parse.NewCQL()
	tmp.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, fmt.Sprintf("${%s.start_date}", tableName)).AddWhere("date", sql_parse.LESS_EQUAL_THAN, fmt.Sprintf("${%s.end_date}", tableName)).AddWhere("days_type", sql_parse.EQUAL, string(dateType))
	dataExpr.Children = append(dataExpr.Children, tmp.WhereClause)
	return dataExpr, nil
}

func TransformCqlAppendDateExpr(ctx context.Context, cql *sql_parse.CQL, startDay, endDay string) (outCql *sql_parse.CQL, err error) {
	dataExpr, _, err := GetDateExpr(ctx, startDay, endDay)
	if err != nil {
		return nil, err
	}
	cql.AddWhereAndValue(dataExpr)
	return cql, nil
}

func GetBaseReqWithoutGroupAttrs(source *dimensions.ProductAnalysisBaseStruct) *dimensions.ProductAnalysisBaseStruct {
	newBaseStruct := &dimensions.ProductAnalysisBaseStruct{}
	if source == nil {
		return newBaseStruct
	}
	copier.CopyWithOption(newBaseStruct, *source, copier.Option{DeepCopy: true})
	if newBaseStruct != nil {
		newBaseStruct.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		for _, d := range source.Dimensions {
			if !d.IsGroup {
				newBaseStruct.Dimensions = append(newBaseStruct.Dimensions, d)
			}
		}
	}
	return newBaseStruct
}

// GetProductPoolExpr 通过货盘ID，拉取货盘规则并翻译成sql
func GetProductPoolExpr(ctx context.Context, prodPoolDim *dimensions.SelectedDimensionInfo,
	baseStruct *dimensions.ProductAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo) ([]string, *sql_parse.CQL, error) {
	// 获取货盘信息
	analysisPoolDoList := make([]dao.AnalysisPoolDo, 0)
	tx := mysql.DB(ctx)
	if len(prodPoolDim.SelectedValues) == 0 {
		return nil, nil, nil
	}
	poolId := prodPoolDim.SelectedValues[0].Code
	// 查询货盘下所有商品id
	err := tx.Table("analysis_pool").Where("is_delete", 0).Where("pool_id = ?", poolId).Find(&analysisPoolDoList).Error
	if err != nil {
		return nil, nil, err
	}
	if len(analysisPoolDoList) == 0 {
		return nil, nil, errors.New("未查询到相关货盘")
	}
	customProductPool := analysisPoolDoList[0]
	// 手动录入货盘
	if customProductPool.PoolType == int64(analysis_pool.AnalysisPoolType_FixedProd) {
		analysisPoolProducts := make([]*dao.AnalysisPoolProductDo, 0)
		err = tx.Table("analysis_pool_product").Where("is_delete='0'").Where("pool_id = ?", customProductPool.PoolId).Find(&analysisPoolProducts).Error
		productIds := make([]string, 0)
		for _, analysisPoolProduct := range analysisPoolProducts {
			productIds = append(productIds, analysisPoolProduct.ProductId)
		}
		return productIds, nil, nil
	} else if customProductPool.PoolType == int64(analysis_pool.AnalysisPoolType_DynamicRule) || customProductPool.PoolType == int64(analysis_pool.AnalysisPoolType_AlgorithmFeature) {
		var poolRule *dimensions.ProductAnalysisBaseStruct
		err = json.Unmarshal([]byte(customProductPool.PoolRule), &poolRule)
		if err != nil {
			logs.CtxError(ctx, "[GetProductPoolExpr] json decode error:%v", err)
			return nil, nil, err
		}
		// 货盘类型是货品流量洞察多维分析规则
		dimensionsList := make([]*dimensions.SelectedDimensionInfo, 0)
		dimensionsList = append(dimensionsList, poolRule.Dimensions...)
		// 获取分析的维度信息
		var groupCol string
		enumCodeMap := make(map[string]string)
		for _, attr := range poolRule.GroupAttrs {
			if customProductPool.PoolType == int64(analysis_pool.AnalysisPoolType_AlgorithmFeature) {
				break
			}
			// 获取维度的查询字段名
			if attr.DimInfo == nil {
				logs.CtxError(ctx, "未查询到维度信息,DimInfo为空")
				return nil, nil, errors.New("未查询到维度信息,DimInfo为空")
			}
			dimInfo := dimMap[convert.ToInt64(attr.DimInfo.Id)]
			if dimInfo == nil {
				logs.CtxError(ctx, "未查询到维度信息")
				return nil, nil, errors.New("未查询到维度信息")
			}
			// 查询该维度的枚举值
			if attr.DimInfo != nil && len(attr.DimInfo.SelectedValues) > 0 {
				for _, enum := range attr.DimInfo.SelectedValues {
					enumCodeMap[enum.Code] = enum.Name
				}
			}
			if attr.NeedDrillDown {
				dimensionsList = append(dimensionsList, &dimensions.SelectedDimensionInfo{
					Id:               attr.DimInfo.Id,
					Name:             attr.DimInfo.Name,
					AttrType:         attr.DimInfo.AttrType,
					SelectedOperator: attr.DimInfo.SelectedOperator,
					SelectedValues:   []*dimensions.EnumElement{attr.Value},
					IsGroup:          true,
				})
			} else {
				if len(groupCol) == 0 {
					groupCol = dimInfo.DimColumn
				}
				dimensionsList = append(dimensionsList, attr.DimInfo)
			}
		}
		poolBaseStruct := &dimensions.ProductAnalysisBaseStruct{
			BizType:    baseStruct.BizType,
			StartDate:  baseStruct.StartDate,
			EndDate:    baseStruct.EndDate,
			Dimensions: dimensionsList,
			GroupAttrs: poolRule.GroupAttrs,
		}
		poolCql, _, _, err := GetBaseConditionWithDims(ctx, poolBaseStruct, false, dimMap, false, false)
		if err != nil {
			return nil, nil, err
		}
		return nil, poolCql, nil
	}
	return nil, nil, nil
}

func GetPushPoolCQL(ctx context.Context, pushPoolDims []*dimensions.SelectedDimensionInfo, dimMap map[int64]*dao.DimensionInfo, dateExpr *sql_parse.Expression, startDate, endDate string) (*sql_parse.CQL, error) {
	// 特殊处理下push转化类型字段
	var pushConvertDim *dimensions.SelectedDimensionInfo
	pushDims := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, selectDim := range pushPoolDims {
		if selectDim.Id == consts.PushConvertType {
			pushConvertDim = selectDim
		} else {
			pushDims = append(pushDims, selectDim)
		}
	}
	pushProdCQL := sql_parse.NewCQL()
	pushProdCQL.Select("prod_id as prod_id").From(utils.AddTableNameAlias("viking_prod_pool", "ttt"))
	condis := make([]string, 0)
	if pushConvertDim != nil && len(pushConvertDim.SelectedValues) > 0 {
		for _, selected := range pushConvertDim.SelectedValues {
			if selected.Code == "0" { // 未转化
				condis = append(condis, "( is_direct_convert = 0 and is_indirect_convert = 0 )")
			} else if selected.Code == "1" { // 直接转化
				condis = append(condis, "(is_direct_convert = 1)")
			} else if selected.Code == "2" { // 间接转化
				condis = append(condis, "(is_indirect_convert = 1)")
			}
		}
		pushProdCQL.AddRawWhere("and ( " + strings.Join(condis, " or ") + ")")
	}
	if len(pushDims) == 0 {
		pushProdCQL.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).
			AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate).
			AddClickHouseSettings("distributed_product_mode = 'local',distributed_perfect_shard=1")
		return pushProdCQL, nil
	}
	cql, err := GetDimCondition(ctx, pushDims, dimMap, dateExpr)
	if err != nil {
		return nil, err
	}
	pushProdCQL.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).
		AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate).
		AddWhereAndValue(cql.WhereClause).
		AddRawWhereAndValue(cql.RawWhereClause...).
		AddClickHouseSettings("distributed_product_mode = 'local',distributed_perfect_shard=1")
	return pushProdCQL, nil
}

func GetSupplySkuPoolCQL(ctx context.Context, supplyChangeDim *dimensions.SelectedDimensionInfo, startDate, endDate, compareStartDate, compareEndDate string) (*sql_parse.CQL, error) {
	selectStr := "sku_id," +
		"count(distinct if(date BETWEEN '%s' and '%s',date,NULL)) as cur_online_day," +
		"count(distinct if(date BETWEEN '%s' and '%s',date,NULL)) as com_online_day," +
		"date_diff('day', toDate('%s'), toDate('%s'))+1 AS cur_day_cnt," +
		"date_diff('day', toDate('%s'), toDate('%s'))+1 AS com_day_cnt," +
		"if(cur_online_day=cur_day_cnt, 1, 0) AS cur_is_aways_online," +
		"if(com_online_day=com_day_cnt, 1, 0) AS com_is_aways_online"
	selectStr = fmt.Sprintf(selectStr, startDate, endDate, compareStartDate, compareEndDate, startDate, endDate, compareStartDate, compareEndDate)
	whereStr := "(date BETWEEN '%s' AND '%s'" +
		"       or  date BETWEEN '%s' AND '%s')" +
		"        AND     is_big_link_sku=1" +
		"        AND     is_online_sku=1"
	whereStr = fmt.Sprintf(whereStr, startDate, endDate, compareStartDate, compareEndDate)
	supplyCQL := sql_parse.NewCQL()
	tableName := ApiProdBigLinkAndSameClusterTableName
	conf, _ := tcc.GetBigLinkClusterSwitchConf(ctx)
	if conf != nil && conf.Switch {
		tableName = conf.NewLogicTableName
	}
	supplyCQL.Select(selectStr).From(utils.AddTableNameAlias(tableName, "ttt"))
	supplyCQL.AddRawWhere(whereStr)
	supplyCQL.GroupBy("sku_id")

	supplyCQL2 := sql_parse.NewCQL()
	supplyCQL2.Select("sku_id as sku_id").FromCql(supplyCQL)
	if supplyChangeDim.Id == consts.IsNewSupplyLink {
		supplyCQL2.AddRawWhere("cur_online_day > 0 and com_online_day = 0")
	} else if supplyChangeDim.Id == consts.IsOfflineSupplyLink {
		supplyCQL2.AddRawWhere("cur_online_day = 0 and com_online_day > 0")
	} else if supplyChangeDim.Id == consts.IsNoChangeSupplyLink {
		supplyCQL2.AddRawWhere("cur_is_aways_online = 1 and com_is_aways_online =1")
	}
	supplyCQL2.Compile()
	return supplyCQL2, nil
}

// GetPackageProdCql 统一动态维度，招商选品集、市集项目、招募策略、流量调控等
func GetPackageProdCql(ctx context.Context, bizType dimensions.BizType,
	packageProdDims []*dimensions.SelectedDimensionInfo, startDate, endDate string,
	dimMap map[int64]*dao.DimensionInfo, isRelatedByDay bool) (*sql_parse.CQL, error) {
	table := DynamicDimensionProdRelationTableName
	logicTableId := consts.DynamicDimensionProdRelationDfTable
	if slices.Contains(consts.NewClusterBizTypeList, bizType) {
		table = DynamicDimensionProdRelationTableBucket
		logicTableId = consts.DynamicDimensionProdRelationTableBucket
	}
	packageProdCql := sql_parse.NewCQL()
	selectStr := "prod_id as prod_id"
	if isRelatedByDay {
		selectStr = "prod_id as prod_id,date as date"
	}
	packageProdCql.Select(selectStr).
		From(utils.AddTableNameAlias(table, "packageProd_table"))
	//entityIds := make([]string, 0)
	partitionCodes := make([]string, 0)
	var partitionDim *dao.DimensionInfo                 // 分区维度
	notPartitionDimsMap := make(map[string][]string, 0) // 非分区维度
	for _, dimItem := range packageProdDims {
		if dimInfo, ok := dimMap[convert.ToInt64(dimItem.Id)]; ok {
			if consts.DynamicDimensionProdRelationPartitionMap[dimInfo.DimColumn] {
				partitionDim = dimInfo
				for _, selectItem := range dimItem.SelectedValues {
					partitionCodes = append(partitionCodes, selectItem.Code)
				}
			} else {
				notPartitionDimsMap[dimInfo.DimColumn] = make([]string, 0)
				for _, selectItem := range dimItem.SelectedValues {
					notPartitionDimsMap[dimInfo.DimColumn] = append(notPartitionDimsMap[dimInfo.DimColumn],
						selectItem.Code)
				}
			}

		}
	}
	newestDay, _ := utils.GetNewestDay(ctx, logicTableId)
	newestDateTime, _ := time.Parse(consts.Fmt_date, newestDay)
	newestDate := newestDateTime.Format(consts.Fmt_Date)
	if isRelatedByDay {
		packageProdCql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).
			AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate)
	} else {
		packageProdCql.AddWhere("date", sql_parse.EQUAL, newestDate)
	}
	// 处理非分区维度
	for dimColumn, dimCodes := range notPartitionDimsMap {
		if len(dimCodes) == 1 {
			packageProdCql.AddWhere(dimColumn, sql_parse.EQUAL, dimCodes[0])
		} else if len(dimCodes) > 1 {
			packageProdCql.AddWhere(dimColumn, sql_parse.IN, dimCodes)
		}
	}
	// 处理分区维度
	packageProdCql.AddWhere("entity_id", sql_parse.IN, partitionCodes).
		AddWhere("dimension_type", sql_parse.EQUAL, partitionDim.DimColumn).
		AddClickHouseSettings("distributed_product_mode = 'local',distributed_perfect_shard=1")
	return packageProdCql, nil
}

// GetPackageDynamicDimensionProdCql 统一动态维度，用户圈选、用户选品集、用户招募策略、用户流量调控等
func GetPackageDynamicDimensionProdCql(ctx context.Context, bizType dimensions.BizType,
	packageDynamicDim *dimensions.SelectedDimensionInfo, startDate, endDate string,
	dimMap map[int64]*dao.DimensionInfo, isRelatedByDay bool, partitionName string) (*sql_parse.CQL, error) {
	table := DynamicDimensionProdRelationTableBucket
	logicTableId := consts.DynamicDimensionProdRelationTableBucket
	if packageDynamicDim.Id == consts.PackageCrowdPackageDimId {
		table = DynamicDimensionUserRelationTableName
		logicTableId = consts.DynamicDimensionUserRelationTable
	}
	packageDynamicDimCql := sql_parse.NewCQL()
	selectStr := fmt.Sprintf("%s as %s", partitionName, partitionName)
	if isRelatedByDay {
		selectStr = fmt.Sprintf("%s as %s,date as date", partitionName, partitionName)
	}
	packageDynamicDimCql.Select(selectStr).
		From(utils.AddTableNameAlias(table, "package_dim_table"))
	//entityIds := make([]string, 0)
	partitionCodes := make([]string, 0)
	var partitionDim *dao.DimensionInfo                 // 分区维度
	notPartitionDimsMap := make(map[string][]string, 0) // 非分区维度
	dimItem := packageDynamicDim
	if dimInfo, ok := dimMap[convert.ToInt64(dimItem.Id)]; ok {
		if consts.PackageDynamicDimensionProdRelationPartitionMap[dimInfo.DimColumn] {
			partitionDim = dimInfo
			for _, selectItem := range dimItem.SelectedValues {
				partitionCodes = append(partitionCodes, selectItem.Code)
			}
		} else {
			notPartitionDimsMap[dimInfo.DimColumn] = make([]string, 0)
			for _, selectItem := range dimItem.SelectedValues {
				notPartitionDimsMap[dimInfo.DimColumn] = append(notPartitionDimsMap[dimInfo.DimColumn],
					selectItem.Code)
			}
		}

	}
	newestDay, _ := utils.GetNewestDay(ctx, logicTableId)
	newestDateTime, _ := time.Parse(consts.Fmt_date, newestDay)
	newestDate := newestDateTime.Format(consts.Fmt_Date)
	if isRelatedByDay {
		packageDynamicDimCql.AddWhere("date", sql_parse.EQUAL, newestDate)
	} else {
		packageDynamicDimCql.AddWhere("date", sql_parse.GREATER_EQUAL_THAN, startDate).
			AddWhere("date", sql_parse.LESS_EQUAL_THAN, endDate)
	}
	// 处理非分区维度
	for _, dimCodes := range notPartitionDimsMap {
		if len(dimCodes) == 1 {
			packageDynamicDimCql.AddWhere(partitionName, sql_parse.EQUAL, dimCodes[0])
		} else if len(dimCodes) > 1 {
			packageDynamicDimCql.AddWhere(partitionName, sql_parse.IN, dimCodes)
		}
	}
	// 处理分区维度
	if partitionDim != nil {
		packageDynamicDimCql.AddWhere("entity_id", sql_parse.IN, partitionCodes).
			AddWhere("dimension_type", sql_parse.EQUAL, partitionDim.DimColumn)
	}
	if bizType != dimensions.BizType_MarketingEngine {
		packageDynamicDimCql.AddClickHouseSettings("distributed_product_mode = 'local',distributed_perfect_shard=1")
	}
	// 需要进一步缩小查询范围
	if packageDynamicDim.Id == consts.PackageCrowdPackageDimId {
		if bizType == dimensions.BizType_MarketingEngine {
			userFilter := fmt.Sprintf(" and user_id in (select user_id from dm_prm_tool_coupon_order_for_insight_bucket_di where date>='%s' and date<='%s' )", startDate, endDate)
			packageDynamicDimCql.AddRawWhere(userFilter)
		}
	}
	return packageDynamicDimCql, nil
}
