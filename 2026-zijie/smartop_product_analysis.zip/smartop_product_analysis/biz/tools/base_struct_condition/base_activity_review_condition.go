package base_struct_condition

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"strings"
)

type BigPromotionReviewOsParamsReq struct {
	BaseStruct     *activity_review.BigPromotionReviewBaseStruct
	DimMap         map[int64]*dao.DimensionInfo
	DimColMap      map[string]*dao.DimensionInfo
	MultiDimension []string
	OrderBy        *base.OrderByInfo
	PageInfo       *base.PageInfo
	TrendPreFlag   *bool // 用来区分趋势图采样后大于7天时，取前半段还是后半段
}

const (
	Curr_Param    = 0b1
	Compare_Param = 0b10
	Overall_Param = 0b100
)

// GetBigPromotionReviewBaseStructConditionParams 通过基础结构抽象，获取查询的sql结构体 -
// 包含基础、对比周期、趋势图
// 入参：
// needParamType：int64 用来区分是否需要参数类型，二进制 0b1 curr 0b10 compare 0b100 overall
func GetBigPromotionReviewBaseStructConditionParams(ctx context.Context, req BigPromotionReviewOsParamsReq, needParamType int64) (curr, compare, overall map[string]interface{}, err error) {
	curr, compare, overall = make(map[string]interface{}), make(map[string]interface{}), make(map[string]interface{})
	if needParamType == 0 || needParamType&Curr_Param != 0 {
		curr, err = GetBigPromotionReviewBaseStructConditionParam(ctx, req, SQLCalcType_Curr)
		if err != nil {
			return
		}
	}
	if needParamType == 0 || needParamType&Compare_Param != 0 {
		compare, err = GetBigPromotionReviewBaseStructConditionParam(ctx, req, SQLCalcType_Compare)
		if err != nil {
			return
		}
	}
	if needParamType == 0 || needParamType&Overall_Param != 0 {
		overall, err = GetBigPromotionReviewBaseStructConditionParam(ctx, req, SQLCalcType_Overall)
		if err != nil {
			return
		}
	}
	return
}

func GetBigPromotionReviewBaseStructConditionParam(ctx context.Context, req BigPromotionReviewOsParamsReq, calcType SQLCalcType) (param map[string]interface{}, err error) {
	if req.BaseStruct == nil {
		return nil, errors.New("[GetBaseStructConditionParam]BaseStruct为空，请检查入参")
	}

	// 获取业务线元信息
	//bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseStruct.BizType)
	//if err != nil || bizInfo == nil {
	//	logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
	//	if err == nil {
	//		err = errors.New("业务线元信息读取失败，请检查TCC配置")
	//	}
	//	return
	//}
	param = make(map[string]interface{})
	param["biz_type"] = int64(req.BaseStruct.BizType)

	// 解析所选维度过滤信息 for 大盘
	supportedDimensions, err := GetSupportedDimensions(ctx, req.BaseStruct.Dimensions, dimensions.BizType_GrowthProductStrategy)
	if err != nil {
		return nil, err
	}
	exprCql, _, _, err := GetBaseConditionWithDims(ctx, &dimensions.ProductAnalysisBaseStruct{
		BizType:    req.BaseStruct.BizType,
		Dimensions: supportedDimensions,
	}, calcType == SQLCalcType_Curr, req.DimMap, false, false)
	if err != nil {
		return
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}
	if exprCql != nil && exprCql.WhereClause != nil {
		whereStr := sql_parse.NewCQL().ParseExpression(exprCql.WhereClause)
		if len(exprCql.RawWhereClause) > 0 {
			whereStr = whereStr + " " + sql_parse.NewCQL().ParseRawExpression(exprCql.RawWhereClause)
		}
		if len(whereStr) > 0 {
			param["filter_param"] = whereStr
		}
	}

	// 解析所选维度过滤信息 for 供给
	supportedDimensions, err = GetSupportedDimensions(ctx, req.BaseStruct.Dimensions, dimensions.BizType_BigPromotionSupply)
	if err != nil {
		return nil, err
	}
	switch calcType {
	case SQLCalcType_Curr:
		param["main_project_id"] = req.BaseStruct.MainProjectId
		//supportedDimensions = appendSupplyDimensions(consts.MainProjectId, []string{req.BaseStruct.MainProjectId}, supportedDimensions)
		if len(req.BaseStruct.MainActivityId) > 0 {
			supportedDimensions = appendSupplyDimensions(consts.MainActivityId, []string{req.BaseStruct.MainActivityId}, supportedDimensions)
		}
		supportedDimensions = appendSupplyDimensions(consts.ActivityId, req.BaseStruct.ActivityId, supportedDimensions)
		supportedDimensions = appendSupplyDimensions(consts.PickPlanIdList, req.BaseStruct.PickPlanIdList, supportedDimensions)
	case SQLCalcType_Compare:
		param["main_project_id"] = req.BaseStruct.CompareMainProjectId
		//supportedDimensions = appendSupplyDimensions(consts.MainProjectId, []string{req.BaseStruct.CompareMainProjectId}, supportedDimensions)
		if len(req.BaseStruct.CompareMainActivityId) > 0 {
			supportedDimensions = appendSupplyDimensions(consts.MainActivityId, []string{req.BaseStruct.CompareMainActivityId}, supportedDimensions)
		}
		supportedDimensions = appendSupplyDimensions(consts.ActivityId, req.BaseStruct.CompareActivityId, supportedDimensions)
		supportedDimensions = appendSupplyDimensions(consts.PickPlanIdList, req.BaseStruct.ComparePickPlanIdList, supportedDimensions)
	default:
	}
	// 筛选供给商品信息
	supplyExprCql, _, _, err := GetBaseConditionWithDims(ctx, &dimensions.ProductAnalysisBaseStruct{
		BizType:    req.BaseStruct.BizType,
		Dimensions: supportedDimensions,
	}, calcType == SQLCalcType_Curr, req.DimMap, false, false)
	if err != nil {
		return
	}
	if supplyExprCql == nil {
		supplyExprCql = sql_parse.NewCQL()
	}
	if supplyExprCql != nil && supplyExprCql.WhereClause != nil {
		whereStr := supplyExprCql.ParseAllWhereExpression()
		if len(whereStr) > 0 {
			param["supply_filter_param"] = whereStr
		}
	}

	if len(req.MultiDimension) > 0 {
		_, supportDimColMap, err := biz_utils.GetDimMapAndColMapByBiz(ctx, dimensions.BizType_BigPromotionSupply)
		if err != nil {
			return nil, err
		}
		joinCql := sql_parse.NewCQL()
		subSelect := make([]string, 0)
		supplySubSelect := make([]string, 0)
		supplyDimensions := make([]string, 0)
		supplyJoinCql := sql_parse.NewCQL()
		andConnector, supplyAndConnector := "", ""
		for _, col := range req.MultiDimension {
			str := ""
			if dimInfo, exist := req.DimColMap[col]; exist && len(dimInfo.DimExpr) > 0 {
				str = fmt.Sprintf("cast(%s as String) as %s", dimInfo.DimExpr, col)
			} else {
				str = fmt.Sprintf("cast(%s as String) as %s", col, col)
			}
			subSelect = append(subSelect, str)
			joinCql.AddRawWhere(fmt.Sprintf("%s a.%s=b.%s", andConnector, col, col))
			andConnector = "and"
			if _, supportExist := supportDimColMap[col]; supportExist {
				supplySubSelect = append(supplySubSelect, str)
				supplyDimensions = append(supplyDimensions, col)
				supplyJoinCql.AddRawWhere(fmt.Sprintf("%s a.%s=b.%s", supplyAndConnector, col, col))
				supplyAndConnector = "and"
			}
		}
		// 避免ambiguous错误，增加alias
		multiDimWithAlias := make([]string, 0)
		exportDims := make([]string, 0)
		for _, dim := range req.MultiDimension {
			multiDimWithAlias = append(multiDimWithAlias, "a."+dim)
			exportDims = append(exportDims, "a."+dim+" as "+dim)
		}
		param["export_select"] = strings.Join(append(exportDims, GenerateDimKey(multiDimWithAlias, "")), ",")
		param["sub_select"] = strings.Join(subSelect, ",")
		param["dimension"] = strings.Join(req.MultiDimension, ",")
		param["join_param"] = sql_parse.NewCQL().ParseRawExpression(joinCql.RawWhereClause)
		if len(supplyDimensions) > 0 {
			param["supply_sub_select"] = strings.Join(supplySubSelect, ",")
			param["supply_dimension"] = strings.Join(supplyDimensions, ",")
			param["supply_join_param"] = sql_parse.NewCQL().ParseRawExpression(supplyJoinCql.RawWhereClause)
		}
	}
	return
}

// GetSupportedDimensions 根据biz获取业务支持的维度
func GetSupportedDimensions(ctx context.Context, dims []*dimensions.SelectedDimensionInfo, bizType dimensions.BizType) ([]*dimensions.SelectedDimensionInfo, error) {
	dimMap, _, err := biz_utils.GetDimMapAndColMapByBiz(ctx, bizType)
	if err != nil {
		return nil, err
	}

	supports := make([]*dimensions.SelectedDimensionInfo, 0)
	for _, dim := range dims {
		_, ok := dimMap[convert.ToInt64(dim.Id)]
		if ok {
			supports = append(supports, dim)
		}
	}
	return supports, nil
}

func appendSupplyDimensions(dimId string, selectedValues []string, dims []*dimensions.SelectedDimensionInfo) []*dimensions.SelectedDimensionInfo {
	if selectedValues == nil || len(selectedValues) == 0 {
		return dims
	}
	enums := make([]*dimensions.EnumElement, 0)
	for _, item := range selectedValues {
		enums = append(enums, &dimensions.EnumElement{
			Code: item,
			Name: item,
		})
	}

	dims = append(dims, &dimensions.SelectedDimensionInfo{
		Id:               dimId,
		Name:             "",
		AttrType:         dimensions.DimensionAttributeType_Product,
		SelectedOperator: base.OperatorType_IN,
		SelectedValues:   enums,
	})
	return dims
}
