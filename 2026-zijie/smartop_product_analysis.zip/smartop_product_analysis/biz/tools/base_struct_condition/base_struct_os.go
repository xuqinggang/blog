package base_struct_condition

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/inf/infsecc"
	"code.byted.org/overpass/common/option/calloption"
	"code.byted.org/overpass/dp_invoker_engine/kitex_gen/dp/invoker/engine"
	"code.byted.org/overpass/dp_invoker_engine/rpc/dp_invoker_engine"
	"code.byted.org/temai/go_lib/convert"
)

type KeyColsTargetEntity struct {
	KeyColValues []interface{}
	TargetEntity []*analysis.TargetCardEntity
	Extra        map[string]any
}

func GetMapKeyColsString(input []interface{}) string {
	dimKey := make([]string, 0)
	for _, k := range input {
		dimKey = append(dimKey, convert.ToString(k))
	}
	return strings.Join(dimKey, "###")
}

func GetTargetCycleRatioListWithKeyColumn(curr, compare, cycle, sync []*KeyColsTargetEntity) []*KeyColsTargetEntity {
	if len(compare) > 0 {
		if len(cycle) == 0 {
			curr = GetTargetCycleRatioListWithKeyColumnByType(curr, compare, CompareTypeCycle)
		} else {
			curr = GetTargetCycleRatioListWithKeyColumnByType(curr, compare, CompareTypeCompare)
		}
	}
	if len(cycle) > 0 {
		curr = GetTargetCycleRatioListWithKeyColumnByType(curr, cycle, CompareTypeCycle)
	}
	if len(sync) > 0 {
		curr = GetTargetCycleRatioListWithKeyColumnByType(curr, sync, CompareTypeSync)
	}
	return curr
}

func GetTargetCycleRatioListWithKeyColumnV2(curr, compare, cycle, sync []*KeyColsTargetEntity) []*KeyColsTargetEntity {
	if len(compare) > 0 {
		curr = GetTargetCycleRatioListWithKeyColumnByType(curr, compare, CompareTypeCompare)
	}
	if len(cycle) > 0 {
		curr = GetTargetCycleRatioListWithKeyColumnByType(curr, cycle, CompareTypeCycle)
	}
	if len(sync) > 0 {
		curr = GetTargetCycleRatioListWithKeyColumnByType(curr, sync, CompareTypeSync)
	}
	return curr
}

type CompareType int64

const (
	CompareTypeCycle   CompareType = 1
	CompareTypeCompare             = 2
	CompareTypeSync                = 3
)

func GetTargetCycleRatioListWithKeyColumnByTypeMagic(curr, compare []*KeyColsTargetEntity, timeType CompareType) []*KeyColsTargetEntity {
	compareMap := make(map[string]map[string]*analysis.TargetCardEntity)
	// 计算整体的下降数值，用于计算贡献度
	wholeDiffMap := make(map[string]float64)
	for _, dimT := range compare {
		if len(dimT.TargetEntity) > 0 {
			compareTargetMap := make(map[string]*analysis.TargetCardEntity)
			for _, t := range dimT.TargetEntity {
				compareTargetMap[t.Name] = t
			}
			dimKey := make([]string, 0)
			for _, k := range dimT.KeyColValues {
				dimKey = append(dimKey, convert.ToString(k))
			}
			compareMap[GetMapKeyColsString(dimT.KeyColValues)] = compareTargetMap
		}
	}
	for _, dimT := range curr {
		if compareTargetMap, existT := compareMap[GetMapKeyColsString(dimT.KeyColValues)]; existT && len(dimT.TargetEntity) > 0 {
			for _, t := range dimT.TargetEntity {
				if compareInfo, existCompare := compareTargetMap[t.Name]; existCompare && compareInfo != nil {
					// 累加总diff
					if _, ok := wholeDiffMap[t.Name]; !ok {
						wholeDiffMap[t.Name] = 0
					}
					if timeType == CompareTypeCycle {
						t.CycleValue = compareInfo.Value
						t.CycleChangeRatio = t.Value - compareInfo.Value
						t.DiffExtra = &analysis.DiffExtraInfo{
							Diff:         t.Value - compareInfo.Value,
							DisplayValue: framework_udf.GetBriefMetricDisplayValueNoErr(t.Value-compareInfo.Value, t.ValueType, t.Unit, int(t.TargetPrecision)),
						}
						wholeDiffMap[t.Name] = wholeDiffMap[t.Name] + t.Value - compareInfo.Value
						t.CycleDisplayValue = compareInfo.DisplayValue
						if compareInfo.Value == 0 {
							t.CycleChangeRatio = consts.MagicNumber
						} else {
							t.CycleChangeRatio = t.CycleChangeRatio / compareInfo.Value
						}
					} else if timeType == CompareTypeSync {
						if t.ComparePeriodData == nil {
							t.ComparePeriodData = &analysis.ComparePeriodData{}
						}
						t.ComparePeriodData.SyncValue = compareInfo.Value
						t.ComparePeriodData.SyncDisplayValue = compareInfo.DisplayValue
						t.ComparePeriodData.SyncDiff = t.Value - compareInfo.Value
						t.ComparePeriodData.SyncDiffDisplayValue = framework_udf.GetBriefMetricDisplayValueNoErr(t.Value-compareInfo.Value, t.ValueType, t.Unit, int(t.TargetPrecision))
						wholeDiffMap[t.Name] = wholeDiffMap[t.Name] + t.Value - compareInfo.Value
						if compareInfo.Value == 0 {
							t.ComparePeriodData.SyncChangeRatio = consts.MagicNumber
						} else {
							t.ComparePeriodData.SyncChangeRatio = t.ComparePeriodData.SyncDiff / compareInfo.Value
						}
					} else if timeType == CompareTypeCompare {
						if t.ComparePeriodData == nil {
							t.ComparePeriodData = &analysis.ComparePeriodData{}
						}
						t.ComparePeriodData.CompareValue = compareInfo.Value
						t.ComparePeriodData.CompareDisplayValue = compareInfo.DisplayValue
						t.ComparePeriodData.CompareDiff = t.Value - compareInfo.Value
						t.ComparePeriodData.CompareDiffDisplayValue = framework_udf.GetBriefMetricDisplayValueNoErr(t.Value-compareInfo.Value, t.ValueType, t.Unit, int(t.TargetPrecision))
						wholeDiffMap[t.Name] = wholeDiffMap[t.Name] + t.Value - compareInfo.Value
						t.ComparePeriodData.IsShowCompare = true
						if compareInfo.Value == 0 {
							t.ComparePeriodData.CompareChangeRatio = consts.MagicNumber
						} else {
							t.ComparePeriodData.CompareChangeRatio = t.ComparePeriodData.CompareDiff / compareInfo.Value
						}
					}
				}
			}
		}
	}
	// 遍历指标卡，加工贡献度
	for _, dimT := range curr {
		for _, entity := range dimT.TargetEntity {
			if _, ok := wholeDiffMap[entity.Name]; ok {
				if timeType == CompareTypeCycle {
					if entity.DiffExtra == nil {
						entity.DiffExtra = &analysis.DiffExtraInfo{}
					}
					if wholeDiffMap[entity.Name] != 0 {
						entity.DiffExtra.DiffContribution = entity.DiffExtra.Diff / wholeDiffMap[entity.Name]
					} else {
						entity.DiffExtra.DiffContribution = consts.MagicNumber
					}
				} else if timeType == CompareTypeCompare {
					if entity.ComparePeriodData == nil {
						entity.ComparePeriodData = &analysis.ComparePeriodData{}
						entity.ComparePeriodData.CompareValue = 0
						entity.ComparePeriodData.CompareDisplayValue = "0"
						entity.ComparePeriodData.SyncDisplayValue = "0"
						entity.ComparePeriodData.SyncValue = 0
						entity.ComparePeriodData.CompareChangeRatio = consts.MagicNumber
						entity.ComparePeriodData.SyncChangeRatio = consts.MagicNumber
					}
					if wholeDiffMap[entity.Name] != 0 {
						entity.ComparePeriodData.CompareContribution = entity.ComparePeriodData.CompareDiff / wholeDiffMap[entity.Name]
					} else {
						entity.ComparePeriodData.CompareContribution = consts.MagicNumber
					}
				} else if timeType == CompareTypeSync {
					if entity.ComparePeriodData == nil {
						entity.ComparePeriodData = &analysis.ComparePeriodData{}
						entity.ComparePeriodData.CompareValue = 0
						entity.ComparePeriodData.CompareDisplayValue = "0"
						entity.ComparePeriodData.SyncDisplayValue = "0"
						entity.ComparePeriodData.SyncValue = 0
						entity.ComparePeriodData.CompareChangeRatio = consts.MagicNumber
						entity.ComparePeriodData.SyncChangeRatio = consts.MagicNumber
					}
					if wholeDiffMap[entity.Name] != 0 {
						entity.ComparePeriodData.SyncContribution = entity.ComparePeriodData.SyncDiff / wholeDiffMap[entity.Name]
					} else {
						entity.ComparePeriodData.SyncContribution = consts.MagicNumber
					}
				}
			}
		}
	}

	return curr
}

func GetTargetCycleRatioListWithKeyColumnByType(curr, compare []*KeyColsTargetEntity, timeType CompareType) []*KeyColsTargetEntity {
	compareMap := make(map[string]map[string]*analysis.TargetCardEntity)
	// 计算整体的下降数值，用于计算贡献度
	wholeDiffMap := make(map[string]float64)
	for _, dimT := range compare {
		if len(dimT.TargetEntity) > 0 {
			compareTargetMap := make(map[string]*analysis.TargetCardEntity)
			for _, t := range dimT.TargetEntity {
				compareTargetMap[t.Name] = t
			}
			dimKey := make([]string, 0)
			for _, k := range dimT.KeyColValues {
				dimKey = append(dimKey, convert.ToString(k))
			}
			compareMap[GetMapKeyColsString(dimT.KeyColValues)] = compareTargetMap
		}
	}
	for _, dimT := range curr {
		if compareTargetMap, existT := compareMap[GetMapKeyColsString(dimT.KeyColValues)]; existT && len(dimT.TargetEntity) > 0 {
			for _, t := range dimT.TargetEntity {
				if compareInfo, existCompare := compareTargetMap[t.Name]; existCompare && compareInfo != nil {
					// 累加总diff
					if _, ok := wholeDiffMap[t.Name]; !ok {
						wholeDiffMap[t.Name] = 0
					}
					if timeType == CompareTypeCycle {
						t.CycleValue = compareInfo.Value
						t.CycleChangeRatio = t.Value - compareInfo.Value
						t.DiffExtra = &analysis.DiffExtraInfo{
							Diff:         t.Value - compareInfo.Value,
							DisplayValue: framework_udf.GetBriefMetricDisplayValueNoErr(t.Value-compareInfo.Value, t.ValueType, t.Unit, int(t.TargetPrecision)),
						}
						wholeDiffMap[t.Name] = wholeDiffMap[t.Name] + t.Value - compareInfo.Value
						t.CycleDisplayValue = compareInfo.DisplayValue
						if !t.IsUsePp {
							if compareInfo.Value == 0 {
								t.CycleChangeRatio = consts.MagicNumber
							} else {
								t.CycleChangeRatio = t.CycleChangeRatio / compareInfo.Value
							}
						}
					} else if timeType == CompareTypeSync {
						if t.ComparePeriodData == nil {
							t.ComparePeriodData = &analysis.ComparePeriodData{}
						}
						t.ComparePeriodData.SyncValue = compareInfo.Value
						t.ComparePeriodData.SyncDisplayValue = compareInfo.DisplayValue
						t.ComparePeriodData.SyncDiff = t.Value - compareInfo.Value
						t.ComparePeriodData.SyncDiffDisplayValue = framework_udf.GetBriefMetricDisplayValueNoErr(t.Value-compareInfo.Value, t.ValueType, t.Unit, int(t.TargetPrecision))
						wholeDiffMap[t.Name] = wholeDiffMap[t.Name] + t.Value - compareInfo.Value
						if !t.IsUsePp {
							if compareInfo.Value == 0 {
								t.ComparePeriodData.SyncChangeRatio = consts.MagicNumber
							} else {
								t.ComparePeriodData.SyncChangeRatio = t.ComparePeriodData.SyncDiff / compareInfo.Value
							}
						}
					} else if timeType == CompareTypeCompare {
						if t.ComparePeriodData == nil {
							t.ComparePeriodData = &analysis.ComparePeriodData{}
						}
						t.ComparePeriodData.CompareValue = compareInfo.Value
						t.ComparePeriodData.CompareDisplayValue = compareInfo.DisplayValue
						t.ComparePeriodData.CompareDiff = t.Value - compareInfo.Value
						t.ComparePeriodData.CompareDiffDisplayValue = framework_udf.GetBriefMetricDisplayValueNoErr(t.Value-compareInfo.Value, t.ValueType, t.Unit, int(t.TargetPrecision))
						wholeDiffMap[t.Name] = wholeDiffMap[t.Name] + t.Value - compareInfo.Value
						t.ComparePeriodData.IsShowCompare = true
						if !t.IsUsePp {
							if compareInfo.Value == 0 {
								t.ComparePeriodData.CompareChangeRatio = consts.MagicNumber
							} else {
								t.ComparePeriodData.CompareChangeRatio = t.ComparePeriodData.CompareDiff / compareInfo.Value
							}
						}
					}
				}
			}
		}
	}
	// 遍历指标卡，加工贡献度
	for _, dimT := range curr {
		for _, entity := range dimT.TargetEntity {
			if _, ok := wholeDiffMap[entity.Name]; ok {
				if timeType == CompareTypeCycle {
					if entity.DiffExtra == nil {
						entity.DiffExtra = &analysis.DiffExtraInfo{}
					}
					if wholeDiffMap[entity.Name] != 0 {
						entity.DiffExtra.DiffContribution = entity.DiffExtra.Diff / wholeDiffMap[entity.Name]
					} else {
						entity.DiffExtra.DiffContribution = 0
					}
				} else if timeType == CompareTypeCompare {
					if entity.ComparePeriodData == nil {
						entity.ComparePeriodData = &analysis.ComparePeriodData{}
					}
					if wholeDiffMap[entity.Name] != 0 {
						entity.ComparePeriodData.CompareContribution = entity.ComparePeriodData.CompareDiff / wholeDiffMap[entity.Name]
					} else {
						entity.ComparePeriodData.CompareContribution = 0
					}
				} else if timeType == CompareTypeSync {
					if entity.ComparePeriodData == nil {
						entity.ComparePeriodData = &analysis.ComparePeriodData{}
					}
					if wholeDiffMap[entity.Name] != 0 {
						entity.ComparePeriodData.SyncContribution = entity.ComparePeriodData.SyncDiff / wholeDiffMap[entity.Name]
					} else {
						entity.ComparePeriodData.SyncContribution = 0
					}
				}
			}
		}
	}

	return curr
}

func GetTargetTrendPoint(ctx context.Context, value interface{}, targetMeta *dao.TargetMetaInfo, trendColValue string) (*analysis.TargetTrendPoint, error) {
	if targetMeta == nil {
		return nil, nil
	}
	displayV, err := framework_udf.GetBriefMetricDisplayValue(value, targetMeta.ValueType, targetMeta.ValueUnit, targetMeta.TargetPrecision)
	if err != nil {
		logs.CtxError(ctx, "GetBriefMetricDisplayValue Err = %v", err)
		return nil, err
	}
	dateStr, err := framework_udf.CustomDate(trendColValue)
	if err != nil {
		logs.CtxError(ctx, "GetTargetTrendPoint CustomDate err = %v", err)
	}
	return &analysis.TargetTrendPoint{
		Value:        convert.ToFloat64(value),
		DisplayValue: displayV,
		Name:         targetMeta.Name,
		DisplayName:  targetMeta.DisplayName,
		X:            dateStr,
		XValue:       trendColValue,
	}, nil
}

func GetTargetEntity(ctx context.Context, value interface{}, targetMeta *dao.TargetMetaInfo) (*analysis.TargetCardEntity, error) {
	if targetMeta == nil {
		return nil, nil
	}
	displayV, err := framework_udf.GetBriefMetricDisplayValue(value, targetMeta.ValueType, targetMeta.ValueUnit, targetMeta.TargetPrecision)
	if err != nil {
		logs.CtxError(ctx, "GetBriefMetricDisplayValue Err = %v", err)
		return nil, err
	}
	return &analysis.TargetCardEntity{
		Name:            targetMeta.Name,
		Value:           convert.ToFloat64(value),
		DisplayValue:    displayV,
		DisplayName:     targetMeta.DisplayName,
		Tips:            targetMeta.Tips,
		DisplayOrder:    int64(targetMeta.DisplayOrder),
		IsUsePp:         targetMeta.IsUsePP,
		Unit:            targetMeta.ValueUnit,
		ValueType:       targetMeta.ValueType,
		TargetPrecision: int64(targetMeta.TargetPrecision),
		Extra: &analysis.TargetCardExtraInfo{
			AttributeType:     targetMeta.AttributeType,
			IsLargerAdvantage: targetMeta.IsLargerAdvantage,
			IsDefaultShow:     targetMeta.IsDefaultShow,
		},
	}, nil
}

type GetTargetListWithKeyColumnReq struct {
	Params                 map[string]interface{}
	Sql                    string
	ApiPath                string
	BizType                dimensions.BizType
	BizList                []dimensions.BizType
	KeyCols                []string
	NeedDistribution       bool
	TrendCol               string
	FilterTarget           bool
	FilterTargetNames      []string
	TargetMetaEffectModule []string
	TargetMetaMap          map[string]*dao.TargetMetaInfo
}

func MergeTargetTrendMap(trendMaps ...map[string]map[string][]*analysis.TargetTrendPoint) map[string]map[string][]*analysis.TargetTrendPoint {
	newTrendMap := make(map[string]map[string][]*analysis.TargetTrendPoint)
	for _, tMap := range trendMaps {
		for k, vMap := range tMap {
			trendTargetNameMap, exist := newTrendMap[k]
			if !exist {
				trendTargetNameMap = make(map[string][]*analysis.TargetTrendPoint)
			}
			for targetName, trends := range vMap {
				newTrends, existTarget := trendTargetNameMap[targetName]
				if !existTarget {
					newTrends = make([]*analysis.TargetTrendPoint, 0)
				}
				newTrends = append(newTrends, trends...)
				trendTargetNameMap[targetName] = newTrends
			}
			newTrendMap[k] = trendTargetNameMap
		}
	}

	return newTrendMap
}

func AddTargetTrend(dimTargets []*KeyColsTargetEntity, trendMaps ...map[string]map[string][]*analysis.TargetTrendPoint) []*KeyColsTargetEntity {
	newTrendMap := MergeTargetTrendMap(trendMaps...)
	for _, dimT := range dimTargets {
		if len(dimT.TargetEntity) > 0 {
			for _, target := range dimT.TargetEntity {
				if trendMap, exist := newTrendMap[GetMapKeyColsString(dimT.KeyColValues)]; exist {
					if trends, existTarget := trendMap[target.Name]; existTarget {
						sort.Slice(trends, func(i, j int) bool {
							return trends[i].XValue < trends[j].XValue
						})
						target.TrendData = trends
					}
				}
			}
		}
	}

	return dimTargets
}

func AddCompareTargetTrend(dimTargets []*KeyColsTargetEntity, trendMaps ...map[string]map[string][]*analysis.TargetTrendPoint) []*KeyColsTargetEntity {
	newTrendMap := MergeTargetTrendMap(trendMaps...)
	for _, dimT := range dimTargets {
		if len(dimT.TargetEntity) > 0 {
			for _, target := range dimT.TargetEntity {
				if trendMap, exist := newTrendMap[GetMapKeyColsString(dimT.KeyColValues)]; exist {
					if trends, existTarget := trendMap[target.Name]; existTarget {
						sort.Slice(trends, func(i, j int) bool {
							return trends[i].X < trends[j].X
						})
						target.CompareTrendData = trends
					}
				}
			}
		}
	}

	return dimTargets
}

func GetTargetTrendWithKeyColumn(ctx context.Context, getTargetListWithKeyColumnReq GetTargetListWithKeyColumnReq) (trendMap map[string]map[string][]*analysis.TargetTrendPoint, err error) {
	records, err := GetRecordsByOS(ctx, getTargetListWithKeyColumnReq.Params, getTargetListWithKeyColumnReq.Sql, getTargetListWithKeyColumnReq.ApiPath)
	if err != nil {
		return
	}
	targetMetaMap, err := GetFilterTargetMetaInfoMap(ctx, int64(getTargetListWithKeyColumnReq.BizType), false, getTargetListWithKeyColumnReq.FilterTarget, getTargetListWithKeyColumnReq.FilterTargetNames, getTargetListWithKeyColumnReq.TargetMetaEffectModule...)
	if err != nil {
		return nil, err
	}

	trendMap = make(map[string]map[string][]*analysis.TargetTrendPoint, 0)
	for _, record := range records {
		keyColValues := make([]interface{}, 0)
		for _, keyCol := range getTargetListWithKeyColumnReq.KeyCols {
			keyColValues = append(keyColValues, record[keyCol])
		}
		trendTargetNameMap, existBase := trendMap[GetMapKeyColsString(keyColValues)]
		if !existBase {
			trendTargetNameMap = make(map[string][]*analysis.TargetTrendPoint, 0)
		}
		trendColValue := convert.ToString(record[getTargetListWithKeyColumnReq.TrendCol])
		for key, value := range record {
			if !slices.ContainsString(getTargetListWithKeyColumnReq.KeyCols, key) && key != getTargetListWithKeyColumnReq.TrendCol {
				trends, exist := trendTargetNameMap[key]
				if !exist {
					trends = make([]*analysis.TargetTrendPoint, 0)
				}

				targetMetaInfo := targetMetaMap[key]
				if targetMetaInfo == nil {
					continue
				}
				newTarget, err := GetTargetTrendPoint(ctx, value, targetMetaMap[key], trendColValue)
				if err != nil {
					return nil, err
				}
				trends = append(trends, newTarget)
				trendTargetNameMap[key] = trends
			}
		}

		trendMap[GetMapKeyColsString(keyColValues)] = trendTargetNameMap
	}
	return trendMap, nil
}

func GetTargetTrendWithKeyColumnRollup(ctx context.Context, getTargetListWithKeyColumnReq GetTargetListWithKeyColumnReq) (trendMap map[string]map[string][]*analysis.TargetTrendPoint, err error) {
	records, err := GetRecordsByOS(ctx, getTargetListWithKeyColumnReq.Params, getTargetListWithKeyColumnReq.Sql, getTargetListWithKeyColumnReq.ApiPath)
	if err != nil {
		return
	}
	targetMetaMap, err := GetFilterTargetMetaInfoMap(ctx, int64(getTargetListWithKeyColumnReq.BizType), false, getTargetListWithKeyColumnReq.FilterTarget, getTargetListWithKeyColumnReq.FilterTargetNames, getTargetListWithKeyColumnReq.TargetMetaEffectModule...)
	if err != nil {
		return nil, err
	}

	trendMap = make(map[string]map[string][]*analysis.TargetTrendPoint, 0)
	for _, record := range records {
		keyColValues := make([]interface{}, 0)
		for _, keyCol := range getTargetListWithKeyColumnReq.KeyCols {
			keyColValues = append(keyColValues, record[keyCol])
		}
		trendTargetNameMap, existBase := trendMap[GetMapKeyColsString(keyColValues)]
		if !existBase {
			trendTargetNameMap = make(map[string][]*analysis.TargetTrendPoint, 0)
		}
		trendColValue := convert.ToString(record[getTargetListWithKeyColumnReq.TrendCol])
		trendColValueTime, err := time.Parse(consts.Fmt_Date, trendColValue)
		if err != nil {
			return nil, err
		}
		var startData, endData time.Time
		if startDateStr, ok := getTargetListWithKeyColumnReq.Params["start_date"].(string); ok {
			startData, err = time.Parse(consts.Fmt_Date, startDateStr)
			if err != nil {
				return nil, err
			}
		} else {
			return nil, fmt.Errorf("[GetTargetTrendWithKeyColumnRollup] start_date is empty")
		}
		if endDateStr, ok := getTargetListWithKeyColumnReq.Params["end_date"].(string); ok {
			endData, err = time.Parse(consts.Fmt_Date, endDateStr)
			if err != nil {
				return nil, err
			}
		} else {
			return nil, fmt.Errorf("[GetTargetTrendWithKeyColumnRollup] end_date is empty")
		}
		if trendColValueTime.Before(startData) || trendColValueTime.After(endData) {
			// skip the default data
			continue
		}
		for key, value := range record {
			if !slices.ContainsString(getTargetListWithKeyColumnReq.KeyCols, key) && key != getTargetListWithKeyColumnReq.TrendCol {
				trends, exist := trendTargetNameMap[key]
				if !exist {
					trends = make([]*analysis.TargetTrendPoint, 0)
				}

				targetMetaInfo := targetMetaMap[key]
				if targetMetaInfo == nil {
					continue
				}
				newTarget, err := GetTargetTrendPoint(ctx, value, targetMetaMap[key], trendColValue)
				if err != nil {
					return nil, err
				}
				trends = append(trends, newTarget)
				trendTargetNameMap[key] = trends
			}
		}

		trendMap[GetMapKeyColsString(keyColValues)] = trendTargetNameMap
	}
	return trendMap, nil
}

func GetDataListByOS(ctx context.Context, params map[string]interface{}, sql string, apiPath string) (resp *engine.SqlResp, dataList [][]interface{}, err error) {
	var dpsToken string
	if len(sql) > 0 {
		resp, err = dp_invoker_engine.SqlQuery(ctx, sql, apiPath, calloption.WithRPCTimeout(time.Second*600))
	} else {
		dpsToken, err = infsecc.GetToken(false)
		if err != nil {
			logs.CtxError(ctx, "infsecc.GetToken err = %v", err)
			return nil, nil, err
		}
		osReq := engine.NewWithParamsReq()
		osReq.ApiID = apiPath
		osReq.Params = convert.ToJSONString(params)
		osReq.Option = []*engine.Option{
			{
				Id:   100,
				Val:  0,
				Val_: dpsToken,
			},
		}
		resp, err = dp_invoker_engine.RawCall.QueryWithParams(ctx, osReq, calloption.WithRPCTimeout(time.Second*600))
	}
	if err != nil {
		logs.CtxError(ctx, "QueryWithParams query with params failed, err: %v", err)
		return nil, nil, err
	}
	logs.CtxInfo(ctx, "query with params succeed, resp: %v", convert.ToJSONString(resp))
	dec := json.NewDecoder(strings.NewReader(resp.Data))
	dec.UseNumber()
	err = dec.Decode(&dataList)
	if err != nil {
		logs.CtxError(ctx, "json error:%v", err)
		return nil, nil, err
	}

	return resp, dataList, nil
}

func GetRecordsByOS(ctx context.Context, params map[string]interface{}, sql string, apiPath string) (ret []map[string]interface{}, err error) {
	resp, dataList, err := GetDataListByOS(ctx, params, sql, apiPath)
	if err != nil {
		return nil, err
	}

	records := make([]map[string]interface{}, 0)
	for _, dataLine := range dataList {
		record := make(map[string]interface{})
		for i, field := range resp.Fields {
			record[field.Name] = dataLine[i]
		}
		records = append(records, record)
	}

	return records, nil
}

func GetTablesByOS(ctx context.Context, params map[string]interface{}, sql string, apiPath string) (dataList [][]interface{}, err error) {
	resp, dataList, err := GetDataListByOS(ctx, params, sql, apiPath)
	if err != nil {
		return nil, err
	}

	var titleLine []interface{}
	for _, data := range resp.Fields {
		titleLine = append(titleLine, convert.ToString(data.Name))
	}
	dataList = append([][]interface{}{titleLine}, dataList...)

	return dataList, nil
}

func GetTargetListWithoutKeyColumn(ctx context.Context, getTargetListWithKeyColumnReq GetTargetListWithKeyColumnReq) (targetEntity []*analysis.TargetCardEntity, err error) {
	dimTargets, err := GetTargetListWithKeyColumn(ctx, getTargetListWithKeyColumnReq)
	if err != nil {
		return nil, err
	}
	if len(dimTargets) > 0 {
		return dimTargets[0].TargetEntity, nil
	}
	return
}

func GetTargetListWithKeyColumn(ctx context.Context, getTargetListWithKeyColumnReq GetTargetListWithKeyColumnReq) (dimTargets []*KeyColsTargetEntity, err error) {
	records, err := GetRecordsByOS(ctx, getTargetListWithKeyColumnReq.Params, getTargetListWithKeyColumnReq.Sql, getTargetListWithKeyColumnReq.ApiPath)
	if err != nil {
		return
	}

	var targetMetaMap map[string]*dao.TargetMetaInfo
	if getTargetListWithKeyColumnReq.BizList != nil && len(getTargetListWithKeyColumnReq.BizList) > 0 {
		targetMetaMap, err = GetFilterTargetMetaInfoMapByBizList(ctx, convert.ToInt64Slice(getTargetListWithKeyColumnReq.BizList), false, getTargetListWithKeyColumnReq.FilterTarget, getTargetListWithKeyColumnReq.FilterTargetNames, getTargetListWithKeyColumnReq.TargetMetaEffectModule...)
		if err != nil {
			return nil, err
		}
	} else {
		targetMetaMap, err = GetFilterTargetMetaInfoMap(ctx, int64(getTargetListWithKeyColumnReq.BizType), false, getTargetListWithKeyColumnReq.FilterTarget, getTargetListWithKeyColumnReq.FilterTargetNames, getTargetListWithKeyColumnReq.TargetMetaEffectModule...)
		if err != nil {
			return nil, err
		}
	}

	if len(getTargetListWithKeyColumnReq.TargetMetaMap) > 0 {
		for k, v := range getTargetListWithKeyColumnReq.TargetMetaMap {
			if _, exist := targetMetaMap[k]; !exist {
				targetMetaMap[k] = v
			}
		}
	}

	distributeMap := make(map[string]float64)
	for _, record := range records {
		for key, value := range record {
			distributeMap[key] += convert.ToFloat64(value)
		}
	}

	dimTargets = make([]*KeyColsTargetEntity, 0)
	for _, record := range records {
		extra := make(map[string]any)
		t := make([]*analysis.TargetCardEntity, 0)
		for key, value := range record {
			if !slices.ContainsString(getTargetListWithKeyColumnReq.KeyCols, key) {
				targetMetaInfo := targetMetaMap[key]
				if targetMetaInfo == nil {
					continue
				}

				newTarget, err := GetTargetEntity(ctx, value, targetMetaMap[key])
				if err != nil {
					return nil, err
				}

				if newTarget != nil {
					if newTarget.Extra == nil {
						newTarget.Extra = &analysis.TargetCardExtraInfo{}
					}

					newTarget.Extra.IsLargerAdvantage = targetMetaInfo.IsLargerAdvantage
					newTarget.Extra.IsDefaultShow = targetMetaInfo.IsDefaultShow
					newTarget.Extra.AttributeType = targetMetaInfo.AttributeType
					newTarget.Extra.SuggestScript = targetMetaInfo.SuggestScript
					newTarget.Extra.SuggestAction = targetMetaInfo.SuggestAction
					newTarget.Extra.BizType = dimensions.BizType(targetMetaInfo.BizId)
					if getTargetListWithKeyColumnReq.NeedDistribution && targetMetaInfo.IsDistribution {
						newTarget.Extra.DistributionFlag = targetMetaInfo.IsDistribution
						newTarget.Extra.DistributionValue = distributeMap[key]
					}
				}
				t = append(t, newTarget)
			}
			if getTargetListWithKeyColumnReq.BizType == dimensions.BizType_ProdReviewLibraMetricGroup {
				// todo 后续从主流程中抽出
				var libraId, vidId, displayName string
				if libraVal, ok := record["flight_id"].(string); ok {
					libraId = libraVal
				}
				if vidVal, ok := record["vid"].(string); ok {
					vidId = vidVal
				}
				libraInfo := fmt.Sprintf("实验组Id: %s", vidId)
				if len(vidId) == 0 {
					libraInfo = fmt.Sprintf("实验Id: %s", libraId)
				}
				if displayVal, ok := record["display_name"].(string); ok {
					displayName = displayVal
				}
				extra["libra_name"] = fmt.Sprintf("%s (%s)", displayName, libraInfo)
			}
		}

		keyColValues := make([]interface{}, 0)
		for _, keyCol := range getTargetListWithKeyColumnReq.KeyCols {
			keyColValues = append(keyColValues, record[keyCol])
		}

		dimTargets = append(dimTargets, &KeyColsTargetEntity{
			KeyColValues: keyColValues,
			TargetEntity: t,
			Extra:        extra,
		})
	}
	return dimTargets, nil
}

func GetTargetMetaInfoMap(ctx context.Context, bizType int64, needUnit bool, effectModule ...string) (map[string]*dao.TargetMetaInfo, error) {
	targetMetaList, err := new(dao.AttributeDao).GetTargetMetaInfo(ctx, bizType, nil, effectModule...)
	if err != nil {
		return nil, err
	}
	// 不需要展示指标时，指标单位除了%，其余都置为空串
	if !needUnit {
		for _, target := range targetMetaList {
			if target.ValueUnit != "%" && target.ValueUnit != "pp" {
				target.ValueUnit = ""
			}
		}
	}
	//if err != nil {
	//	return nil, err
	//}
	// 不需要展示指标时，指标单位除了%，其余都置为空串
	ret := make(map[string]*dao.TargetMetaInfo)
	for _, target := range targetMetaList {
		ret[target.Name] = target
	}

	return ret, nil
}

func GetTargetMetaInfoMapByBizList(ctx context.Context, bizList []int64, needUnit bool, effectModule ...string) (map[string]*dao.TargetMetaInfo, error) {
	targetMetaList, err := new(dao.AttributeDao).GetTargetMetaInfoBizList(ctx, bizList, nil, effectModule...)
	if err != nil {
		return nil, err
	}
	// 不需要展示指标时，指标单位除了%，其余都置为空串
	if !needUnit {
		for _, target := range targetMetaList {
			if target.ValueUnit != "%" && target.ValueUnit != "pp" {
				target.ValueUnit = ""
			}
		}
	}
	//if err != nil {
	//	return nil, err
	//}
	// 不需要展示指标时，指标单位除了%，其余都置为空串
	ret := make(map[string]*dao.TargetMetaInfo)
	for _, target := range targetMetaList {
		ret[target.Name] = target
	}

	return ret, nil
}

func GetFilterTargetMetaInfoMap(ctx context.Context, bizType int64, needUnit bool, filterTarget bool, filterTargetNames []string, effectModule ...string) (map[string]*dao.TargetMetaInfo, error) {
	mapRet, err := GetTargetMetaInfoMap(ctx, bizType, needUnit, effectModule...)
	if err != nil {
		return nil, err
	}
	if !filterTarget {
		return mapRet, nil
	}

	newMap := make(map[string]*dao.TargetMetaInfo)
	for i, targetName := range filterTargetNames {
		if metaInfo, exist := mapRet[targetName]; exist {
			metaInfo.DisplayOrder = i
			newMap[targetName] = metaInfo
		}
	}
	return newMap, nil
}

func GetFilterTargetMetaInfoMapByBizList(ctx context.Context, bizList []int64, needUnit bool, filterTarget bool, filterTargetNames []string, effectModule ...string) (map[string]*dao.TargetMetaInfo, error) {
	mapRet, err := GetTargetMetaInfoMapByBizList(ctx, bizList, needUnit, effectModule...)
	if err != nil {
		return nil, err
	}
	if !filterTarget {
		return mapRet, nil
	}

	newMap := make(map[string]*dao.TargetMetaInfo)
	for i, targetName := range filterTargetNames {
		if metaInfo, exist := mapRet[targetName]; exist {
			metaInfo.DisplayOrder = i
			newMap[targetName] = metaInfo
		}
	}
	return newMap, nil
}

func QueryWithParamsDump(ctx context.Context, params map[string]interface{}, apiPath, source, fileName string) (int64, error) {
	// use dps-sdk to fetch dps token (for TCE/FaaS)
	// for devbox or mac, please use doas (https://bytedance.feishu.cn/docx/doxcnPOLtP6ueLE2PMPOSATGI8b) 本地调试请使用doas
	dpsToken, err := infsecc.GetToken(false)

	osReq := engine.NewWithParamsReq()
	osReq.ApiID = apiPath
	osReq.Params = convert.ToJSONString(params)
	osReq.Option = []*engine.Option{
		{
			Id:   100,
			Val:  0,
			Val_: dpsToken,
		},
	}
	// put your api data
	req := &engine.WithParamsDumpReq{
		Request: osReq,
		Output:  fmt.Sprintf("hdfs://haruna/home/byte_temail_project_data/warehouse/ecom_data.db/xyz_product_analysis_pids/%s/%s", source, fileName),
		Format:  "CSV",
		Timeout: 120,
	}
	resp, err := dp_invoker_engine.RawCall.QueryWithParamsDump(ctx, req, calloption.WithRPCTimeout(time.Second*600))
	if err != nil {
		logs.CtxError(ctx, "QueryWithParamsDump failed, err: %v", err)
		return 0, err
	}
	logs.CtxInfo(ctx, "QueryWithParamsDump succeed, resp: %v", convert.ToJSONString(resp))

	var dataList [][]interface{}
	dec := json.NewDecoder(strings.NewReader(resp.Data))
	dec.UseNumber()
	err = dec.Decode(&dataList)
	if err != nil {
		logs.CtxError(ctx, "QueryWithParamsDump json error:%v", err)
		return 0, err
	}

	if len(dataList) == 0 || len(dataList[0]) == 0 {
		logs.CtxError(ctx, "QueryWithParamsDump json error:%v", err)
		return 0, errors.New("dump获取task id任务失败")
	}

	return convert.ToInt64(dataList[0][0]), nil
}

func QueryDumpStatus(ctx context.Context, taskIDs ...int64) (map[int64]int, error) {
	// use dps-sdk to fetch dps token (for TCE/FaaS)
	// for devbox or mac, please use doas (https://bytedance.feishu.cn/docx/doxcnPOLtP6ueLE2PMPOSATGI8b) 本地调试请使用doas
	dpsToken, err := infsecc.GetToken(false)

	osReq := engine.NewQueryDumpStatusReq()
	osReq.TaskIds = taskIDs
	osReq.DpsToken = &dpsToken
	resp, err := dp_invoker_engine.RawCall.QueryDumpStatus(ctx, osReq, calloption.WithRPCTimeout(time.Second*600))
	if err != nil {
		logs.CtxError(ctx, "QueryDumpStatus failed, err: %v", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "QueryDumpStatus succeed, resp: %v", convert.ToJSONString(resp))

	var dataList [][]interface{}
	dec := json.NewDecoder(strings.NewReader(resp.Data))
	dec.UseNumber()
	err = dec.Decode(&dataList)
	if err != nil {
		logs.CtxError(ctx, "QueryDumpStatus json error:%v", err)
		return nil, err
	}

	records := make([]map[string]interface{}, 0)
	for _, dataLine := range dataList {
		record := make(map[string]interface{})
		for i, field := range resp.Fields {
			record[field.Name] = dataLine[i]
		}
		records = append(records, record)
	}

	retMap := make(map[int64]int)
	for _, record := range records {
		retMap[convert.ToInt64(record["TaskId"])] = convert.ToInt(record["Status"])
	}
	return retMap, nil
}
