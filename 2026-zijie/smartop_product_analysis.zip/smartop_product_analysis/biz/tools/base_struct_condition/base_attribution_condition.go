package base_struct_condition

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"strings"
)

type AttributionOsParamsReq struct {
	BaseStruct     *analysis.AttributionCommonBaseStruct
	DimMap         map[int64]*dao.DimensionInfo
	DimColMap      map[string]*dao.DimensionInfo
	MultiDimension []string
	OrderBy        *base.OrderByInfo
	PageInfo       *base.PageInfo
}

// GetAttributionStructConditionParams 通过基础结构抽象，获取查询的sql结构体 - 包含基础、对比周期、趋势图
func GetAttributionStructConditionParams(ctx context.Context, req AttributionOsParamsReq) (curr, compare, trend, compareTrend map[string]interface{}, err error) {
	curr, err = GetAttributionStructConditionParam(ctx, req, SQLCalcType_Curr)
	if err != nil {
		return
	}
	compare, err = GetAttributionStructConditionParam(ctx, req, SQLCalcType_Compare)
	if err != nil {
		return
	}
	trend, err = GetAttributionStructConditionParam(ctx, req, SQLCalcType_Trend)
	if err != nil {
		return
	}
	compareTrend, err = GetAttributionStructConditionParam(ctx, req, SQLCalcType_CompareTrend)
	if err != nil {
		return
	}
	return
}

func GetAttributionStructConditionParam(ctx context.Context, req AttributionOsParamsReq, calcType SQLCalcType) (param map[string]interface{}, err error) {
	if req.BaseStruct == nil {
		return nil, errors.New("[GetBaseStructConditionParam]BaseStruct为空，请检查入参")
	}
	// 获取业务线元信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseStruct.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxError(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		if err == nil {
			err = errors.New("业务线元信息读取失败，请检查TCC配置")
		}
		return
	}

	param = make(map[string]interface{})
	if req.BaseStruct.BizType == dimensions.BizType_AttributionProdBase { // 如果是 商品基础信息 原因
		noPurcaseList, err := GetNoPurchasePvKeys(ctx, req.BaseStruct.BizType) // 补充不可买枚举信息
		if err != nil {
			logs.CtxError(ctx, "GetNoPurchasePvKeys, err = %v+", err)
			return nil, err
		}
		if len(noPurcaseList) > 0 {
			param["no_purchase_reason_col_list"] = noPurcaseList
		}
	}

	startDate, endDate := GetDateRange(&dimensions.ProductAnalysisBaseStruct{
		StartDate:        req.BaseStruct.StartDate,
		EndDate:          req.BaseStruct.EndDate,
		CompareStartDate: req.BaseStruct.CompareStartDate,
		CompareEndDate:   req.BaseStruct.CompareEndDate,
	}, calcType == SQLCalcType_Compare || calcType == SQLCalcType_CompareTrend)
	param["start_date"] = startDate
	param["end_date"] = endDate
	param["compare_start_date"] = req.BaseStruct.CompareStartDate
	param["compare_end_date"] = req.BaseStruct.CompareEndDate
	param["date_range"] = time_utils.DateDiffAbs(startDate, endDate) + 1
	param["biz_type"] = int64(req.BaseStruct.BizType)
	param["insight_type"] = int64(req.BaseStruct.InsightType)
	// 表名筛选
	param["table_name"] = bizInfo.TableName
	// 变化标识
	param["pv_incr_type"] = req.BaseStruct.PvIncrType

	if req.BaseStruct.ObjectBizType != nil {
		param["object_biz_type"] = req.BaseStruct.ObjectBizType
	}

	ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, []consts.DateType{consts.DateType_DAY, consts.DateType_WEEK, consts.DateType_WEEK}) // 暂时以大盘用增表为主
	dateExpr, _, err := GetDateExpr(ctx, req.BaseStruct.StartDate, req.BaseStruct.EndDate)
	if err != nil {
		return nil, err
	}
	param["date_expr"] = sql_parse.NewCQL().ParseExpression(dateExpr)

	compareDateExpr, _, err := GetDateExpr(ctx, req.BaseStruct.CompareStartDate, req.BaseStruct.CompareEndDate)
	if err != nil {
		return nil, err
	}
	param["compare_date_expr"] = sql_parse.NewCQL().ParseExpression(compareDateExpr)

	// 大盘不需要下面的筛选项
	if calcType == SQLCalcType_Overall {
		return
	}

	// 分页和排序逻辑
	if req.OrderBy == nil || req.OrderBy.ColumnName == nil || len(*req.OrderBy.ColumnName) == 0 {
		var orderField = consts.AttrNameShowPV
		req.OrderBy = &base.OrderByInfo{
			ColumnName: &orderField,
			IsDesc:     true,
		}
	}
	param["order_by"] = fmt.Sprintf("%v %v,prod_id", *req.OrderBy.ColumnName, utils.If(req.OrderBy.IsDesc, "desc", "asc"))
	if req.PageInfo == nil {
		req.PageInfo = &base.PageInfo{
			PageNum:  0,
			PageSize: 10,
		}
	}
	param["limit"] = req.PageInfo.PageSize
	param["offset"] = req.PageInfo.PageSize * (req.PageInfo.PageNum - 1)

	if calcType == SQLCalcType_Trend || calcType == SQLCalcType_CompareTrend {
		req.MultiDimension = append(req.MultiDimension, "date")
	}

	// 解析所选维度过滤信息
	exprCql, _, _, err := GetBaseConditionWithDims(ctx, &dimensions.ProductAnalysisBaseStruct{
		BizType:          req.BaseStruct.BizType,
		StartDate:        req.BaseStruct.StartDate,
		EndDate:          req.BaseStruct.EndDate,
		CompareStartDate: req.BaseStruct.CompareStartDate,
		CompareEndDate:   req.BaseStruct.CompareEndDate,
		Dimensions:       req.BaseStruct.Dimensions,
	}, calcType == SQLCalcType_Compare, req.DimMap, false, false)
	if err != nil {
		return
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}

	whereStr := exprCql.ParseAllWhereExpression()
	if len(whereStr) > 0 {
		param["filter_param"] = whereStr
	}

	prodList, err := GetBaseConditionProdList(ctx, req.BaseStruct)
	if err != nil {
		return
	}
	if len(prodList) > 0 {
		param["prod_filter_param"] = fmt.Sprintf("%s in (%s)", consts.ProductID, strings.Join(prodList, ","))
	}

	if len(req.MultiDimension) > 0 {
		subSelect := make([]string, 0)
		for _, d := range req.MultiDimension {
			if dimInfo, exist := req.DimColMap[d]; exist && len(dimInfo.DimExpr) > 0 {
				subSelect = append(subSelect, fmt.Sprintf("%s as %s", dimInfo.DimExpr, d))
			} else {
				subSelect = append(subSelect, d)
			}
		}
		param["dimension"] = strings.Join(req.MultiDimension, ",")
	}
	return
}

func GetBaseConditionProdList(ctx context.Context, baseStruct *analysis.AttributionCommonBaseStruct) (prodList []string, err error) {
	prodList = make([]string, 0)
	if len(baseStruct.Dimensions) > 0 {
		for _, reqDim := range baseStruct.Dimensions {
			if len(reqDim.SelectedValues) == 0 {
				continue
			}

			if reqDim.Id == consts.CustomProductPool {
				// 获取货盘信息
				analysisPoolDoList := make([]dao.AnalysisPoolDo, 0)
				tx := mysql.DB(ctx)
				poolId := reqDim.SelectedValues[0].Code
				// 查询货盘下所有商品id
				err = tx.Table("analysis_pool").Where("is_delete", 0).Where("pool_id = ?", poolId).Find(&analysisPoolDoList).Error
				if err != nil {
					logs.CtxError(ctx, "GetBaseConditionProdList 查询货盘信息error: %v+", err)
					return prodList, err
				}
				if len(analysisPoolDoList) > 0 && analysisPoolDoList[0].PoolType == 0 { // 手动录入货盘
					analysisPoolProducts := make([]*dao.AnalysisPoolProductDo, 0)
					err = tx.Table("analysis_pool_product").Where("is_delete='0'").Where("pool_id = ?", analysisPoolDoList[0].PoolId).Find(&analysisPoolProducts).Error
					if err != nil || len(analysisPoolProducts) == 0 {
						logs.CtxError(ctx, "GetBaseConditionProdList 查询货盘[%s]商品失败，analysisPoolProducts %s, error: %v+", analysisPoolDoList[0].PoolId, convert.ToJSONString(analysisPoolProducts), err)
						return prodList, errors.New(fmt.Sprintf("查询货盘[%s]商品失败", analysisPoolDoList[0].PoolId))
					}
					for _, analysisPoolProduct := range analysisPoolProducts {
						prodList = append(prodList, analysisPoolProduct.ProductId)
					}
				}
			}

			if reqDim.Id == consts.ProdIDSingleDim {
				if len(reqDim.SelectedValues) > 0 {
					for _, v := range reqDim.SelectedValues {
						prodList = append(prodList, v.Code)
					}
				}
			}
		}
	}
	prodList = slices.DistinctString(prodList)
	return prodList, nil
}

func GetNoPurchasePvKeys(ctx context.Context, bizType dimensions.BizType) ([]string, error) {
	targetMetaList, err := new(dao.AttributeDao).GetTargetMetaByType(ctx, int64(bizType), "不可买曝光-购买限制", "不可买曝光-营销活动", "不可买曝光-销售状态", "不可买曝光-其他")
	res := make([]string, 0)
	if err != nil {
		return nil, err
	}
	for _, info := range targetMetaList {
		keyArr := strings.Split(info.Name, "_")
		key := keyArr[len(keyArr)-1]
		if convert.ToInt64(key) > 0 {
			res = append(res, key)
		}
	}
	res = slices.DistinctString(res)
	return res, nil
}
