package base_struct_condition

import (
	"context"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
)

func GetAttributeList(ctx context.Context, attrList []*dao.TargetMetaInfo) (subList, baseList []string) {
	if len(attrList) > 0 {
		subList = make([]string, 0)
		baseList = make([]string, 0)

		for _, attr := range attrList {
			var attrExpr string
			if len(attr.CalcAggExpr) > 0 {
				attrExpr = attr.CalcAggExpr
			} else {
				switch sql_parse.AggregateMethod(attr.CalcAggMethod) {
				case sql_parse.SUM, sql_parse.AVG, sql_parse.MAX, sql_parse.MIN:
					attrExpr = fmt.Sprintf("%s(%s) as %s", attr.CalcAggMethod, attr.Name, attr.Name)
				case sql_parse.COUNT:
					attrExpr = fmt.Sprintf("%s(1) as %s", attr.CalcAggMethod, attr.Name)
				case sql_parse.HLL_SKETCH:
					subList = append(subList, fmt.Sprintf("hllSketchUnion(%s) as %s_sketch", attr.Name, attr.Name))
					baseList = append(baseList, fmt.Sprintf("cast(coalesce(hllSketchEstimate(12,1)(%s_sketch),0) as Int64) as %s_cnt", attr.Name, attr.Name))
				default:
					fmt.Println(attr)
				}
			}

			if len(attrExpr) > 0 {
				if base.TargetAttributeCalcType(attr.CalcType) == base.TargetAttributeCalcType_Basic {
					subList = append(subList, attrExpr)
				}
				baseList = append(baseList, attrExpr)
			}
		}
	}

	return
}
