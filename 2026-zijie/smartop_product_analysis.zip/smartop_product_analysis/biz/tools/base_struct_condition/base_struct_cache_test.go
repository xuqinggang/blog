package base_struct_condition

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"testing"
)

func TestCache(t *testing.T) {
	ctx := context.Background()
	req := &dimensions.ProductAnalysisBaseStruct{
		BizType:          0,
		StartDate:        "2024-05-01",
		EndDate:          "2024-05-02",
		CompareStartDate: "2024-05-04",
		CompareEndDate:   "2024-05-05",
		Dimensions: []*dimensions.SelectedDimensionInfo{
			{
				Id:   "1",
				Name: "2",
			},
		},
		GroupAttrs: nil,
	}
	var resp *dimensions.ProductAnalysisBaseStruct
	resp, _ = GetCacheResp(ctx, "", req, resp)
	fmt.Println(convert.ToJSONString(resp))
}
