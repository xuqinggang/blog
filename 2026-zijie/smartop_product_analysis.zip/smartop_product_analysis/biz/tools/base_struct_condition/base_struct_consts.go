package base_struct_condition

type SQLCalcType int64

const (
	SQLCalcType_Curr         SQLCalcType = 1
	SQLCalcType_Compare      SQLCalcType = 2
	SQLCalcType_Trend        SQLCalcType = 3
	SQLCalcType_Overall      SQLCalcType = 4
	SQLCalcType_CompareTrend SQLCalcType = 5
)

const (
	ApiProdBaseDfTableName                  = "app_product_insight_prod_base_df"
	ApiProdPoolTableNameV2                  = "app_product_analysis_product_pool_di_v2"
	ApiProdPoolTableNameBucket              = "app_product_analysis_product_pool_di_v2_bucket"
	ApiProdOncePoolTableName                = "app_product_analysis_long_product_pool_di"
	ApiActivityTableName                    = "app_prm_platform_prod_activity_sign_up_di"
	ApiActivityTableNameBucket              = "app_prm_platform_prod_activity_sign_up_di_bucket"
	ApiBrainTableName                       = "dwd_auth_publish_matching_brain_product_insight_di"
	ApiProdBrandTrial                       = "app_product_prod_brand_trail_stats_di"
	ProductPlanGuess                        = "app_product_plan_guess_new_df"
	ProdSelectTag                           = "prod_select_center"
	ChannelTag                              = "channel"
	BigPromotionProdBaseDfTableName         = "app_product_insight_big_promotion_prod_base_df_v2"
	MarketActivityTempTableName             = "app_product_insight_market_view_di"
	DynamicDimensionProdRelationTableName   = "dynamic_dimension_prod_relation_df"
	DynamicDimensionProdRelationTableBucket = "dynamic_dimension_prod_relation_df_bucket"
	ApiProdBigLinkAndSameClusterTableName   = "app_product_big_link_and_same_cluster_merge_stats_di_v2"
	ApiAlgorithmFeaturePoolTableName        = "product_select_allowance_zero_subsidy_explode_result"

	DynamicDimensionUserRelationTableName = "dynamic_dimension_user_relation_df"
)

type CKSettingType int64

const (
	CKSettingNone CKSettingType = 1
	CKSettingSub  CKSettingType = 2
	CKSettingBase CKSettingType = 3
)

// 大促报名状态适配业务逻辑
var BigactSignStatusReplaceMap = map[string]string{
	"主动报名+氛围圈选": "1','2','3",
	"主动报名":          "1','2",
	"氛围圈选":          "1','3",
}

var BigactSignStatusReplaceList = []string{
	"主动报名+氛围圈选",
	"主动报名",
	"氛围圈选",
}
