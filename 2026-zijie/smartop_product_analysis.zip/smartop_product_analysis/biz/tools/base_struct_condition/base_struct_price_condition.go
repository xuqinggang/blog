package base_struct_condition

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
	"strings"
)

type PriceOsParamsReq struct {
	BaseStruct     *dimensions.PriceAnalysisBaseStruct
	DimMap         map[int64]*dao.DimensionInfo
	DimColMap      map[string]*dao.DimensionInfo
	MultiDimension []string
	OrderBy        *base.OrderByInfo
	PageInfo       *base.PageInfo
}

// GetPriceBaseStructConditionParams 通过基础结构抽象，获取查询的sql结构体 - 包含基础、大盘、趋势图
func GetPriceBaseStructConditionParams(ctx context.Context, req PriceOsParamsReq) (curr, trend, overall map[string]interface{}, err error) {
	curr, err = GetPriceBaseStructConditionParam(ctx, req, SQLCalcType_Curr)
	if err != nil {
		return
	}
	trend, err = GetPriceBaseStructConditionParam(ctx, req, SQLCalcType_Trend)
	if err != nil {
		return
	}
	overall, err = GetPriceBaseStructConditionParam(ctx, req, SQLCalcType_Overall)
	return
}

func GetPriceConditionSimpleParam(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) map[string]interface{} {
	param := make(map[string]interface{})
	startDate, endDate := req.StartDate, req.EndDate
	param["start_date"] = startDate
	param["end_date"] = endDate
	param["date_range"] = time_utils.DateDiffAbs(startDate, endDate) + 1
	param["biz_type"] = int64(req.BizType)
	param["price_comparison_type"] = int64(req.PriceComparisonType)
	param["price_in_out_type"] = int(biz_info.GetCtxBizInfoPriceAAInOutType(ctx))
	if req.Granularity != nil {
		param["granularity"] = int64(*req.Granularity)
	}
	return param
}

func GetPriceBaseStructConditionParam(ctx context.Context, req PriceOsParamsReq, calcType SQLCalcType) (param map[string]interface{}, err error) {
	param = make(map[string]interface{})
	startDate, endDate := req.BaseStruct.StartDate, req.BaseStruct.EndDate
	param["start_date"] = startDate
	param["end_date"] = endDate
	param["date_range"] = time_utils.DateDiffAbs(startDate, endDate) + 1
	param["biz_type"] = int64(req.BaseStruct.BizType)
	param["price_comparison_type"] = int64(req.BaseStruct.PriceComparisonType)
	param["price_in_out_type"] = int(biz_info.GetCtxBizInfoPriceAAInOutType(ctx))

	if calcType == SQLCalcType_Trend {
		switch req.BaseStruct.DateType {
		case base.DateType_DAY:
			param["date_type"] = "day"
		case base.DateType_WEEK:
			param["date_type"] = "week"
		case base.DateType_MONTH:
			param["date_type"] = "month"
		default:
			logs.CtxInfo(ctx, "req.BaseStruct.DateType not find, %s", convert.ToJSONString(req.BaseStruct.DateType))
		}
	}

	if req.BaseStruct.Granularity != nil {
		param["granularity"] = int64(*req.BaseStruct.Granularity)
	}

	// 大盘不需要下面的筛选项
	if calcType == SQLCalcType_Overall {
		return
	}

	// 分页和排序逻辑
	if req.OrderBy != nil {
		var orderByField, orderType string
		if req.OrderBy.IsDesc {
			orderType = "desc"
		} else {
			orderType = "asc"
		}
		if req.OrderBy.ColumnName != nil {
			orderByField = *req.OrderBy.ColumnName
		} else if req.OrderBy.Field != nil {
			switch *req.OrderBy.Field {
			case base.OrderByField_ShowPv:
				orderByField = "show_pv"
			case base.OrderByField_PayOrderNum:
				orderByField = "pay_ord_cnt"
			case base.OrderByField_BrandLevel:
				orderByField = "complex_brand_s_level"
			default:
				orderByField = consts.Empty
			}
		} else {
			return nil, errors.New("order by字段传参有问题，请检查")
		}
		param["order_by"] = fmt.Sprintf("%v %v,prod_id", orderByField, orderType)
	}

	if req.PageInfo != nil {
		param["limit"] = req.PageInfo.PageSize
		param["offset"] = req.PageInfo.PageSize * (req.PageInfo.PageNum - 1)
	}

	// 解析所选维度过滤信息
	exprCql, err := GetPriceBaseConditionWithDims(ctx, req.BaseStruct, req.DimMap)
	if err != nil {
		return
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}

	whereStr := exprCql.ParseAllWhereExpression()
	if len(whereStr) > 0 {
		param["filter_param"] = whereStr
	}

	if req.MultiDimension == nil {
		req.MultiDimension = make([]string, 0)
	}
	if calcType == SQLCalcType_Trend {
		req.MultiDimension = append(req.MultiDimension, "date")
	}

	if len(req.MultiDimension) > 0 {
		subSelect := make([]string, 0)
		for _, d := range req.MultiDimension {
			if dimInfo, exist := req.DimColMap[d]; exist && len(dimInfo.DimExpr) > 0 {
				subSelect = append(subSelect, fmt.Sprintf("%s as %s", dimInfo.DimExpr, d))
			} else {
				subSelect = append(subSelect, d)
			}
		}

		param["sub_select"] = strings.Join(subSelect, ",")
		param["dimension"] = strings.Join(req.MultiDimension, ",")
	}
	return
}

func GetPriceBaseConditionWithDims(ctx context.Context, baseStruct *dimensions.PriceAnalysisBaseStruct, dimMap map[int64]*dao.DimensionInfo) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()
	dateExpr, _, err := GetDateExpr(ctx, baseStruct.StartDate, baseStruct.EndDate)
	if err != nil {
		return
	}
	if len(baseStruct.Dimensions) > 0 {
		prodValLastDayDims := make([]*dimensions.SelectedDimensionInfo, 0)
		prodBaseDims := make([]*dimensions.SelectedDimensionInfo, 0)

		for _, reqDim := range baseStruct.Dimensions {
			if reqDim == nil {
				continue
			}
			dimInfo := dimMap[convert.ToInt64(reqDim.Id)]
			if dimInfo == nil {
				logs.CtxError(ctx, "[GetBaseStructConditionCql]未查询到维度信息,id=%s", reqDim.Id)
				return nil, errors.New("未查询到维度信息")
			}

			if dimInfo.IsProdIDAttr == 1 {
				prodValLastDayDims = append(prodValLastDayDims, reqDim)
			} else {
				prodBaseDims = append(prodBaseDims, reqDim)
			}
		}

		if len(prodValLastDayDims) > 0 {
			lastVCql, err := GetProductLastDayValCQL(ctx, prodValLastDayDims, dimMap, baseStruct.EndDate, consts.Empty, false)
			if err != nil {
				return nil, err
			}
			cql.AddSubQueryWhere(consts.ProductID, sql_parse.IN, lastVCql)
		}

		if len(prodBaseDims) > 0 {
			baseExprCql, err := GetDimCondition(ctx, prodBaseDims, dimMap, dateExpr)
			if err != nil {
				return nil, err
			}
			cql.AddWhereAndValue(baseExprCql.WhereClause).AddRawWhereAndValue(baseExprCql.RawWhereClause...)
		}
	}
	return cql, nil
}

type PriceFlowStandardParamsReq struct {
	BaseStruct       *dimensions.PriceAnalysisBaseStruct
	DimMap           map[int64]*dao.DimensionInfo
	EntityList       []string
	Channel          string
	FlowChannel      string
	FlowStandardType dimensions.PriceFlowStandardType
	IsOverall        bool
}

func GetPriceChangeFlowStandardSubSQL(ctx context.Context, req PriceFlowStandardParamsReq) (cql *sql_parse.CQL, err error) {
	cql = sql_parse.NewCQL()

	if req.BaseStruct.Granularity == nil {
		return nil, errors.New("商品/SKU粒度未配置")
	}
	tableName := consts.ProdPriceChangeTableName
	if *req.BaseStruct.Granularity == dimensions.AnalysisGranularity_SKU {
		tableName = consts.SkuPriceChangeTableName
	}

	cql.Select(req.EntityList...).From(fmt.Sprintf("%s as sub_flow_standard_sql", tableName)).AddWhere("date_range", sql_parse.EQUAL, "3d")

	// 填充场域
	if len(req.FlowChannel) == 0 {
		req.FlowChannel = "all"
	}
	cql.AddWhere("channel", sql_parse.EQUAL, req.FlowChannel)

	// 填充时间
	cql.AddWhereRawCond("date between ? and ?", req.BaseStruct.StartDate, req.BaseStruct.EndDate)

	switch biz_info.GetCtxBizInfoPriceAAInOutType(ctx) {
	case dimensions.PriceInOutType_PRICE_IN:
		cql.AddWhere("xd_is_high_price_range_tag", sql_parse.EQUAL, 1)
		cql.AddWhere("xd_priority", sql_parse.IN, consts.PricePriorityList)
	case dimensions.PriceInOutType_PRICE_OUT:
		cql.AddWhere("out_is_high_price_range_tag", sql_parse.EQUAL, 1)
		cql.AddWhere("out_priority", sql_parse.IN, consts.PricePriorityList)
	default:
		return nil, errors.New("未设置内/外价格力对比")
	}

	// 如果看改价全部数据，则不需要筛选条件
	if req.IsOverall {
		priceChangeWhereStr, err := GetOutXdPriceChangeWhereStr(ctx, biz_info.GetCtxBizInfoPriceAAInOutType(ctx))
		if err != nil {
			logs.CtxError(ctx, "[GetPriceChangeFlowStandardSubSQL]GetOutXdPriceChangeWhereStr Err, %v", err)
			return nil, err
		}
		cql.AddRawWhere(fmt.Sprintf("and %s ", priceChangeWhereStr))
		return cql, nil
	}

	// 填充条件
	// 解析所选维度过滤信息
	exprCql, err := GetPriceBaseConditionWithDims(ctx, req.BaseStruct, req.DimMap)
	if err != nil {
		return
	}
	if exprCql == nil {
		exprCql = sql_parse.NewCQL()
	}

	cql.AddWhereAndValue(exprCql.WhereClause)
	if len(exprCql.RawWhereClause) > 0 {
		cql.AddRawWhereAndValue(exprCql.RawWhereClause...)
	}

	// 判断是获取哪个达标的条件
	switch req.FlowStandardType {
	case dimensions.PriceFlowStandardType_FlowStandard_NONE: // 无需配置
		return
	case dimensions.PriceFlowStandardType_FlowStandard_ALL:
		cql.AddWhereAndValue(&sql_parse.Expression{
			Logic: sql_parse.OR,
			Children: []*sql_parse.Expression{
				sql_parse.GetExpressionWithOperator("0.3", sql_parse.GREATER_EQUAL_THAN, sql_parse.DOUBLE, "aa_change_rate"),
				sql_parse.GetExpressionWithOperator("0.5", sql_parse.GREATER_EQUAL_THAN, sql_parse.DOUBLE, "tk_lower_price_prod_show_cnt_rate"),
			},
		})
	case dimensions.PriceFlowStandardType_FlowStandard_AA:
		cql.AddWhere("aa_change_rate", sql_parse.GREATER_EQUAL_THAN, 0.3)
	case dimensions.PriceFlowStandardType_FlowStandard_CSPU:
		cql.AddWhere("tk_lower_price_prod_show_cnt_rate", sql_parse.GREATER_EQUAL_THAN, 0.5)
	default:
		return nil, errors.New("流量达标的标识未正确配置")
	}

	return
}

func GetOutXdPriceChangeWhereStr(ctx context.Context, priceInOutType dimensions.PriceInOutType) (ret string, err error) {
	priceChangeTypeMap, err := biz_info.GetOutXdPriceChangeTypeMap(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetOutXdPriceChangeWhereStr]GetOutXdPriceChangeTypeMap Err, %v", err)
		return ret, err
	}
	priceChangeWhereArr := make([]string, 0)
	for k, v := range priceChangeTypeMap {
		switch priceInOutType {
		case dimensions.PriceInOutType_PRICE_IN:
			if strings.HasPrefix(k, "站内") {
				priceChangeWhereArr = append(priceChangeWhereArr, v)
			}
		case dimensions.PriceInOutType_PRICE_OUT:
			if strings.HasPrefix(k, "站外") {
				priceChangeWhereArr = append(priceChangeWhereArr, v)
			}
		default:
			return ret, errors.New("未设置内/外价格力对比")
		}
	}
	if len(priceChangeWhereArr) == 0 {
		return ret, errors.New("获取价格力变化条件失败")
	}
	return fmt.Sprintf(" (%s) ", strings.Join(priceChangeWhereArr, " or ")), nil
}

/*
GetOrderSourceChannelSelect

	第一个返回体:
	if(app_name in ('抖音','抖音极速版'),['all'],[]) as all_channel,
	if(app_name in ('抖音','抖音极速版') and content_type = '直播',['live'],[]) as live_channel,
	if(app_name in ('抖音','抖音极速版') and content_type = '短视频',['video'],[]) as video_channel,
	if(app_name in ('抖音','抖音极速版') and search_module is not null,['search'],[]) as search_channel,
	if(app_name in ('抖音','抖音极速版') and guess_channel is not null,['guess'],[]) as guess_channel,
	if(app_name in ('抖音','抖音极速版') and is_billion_order = 1,['billion'],[]) as billion_channel,
	arrayConcat(all_channel,live_channel,video_channel,search_channel,guess_channel,billion_channel) as arr_channel
*/
func GetOrderSourceChannelSelect(ctx context.Context, needAll bool) (string, string, error) {
	metaList, err := biz_info.GetOrderSourceChannelMetaInfoList(ctx)
	if err != nil {
		return consts.Empty, consts.Empty, err
	}

	outArr := make([]string, 0)
	if len(metaList) > 0 {
		channelList := make([]string, 0)
		for _, meta := range metaList {
			if meta.Channel == "all" && !needAll {
				continue
			}
			outArr = append(outArr, fmt.Sprintf("if(%s,['%s'],[]) as %s_channel", meta.Express, meta.Channel, meta.Channel))
			channelList = append(channelList, fmt.Sprintf("%s_channel", meta.Channel))
		}
		outArr = append(outArr, fmt.Sprintf("arrayConcat(%s) as arr_channel", strings.Join(channelList, ",")))
	}
	return strings.Join(outArr, ","), "arrayJoin(arr_channel)", nil
}
