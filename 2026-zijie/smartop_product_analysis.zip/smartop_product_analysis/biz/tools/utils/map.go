package utils

func MergeMaps(map1, map2 *map[string]interface{}) map[string]interface{} {
	merged := make(map[string]interface{})
	for k, v := range *map1 {
		merged[k] = v
	}
	for k, v := range *map2 {
		merged[k] = v
	}
	return merged
}

func MergeMapString(map1, map2 *map[string]string) map[string]string {
	merged := make(map[string]string)
	for k, v := range *map1 {
		merged[k] = v
	}
	for k, v := range *map2 {
		merged[k] = v
	}
	return merged
}
