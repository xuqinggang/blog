package utils

import (
	"fmt"
	"regexp"
	"strings"

	"code.byted.org/gopkg/pkg/errors"
)

var reg = regexp.MustCompile(`\${[0-9a-zA-Z_\-.]+}`)

// StringFormatByRegex 字符串占位符替换(可指定正则表达式来匹配)
func StringFormatByRegex(format string, params map[string]interface{}) (newVal string, err error) {
	if reg == nil {
		return
	}
	placeHolders := reg.FindAllString(format, -1) // 占位符
	builder := strings.Builder{}
	for idx, seg := range reg.Split(format, -1) {
		builder.WriteString(seg)
		if idx < len(placeHolders) {
			// params中有这个参数则替换，否则报错
			placeholder := placeHolders[idx]
			// ${placeholder} 格式的占位符
			if len(placeholder) < 3 {
				err = errors.New(fmt.Sprintf("参数异常: 实际字符串长度=%v", len(placeholder)))
				return
			}
			if val, ok := params[placeholder[2:len(placeholder)-1]]; !ok {
				err = errors.New(fmt.Sprintf("缺少必要参数:%s", placeholder))
				return
			} else {
				builder.WriteString(fmt.Sprintf("%v", val))
			}
		}
	}

	newVal = builder.String()

	return
}

// StringSplitNotEmpty 空串时split返回空数组
func StringSplitNotEmpty(s string, d string) []string {
	if s == "" {
		return []string{}
	}

	return strings.Split(s, d)
}
