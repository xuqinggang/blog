package utils

import (
	"bytes"
	"context"
	"io/ioutil"
	"net/http"
	URL "net/url"
	"time"

	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/byted/consts"
	"code.byted.org/temai/go_lib/convert"
	"github.com/goccy/go-json"
)

type Element struct {
	Key   string
	Value string
}

type RequestOption struct {
	Timeout int
}

func HttpRequest(ctx context.Context, method, url string, headers []Element, data interface{}, queryParams []Element, resp interface{}, options *RequestOption) error {
	logs.CtxInfo(ctx, "[HttpRequest] host:%s, data:%+v", url, convert.ToJSONString(data))
	values := URL.Values{}
	for _, param := range queryParams {
		values.Add(param.Key, param.Value)
	}
	if len(queryParams) != 0 {
		url = url + "?" + values.Encode()
	}
	jsonStr, _ := json.Marshal(data)
	req, err := http.NewRequest(method, url, bytes.NewBuffer(jsonStr))
	if err != nil {
		logs.CtxError(ctx, "[HttpRequest] NewRequest err:%+v", err)
		return err
	}
	logId := ctx.Value(consts.CtxKeyLogID)
	if len(convert.ToString(logId)) > 0 {
		req.Header.Add("X-Tt-Logid", convert.ToString(logId))
		req.Header.Add("request-id", convert.ToJSONString(logId))
	}
	req.Header.Add("accept", "*/*")
	req.Header.Add("content-type", "application/json")
	for _, header := range headers {
		req.Header.Add(header.Key, header.Value)
	}
	defer req.Body.Close()
	t := 60
	if options != nil && options.Timeout > 0 {
		t = options.Timeout
	}
	client := &http.Client{Timeout: (time.Duration(t)) * time.Second}
	res, err := client.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	result, _ := ioutil.ReadAll(res.Body)
	logs.CtxInfo(ctx, "[HttpRequest] result: %+v", string(result))
	return TransJson2Struct(ctx, string(result), resp)
}
