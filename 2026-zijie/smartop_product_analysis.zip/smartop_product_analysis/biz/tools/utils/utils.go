package utils

import (
	"context"
	cryptoRand "crypto/rand"
	"encoding/json"
	"fmt"
	"math/big"
	"math/rand"
	"reflect"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"

	"github.com/jinzhu/copier"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"

	"code.byted.org/gopkg/metainfo"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/framework_udf"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/overpass/ecom_navigator_rpc/rpc/ecom_navigator_rpc"
	"code.byted.org/overpass/ecom_smartop_guard/kitex_gen/ecom/smartop/guard"
	"code.byted.org/overpass/ecom_smartop_guard/rpc/ecom_smartop_guard"
	"code.byted.org/temai/go_lib/convert"
	"code.byted.org/temai/go_portal_sdk/models"
	"code.byted.org/temai/go_portal_sdk/portal_agw"
	"github.com/bytedance/sonic"
	"github.com/pborman/uuid"
	"github.com/sanity-io/litter"
	"github.com/thoas/go-funk"
)

func GenerateFilterParam(whereParams []*dimensions.SelectedDimensionInfo) (*string, error) {
	var andParams []string
	for _, andParam := range whereParams {
		var tmp string
		// 没有值的话直接continue
		if len(andParam.SelectedValues) == 0 {
			continue
		}
		var operator string
		if andParam.SelectedOperator == base.OperatorType_IN {
			operator = consts.OperatorTypeIn
		} else if andParam.SelectedOperator == base.OperatorType_NOT_IN {
			operator = consts.OperatorTypeNotIn
		} else { // 目前多维分析参数 暂时只接上面两种
			continue
		}

		// 如果操作符是IN，需要左右括号
		if operator == consts.OperatorTypeIn || operator == consts.OperatorTypeNotIn {
			values := ""
			for j, _ := range andParam.SelectedValues {
				if len(andParam.SelectedValues[j].TypeValue) > 0 {
					// ToDo 金额阈值相关筛选项的处理
					continue
				} else {
					// 如果是string类型，需要加单引号
					val := strings.ReplaceAll(andParam.SelectedValues[j].Code, "'", "\\'")
					values += fmt.Sprintf("'%s'", val)
				}
			}
			id, err := strconv.ParseInt(andParam.Id, 10, 64)
			if err != nil {
				return nil, errors.WithMessage(err, "维度id类型转化失败")
			}
			dim, err := new(dao.DimensionListDao).GetDimensionById(context.Background(), id)
			if err != nil {
				return nil, errors.WithMessage(err, "根据维度ID查询维度失败")
			}
			tmp += fmt.Sprintf("%s %s (%s)", dim.DimColumn, operator, values)
		} else if operator == consts.OperatorTypeArrayHas {
			val := strings.ReplaceAll(andParam.SelectedValues[0].Code, "'", "\\'")
			tmp += fmt.Sprintf("arrayjoin(%s) LIKE '%%%s%%'", andParam.Id, val)
		} else if operator == consts.OperatorTypeLike {
			val := strings.ReplaceAll(andParam.SelectedValues[0].Code, "'", "\\'")
			tmp += fmt.Sprintf("%s LIKE '%%%s%%'", andParam.Id, val)
		} else { // 目前只有等于大于小于的情况，只关注0号位
			value := andParam.SelectedValues[0].Code
			// 如果是string类型，需要加单引号
			val := strings.ReplaceAll(andParam.SelectedValues[0].Code, "'", "\\'")
			value = fmt.Sprintf("'%s'", val)

			tmp += fmt.Sprintf("%s %s %s", andParam.Id, operator, value)
		}
		andParams = append(andParams, tmp)
	}

	if len(andParams) == 0 {
		return nil, nil
	}
	res := strings.Join(andParams, " And ")
	return &res, nil
}

func CheckUserDimension(userDimensionMap map[string]*guard.DimensionValue, dims ...string) bool {
	if len(userDimensionMap) == 0 {
		return false
	}
	for _, d := range dims {
		if _, exist := userDimensionMap[d]; exist {
			return true
		}
	}
	return false
}

func GetStreamUserDimensionMap(ctx context.Context, employeeId *string) (map[string]*guard.DimensionValue, error) {
	if employeeId == nil {
		logs.CtxError(ctx, "[GetStreamUserDimensionMap] employeeId is nil")
		return nil, errors.New("employeeId is nil")
	}
	userDimensionInfo, err := GetUserDimensionWithCache(ctx, *employeeId)
	if err != nil {
		logs.CtxError(ctx, "[GetUserDimensionMap]GetUserDimension Error: %v+", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[GetUserDimensionMap]GetUserDimension userDimensionInfo: %v+", convert.ToJSONString(userDimensionInfo))

	ret := make(map[string]*guard.DimensionValue)
	if userDimensionInfo.Dimension == nil || len(userDimensionInfo.Dimension.Values) == 0 {
		return ret, nil
	}

	for _, v := range userDimensionInfo.Dimension.Values {
		ret[v.Code] = v
	}
	return ret, nil
}

func GetUserDimensionMap(ctx context.Context) (map[string]*guard.DimensionValue, error) {

	var user *models.UserInfo
	user = getEcopUserFromRPCContext(ctx, user)
	//没从上下文里面拿到ecop_user，走agw鉴权
	if user == nil {
		user = portal_agw.GetUserInfo(ctx)
		logs.CtxInfo(ctx, fmt.Sprintf("user info: %v", litter.Sdump(user)))
		if user == nil {
			logs.CtxInfo(ctx, "获取用户信息为空")
			return nil, errors.New("获取用户信息为空")
		}
	}
	if user.EmployeeId == nil {
		logs.CtxInfo(ctx, "获取用户EmployeeId信息为空")
		return nil, errors.New("获取用户EmployeeId信息为空")
	}
	userDimensionInfo, err := GetUserDimensionWithCache(ctx, *user.EmployeeId)
	if err != nil {
		logs.CtxError(ctx, "[GetUserDimensionMap]GetUserDimension Error: %v+", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[GetUserDimensionMap]GetUserDimension userDimensionInfo: %v+", convert.ToJSONString(userDimensionInfo))

	ret := make(map[string]*guard.DimensionValue)
	if userDimensionInfo.Dimension == nil || len(userDimensionInfo.Dimension.Values) == 0 {
		return ret, nil
	}

	for _, v := range userDimensionInfo.Dimension.Values {
		ret[v.Code] = v
	}
	return ret, nil
}

func GetUserDimensionWithCache(ctx context.Context, employeeId string) (*guard.GetUserDimensionResponse, error) {
	// 从redis获取
	var redisKey = consts.ProductAnalysisDataAuth + "_" + convert.ToString(employeeId)
	if env.IsBoe() {
		redisKey = redisKey + "_boe"
	} else if env.IsPPE() {
		redisKey = redisKey + "_ppe"
	}
	userDimensionInfoString, _ := redis.Get(ctx, redisKey)
	if len(userDimensionInfoString) > 0 {
		var userDimensionInfo *guard.GetUserDimensionResponse
		err := json.Unmarshal([]byte(userDimensionInfoString), &userDimensionInfo)
		if err == nil {
			logs.CtxInfo(ctx, "[GetUserDimensionMap]GetUserDimension userDimensionInfo from redis: key: %s, value: %v+", redisKey, convert.ToJSONString(userDimensionInfo))
			return userDimensionInfo, nil
		}
	}
	// 从guard获取
	userDimensionInfo, err := ecom_smartop_guard.GetUserDimension(ctx, employeeId, consts.ProductAnalysisDataAuth)
	if err != nil {
		logs.CtxError(ctx, "[GetUserDimensionMap]GetUserDimension Error: %v+", err)
		return nil, err
	}
	logs.CtxInfo(ctx, "[GetUserDimensionMap]GetUserDimension userDimensionInfo: %v+", convert.ToJSONString(userDimensionInfo))

	//异步存入redis
	go func(ctx context.Context, redisKey string, userDimensionInfo *guard.GetUserDimensionResponse) {
		ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
		defer cancel()
		userDimensionInfoCopy := &guard.GetUserDimensionResponse{}
		_ = copier.CopyWithOption(userDimensionInfoCopy, userDimensionInfo, copier.Option{DeepCopy: true})
		userDimensionInfoByte, err := json.Marshal(userDimensionInfoCopy)
		if err != nil {
			logs.CtxError(ctx, "[GetUserDimensionMap]json.Marshal for redis error: %v", err)
			return
		}
		logs.CtxInfo(ctx, "[GetUserDimensionMap]SetNx to redis userDimensionInfo: key:%s, value: %v", redisKey, convert.ToJSONString(userDimensionInfoCopy))
		_, err = redis.SetNx(ctx, redisKey, string(userDimensionInfoByte), 1*time.Minute)
		if err != nil {
			logs.CtxWarn(ctx, "[GetUserDimensionMap]SetNx to redis error: %v", err)
		}
	}(ctx, redisKey, userDimensionInfo)

	return userDimensionInfo, nil
}

func getEcopUserFromRPCContext(ctx context.Context, user *models.UserInfo) *models.UserInfo {
	//RPC接口可能是 从psm服务端调用，不仅仅是agw http到rpc
	//先检查上下文检查有没有ecop_current_user，有的话不走agw ecop鉴权了
	//上面portal_agw.GetUserInfo只能拿对应agw放的ecop_user但是rpc服务之间也可能有ecop_user
	ecopCurrentUser, exist := metainfo.GetPersistentValue(ctx, "ECOP_CURRENT_USER")
	if exist {
		var ecopUser guard.OpUser
		castErr := json.Unmarshal([]byte(ecopCurrentUser), &ecopUser)
		if castErr == nil {
			user = &models.UserInfo{
				EmployeeId: &ecopUser.EmployeeId,
				UserName:   &ecopUser.UserName,
				Email:      ecopUser.Email,
			}
		}
	}
	return user
}

// 通过 employeeId 获取用户信息
func GetEcopUserByEmployeeId(ctx context.Context, employeeId string) (*guard.OpUser, error) {
	res, err := ecom_smartop_guard.RawCall.GetOpUserByEmployeeId(ctx, &guard.GetOpUserByEmployeeIdRequest{
		EmployeeId: employeeId,
		WithEaInfo: true,
		WithOpenId: true,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetEcopUserByEmployeeId]GetOpUserByEmployeeId Error: %v+", err)
		return nil, err
	}

	return res.OpUser, nil
}

func RPCBatchGetOpUserByEmployeeIds(ctx context.Context, employeeIds []string) ([]*guard.OpUser, error) {
	req := guard.NewBatchGetOpUserByEmployeeIdsRequest()
	req.EmployeeIds = employeeIds
	req.WithEaInfo = true
	resp, err := ecom_smartop_guard.RawCall.BatchGetOpUserByEmployeeIds(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "[RpcBatchGetOpUserByEmployeeIds]调用失败，err=%v+", err)
		return nil, err
	}
	if resp.BaseResp == nil || (resp.BaseResp != nil && resp.BaseResp.StatusCode != 0) {
		logs.CtxError(ctx, "[RpcBatchGetOpUserByEmployeeIds]调用失败")
		return nil, err
	}
	return resp.OpUsers, nil
}

func RPCGetOpUserByEmployeeIds(ctx context.Context, employeeId string) (*guard.OpUser, error) {
	req := guard.NewGetOpUserByEmployeeIdRequest()
	req.EmployeeId = employeeId
	resp, err := ecom_smartop_guard.RawCall.GetOpUserByEmployeeId(ctx, req)
	if err != nil || resp == nil {
		logs.CtxError(ctx, "[RpcGetOpUserByEmployeeIds]调用失败，err=%v+", err)
		return nil, err
	}
	if resp.BaseResp == nil || (resp.BaseResp != nil && resp.BaseResp.StatusCode != 0) {
		logs.CtxError(ctx, "[RpcGetOpUserByEmployeeIds]调用失败")
		return nil, err
	}
	return resp.OpUser, nil
}

func IsCostUser(ctx context.Context) bool {
	if env.IsBoe() {
		return false
	}

	var user *models.UserInfo
	user = getEcopUserFromRPCContext(ctx, user)
	//没从上下文里面拿到ecop_user，走agw鉴权
	if user == nil {
		user = portal_agw.GetUserInfo(ctx)
	}
	logs.CtxInfo(ctx, fmt.Sprintf("user info: %v", litter.Sdump(user)))
	if user == nil {
		return false
	}

	userDimensionMap, err := GetUserDimensionMap(ctx)
	if err != nil {
		return false
	}
	return CheckUserDimension(userDimensionMap, consts.PostCostUserDimension)
}

func GetOperatorEmailFromContext(ctx context.Context) (string, error) {
	if env.IsBoe() {
		return "api-boe", nil
	}
	user := portal_agw.GetUserInfo(ctx)
	logs.CtxInfo(ctx, fmt.Sprintf("user info: %v", litter.Sdump(user)))
	if user == nil {
		return "", errors.New("GetOperatorEmailFromContext, no user info")
	}
	if user.Email == nil {
		return "", errors.New("GetOperatorEmailFromContext, no user email info")
	}
	return *user.Email, nil
}

func GetCurrentUser(ctx context.Context) (user *models.UserInfo, err error) {
	user = portal_agw.GetUserInfo(ctx)
	logs.CtxInfo(ctx, fmt.Sprintf("user info: %v", litter.Sdump(user)))
	if user == nil {
		err = errors.New("GetCurrentUser, no user info")
		return
	}
	if user.Email == nil {
		err = errors.New("GetCurrentUser, no user email info")
	}
	return
}

func TransJson2Struct(ctx context.Context, jsonStr string, v interface{}) error {
	if len(jsonStr) <= 0 {
		return nil
	}
	var myConfig = sonic.Config{
		UseNumber: true,
	}.Froze()
	reader := strings.NewReader(jsonStr)
	dc := myConfig.NewDecoder(reader)
	err := dc.Decode(&v)
	if err != nil {
		logs.CtxWarn(ctx, "TransJson2Struct failed.cause = %+v,jsonStr = %+v", err, jsonStr)
		return err
	}
	return nil
}

func If[T any](isTrue bool, trueV, falseV T) T {
	if isTrue {
		return trueV
	}
	return falseV
}

// GetNewestDay 从传入的逻辑表中获取就绪时间最晚的一张表的时间
func GetNewestDay(ctx context.Context, logicTables ...string) (string, error) {
	// 从ch拉取时间分区
	minNewTime, _ := time.Parse(consts.FmtDate, "30000101")
	for _, logicTable := range logicTables {
		resp, err := ecom_navigator_rpc.GetProdDateByLogTable(ctx, logicTable, nil)
		if err != nil {
			logs.CtxError(ctx, err.Error())
			return "", errors.WithMessage(err, "获取时间分区失败")
		}
		value := resp.GetFieldsToPDate()["date"]
		if value == "" {
			value = resp.GetFieldsToPDate()["p_date"]
		}
		logs.CtxInfo(ctx, "GetNewestDay logicTable:%s, value:%s", logicTable, value)
		temp, _ := time.Parse(consts.FmtDateHHMMSS, value)
		if temp.Before(minNewTime) {
			minNewTime = temp
		}
	}
	return minNewTime.Format(consts.FmtDate), nil
}

// GetOldestAndNewestDate 从传入的逻辑表中获取就绪时间最晚的一张表的时间
func GetOldestAndNewestDate(ctx context.Context, logicTables []string, rangeDate int) (string, string, error) {
	// 从ch拉取时间分区
	minNewTime, _ := time.Parse(consts.FmtDateSlash, "3000-01-01")
	for _, logicTable := range logicTables {
		resp, err := ecom_navigator_rpc.GetProdDateByLogTable(ctx, logicTable, nil)
		if err != nil {
			logs.CtxError(ctx, err.Error())
			return "", "", errors.WithMessage(err, "获取时间分区失败")
		}
		// 部分底表的时间分区字段为date，有些为p_date，这里做下预防
		value := resp.GetFieldsToPDate()["date"]
		if value == "" {
			value = resp.GetFieldsToPDate()["p_date"]
		}
		temp, _ := time.Parse(consts.FmtDateHHMMSS, value)
		if temp.Before(minNewTime) {
			minNewTime = temp
		}
	}
	newest := minNewTime.Format(consts.FmtDateSlash)
	oldest := minNewTime.AddDate(0, 0, -rangeDate+1).Format(consts.FmtDateSlash)
	// 价格力相关暂时只支持03-01后的日期选择
	if oldest < "2024-03-01" {
		oldest = "2024-03-01"
	}
	return oldest, newest, nil
}

func AddTableNameAlias(tableName, alias string) string {
	return tableName + " " + alias
}

func GetBoolPtr(flag bool) *bool {
	return &flag
}

func GetOperatorEmployeeIdFromContext(ctx context.Context) (string, error) {
	if env.IsBoe() {
		return "api-boe", nil
	}
	user := portal_agw.GetUserInfo(ctx)
	logs.CtxInfo(ctx, fmt.Sprintf("user info: %v", litter.Sdump(user)))
	if user == nil {
		return "", errors.New("GetOperatorEmployeeIdFromContext, no user info")
	}
	if user.EmployeeId == nil {
		return "", errors.New("GetOperatorEmployeeIdFromContext, no employee id info")
	}
	employeeId := convert.ToString(user.EmployeeId)
	return employeeId, nil
}

// 根据ctx获取用户信息
func GetUserInfo(ctx context.Context) *models.UserInfo {
	var user *models.UserInfo
	if env.IsBoe() {
		// boe环境写死用户信息
		var (
			email      = "huangdonglu.jackson@bytedance.com"
			userName   = "huangdonglu.jackson"
			employeeId = "2692293"
		)

		return &models.UserInfo{
			Email:      &email,
			UserName:   &userName,
			EmployeeId: &employeeId,
		}
	}

	user = portal_agw.GetUserInfo(ctx)

	if user == nil {
		userInfo, ok := ctx.Value(consts.CtxUserInfo).(*guard.OpUser)
		if ok && userInfo != nil {
			copier.Copy(user, userInfo)
		}
	}
	return user
}

func MapToStruct(ctx context.Context, mapObject map[string]interface{}, target interface{}) error {
	jsonData, err := sonic.Marshal(mapObject)
	if err != nil {
		logs.CtxError(ctx, "Error occurred during marshaling. Error: %s", err.Error())
		return err
	}
	err = sonic.Unmarshal(jsonData, &target)
	if err != nil {
		logs.CtxError(ctx, "Error occurred during unmarshaling. Error: %s", err.Error())
	}
	return nil
}

func StructToMap(obj interface{}) (map[string]interface{}, error) {
	result := make(map[string]interface{})
	v := reflect.ValueOf(obj)
	if v.Kind() == reflect.Ptr {
		v = v.Elem()
	}

	// 确保我们处理的是结构体
	if v.Kind() != reflect.Struct {
		return nil, fmt.Errorf("expected a struct, received %v", v.Kind())
	}

	t := v.Type()
	for i := 0; i < v.NumField(); i++ {
		field := t.Field(i)
		fieldValue := v.Field(i)

		// 检查切片是否为空
		if fieldValue.Kind() == reflect.Slice && fieldValue.IsNil() {
			continue // 如果切片为空，则跳过此字段
		}

		jsonTag := field.Tag.Get("json")
		if jsonTag == "" {
			jsonTag = field.Name // 如果没有json标签，使用字段名
		} else {
			// 处理带有逗号的标签，如 `json:"name,omitempty"`
			jsonTag = strings.Split(jsonTag, ",")[0]
		}

		// 只有当切片不为空时，才添加到结果中
		if !(fieldValue.Kind() == reflect.Slice && fieldValue.Len() == 0) {
			result[jsonTag] = fieldValue.Interface()
		}
	}

	return result, nil
}

func GenRedisKey(moduleName string) string {
	return fmt.Sprintf("%s_%s", moduleName, strconv.Itoa(int(time.Now().Unix()))+"_"+uuid.NewUUID().String())
}

func TrimRightRepeat(s, cutset string) string {
	if !strings.HasSuffix(s, cutset) {
		return s
	}

	s = strings.TrimRight(s, cutset)
	return TrimRightRepeat(s, cutset)
}

func GetDiffStr(info *analysis.DiffExtraInfo) (diff, ratio string) {
	diff = "-"
	ratio = "-"
	if info != nil {
		diff = framework_udf.DeleteZeroSuffix(strconv.FormatFloat(info.Diff, 'f', 5, 64))
		if info.DiffRatio == consts.MagicNumber {
			ratio = "0%"
		} else {
			ratio = fmt.Sprintf("%.2f%%", info.DiffRatio*100)
		}
	}
	return diff, ratio
}

func TransformBoolToString(flag *bool) string {
	if flag == nil {
		return "否"
	}
	if *flag {
		return "是"
	}
	return "否"
}

func TransformIntArrToStringArr(intArray *[]int64) []string {
	strArray := make([]string, len(*intArray))

	// 遍历整数数组，将每个整数转换为字符串并存储在字符串数组中
	for i, num := range *intArray {
		strArray[i] = convert.ToString(num)
	}

	return strArray
}

func GetHanLen(str string) (int, int) {
	var hanCount, allCount int
	for _, v := range str {
		if unicode.Is(unicode.Han, v) {
			hanCount++
		}
		allCount++
	}
	return hanCount, allCount
}

func GetErrorMsg(errStr, defaultStr string) string {
	hanCount, allCount := GetHanLen(errStr)
	if allCount == 0 || convert.ToFloat64(hanCount)/convert.ToFloat64(allCount) < 0.6 {
		return defaultStr
	}
	return errStr
}

func GetEnv() string {
	if env.IsBoe() {
		return "boe"
	} else if env.IsPPE() {
		return "ppe"
	} else {
		return "prod"
	}
}

func ConvertArrayToMarkdownTable(data [][]interface{}) (string, error) {
	if len(data) == 0 {
		return "", nil
	}

	var sb strings.Builder

	// Process and write the header
	header := make([]string, len(data[0]))
	for i, item := range data[0] {
		strValue, err := convert.ToStringE(item)
		if err != nil {
			return "", fmt.Errorf("error in header conversion at index %d: %v", i, err)
		}
		header[i] = strValue
	}
	sb.WriteString("| " + strings.Join(header, " | ") + " |\n")

	// Write the separator line
	separator := make([]string, len(header))
	for i := range separator {
		separator[i] = "---"
	}
	sb.WriteString("| " + strings.Join(separator, " | ") + " |\n")

	// Process and write each row
	for _, row := range data[1:] {
		stringRow := make([]string, len(row))
		for j, item := range row {
			strValue, err := convert.ToStringE(item)
			if err != nil {
				return "", fmt.Errorf("error in row conversion at column %d: %v", j, err)
			}
			stringRow[j] = strValue
		}
		sb.WriteString("| " + strings.Join(stringRow, " | ") + " |\n")
	}

	return sb.String(), nil
}

func ConvertStringArrayToMarkdownTable(data [][]string) (string, error) {
	if len(data) == 0 {
		return "", nil
	}

	// 将[][]string转换为[][]interface{}
	interfaceData := make([][]interface{}, len(data))
	for i, row := range data {
		interfaceRow := make([]interface{}, len(row))
		for j, col := range row {
			interfaceRow[j] = col
		}
		interfaceData[i] = interfaceRow
	}

	return ConvertArrayToMarkdownTable(interfaceData)
}

func ConvertFourthQuadrantConfToMarkdown(quadrantConf *prod_review.QuadrantPartitionParams, bizInfoList []*dao.BizInfo, dimMap map[int64]*dao.DimensionInfo, targetMetaList []*dimensions.TargetMetaInfo) string {
	if quadrantConf == nil {
		return ""
	}

	lines := make([]string, 0)
	lines = append(lines, "|")
	// 横轴配置
	lines = append(lines, fmt.Sprintf("横轴配置指标名称：%s", quadrantConf.XAxisConfig.AxisTargetName))
	lines = append(lines, fmt.Sprintf("横轴配置指标值类型：%s", quadrantConf.XAxisConfig.ValueType.String()))
	lines = append(lines, fmt.Sprintf("横轴配置指标比较条件：%s", quadrantConf.XAxisConfig.AxisCondition.String()))
	lines = append(lines, fmt.Sprintf("横轴配置指标分割方式：%s", quadrantConf.XAxisConfig.AxisSegmentation.String()))
	lines = append(lines, fmt.Sprintf("横轴配置指标分割值：%f", quadrantConf.XAxisConfig.AxisSegmentationValue))
	if quadrantConf.YAxisConfig == nil {
		return ""
	}
	lines = append(lines, fmt.Sprintf("纵轴配置指标名称：%s", quadrantConf.YAxisConfig.AxisTargetName))
	lines = append(lines, fmt.Sprintf("纵轴配置指标值类型：%s", quadrantConf.YAxisConfig.ValueType.String()))
	lines = append(lines, fmt.Sprintf("纵轴配置指标比较条件：%s", quadrantConf.YAxisConfig.AxisCondition.String()))
	lines = append(lines, fmt.Sprintf("纵轴配置指标分割方式：%s", quadrantConf.YAxisConfig.AxisSegmentation.String()))
	lines = append(lines, fmt.Sprintf("纵轴配置指标分割值：%f", quadrantConf.YAxisConfig.AxisSegmentationValue))

	return strings.Join(lines, "\n")
}

func ConvertSupplyBubbleConfToMarkdown(bubbleConf *prod_review.BubbleChartParams, bizInfoList []*dao.BizInfo, dimMap map[int64]*dao.DimensionInfo, targetMetaList []*dimensions.TargetMetaInfo) string {
	if bubbleConf == nil || bubbleConf.XAxis == nil || bubbleConf.YAxis == nil {
		return ""
	}

	lines := make([]string, 0)
	lines = append(lines, "|")
	// 横轴配置
	lines = append(lines, fmt.Sprintf("横轴配置指标名称：%s", bubbleConf.XAxis.AxisTargetName))
	lines = append(lines, fmt.Sprintf("横轴配置指标值类型：%s", bubbleConf.XAxis.ValueType.String()))
	// 纵轴配置
	lines = append(lines, fmt.Sprintf("纵轴配置指标名称：%s", bubbleConf.YAxis.AxisTargetName))
	lines = append(lines, fmt.Sprintf("纵轴配置指标值类型：%s", bubbleConf.YAxis.ValueType.String()))

	lines = append(lines, fmt.Sprintf("象限划分配置：%s", bubbleConf.AxisSegmentation.String()))

	return strings.Join(lines, "\n")
}

func ConvertBaseReqToMarkdown(baseReq *dimensions.ProductAnalysisBaseStruct, bizInfoList []*dao.BizInfo, dimMap map[int64]*dao.DimensionInfo, targetMetaList []*dimensions.TargetMetaInfo) string {
	if baseReq == nil {
		return ""
	}

	lines := make([]string, 0)

	// 业务线
	bizInfo, ok := funk.Find(bizInfoList, func(info *dao.BizInfo) bool {
		return info != nil && info.BizType == baseReq.BizType
	}).(*dao.BizInfo)
	if bizInfo != nil && ok {
		lines = append(lines, fmt.Sprintf("业务线：%s", bizInfo.BizName))
	}

	// 分析周期
	lines = append(lines, fmt.Sprintf("分析周期：%s - %s", baseReq.StartDate, baseReq.EndDate))

	// 对比周期
	lines = append(lines, fmt.Sprintf("对比周期：%s - %s", baseReq.CompareStartDate, baseReq.CompareEndDate))

	// 筛选维度
	validDimensions, ok := funk.Filter(baseReq.Dimensions, func(dim *dimensions.SelectedDimensionInfo) bool {
		return len(dim.SelectedValues) > 0
	}).([]*dimensions.SelectedDimensionInfo)
	if ok && len(validDimensions) > 0 {
		lines = append(lines, "筛选维度：")
		for _, dim := range validDimensions {
			selectedValues, _ := funk.Map(dim.SelectedValues, func(val *dimensions.EnumElement) string {
				if len(val.TypeValue) > 0 {
					// 针对xxID类型的维度进行特化处理
					return strings.Join(val.TypeValue, ", ")
				}
				return val.Name
			}).([]string)

			// 处理维度名称
			dimName := dim.Name
			if dimName == "" {
				dimInfo, ok := dimMap[convert.ToInt64(dim.Id)]
				if ok && dimInfo != nil {
					dimName = dimInfo.ShowName
				}
			}

			if len(selectedValues) > 10 {
				// 处理超过10个枚举值的情况
				top10Values := selectedValues[:10]
				lines = append(lines, fmt.Sprintf("- 【%s】：%s 等 %d 个", dimName, strings.Join(top10Values, "、"), len(selectedValues)))
			} else {
				lines = append(lines, fmt.Sprintf("- 【%s】：%s", dimName, strings.Join(selectedValues, "、")))
			}
		}
		// 添加两个换行符
		lines = append(lines, "")
	}

	// 下钻维度
	if len(baseReq.GroupAttrs) > 0 {
		lines = append(lines, "下钻维度：")
		for _, dim := range baseReq.GroupAttrs {
			groupDimName := ""
			if dim.DimInfo != nil {
				groupDimName = dim.DimInfo.Name
			}
			if groupDimName == "" {
				dimInfo, ok := dimMap[convert.ToInt64(dim.DimInfo.Id)]
				if ok && dimInfo != nil {
					groupDimName = dimInfo.ShowName
				}
			}

			if dim.Value != nil && dim.Value.Name != "" {
				lines = append(lines, fmt.Sprintf("- 【%s】：%s", groupDimName, dim.Value.Name))
			} else {
				lines = append(lines, fmt.Sprintf("- 【%s】", groupDimName))
			}
		}
		// 添加两个换行符
		lines = append(lines, "")
	}

	// 指标阈值筛选
	if len(baseReq.ThresholdAttrs) > 0 {
		lines = append(lines, "指标阈值筛选：")
		for _, attr := range baseReq.ThresholdAttrs {
			// 查找指标名称
			var targetName string
			targetMeta, ok := funk.Find(targetMetaList, func(target *dimensions.TargetMetaInfo) bool {
				return target.Name == attr.Key
			}).(*dimensions.TargetMetaInfo)
			if ok && targetMeta != nil {
				targetName = targetMeta.DisplayName
			}

			var thresholdText string
			switch attr.Type {
			case dimensions.ThresholdType_TOP_THRESHOLD:
				thresholdText = fmt.Sprintf("Top%d", attr.TopN)
			case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
				thresholdText = fmt.Sprintf("贡献度 top %d%%", attr.TopN)
			case dimensions.ThresholdType_ACC_THRESHOLD:
				if attr.AccThreshold != nil {
					var operatorLabel string
					switch attr.AccThreshold.Operator {
					case base.OperatorType_IN:
						operatorLabel = "包含"
					case base.OperatorType_NOT_IN:
						operatorLabel = "不包含"
					case base.OperatorType_GREATER_EQUAL_THAN:
						operatorLabel = "大于等于"
					case base.OperatorType_LESS_EQUAL_THAN:
						operatorLabel = "小于等于"
					case base.OperatorType_GREATER_THAN:
						operatorLabel = "大于"
					case base.OperatorType_LESS_THAN:
						operatorLabel = "小于"
					case base.OperatorType_EQUAL:
						operatorLabel = "等于"
					default:
						operatorLabel = ""
					}
					thresholdText = fmt.Sprintf("精准阈值 %s %v", operatorLabel, attr.AccThreshold.Threshold)
				}
			default:
				// 其他类型不处理
			}

			if targetName != "" && thresholdText != "" {
				lines = append(lines, fmt.Sprintf("- 【%s】：%s", targetName, thresholdText))
			}
		}
		// 添加两个换行符
		lines = append(lines, "")
	}

	// 指标阈值筛选逻辑关系
	if baseReq.ThresholdExpr != nil {
		logicRelation := "且"
		if *baseReq.ThresholdExpr == base.LogicalExprType_OR {
			logicRelation = "或"
		}
		lines = append(lines, fmt.Sprintf("指标阈值筛选逻辑关系：%s", logicRelation))
	}

	return strings.Join(lines, "\n")
}

// UnescapeUnicode 将字符串中的 Unicode 转义序列（如 \u4fdd）转换为对应的字符
func UnescapeUnicode(s string) string {
	// 正则匹配 Unicode 转义序列
	re := regexp.MustCompile(`\\u([0-9a-fA-F]{4})`)

	// 替换匹配项
	result := re.ReplaceAllStringFunc(s, func(match string) string {
		hexPart := match[2:6] // 提取四位十六进制
		code, _ := strconv.ParseInt(hexPart, 16, 32)
		return string(rune(code))
	})

	return result
}

/**
 * 二维数组转列
 * 输入：
 * [
 * 	["column1", "column2", "column3"],
 * 	[1, 2, 3],
 * 	[4, 5, 6]
 * ]
 * 输出：
 * map[string][]interface{}{
 * 	"column1": {1, 4},
 * 	"column2": {2, 5},
 * 	"column3": {3, 6},
 * }
 */
func TransposeToColumnsMap(data [][]interface{}) map[string][]interface{} {
	if len(data) == 0 {
		return nil
	}

	// 第一行作为列名
	headers := data[0]
	result := make(map[string][]interface{}, len(headers))

	// 初始化 map key
	for _, h := range headers {
		key, ok := h.(string)
		if !ok {
			// 如果列名不是字符串，跳过或报错
			continue
		}
		result[key] = []interface{}{}
	}

	// 遍历剩余行，按列名归集数据
	for _, row := range data[1:] {
		for colIndex, val := range row {
			key, ok := headers[colIndex].(string)
			if !ok {
				continue
			}
			result[key] = append(result[key], val)
		}
	}

	return result
}
func CopyMap(src map[string]interface{}) map[string]interface{} {
	dst := make(map[string]interface{}, len(src))
	for k, v := range src {
		dst[k] = v
	}
	return dst
}

func SortMultiDimTableRows(ctx context.Context, rows []*common_response.RowData) {
	if len(rows) == 0 {
		return
	}
	sort.SliceStable(rows, func(i, j int) bool {
		if rows[i] == nil || rows[j] == nil {
			return false
		}
		return rows[i].DimensionCode < rows[j].DimensionCode
	})
	for _, row := range rows {
		SortMultiDimTableRows(ctx, row.ChildrenRows)
	}
	logs.CtxInfo(ctx, "[SortMultiDimTableRows] SortMultiDimTableRows, rows=%v", rows)
}

func SortMultiDimTableTargets(ctx context.Context, resp *common_response.MultiDimTableData) {
	if resp == nil {
		return
	}
	SortRowDataDataTargets(resp.AllTotal)
	SortRowDataDataTargets(resp.Total)
	for _, row := range resp.Rows {
		SortRowDataDataTargets(row)
	}
	logs.CtxInfo(ctx, "[sortMultiDimTableData] sortMultiDimTableData, resp=%v", resp)
}

// SortRowDataDataTargets 按DisplayOrder排序
func SortRowDataDataTargets(data *common_response.RowData) {
	if data == nil {
		return
	}
	if len(data.TargetList) == 0 {
		return
	}
	sort.Slice(data.TargetList, func(i, j int) bool {
		if data.TargetList[i] == nil || data.TargetList[j] == nil {
			return false
		}
		return data.TargetList[i].DisplayOrder < data.TargetList[j].DisplayOrder
	})
	for _, row := range data.ChildrenRows {
		SortRowDataDataTargets(row)
	}
}

func ExtractUsernameFromEmail(email string) string {
	// 正则表达式，匹配@符号前面的所有字符
	regex := regexp.MustCompile(`^([^@]+)@`)
	matches := regex.FindStringSubmatch(email)
	if len(matches) > 1 {
		return matches[1]
	}
	return ""
}

func GenerateTOSPath(ctx context.Context) string {
	userEmail, err := GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, "GenerateTOSPath error, %s", err.Error())
		return ""
	}

	userName := ExtractUsernameFromEmail(userEmail)
	filename := fmt.Sprintf("%s_ret.csv", userName)
	timestamp := time.Now().Format("20060102150405")
	rand.NewSource(time.Now().UnixNano())
	key := fmt.Sprintf("analysis_pool_product/%d%s_%s", rand.Intn(10000), timestamp, filename)

	return key
}

func RandInt(v int64) int {
	n, err := cryptoRand.Int(cryptoRand.Reader, big.NewInt(v))
	if err != nil {
		return 0
	}
	return int(n.Int64())
}

func TransToAnySlice(tags []string) []any {
	tmp := make([]any, 0)
	for _, tag := range tags {
		tmp = append(tmp, tag)
	}
	return tmp
}

// 辅助函数：格式化变化率
func FormatRatio(ratio float64) string {
	// 保留两位小数
	formatted := fmt.Sprintf("%.2f%%", ratio*100)
	// 添加符号
	if ratio > 0 {
		formatted = fmt.Sprintf("+%s", formatted)
	}
	return formatted
}

func GetStartDateAndEndDate(ctx context.Context, endDate string, dateRule *dimensions.DateRule) (string, string, error) {
	if dateRule.Type == dimensions.DateRuleType_AbsoluteDateRange {
		return dateRule.GetStartDate(), dateRule.GetEndDate(), nil
	} else if dateRule.Type == dimensions.DateRuleType_RelativeDateRange {
		// 解析结束日期，计算起始日期
		endDateObj, err := time.Parse("2006-01-02", endDate)
		if err != nil {
			logs.CtxError(ctx, "GetStartDateAndEndDate time.Parse err=%v+, endDate=%v", err, endDate)
			return "", "", err
		}
		// 计算起始日期：结束日期向前推navigationAttr.DateRule.Day天
		day := *dateRule.Day - 1
		startDateObj := endDateObj.AddDate(0, 0, int(-day))
		startDate := startDateObj.Format("2006-01-02")
		return startDate, endDate, nil
	}

	return dateRule.GetStartDate(), dateRule.GetEndDate(), nil
}
