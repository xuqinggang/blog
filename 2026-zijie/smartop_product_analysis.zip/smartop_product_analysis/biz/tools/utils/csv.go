package utils

import (
	"bytes"
	"context"
	"encoding/csv"
	"errors"
	"fmt"

	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/stone/math"
	"github.com/saintfish/chardet"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
)

func ParseContentToCSVFormat(ctx context.Context, content []byte) ([][]string, error) {
	encoding, _ := detectCSVEncoding(content)
	if encoding == "GBK" {
		//转成utf8
		utf8Bytes, err := gbkToUtf8(content)
		if err != nil {
			logs.CtxError(ctx, "[parseContentToCSVFormat] gbkToUtf8(content) error, err=%v", err)
		} else {
			content = utf8Bytes
		}
	}

	content = removeLeadingZWNBSP(content)
	csvReader := csv.NewReader(bytes.NewReader(content))
	records, err := csvReader.ReadAll()
	if err != nil {
		logs.CtxError(ctx, "[parseContentToCSVFormat] csv reader error, err=%v", err)
		return nil, err
	}

	return ProcessAndValidateCsv(records)
}

func ProcessAndValidateCsv(records [][]string) ([][]string, error) {
	// 过滤所有行都为空的列
	if len(records) > 0 {
		// 确定每列是否全为空
		colCount := len(records[0])
		emptyCols := make([]bool, colCount)
		for i := range emptyCols {
			emptyCols[i] = true // 假设列是空的，直到找到非空值
		}

		// 检查每一列
		for _, row := range records {
			for i := 0; i < colCount && i < len(row); i++ {
				if row[i] != "" {
					emptyCols[i] = false // 找到非空值，标记该列不为空
				}
			}
		}

		// 创建新的记录，排除全空的列
		var filteredRecords [][]string
		for _, row := range records {
			var newRow []string
			for i := 0; i < colCount && i < len(row); i++ {
				if !emptyCols[i] {
					newRow = append(newRow, row[i])
				}
			}
			filteredRecords = append(filteredRecords, newRow)
		}
		records = filteredRecords
	}

	var header, firstRow []string

	//判断csv文件是否合法
	if len(records) > 0 {
		header = records[0]
		//header不能有空字符串
		for _, r := range header {
			if len(r) == 0 {
				return nil, errors.New("表头不能存在空列名")
			}
		}
	}
	if len(records) > 1 {
		firstRow = records[1]
	}

	if len(header) != len(firstRow) {
		return nil, errors.New("表头和数据列数量不匹配")
	}

	return records, nil
}

// 移除文档开头的 ZWNBSP（UTF-8 BOM: 0xEF 0xBB 0xBF）
func removeLeadingZWNBSP(content []byte) []byte {
	// UTF-8 BOM 的字节序列是 0xEF 0xBB 0xBF，对应 U+FEFF
	if len(content) >= 3 && content[0] == 0xEF && content[1] == 0xBB && content[2] == 0xBF {
		return content[3:] // 移除开头的 3 个字节（BOM）
	}
	return content // 无 BOM 则返回原内容
}

// 判断CSV文件编码（UTF-8或GBK）
func detectCSVEncoding(content []byte) (string, error) {
	// 读取部分内容（前4096字节足够检测编码）
	data := content[0:math.MinInt(4096, len(content))]

	// 检测编码
	detector := chardet.NewTextDetector()
	result, err := detector.DetectBest(data)
	if err != nil {
		return "", fmt.Errorf("编码检测失败：%v", err)
	}

	// 特殊处理：GBK在检测结果中可能显示为"GB-18030"（兼容GBK）
	if result.Charset == "GB-18030" {
		return "GBK", nil
	}

	// 返回检测到的编码（如"UTF-8"）
	return result.Charset, nil
}

// gbkToUtf8 将GBK编码的byte数组转换为UTF-8编码的byte数组
func gbkToUtf8(gbkBytes []byte) ([]byte, error) {
	// 创建GBK解码器
	decoder := simplifiedchinese.GBK.NewDecoder()

	// 使用transform.Transform将GBK字节流转换为UTF-8
	utf8Bytes, _, err := transform.Bytes(decoder, gbkBytes)
	if err != nil {
		return nil, fmt.Errorf("GBK转UTF-8失败：%v", err)
	}

	return utf8Bytes, nil
}
