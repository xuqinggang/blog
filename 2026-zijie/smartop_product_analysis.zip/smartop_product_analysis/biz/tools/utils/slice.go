package utils

import (
	"strconv"
	"strings"
)

// GetImpressI64Slice int64 slice 去重
func GetImpressI64Slice(arr []int64) []int64 {
	m := make(map[int64]struct{})
	result := make([]int64, 0)
	for _, v := range arr {
		if _, ok := m[v]; ok {
			continue
		} else {
			m[v] = struct{}{}
			result = append(result, v)
		}
	}
	return result
}

// GetImpressStrSlice string slice 去重
func GetImpressStrSlice(arr []string) []string {
	m := make(map[string]struct{})
	result := make([]string, 0)
	for _, v := range arr {
		if _, ok := m[v]; ok {
			continue
		} else {
			m[v] = struct{}{}
			result = append(result, v)
		}
	}
	return result
}

// SliceString2Int64 str转int
func SliceString2Int64(ss []string) []int64 {
	ret := make([]int64, len(ss))
	for i, s := range ss {
		ret[i], _ = strconv.ParseInt(s, 10, 64)
	}
	return ret
}

// String2Int64 str转int
func String2Int64(s string) (int64, error) {
	ret, err := strconv.ParseInt(s, 10, 64)
	return ret, err
}

// Int642String int转str
func Int642String(i int64) string {
	return strconv.FormatInt(i, 10)
}

// SliceInt642String int转str
func SliceInt642String(vs []int64) []string {
	ret := make([]string, len(vs))
	for i, v := range vs {
		ret[i] = strconv.FormatInt(v, 10)
	}
	return ret
}

// IsInInt64Slice .
func IsInInt64Slice(target int64, items []int64) bool {
	for _, item := range items {
		if target == item {
			return true
		}
	}
	return false
}

// IsInStringSlice .
func IsInStringSlice(target string, items []string) bool {
	for _, item := range items {
		if target == item {
			return true
		}
	}
	return false
}

func String2List(ss string, sep string) []string {
	res := make([]string, 0)
	if len(ss) == 0 {
		return res
	}

	if len(sep) == 0 {
		return []string{ss}
	}

	return strings.Split(ss, sep)
}

func List2String(items []string, sep string) string {
	return strings.Join(items, sep)
}

func CutSLice(data []int64, shareNums int) [][]int64 {
	// 计算数组的长度和元素总数
	dataLen := len(data)
	resSlice := make([][]int64, 0)
	if dataLen == 0 {
		return resSlice
	}

	for i := 0; i < dataLen; i += shareNums {
		endIndex := i + shareNums
		if endIndex > dataLen {
			endIndex = dataLen
		}
		resSlice = append(resSlice, data[i:endIndex])
	}

	// 返回分组结果
	return resSlice
}

func Contains(s []int64, e int64) bool {
	for _, a := range s {
		if a == e {
			return true
		}
	}
	return false
}
