package utils

import (
	"context"
	"time"

	"code.byted.org/gopkg/logs/v2"
)

// PollingConfig 轮询配置结构体
type PollingConfig struct {
	// PollInterval 轮询间隔
	PollInterval time.Duration
	// MaxPollingTime 最大轮询时间
	MaxPollingTime time.Duration
	// MaxPollingAttempts 最大轮询尝试次数
	MaxPollingAttempts int
}

// PollingResult 轮询结果结构体
type PollingResult struct {
	// Completed 是否完成轮询
	Completed bool
	// TimedOut 是否超时
	TimedOut bool
	// Attempts 尝试次数
	Attempts int
	// Duration 轮询持续时间
	Duration time.Duration
}

// PollingCondition 轮询条件函数类型
type PollingCondition func(ctx context.Context) (bool, error)

// PollingAction 轮询操作函数类型
type PollingAction func(ctx context.Context) error

// PollUntil 通用的轮询方法，支持配置轮询时间间隔、失败重试时间间隔、最大轮询时间和次数
// condition: 轮询条件函数，返回true表示轮询完成
// action: 轮询操作函数，执行具体的轮询操作
// config: 轮询配置
func PollUntil(ctx context.Context, condition PollingCondition, action PollingAction, config PollingConfig) PollingResult {
	result := PollingResult{
		Completed: false,
		TimedOut:  false,
		Attempts:  0,
		Duration:  0,
	}

	startTime := time.Now()

	for {
		// 检查轮询条件
		completed, err := condition(ctx)
		if err != nil {
			logs.CtxWarn(ctx, "[PollUntil] condition check failed, err: %v", err)
			// 条件检查失败，继续轮询
		} else if completed {
			result.Completed = true
			result.Duration = time.Since(startTime)
			logs.CtxInfo(ctx, "[PollUntil] polling completed successfully, attempts: %d, duration: %v",
				result.Attempts, result.Duration)
			break
		}

		// 检查是否超时或超过最大尝试次数
		result.Attempts++
		result.Duration = time.Since(startTime)

		if result.Duration > config.MaxPollingTime || result.Attempts > config.MaxPollingAttempts {
			result.TimedOut = true
			logs.CtxWarn(ctx, "[PollUntil] polling timeout or max attempts reached, attempts: %d, duration: %v",
				result.Attempts, result.Duration)
			break
		}

		// 执行轮询操作
		if err := action(ctx); err != nil {
			logs.CtxWarn(ctx, "[PollUntil] action failed, attempt: %d, err: %v", result.Attempts, err)
			// 操作失败，继续轮询
		}

		// 等待下一次轮询
		time.Sleep(config.PollInterval)
	}

	return result
}
