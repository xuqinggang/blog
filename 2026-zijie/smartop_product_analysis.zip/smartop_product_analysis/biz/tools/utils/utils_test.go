package utils

import (
	"fmt"
	"testing"
)

func TestTrimRightRepeat(t *testing.T) {
	fmt.Println(TrimRightRepeat("sfewf===", "="))
}

func TestGetHanLen(t *testing.T) {
	input := "报错信息是dfwefewfwe  fwewef e "
	fmt.Println(GetHanLen(input))
}
