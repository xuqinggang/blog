package utils

import (
	"context"
	"sync"
	"time"

	"golang.org/x/sync/semaphore"
)

// AsyncCaller 高性能异步方法调用，支持超时控制、错误检查、自动recover
// 返回值可【多次获取】，经测试性能与直接使用 WaitGroup、Channel 一致
func AsyncCaller[T any](fn func(v any) (T, error)) Caller[T] {
	return &caller[T]{
		fn: fn,
	}
}

// Caller 异步调用器
type Caller[T any] interface {
	String() string
	SetTimeout(time.Duration) Caller[T]
	SetSemaphore(weighted *semaphore.Weighted) Caller[T]
	Call(v any) Result[T]
}

// Result 异步调用结果
type Result[T any] interface {
	String() string
	Value() T
	Error() error
	Timeout() time.Duration
	Duration() time.Duration
	Timeouted() bool
	Recovered() any
	Success() bool
}

// 实现了 Caller 和 Result
type caller[T any] struct {
	fn        func(v any) (T, error)
	timeout   time.Duration
	weighted  *semaphore.Weighted
	duration  time.Duration
	wait      sync.WaitGroup
	value     T
	error     error
	recovered any
	timeouted bool
}

func (c *caller[T]) String() string {
	return "async caller"
}

func (c *caller[T]) SetSemaphore(weighted *semaphore.Weighted) Caller[T] {
	c.weighted = weighted
	return c
}

func (c *caller[T]) SetTimeout(timeout time.Duration) Caller[T] {
	c.timeout = timeout
	return c
}

func (c *caller[T]) Timeout() time.Duration {
	return c.timeout
}

func (c *caller[T]) Value() T {
	c.wait.Wait()
	return c.value
}

func (c *caller[T]) Error() error {
	c.wait.Wait()
	return c.error
}

func (c *caller[T]) Duration() time.Duration {
	c.wait.Wait()
	return c.duration
}

func (c *caller[T]) Timeouted() bool {
	c.wait.Wait()
	return c.timeouted
}

func (c *caller[T]) Recovered() any {
	c.wait.Wait()
	return c.recovered
}

func (c *caller[T]) Success() bool {
	c.wait.Wait()
	return !c.timeouted && c.recovered == nil && c.error == nil
}

func (c *caller[T]) Call(v any) Result[T] {
	if c.weighted != nil {
		err := c.weighted.Acquire(context.Background(), 1)
		if err != nil {
			c.error = err
			return c
		}
	}

	c.wait.Add(1)
	if c.timeout > 0 {
		// 只执行一次结束逻辑
		var once sync.Once
		go func() {
			start := time.Now()
			defer func() {
				if r := recover(); r != nil {
					c.recovered = r
				}
				c.duration = time.Since(start)
			}()
			c.value, c.error = c.fn(v)
			// 正常结束
			once.Do(c.afterFunc)
		}()

		time.AfterFunc(c.timeout, func() {
			// 超时结束
			once.Do(func() {
				c.timeouted = true
				c.duration = c.timeout
				c.afterFunc()
			})
		})

	} else {
		go func() {
			start := time.Now()
			defer func() {
				if r := recover(); r != nil {
					c.recovered = r
				}
				c.duration = time.Since(start)
			}()
			c.value, c.error = c.fn(v)
			c.afterFunc()
		}()
	}
	return c
}

func (c *caller[T]) afterFunc() {
	c.wait.Done()
	if c.weighted != nil {
		c.weighted.Release(1)
	}
}
