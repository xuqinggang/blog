package utils

import "sync"

// 基于 sync.Map 的并发安全映射
type SyncMap struct {
	sync.Map
}

// 创建新的并发映射
func NewSyncMap() *SyncMap {
	return &SyncMap{}
}

// 设置键值对
func (cm *SyncMap) Set(key string, value interface{}) {
	cm.Store(key, value)
}

// 获取键值对
func (cm *SyncMap) Get(key string) (interface{}, bool) {
	return cm.Load(key)
}

// 删除键值对
func (cm *SyncMap) Delete(key string) {
	cm.Map.Delete(key)
}

// 遍历所有键值对
func (cm *SyncMap) Range(f func(key string, value interface{}) bool) {
	cm.Map.Range(func(key, value interface{}) bool {
		strKey, ok := key.(string)
		if !ok {
			return true // 跳过非字符串键
		}
		return f(strKey, value)
	})
}