package time_utils

import (
	"fmt"
	"strings"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/gopkg/pkg/errors"
)

var CST = time.FixedZone("CST", 8*3600)

const SecondsOfMillisecond = 1000 // 一秒有多少毫秒

func CurrentTsSec() int64 {
	now := time.Now()
	return now.Unix()
}

func CurrentTsMs() int64 {
	now := time.Now()
	return now.UnixNano() / 1e6
}

// TodayStart 返回今天00:00
func TodayStart() time.Time {
	now := time.Now().In(CST)
	return DayStart(now)
}

func DayStart(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, CST)
}

func FromUnixCST(seconds int64) time.Time {
	return time.Unix(seconds, 0).In(CST)
}

func DateOfToday() string {
	return DateOfTime(time.Now())
}

func DateOfTime(t time.Time) string {
	return t.Format(consts.Fmt_date)
}

func BizDateOfTime(t time.Time) string {
	return t.Format(consts.Fmt_Date)
}

func DateTimeStrToTime(dateStr string) (time.Time, error) {
	return time.ParseInLocation(consts.Fmt_DateTime, dateStr, CST)
}

func DateOfTimeInt(t time.Time) int {
	return t.Year()*10000 + int(t.Month())*100 + t.Day()
}

func NDaysAgo(d int) time.Time {
	return TodayStart().Add(-time.Hour * (24 * time.Duration(d)))
}

func NDaysAfter(d int) time.Time {
	return TodayStart().Add(time.Hour * (24 * time.Duration(d)))
}

func GenDateStr(startDate, endDate string) string {
	start, _ := DateFmt(startDate, consts.FmtDateSlash, consts.FmtDate)
	end, _ := DateFmt(endDate, consts.FmtDateSlash, consts.FmtDate)
	dateStr := fmt.Sprintf("%s-%s", start, end)
	return dateStr
}

/*
@desc DateFmt	日期字符串进行指定格式转换
*/
func DateFmt(date, srcFmt, dstFmt string) (string, error) {
	timeObj, err := time.ParseInLocation(srcFmt, date, time.Local)
	if err != nil {
		return "", err
	}
	ts := timeObj.Unix()
	return time.Unix(ts, 0).Format(dstFmt), nil
}

func CurrentTimestampStr() string {
	return TimestampSecondToDate(time.Now().Unix())
}

func TimestampSecondToDate(t int64) string {
	tm := time.Unix(t, 0).In(CST)
	return tm.Format(consts.Fmt_DateTime)
}

func DateToTimestampSecond(t string) (int64, error) {
	tm, err := time.ParseInLocation(consts.Fmt_DateTime, t, CST)
	if err != nil {
		return 0, err
	}
	return tm.Unix(), nil
}

func TodayBizDate() string {
	return DateOfTime(time.Now().In(CST))
}

func TodayBizDateInt() int {
	start := TodayStart()
	return start.Year()*10000 + int(start.Month())*100 + start.Day()
}

func YesterdayBizDate() string {
	return DateOfTime(time.Now().In(CST).Add(-24 * time.Hour))
}

func YesterdayBizDateInt() int {
	start := TodayStart().Add(-24 * time.Hour)
	return start.Year()*10000 + int(start.Month())*100 + start.Day()
}

func BizDateBeforeDays(days int) string {
	return DateOfTime(time.Now().In(CST).Add(-24 * time.Hour * time.Duration(days)))
}

func BizDateBeforeDaysInt(days int) int {
	start := TodayStart().Add(-24 * time.Hour * time.Duration(days))
	return start.Year()*10000 + int(start.Month())*100 + start.Day()
}

func MysqlDateToBizDate(mysqlDate string) string {
	return mysqlDate[0:4] + mysqlDate[5:7] + mysqlDate[8:10]
}

func MysqlDateToStandardFmt(mysqlDate string) string {
	return strings.ReplaceAll(strings.ReplaceAll(mysqlDate, "T", " "), "+08:00", "")
}

func BizDateStrToTime(dateStr string) (time.Time, error) {
	return time.ParseInLocation(consts.Fmt_Date, dateStr, CST)
}

func NDaysAgoFromEndTime(endDateStr string, days int) string {
	endDate, _ := BizDateStrToTime(endDateStr)
	startDate := endDate.Add(-24 * time.Hour * time.Duration(days))
	return DateOfTime(startDate)
}

// 各种不同日期格式转换, 可以通过一个 BizDate 类实现
// clickhouse 日期格式为 2021-01-01
// hive 日期格式为 20210101
// mysql boe 日期格式为 2021-01-01 00:00:00
// mysql ppe 日期格式为 2021-01-01T00:00:00

// ChPartitionToHivePartition 2020-01-01 -> 20200101
func ChPartitionToHivePartition(hivePartition string) string {
	if len(hivePartition) >= 10 {
		return hivePartition[0:4] + hivePartition[5:7] + hivePartition[8:10]
	}
	return hivePartition
}

func HivePartitionToChPartition(chPartition string) string {
	if len(chPartition) != 8 {
		return chPartition
	}
	return chPartition[0:4] + "-" + chPartition[4:6] + "-" + chPartition[6:8]
}

func GetFirstDateOfMonth(d time.Time) time.Time {
	d = d.AddDate(0, 0, -d.Day()+1)
	return DayStart(d)
}

func GetLastDateOfMonth(d time.Time) time.Time {
	return GetFirstDateOfMonth(d).AddDate(0, 1, -1)
}

// GetFirstTimeOfWeek 获取本周周一的时间
func GetFirstTimeOfWeek(t time.Time) time.Time {
	offset := int(time.Monday - t.Weekday())
	if offset > 0 {
		offset = -6
	}
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location()).AddDate(0, 0, offset)
}

// 获取本周周日日期
func GetWeekSunday(t time.Time) time.Time {
	monday := GetFirstTimeOfWeek(t)
	return monday.AddDate(0, 0, 6)
}

func AddDate(t time.Time, year, month, day int) time.Time {
	// 先跳到目标月的1号
	targetDate := t.AddDate(year, month, -t.Day()+1)
	// 获取目标月的临界值
	targetDay := targetDate.AddDate(0, 1, -1).Day()
	// 对比临界值与源日期值，取最小的值
	if targetDay > t.Day() {
		targetDay = t.Day()
	}
	// 最后用目标月的1号加上目标值和入参的天数
	targetDate = targetDate.AddDate(0, 0, targetDay-1+day)
	return targetDate
}

// 20060102格式的日期转换成时间戳
func ParseDateFromStr(date string) (int64, error) {
	if date == "" {
		return 0, errors.New("date is nil")
	}
	t, err := time.ParseInLocation("2006-01-02", date, time.Local)
	if err != nil {
		return 0, err
	}
	return t.Unix(), nil
}

// 20060102格式的日期转换成时间戳,并取当天结尾时间
func ParseDateEndOfDayFromStr(date string) (int64, error) {
	if date == "" {
		return 0, errors.New("date is nil")
	}
	t, err := time.ParseInLocation("2006-01-02", date, time.Local)
	if err != nil {
		return 0, err
	}
	endOfDay := time.Date(t.Year(), t.Month(), t.Day(), 23, 59, 59, 999999999, time.Local)

	return endOfDay.Unix(), nil
}

func DateOfTimeToUnix(t time.Time) *int64 {
	timeUnix := t.Unix()
	return &timeUnix
}

func GetPrefixSuffixCustomDateByDateType(startDate, endDate string, dateType base.DateType) (preStartDate, preEndDate, sufStartDate, sufEndDate string, err error) {
	startTime, err := BizDateStrToTime(startDate)
	if err != nil {
		return
	}
	endTime, err := BizDateStrToTime(endDate)
	if err != nil {
		return
	}

	switch dateType {
	case base.DateType_DAY:
		preStartDate, preEndDate = startDate, startDate
		sufStartDate, sufEndDate = endDate, endDate
	case base.DateType_WEEK:
		preStartDate, preEndDate = BizDateOfTime(GetFirstTimeOfWeek(startTime)), BizDateOfTime(GetWeekSunday(startTime))
		sufStartDate, sufEndDate = BizDateOfTime(GetFirstTimeOfWeek(endTime)), BizDateOfTime(GetWeekSunday(endTime))
	case base.DateType_MONTH:
		preStartDate, preEndDate = BizDateOfTime(GetFirstDateOfMonth(startTime)), BizDateOfTime(GetLastDateOfMonth(startTime))
		sufStartDate, sufEndDate = BizDateOfTime(GetFirstDateOfMonth(endTime)), BizDateOfTime(GetLastDateOfMonth(endTime))
	default:
		return
	}
	return
}
