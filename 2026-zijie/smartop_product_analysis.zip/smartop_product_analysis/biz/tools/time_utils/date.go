package time_utils

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"math"
	"time"

	"code.byted.org/ecom/compass_strategy_toolbox/util/numberu"
	"code.byted.org/ecom/compass_strategy_toolbox/util/timeu"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
)

func DateDiffAbs(date1, date2 string) int64 {
	t1, _ := time.Parse(consts.Fmt_Date, date1)
	t2, _ := time.Parse(consts.Fmt_Date, date2)
	diff := t2.Sub(t1).Hours() / 24
	return int64(math.Abs(diff))
}

func DateStringToTimestamp(date string) int64 {
	t1, _ := time.Parse(consts.Fmt_Date, date)
	return t1.Unix()
}

func DateDiffAbsWithFormat(date1, date2, format string) int64 {
	t1, _ := time.Parse(format, date1)
	t2, _ := time.Parse(format, date2)
	diff := t2.Sub(t1).Hours() / 24
	return int64(math.Abs(diff))
}

// GetCycleStartEndDate 获取环比周期时间
func GetCycleStartEndDate(beginDate, endDate string) (string, string, error) {
	beginTime, err := time.Parse(consts.FmtDateSlash, beginDate)
	if err != nil {
		return "", "", err
	}
	endTime, err := time.Parse(consts.FmtDateSlash, endDate)
	if err != nil {
		return "", "", err
	}
	duration := int(endTime.Sub(beginTime).Hours() / 24)
	lastEndDate := beginTime.AddDate(0, 0, -1).Format(consts.FmtDateSlash)
	lastStartDate := beginTime.AddDate(0, 0, -1-duration).Format(consts.FmtDateSlash)
	return lastStartDate, lastEndDate, nil
}

func GenDateRangeList(startDate, endDate, format string) []string {
	t1, _ := time.Parse(format, startDate)
	diff := DateDiffAbsWithFormat(startDate, endDate, format)
	dateList := make([]string, 0)
	for i := 0; int64(i) <= diff; i++ {
		tmpDateStr := t1.Add(time.Duration(i) * 24 * time.Hour).Format(format)
		dateList = append(dateList, tmpDateStr)
	}
	return dateList
}

func AddDateTimeFormat(date string, format string, num int) string {
	t, _ := time.Parse(format, date)
	res := t.AddDate(0, 0, num).Format(format)
	return res
}

func isDateTypeContains(ss []consts.DateType, s consts.DateType) bool {
	if len(ss) == 0 {
		return false
	}
	for _, v := range ss {
		if v == s {
			return true
		}
	}
	return false
}

func GetCustomTimeStrSplit(startDate, endDate string, dateTypeList []consts.DateType) (map[consts.DateType][]*DateSplitResult, error) {
	startTime, err := time.Parse(consts.Fmt_Date, startDate)
	if err != nil {
		return nil, err
	}
	endTime, err := time.Parse(consts.Fmt_Date, endDate)
	if err != nil {
		return nil, err
	}
	ret := GetCustomTimeSplit(startTime.Unix(), endTime.Unix(), dateTypeList)
	return ret, nil
}

func GetCustomTimeSplit(startTime, endTime int64, dateTypeList []consts.DateType) map[consts.DateType][]*DateSplitResult {
	// 定义时间变量
	endDate := endTime
	startDate := startTime

	// 定义返回值，包括近7天，近30天，自然月，自然周，自然日的开始和结束时间
	startLastMon, endLastMon,
		startLastSeven, endLastSeven,
		startMon, endMon,
		startWeek, endWeek,
		startDay := make([]string, 0), make([]string, 0),
		make([]string, 0), make([]string, 0),
		make([]string, 0), make([]string, 0),
		make([]string, 0), make([]string, 0),
		make([]string, 0)

	// 根据优先级先计算近30天
	if isDateTypeContains(dateTypeList, consts.DateType_LAST_ONE_MONTH) {
		startLastMon, endLastMon = GetTimeByLastCustomDay(TimeConvertDate(startDate), TimeConvertDate(endDate), consts.DateType_LAST_ONE_MONTH)
		if len(startLastMon) != 0 {
			endDate, _ = ParseDateFromStr(startLastMon[len(startLastMon)-1])
		}
	}

	// 计算近7天
	if isDateTypeContains(dateTypeList, consts.DateType_LAST_SEVEN_DAYS) {
		if len(startLastMon) != 0 {
			endDate, _ = ParseDateFromStr(startLastMon[len(startLastMon)-1])
			endDate = time.Unix(endDate, 0).AddDate(0, 0, -1).Unix()
		}
		startLastSeven, endLastSeven = GetTimeByLastCustomDay(TimeConvertDate(startDate), TimeConvertDate(endDate), consts.DateType_LAST_SEVEN_DAYS)
		if len(startLastSeven) != 0 {
			endDate, _ = ParseDateFromStr(startLastSeven[len(startLastSeven)-1])
			endDate = time.Unix(endDate, 0).AddDate(0, 0, -1).Unix()
		}
	}

	// 自然周和自然月要计算夹缝的自然日，定义好夹缝的首尾时间
	startFrontDay := startTime
	endLastDay := endTime

	if isDateTypeContains(dateTypeList, consts.DateType_WEEK) && isDateTypeContains(dateTypeList, consts.DateType_MONTH) {
		// 第一种是既包含自然月又包含自然周，那么直接调用现成的方法
		startMon, endMon, startWeek, endWeek, startDay = GetCustomTimeSplitV2(startDate, endDate)
	} else if isDateTypeContains(dateTypeList, consts.DateType_MONTH) {
		// 只包含自然月
		startMon, endMon = GetTimeByLastCustomDay(TimeConvertDate(startDate), TimeConvertDate(endDate), consts.DateType_MONTH)
		if len(startMon) != 0 {
			// 如果自然月不为空的话，给自然月首尾时间赋值
			startDay = commonWeekAndMonthSplit(startMon, endMon, startFrontDay, endLastDay)
		} else {
			// 自然月为nil的话，相当于每一天都是自然日
			startDay = GetContinueTimeByDay(TimeConvertDate(startTime), TimeConvertDate(endDate))
		}
	} else if isDateTypeContains(dateTypeList, consts.DateType_WEEK) {
		// 只包含自然周
		startWeek, endWeek = GetTimeByLastCustomDay(TimeConvertDate(startDate), TimeConvertDate(endDate), consts.DateType_WEEK)
		if len(startWeek) != 0 {
			// 如果自然周不为空的话，给自然周首尾时间赋值
			startDay = commonWeekAndMonthSplit(startWeek, endWeek, startFrontDay, endLastDay)
		} else {
			// 自然周为nil的话，相当于每一天都是自然日
			startDay = GetContinueTimeByDay(TimeConvertDate(startTime), TimeConvertDate(endDate))
		}
	} else {
		// 如果都不包含，每一天都是自然日
		startDay = GetContinueTimeByDay(TimeConvertDate(startDate), TimeConvertDate(endDate))
	}
	return getDateResultV2(startLastMon, endLastMon, startLastSeven, endLastSeven, startMon, endMon, startWeek, endWeek, startDay)
}

// GetBigPromotionTimeSplit 日期拆分 For大促
func GetBigPromotionTimeSplit(startTime, endTime int64) map[consts.DateType][]*DateSplitResult {
	startDate := TimeConvertDate(startTime)
	endDate := TimeConvertDate(endTime)

	splitResult := make(map[consts.DateType][]*DateSplitResult)
	currentDate := startDate

	// 判断时间是否包含05-27
	if Contains0527(startDate, endDate) {
		//startDate = time.Date(startDate.Year(), 5, 27, 0, 0, 0, 0, startDate.Location())
		date := &DateSplitResult{
			StartDate: "",
			EndDate:   TimeConvertCurrDate(endDate.Unix()),
		}
		splitResult[consts.DateType_SINCE_0527] = []*DateSplitResult{date}
		//return splitResult
		endDate = time.Date(endDate.Year(), 5, 26, 8, 0, 0, 0, endDate.Location())
	}
	//var result []string
	// 按 7d 补齐天数
	currentDate, sevenDaySplitResult := splitDateRangeFor7dOr1d(currentDate, endDate, consts.DateType_LAST_SEVEN_DAYS)
	//result = []string{}

	splitResult[consts.DateType_LAST_SEVEN_DAYS] = sevenDaySplitResult
	// 补齐剩余天数 1d
	//for {
	//	nextDate := currentDate
	//	// Check if next date exceeds end date
	//	if nextDate.After(endDate) {
	//		break
	//	}
	//	// Convert to timestamp and format
	//	result = append(result, TimeConvertCurrDate(nextDate.Unix()))
	//	// Update next date for next iteration
	//	currentDate = nextDate.AddDate(0, 0, 1)
	//}
	//daySplitResult := make([]*DateSplitResult, 0)
	//for i, _ := range result {
	//	date := &DateSplitResult{
	//		StartDate: "",
	//		EndDate:   result[i],
	//	}
	//	daySplitResult = append(daySplitResult, date)
	//}
	// 补齐1d的剩余天数
	currentDate, daySplitResult := splitDateRangeFor7dOr1d(currentDate, endDate, consts.DateType_DAY)
	splitResult[consts.DateType_DAY] = daySplitResult
	return splitResult
}

// 按近7天和1天拆分日期
func splitDateRangeFor7dOr1d(currentDate time.Time, endDate time.Time, dateType consts.DateType) (time.Time, []*DateSplitResult) {
	var result []string
	for {
		nextDate := currentDate
		if dateType == consts.DateType_LAST_SEVEN_DAYS {
			// Add 7 days to current date
			nextDate = currentDate.AddDate(0, 0, 6)
		}
		// Check if next date exceeds end date
		if nextDate.After(endDate) {
			break
		}
		// Convert to timestamp and format
		result = append(result, TimeConvertCurrDate(nextDate.Unix()))
		// Update current date for next iteration
		currentDate = nextDate.AddDate(0, 0, 1)
	}
	sevenDaySplitResult := make([]*DateSplitResult, 0)
	for i := range result {
		date := &DateSplitResult{
			StartDate: "",
			EndDate:   result[i],
		}
		sevenDaySplitResult = append(sevenDaySplitResult, date)
	}
	return currentDate, sevenDaySplitResult
}

// Contains0527 检查时间范围是否包含5月27日（东八区时间，任意年份）
func Contains0527(startDate, endDate time.Time) bool {

	// 生成起始年和结束年之间的所有5月27日
	for year := startDate.Year(); year <= endDate.Year(); year++ {
		may27 := time.Date(year, time.May, 27, 8, 0, 0, 0, startDate.Location())
		if !may27.Before(startDate) && !may27.After(endDate) {
			return true
		}
	}
	return false
}

// 拆分成多个近7天，近30天，自然周，自然月
func GetTimeByLastCustomDay(startTime, endTime time.Time, dateType consts.DateType) (startLastCustomDay, endLastCustomDay []string) {
	days := 0
	switch dateType {
	case consts.DateType_LAST_SEVEN_DAYS: // 近7天
		days = 6
	case consts.DateType_LAST_ONE_MONTH: // 近30天
		days = 29
	}
	if days != 0 {
		i := 0
		for {
			end := endTime.AddDate(0, 0, -days*i)
			if i > 0 {
				end = end.AddDate(0, 0, -1*i)
			}
			start := end.AddDate(0, 0, -days)
			if start.Unix() < startTime.Unix() {
				break
			}
			startLastCustomDay = append(startLastCustomDay, start.Format("20060102"))
			endLastCustomDay = append(endLastCustomDay, end.Format("20060102"))
			i++
		}
	}

	switch dateType {
	case consts.DateType_WEEK: // 自然周
		startLastCustomDay, endLastCustomDay = GetContinueTimeByWeek(startTime, endTime)
	case consts.DateType_MONTH: // 自然月
		startLastCustomDay, endLastCustomDay = GetContinueTimeByMonth(startTime, endTime)
	}
	return startLastCustomDay, endLastCustomDay
}

// 拆分日
func GetContinueTimeByDay(startTime, endTime time.Time) (startDay []string) {
	i := 0
	for {
		start := TimeConvertDayDate(startTime.Unix(), i*1)
		startTimestamp, _ := ParseDateFromStr(start)
		if startTimestamp > endTime.Unix() {
			break
		}
		startDay = append(startDay, time.Unix(startTimestamp, 0).Format(consts.FmtDateSlash))
		i++
	}
	return startDay
}

// 拆分为周
func GetContinueTimeByWeek(startTime, endTime time.Time) (startWeek, endWeek []string) {
	// 取出开始时间的本周末时间
	sunday := GetWeekSunday(startTime)
	// 取出结束时间的本周一时间
	monday := GetFirstTimeOfWeek(endTime)
	// 计算每个周
	i := 0
	startMonday := sunday.AddDate(0, 0, 1)
	if time.Monday-startTime.Weekday() == 0 {
		// 如果开始时间是周一
		startMonday = startTime
	}
	endMonday := monday.AddDate(0, 0, -1)
	if time.Sunday-endTime.Weekday() == 0 {
		// 如果结束时间是周末
		endMonday = endTime
	}
	for {
		// 获取每次循环的周一
		start := startMonday.AddDate(0, 0, i*7)
		// 获取每次循环的周日
		end := GetWeekSunday(start)
		if start == end || end.Unix() > endMonday.Unix() {
			break
		}
		startWeek = append(startWeek, start.Format(consts.FmtDateSlash))
		endWeek = append(endWeek, end.Format(consts.Fmt_Date))
		i++
	}

	return startWeek, endWeek
}

// 拆分为月
func GetContinueTimeByMonth(startTime, endTime time.Time) (startMonth, endMonth []string) {
	// startTime抹去零头，对齐到当天00:00:00
	startTime = GetZeroTime(startTime)
	// 判断下开始日期和结束日期是否是整个月
	startMonthFirstDay := GetFirstDateOfMonth(startTime)
	endMonthLastDay := GetLastDateOfMonth(endTime)
	start := startTime
	end := endTime
	// 如果开始时间大于开始当月第一天，start设置为从下个月月初开始
	if startTime.Unix() > startMonthFirstDay.Unix() {
		start = AddDate(startMonthFirstDay, 0, 1, 0)
	}
	// 如果结束时间小于结束当月最后一天，end设置为从上个月末结束
	if endTime.Unix() < endMonthLastDay.Unix() {
		end = AddDate(endMonthLastDay, 0, -1, 0)
	}
	for i := start; i.Before(end); i = AddDate(i, 0, 1, 0) {
		startMonth = append(startMonth, i.Format(consts.Fmt_Date))
		endMonth = append(endMonth, AddDate(i, 0, 1, -1).Format(consts.Fmt_Date))
	}
	return startMonth, endMonth
}

// 返回格式为[]string
func GetCustomTimeSplitV2(startTime, endTime int64) (statsMon, dateMon, statsWeek, dateWeek, dateDay []string) {
	// 先把月抽出来
	statsMon, dateMon = GetContinueTimeByMonth(TimeConvertDate(startTime), TimeConvertDate(endTime))

	// 把算好的月的开头一天和结尾一天取出来
	var startMonthDay int64
	var endMonthDay int64
	if len(statsMon) == 0 {
		// 如果月记录为null，开始时间和结束时间设置为原先的
		startMonthDay = startTime
		endMonthDay = endTime
		statsWeek, dateWeek = GetContinueTimeByWeek(TimeConvertDate(startMonthDay), TimeConvertDate(endMonthDay))

		if len(statsWeek) == 0 {
			// 如果没有周记录
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(startTime), TimeConvertDate(endTime))...)
		} else {
			endWeekTime, _ := ParseDateFromStr(statsWeek[0])
			startWeekTime, _ := ParseDateFromStr(dateWeek[len(dateWeek)-1])
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(startTime), TimeConvertDate(endWeekTime).AddDate(0, 0, -1))...)
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(startWeekTime).AddDate(0, 0, 1), TimeConvertDate(endTime))...)
		}
	} else {
		startMonthFirst, _ := ParseDateFromStr(statsMon[0])
		endMonthLast, _ := ParseDateFromStr(dateMon[len(dateMon)-1])
		startMonthDay = TimeConvertBeforeDay(startMonthFirst, -1).Unix()
		endMonthDay = TimeConvertBeforeDay(endMonthLast, 1).Unix()
		// 月记录不为null，就设置开头时间和结束时间
		statsWeekHead, dateWeekHead := GetContinueTimeByWeek(TimeConvertDate(startTime), TimeConvertDate(startMonthDay))
		statsWeekTail, dateWeekTail := GetContinueTimeByWeek(TimeConvertDate(endMonthDay), TimeConvertDate(endTime))
		if len(statsWeekHead) == 0 {
			// 如果开头周记录为nil
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(startTime), TimeConvertDate(startMonthDay))...)
		} else {
			startWeek, _ := ParseDateFromStr(statsWeekHead[0])
			endWeek, _ := ParseDateFromStr(dateWeekHead[len(dateWeekHead)-1])
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(startTime), TimeConvertDate(startWeek).AddDate(0, 0, -1))...)
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(endWeek).AddDate(0, 0, 1), TimeConvertDate(startMonthDay))...)
		}

		if len(statsWeekTail) == 0 {
			// 如果结尾周记录为nil
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(endMonthDay), TimeConvertDate(endTime))...)
		} else {
			endWeek, _ := ParseDateFromStr(dateWeekTail[len(dateWeekTail)-1])
			startWeek, _ := ParseDateFromStr(statsWeekTail[0])
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(endWeek).AddDate(0, 0, 1), TimeConvertDate(endTime))...)
			dateDay = append(dateDay, GetContinueTimeByDay(TimeConvertDate(endMonthDay), TimeConvertDate(startWeek).AddDate(0, 0, -1))...)
		}
		statsWeek = append(statsWeek, statsWeekHead...)
		statsWeek = append(statsWeek, statsWeekTail...)
		dateWeek = append(dateWeek, dateWeekHead...)
		dateWeek = append(dateWeek, dateWeekTail...)
	}
	return statsMon, dateMon, statsWeek, dateWeek, dateDay
}

// TimeConvertBeforeDate 通过时间戳获取早几天具体年月日
func TimeConvertBeforeDay(t int64, diff int) time.Time {
	var cstZone = time.FixedZone("CST", 8*3600) // 东八
	return time.Unix(t, 0).In(cstZone).AddDate(0, 0, diff)
}

// 返回自然周，自然月中的每日时间公用方法
func commonWeekAndMonthSplit(startDate, endDate []string, startFrontDay, endLastDay int64) []string {
	endFrontDay, _ := ParseDateFromStr(startDate[0])
	endFrontDay = time.Unix(endFrontDay, 0).AddDate(0, 0, -1).Unix()
	startLastDay, _ := ParseDateFromStr(endDate[len(endDate)-1])
	startLastDay = time.Unix(startLastDay, 0).AddDate(0, 0, 1).Unix()

	startDay := GetContinueTimeByDay(TimeConvertDate(startFrontDay), TimeConvertDate(endFrontDay))
	startDay = append(startDay, GetContinueTimeByDay(TimeConvertDate(startLastDay), TimeConvertDate(endLastDay))...)
	return startDay
}

type DateSplitResult struct {
	StartDate string
	EndDate   string
}

// 返回值为 map[rocket_constu.DateType][]*DateSplitResult
func getDateResultV2(startLastMon, endLastMon,
	startLastSeven, endLastSeven,
	startMonth, endMonth,
	startWeek, endWeek,
	dateDay []string) map[consts.DateType][]*DateSplitResult {

	result := make(map[consts.DateType][]*DateSplitResult, 0)

	startLastMonSplitResult := make([]*DateSplitResult, 0)
	for i := range startLastMon {
		date := &DateSplitResult{
			StartDate: startLastMon[i],
			EndDate:   endLastMon[i],
		}
		startLastMonSplitResult = append(startLastMonSplitResult, date)
	}
	startLastSevenSplitResult := make([]*DateSplitResult, 0)
	for i := range startLastSeven {
		date := &DateSplitResult{
			StartDate: startLastSeven[i],
			EndDate:   endLastSeven[i],
		}
		startLastSevenSplitResult = append(startLastSevenSplitResult, date)
	}

	monthSplitResult := make([]*DateSplitResult, 0)
	for i := range startMonth {
		date := &DateSplitResult{
			StartDate: startMonth[i],
			EndDate:   endMonth[i],
		}
		monthSplitResult = append(monthSplitResult, date)
	}

	weekSplitResult := make([]*DateSplitResult, 0)
	for i := range startWeek {
		date := &DateSplitResult{
			StartDate: startWeek[i],
			EndDate:   endWeek[i],
		}
		weekSplitResult = append(weekSplitResult, date)
	}

	daySplitResult := make([]*DateSplitResult, 0)
	for i := range dateDay {
		date := &DateSplitResult{
			StartDate: dateDay[i],
			EndDate:   dateDay[i],
		}
		daySplitResult = append(daySplitResult, date)
	}

	if len(monthSplitResult) != 0 {
		result[consts.DateType_MONTH] = monthSplitResult
	}
	if len(weekSplitResult) != 0 {
		result[consts.DateType_WEEK] = weekSplitResult
	}
	if len(daySplitResult) != 0 {
		result[consts.DateType_DAY] = daySplitResult
	}
	if len(startLastSevenSplitResult) != 0 {
		result[consts.DateType_LAST_SEVEN_DAYS] = startLastSevenSplitResult
	}
	if len(startLastMonSplitResult) != 0 {
		result[consts.DateType_LAST_ONE_MONTH] = startLastMonSplitResult
	}
	return result
}

// TimeConvertDate 通过时间戳获取 time.Time 时间(东八)
func TimeConvertDate(t int64) time.Time {
	var cstZone = time.FixedZone("CST", 8*3600) // 东八
	return time.Unix(t, 0).In(cstZone)
}

// 获取某一天的0点时间
func GetZeroTime(d time.Time) time.Time {
	return time.Date(d.Year(), d.Month(), d.Day(), 0, 0, 0, 0, d.Location())
}

// TimeConvertDayDate 通过时间戳获取天跨度的日期
func TimeConvertDayDate(t int64, offset int) string {
	return TimeConvertCurrDate(time.Unix(t, 0).AddDate(0, 0, offset).Unix())
}

// TimeConvertCurrDate 通过时间戳获取本区具体年月日
func TimeConvertCurrDate(t int64) string {
	var cstZone = time.FixedZone("CST", 8*3600) // 东八
	return time.Unix(t, 0).In(cstZone).Format(consts.FmtDateSlash)
}

// TimeConvertBeforeDate 通过时间戳获取早几天具体年月日
func TimeConvertBeforeDate(t int64, diffDay int) string {
	var cstZone = time.FixedZone("CST", 8*3600) // 东八
	return time.Unix(t, 0).In(cstZone).AddDate(0, 0, diffDay).Format(consts.FmtDateSlash)
}

func GetTrendDateByPointNum(startTime int64, endTime int64, pointNum int) []string {
	startDate := TimeConvertCurrDate(startTime)

	dates := make([]string, 0)
	// 对齐到0点计算
	endDateTime := timeu.TrimDate(time.Unix(endTime, 0), 0)
	startDateTime := timeu.TrimDate(time.Unix(startTime, 0), 0)
	// 以30个日期点作为标准（有29个时间间隔）
	dateRange := float64(timeu.OneDay * (pointNum - 1))
	// 通过时间跨度计算每添加一个时间点跳过点的个数贡献值，当贡献值大于1说明需要跳过1个，大于N说明需要跳过N个
	step := (endDateTime.Sub(startDateTime).Seconds() - dateRange) / dateRange
	var jumpAccumulator float64 = 0
	for idx := 0; TimeConvertBeforeDate(endTime, idx*-1) >= startDate; idx++ {
		dates = append(dates, TimeConvertBeforeDate(endTime, idx*-1))
		// 只有超过30天的自定义时间step大于0才会跳日期
		if step > 0 {
			jumpAccumulator += step
			if jumpAccumulator >= 1 { // 超过1时，根据跳跃累加值跳过N个日期
				idx, jumpAccumulator = idx+int(jumpAccumulator)/1, jumpAccumulator-float64(int(jumpAccumulator)/1)
				continue
			}
			// 当出现浮点数0.999等情况也需要跳过下一个点，但是浮点数计算有误差
			if math.Abs(jumpAccumulator-1) < numberu.MIN {
				idx, jumpAccumulator = idx+1, jumpAccumulator-1
				continue
			}
		}
	}
	return dates
}

func JudgeIsCycle(startDate, endDate, compareStartDate, compareEndDate string) (bool, error) {
	startTime, err := time.Parse(consts.Fmt_Date, startDate)
	if err != nil {
		return false, err
	}
	cycleEndDate := startTime.AddDate(0, 0, -1).Format(consts.Fmt_Date)
	cycleStartDate := startTime.AddDate(0, 0, -int(DateDiffAbs(startDate, endDate))-1).Format(consts.Fmt_Date)

	if cycleStartDate == compareStartDate && cycleEndDate == compareEndDate {
		return true, nil
	}
	return false, nil
}

func GetSyncDate(startDate, endDate string, syncType analysis.SyncType) (string, string, error) {
	startTime, err := time.Parse(consts.Fmt_Date, startDate)
	if err != nil {
		return "", "", err
	}
	endTime, err := time.Parse(consts.Fmt_Date, endDate)
	if err != nil {
		return "", "", err
	}
	if syncType == analysis.SyncType_Week {
		syncStartDate := startTime.AddDate(0, 0, -7).Format(consts.Fmt_Date)
		syncEndDate := endTime.AddDate(0, 0, -7).Format(consts.Fmt_Date)
		return syncStartDate, syncEndDate, nil
	}
	if syncType == analysis.SyncType_Month {
		syncStartDate := startTime.AddDate(0, 0, -30).Format(consts.Fmt_Date)
		syncEndDate := endTime.AddDate(0, 0, -30).Format(consts.Fmt_Date)
		return syncStartDate, syncEndDate, nil
	}
	return startDate, endDate, nil
}

func GetAddDate(startDate string, days int) (string, error) {
	startTime, err := time.Parse(consts.Fmt_Date, startDate)
	if err != nil {
		return "", err
	}
	resDate := startTime.AddDate(0, 0, days).Format(consts.Fmt_Date)
	return resDate, nil
}
