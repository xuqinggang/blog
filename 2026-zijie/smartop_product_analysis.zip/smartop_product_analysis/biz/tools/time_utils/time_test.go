package time_utils

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/temai/go_lib/convert"
	"encoding/base64"
	"fmt"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestDateOfTimeInt(t *testing.T) {
	if DateOfTimeInt(TodayStart()) != TodayBizDateInt() {
		t.Error("DateOfTimeInt(TodayStart()) != TodayBizDateInt()")
	}
}

func TestGetTrendDateByPointNum(t *testing.T) {
	startTime, _ := time.Parse(consts.Fmt_Date, "2024-05-01")
	endTime, _ := time.Parse(consts.Fmt_Date, "2024-05-31")

	fmt.Println(convert.ToJSONString(GetTrendDateByPointNum(startTime.Unix(), endTime.Unix(), 7)))
}

func TestGetCustomTimeSplit(t *testing.T) {
	//a, b := GetContinueTimeByWeek(timeu.TimeConvertDate(1715385600), timeu.TimeConvertDate(1717286400))
	//fmt.Println(a)
	//fmt.Println(b)
	fmt.Println(convert.ToJSONString(GetCustomTimeSplit(1715385600, 1717286400, []consts.DateType{consts.DateType_DAY, consts.DateType_WEEK})))
}

func TestDateTimeStrToTime(t *testing.T) {
	d1, _ := DateTimeStrToTime("2021-01-01 00:00:00")
	d2, _ := DateTimeStrToTime("2021-01-02 00:00:00")
	if d2.Sub(d1).Hours() != 24 {
		t.Error("d2.Sub(d1).Hours() == " + strconv.FormatFloat(d2.Sub(d1).Hours(), 'f', 2, 64) + " != 24")
	}
}

func TestGenDateStr(t *testing.T) {
	if GenDateStr("2021-01-01", "2021-01-02") != "20210101-20210102" {
		t.Error("GenDateStr() != 20210101-20210102")
	}
}

func TestTimestampToDate(t *testing.T) {
	if "2023-02-28 11:08:05" != TimestampSecondToDate(1677553685) {
		t.Error("计算错误")
	}
}

func TestDateToTimestampSecond(t *testing.T) {
	if tm, _ := DateToTimestampSecond("2023-02-28 11:08:05"); tm != 1677553685 {
		t.Error("计算错误")
	}
}

func TestBase64Encode(t *testing.T) {
	Auth := "${username}:PBI5TZjflNAdcf4UdZnAsnWZSxYQGPND"
	Auth = strings.Replace(Auth, "${username}", "limengxu.ruozhou", -1)

	AuthEnc := base64.StdEncoding.EncodeToString([]byte(Auth))
	fmt.Println(AuthEnc)
}

func TestTodayBizDate(t *testing.T) {
	if TodayBizDate() != DateOfTime(TodayStart()) {
		t.Error("TodayBizDate() != DateOfTime(TodayStart())")
	}
}

func TestYesterdayBizDate(t *testing.T) {
	t.Log(YesterdayBizDate())
}

func TestTodayBizDateInt(t *testing.T) {
	if strconv.Itoa(TodayBizDateInt()) != TodayBizDate() {
		t.Error("TodayBizDateInt() != TodayBizDate")
	}
}

func TestYesterdayBizDateInt(t *testing.T) {
	if strconv.Itoa(YesterdayBizDateInt()) != YesterdayBizDate() {
		t.Error("YesterdayBizDateInt() != YesterdayBizDate")
	}
}

func TestBizDateBeforeDays(t *testing.T) {
	if BizDateBeforeDays(1) != YesterdayBizDate() {
		t.Error("BizDateBeforeDays(1) != YesterdayBizDate")
	}
}

func TestBizDateBeforeDaysInt(t *testing.T) {
	if BizDateBeforeDaysInt(1) != YesterdayBizDateInt() {
		t.Error("BizDateBeforeDaysInt(1) != YesterdayBizDateInt")
	}
}

func TestMysqlDateToBizDate(t *testing.T) {
	if MysqlDateToBizDate("2021-01-01") != "20210101" {
		t.Error("MysqlDateToBizDate() != 20210101")
	}
	if MysqlDateToBizDate("2021-01-01 00:00:00") != "20210101" {
		t.Error("MysqlDateToBizDate() != 20210101")
	}
	if MysqlDateToBizDate("2021-01-01 00:00:00.000") != "20210101" {
		t.Error("MysqlDateToBizDate() != 20210101")
	}
	if MysqlDateToBizDate("2021-01-01T10:34:40") != "20210101" {
		t.Error("MysqlDateToBizDate() != 20210101")
	}
	if MysqlDateToBizDate("2021-01-01T10:34:40.000") != "20210101" {
		t.Error("MysqlDateToBizDate() != 20210101")
	}
	if MysqlDateToBizDate("2021-01-01T10:34:40.000Z") != "20210101" {
		t.Error("MysqlDateToBizDate() != 20210101")
	}
	if MysqlDateToBizDate("2021-01-01T10:34:40Z") != "20210101" {
		t.Error("MysqlDateToBizDate() != 20210101")
	}
}

func TestBizDateStrToTime(t *testing.T) {
	if d, _ := BizDateStrToTime("20230101"); DateOfTime(d) != "20230101" {
		t.Error("BizDateStrToTime() != 20230101")
	}
}

func TestNDaysAgoFromEndTime(t *testing.T) {
	if NDaysAgoFromEndTime("20230101", 1) != "20221231" {
		t.Error("NDaysAgoFromEndTime() != 20221231")
	}
}

func TestChPartitionToHivePartition(t *testing.T) {
	if ChPartitionToHivePartition("2023-01-01") != "20230101" {
		t.Error("ChPartitionToHivePartition() != 20230101")
	}
	if ChPartitionToHivePartition("2023-01-01T12:01:01") != "20230101" {
		t.Error("ChPartitionToHivePartition() != 20230101")
	}
	if ChPartitionToHivePartition("20230101") != "20230101" {
		t.Error("ChPartitionToHivePartition() != 20230101")
	}
}

func TestHivePartitionToChPartition(t *testing.T) {
	if HivePartitionToChPartition("20230101") != "2023-01-01" {
		t.Error("ChPartitionToHivePartition(20230101) != 2023-01-01")
	}
	if HivePartitionToChPartition("2023-07-06") != "2023-07-06" {
		t.Error("ChPartitionToHivePartition(2023-07-06) != 2023-07-06")
	}

}

func TestMysqlDateToStandardFmt(t *testing.T) {
	if MysqlDateToStandardFmt("2023-01-01") != "2023-01-01" {
		t.Error("MysqlDateToStandardFmt() != 2023-01-01")
	}
	if MysqlDateToStandardFmt("2023-01-01 00:00:00") != "2023-01-01 00:00:00" {
		t.Error("MysqlDateToStandardFmt() != 2023-01-01 00:00:00")
	}
	/*if MysqlDateToStandardFmt("2023-01-01 00:00:00.000") != "2023-01-01 00:00:00" {
		t.Error("MysqlDateToStandardFmt() != 2023-01-01 00:00:00")
	}*/
	if MysqlDateToStandardFmt("2023-01-01T10:34:40") != "2023-01-01 10:34:40" {
		t.Error("MysqlDateToStandardFmt() != 2023-01-01 10:34:40")
	}
	/*if MysqlDateToStandardFmt("2023-01-01T10:34:40.000") != "2023-01-01 10:34:40" {
		t.Error("MysqlDateToStandardFmt() != 2023-01-01 10:34:40")
	}*/
}
