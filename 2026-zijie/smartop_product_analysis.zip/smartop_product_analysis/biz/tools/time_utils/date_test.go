package time_utils

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/sql_parse"
	"fmt"
	"testing"
)

func TestGetBigPromotionTimeSplit(t *testing.T) {
	//startTime, _ := time.Parse(consts.Fmt_Date, "2025-05-01")
	//
	//endTime, _ := time.Parse(consts.Fmt_Date, "2025-06-30")
	result, _ := GetCustomTimeStrSplit("2025-05-01", "2025-06-30", []consts.DateType{consts.DateType_DAY, consts.DateType_WEEK})

	dataExpr := &sql_parse.Expression{
		Logic:    sql_parse.OR,
		Children: make([]*sql_parse.Expression, 0),
	}
	for dateType, splitVList := range result {
		if len(splitVList) == 0 {
			continue
		}

		dates := make([]string, 0)
		for _, v := range splitVList {
			dates = append(dates, v.EndDate)
		}
		fmt.Println(dates)

		tmp := sql_parse.NewCQL()
		tmp.AddWhere("date", sql_parse.IN, dates).AddWhere("days_type", sql_parse.EQUAL, string(dateType))
		dataExpr.Children = append(dataExpr.Children, tmp.WhereClause)
	}
	fmt.Println(sql_parse.NewCQL().ParseExpression(dataExpr))
}
