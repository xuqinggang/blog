package idgenerator

import (
	"code.byted.org/ecom/compass_strategy_toolbox/errcodes"
	logu "code.byted.org/ecom/compass_strategy_toolbox/logger"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/gopkg/idgenerator/v2"
	"code.byted.org/temai/go_lib/convert"
	"context"
)

var (
	namespace = "ecom_product_analysis"
)

var client idgenerator.NtIdGenerator

func init() {
	InitIDGenerator()
}

const (
	errHint = "if you run on Macbook / Local Environment, " +
		"please make sure you have setup env var CONSUL_HTTP_HOST=x.x.x.x and RUNTIME_IDC_NAME=boei18n, " +
		"ref: https://bytedance.feishu.cn/wiki/wikcnFXjdlnEyxEdIZxgOvwLI8f"
)

func InitIDGenerator() {
	clientTmp, err := idgenerator.NewNtIdGeneratorBuilder().
		WithNamespace(namespace).
		Build()
	if err != nil {
		//panic(fmt.Errorf("idgenerator client init fail, err: %w\n%v", err, errHint))
	}
	client = clientTmp
}

func GenerateIdString(ctx context.Context) (string, error) {
	id, err := client.Get(ctx)
	if err != nil {
		logu.CtxNotice(ctx, "[utils#id_generator#GenerateIdString] Generate id err: %+v", err)
		return consts.Empty, err
	}

	logu.CtxInfo(ctx, "[utils#id_generator#GenerateIdString] Generate id: %d", id)
	return convert.ToString(id), nil
}

func GenerateId(ctx context.Context) (int64, error) {
	id, err := client.Get(ctx)
	if err != nil {
		logu.CtxError(ctx, errcodes.ProcessError, "[utils#id_generator#GenerateIdString] Generate id err: %+v", err)
		return 0, err
	}
	return convert.ToInt64(id), nil
}
