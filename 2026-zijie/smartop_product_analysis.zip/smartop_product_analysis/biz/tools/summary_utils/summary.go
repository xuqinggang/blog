package summary_utils

import (
	"reflect"

	"code.byted.org/overpass/ecom_product_pack_platform/kitex_gen/ecom/product/pack_platform"
	"code.byted.org/overpass/ecom_product_pack_platform/kitex_gen/ecom/product/purchase"
	"code.byted.org/overpass/ecom_product_pack_platform/kitex_gen/ecom/summary/marketing"
	"github.com/thoas/go-funk"
)

var ExplosiveSubsidySet = []marketing.CampaignType{marketing.CampaignType_ExplosiveSubsidy, marketing.CampaignType_GroupBuyExplosiveSubsidy,
	marketing.CampaignType_BigmarketExplosiveSubsidy2, marketing.CampaignType_BigmarketexplosiveSubsidy}

var MemberSampleSet = []marketing.CampaignType{marketing.CampaignType_MemberSample}

var SeckillSet = []marketing.CampaignType{marketing.CampaignType_PlatformSeckill, marketing.CampaignType_ExplosiveCheapBuy, marketing.CampaignType_NyuanMpieceDiscount}

// 通过Summary获取商品名称
func GetProductName(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *string {
	if packPlatform == nil || packPlatform[pid] == nil {
		return nil
	}

	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}

	if productInfo.BaseInfo == nil || productInfo.BaseInfo.ProductBaseInfo == nil {
		return nil
	}

	// 优先返回summary的商品名称
	return &productInfo.BaseInfo.ProductBaseInfo.Title
}

// 通过Summary获取商品背景图片
func GetProductBgUrl(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *string {
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.BaseInfo == nil || productInfo.BaseInfo.ProductBaseInfo == nil ||
		len(productInfo.BaseInfo.ProductBaseInfo.Images) == 0 {
		return nil
	}

	for _, image := range productInfo.BaseInfo.ProductBaseInfo.Images {
		if len(image.UrlList) > 0 {
			return &image.UrlList[0]
		}
	}

	return nil
}

// 通过Summary获取最低价sku是否参加大牌试用活动
func GetIsBrandTrialProduct(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *bool {
	brandTrialBizTag := []string{"FakeMemberSample", "MemberSample"}
	res := false
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.MarketingInfo == nil ||
		productInfo.MarketingInfo.ProductMarketingInfo == nil ||
		productInfo.MarketingInfo.ProductMarketingInfo.MinSkuInfo == nil ||
		productInfo.MarketingInfo.ProductMarketingInfo.MinSkuInfo.Campaign == nil ||
		productInfo.MarketingInfo.ProductMarketingInfo.MinSkuInfo.Campaign.Feature == nil {
		return nil
	}
	if v, ok := productInfo.MarketingInfo.ProductMarketingInfo.MinSkuInfo.Campaign.Feature["business_code"]; ok {
		res = funk.Contains(brandTrialBizTag, v)
	}

	return &res
}

// 通过Summary获取外展sku是否参加秒杀活动
func GetIsSeckillProduct(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *bool {
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.MarketingInfo == nil ||
		productInfo.MarketingInfo.ShowProductMarketingInfo == nil ||
		productInfo.MarketingInfo.ShowProductMarketingInfo.ShowSkuInfo == nil ||
		productInfo.MarketingInfo.ShowProductMarketingInfo.ShowSkuInfo.Campaign == nil ||
		productInfo.MarketingInfo.ShowProductMarketingInfo.ShowSkuInfo.Campaign.Campaign == nil {
		return nil
	}
	res := funk.Contains(SeckillSet, productInfo.MarketingInfo.ShowProductMarketingInfo.ShowSkuInfo.Campaign.Campaign.CampaignType)

	return &res
}

// 通过Summary获取外展sku是否参加超值购活动
func GetIsAllowanceProduct(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *bool {
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.MarketingInfo == nil ||
		productInfo.MarketingInfo.ShowProductMarketingInfo == nil ||
		productInfo.MarketingInfo.ShowProductMarketingInfo.ShowSkuInfo == nil ||
		productInfo.MarketingInfo.ShowProductMarketingInfo.ShowSkuInfo.Campaign == nil ||
		productInfo.MarketingInfo.ShowProductMarketingInfo.ShowSkuInfo.Campaign.Campaign == nil {
		return nil
	}
	res := funk.Contains(ExplosiveSubsidySet, productInfo.MarketingInfo.ShowProductMarketingInfo.ShowSkuInfo.Campaign.Campaign.CampaignType)

	return &res
}

// 通过Summary获取是否可售
func GetPurchaseStatus(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *bool {
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.TradeInfo == nil ||
		productInfo.TradeInfo.ProductPurchaseStatus == nil {
		return nil
	}
	return productInfo.TradeInfo.ProductPurchaseStatus.PurchaseStatus
}

// 通过Summary获取不可售原因
func GetPurchaseStatusReason(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *purchase.PurchaseReason {
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.TradeInfo == nil ||
		productInfo.TradeInfo.ProductPurchaseStatus == nil {
		return nil
	}
	return productInfo.TradeInfo.ProductPurchaseStatus.PurchaseReason
}

// 通过Summary获取具体不可售原因
func GetPurchaseStatusReasonDetail(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *string {
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.TradeInfo == nil ||
		productInfo.TradeInfo.ProductPurchaseStatus == nil {
		return nil
	}
	return productInfo.TradeInfo.ProductPurchaseStatus.PurchaseReasonDetail
}

// 通过Summary获取活动库存
func GetCampaignStock(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *int64 {
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.BaseInfo == nil ||
		productInfo.BaseInfo.ProductStockInfo == nil {
		return nil
	}
	t := reflect.TypeOf(productInfo.BaseInfo.ProductStockInfo.CampaignStockNumSum)
	if t.Kind() == reflect.Int64 {
		return &productInfo.BaseInfo.ProductStockInfo.CampaignStockNumSum
	}
	return nil
}

// 通过Summary获取普通库存
func GetNormalStock(pid int64, packPlatform map[int64]*pack_platform.ProductItem) *int64 {
	productInfo, ok := packPlatform[pid]
	if !ok || productInfo == nil {
		return nil
	}
	if productInfo.BaseInfo == nil ||
		productInfo.BaseInfo.ProductStockInfo == nil {
		return nil
	}
	t := reflect.TypeOf(productInfo.BaseInfo.ProductStockInfo.NormalStockNumSum)
	if t.Kind() == reflect.Int64 {
		return &productInfo.BaseInfo.ProductStockInfo.NormalStockNumSum
	}
	return nil
}
