package ab

import (
	"errors"
	"math"
)

type SignificanceNumberParam struct {
	BaseAvg      float64 // 对照组均值
	ExpAvg       float64 // 实验组均值
	BaseVariance float64 // 对照组方差
	ExpVariance  float64 // 实验组方差
	BaseCnt      float64 // 对照组样本量
	ExpCnt       float64 // 实验组样本量
}

type SignificanceRatioParam struct {
	BaseRatio float64 // 对照组比率
	ExpRatio  float64 // 实验组比率
	BaseCnt   float64 // 对照组样本量
	ExpCnt    float64 // 实验组样本量
}

// SignificanceNumberType95Judge 95%数值类型显著校验
func SignificanceNumberType95Judge(param *SignificanceNumberParam) (bool, error) {
	return significanceNumberTypeJudge(param, 1.96)
}

// SignificanceNumberType90Judge 90%数值类型显著校验
func SignificanceNumberType90Judge(param *SignificanceNumberParam) (bool, error) {
	return significanceNumberTypeJudge(param, 1.64)
}

// SignificanceRatioType95Judge 95%比率类型显著校验
func SignificanceRatioType95Judge(param *SignificanceRatioParam) (bool, error) {
	return significanceRatioTypeJudge(param, 1.96)
}

// SignificanceRatioType90Judge 90%比率类型显著校验
func SignificanceRatioType90Judge(param *SignificanceRatioParam) (bool, error) {
	return significanceRatioTypeJudge(param, 1.64)
}

func significanceNumberTypeJudge(param *SignificanceNumberParam, significanceValue float64) (bool, error) {
	if param == nil || param.BaseAvg <= 0 || param.ExpAvg <= 0 || param.BaseVariance <= 0 || param.ExpVariance <= 0 || param.BaseCnt <= 0 || param.ExpCnt <= 0 {
		return false, errors.New("invalid param")
	}

	return math.Abs(param.ExpAvg-param.BaseAvg)/math.Sqrt(param.ExpVariance/param.ExpCnt+param.BaseVariance/param.BaseCnt) > significanceValue, nil
}

func significanceRatioTypeJudge(param *SignificanceRatioParam, significanceValue float64) (bool, error) {
	if param == nil || param.BaseRatio <= 0 || param.ExpRatio <= 0 || param.BaseCnt <= 0 || param.ExpCnt <= 0 {
		return false, errors.New("invalid param")
	}

	a := math.Sqrt(param.ExpRatio*(1-param.ExpRatio)/param.ExpCnt + param.BaseRatio*(1-param.BaseRatio)/param.BaseCnt)
	if a == 0 {
		return false, errors.New("significanceRatioTypeJudge sqrt is 0")
	}

	return math.Abs(param.ExpRatio-param.BaseRatio)/a > significanceValue, nil
}
