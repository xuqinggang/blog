package extension_domain

import (
	mdt "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_table_domain/extension"
	mdt_trend "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_trend_domain/extension"
	need_dump_dimension_extension "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/need_dump_dimension_domain/extension"
)

// RegisterAllExtensions 调用所有模块的 Register 函数来注册所有 extension_domain 的扩展点
func RegisterAllExtensions() {
	// 注册扩展点
	mdt.Register()
	mdt_trend.Register()
	need_dump_dimension_extension.Register()
}

func RegisterAllImpl() {
	// 注册扩展点的 impl
	mdt.RegisterImpl()
	mdt_trend.RegisterImpl()
	need_dump_dimension_extension.RegisterImpl()
}

func Init() {
	RegisterAllExtensions()
	RegisterAllImpl()
}
