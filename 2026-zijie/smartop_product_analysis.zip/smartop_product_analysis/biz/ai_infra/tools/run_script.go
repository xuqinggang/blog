package tools

import (
	"context"
	"fmt"
	"time"

	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gdp/env"
	"code.byted.org/gopkg/logs/v2"
	"github.com/bytedance/sonic"
	"github.com/cloudwego/eino/components/tool"
	eino_utils "github.com/cloudwego/eino/components/tool/utils"
	"github.com/cloudwego/eino/schema"
	"gopkg.in/resty.v1"
)

type RunScript struct{}

type RunScriptParams struct {
	Code string `json:"code" jsonschema:"required,description=需要运行的 python 代码"`
}

type RunScriptRequest struct {
	Code      string `json:"code"`
	SessionId string `json:"session_id"`
}

type CloseSessionRequest struct {
	SessionId string `json:"session_id"`
}

type CloseSessionResp struct {
	Status    string  `json:"status"`
	SessionId string  `json:"session_id"`
	Reason    *string `json:"reason,omitempty"`
}

type Figure struct {
	Type   string `json:"type,omitempty" jsonschema:"description=图表导出的图片类型，可选值：png、jpg、jpeg,enum=png,jpg,jpeg"`
	TosKey string `json:"tos_key,omitempty" jsonschema:"description=图片的object_key"`
	Url    string `json:"url,omitempty" jsonschema:"description=图片地址"`
	Source string `json:"source,omitempty" jsonschema:"description=图表类型"`
	Index  int    `json:"index,omitempty" jsonschema:"description=图表索引"`
}

type RunScriptRes struct {
	Status  string    `json:"status" jsonschema:"required,description=代码运行状态,enum=success,error"`
	Stdout  string    `json:"stdout,omitempty" jsonschema:"description=代码运行标准输出"`
	Stderr  string    `json:"stderr,omitempty" jsonschema:"description=代码运行错误输出"`
	Figures []*Figure `json:"figures,omitempty" jsonschema:"description=可视化图表导出的图片，当代码中调用 matplotlib.pyplot 或 seaborn 等库绘制图表时，会导出图片"`
	// Meta    interface{} `json:"meta,omitempty" jsonschema:"description=代码运行元信息（执行耗时、资源限制）"`
}

const (
	RunScriptToolName = "run_script"
	RunScriptToolDesc = "运行python脚本并获取结果"
)

func CloseSession(ctx context.Context, sessionId string) error {
	url := "https://5j0o6drj.fn.bytedance.net/close_session"
	if env.IsBoe() {
		url = "https://guzbn1gz.fn-boe.bytedance.net/close_session"
	}

	req := &CloseSessionRequest{
		SessionId: sessionId,
	}
	resp := &CloseSessionResp{}
	runResp, err := resty.New().
		SetTimeout(60 * time.Second).
		R().
		SetBody(req).
		SetResult(resp).
		Post(url)

	if err != nil {
		logs.CtxWarn(ctx, "[CloseSession] CloseSession failed, err=%v", err)
		return err
	}
	if runResp == nil || runResp.StatusCode() != 200 {
		logs.CtxWarn(ctx, "[CloseSession] CloseSession failed, resp is nil or status code is not 200")
		return fmt.Errorf("CloseSession failed, resp is nil or status code is not 200")
	}
	if resp.Status != "closed" {
		logs.CtxWarn(ctx, "[CloseSession] CloseSession failed, resp status is not success, reason=%v", resp.Reason)
		return fmt.Errorf("CloseSession failed, resp status is not success, reason=%v", resp.Reason)
	}

	return nil
}

func NewRunScriptTool() *RunScript {
	return &RunScript{}
}

func (d *RunScript) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return eino_utils.GoStruct2ToolInfo[RunScriptParams](RunScriptToolName, RunScriptToolDesc)
}

func (d *RunScript) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *RunScriptParams
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	url := "https://5j0o6drj.fn.bytedance.net/run"
	if env.IsBoe() {
		url = "https://guzbn1gz.fn-boe.bytedance.net/run"
	}

	resp := &RunScriptRes{}
	req := &RunScriptRequest{
		Code: params.Code,
	}

	syncMap, ok := ctx.Value(consts.CtxSyncMap).(*utils.SyncMap)
	if ok && syncMap != nil {
		sessionId, ok := syncMap.Get(consts.SyncMapSessionIdKey)
		if ok {
			req.SessionId = sessionId.(string)
		}
	}

	runResp, err := resty.New().
		SetTimeout(60 * time.Second).
		R().
		SetBody(req).
		SetResult(resp).
		Post(url)

	if err != nil {
		logs.CtxError(ctx, "[RunScript] RunScript failed, err=%v", err)
		return fmt.Sprintf("RunScript failed, err=%s", err.Error()), nil
	}
	if runResp == nil || runResp.StatusCode() != 200 {
		logs.CtxError(ctx, "[RunScript] RunScript failed, resp is nil or status code is not 200")
		return "RunScript failed, resp is nil or status code is not 200", nil
	}

	res, err := sonic.MarshalString(resp)
	if err != nil {
		return "", err
	}
	return res, nil
}
