package tools

import (
	"context"
	"fmt"

	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/libra"
	"github.com/bytedance/sonic"
	"github.com/cloudwego/eino/components/tool"
	eino_utils "github.com/cloudwego/eino/components/tool/utils"
	"github.com/cloudwego/eino/schema"
)

type CommonFlightParam struct {
	FlightId int64 `json:"flight_id" jsonschema:"required,description=实验ID"`
}

type GetMetricGroupDetailParam struct {
	AppId         int64 `json:"app_id" jsonschema:"required,description=应用id"`
	MetricGroupId int64 `json:"metric_group_id" jsonschema:"required,description=指标组id"`
}

type GetDimValueListParam struct {
	AppId int64 `json:"app_id" jsonschema:"required,description=应用id"`
	DimId int64 `json:"dim_id" jsonschema:"required,description=维度id"`
}

type GetFlightDetailResult struct {
	Data     *libra.Flight `json:"data,omitempty" jsonschema:"description=实验详情"`
	ErrorMsg string        `json:"error_msg,omitempty" jsonschema:"description=错误信息"`
}

type GetFlightBaseUserResult struct {
	Data     *libra.FlightBaseUserData `json:"data,omitempty" jsonschema:"description=实验进组人数信息"`
	ErrorMsg string                    `json:"error_msg,omitempty" jsonschema:"description=错误信息"`
}

type GetMetricGroupDetailResult struct {
	Data     *libra.MetricGroupDetailData `json:"data,omitempty" jsonschema:"description=指标组详情"`
	ErrorMsg string                       `json:"error_msg,omitempty" jsonschema:"description=错误信息"`
}

type GetFlightDetail struct{}

type GetFlightBaseUser struct{}

type GetMetricGroupDetail struct{}

func NewGetFlightDetailTool() *GetFlightDetail {
	return &GetFlightDetail{}
}

func NewGetFlightBaseUserTool() *GetFlightBaseUser {
	return &GetFlightBaseUser{}
}

func NewGetMetricGroupDetailTool() *GetMetricGroupDetail {
	return &GetMetricGroupDetail{}
}

func (d *GetFlightDetail) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return eino_utils.GoStruct2ToolInfo[CommonFlightParam]("get_flight_detail", "查询实验详情，返回的结果类型定义如下：\n\n```ts\n/** GetFlightDetailResult 实验详情响应 */\nexport interface GetFlightDetailResult {\n  /** 实验详情 */\n  data?: Flight;\n  /** 错误信息 */\n  error_msg?: string;\n}\n\n/** Flight 实验详情 */\nexport interface Flight {\n  /** 实验id */\n  id: number;\n  /** 分流类型，0:uid, 1:did, 2:rid, 3:union, 4:uuid, 5:cdid, 6:ssid, 7:webid, 8:pkid, 9:纯uid分流 */\n  inherit_type: number;\n  /** 实验状态，0:已结束, 1:进行中, 2:待调度, 3:调试中, 4:已暂停, 91同0 */\n  status: number;\n  /** 实验名称 */\n  name: string;\n  /** 实验描述 */\n  description: string;\n  /** 实验开始时间，格式为yyyy-MM-dd HH:mm:ss */\n  start_time: string;\n  /** 实验结束时间，格式为yyyy-MM-dd HH:mm:ss */\n  end_time: string;\n  /** 实验目标 */\n  expectation: string;\n  /** 实验分组 */\n  versions: Version[];\n  /** 实验关联的appid */\n  app_id: number;\n  /** 实验关联的app名称 */\n  app_name: string;\n  /** 实验关联的productid */\n  product_id: number;\n  /** 实验关联的product名称 */\n  product_name: string;\n  /** 实验关联的product */\n  product: string;\n  /** 实验关联的监控指标分组 */\n  watching_metric_groups: WatchingMetricGroup[];\n}\n\n/** Version 实验分组 */\nexport interface Version {\n  /** 实验分组配置 */\n  config: string;\n  /** 实验分组描述 */\n  description: string;\n  /** 实验分组id */\n  id: number;\n  /** 实验分组名称 */\n  name: string;\n  /** 状态， 0:已关闭, 1:有效 */\n  status: number;\n  /** 实验分组类型，0:对照组, 1:实验组 */\n  type: number;\n  /** 实验组用户分群名称 */\n  user_tag: string;\n  /** 流量权重比，仅针对流量不均等实验有意义，权重比值0 ~ 1000，实验每个version的weight加起来一定等于1000 */\n  weight: number;\n  /** 实验分组实际流量占比，0 ~ 100 */\n  real_traffic: number;\n}\n\n/** WatchingMetricGroup 指标组监控 */\nexport interface WatchingMetricGroup {\n  /** 指标组id */\n  metric_group_id: number;\n  /** 指标组名称 */\n  metric_group_name: string;\n  /** 指标组类型 */\n  metric_group_type: string;\n  /** 指标组维度 */\n  dimensions: any[];\n}\n```")
}

func (d *GetFlightBaseUser) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return eino_utils.GoStruct2ToolInfo[CommonFlightParam]("get_flight_base_user", "查询实验进组人数信息，返回的结果类型定义如下：\n\n```ts\n/** GetFlightBaseUserResult 实验进组人数信息响应 */\nexport interface GetFlightBaseUserResult {\n  /** 实验进组人数信息 */\n  data?: FlightBaseUserData;\n  /** 错误信息 */\n  error_msg?: string;\n}\n\n/** FlightBaseUserData 实验进组人数数据 */\nexport interface FlightBaseUserData {\n  /** 实验进组人数总和 */\n  sum_baseuser: number;\n  /** 分流方式, uid/did/uuid等 */\n  hash_strategy: string;\n  /** 实验进组人数列表 */\n  baseuser: Baseuser[];\n}\n\n/** Baseuser 实验分组进组人数 */\nexport interface Baseuser {\n  /** 进组人数 */\n  baseuser: number;\n  /** 实验分组名称 */\n  vname: string;\n  /** 实验分组id */\n  vid: number;\n}\n```")
}

func (d *GetMetricGroupDetail) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return eino_utils.GoStruct2ToolInfo[GetMetricGroupDetailParam]("get_metric_group_detail", "查询指标组详情，返回的结果类型定义如下：\n\n```ts\n/** GetMetricGroupDetailResult 指标组详情响应 */\nexport interface GetMetricGroupDetailResult {\n  /** 指标组详情 */\n  data?: MetricGroupDetailData;\n  /** 错误信息 */\n  error_msg?: string;\n}\n\n/** MetricGroupDetailData 指标组详情数据 */\nexport interface MetricGroupDetailData {\n  /** 指标组id */\n  id: number;\n  /** 指标组名称 */\n  name: string;\n  /** 指标组状态，1表示正常，0表示下线 */\n  status: number;\n  /** 指标组描述 */\n  description: string;\n  /** 累计支持 */\n  merge_types: MergeTypes;\n  /** 指标组指标列表 */\n  metrics: Metric[];\n  /** 指标组维度列表 */\n  dimensions: Dimension[];\n}\n\n/** MergeTypes 累计支持类型 */\nexport interface MergeTypes {\n  /** 从头累计开始时间 */\n  total_start_time: number;\n  /** 支持灵活累计，1表示支持 */\n  support_accumulate: number;\n  /** 支持从头累计，1表示支持 */\n  support_total: number;\n  /** 支持求平均值，1表示支持 */\n  support_avg: number;\n}\n\n/** Metric 指标 */\nexport interface Metric {\n  /** 指标id */\n  id: number;\n  /** 指标名称 */\n  name: string;\n  /** 指标描述 */\n  description: string;\n  /** 指标状态，1表示正常，0表示下线 */\n  status: number;\n  /** 指标key */\n  key: string;\n  /** 指标文件 */\n  file: string;\n  /** 是否可见，true表示可见 */\n  visible: boolean;\n  /** 指标类型，0表示负向，1表示正向 */\n  benefit_type: number;\n  /** 指标sql */\n  metric_sql: string;\n}\n\n/** Dimension 维度 */\nexport interface Dimension {\n  /** 维度id */\n  id: number;\n  /** 维度名称 */\n  name: string;\n  /** 维度描述 */\n  desc: string;\n  /** 维度值列表 */\n  dim_values: DimValue[];\n}\n\n/** DimValue 维度值 */\nexport interface DimValue {\n  /** 维度值id */\n  id: number;\n  /** 维度值名称 */\n  name: string;\n  /** 维度值描述 */\n  desc: string;\n  /** 维度key */\n  dim_key: string;\n  /** 维度id */\n  dim_id: number;\n  /** 排序 */\n  order_num: number;\n}\n```")
}

func (d *GetFlightDetail) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *CommonFlightParam
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	resp, err := libra.GetFlightDetail(ctx, params.FlightId)
	if err != nil {
		return fmt.Sprintf("获取实验详情失败，错误信息: %s", err.Error()), nil
	}
	if resp.Code != 0 {
		return fmt.Sprintf("获取实验详情失败，错误信息: %s", resp.Message), nil
	}
	if resp.Data == nil {
		return "获取实验详情成功，但是返回数据为空", nil
	}

	res, err := sonic.MarshalString(resp.Data.Flight)
	if err != nil {
		return "", err
	}
	return res, nil
}

func (d *GetFlightBaseUser) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *CommonFlightParam
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	resp, err := libra.GetFlightBaseUser(ctx, params.FlightId)
	if err != nil {
		return fmt.Sprintf("获取实验进组人数信息失败，错误信息: %s", err.Error()), nil
	}
	if resp.Code != 0 {
		return fmt.Sprintf("获取实验进组人数信息失败，错误信息: %s", resp.Message), nil
	}
	if resp.Data == nil {
		return "获取实验进组人数信息成功，但是返回数据为空", nil
	}

	res, err := sonic.MarshalString(resp.Data)
	if err != nil {
		return "", err
	}
	return res, nil
}

func (d *GetMetricGroupDetail) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *GetMetricGroupDetailParam
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	resp, err := libra.GetMetricGroupDetail(ctx, params.AppId, params.MetricGroupId)
	if err != nil {
		return fmt.Sprintf("获取指标组详情失败，错误信息: %s", err.Error()), nil
	}
	if resp.Code != 0 {
		return fmt.Sprintf("获取指标组详情失败，错误信息: %s", resp.Message), nil
	}
	if resp.Data == nil {
		return "获取指标组详情成功，但是返回数据为空", nil
	}

	res, err := sonic.MarshalString(resp.Data)
	if err != nil {
		return "", err
	}
	return res, nil
}
