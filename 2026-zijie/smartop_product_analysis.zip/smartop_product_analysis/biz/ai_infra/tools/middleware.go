package tools

import (
	"context"
	"encoding/json"
	"fmt"

	"code.byted.org/ecom/compass_strategy_toolbox/util/co"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tos"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"
	"github.com/cloudwego/eino/compose"
)

type DataInfo struct {
	ObjectKey   string          `json:"object_key" jsonschema:"required,description=当前数据查询结果在TOS中的key"`
	Data        [][]interface{} `json:"data,omitempty" jsonschema:"description=查询到的数据，用于上传到tos，不直接给AI消费"`
	DataPreview *string         `json:"data_preview,omitempty" jsonschema:"description=查询到的数据预览，主要用于前端展示，不给AI消费"`
	Description string          `json:"description" jsonschema:"required,description=数据描述"`
}

type GetDataToolRes struct {
	Data     []*DataInfo `json:"data,omitempty" jsonschema:"description=查询到的数据"`
	ErrorMsg string      `json:"error_msg,omitempty" jsonschema:"description=错误信息"`
}

func GetDataList(ctx context.Context) ([]*DataInfo, error) {
	syncMap, ok := ctx.Value(consts.CtxSyncMap).(*utils.SyncMap)
	if !ok || syncMap == nil {
		return nil, fmt.Errorf("syncMap is nil")
	}

	dataList, ok := syncMap.Get(consts.SyncMapDataListKey)
	if !ok || dataList == nil {
		return nil, nil
	}

	_dataList, ok := dataList.([]*DataInfo)
	if !ok || len(_dataList) == 0 {
		return nil, fmt.Errorf("dataList type assertion failed")
	}

	return _dataList, nil
}

func DeleteDataList(ctx context.Context) {
	syncMap, ok := ctx.Value(consts.CtxSyncMap).(*utils.SyncMap)
	if !ok || syncMap == nil {
		logs.CtxError(ctx, "[DeleteDataList] syncMap is nil")
		return
	}

	syncMap.Delete(consts.SyncMapDataListKey)
}

// 数据处理中间件，要确保工具返回的都是GetDataToolRes格式，如果不是则跳过
func ProcessDataMiddleware(next compose.InvokableToolEndpoint) compose.InvokableToolEndpoint {
	return func(ctx context.Context, input *compose.ToolInput) (resp *compose.ToolOutput, err error) {
		resp, err = next(ctx, input)
		if err != nil {
			return nil, err
		}

		syncMap, ok := ctx.Value(consts.CtxSyncMap).(*utils.SyncMap)
		if !ok || syncMap == nil {
			return nil, fmt.Errorf("[ProcessDataMiddleware] syncMap is nil")
		}

		var dataRes *GetDataToolRes
		_err := json.Unmarshal([]byte(resp.Result), &dataRes)
		if _err != nil || dataRes == nil || len(dataRes.Data) == 0 || dataRes.ErrorMsg != "" {
			// 如果类型不匹配、数据为空、有错误信息，直接放行
			return resp, nil
		}

		// 并发上传数据到tos
		cc := co.NewConcurrent(ctx)
		for _, data := range dataRes.Data {
			currentData := data
			cc.GoV2(func() error {
				// 将interface{}转换为string
				records := make([][]string, 0)
				for _, row := range currentData.Data {
					record := make([]string, 0)
					for _, cell := range row {
						record = append(record, convert.ToString(cell))
					}
					records = append(records, record)
				}
				// 上传数据到TOS
				objKey, _err := tos.UploadRecordsAsCSV(ctx, records, nil)
				if _err != nil {
					logs.CtxError(ctx, "[ProcessDataMiddleware] Error uploading data to TOS: %v", _err)
					return _err
				}
				currentData.ObjectKey = objKey // 上传成功后，将objectKey赋值给currentData.ObjectKey
				return nil
			})
		}
		err = cc.WaitV2()
		if err != nil {
			logs.CtxError(ctx, "[ProcessDataMiddleware] Concurrent upload data to TOS failed: %v", err)
			return nil, err
		}

		dataList, err := GetDataList(ctx)
		if err != nil {
			logs.CtxError(ctx, "[ProcessDataMiddleware] GetDataList failed, err=%v", err)
			return nil, err
		}
		dataList = append(dataList, dataRes.Data...) // 合并dataRes.Data到dataList
		syncMap.Set(consts.SyncMapDataListKey, dataList)

		result, err := json.Marshal(dataRes)
		if err != nil {
			logs.CtxError(ctx, "[ProcessDataMiddleware] Error marshalling dataRes: %v", err)
			return nil, err
		}
		resp.Result = string(result)

		return resp, nil
	}
}
