package tools

import (
	"context"
	"fmt"

	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tqs"
	"code.byted.org/gopkg/logs/v2"
	"github.com/bytedance/sonic"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/components/tool/utils"
	"github.com/cloudwego/eino/schema"
)

type ExecuteSqlTool struct{}

type ExecuteSqlToolParams struct {
	Sql string `json:"sql" jsonschema:"required,description=要执行的SQL语句"`
}

func NewExecuteSqlTool() *ExecuteSqlTool {
	return &ExecuteSqlTool{}
}

func (d *ExecuteSqlTool) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return utils.GoStruct2ToolInfo[ExecuteSqlToolParams]("execute_sql", "执行SQL语句")
}

func (d *ExecuteSqlTool) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *ExecuteSqlToolParams
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	if params.Sql == "" {
		return "sql is empty", nil
	}

	// TODO：hive sql 校验
	tqsResp, tqsErr := tqs.QuerySync(ctx, params.Sql, false)
	if tqsErr != nil {
		logs.CtxWarn(ctx, "[ExecuteSqlTool] query sync failed, sql:%s, err:%v", params.Sql, tqsErr)
		return fmt.Sprintf("sql 执行失败, 错误信息:%s", tqsErr.Error()), nil
	}

	res, err := sonic.MarshalString(tqsResp)
	if err != nil {
		logs.CtxError(ctx, "[ExecuteSqlTool] marshal tqsResp failed, err:%v", err)
		return "", err
	}
	return res, nil
}
