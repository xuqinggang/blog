package tools

import (
	"context"
	"fmt"

	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/mcp"
	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino-ext/components/model/ark"
	"github.com/cloudwego/eino/components/tool"
	eino_utils "github.com/cloudwego/eino/components/tool/utils"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/flow/agent/react"
	"github.com/cloudwego/eino/schema"
	"github.com/volcengine/volcengine-go-sdk/service/arkruntime/model"
)

type MermaidToolParams struct {
	Query string `json:"query" jsonschema:"required,description=生成 Mermaid 图表的详细描述，包括图表类型、图表数据（需要详细说明具体的数据）、图表标题、坐标轴（需要包含含刻度、标签和标题）、数据标签、图表样式等。描述必须涵盖生成该图表的所有信息，不能使用上下文笼统概括。"`
}

type MermaidTool struct{}

func NewMermaidTool() *MermaidTool {
	return &MermaidTool{}
}

func (d *MermaidTool) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return eino_utils.GoStruct2ToolInfo[MermaidToolParams]("mermaid_chart", "Mermaid 图表生成工具，能够根据描述生成合适的 Mermaid 图表并校验 Mermaid 图表的语法是否正确。")
}

func (d *MermaidTool) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (res string, err error) {
	var params *MermaidToolParams
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	if params == nil || params.Query == "" {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", "Query 不能为空"), nil
	}

	// 获取方舟配置
	arkConfig, err := biz_info.GetArkConfig(ctx)
	if err != nil || arkConfig == nil {
		logs.CtxError(ctx, "[MermaidTool] GetArkConfig failed, err=%v", err)
		return
	}

	// 获取ai配置
	aiConfig, err := biz_info.GetArtificialIntelligenceConfig(ctx)
	if err != nil || aiConfig == nil {
		logs.CtxError(ctx, "[MermaidTool] GetArtificialIntelligenceConfig failed, err=%v", err)
		return "", err
	}

	// get system prompt
	systemPrompt, err := fornax.GetPromptWithParams(ctx, "product_analysis.ai_analysis.mermaid", nil)
	if err != nil {
		logs.CtxError(ctx, "[MermaidTool] get mermaid prompt failed, err=%v", err)
		return
	}

	// model
	mermaidTemp := float32(0)
	mermaidMaxTokens := int(4096)
	modelKey := "deepseek-v3.1" // 默认使用deepseek-v3.1的模型
	if aiConfig.Model != nil && len(aiConfig.Model["mermaid_model"]) > 0 {
		modelKey = aiConfig.Model["mermaid_model"]
	}
	mermaidModel, err := ark.NewChatModel(ctx, &ark.ChatModelConfig{
		APIKey:      arkConfig.ApiKey,
		Model:       arkConfig.Endpoint[modelKey],
		Temperature: &mermaidTemp,
		MaxTokens:   &mermaidMaxTokens,
		Thinking: &model.Thinking{
			Type: model.ThinkingTypeDisabled, // 禁用思考
		},
	})
	if err != nil {
		logs.CtxError(ctx, "[MermaidTool] NewChatModel failed, err=%v", err)
		return
	}

	// tool
	tools, err := mcp.GetByteMCPTools(ctx, "mermaid", []string{"mermaid_check_mermaid_check"})
	if err != nil {
		logs.CtxError(ctx, "[MermaidTool] GetMCPTools failed, err=%v", err)
		return
	}

	mermaidReactAgent, err := react.NewAgent(ctx, &react.AgentConfig{
		ToolCallingModel: mermaidModel,
		ToolsConfig: compose.ToolsNodeConfig{
			Tools:               tools,
			UnknownToolsHandler: UnknownToolsHandler,
		},
		MaxStep: 20,
	})
	if err != nil {
		logs.CtxError(ctx, "[MermaidTool] NewAgent failed, err=%v", err)
		return
	}

	// run model
	result, err := mermaidReactAgent.Generate(ctx, []*schema.Message{
		schema.SystemMessage(systemPrompt),
		schema.UserMessage(params.Query),
	})
	if err != nil {
		logs.CtxError(ctx, "[MermaidTool] Generate failed, err=%v", err)
		return
	}
	if result != nil {
		res = utils.UnescapeUnicode(result.Content)
	}

	return

}
