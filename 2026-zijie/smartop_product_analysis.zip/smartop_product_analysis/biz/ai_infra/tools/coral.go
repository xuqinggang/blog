package tools

import (
	"context"
	"fmt"
	"strings"

	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/coral_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/overpass/ecom_smartop_guard/kitex_gen/ecom/smartop/guard"
	"github.com/bytedance/sonic"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/components/tool/utils"
	"github.com/cloudwego/eino/schema"
)

type QueryHiveDDLParam struct {
	DBName    string `json:"db_name" jsonschema:"required,description=hive表所在数据库名称"`
	TableName string `json:"table_name" jsonschema:"required,description=hive表表名"`
}

type CoralChatParam struct {
	Query string `json:"query" jsonschema:"required,description=用于进行找表、找数据集、找文档的提问内容，查询的时候除了传入问题，额外传入需要的指标、关键词可提升准确性"`
}

type QueryHiveDDL struct{}

type QueryHivePartitions struct{}

type CoralQuery struct{}

func NewQueryHiveDDLTool() *QueryHiveDDL {
	return &QueryHiveDDL{}
}

func NewQueryHivePartitionsTool() *QueryHivePartitions {
	return &QueryHivePartitions{}
}

func NewCoralQueryTool() *CoralQuery {
	return &CoralQuery{}
}

func (d *QueryHiveDDL) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return utils.GoStruct2ToolInfo[QueryHiveDDLParam]("query_hive_ddl", "根据库名和表名查询Hive表完整的DDL信息")
}

func (d *QueryHivePartitions) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return utils.GoStruct2ToolInfo[QueryHiveDDLParam]("query_hive_partitions", "根据库名和表名查询Hive表的最近分区信息。partName：分区描述，通常包含日期")
}

func (d *CoralQuery) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return utils.GoStruct2ToolInfo[CoralChatParam]("coral_query", "根据问题查询Hive表、数据集、文档等信息")
}

func (d *QueryHiveDDL) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *QueryHiveDDLParam
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	// 库表拆分问题兜底
	if len(params.DBName) > 0 && len(params.TableName) > 0 {
		if strings.HasPrefix(params.TableName, params.DBName+".") {
			params.TableName = strings.TrimPrefix(params.TableName, params.DBName+".")
		}
	}

	resp, err := coral_service.QueryHiveDDL(ctx, &coral_service.CoralQueryDDLReq{
		DbName:    params.DBName,
		TableName: params.TableName,
	})
	if err != nil {
		return fmt.Sprintf("查询Hive表DDL失败，%s", err.Error()), nil
	}

	res, err := sonic.MarshalString(resp)
	if err != nil {
		return "", err
	}
	return res, nil
}

func (d *QueryHivePartitions) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *QueryHiveDDLParam
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	// 库表拆分问题兜底
	if len(params.DBName) > 0 && len(params.TableName) > 0 {
		if strings.HasPrefix(params.TableName, params.DBName+".") {
			params.TableName = strings.TrimPrefix(params.TableName, params.DBName+".")
		}
	}

	resp, err := coral_service.QueryHivePartitions(ctx, &coral_service.CoralQueryDDLReq{
		DbName:    params.DBName,
		TableName: params.TableName,
		Limit:     5,
	})
	if err != nil {
		return fmt.Sprintf("查询Hive表分区失败，%s", err.Error()), nil
	}

	res, err := sonic.MarshalString(resp)
	if err != nil {
		return "", err
	}
	return res, nil
}

func (d *CoralQuery) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *CoralChatParam
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	userName := ""
	userInfo, ok := ctx.Value(consts.CtxUserInfo).(*guard.OpUser)
	if ok {
		userName = userInfo.UserName
	}

	resp, err := coral_service.CoralChat(ctx, &coral_service.CoralChatQueryReq{
		Query:        fmt.Sprintf("%s\n，仅返回Hive表", params.Query),
		Mode:         "DEEP_THINK", // QUICK 快思考模式 DEEP_THINK 慢思考模式
		BusinessLine: "中国区电商",
		RealUser:     userName,
	})

	if err != nil {
		return fmt.Sprintf("查询Hive表、数据集、文档等信息失败，%s", err.Error()), nil
	}

	res, err := sonic.MarshalString(resp)
	if err != nil {
		return "", err
	}
	return res, nil
}
