package tools

import (
	"context"
	"errors"
	"fmt"

	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/overpass/ecom_smartop_guard/kitex_gen/ecom/smartop/guard"
	"github.com/bytedance/sonic"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/components/tool/utils"
	"github.com/cloudwego/eino/schema"
)

const (
	GetDocContentToolName = "get_doc_content"
	GetDocContentToolDesc = "根据文档链接获取飞书云文档内容"
	CheckDocPermissionToolName = "check_doc_permission"
	CheckDocPermissionToolDesc = "校验用户是否有查看飞书云文档的权限"
)

type GetDocContent struct {
	LarkService lark_service.ILarkService
}

type CheckDocPermission struct {
	LarkService lark_service.ILarkService
}

type CheckDocPermissionToolParams struct {
	DocUrl string `json:"doc_url" jsonschema:"required,description=飞书云文档链接，例如：https://bytedance.larkoffice.com/wiki/VOnewKNkVin0qVkuXKBcTqNwnEc"`
}

type GetDocContentToolParams struct {
	DocUrl string `json:"doc_url" jsonschema:"required,description=飞书云文档链接，例如：https://bytedance.larkoffice.com/wiki/VOnewKNkVin0qVkuXKBcTqNwnEc"`
}

func NewCheckDocPermissionTool(larkService lark_service.ILarkService) *CheckDocPermission {
	return &CheckDocPermission{LarkService: larkService}
}

func NewGetDocContentTool(larkService lark_service.ILarkService) *GetDocContent {
	return &GetDocContent{LarkService: larkService}
}

func (d *GetDocContent) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return utils.GoStruct2ToolInfo[GetDocContentToolParams](GetDocContentToolName, GetDocContentToolDesc)
}

func (d *CheckDocPermission) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return utils.GoStruct2ToolInfo[CheckDocPermissionToolParams](CheckDocPermissionToolName, CheckDocPermissionToolDesc)
}

func (d *GetDocContent) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *GetDocContentToolParams
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	// 从ctx中获取userInfo
	userInfo, ok := ctx.Value(consts.CtxUserInfo).(*guard.OpUser)
	if !ok {
		logs.CtxError(ctx, "[GetDocContentTool] user not found in ctx")
		return "", errors.New("user not found in ctx")
	}

	// 获取飞书云文档内容
	resp, err := d.LarkService.GetDocContent(ctx, params.DocUrl, &userInfo.EmployeeId)
	if err != nil {
		return fmt.Sprintf("获取飞书云文档内容失败，错误信息：%s", err.Error()), nil
	}
	return resp, nil
}

func (d *CheckDocPermission) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *CheckDocPermissionToolParams
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	// 从ctx中获取userInfo
	userInfo, ok := ctx.Value(consts.CtxUserInfo).(*guard.OpUser)
	if !ok {
		logs.CtxError(ctx, "[CheckDocPermissionTool] user not found in ctx")
		return "", errors.New("user not found in ctx")
	}

	// 校验飞书云文档是否有权限
	resp, err := d.LarkService.CheckDocPermission(ctx, params.DocUrl, &userInfo.EmployeeId)
	if err != nil {
		return fmt.Sprintf("校验飞书云文档是否有权限失败，错误信息：%s", err.Error()), nil
	}
	// if !resp.HasPermission {
	// 	// 如果没有权限，返回compose.InterruptAndRerun中断
	// 	return "", compose.InterruptAndRerun
	// }

	res, err := sonic.MarshalString(resp)
	if err != nil {
		return "", err
	}
	return res, nil
}
