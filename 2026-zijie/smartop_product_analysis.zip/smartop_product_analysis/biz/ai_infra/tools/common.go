package tools

import (
	"context"
	"fmt"

	"code.byted.org/gopkg/logs/v2"
)

func UnknownToolsHandler(ctx context.Context, name, input string) (string, error) {
	logs.CtxWarn(ctx, "[UnknownToolsHandler] tool not found, name=%s, input=%s\n", name, input)
	return fmt.Sprintf("未知工具「%s」，请检查名称。", name), nil
}
