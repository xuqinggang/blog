package tools

import (
	"context"
	"fmt"

	ai_infra_utils "code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/utils"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/components/tool/utils"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/schema"
	"github.com/thoas/go-funk"
)

const (
	TodoStatusPending    = "pending"
	TodoStatusInProgress = "in_progress"
	TodoStatusCompleted  = "completed"
	TodoStatusCanceled   = "canceled"
)

const (
	TodoPriorityHigh   = "high"
	TodoPriorityMedium = "medium"
	TodoPriorityLow    = "low"
)

type TodoItem struct {
	ID       int    `json:"id" jsonschema:"required,description=任务的唯一标识，从1开始递增"`
	Title    string `json:"title" jsonschema:"required,description=任务的标题"`
	Priority string `json:"priority" jsonschema:"required,description=任务的优先级，可选值为high、medium、low，默认值为medium,enum=high,medium,low,default=medium"`
	Status   string `json:"status" jsonschema:"required,description=任务的状态，可选值为pending、in_progress、completed、canceled，默认值为pending,enum=pending,in_progress,completed,canceled,default=pending"`
}

type TodoWriteParams struct {
	Todos []*TodoItem `json:"todos" jsonschema:"required,description=要写入的任务列表"`
}

type TodoHandler func(ctx context.Context, todos []*TodoItem) error

type TodoWrite struct {
	todoHandler TodoHandler
}

const (
	TodoWriteToolName = "todo_write"
	TodoWriteToolDesc = "更新所有的任务列表。**注意**，此工具不能和其他工具并行调用"
)

func NewTodoWrite(todoHandler TodoHandler) *TodoWrite {
	return &TodoWrite{
		todoHandler: todoHandler,
	}
}

// 提供一个空的todo_write工具，用于大模型追踪任务进度，请确保Graph State中包含Todos字段
func (d *TodoWrite) Info(ctx context.Context) (*schema.ToolInfo, error) {
	return utils.GoStruct2ToolInfo[TodoWriteParams](TodoWriteToolName, TodoWriteToolDesc)
}

func (d *TodoWrite) InvokableRun(ctx context.Context, argumentsInJSON string, _ ...tool.Option) (string, error) {
	var params *TodoWriteParams
	if _err := ai_infra_utils.UnmarshalToolArguments(argumentsInJSON, &params); _err != nil {
		return fmt.Sprintf("非法参数，请检查修改后重新执行：【%s】", _err.Error()), nil
	}

	unFinishedTodos, ok := funk.Filter(params.Todos, func(todo *TodoItem) bool {
		return todo.Status == TodoStatusPending || todo.Status == TodoStatusInProgress
	}).([]*TodoItem)
	if !ok {
		return "", fmt.Errorf("invalid todo items")
	}

	message := fmt.Sprintf("已更新任务列表，共%d个任务", len(params.Todos))
	if len(unFinishedTodos) > 0 {
		message += fmt.Sprintf("，其中%d个任务为未完成状态", len(unFinishedTodos))
	} else {
		message += "，所有任务均已完成"
	}

	if d.todoHandler != nil {
		// 如果传递了todoHandler，调用todoHandler处理todos
		if err := d.todoHandler(ctx, params.Todos); err != nil {
			return "", fmt.Errorf("failed to handle todos: %w", err)
		}
	} else {
		// 将todos写入state - 使用反射确保兼容性
		if err := compose.ProcessState(ctx, func(ctx context.Context, state any) error {
			return ai_infra_utils.SetStateValue(state, "Todos", params.Todos)
		}); err != nil {
			return "", fmt.Errorf("failed to write todos to state: %w", err)
		}
	}

	return message, nil
}
