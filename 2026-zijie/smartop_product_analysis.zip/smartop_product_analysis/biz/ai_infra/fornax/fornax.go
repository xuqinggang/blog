package fornax

import (
	"context"
	"fmt"
	"sync"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	fornax_callback "code.byted.org/flow/eino-byted-ext/callbacks/fornax"
	"code.byted.org/flowdevops/fornax_sdk"
	"code.byted.org/flowdevops/fornax_sdk/domain"
	"code.byted.org/flowdevops/fornax_sdk/domain/chatmodel"
	"code.byted.org/flowdevops/fornax_sdk/domain/prompt"
	"code.byted.org/flowdevops/fornax_sdk/domain/prompt/execution"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/overpass/ecom_smartop_guard/kitex_gen/ecom/smartop/guard"
	"github.com/cloudwego/eino/callbacks"
)

var (
	fornaxClient *fornax_sdk.Client
	initOnce     sync.Once
)

func Init() {
	initOnce.Do(func() {
		ctx := context.Background()
		var err error
		fornaxClient, err = createFornaxClient(ctx)
		if err != nil {
			logs.CtxError(ctx, "[fornax] Init fornax client failed, err=%v", err)
			panic(err)
		}
		logs.CtxInfo(ctx, "[fornax] Init fornax client success")
	})
}

func createFornaxClient(ctx context.Context) (*fornax_sdk.Client, error) {
	fornaxConfig, err := biz_info.GetFornaxConfig(ctx)
	if err != nil || fornaxConfig == nil {
		logs.CtxError(ctx, "[createFornaxClient] GetFornaxConfig failed, err=%v", err)
		return nil, err
	}

	config := &domain.Config{
		Identity: &domain.Identity{
			AK: fornaxConfig.AccessKey,
			SK: fornaxConfig.SecretKey,
		},
	}

	client, err := fornax_sdk.NewClient(config)
	if err != nil {
		logs.CtxError(ctx, "[createFornaxClient] Init fornaxClient failed, err=%v", err)
		return nil, err
	}

	fornaxCallback := fornax_callback.NewDefaultCallbackHandler(client)
	callbacks.AppendGlobalHandlers(fornaxCallback)

	return client, nil
}

func GetFornaxClient(ctx context.Context) *fornax_sdk.Client {
	Init()
	return fornaxClient
}

// 注入tag到fornax trace：https://bytedance.larkoffice.com/wiki/MgRHwFsWHi6t3nkPPMOc78UcnJg
func InjectFornaxTrace(ctx context.Context, user *guard.OpUser, messageId string, sessionId string) context.Context {
	if user != nil && user.Email != nil {
		ctx = fornax_sdk.InjectUserID(ctx, *user.Email)
	}
	if messageId != "" {
		ctx = fornax_sdk.InjectMessageID(ctx, messageId)
	}
	kvs := map[string]string{"env": utils.GetEnv()}
	if sessionId != "" {
		kvs["session_id"] = sessionId
	}
	ctx = fornax_sdk.InjectKVs(ctx, kvs) // 业务自定义字段，注入到后会上报到tag
	return ctx
}

// fornax Prompt as a Service：https://bytedance.larkoffice.com/wiki/E7Zhw7mCIiuKKOk2C2xcRTiAnec?refer_index=1&refer_type=citation
func ExecutePrompt(ctx context.Context, promptKey string, variables map[string]any, messages []*chatmodel.ChatMessage, options []execution.Option, customModelConfig *execution.CustomModelConfig) (message chatmodel.ChatMessage, err error) {
	fornaxClient := GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[ExecutePrompt] get fornax client failed")
		return
	}

	result, err := fornaxClient.ExecutePromptLocal(ctx, &execution.ExecutePromptLocalParam{
		PromptKey:         promptKey,
		Variables:         variables,
		ChatMessages:      messages,
		CustomModelConfig: customModelConfig,
	}, options...)
	if err != nil || result == nil || len(result.Choices) <= 0 {
		logs.CtxError(ctx, "[ExecutePrompt] execute prompt failed, err=%v", err)
		return
	}

	message = result.Choices[0].Message
	return
}

func GetPromptWithParams(ctx context.Context, key string, params map[string]any) (res string, err error) {
	fornaxClient := GetFornaxClient(ctx)
	if fornaxClient == nil {
		logs.CtxError(ctx, "[GetPromptWithParams] get fornax client failed")
		return
	}
	getPromptResult, err := fornaxClient.GetPrompt(ctx, &prompt.GetPromptParam{
		Key: key,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetPromptWithParams] get prompt failed, err=%v", err)
		return
	}
	promptObj := getPromptResult.Prompt
	messageList, err := fornaxClient.FormatPrompt(ctx, promptObj, params)
	if err != nil {
		logs.CtxError(ctx, "[GetPromptWithParams] format prompt failed, err=%v", err)
		return
	}
	for _, message := range messageList {
		res = message.Content
		break
	}
	if len(res) == 0 {
		err = fmt.Errorf("[GetPromptWithParams] get prompt result empty, key=%s", key) // 报错：传入错误参数的时候有更明确地报错
	}
	return
}
