package sophon_sdk

import (
	"context"
	"net/http"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gopkg/logs"
)

const (
	SophonHost  = "https://sophon-ai.bytedance.net/gateway"
	SophonModel = "skylark2-pro-4k-v1.2"
)

func ChatContentCompletion(ctx context.Context, content string) (string, error) {
	url := SophonHost + "/openapi/model/chatCompletion"
	headers := make([]utils.Element, 0)
	headers = append(headers, utils.Element{
		Key:   "api-key",
		Value: biz_info.GetSophonToken(ctx),
	})
	req := ChatCompletionReq{
		Model: SophonModel,
		//MaxTokens: 4096,
		Messages: []MessageDTO{
			{Role: "user", Content: content},
		},
	}
	resp := &ChatCompletionResp{}
	err := utils.HttpRequest(ctx, http.MethodPost, url, headers, req, nil, resp, nil)

	if len(resp.Choices) > 0 {
		return resp.Choices[0].Message.Content, err
	}
	return consts.Empty, err
}

type ChatConfig struct {
	apiKey string
	apiId  string
}

func GetChatConfig(ctx context.Context, botType *string) (config ChatConfig, err error) {
	tcc, err := biz_info.GetArtificialIntelligenceConfig(ctx)

	config.apiKey = ""
	config.apiId = ""
	if err != nil {
		logs.CtxError(ctx, "Error while process intelligence TCC config")
		return
	}

	apiKey := tcc.SophonKey
	apiMap := tcc.SophonApiMap
	var apiId = "n20JUfOd"
	if botType != nil {
		id := apiMap[*botType]
		if id != "" {
			apiId = id
		}
	}
	config.apiKey = apiKey
	config.apiId = apiId
	return
}

// func ChatDialogue(ctx context.Context, request *ai_analysis.Chat2AIRequest, content string) (string, string, error) {
// 	userInfo := portal_agw.GetUserInfo(ctx)
// 	chatConfig, err := GetChatConfig(ctx, request.BotType)
// 	if err != nil {
// 		logs.CtxError(ctx, "Error while process intelligence config")
// 		return "", "", err
// 	}
// 	var sessionId string = ""
// 	if request.SessionId != nil {
// 		sessionId = *request.SessionId
// 	}

// 	url := SophonHost + "/openapi/dialogue/chatCompletion"
// 	headers := make([]utils.Element, 0)
// 	headers = append(headers, utils.Element{
// 		Key:   "api-key",
// 		Value: chatConfig.apiKey,
// 	})

// 	req := ChatCompletionReq{
// 		AppId: chatConfig.apiId,
// 		Messages: []MessageDTO{
// 			{Role: "user", Content: content},
// 		},
// 		Stream:    false,
// 		SessionId: sessionId,
// 		User:      *userInfo.Email,
// 	}
// 	resp := &ChatCompletionResp{}
// 	err = utils.HttpRequest(ctx, http.MethodPost, url, headers, req, nil, resp, &utils.RequestOption{
// 		Timeout: 300,
// 	})

// 	if len(resp.Choices) > 0 {
// 		return resp.Choices[0].Message.Content, resp.SessionId, err
// 	}
// 	return consts.Empty, "", err
// }
// func ChatStream(content string, request *ai_analysis.Chat2AIRequest, stream product_analysis.SmartopProductAnalysisService_Chat2AIStreamServer) error {
// 	ctx := stream.Context()
// 	chatConfig, err := GetChatConfig(ctx, request.BotType)
// 	if err != nil {
// 		logs.CtxError(ctx, "Error while process intelligence config")
// 		return err
// 	}

// 	var sessionId string = ""
// 	if request.SessionId != nil {
// 		sessionId = *request.SessionId
// 	}

// 	url := SophonHost + "/openapi/dialogue/chatCompletion"
// 	headers := make([]utils.Element, 0)
// 	headers = append(headers, utils.Element{
// 		Key:   "api-key",
// 		Value: chatConfig.apiKey,
// 	})
// 	body := ChatCompletionReq{
// 		AppId:     chatConfig.apiId,
// 		SessionId: sessionId,
// 		Messages: []MessageDTO{
// 			{Role: "user", Content: content},
// 		},
// 		Stream: true,
// 		User:   request.User,
// 		ApiExecuteInfo: ApiExecuteInfo{
// 			SophonExeType: "api", // 输出思维链
// 		},
// 	}
// 	jsonStr, _ := json.Marshal(body)
// 	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(jsonStr))

// 	if err != nil {
// 		return err
// 	}
// 	req.Header.Add("accept", "*/*")
// 	req.Header.Add("content-type", "application/json")
// 	for _, header := range headers {
// 		req.Header.Add(header.Key, header.Value)
// 	}
// 	defer req.Body.Close()
// 	client := &http.Client{
// 		Transport: &http.Transport{
// 			DisableKeepAlives: false,
// 		},
// 		Timeout: (time.Duration(300)) * time.Second}
// 	resp, err := client.Do(req)
// 	if err != nil {
// 		return err
// 	}
// 	defer resp.Body.Close()

// 	scanner := bufio.NewScanner(resp.Body)
// 	for scanner.Scan() {
// 		message := scanner.Text()
// 		resp := &ai_analysis.Chat2AIStreamResponse{
// 			RawText: message,
// 		}
// 		err = stream.Send(resp)
// 		if err != nil {
// 			return err
// 		}
// 	}
// 	return nil
// }

func ChatCompletion(ctx context.Context, req *ChatCompletionReq) (*ChatCompletionResp, error) {
	url := SophonHost + "/openapi/model/chatCompletion"
	headers := make([]utils.Element, 0)
	headers = append(headers, utils.Element{
		Key:   "api-key",
		Value: biz_info.GetSophonToken(ctx),
	})
	resp := &ChatCompletionResp{}
	err := utils.HttpRequest(ctx, http.MethodPost, url, headers, req, nil, resp, nil)
	return resp, err
}

type ChatCompletionReq struct {
	Model          string         `json:"model"`
	AppId          string         `json:"appId"`
	User           string         `json:"user"`
	Stream         bool           `json:"stream"`
	SessionId      string         `json:"sessionId"`
	MaxTokens      int64          `json:"max_tokens"`
	Messages       []MessageDTO   `json:"messages"`
	ApiExecuteInfo ApiExecuteInfo `json:"apiExecuteInfo"`
}

type MessageDTO struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type ApiExecuteInfo struct {
	SophonExeType  string      `json:"sophonExeType"`
	BizTenantId    string      `json:"bizTenantId"`
	Resume         string      `json:"resume"`
	ClarifyContext interface{} `json:"clarifyContext"`
}

type ChatCompletionResp struct {
	ID        string       `json:"id"`
	Choices   []ChatChoice `json:"choices"`
	Usage     Usage        `json:"usage"`
	LogID     string       `json:"logId"`
	AckId     string       `json:"ackId"`
	SessionId string       `json:"sessionId"`
}

type ChatChoice struct {
	Index   int64      `json:"index"`
	Message MessageDTO `json:"message"`
}

type Usage struct {
	PromptTokens     int64 `json:"prompt_tokens"`
	CompletionTokens int64 `json:"completion_tokens"`
	TotalTokens      int64 `json:"total_tokens"`
}
