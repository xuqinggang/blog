package mcp

import (
	"context"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/inf/bytedmcp/go/adapter"
	byted_client "code.byted.org/inf/bytedmcp/go/client"
	"github.com/cloudwego/eino/components/tool"
)

func getMCPClientConfigs(psms []string) []byted_client.MCPClientConf {
	clientConfigs := make([]byted_client.MCPClientConf, 0)
	for _, psm := range psms {
		clientConfigs = append(clientConfigs, byted_client.MCPClientConf{
			ServerName: psm,
			ClientType: byted_client.HTTP,
		})
	}
	return clientConfigs
}

func getByteMCPClients(ctx context.Context) (map[string]*byted_client.BytedMCPClient, error) {
	aiConfig, err := biz_info.GetArtificialIntelligenceConfig(ctx)
	if err != nil {
		return nil, err
	}

	clients := make(map[string]*byted_client.BytedMCPClient)
	if aiConfig != nil && aiConfig.McpServerPsm != nil {
		for name, psms := range aiConfig.McpServerPsm {
			clientConfigs := getMCPClientConfigs(psms)
			// 创建选项切片
			options := []byted_client.BytedMCPClientOption{
				// set the request timeout to prevent any requests to the mcp server from indefinitely hanging
				byted_client.WithRequestTimeout(60 * time.Second),
			}

			// byte_rag mcp需要添加BYTERAG_TOKEN配置
			if name == "byte_rag" {
				byteRAGConfig, err := biz_info.GetByteRAGConfig(ctx)
				if err != nil {
					return nil, err
				}
				// ByteRAG Token 使用『请求参数』的方式注入
				options = append(options, byted_client.WithCallToolMetaParams(map[string]any{
					"BYTERAG_TOKEN": byteRAGConfig.Token,
				}))
			}

			client, err := byted_client.NewBytedMCPClient(
				clientConfigs,
				options...,
			// enable logging out call tool trace, turn this off to prevent log clutter
			// byted_client.WithCallToolTraceEnabled(),
			)
			if err != nil {
				return nil, err
			}
			clients[name] = client
		}
	}
	return clients, nil
}

func getEinoTools(ctx context.Context, cli *byted_client.BytedMCPClient, toolNames ...string) ([]tool.BaseTool, error) {
	tools, err := adapter.ConvertMCPToolToEinoTool(ctx, cli, toolNames...)
	if err != nil {
		logs.CtxError(ctx, "[GetEinoTools] convert mcp tool to eino tool err, err: %v", err)
		return nil, err
	}
	return tools, nil
}

func GetByteMCPTools(ctx context.Context, name string, toolNames []string) ([]tool.BaseTool, error) {
	mcpTools := []tool.BaseTool{}
	if ByteMCPClients[name] == nil {
		return mcpTools, nil
	}

	mcpTools, err := getEinoTools(ctx, ByteMCPClients[name], toolNames...)
	if err != nil {
		logs.CtxError(ctx, "[GetByteMCPTools] get mcp tools failed, err=%v", err)
		return nil, err
	}
	return mcpTools, nil
}
