package mcp

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/gopkg/logs/v2"
	eino_mcp "github.com/cloudwego/eino-ext/components/tool/mcp"
	"github.com/cloudwego/eino/components/tool"
	"github.com/mark3labs/mcp-go/client"
	"github.com/mark3labs/mcp-go/client/transport"
	"github.com/mark3labs/mcp-go/mcp"
)

const (
	transportStdio = "stdio"
	transportSSE   = "sse"
)

type MCPConfig struct {
	MCPServers map[string]ServerConfigWrapper `json:"mcpServers"`
}

type ServerConfig interface {
	GetType() string
}

type STDIOServerConfig struct {
	Command string            `json:"command"`
	Args    []string          `json:"args"`
	Env     map[string]string `json:"env,omitempty"`
}

func (s STDIOServerConfig) GetType() string {
	return transportStdio
}

type SSEServerConfig struct {
	Url     string   `json:"url"`
	Headers []string `json:"headers,omitempty"`
}

func (s SSEServerConfig) GetType() string {
	return transportSSE
}

type ServerConfigWrapper struct {
	Config ServerConfig
}

func (w *ServerConfigWrapper) UnmarshalJSON(data []byte) error {
	var typeField struct {
		Url string `json:"url"`
	}

	if err := json.Unmarshal(data, &typeField); err != nil {
		return err
	}
	if typeField.Url != "" {
		// If the URL field is present, treat it as an SSE server
		var sse SSEServerConfig
		if err := json.Unmarshal(data, &sse); err != nil {
			return err
		}
		w.Config = sse
	} else {
		// Otherwise, treat it as a STDIOServerConfig
		var stdio STDIOServerConfig
		if err := json.Unmarshal(data, &stdio); err != nil {
			return err
		}
		w.Config = stdio
	}

	return nil
}
func (w ServerConfigWrapper) MarshalJSON() ([]byte, error) {
	return json.Marshal(w.Config)
}

func getCommonMCPClients(ctx context.Context) (map[string]client.MCPClient, error) {
	// 将 DeerConfig 转换为 MCPConfig
	mcpConfig := &MCPConfig{
		MCPServers: make(map[string]ServerConfigWrapper),
	}

	// 初始化MCP配置
	aiConfig, err := biz_info.GetArtificialIntelligenceConfig(ctx)
	if err == nil && aiConfig != nil {
		if aiConfig.McpServerSse != nil {
			for name, sseConfig := range aiConfig.McpServerSse {
				mcpConfig.MCPServers[name] = ServerConfigWrapper{
					Config: SSEServerConfig{
						Url:     sseConfig.Url,
						Headers: sseConfig.Headers,
					},
				}
			}
		}
		if aiConfig.McpServerStdio != nil {
			for name, stdioConfig := range aiConfig.McpServerStdio {
				mcpConfig.MCPServers[name] = ServerConfigWrapper{
					Config: STDIOServerConfig{
						Command: stdioConfig.Command,
						Args:    stdioConfig.Args_,
						Env:     stdioConfig.Env,
					},
				}
			}
		}
	}

	clients := make(map[string]client.MCPClient)

	for name, server := range mcpConfig.MCPServers {
		var mcpClient client.MCPClient
		var err error
		if server.Config.GetType() == transportSSE {
			sseConfig := server.Config.(SSEServerConfig)
			options := []transport.ClientOption{}

			if len(sseConfig.Headers) > 0 {
				// Parse headers from the conf
				headers := make(map[string]string)
				for _, header := range sseConfig.Headers {
					parts := strings.SplitN(header, ":", 2)
					if len(parts) == 2 {
						key := strings.TrimSpace(parts[0])
						value := strings.TrimSpace(parts[1])
						headers[key] = value
					}
				}
				options = append(options, client.WithHeaders(headers))
			}

			mcpClient, err = client.NewSSEMCPClient(
				sseConfig.Url,
				options...,
			)
			if err == nil {
				// sse client  needs to manually start asynchronous communication
				// while stdio does not require it.
				err = mcpClient.(*client.Client).Start(ctx)
			}
		} else {
			stdioConfig := server.Config.(STDIOServerConfig)
			var env []string
			for k, v := range stdioConfig.Env {
				env = append(env, fmt.Sprintf("%s=%s", k, v))
			}
			mcpClient, err = client.NewStdioMCPClient(
				stdioConfig.Command,
				env,
				stdioConfig.Args...)
		}
		if err != nil {
			for _, c := range clients {
				_ = c.Close()
			}
			return nil, fmt.Errorf(
				"failed to create MCP client for %s: %w",
				name,
				err,
			)
		}

		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, 60*time.Second)
		defer cancel()

		initRequest := mcp.InitializeRequest{}
		initRequest.Params.ProtocolVersion = mcp.LATEST_PROTOCOL_VERSION
		initRequest.Params.ClientInfo = mcp.Implementation{
			Name:    "mcphost",
			Version: "0.1.0",
		}
		initRequest.Params.Capabilities = mcp.ClientCapabilities{}

		_, err = mcpClient.Initialize(ctx, initRequest)
		if err != nil {
			_ = mcpClient.Close()
			for _, c := range clients {
				_ = c.Close()
			}
			return nil, fmt.Errorf(
				"failed to initialize MCP client for %s: %w",
				name,
				err,
			)
		}

		clients[name] = mcpClient
	}

	return clients, nil
}

func GetCommonMCPTools(ctx context.Context, name string, toolNames []string) ([]tool.BaseTool, error) {
	mcpTools := []tool.BaseTool{}
	if CommonMCPClients[name] == nil {
		return mcpTools, nil
	}

	mcpTools, err := eino_mcp.GetTools(ctx, &eino_mcp.Config{
		Cli:          CommonMCPClients[name],
		ToolNameList: toolNames,
	})
	if err != nil {
		logs.CtxError(ctx, "[GetCommonMCPTools] get mcp tools failed, err=%v", err)
		return nil, err
	}
	return mcpTools, nil
}
