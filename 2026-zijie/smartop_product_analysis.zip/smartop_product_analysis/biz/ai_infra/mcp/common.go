package mcp

import (
	"context"

	"code.byted.org/gopkg/logs/v2"
	byted_client "code.byted.org/inf/bytedmcp/go/client"
	"github.com/mark3labs/mcp-go/client"
)

var (
	CommonMCPClients map[string]client.MCPClient
	ByteMCPClients   map[string]*byted_client.BytedMCPClient
)

func Init() {
	var err error
	ctx := context.Background()
	// 初始化字节云mcp
	ByteMCPClients, err = getByteMCPClients(ctx)
	if err != nil {
		logs.CtxError(ctx, "[mcp] Init byte mcp client failed, err=%v", err)
		panic(err)
	}
	logs.CtxInfo(ctx, "[mcp] Init byte mcp client success")
	// 初始化通用mcp
	CommonMCPClients, err = getCommonMCPClients(ctx)
	if err != nil {
		logs.CtxError(ctx, "[mcp] Init common mcp client failed, err=%v", err)
		panic(err)
	}
	logs.CtxInfo(ctx, "[mcp] Init common mcp client success")
}
