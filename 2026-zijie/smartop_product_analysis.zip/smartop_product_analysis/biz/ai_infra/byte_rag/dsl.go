package byte_rag

type RangeCond struct {
	Gte    any   `json:"gte,omitempty"`
	Gt     any   `json:"gt,omitempty"`
	Lte    any   `json:"lte,omitempty"`
	Lt     any   `json:"lt,omitempty"`
	Center []any `json:"center,omitempty"`
	Radius any   `json:"radius,omitempty"`
}

type DSL struct {
	OP    string `json:"op"`
	Field string `json:"field,omitempty"`
	Conds []any  `json:"conds,omitempty"`
	RangeCond
}

func And(conds ...any) *DSL {
	return &DSL{
		OP:    "and",
		Conds: conds,
	}
}

func Or(conds ...any) *DSL {
	return &DSL{
		OP:    "or",
		Conds: conds,
	}
}

func Must(field string, conds ...any) *DSL {
	return &DSL{
		OP:    "must",
		Field: field,
		Conds: conds,
	}
}

func MustNot(field string, conds ...any) *DSL {
	return &DSL{
		OP:    "must_not",
		Field: field,
		Conds: conds,
	}
}

func Range(field string, cond RangeCond) *DSL {
	return &DSL{
		OP:        "range",
		Field:     field,
		RangeCond: cond,
	}
}

func RangeOut(field string, cond RangeCond) *DSL {
	return &DSL{
		OP:        "range_out",
		Field:     field,
		RangeCond: cond,
	}
}
