package byte_rag

import (
	"context"
	"fmt"
	"time"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/gdp/env"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/iespkg/retry-go"
	"code.byted.org/overpass/flow_dataengine_byte_rag/kitex_gen/flow/dataengine/byte_rag"
	"code.byted.org/overpass/flow_dataengine_byte_rag/rpc/flow_dataengine_byte_rag"
	"code.byted.org/temai/go_lib/convert"
	"github.com/bytedance/sonic"
)

type RetrieveParam struct {
	Key          string
	Query        string
	TopK         int32
	MinScore     float64
	Filter       *DSL
	DatasetId    *string
	Channels     []*byte_rag.Channel
	OutputFields []string
}

func RetrieveDocID(ctx context.Context, param *RetrieveParam) (res []string, err error) {
	if param == nil {
		return
	}

	items, err := RetrieveSlice(ctx, param)
	if err != nil {
		return
	}

	for _, item := range items {
		if item == nil || item.DocId == nil || item.Channels == nil {
			continue
		}
		res = append(res, item.GetDocId())
	}

	return
}

func RetrieveSlice(ctx context.Context, param *RetrieveParam) (items []*byte_rag.Item, err error) {
	byteRAGConfig, err := biz_info.GetByteRAGConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, "[RetrieveSlice] get byte rag config failed, err: %v", err)
		return nil, err
	}

	var datasetId string
	if param.DatasetId != nil {
		datasetId = *param.DatasetId
	} else {
		datasetId = byteRAGConfig.Dataset[param.Key]
	}
	if datasetId == "" {
		err = fmt.Errorf("datasetID is empty")
		logs.CtxError(ctx, "[RetrieveSlice] datasetID is empty, err: %v", err)
		return nil, err
	}

	if len(param.Channels) == 0 {
		return
	}
	if param.TopK <= 0 {
		param.TopK = 3
	}
	if param.MinScore < 0 {
		param.MinScore = 0.0
	}

	rankType := "bge_reranker_v2_m3" // 只能在cn环境使用
	if env.IsBoe() {
		rankType = "flow_ranker"
	}
	req := &byte_rag.RetrieveRequest{
		Token:     &byteRAGConfig.Token,
		DatasetId: &datasetId,
		Query:     &param.Query,
		Channels:  param.Channels,
		TopK:      &param.TopK,
		MinScore:  &param.MinScore,
		Rank: &byte_rag.Ranker{
			Type: &rankType,
		},
	}
	if param.Filter != nil {
		filterJson, _err := sonic.MarshalString(param.Filter)
		if _err != nil {
			logs.CtxError(ctx, "[RetrieveSlice] marshal filter failed, err: %v", _err)
			return nil, _err
		}
		req.Filter = &filterJson
	}
	if len(param.OutputFields) > 0 {
		req.OutputFields = param.OutputFields
	}

	resp, err := flow_dataengine_byte_rag.RawCall.Retrieve(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[RetrieveSlice] byte rag retrieve failed, err: %v", err)
		return nil, err
	}

	if resp.GetCode() != 0 {
		err = fmt.Errorf("retrieve failed, code=%d, msg=%s", resp.GetCode(), resp.GetMsg())
		logs.CtxError(ctx, "[RetrieveSlice] rpc failed, err: %v", err)
		return
	}

	result := resp.GetData()
	if result != nil {
		items = result.Items
	}
	return
}

func GetSliceContent(items []*byte_rag.Item) []string {
	var res []string
	for _, v := range items {
		if v == nil || convert.ToString(v.Slice) == "" {
			continue
		}
		res = append(res, convert.ToString(v.Slice))
	}
	return res
}

type DocumentParam struct {
	Key        string
	DocID      string
	Data       map[string]any
	ChunkRules map[string]*byte_rag.ChunkRule
}

type KnowledgeOPType int32

const (
	KnowledgeOpCreate KnowledgeOPType = 1
	KnowledgeOpUpdate KnowledgeOPType = 2
	KnowledgeOpDelete KnowledgeOPType = 3
)

func DoDocumentAction(ctx context.Context, op KnowledgeOPType, param *DocumentParam) (docMeta *byte_rag.DocumentMeta, err error) {
	if param == nil {
		return
	}

	byteRAGConfig, err := biz_info.GetByteRAGConfig(ctx)
	if err != nil {
		logs.CtxError(ctx, "[DoDocumentAction] get byte rag config failed, err: %v", err)
		return
	}
	datasetId := byteRAGConfig.Dataset[param.Key]
	if datasetId == "" {
		err = fmt.Errorf("datasetID is empty")
		logs.CtxError(ctx, "[DoDocumentAction] datasetID is empty, err: %v", err)
		return
	}

	switch op {
	case KnowledgeOpCreate:
		docMeta, err = IndexDocument(ctx, byteRAGConfig.Token, datasetId, param.Data, param.ChunkRules)
	case KnowledgeOpUpdate:
		docMeta, err = UpdateDocument(ctx, byteRAGConfig.Token, datasetId, param.DocID, param.Data, param.ChunkRules)
	case KnowledgeOpDelete:
		err = DeleteDocument(ctx, byteRAGConfig.Token, datasetId, param.DocID)
	default:
		return
	}
	if err != nil {
		return
	}
	if op == KnowledgeOpDelete || docMeta == nil || docMeta.DocId == nil {
		return
	}

	// 使用通用轮询方法检查文档状态
	pollingResult := utils.PollUntil(ctx,
		// 轮询条件：文档状态不再是INPROGRESS
		func(ctx context.Context) (bool, error) {
			if docMeta.Status == nil || *docMeta.Status != byte_rag.DocumentStatus_INPROGRESS {
				return true, nil
			}
			return false, nil
		},
		// 轮询操作：获取文档状态并更新
		func(ctx context.Context) error {
			// 使用重试机制获取文档状态
			var queryResult *byte_rag.DocumentMeta
			var getDocErr error
			cmd := retry.NewCommand(
				func(i int) (any, error) {
					queryResult, getDocErr = GetDocument(ctx, byteRAGConfig.Token, byteRAGConfig.Dataset[param.Key], docMeta.GetDocId())
					if getDocErr != nil {
						return nil, getDocErr
					}
					return nil, nil
				},
				retry.WithAttempts(3), // 最多重试3次
				retry.WithBackoffFunc(func(_ time.Duration, _ uint) time.Duration {
					return 1*time.Second + time.Duration(utils.RandInt(200))*time.Millisecond
				}), // 退避策略，每次重试间隔增加随机抖动
			)

			_, retryErr := retry.Do(ctx, "DoDocumentAction_GetDocument", cmd)
			if retryErr != nil {
				logs.CtxWarn(ctx, "[DoDocumentAction] GetDocument failed after retries, docID: %s, err: %v", docMeta.GetDocId(), retryErr)
				return retryErr
			}

			if queryResult == nil {
				logs.CtxWarn(ctx, "[DoDocumentAction] GetDocument nil, docID: %s", docMeta.GetDocId())
			} else {
				docMeta.Status = queryResult.Status
			}
			return nil
		},
		// 使用默认轮询配置
		utils.PollingConfig{
			PollInterval:       5*time.Second + time.Duration(utils.RandInt(200))*time.Millisecond,
			MaxPollingTime:     10 * time.Minute,
			MaxPollingAttempts: 60,
		},
	)

	// 记录轮询结果
	if pollingResult.TimedOut {
		logs.CtxWarn(ctx, "[DoDocumentAction] polling timeout, docID: %s, attempts: %d, duration: %v",
			docMeta.GetDocId(), pollingResult.Attempts, pollingResult.Duration)
	} else if pollingResult.Completed {
		logs.CtxInfo(ctx, "[DoDocumentAction] polling completed, docID: %s, attempts: %d, duration: %v",
			docMeta.GetDocId(), pollingResult.Attempts, pollingResult.Duration)
	}

	return
}

// 导入文档
func IndexDocument(ctx context.Context, token string, datasetID string, data map[string]interface{}, chunkRules map[string]*byte_rag.ChunkRule) (result *byte_rag.DocumentMeta, err error) {
	if data == nil {
		err = fmt.Errorf("data is nil")
		logs.CtxError(ctx, "[IndexDocument] data is nil, err: %v", err)
		return
	}

	req := &byte_rag.IndexDocumentRequest{
		Token:     &token,
		DatasetId: &datasetID,
	}
	dataJson, err := sonic.MarshalString(data)
	if err != nil {
		logs.CtxError(ctx, "[IndexDocument] marshal data failed, err: %v", err)
		return
	}
	req.Data = &dataJson
	if chunkRules != nil {
		req.ChunkRules = chunkRules
	}

	resp, err := flow_dataengine_byte_rag.RawCall.IndexDocument(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[IndexDocument] rpc failed, err: %v", err)
		return
	}

	if resp.GetCode() != 0 {
		err = fmt.Errorf("IndexDocument failed, code=%d, msg=%s", resp.GetCode(), resp.GetMsg())
		logs.CtxError(ctx, "[IndexDocument] rpc failed, err: %v", err)
		return
	}

	result = resp.GetData()
	return
}

// 更新文档
func UpdateDocument(ctx context.Context, token string, datasetID string, docID string, data map[string]interface{}, chunkRules map[string]*byte_rag.ChunkRule) (result *byte_rag.DocumentMeta, err error) {
	if data == nil {
		err = fmt.Errorf("data is nil")
		logs.CtxError(ctx, "[UpdateDocument] data is nil, err: %v", err)
		return
	}

	req := &byte_rag.UpdateDocumentRequest{
		Token:     &token,
		DatasetId: &datasetID,
		DocId:     &docID,
	}
	dataJson, err := sonic.MarshalString(data)
	if err != nil {
		logs.CtxError(ctx, "[UpdateDocument] marshal data failed, err: %v", err)
		return
	}
	req.Data = &dataJson
	if chunkRules != nil {
		req.ChunkRules = chunkRules
	}

	resp, err := flow_dataengine_byte_rag.RawCall.UpdateDocument(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[UpdateDocument] rpc failed, err: %v", err)
		return
	}

	if resp.GetCode() != 0 {
		err = fmt.Errorf("UpdateDocument failed, code=%d, msg=%s", resp.GetCode(), resp.GetMsg())
		logs.CtxError(ctx, "[UpdateDocument] rpc failed, err: %v", err)
		return
	}

	result = resp.GetData()
	return
}

// 删除文档
func DeleteDocument(ctx context.Context, token string, datasetID string, docID string) (err error) {
	req := &byte_rag.DeleteDocumentRequest{
		Token:     &token,
		DatasetId: &datasetID,
		DocId:     &docID,
	}
	resp, err := flow_dataengine_byte_rag.RawCall.DeleteDocument(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[DeleteDocument] rpc failed, err: %v", err)
		return
	}

	if resp.GetCode() != 0 {
		err = fmt.Errorf("DeleteDocument failed, code=%d, msg=%s", resp.GetCode(), resp.GetMsg())
		logs.CtxError(ctx, "[DeleteDocument] rpc failed, err: %v", err)
		return
	}

	return
}

// 获取文档状态，后面可以配置MQ消费：https://bytedance.larkoffice.com/docx/PyXddpyPzojljGxFXolc6AUenLf
func GetDocument(ctx context.Context, token string, datasetID string, docID string) (result *byte_rag.DocumentMeta, err error) {
	req := &byte_rag.GetDocumentRequest{
		Token:     &token,
		DatasetId: &datasetID,
		DocId:     &docID,
	}
	resp, err := flow_dataengine_byte_rag.RawCall.GetDocument(ctx, req)
	if err != nil {
		logs.CtxError(ctx, "[GetDocument] rpc failed, err: %v", err)
		return
	}

	if resp.GetCode() != 0 {
		err = fmt.Errorf("GetDocument failed, code=%d, msg=%s", resp.GetCode(), resp.GetMsg())
		logs.CtxError(ctx, "[GetDocument] rpc failed, err: %v", err)
		return
	}

	result = resp.GetData()

	return
}
