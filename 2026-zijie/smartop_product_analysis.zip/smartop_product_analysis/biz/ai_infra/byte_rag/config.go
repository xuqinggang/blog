package byte_rag

import (
	"code.byted.org/overpass/flow_dataengine_byte_rag/kitex_gen/flow/dataengine/byte_rag"
	"code.byted.org/temai/go_lib/convert"
)

const (
	FlightAnalysisConclusion = "flight_analysis_conclusion"
	ProductAnalysis          = "product_analysis"
)

var KnowledgeKey2Channels = map[string][]*byte_rag.Channel{
	FlightAnalysisConclusion: {
		buildChannel("strategy_reflection_text", 10, 1),
		buildChannel("strategy_reflection_text_embedding", 10, 0.2),
		buildChannel("flight_conclusion_text", 10, 1),
		buildChannel("flight_conclusion_text_embedding", 10, 0.2),
	},
	ProductAnalysis: {
		buildChannel("doc_text", 10, 1),
		buildChannel("doc_text_embedding", 10, 0.3),
	},
}

func buildChannel(filed string, topK int32, minScore float64) *byte_rag.Channel {
	return &byte_rag.Channel{
		Field:    &filed,
		TopK:     &topK,
		MinScore: &minScore,
	}
}

func buildChannelWithMatchType(filed string, topK int32, minScore float64) *byte_rag.Channel {
	return &byte_rag.Channel{
		Field:    &filed,
		TopK:     &topK,
		MinScore: &minScore,
		FullTextOptions: &byte_rag.FullTextRetrieveOptions{
			MatchType: convert.ToStringPtr("match_phrase"),
		},
	}
}

// 默认的切片规则
var CommonChunkRules = map[string]any{
	"content": map[string]any{
		"chunk_type": 3,
		"auto_chunk_rule": map[string]any{
			"chunk_size": 4096,
			"chunk_mode": 0,
			"common_chunk_rule": map[string]any{
				"image_extraction": true,
				"table_extraction": true,
				"extra_config": map[string]any{
					"md_exclude_types":     "[]",
					"md_splittable_types":  "[]",
					"md_doc_tree_split_by": "element",
					"merge_small_chunks":   "true",
				},
			},
			"markdown_chunk_rule": map[string]any{
				"split_to_header_level":      6,
				"append_n_header_to_content": 2,
			},
		},
	},
}
