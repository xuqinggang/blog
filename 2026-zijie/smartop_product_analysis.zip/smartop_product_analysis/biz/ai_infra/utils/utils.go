package ai_infra_utils

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"reflect"
	"strings"

	"github.com/cloudwego/eino/schema"
	"github.com/invopop/jsonschema"
)

func SetStateValue(state any, fieldName string, value any) error {
	// 确保state是一个指针
	stateVal := reflect.ValueOf(state)
	if stateVal.Kind() != reflect.Ptr {
		return fmt.Errorf("state must be a pointer")
	}

	// 获取指针指向的结构体
	elem := stateVal.Elem()
	if elem.Kind() != reflect.Struct {
		return fmt.Errorf("state must point to a struct")
	}

	// 查找字段
	field := elem.FieldByName(fieldName)
	if !field.IsValid() {
		return fmt.Errorf("field %s not found", fieldName)
	}

	// 确保字段可以设置
	if !field.CanSet() {
		return fmt.Errorf("field %s cannot be set", fieldName)
	}

	// 确保字段类型匹配
	if field.Type() != reflect.TypeOf(value) {
		return fmt.Errorf("field %s type mismatch", fieldName)
	}

	// 设置字段值
	field.Set(reflect.ValueOf(value))
	return nil
}

func GenerateSchema[T any]() *jsonschema.Schema { // <-- 优化返回类型为具体 Schema 类型
	reflector := jsonschema.Reflector{
		AllowAdditionalProperties: false,
		DoNotReference:            true,
	}
	return reflector.Reflect(new(T)) // 使用 new(T) 避免空值问题
}

func UnmarshalToolArguments(str string, obj any) (err error) {
	/*
		解决工具调用时参数报错
	*/
	if obj == nil || len(str) == 0 {
		return fmt.Errorf("obj is nil or str is empty")
	}
	originStr := str
	var (
		badSuffix = []string{"<|FunctionCallEnd|>", "<||FunctionCallEnd|>"}
		badPrefix = []string{"<||FunctionCallBegin|>"}
	)
	for _, item := range badSuffix {
		str = strings.TrimSuffix(str, item)
	}
	for _, item := range badPrefix {
		str = strings.TrimPrefix(str, item)
	}

	for i := 0; i < 3; i++ {
		if tmpErr := json.Unmarshal([]byte(str), obj); tmpErr != nil {
			if strings.Contains(tmpErr.Error(), "in string escape code") {
				return fmt.Errorf("字符串转义报错(%s)，注意JSON中Latex公式的二次转义处理", tmpErr.Error())
			} else if str[len(str)-1] == ']' || str[len(str)-1] == '}' {
				str = strings.TrimSpace(str[:len(str)-1])
			} else {
				break
			}
		} else {
			return // 解析成功
		}
	}
	err = json.Unmarshal([]byte(originStr), obj) // 原始报错
	return
}

// 流式调用中判断是否有 ToolCall，如果先返回content再调用tool（Deepseek v3.1、Claude），则使用这个方法，否则可以用默认的
func StreamToolCallChecker(_ context.Context, sr *schema.StreamReader[*schema.Message]) (bool, error) {
	defer sr.Close()

	for {
		msg, err := sr.Recv()
		if err != nil {
			if errors.Is(err, io.EOF) {
				return false, nil
			} else {
				return false, err
			}
		}
		if len(msg.ToolCalls) > 0 {
			return true, nil
		}
	}
}
