package callback

import (
	"context"
	"fmt"

	"code.byted.org/gopkg/logs/v2"
	"github.com/cloudwego/eino/callbacks"
	"github.com/cloudwego/eino/schema"
)

// eino callback handler：https://bytedance.larkoffice.com/wiki/MuDQwqoaFiP2bPkwIGYcURpfnQe
type GlobalHandler struct {
}

func (cb *GlobalHandler) OnStart(ctx context.Context, info *callbacks.RunInfo, input callbacks.CallbackInput) context.Context {
	fmt.Println("=========[Global OnStart]=========")
	return ctx
}

func (cb *GlobalHandler) OnEnd(ctx context.Context, info *callbacks.RunInfo, output callbacks.CallbackOutput) context.Context {
	fmt.Println("=========[Global OnEnd]=========")
	return ctx
}

func (cb *GlobalHandler) OnError(ctx context.Context, info *callbacks.RunInfo, err error) context.Context {
	fmt.Println("=========[Global OnError]=========")
	logs.CtxError(ctx, "[Global OnError] Original error: %v", err)
	return ctx
}

func (cb *GlobalHandler) OnEndWithStreamOutput(ctx context.Context, info *callbacks.RunInfo, output *schema.StreamReader[callbacks.CallbackOutput]) context.Context {
	fmt.Println("=========[Global OnEndStream]=========")

	go func() {
		defer func() {
			if err := recover(); err != nil {
				fmt.Println("[Global OnEndStream] panic err:", err)
			}
		}()

		defer output.Close() // remember to close the stream in defer
	}()

	return ctx
}

func (cb *GlobalHandler) OnStartWithStreamInput(ctx context.Context, info *callbacks.RunInfo, input *schema.StreamReader[callbacks.CallbackInput]) context.Context {
	fmt.Println("=========[Global OnStartStream]=========")
	defer input.Close()
	return ctx
}
