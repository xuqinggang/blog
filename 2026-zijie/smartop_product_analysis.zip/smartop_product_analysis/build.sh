#!/usr/bin/env bash
RUN_NAME="ecom.smartop.product_analysis"

mkdir -p output/bin output/conf
cp script/* output/
cp conf/* output/conf/
chmod +x output/bootstrap.sh

if [ "$BUILD_TYPE" = "offline" -o "$BUILD_TYPE" = "test" ]; then # 也可以自定义条件
    go install code.byted.org/bet/go_coverage@tiktok_sg
    go_coverage annotate
fi

if [ "$IS_SYSTEM_TEST_ENV" != "1" ]; then
    go build -o output/bin/${RUN_NAME}
else
    go test -c -covermode=set -o output/bin/${RUN_NAME} -coverpkg=./...
fi

bash -c "$(curl -fsL https://tosv.byted.org/obj/uitesting/tos_upload_blame.sh)" || echo ""