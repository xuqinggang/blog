package middleware

import (
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/pkg/endpoint"
	"context"
	"github.com/goccy/go-json"
	"time"
)

// CtxLog 打印请求和响应
func CtxLog(next endpoint.Endpoint) endpoint.Endpoint {
	return func(ctx context.Context, req, resp interface{}) (err error) {
		bytes, _ := json.Marshal(req)
		logs.CtxInfo(ctx, "request: %s\n", string(bytes))
		startTime := time.Now().UnixNano() / 1e6
		err = next(ctx, req, resp)
		duration := time.Now().UnixNano()/1e6 - startTime
		bytes, _ = json.Marshal(resp)
		logs.CtxInfo(ctx, "response: %s,\n timeCost: %v ms\n", string(bytes), duration)
		return err
	}
}
