package middleware

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/metric"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"
	"code.byted.org/gopkg/ctxvalues"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/pkg/endpoint"
	"code.byted.org/kite/kitex/pkg/rpcinfo"
	"code.byted.org/temai/go_lib/convert"
	"code.byted.org/temai/go_portal_sdk/models"
	"context"
	"crypto/sha256"
	b64 "encoding/base64"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"github.com/mohae/deepcopy"
	"reflect"
	"time"
)

type ReqInfo struct {
	StartDate        string `json:"start_date"`
	EndDate          string `json:"end_date"`
	CompareStartDate string `json:"compare_start_date"`
	CompareEndDate   string `json:"compare_end_date"`
	MethodName       string `json:"method_name"`
	UserEmail        string `json:"user_email"`
	UserId           string `json:"user_id"`
	LogID            string `json:"log_id"`
	BizType          string `json:"biz_type"`
	BizName          string `json:"biz_name"`
	ReqBase64Code    string `json:"req_base64_code"`
	CurrentEnv       string `json:"current_env"`
	TimeStamp        int64  `json:"time_stamp"`
	ReqJson          string `json:"req_json"`
}

func fillReqInfo(reqInfo *ReqInfo, reqBase *dimensions.ProductAnalysisBaseStruct) {
	if reqBase == nil {
		return
	}
	reqInfo.StartDate = reqBase.StartDate
	reqInfo.EndDate = reqBase.EndDate
	reqInfo.CompareStartDate = reqBase.CompareStartDate
	reqInfo.CompareEndDate = reqBase.CompareEndDate
	reqInfo.BizName = convert.ToString(reqBase.BizType)
	reqInfo.BizType = convert.ToString(int64(reqBase.BizType))
}

func fillReqInfoAttr(reqInfo *ReqInfo, reqBase *analysis.AttributionCommonBaseStruct) {
	if reqBase == nil {
		return
	}
	reqInfo.StartDate = reqBase.StartDate
	reqInfo.EndDate = reqBase.EndDate
	reqInfo.CompareStartDate = reqBase.CompareStartDate
	reqInfo.CompareEndDate = reqBase.CompareEndDate
	reqInfo.BizName = convert.ToString(reqBase.BizType)
	reqInfo.BizType = convert.ToString(int64(reqBase.BizType))
}

// CacheHit 缓存命中率统计,维度使用统计
func CacheHit(next endpoint.Endpoint) endpoint.Endpoint {
	return func(ctx context.Context, req, resp interface{}) (err error) {
		startTime := time.Now()
		err = next(ctx, req, resp)
		rpcInfo := rpcinfo.GetRPCInfo(ctx)
		method := rpcInfo.To().Method()
		logId, _ := ctxvalues.LogID(ctx)
		var userInfo *models.UserInfo
		var uErr error
		userInfo, uErr = utils.GetCurrentUser(ctx)
		if uErr != nil || userInfo == nil {
			userInfo = &models.UserInfo{
				Email: proto.String("未知"),
				Id:    proto.Int64(0),
			}
		}
		reqInfo := &ReqInfo{}
		var requestData interface{}
		if requestDataI, ok := req.(interface{ GetFirstArgument() interface{} }); ok {
			requestData = requestDataI.GetFirstArgument()
		} else {
			return err
		}
		reqInfo.LogID = logId
		reqInfo.MethodName = method
		if userInfo != nil {
			reqInfo.UserId = convert.ToString(userInfo.Id)
			reqInfo.UserEmail = *userInfo.Email
		}
		reqInfo.LogID = logId
		reqInfo.TimeStamp = time.Now().Unix()
		if env.IsBoe() {
			reqInfo.CurrentEnv = "boe"
		} else if env.IsPPE() {
			reqInfo.CurrentEnv = "ppe"
		} else {
			reqInfo.CurrentEnv = "prod"
		}

		var hashStr string
		needSaveRedis := true
		switch reqImpl := requestData.(type) {
		case *dimensions.ProductAnalysisBaseStruct:
			fillReqInfo(reqInfo, reqImpl)
		case *analysis.GetProductAnalysisBaseRequest:
			fillReqInfo(reqInfo, reqImpl.BaseReq)
			if newReqImpl, ok := deepcopy.Copy(reqImpl).(*analysis.GetProductAnalysisBaseRequest); ok {
				newReqImpl.Base = nil
				hashStr = convert.ToJSONString(newReqImpl)
			}
		case *analysis.GetProductAnalysisMultiDimFullListRequest:
			fillReqInfo(reqInfo, reqImpl.BaseReq)
			if newReqImpl, ok := deepcopy.Copy(reqImpl).(*analysis.GetProductAnalysisMultiDimFullListRequest); ok {
				newReqImpl.Base = nil
				hashStr = convert.ToJSONString(newReqImpl)
			}
		case *analysis.GetAttributionCommonBaseRequest:
			fillReqInfoAttr(reqInfo, reqImpl.BaseReq)
			if newReqImpl, ok := deepcopy.Copy(reqImpl).(*analysis.GetAttributionCommonBaseRequest); ok {
				newReqImpl.Base = nil
				hashStr = convert.ToJSONString(newReqImpl)
			}
		case *great_value_buy.GetGreatValueBuyCommonRequest:
			fillReqInfo(reqInfo, reqImpl.BaseReq)
			if newReqImpl, ok := deepcopy.Copy(reqImpl).(*great_value_buy.GetGreatValueBuyCommonRequest); ok {
				newReqImpl.Base = nil
				hashStr = convert.ToJSONString(newReqImpl)
			}
		case *sku_cluster.SkuClusterCommonRequest:
			fillReqInfo(reqInfo, reqImpl.BaseReq)
			if newReqImpl, ok := deepcopy.Copy(reqImpl).(*sku_cluster.SkuClusterCommonRequest); ok {
				newReqImpl.Base = nil
				hashStr = convert.ToJSONString(newReqImpl)
			}
		case *common_request.CommonAnalysisRequest:
			fillReqInfo(reqInfo, reqImpl.BaseReq)
			if newReqImpl, ok := deepcopy.Copy(reqImpl).(*common_request.CommonAnalysisRequest); ok {
				newReqImpl.Base = nil
				hashStr = convert.ToJSONString(newReqImpl)
			}
		default:
			needSaveRedis = false
			// 默认不处理
		}
		hash := sha256.Sum256([]byte(hashStr))
		base64Code := b64.StdEncoding.EncodeToString(hash[:])
		reqInfo.ReqBase64Code = base64Code
		reqInfo.ReqJson = hashStr
		var respData, baseResp interface{}
		if respDataI, ok := resp.(interface{ GetResult() interface{} }); ok && respDataI != nil {

			respData = respDataI.GetResult()
		} else {
			return err
		}
		if baseRespI, ok := respData.(interface{ GetOrSetBaseResp() interface{} }); ok && baseRespI != nil &&
			!reflect.ValueOf(baseRespI).IsNil() {
			baseResp = baseRespI.GetOrSetBaseResp()
			if _baseResp, ok1 := baseResp.(*base.BaseResp); ok1 && _baseResp != nil {
				if _baseResp.Extra == nil {
					_baseResp.Extra = make(map[string]string)
				}
				_baseResp.Extra["current_env"] = reqInfo.CurrentEnv
			}
		}
		redisKey := fmt.Sprintf("req_cache_key|%s", logId)
		reqInfoStr := convert.ToJSONString(reqInfo)
		if needSaveRedis {
			_ = redis.Set(ctx, redisKey, reqInfoStr, time.Hour*48)
		}
		milliSecond := time.Since(startTime).Milliseconds()
		logs.CtxInfo(ctx, "ReqInfoStr = %s\ncost_time=%vms", reqInfoStr, milliSecond)
		metric.EmitTimer("method_latency", startTime, map[string]string{
			"biz_type":    reqInfo.BizType,
			"method_name": reqInfo.MethodName,
		})
		return err
	}

}
