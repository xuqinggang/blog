package main

import (
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/aggregate"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	"context"
	"reflect"
	"testing"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
)

func TestSmartopProductAnalysisServiceImpl_InitPlanAnalysisPool(t *testing.T) {
	type args struct {
		ctx context.Context
		req *analysis.InitPlanAnalysisPoolRequest
	}
	tests := []struct {
		name     string
		args     args
		wantResp *analysis.InitPlanAnalysisPoolResponse
		wantErr  bool
	}{
		{
			name: "111",
			args: args{
				ctx: context.Background(),
				req: &analysis.InitPlanAnalysisPoolRequest{
					//PlanId: 1,
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &SmartopProductAnalysisServiceImpl{}
			gotResp, err := s.InitPlanAnalysisPool(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("InitPlanAnalysisPool() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotResp, tt.wantResp) {
				t.Errorf("InitPlanAnalysisPool() gotResp = %v, want %v", gotResp, tt.wantResp)
			}
		})
	}
}

func TestSmartopProductAnalysisServiceImpl_GuessAllTreeDownload(t *testing.T) {
	type args struct {
		ctx context.Context
		req *aggregate.AllTreeDownloadRequest
	}
	tests := []struct {
		name     string
		args     args
		wantResp *analysis.GetProductAnalysisDownloadResponse
		wantErr  bool
	}{
		{
			name: "111",
			args: args{
				ctx: context.Background(),
				req: &aggregate.AllTreeDownloadRequest{
					TreeReq: &great_value_buy.GetGreatValueBuyCommonRequest{
						BaseReq: &dimensions.ProductAnalysisBaseStruct{
							BizType:          0,
							StartDate:        "",
							EndDate:          "",
							CompareStartDate: "",
							CompareEndDate:   "",
							Dimensions:       nil,
							ThresholdAttrs:   nil,
							ThresholdExpr:    nil,
							GroupAttrs:       nil,
							UvFlag:           nil,
							TargetMetaList:   nil,
							CompareType:      nil,
							IsTotal:          nil,
							NoCompare:        nil,
						},
					},
				},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &SmartopProductAnalysisServiceImpl{}
			gotResp, err := s.GuessAllTreeDownload(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("GuessAllTreeDownload() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(gotResp, tt.wantResp) {
				t.Errorf("GuessAllTreeDownload() gotResp = %v, want %v", gotResp, tt.wantResp)
			}
		})
	}
}
