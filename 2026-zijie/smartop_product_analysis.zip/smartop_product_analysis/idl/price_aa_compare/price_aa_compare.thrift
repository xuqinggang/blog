namespace py analysis
namespace go analysis

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../dimensions/price_dimensions.thrift"
include "../analysis/analysis.thrift"
include "../basic_info.thrift"

// aa标准请求体
enum PriceAATargetType {
    PAY // 成交
    SHOW // 曝光
}

struct GetPriceAABaseRequest {
    1: price_dimensions.PriceAnalysisBaseStruct base_req
    2: string channel // 场域属性筛选
    3: list<dimensions.SelectedDimensionInfo> dimensions // 筛选属性，目前只有：价格带

    11: PriceAATargetType target_type // 传入类型
    255: optional base.Base Base
}

struct GetPriceAASupplyDistributedRequest {
    1: price_dimensions.PriceAnalysisBaseStruct base_req
    2: string dim_id // 维度ID

    255: optional base.Base Base
}

// 业务收益分析变化分布
struct GetPriceAAMultiPieChartData {
    1: string name
    2: list<analysis.TargetCardEntity> target_list
}

struct GetPriceAAMultiPieChartResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<GetPriceAAMultiPieChartData> data

    255: base.BaseResp BaseResp
}

// 供给漏斗
struct GetPriceAASupplyCntData {
    1: string name // 标题名称
    2: string tips // 文案信息
    3: list<analysis.TargetCardEntity> target_list // 指标，目前只有 订单高价率
}

struct GetPriceAASupplyCntListResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<GetPriceAASupplyCntData> data

    255: base.BaseResp BaseResp
}

// 业务收益分析 - 瀑布图
struct GetPriceAABizIncomeTrendData {
    1: string name
    2: analysis.TargetTrendPoint total
    3: list<analysis.TargetTrendPoint> sub
}

struct GetPriceAABizIncomeTrendResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required list<GetPriceAABizIncomeTrendData> data     // 返回结果

    255: base.BaseResp BaseResp
}

// 核心结论返回体
struct TotalConclusionInfo {
    1: analysis.TargetCardEntity price_change_filter // 筛选符合条件的品
    2: analysis.TargetCardEntity price_change        // 比价覆盖的品
    3: analysis.TargetCardEntity market              // 大盘的品
}
struct TargetConclusionInfo {
    1: string name
    2: analysis.TargetCardEntity target
}
struct TargetDiffConclusionInfo {
    1: double cnt_percent // 占比
    2: analysis.TargetCardEntity total_info
    3: TargetConclusionInfo change_max_channel
    4: TargetConclusionInfo change_min_channel
}
struct TargetDiffConclusionData {
    1: analysis.TargetCardEntity total_target
    2: TargetDiffConclusionInfo incr_info
    3: TargetDiffConclusionInfo reduce_info
}
struct SupplyConclusionData {
    1: list<analysis.TargetCardEntity> prod_pool
    2: list<TargetConclusionInfo> cate_info
}
struct FlowStandardConclusionDiffInfo {
    1: analysis.TargetCardEntity flow_standard_cnt
    2: list<analysis.TargetCardEntity> targets
}
struct FlowStandardConclusionInfo {
    1: string channel_name // 场域名称
    2: analysis.TargetCardEntity flow_standard_all
    3: FlowStandardConclusionDiffInfo flow_standard_aa
    4: FlowStandardConclusionDiffInfo flow_standard_cspu
}
struct FlowStandardConclusionData {
    1: list<FlowStandardConclusionInfo> meet_standard
    2: list<FlowStandardConclusionInfo> not_up_to_standard
}
struct PriceAACoreConclusionData {
    1: TotalConclusionInfo total_info // 整体
    2: list<TargetDiffConclusionData> biz_income_info // 业务收益
    3: list<TargetDiffConclusionData> flow_diff_info // 流量变化
    4: SupplyConclusionData supply_info // 供给来源
    5: FlowStandardConclusionData flow_standard_conclusion // 流量达标
}
struct GetPriceAACoreConclusionResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: PriceAACoreConclusionData data

    255: base.BaseResp BaseResp
}