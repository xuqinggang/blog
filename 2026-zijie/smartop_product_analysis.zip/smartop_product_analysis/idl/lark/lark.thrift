namespace py lark
namespace go lark

include "../base.thrift"

enum DocNoPermissionReason {
    NoAuth = 1,       // 未授权
    NoPermission = 2, // 用户没有云文档权限
}

struct CheckDocPermissionRequest {
    1: required string doc_url,   // 文档链接
    255: optional base.Base Base,
}

struct CheckDocPermissionResponseData {
    1: required bool has_permission,          // 是否有权限
    2: optional DocNoPermissionReason reason, // 无权限原因
}

struct CheckDocPermissionResponse {
    1: required i32 code,                            // 状态码 0: 成功
    2: required string msg,                          // 出错提示消息
    3: required CheckDocPermissionResponseData data, // 是否有权限
    255: required base.BaseResp BaseResp,
}

struct GetDocContentRequest {
    1: required string doc_url,   // 文档链接
    255: optional base.Base Base,
}

struct GetDocContentResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    3: required string data,              // 文档内容
    255: required base.BaseResp BaseResp,
}