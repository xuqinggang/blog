namespace py diagnosis
namespace go diagnosis

include "../base.thrift"
include "../great_value_buy/great_value_buy.thrift"
include "../analysis/analysis.thrift"
include "../module_name/module_name.thrift"

struct YOYConfig {
    1: bool is_open_yoy
    2: optional string start_date
    3: optional string end_date
}

struct DiagnosisParams {
    1: module_name.ModuleName module_name,                                    // 模块名称
    2: optional bool need_trend,                                                      // 是否需要趋势图
    3: optional bool need_cycle,                                                      // 需要环比
    4: optional bool need_sync,                                                       // 是否需要同比
    5: optional list<great_value_buy.TargetGranularityType> target_granularity_list,                  // 指标粒度
    6: optional list<great_value_buy.GetGreatValueBuyDiagnosisTopicTargetInfo> diagnosis_target_list, // 诊断指标
    7: optional list<great_value_buy.GetGreatValueBuyDiagnosisTargetType> target_type_list,           // 指标计算方式
    8: optional great_value_buy.TargetDrillType target_drill_type,                                    // 下钻类型
    9: optional list<string> select_sku_id_list,                              // 筛选的sku_id
    10: optional list<string> common_select_list,                             //筛选的选项
    11: optional list<great_value_buy.OptimizeItem> optimize_items                            // 可优化项
    12: optional list<great_value_buy.CrmTask> crm_actions                                    // CRM任务
    13: optional great_value_buy.CoreTreeType core_tree_type                                  // 归因树类型
    14: list<analysis.TargetCardEntity> dependent_target_list                  // 依赖指标
    15: optional bool need_total                                                        // 是否需要整体卡片
    16: optional great_value_buy.TargetConfigData target_config_list                    // 指标配置
    17: optional YOYConfig yoy_config                                                 // yoy配置

    100: optional base.PageInfo page_req
    101: optional base.OrderByInfo order_by

    255: optional base.Base Base,
}