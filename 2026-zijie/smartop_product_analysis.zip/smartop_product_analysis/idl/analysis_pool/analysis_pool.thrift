namespace py analysis_pool
namespace go analysis_pool
namespace java analysis_pool

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../product_select/product_select.thrift"


//****************************************************************
//*********************** 货盘管理 *****************************
//****************************************************************

enum PoolSource {
    UnKnow                   = 0,    // 未知
    SeckillChannelDelivery   = 1,    // 秒杀频道投放
    AllowanceChannelDelivery = 2,    // 超值购频道投放
    SimilarProduct           = 3,    // 相似商品洞察
}

// 阈值类型，有价值品定义
enum AnalysisPoolType {
    FixedProd        = 0    // 固定商品ID
    DynamicRule      = 1    // 动态规则
    AlgorithmFeature = 2    // 算法特征
}

enum ApplicationVector {
    Hive = 0,    // hive表
}

enum ApplicationScene {
    AllowanceZeroSubsidy = 0,    // 超值购0补
    GuessFlowSupport     = 1,    // 猜喜流量扶持
}

enum ApplicationStatus {
    Failed  = 0,    // 失败
    Succeed = 1,    // 成功
}

struct FeatureRuleInfo {
    1: i64     feature_rule_cnt  // 算法特征数量
    2: string  feature_rule_str  // 算法特征组合描述
}

struct AnalysisPoolApplicationRecord {
    1: required string             application_record_id       // 记录id
    2: required string             pool_id                     // 货盘id
    3: required ApplicationScene   application_scene           // 下游应用场景，0=企划中心超值购0补，1=猜喜流量扶持
    4: required ApplicationVector  application_vector          // 下游应用载体，0=hive
    5: optional i64                update_frequency            // 更新频率，x天一次
    6: optional string             target_hive_warehouse_name  // 目标HIVE表库名
    7: optional string             target_hive_table_name      // 目标HIVE表名
    8: optional string             target_hive_prod_alias      // 商品id别名
    9: optional ApplicationStatus  application_status          // 应用状态 0=异常 1=正常
    10: optional string            application_error_info      // 应用失败信息
}

struct AnalysisPool {
    1: optional string                                pool_id                  // 货盘ID
    2: optional string                                pool_name                // 货盘名称
    3: optional string                                create_user_id           // 创建者userId
    4: optional i64                                   create_time              // 创建时间(时间戳，秒)
    5: optional string                                update_user_id           // 更新者userId
    6: optional i64                                   update_time              // 创建时间(时间戳，秒)
    7: required AnalysisPoolType                      pool_type                // 货盘类型 0 商品 1 规则
    8: required PoolSource                            pool_source              // 货盘来源 0=无, 1=秒杀频道投放, 2=超值购频道投放
    9: optional dimensions.ProductAnalysisBaseStruct  base_struct              // 货盘规则
    10: optional list<AnalysisPoolApplicationRecord>  application_record_list  // 货盘关联下游应用
}

// 查询货盘列表
struct QueryAnalysisPoolListReq {
    1: base.PageInfo              page_req          // 分页参数
    3: optional string            create_user_id    // 创建人user id
    4: optional string            pool_name         // 货盘名称
    5: optional PoolSource        pool_source       // 货盘来源 0=无, 1=秒杀频道投放, 2=超值购频道投放
    6: optional list<PoolSource>  pool_source_list  // 货盘来源支持传数组 0=无, 1=秒杀频道投放, 2=超值购频道投放. eg: [1, 2]
    7: optional string            pool_id           // 货盘id
    8: optional AnalysisPoolType  pool_type         // 货盘类型 0 商品 1 规则 2 算法特征生成

    255: optional base.Base       Base             
}

struct QueryAnalysisPoolListData {
    1: required list<AnalysisPool>  list      
    2: base.PageResp                page_info  // 页码
}

struct QueryAnalysisPoolListResp {
    1: required i32                        code      // 状态码 0: 成功
    2: required string                     msg       // 出错提示消息
    3: required QueryAnalysisPoolListData  data      // 返回结果

    255: optional base.BaseResp            BaseResp 
}

// 创建货盘
struct CreateAnalysisPoolReq {
    1: required string                                pool_name        // 货盘名称
    2: optional string                                pid_list         // 商品id列表
    3: required AnalysisPoolType                      pool_type        // 货盘类型 0 商品 1 规则
    4: required PoolSource                            pool_source      // 货盘来源 0=无, 1=秒杀频道投放, 2=超值购频道投放
    5: optional dimensions.ProductAnalysisBaseStruct  base_struct      // 货盘规则
    6: optional bool                                  is_total         // 是否整体规则
    7: optional string                                feature_task_id  // 特征圈品任务id
    255: optional base.Base                           Base            
}

struct CreateAnalysisPoolResp {
    1: required string           data      // 货盘id
    255: optional base.BaseResp  BaseResp 
}

// 更新货盘
struct UpdateAnalysisPoolReq {
    1: required string       pool_id    // 货盘ID
    2: optional string       pool_name  // 货盘名称
    3: optional string       pool_rule  // 货盘圈品规则
    255: optional base.Base  Base      
}

struct UpdateAnalysisPoolResp {
    1: required string           analysis_pool_id 
    255: optional base.BaseResp  BaseResp         
}

//删除货盘
struct DeleteAnalysisPoolReq {
    1: required string       pool_id  // 货盘ID
    255: optional base.Base  Base    
}

struct DeleteAnalysisPoolResp {
    1: required bool             data      // 是否删除
    255: optional base.BaseResp  BaseResp 
}

// 查询货盘详情
struct QueryAnalysisPoolDetailReq {
    1: string                                         pool_id      // 货盘ID
    2: optional dimensions.ProductAnalysisBaseStruct  base_struct  // 货盘规则

    255: optional base.Base                           Base        
}

struct AnalysisPoolStat {}

struct QueryAnalysisPoolDetailData {
    1: AnalysisPool                               info              
    2: i64                                        prod_cnt_1d        // 近一日商品数量
    3: string                                     prod_tag_code      // 商品画像标记
    4: optional product_select.ProductSelectTask  feature_rule_info  // 算法特征任务信息
}

struct QueryAnalysisPoolDetailResp {
    1: required i32                          code      // 状态码 0: 成功
    2: required string                       msg       // 出错提示消息
    3: required QueryAnalysisPoolDetailData  data      // 返回结果

    255: optional base.BaseResp              BaseResp 
}

// 查询货盘投放整体数据
struct QueryAnalysisPoolDeliveryStatReq {
    1: string                pool_id  // 货盘ID

    255: optional base.Base  Base    
}

struct AnalysisPoolDeliveryStat {
    1: optional string   date                         // 日期
    2: optional string   pay_ord_uv                   // 投放场景支付用户数
    3: optional string   show_uv                      // 投放场景曝光用户数
    4: optional string   pay_ord_cnt                  // 投放场景支付订单数
    5: optional string   pay_gmv                      // 投放场景支付GMV
    6: optional string   platform_coupon_amt          // 投放场景平台券金额
    7: optional string   campaign_platform_cost_amt   // 投放场景活动平台补贴金额
    8: optional string   all_platform_cost_amt        // 投放场景货补金额(券+补贴)
    9: optional string   real_cost                    // 投放场景花费实际消耗
    10: optional string  avg_order_real_cost          // 投放场景订单成本(每笔支付订单花费实际消耗)
    11: optional string  avg_order_platform_cost_amt  // 投放场景补贴成本(每笔支付订单花费平台货补成本)
    12: optional string  avg_order_cost               // 投放场景总成本(投放场景支付订单成本 + 投放场景补贴成本)
    13: optional string  cac                          // 投放场景用户成本(每个支付用户花费实际消耗)
}

struct QueryAnalysisPoolDeliveryStatData {
    1: optional AnalysisPoolDeliveryStat        agg_data           // 汇总数据
    2: optional list<AnalysisPoolDeliveryStat>  group_by_day_data  // 按天分组数据
}

struct QueryAnalysisPoolDeliveryStatResp {
    1: required i32                                code      // 状态码 0: 成功
    2: required string                             msg       // 出错提示消息
    3: required QueryAnalysisPoolDeliveryStatData  data      // 返回结果

    255: optional base.BaseResp                    BaseResp 
}

// 创建货盘下游应用记录
struct CreateAnalysisPoolApplicationRecordReq {
    1: required string             pool_id                     // 货盘id
    2: required ApplicationScene   application_scene           // 下游应用场景，0=企划中心超值购0补，1=猜喜流量扶持
    3: required ApplicationVector  application_vector          // 下游应用载体，0=hive
    4: optional i64                update_frequency            // 更新周期每 x 天更新
    5: optional string             target_hive_warehouse_name  // 目标HIVE表库名
    6: optional string             target_hive_table_name      // 目标HIVE表名
    7: optional string             target_hive_prod_alias      // 商品id别名
    255: optional base.Base        Base                       
}

struct CreateAnalysisPoolApplicationRecordResp {
    1: required string           data      // 应用记录id
    255: optional base.BaseResp  BaseResp 
}
