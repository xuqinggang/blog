namespace py common_response
namespace go common_response

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../analysis/analysis.thrift"
include "../basic_info.thrift"
include "../prod_review/prod_review.thrift"



//    ----------------------------------------- 多维表通用结构 --------------------------------------------
struct RowData {
    1: string dimension_name   // 维度名称
    2: string dimension_code   // 维度code
    3: string dimension_value
    4: list<analysis.TargetCardEntity> target_list  // 指标列表
    5: list<RowData> children_rows // 下钻维度
    6: string prod_tag_code // 查看商品画像的标签，老版商品明细
    8: map<string,string> extra_info   // 额外信息
}

struct MultiDimTableData{
    1: RowData total         // 置顶行，全部商品
    2: list<RowData> rows    // 指标列表
    3: RowData all_total
    4: map<string,string> extra_info     // 额外信息

    10: optional base.PageResp page_info // 分页信息
}

struct CommonAnalysisMultiDimTableResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required MultiDimTableData data // 返回结果

    255:optional base.BaseResp BaseResp
}

struct TargetRowData {
    1: string code   // 指标code
    2: string name   // 指标名称
    3: string type   // 指标类型，核心指标/观测指标
    4: list<analysis.TargetCardEntity> index_list   // 指标列表
    5: list<TargetRowData> children_target          // 下钻维度目标
}

struct TargetData {
    1: string group                         // 目标分组
    2: list<TargetRowData> records          // 目标记录
}

struct CommonAnalysisTargetTableResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required list<TargetData> data                   // 目标列表

    255:optional base.BaseResp BaseResp
}

struct CommonAnalysisDownloadResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required bool data,                                 // 下载结果

    255: base.BaseResp BaseResp
}

//    ----------------------------------------- 分组指标 --------------------------------------------
struct QuadrantInfo{
    1: string quadrant_name  // 象限名称
    2: list<string> main_category_name  // 主要类目
    3: string quadrant_query_param // 象限查询参数
}

struct ValueClassifyInfo {
    1: string query_param
    // 原始的请求数据， 用于lander组件的数据回显
    2: prod_review.ProductValueClassifyParams origin_params
}
struct ItemDataExtraInfo{
    1: QuadrantInfo quadrant_info // 商品复盘额外信息
    2: prod_review.FunnelFloor funnel_floor // 漏斗层信息
    3: ValueClassifyInfo value_classify_info // 价值分类信息
}

struct ItemDataListExtraInfo{
    1: prod_review.QuadrantAxisConfig quadrant_axis_config // 象限划分具体信息，用于前端展示和后续筛选
}

struct ItemData {
    1: string item_name   // 分组名称
    2: list<analysis.TargetCardEntity> target_list    // 指标列表 pv
    3: list<ItemData> children     // 子项目
    4: ItemDataExtraInfo extra_info   //  额外信息
}

struct ItemDataList{
    1: list<ItemData> item_data_list
    2: ItemDataListExtraInfo extra_info
}

struct CommonAnalysisItemDataResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required ItemDataList data // 返回结果

    255:optional base.BaseResp BaseResp
}



//    ----------------------------------------- 统一数据 --------------------------------------------

struct UnifiedDataExtraInfo{
    1: optional prod_review.BubbleChartInfo bubble_chart_info // 气泡图信息
}

struct UnifiedData{
    1: list<map<string,string>> key_value_list
    2: optional UnifiedDataExtraInfo extra_info // 额外信息
}
// 今天+L1+gmv+value

struct CommonAnalysisUnifiedDataResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required UnifiedData data // 返回结果

    255:optional base.BaseResp BaseResp
}

//    ----------------------------------------- 诊断结论 --------------------------------------------

struct  GetDiagnosisConclusion{
    1: list<dimensions.SelectedDimensionInfo> dimensions // 人货场属性筛选
    2: string conclusion_format_text
}

struct GetDiagnosisConclusionGroup{
    1: string name
    2: GetDiagnosisConclusion conclusions
}

struct GetDiagnosisConclusionData {
    1: list<GetDiagnosisConclusionGroup> group_list
}

struct GetDiagnosisConclusionResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required GetDiagnosisConclusionData data, // 返回结果

    255: base.BaseResp BaseResp
}

//    ----------------------------------------- 业务线统一配置 --------------------------------------------

struct BizConfigData {
    1: dimensions.BizType depend_biz_type
    2: prod_review.ProdReviewConfig prod_review_config  // 商品复盘配置
    // 3: 其它业务线配置，后续关于业务线配置都从这个接口中拿
}

// 业务线配置返回
struct BizConfigResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required BizConfigData data // 返回结果

    255:optional base.BaseResp BaseResp
}

struct CommonMultiDimTargetTrendInfo {
    1: string target_name                                   // 指标名称
    2: analysis.TargetCardExtraInfo extra_info              // 指标额外信息
    3: list<analysis.TargetTrendPoint> target_point_list    // 指标趋势数据
}

// 多维度趋势数据
struct CommonMultiDimTrendInfo {
    1: string enum_value
    2: string display_name
    3: list<CommonMultiDimTargetTrendInfo> target_list
    4: list<CommonMultiDimTrendInfo> children
}
struct CommonMultiDimTrendData {
    1: CommonMultiDimTrendInfo all_total
    2: CommonMultiDimTrendInfo total
    3: list<CommonMultiDimTrendInfo> rows
}

struct CommonMultiDimTrendResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                           // 出错提示消息
    3: required UnifiedData data
    4: required list<map<string,string>> standard_data_list // 标准数据

    255: base.BaseResp BaseResp
}