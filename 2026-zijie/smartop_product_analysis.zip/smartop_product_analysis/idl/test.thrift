struct TestResponse {
    1: required i32 code   // 状态码 0: 成功
    2: required string msg // 出错提示消息
}

struct TestRequest {
    1: optional string id // 出错提示消息
}