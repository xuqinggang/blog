namespace py file
namespace go file

include "../base.thrift"

struct UploadFileRequest {
    1: required binary raw_body (agw.source = "raw_body"),
    2: required string content_disposition (api.header = "Content-Disposition"),
    3: required string content_type (agw.source = 'header', agw.key = 'Content-Type'),
    253: optional map<string, list<string>> headers (agw.source = "headers"),
    255: optional base.Base Base,
}

struct UploadFileResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    3: required string url,               // file
    4: required string obj_key,           // object key
    255: optional base.BaseResp BaseResp,
}