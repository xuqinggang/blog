namespace py prod_review
namespace go prod_review


include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../analysis/analysis.thrift"
include "../basic_info.thrift"

// 货盘类型
enum ProdPoolType{
    Unknown = 0
    Current = 1 // 当前货盘
    Compare = 2 // 对比货盘
    // 建议扩大规模的品
    SuggestExpandScaleProduct = 3
    // 建议流量扶持的品
    SuggestTrafficSupportProduct = 4
    // 建议优化转化的品
    SuggestOptimizeConvertProduct = 5
    // 建议淘汰的品
    SuggestEliminateProduct = 6
    // 短期有价值品
    ShortTermValueProduct = 7
    // 长期有价值品
    LongTermValueProduct = 8
    // 策略负向品
    StrategyNegativeProduct = 9
}

// 阈值类型，有价值品定义
enum ThresholdType {
    Unknown = 0
    AbsoluteValue = 1       // 绝对值
    Percentile = 2          // 分位数
}

// 值类型
enum ValueType {
    Unknown = 0
    Increase = 1    // 增量
    AbsoluteValue = 2       // 绝对值
    // AA增幅
    AAIncreasePercent = 3          // AA增幅
    ABIncreasePercent = 4          // AB增幅
    ABIncrease = 5                 // AB增量
}




// 对比条件，小于，小于等于，大于，大于等于
enum CompareCondition{
    Unknown = 0
    LessThan = 1  // 小于
    LessThanOrEqual = 2  // 小于等于
    GreaterThan = 3  // 大于
    GreaterThanOrEqual = 4  // 大于等于
}

// 象限划分，均值，中位数，分位数
enum AxisSegmentation{
    Unknown = 0
    Mean = 1  // 均值
    // 中位数
    Median = 2  // 中位数
    Top10Percent = 3  // top10%分位数
    Top20Percent = 4  // top20%分位数
}

// 价值品定义
enum ValueProductType {
    Unknown = 0
    ContributionRate = 1  // 贡献度
    Percentile = 2     // 分位数
    IncreaseRate = 3     // 增幅
}


// 分析对象，整体商品，策略覆盖品，策略未覆盖品
enum AnalysisObject{
    Unknown = 0
    AllProduct = 1  // 整体商品
    StrategyCoveredProduct = 2  // 策略覆盖品
    StrategyUncoveredProduct = 3  // 策略未覆盖品
}

// 漏斗图枚举
enum FunnelChart {
    Unknown = 0
    CoreBizFunnel = 1                   // 核心业务漏斗
    RuleFunnel = 2        // 规则漏斗
    OperationFunnelSignUpSuccess = 3 // 运营漏斗-报名成功
    OperationFunnelSignUpFailPriceMatch = 4 // 运营漏斗-报名未成功-价格符合
    OperationFunnelSignUpFailPriceNoMatch = 5 // 运营漏斗-报名未成功-价格不符合
    OperationFunnelNoSignUpPriceMatch = 6 // 运营漏斗-未报名-价格符合
    OperationFunnelNoSignUpPriceNoMatch = 7 // 运营漏斗-未报名-价格不符合
    // 机会品招募漏斗
    RecruitProdFunnel = 8 // 运营漏斗-机会品招募成功
    CommonFunnel = 9 // 通用漏斗
    MarketCommonFunnel = 10 // 商城加补漏斗




    OperationFunnelTest = -1 // 运营漏斗-测试
}

enum AIModuleName {
    Unknown = 0,
    // 专项-目标分析
    AllowanceTarget = 1,
    // 专项-供给分析
    AllowanceSupply = 2,
    // 单一策略-人货场洞察
    SingleStrategyMultiDimAnalysis = 3,
    // 单一策略-供给分析
    SingleStrategySupplyAnalysis = 4,
}

// AI 提示词变量
typedef map<string, map<string, string>> PromptVariables

enum ModuleName {
    Unknown = 0
    // 单策略
    SingleStrategy = 1
    // 汇总层
    SummaryLayer = 2
    // 单策略-商品价值分类
    SingleStrategyProductValueClassification = 3
    // 单策略-供给分析
    SingleStrategySupplyAnalysis = 4
    // 单策略-供给深度分析气泡图
    SingleStrategySupplyAnalysisBubbleChart = 5
    // 单策略-流量分布
    SingleStrategyFlowDistribution = 6
    // 单策略-流量分布气泡图
    SingleStrategyFlowDistributionBubbleChart = 7
    // 策略列表
    StrategyList = 8
    // 单策略-人货场洞察
    SingleStrategyMultiDimAnalysis = 9
    // 专项-人货场洞察
    SpecialItemMultiDimAnalysis = 10
    // 专项-漏斗-下钻分析-第一级
    FunnelDrillAnalysisFirst = 11

    // 专项-超值购目标分析
    AllowanceTarget = 12
    // 专项-超值购漏斗分析
    AllowanceFunnel = 13
    // 专项-漏斗-下钻分析-第二级
    FunnelDrillAnalysisSecond = 14
    // 专项-AI 诊断
    AIDiagnosis = 15
    // 单策略-漏斗下钻分析-第一级
    SingleStrategyFunnelDrillAnalysisFirst = 16
    // 单策略-漏斗下钻分析-第二级
    SingleStrategyFunnelDrillAnalysisSecond = 17
    // 机会品招募漏斗
    RecruitProdFunnel = 18
    // 专项-流量分布
    SpecialItemFlowDistribution = 19
    // 专项-贡献度分析
    SpecialItemContributionAnalysis = 20
    // metric_group_analysis 指标组分析
    MetricGroupAnalysis = 21

}

// 目标维度和具体code
struct GoalInfo {
    1: string dimension_id // 维度id
    2: string dimension_code // 维度code
}

// 轴配置
struct QuadrantAxisConfig {
     1: string axis_target_name // 轴，指标名称
     2: ValueType value_type // 值类型
     3: CompareCondition axis_condition // 轴，对比条件
     4: AxisSegmentation axis_segmentation // 轴划分
     5: double axis_segmentation_value // 抽划分，具体值
}

struct BubbleChartInfo{
    1: string x_axis_target_name // x轴指标名称
    2: string x_axis_target_value // x轴指标值
    3: string x_axis_target_display_value // x轴指标展示值
    4: string y_axis_target_name //  y轴指标名称
    5: string y_axis_target_value // y轴指标值
    6: string y_axis_target_display_value // y轴指标展示值
}

// 漏斗层信息
struct FunnelFloor {
    1: list<dimensions.SelectedDimensionInfo> dimension_infos  // 漏斗绑定的维度信息
    2: i64 funnel_floor_order // 漏斗层顺序
    3: string core_target_name // 目标指标
    4: string tips // 提示词
}



// 商品分化
struct ProductFractureParams {
    1: ValueProductType value_product_type // 价值品定义
    2: double short_term_value   // 短期指标值
    3: double long_term_value    // 长期指标值
    4: CompareCondition short_term_condition
    5: CompareCondition long_term_condition
}

//四现象分析请求参数
struct QuadrantPartitionParams {
    1: ProdPoolType prod_pool_type // 货盘类型
    2: ThresholdType threshold_type // 阈值类型
    3: QuadrantAxisConfig x_axis_config // x轴配置
    4: QuadrantAxisConfig y_axis_config // y轴配置
    7: AnalysisObject   analysis_object // 分析对象类型
    8: string strategy_id // 策略id
    9: string drill_dimension_id // 下钻维度id
}

// 商品气泡图请求参数
struct BubbleChartParams {
    1: ProdPoolType prod_pool_type // 货盘类型
    2: string drill_dimension_id  // 下钻维度id
    3: list<dimensions.SelectedDimensionInfo> dimensions // 维度筛选
    4: string bubble_size_target_name // 决定气泡大小的指标名称
    5: QuadrantAxisConfig x_axis // x轴配置
    6: QuadrantAxisConfig y_axis // y轴配置
    7: AxisSegmentation axis_segmentation // 轴划分
    8: string quadrant_query_param // 象限查询参数
    9: string product_fracture_params   // 商品分化查询参数
    10: AnalysisObject   analysis_object // 分析对象类型
    11: string strategy_id // 策略id
}

// 商品价值分类请求参数
struct ProductValueClassifyParams {
    1: required ProdPoolType prod_pool_type,       // 分析货盘
    2: required ValuableProductDefine define_type, // 有价值品定义
    3: required double short_term_threshold,       // 短期阈值
    4: required double long_term_threshold,        // 长期阈值
    5: required QueryType query_type,              // 查询类型
    6: optional TargetPoolType target_pool_type,   // 目标货盘
}

// 有价值品定义
enum ValuableProductDefine {
    // 贡献度
    Contribution = 1,
    // TOP 分位
    TopPercentile = 2,
    // 增幅
    Amplitude = 3,
}

// 查询类型
enum QueryType {
    // 商品数量
    ProductCount = 0,
    // 下钻分析
    DrillDown = 1,
}

enum TargetPoolType {
    // 全量商品
    AllProducts = 0,
    // 优势品
    AdvantageProducts = 1,
    // 劣势品
    DisadvantageProducts = 2,
}

// 流量分析方式

// 流量分析方式
enum FlowAnalysisType {
    Unknown = 0
    ProdPoolCompare = 1  // 货盘对比
    PeriodCompare = 2 // 周期维度对比
}


// 流量分布配置
struct FlowDistributionParams {
    1: AnalysisObject analysis_object // 分析对象类型
    2: string strategy_id // 策略id
    3: list<dimensions.SelectedDimensionInfo> dimensions // 维度筛选
    4: string target_name // 分析指标明细
    5: string drill_dimension_id  // 分布或者下钻维度
    6: FlowAnalysisType flow_analysis_type // 流量分析方式
}

// 商品明细查询参数
struct ProdDetailParams {
    1: string quadrant_query_param // 象限查询参数
    2: string bubble_chart_query_param // 气泡图查询参数
    3: string value_classify_query_params // 商品分化查询参数
    4: AnalysisObject analysis_object // 分析对象类型
}

// 货盘复盘业务参数
struct ProdReviewParams {
    1: string biz_project_id // 业务专项或业务货盘id
    2: string strategy_id // 策略id
    3: string report_id // 复盘报告id
    4: ExpConfig exp_config // 实验配置
    5: ModuleName module_name
    6: CompareProdPoolType compare_prod_pool_type // 对比货盘类型
    7: ProductFractureParams    product_fracture_params // 商品分化参数
    8: QuadrantPartitionParams  quadrant_partition_params // 四象限分析参数
    9: BubbleChartParams bubble_chart_params // 气泡图参数
    10: FlowDistributionParams flow_distribution_params // 流量分布参数
    11: FunnelChart funnel_chart // 漏斗图类型
    12: GoalInfo goal_info // 目标维度和具体code
    13: ProdDetailParams prod_detail_params // 商品明细查询参数
    14: optional AIModuleName ai_module_name, // AI诊断模块
    15: optional ProductValueClassifyParams product_value_classify_params // 商品价值分类参数
}

// 货盘复盘业务参数
struct ProdReviewRespExtraInfo {

}





// 策略粒度
enum StrategyGranularity {
    Unknown = 0
    Product = 1   // 商品
}

// 分析视角
enum AnalysisPerspective{
    Unknown = 0
    AA = 1
    AB = 2
    AA_AB = 3
}

// 目标类型
enum GoalType {
    Unknown = 0
    ShortTerm  = 1  // 短期目标
    LongTerm   = 2  // 长期目标
}

// 视角类型
enum ViewType {
    Unknown = 0
    AA = 1
    AB = 2
}

// 指标类型
enum TargetType{
    Unknown = 0
    Increase = 1  // 增量
    IncreaseRate = 2  // 增幅
    AbsoluteValue = 3  // 绝对值
}

// AA增量计算方式
enum InCreaseCalType {
    Unknown = 0
    ReachStdVsReachStd = 1  // 达标 vs 达标
    ReachStdVsNoReachStd = 2  // 达标 vs 未打标
    ReachStdVsTotalPeriod = 3  // 达标 vs 全周期

}

// AB实验汇总方式
enum SummaryType {
    Unknown = 0
    AbsoluteAgg = 1  // 绝对值聚合
    PosAbsoluteAgg = 2 // 正向绝对值聚合
    NegAbsoluteAgg = 3 // 负向绝对值聚合
    PosAbsoluteSignificantAgg = 4 // 正向绝对值显著聚合
}

// 增量统计口径
enum StatisticType {
    Unknown = 0
    Daily = 1   // 日均
    Sum = 2     // 累计
}

// 业务专项类型
enum BizProjectType {
    Unknown = 0
    BizProject = 1  // 业务专项
    BizProjectProdPool = 2  // 业务专项货盘
}

// 实体类型
enum EntityType {
    Unknown = 0
    Strategy = 1  // 策略
    BizProject = 2  // 业务专项
}

//  支持对象
enum SupportObject {
    Unknown = 0
    Customer = 1    // C侧
    Business = 2    // B侧
}

//  类型处理逻辑ID
enum ProcessLogicId {
    Unknown     = 0
    // 1-100 市集相关
    MarketSignUpActivity    = 1
    MarketReverseAB         = 2
}

// 对比货盘类型
enum CompareProdPoolType {
    Unknown = 0
    EcomOverall = 1  // 电商大盘
    StrategyOverall = 2  // 策略覆盖大盘
    CustomProdPool = 3 // 自定义货盘
    ZeroOverall = 4 // 0补大盘
    BizProjectProdPool = 5 // 业务专项覆盖大盘
}

// 圈品逻辑
enum SelectProductType {
    Unknown = 0
    AnyDayMatch = 1  // 任意一天符合
    RuleMatch = 2    // 规则选品
}

// 周期对比类型
enum PeriodCompareType {
    Unknown = 0
    SameProdCompare = 1  // 同品对比，同一波品，里那个周期对比
    RuleProdCompare = 2  // 规则选品对比，相同规则品，不同周期对比
}

// 分析类型
enum StrategyAnalysisType{
    Unknown = 0
    AACommonAnalysis = 1 // AA通用分析
    ABExpAnalysis= 2     // AB实验分析
}

// 业务专项货盘类型
enum BizProjectProdPoolType {
    Unknown = 0
    BizProject = 1  // 业务专项全部商品
    BizProjectStrategyCover = 2  // 业务专项策略覆盖品
}

// 对比货盘配置
struct CompareProdPoolConf {
    1: map<CompareProdPoolType,string> compare_prod_pool_type_map // 对比货盘类型
}

// 四象限分析配置
struct QuadrantPartitionConf {
    1: map<ProdPoolType,string> prod_pool_type_map // 货盘类型
    2: map<ThresholdType,string> threshold_type_map // 阈值类型，绝对值、分位数
    3: map<ValueType,string> value_type_map // 值类型，增量、绝对值
    4: list<string>  partition_target_list // 划分指标
    5: map<CompareCondition,string> compare_condition_map // 对比条件，小于，小于等于，大于，大于等于
    6: map<AxisSegmentation,string> axis_segmentation_map // 象限划分，均值，中位数，分位数
    7: string one_service_api      // OS API
    8: string main_dimension_id    // 主要维度id
    9: string main_dimension_col    // 主要维度列名和主要维度id二选一
}

// 商品分化配置
struct ProductFractureConf {
    1: map<ValueProductType,string> value_product_type_map // 价值品定义
    2: map<ValueType,string>  value_type_map // 值类型，AA增幅、AB增幅
    3: string one_service_api      // OS API
}

// 气泡图配置
struct BubbleChartConf {
    1: map<ProdPoolType,string> prod_pool_type_map // 货盘类型
    2: list<string> distribution_dimension_ids  // 可选分布维度
    3: list<string> drill_dimension_ids   // 可选下钻维度
    4: map<AxisSegmentation,string> axis_segmentation_map // 象限划分，均值，中位数，top10分位，top20分位数
    5: list<string> partition_target_list // 象限划分指标
    6: map<ValueType,string> value_type_map // 值类型，绝对值
    7: list<string> bubble_size_target_list // 决定气泡大小的指标名称
    8: map<AnalysisObject,string> biz_project_analysis_object_map // 业务专项分析对象
    9: string one_service_api      // OS API
}
// 流量配置
struct FlowDistributionConf {
    1: map<AnalysisObject,string> biz_project_analysis_object_map // 业务专项分析对象
    2: list<string> filter_dimension_ids // 可选过滤维度
    3: list<string> distribution_dimension_ids // 可选分布维度
    4: list<string> flow_analysis_target_list  // 流量分析指标
    5: string one_service_api      // OS API
}

struct LibraMetricGroupAnalysisConf {
    1: i32 id             // 指标组分析id
    2: string name        // 指标组分析名称
    3: string description // 指标组分析描述
    4: string dimensions  // 维度配置,使用序列化后的结果
}

struct ModuleConfig {
    1: CompareProdPoolConf compare_prod_pool_conf // 对比货盘设置
    2: QuadrantPartitionConf quadrant_partition_conf // 四象限分析设置
    3: ProductFractureConf product_fracture_conf // 商品分化设置
    4: BubbleChartConf  supply_bubble_chart_conf // 供给气泡图设置
    5: BubbleChartConf  flow_bubble_chart_conf // 流量气泡图设置
    6: FlowDistributionConf flow_distribution_conf // 流量分布设置
    7: optional list<LibraMetricGroupAnalysisConf> libra_metric_group_analysis_conf_list // 指标组分析设置
}

struct ProdReviewConfig {
    1: ModuleConfig strategy_module_config   // 策略专项配置
    2: ModuleConfig biz_project_module_config // 业务专项配置
}

// 实验配置
struct ExpConfig {
    1: string experiment_id // 实验id
    2: string base_version_id // 对照组id
    3: string exp_version_id //  实验组id
    4: bool   is_all_versions // 是否包含所有实验组
    5: string strategy_id // 策略id
    6: SummaryType summary_type // 实验汇总类型
}



// 策略目标
struct StrategyGoal {
    1: GoalType goal_type // 目标类型
    2: i32 after_strategy_end_day // 策略结束后多少天
    3: string target_name  // 指标名称
    4: TargetType target_type  // 指标类型
    5: ViewType view_type  // 视角类型
    6: string target_display_name // 指标展示名称
    7: CompareCondition goal_condition // 目标条件类型
    8: double goal_target_value // 目标指标值
}

// 策略类型
struct StrategyType {
    1: string strategy_type_id // 策略类型id
    2: string strategy_type_name // 策略类型名称
    3: list<string> binding_dimension_ids // 绑定维度
    4: dimensions.BizType biz_type // 业务线
    5: SelectProductType select_product_type // 圈品逻辑
    6: string reach_std_rule   // 达标规则
    7: bool is_depend_user_input  // 是否依赖用户输入
    8: PeriodCompareType period_compare_type // 周期对比类型
    9: list<AnalysisPerspective> support_analysis_perspective    // 策略类型支持的分析视角
    10: SupportObject support_object    // 策略类型支持的对象
    11: ProcessLogicId process_logic_id // 类型处理逻辑ID
    12: StrategyAnalysisType strategy_analysis_type // 策略类型支持的分析类型
    13: bool is_depend_sub_query // 是否依赖子查询
    14: string ai_prompt // ai提示词
}

// 货盘复盘策略
struct ProdReviewStrategy {
    1: string strategy_id        // 策略id
    2: string strategy_name   // 策略名称
    3: string strategy_desc   // 策略描述
    4: StrategyType strategy_type   // 策略类型
    5: StrategyGranularity granularity     // 策略粒度
    6: i64 start_date      // 开始时间
    7: i64 end_date        // 结束时间
    8: string flight_id          // 关联实验id
    9: LibraItem base_version_info    // 对照组
    10: list<LibraItem> all_version_info // 实验的所有组（包含对照组）
    11: list<dimensions.SelectedDimensionInfo> relation_prod_pool    // 关联货盘,一组维度规则的序列化(SelectedDimensionInfo的jsonStr)
    12: StrategyGoal short_term_goal  // 短期目标
    13: StrategyGoal long_term_goal   // 长期目标
    14: list<string> target_list
    15: AnalysisPerspective analysis_perspective    // 分析视角
    16: InCreaseCalType aa_increase_cal_type   // aa 增量计算方式
    17: StatisticType statistic_type   // 增量统计口径
    18: list<dimensions.SelectedDimensionInfo> strategy_reach_rule // 策略达标规则(SelectedDimensionInfo的jsonStr)
    19: string create_user  // 创建人
    20: string update_user  // 更新人
    21: i64 create_time  // 创建时间
    22: i64 update_time  // 更新时间
    23: i32 is_del // 是否删除
    24: list<analysis.TargetCardEntity> query_target_list
    25: bool has_edit_permission // 是否有编辑权限
    26: dimensions.BizType biz_type // 所属业务线
}

struct LibraItem {
    1: string version_id
    2: string version_name
    3: VersionType version_type // 分组类型
}


// 业务专项
struct BizProject {
    1: string biz_project_id // 业务专项id
    2: string biz_project_name // 业务专项名称
    4: list<dimensions.SelectedDimensionInfo> filter_dimensions // 业务专项过滤维度(SelectedDimensionInfo的jsonStr)
    5: list<string> bind_strategy_ids // 绑定的策略id
    6: dimensions.BizType biz_type // 所属业务线
    7: SummaryType summary_type  // 汇总方式
    //8: InCreaseCalType aa_increase_cal_type   // aa 增量计算方式
    9: list<string> target_list // 指标列表
    10:list<string> diagnosis_target_list // 维度列表
    // 11:ExpConfig exp_config // 实验配置
    12: string create_user  // 创建人
    13: string update_user  // 更新人
    14: i64 create_time  // 创建时间
    15: i64 update_time  // 更新时间
    16: string effective_time // 生效时间
    17: i32 is_del // 是否删除
    18: list<analysis.TargetCardEntity> query_target_list
    19: list<ProdReviewStrategy> strategy_list // 绑定的策略列表
    20: bool has_edit_permission // 是否有编辑权限
}


// 复盘报告
struct ProdReviewReport {
    1: string report_id // 复盘报告id
    2: string report_name // 复盘报告名称
    3: string relation_id // 关联id， 策略id/业务专项id
    4: EntityType entity_type // 实体类型,0-策略，1-业务专项
    5: list<dimensions.SelectedDimensionInfo> filter_dimensions // 过滤维度(SelectedDimensionInfo的jsonStr)
    6: list<dimensions.SelectedDimensionInfo> compare_filter_dimensions // 对比过滤维度(SelectedDimensionInfo的jsonStr)
    7: CompareProdPoolType compare_prod_pool_type // 对比货盘类型
    8: string create_user  // 创建人
    9: string update_user  // 更新人
    10: i64 create_time  // 创建时间
    11: i64 update_time  // 更新时间
    12: i32 is_del // 是否删除
    13: dimensions.BizType biz_type // 所属业务线
    14: BizProject biz_project // 业务专项
    15: ProdReviewStrategy prod_review_strategy // 业务专项绑定的策略列表
    16: bool has_edit_permission // 是否有编辑权限
}

// 实验组信息
struct LibraInfo {
    1: list<LibraVersion> libra_version_info_list   // 实验组信息
}

// 实验组信息
struct LibraVersion {
    1: required string        id,                // 实验组ID
    2: required string        name,              // 实验组名称哈希
    3: required string        display_name,       // 实验组名称
    4: required string        config,            // 实验组配置，json字符串
    5: required VersionType   version_type,       // 实验组类型
    6: required VersionStatus status,            // 实验组状态
    7: required string        user_tag,           // 实验组用户分群
    8: required string        flight_id,          // 实验ID
    9: required string        flight_name,        // 实验名称哈希
    10: required string       flight_display_name, // 实验名称
    11: required string       owner,             // 实验owner，多个owner以逗号分隔。Deprecated，请使用Owners
    12: required FlightStatus flight_status,      // 实验状态
    13: required i64          start_time,         // 实验开启时间，UNIX时间戳
    14: required i64          end_time,           // 实验结束时间，UNIX时间戳
    15: required string       product_id,         // 功能模块ID
    16: required HashStrategy hash_strategy,      // 分流策略
    17: required i64          create_time,        // 实验创建时间，UNIX时间戳
    18: required string       description,       // 实验组描述
    19: required FlightType   flight_type,        // 实验类型
    20: required string       layer_name,         // 实验层名称
    21: required string       token,             // 功能模块Token
    22: required string       app_id,             // Libra后台应用ID
    23: required list<string> apps,              // 业务应用ID
    24: required string       app_name,           // 应用名称
    25: required bool         isUTC,             // 是否UTC
    26: required list<string> owners,            // 实验owners
    27: required list<string> user_list,          // 实验组白名单用户
    28: required string       layer_id,           // 实验层ID
    29: required string       layer_display_name,  // 实验层显示名称
    30: required string       conditional_config, // 多机房配置,仅海外
    31: required string       weight,            // 不均等流量实验版本权重
    32: required string       reuse_vid,          // 共享实验版本
}

enum VersionType {
    CONTROL    = 0, // 对照组
    EXPERIMENT = 1, // 实验组
}

enum VersionStatus {
    OFF = 0, // 关闭
    ON  = 1, // 开启
}

enum FlightStatus {
    EXPIRED    = 0,  // 已过期
    PROCESSING = 1,  // 进行中
    READY      = 2,  // 待调度
    TESTING    = 3,  // 测试中
    SUSPEND    = 4,  // 已暂停
    RELEASED   = 91, // 满足预期

    OTHER      = -1, // 其它
}

enum HashStrategy {
    UID    = 0, // 按uid分流
    DID    = 1, // 按device_id分流
    RID    = 2, // 按rid分流
    UNION  = 3, // 联合分流
    UUID   = 4, // 按uuid分流
    CDID   = 5, // 按cdid分流
}

enum FlightType {
    STRATEGY               = 0  // 服务端实验（策略实验）
    PRODUCT                = 1  // 普通客户端实验（产品实验）
    AD_USER                = 2  // 广告用户实验
    AD_ADVERTISER          = 3  // 广告主实验
    AD_PLAN                = 4  // 广告计划实验
    INTERLEAVING           = 5  // 搜索实验
    AB_CLIENT_SDK          = 6  // AB客户端SDK实验
    SETTINGS_CLIENT_SDK    = 7  // Settings SDK实验
    SETTINGS_LOCAL_AB      = 8  // Settings本地分流实验
    REGRESSION             = 9  // 自动搜参实验
    SETTINGS_NORMAL_CLIENT = 10 // Settings普通客户端实验

    OTHER = -1                  // 其它
}

struct GetProdReviewStrategyListData {
    1: list<ProdReviewStrategy> strategy_list    // 策略信息

    11: i64 total_count                          // 总数量
}

struct GetProdReviewBizProjectListData {
    1: list<BizProject> biz_project_list    // 专项信息

    11: i64 total_count                     // 总数量
}

struct GetProdReviewReportListData {
    1: list<ProdReviewReport> report_list    // 复盘报告信息

    11: i64 total_count                      // 总数量
}


//  -----------------------------  更新或新增策略  ------------------
struct CreateAndUpdateProdReviewStrategyRequest {
    1: ProdReviewStrategy strategy    // id 为空时创建，否则更新

    255: optional base.Base Base
}

struct CreateAndUpdateProdReviewStrategyResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required bool data // 返回结果

    255:optional base.BaseResp BaseResp
}

//  -----------------------------  获取策略列表  ------------------
struct GetProdReviewStrategyListRequest {
    1: dimensions.BizType biz_type // 业务线
    2: string  strategy_type_id // 策略类型id
    3: string  strategy_name // 策略名称
    4: list<string>  strategy_ids // 策略ids，多策略查询
    5: i64  effective_start_date  // 生效开始时间
    6: i64  effective_end_date //  生效结束时间
    7: i64  biz_project_id     //   业务专项id
    8: string analysis_start_date   // 分析开始时间
    9: string analysis_end_date     // 分析结束时间

    11: i32 page_num                                      // 页号（第一页传0）
    12: i32 page_size                                     // 记录数量
    13: i32 is_need_all             // 是否返回所有策略
    14: i32 is_only_need_strategy  // 仅需要策略信息，不需要商品数量等指标
    15: optional string employee_id // 员工id
    16: bool is_need_return_targets       // 默认不返回指标数据，false不返回，true返回

    255: optional base.Base Base
}

struct GetProdReviewStrategyListResponse {
    1: required i32 code    // 状态码 0: 成功
    2: required string msg  // 出错提示消息
    3: required GetProdReviewStrategyListData data   // 返回结果

    255: optional base.BaseResp BaseResp
}

//  -----------------------------  获取策略类型列表  ------------------
struct GetProdReviewStrategyTypeListRequest {
    1: optional dimensions.BizType biz_type // 业务线
    255: optional base.Base Base
}

struct GetProdReviewStrategyTypeListResponse {
    1: required i32 code    // 状态码 0: 成功
    2: required string msg  // 出错提示消息
    3: required list<StrategyType> data   // 返回结果

    255: optional base.BaseResp BaseResp
}


//  -----------------------------  更新或新增，业务专项或业务专项货盘  ------------------
struct CreateAndUpdateProdReviewBizProjectRequest {
    1: BizProject biz_project    // id 为空时创建，否则更新

    255: optional base.Base Base
}

struct CreateAndUpdateProdReviewBizProjectResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required bool data // 返回结果

    255: optional base.BaseResp BaseResp
}

//  -----------------------------  获取业务专项列表  ------------------
struct GetProdReviewBizProjectListRequest {
    1: dimensions.BizType biz_type // 业务线
    2: string biz_project_id // 业务专项id
    3: string biz_project_name // 业务专项名称
    4: string analysis_start_date   // 开始时间
    5: string analysis_end_date     // 结束时间
    6: bool is_need_return_targets       // 默认不返回指标数据，false不返回，true返回

    11: i32 page_num                                      // 页号（第一页传0）
    12: i32 page_size                                     // 记录数量

    255: optional base.Base Base
}

struct GetProdReviewBizProjectListResponse {
    1: required i32 code    // 状态码 0: 成功
    2: required string msg  // 出错提示消息
    3: required GetProdReviewBizProjectListData data   // 返回结果

    255: optional base.BaseResp BaseResp
}

//  -----------------------------  更新或新增，复盘报告  ------------------
struct CreateAndUpdateProdReviewReportRequest  {
    1: ProdReviewReport report    // id 为空时创建，否则更新

    255: optional base.Base Base
}

struct CreateAndUpdateProdReviewReportResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required bool data // 返回结果

    255:optional base.BaseResp BaseResp
}

//  -----------------------------  获取复盘报告列表  ------------------
struct GetProdReviewReportListRequest {
    1: dimensions.BizType biz_type          // 业务线
    2: string report_id // 复盘报告id
    3: string report_name                 // 报告名称
    4: string create_user                   // 创建人
    5: string analysis_start_date           // 开始时间
    6: string analysis_end_date             // 结束时间
    7: bool is_need_return_targets       // 默认不返回指标数据，false不返回，true返回

    11: i32 page_num                                      // 页号（第一页传0）
    12: i32 page_size                                     // 记录数量

    255: optional base.Base Base
}

struct GetProdReviewReportListResponse {
    1: required i32 code    // 状态码 0: 成功
    2: required string msg  // 出错提示消息
    3: required GetProdReviewReportListData data   // 返回结果

    255: optional base.BaseResp BaseResp
}

//  -----------------------------  获取libra信息  ------------------
struct GetLibraInfoRequest {
    1: string flight_id                     // 实验id

    255: optional base.Base Base
}

struct GetLibraInfoResponse{
    1: required i32 code    // 状态码 0: 成功
    2: required string msg  // 出错提示消息
    3: required LibraInfo data   // 返回结果

    255: optional base.BaseResp BaseResp
}