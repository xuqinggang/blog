namespace py dimensions
namespace go dimensions

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../dimensions/price_dimensions.thrift"

struct CreateOrUpdateTemplateRequest{
    1: optional dimensions.ProductAnalysisBaseStruct base_info // 基础请求体
    2: string template_id       // 模板ID, 创建时不传
    3: string name              // 模板名称
    4: bool is_common           // 是否公用
    5: optional dimensions.BizType biz_type  // 业务线ID
    6: optional string base_req_marshal // 结构体序列化字符串
    7: optional TemplateModule module_enum // 所属的模块枚举，不传默认是主模块

    255: optional base.Base Base
}

enum TemplateModule{
    MainModule = 0, // 主模块，对应之前各个业务线的模版
    TrendAnalysis = 1, // 趋势分析
    FunnelAnalysis = 2, // 漏斗分析
    ProdRanking = 3, // 商品榜单
    VolumePrice = 4, // 量价模型
}

struct CreateOrUpdateTemplateResponse {
    1: string data  //模板ID

    255: optional base.BaseResp BaseResp,
}

struct DeleteTemplateRequest {
    1: required string template_id  //模板ID

    255: optional base.Base Base
}
struct DeleteTemplateResponse {
    1: bool data //是否删除成功

    255: optional base.BaseResp BaseResp
}

struct GetTemplateListRequest {
    1: required dimensions.BizType biz_type
    2: optional string keyword // 搜索关键词
    3: optional TemplateModule module_enum // 所属的模块枚举，不传默认是主模块

    255: optional base.Base Base
}

struct TemplateElement {
    1: required string  id,     // 唯一标识id
    2: required string  name,   // 展示名称
    3: required string creator, // 创建者
    4: required bool edit, // 是否有编辑权限
}

struct GetTemplateListData {
    1: list<TemplateElement> self_list            // 个人模板列表
    2: list<TemplateElement> common_list          // 公共模版列表
    3: list<TemplateElement> recently_used_list   // 最近常用模板
    4: list<TemplateElement> hot_common_list      // 热门、公共模板
}

struct GetTemplateListResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetTemplateListData data     // 返回结果

    255: optional base.BaseResp BaseResp
}

struct GetTemplateDetailRequest {
    1: required string template_id       // 模板ID

    255: optional base.Base Base
}

struct GetTemplateDetailData {
    1: optional dimensions.ProductAnalysisBaseStruct base_info // 模版的基础信息
    2: string template_id       // 模板ID, 创建时不传
    3: string name              // 模板名称
    4: bool is_common           // 是否公用
    5: string base_req_marshal // 各个页面通用入参序列化后的字符串
}

struct GetTemplateDetailResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetTemplateDetailData data     // 返回结果

    255: optional base.BaseResp BaseResp
}