namespace go ecom.smartop.product_analysis

include "base.thrift"
include "dimensions/dimensions.thrift"
include "analysis/analysis.thrift"
include "activity/activity.thrift"
include "analysis/price_analysis.thrift"
include "template/template.thrift"
include "analysis_pool/analysis_pool.thrift"
include "analysis_pool_product/analysis_pool_product.thrift"
include "analysis_pool_diagnosis/analysis_pool_diagnosis.thrift"
include "analysis_pool_alert_rule/analysis_pool_alert_rule.thrift"
include "dimensions/price_dimensions.thrift"
include "price_aa_compare/price_aa_compare.thrift"
include "activity_review/activity_review.thrift"
include "attribution/attribution.thrift"
include "dorado_task/dorado_task.thrift"
include "subscription/subscription.thrift"
include "volume_price/volume_price.thrift"
include "great_value_buy/great_value_buy.thrift"
include "sku_cluster/sku_cluster.thrift"
include "ai_analysis/ai_analysis.thrift"
include "ai_analysis/ai_strategy.thrift"
include "prod_review/prod_review.thrift"
include "common_request/common_request.thrift"
include "common_response/common_response.thrift"
include "product_select/product_select.thrift"
include "lark/lark.thrift"
include "aggregate/aggregate.thrift"
include "file/file.thrift"
include "test.thrift"

// 商品洞察
service SmartopProductAnalysisService {

    /*
        维度管理
     */

    // 商品流量洞察 - 维度管理 - 获取维度列表信息
    dimensions.GetDimensionListResponse GetDimensionList(1: dimensions.GetDimensionListRequest req) (api.get = "/product_analysis/dimensions/get_dimension_list", api.category = "维度管理", agw.preserve_base = "true"),
    //    // 商品流量洞察 - 维度管理 - 搜索维度、枚举列信息
    //    dimensions.GetDimensionEnumSearchListResponse GetDimensionEnumSearchList(1:dimensions.GetDimensionEnumSearchListRequest req ) ( api.get="/product_analysis/dimensions/get_dimension_enum_search_list", api.category="维度管理", agw.preserve_base="true")
    //    // 商品流量洞察 - 维度管理 - 获取分页动态枚举列表
    dimensions.GetDimensionPageEnumListResponse GetDimensionPageEnumList(1: dimensions.GetDimensionPageEnumListRequest req) (api.post = "/product_analysis/dimensions/get_page_enum_list", api.category = "维度管理", agw.preserve_base = "true"),
    // 可用时间接口
    dimensions.GetDataReadyTimeResponse GetReadyTime(1: dimensions.GetDataReadyTimeRequest req) (api.get = "/product_analysis/dimensions/get_ready_time", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 自然语言处理分析维度筛选
    dimensions.GenerateDimensionWithNlpResponse GenerateDimensionWithNlp(1: dimensions.GenerateDimensionWithNlpRequest req) (api.get = "/product_analysis/dimensions/nlp_generate_dimension", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 获取需要判断B店混比的枚举项
    dimensions.GetPriceHybridTagEnumListResponse GetPriceHybridTagEnumList(1: dimensions.GetPriceHybridTagEnumListRequest req) (api.get = "/product_analysis/dimensions/get_price_hybrid_tag_enum_list", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 获取业务数据列表
    dimensions.GetProductAnalysisBizListResponse GetProductAnalysisBizList(1: dimensions.GetProductAnalysisBizListRequest req) (api.get = "/product_analysis/dimensions/get_product_analysis_biz_list", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 获取业务指标列表
    dimensions.GetProductAnalysisTargetMetaListResponse GetProductAnalysisTargetMetaList(1: dimensions.GetProductAnalysisTargetMetaListRequest req) (api.get = "/product_analysis/dimensions/get_product_analysis_target_meta_list", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品池状态手动更新接口
    dimensions.UpdatePoolStatusResponse UpdatePoolStatus(1: dimensions.UpdatePoolStatusRequest req) (api.get = "/product_analysis/dimensions/update_pool_status", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 获取异动归因业务数据列表
    dimensions.GetProductAnalysisBizListResponse GetAttributionTreeBizList(1: dimensions.GetProductAnalysisBizListRequest req) (api.get = "/product_analysis/dimensions/get_attribution_tree_biz_list", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 猜喜服饰看板 - 获取权限列表
    dimensions.GetProductAnalysisBizListResponse GetGuessDressBizList(1: dimensions.GetProductAnalysisBizListRequest req) (api.get = "/product_analysis/dimensions/get_guess_dress_bizList", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 获取超值购诊断权限列表
    dimensions.GetProductAnalysisBizListResponse GetGreatValueBuyBizList(1: dimensions.GetProductAnalysisBizListRequest req) (api.get = "/product_analysis/dimensions/get_greate_value_buy_bizList", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 猜喜异动归因
    dimensions.GetProductAnalysisBizListResponse GetGuessAttributionBizList(1: dimensions.GetProductAnalysisBizListRequest req) (api.get = "/product_analysis/dimensions/get_guess_attribution_bizList", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 注册同步
    dimensions.RegisterNeedDumpDimensionResponse RegisterNeedDumpDimension(1: dimensions.RegisterNeedDumpDimensionRequest req) (api.post = "/product_analysis/dimensions/register_need_dump_dimension", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 获取注册需要同步的维度状态
    dimensions.DumpDimensionStatusResponse GetRegisterNeedDumpDimensionStatus(1: dimensions.GetDumpDimensionStatusRequest req) (api.post = "/product_analysis/dimensions/get_dump_dimension_status", api.category = "维度管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 维度管理 - 获取诊断业务线列表
    dimensions.GetProductAnalysisBizListResponse GetDiagnosisBizList(1: dimensions.GetProductAnalysisBizListRequest req) (api.get = "/product_analysis/dimensions/get_diagnosis_biz_list", api.category = "维度管理", agw.preserve_base = "true"),

    /*
        商品分析
     */

    // 商品流量洞察 - 商品分析 - 获取核心指标-总览
    analysis.GetProductAnalysisCoreOverviewResponse GetProductAnalysisCoreOverview(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_core_overview", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取漏斗图的默认结构
    analysis.GetProductAnalysisDefaultFunnelMateResponse GetProductAnalysisDefaultFunnelMate(1: analysis.GetProductAnalysisDefaultFunnelMateRequest req) (api.post = "/product_analysis/analysis/get_default_funnel_mate", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取核心指标-UV类指标点查
    analysis.GetProductAnalysisCoreTargetResponse GetProductAnalysisCoreTarget(1: analysis.GetProductAnalysisCoreTargetRequest req) (api.post = "/product_analysis/analysis/get_core_target", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取核心指标-结论
    analysis.GetProductAnalysisCoreConclusionResponse GetProductAnalysisCoreConclusion(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_core_conclusion", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取核心指标-分层结构
    analysis.GetProductAnalysisCoreHierarchicalResponse GetProductAnalysisCoreHierarchical(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_core_hierarchical", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取多维分析-结论
    analysis.GetProductAnalysisMultiDimConclusionResponse GetProductAnalysisMultiDimConclusion(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_conclusion", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取多维分析-下钻列表
    analysis.GetProductAnalysisMultiDimListResponse GetProductAnalysisMultiDimList(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_list", api.category = "商品分析", agw.preserve_base = "true"),
    //    // 商品流量洞察 - 商品分析 - 获取多维分析-趋势图
    //    analysis.GetProductAnalysisMultiDimTrendResponse GetProductAnalysisMultiDimTrend(1: analysis.GetProductAnalysisBaseRequest req) ( api.post="/product_analysis/analysis/get_multi_dim_trend", api.category="商品分析", agw.preserve_base="true")
    // 商品流量洞察 - 商品分析 - 获取多维分析-商品明细
    analysis.GetProductAnalysisMultiDimProductListResponse GetProductAnalysisMultiDimProductList(1: analysis.GetProductAnalysisMultiDimProductListRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_product_list", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取核心指标-总览-下载
    analysis.GetProductAnalysisDownloadResponse GetProductAnalysisCoreOverviewDownload(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_core_overview_download", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取多维分析-下钻列表-下载
    analysis.GetProductAnalysisDownloadResponse GetProductAnalysisMultiDimListDownload(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_list_download", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取多维分析-商品明细-下载
    analysis.GetProductAnalysisDownloadResponse GetProductAnalysisMultiDimProductListDownload(1: analysis.GetProductAnalysisMultiDimProductListRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_product_list_download", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取商品数
    analysis.GetProductAnalysisProdCntResponse GetProductAnalysisProdCnt(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_product_analysis_prod_cnt", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 拐点洞察
    analysis.InflectionPointInsightResponse InflectionPointInsight(1: analysis.InflectionPointInsightRequest req) (api.post = "/product_analysis/attribution/inflection_point_insight", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 拐点洞察 - 下载
    analysis.InflectionPointInsightDownloadResponse InflectionPointInsightDownload(1: analysis.InflectionPointInsightDownloadRequest req) (api.post = "/product_analysis/attribution/inflection_point_insight_download", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 相似品洞察
    analysis.GetSimilarProductResponse GetSimilarProduct(1: analysis.GetSimilarProductRequest req) (api.post = "/product_analysis/attribution/get_similar_product", api.category = "相似品洞察", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 相似品洞察 - 下载
    analysis.GetSimilarProductDownloadResponse GetSimilarProductDownload(1: analysis.GetSimilarProductDownloadRequest req) (api.post = "/product_analysis/attribution/get_similar_product_download", api.category = "相似品洞察", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 相似品洞察 - 创建货盘
    analysis.CreateGetSimilarProductPoolResponse CreateGetSimilarProductPool(1: analysis.CreateGetSimilarProductPoolRequest req) (api.post = "/product_analysis/attribution/create_get_similar_product_pool", api.category = "相似品洞察", agw.preserve_base = "true"),
    // 添加结论反馈
    analysis.AddFeedBackResponse AddFeedBack(1: analysis.AddFeedBackRequest req) (api.post = "/product_analysis/analysis/add_feed_back", api.category = "模板管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取多维分析 - 获取完整树
    analysis.GetProductAnalysisMultiDimFullListResponse GetProductAnalysisMultiDimFullList(1: analysis.GetProductAnalysisMultiDimFullListRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_full_list", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取多维分析 - 获取趋势图
    analysis.GetProductAnalysisMultiDimTrendResponse GetProductAnalysisMultiDimTrend(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_trend", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取多维分析 - 获取货补数据
    analysis.GetMultiDimExtraTargetListResponse GetProductAnalysisMultiDimProdCostData(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_prod_cost", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 异动归因 - 获取商品详情
    analysis.GetProductDetailResponse GetProductDetail(1: analysis.GetProductDetailRequest req) (api.post = "/product_analysis/analysis/get_product_detail", api.category = "商品分析", agw.preserve_base = "true"),
    // 异动归因-获取商品详情By商品全景
    analysis.GetProductDetailBy360Response GetProductDetailBy360(1: analysis.GetProductDetailRequest req) (api.post = "/product_analysis/analysis/get_product_detail_by360", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 货盘核心指标tab - 趋势分析表格
    analysis.GetProductReportTableResponse GetProductReportTable(1: analysis.GetProductReportTableRequest req) (api.post = "/product_analysis/analysis/get_product_report_table", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 货盘核心指标tab - 趋势分析表格-订阅
    analysis.GetProductAnalysisSubscribeResponse GetProductReportTableSubscribe(1: analysis.GetProductReportTableRequest req) (api.post = "/product_analysis/analysis/get_product_report_table_subscribe", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 货盘核心指标tab - 趋势分析表格-下载
    analysis.GetProductAnalysisDownloadResponse GetProductReportTableDownload(1: analysis.GetProductReportTableRequest req) (api.post = "/product_analysis/attribution/get_product_report_table_download", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取多维分析 - 获取UV指标
    analysis.GetMultiDimExtraTargetListResponse GetProductAnalysisMultiDimUvTargets(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_multi_dim_uv_targets", api.category = "商品分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 商品分析 - 获取核心指标 - UV指标
    analysis.GetProductAnalysisCoreOverviewResponse GetProductAnalysisUVCore(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/analysis/get_uv_core", api.category = "商品分析", agw.preserve_base = "true"),

    /*
        模板管理
     */

    // 商品流量洞察 - 模版管理 - 创建模版
    template.CreateOrUpdateTemplateResponse CreateTemplate(1: template.CreateOrUpdateTemplateRequest req) (api.post = "/product_analysis/template/create_template", api.category = "模板管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 模版管理 - 更新模版
    template.CreateOrUpdateTemplateResponse UpdateTemplate(1: template.CreateOrUpdateTemplateRequest req) (api.post = "/product_analysis/template/update_template", api.category = "模板管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 模版管理 - 删除模版
    template.DeleteTemplateResponse DeleteTemplate(1: template.DeleteTemplateRequest req) (api.post = "/product_analysis/template/delete_template", api.category = "模板管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 模版管理 - 获取模版列表
    template.GetTemplateListResponse GetTemplateList(1: template.GetTemplateListRequest req) (api.post = "/product_analysis/template/get_template_list", api.category = "模板管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 模版管理 - 获取模版详情
    template.GetTemplateDetailResponse GetTemplateDetail(1: template.GetTemplateDetailRequest req) (api.post = "/product_analysis/template/get_template_detail", api.category = "模板管理", agw.preserve_base = "true"),
    // 商品流量洞察 - 模版管理 - 生产模板缓存
    base.BaseResponse GenreateTemplateCache(1: base.EmptyRequest req) (api.post = "/product_analysis/template/generate_template_cache", api.category = "模板管理", agw.preserve_base = "true"),

    /*
      货盘管理
     */

    // 货盘管理 - 查询货盘基本信息
    analysis_pool.QueryAnalysisPoolDetailResp QueryAnalysisPoolDetail(1: analysis_pool.QueryAnalysisPoolDetailReq req) (api.post = "/product_analysis/product_alert/query_analysis_pool_detail", api.category = "分析货盘管理", agw.preserve_base = "true"),
    // 货盘管理 - 查询货盘列表
    analysis_pool.QueryAnalysisPoolListResp QueryAnalysisPool(1: analysis_pool.QueryAnalysisPoolListReq req) (api.post = "/product_analysis/product_alert/query_analysis_pool", api.category = "分析货盘管理", agw.preserve_base = "true"),
    // 货盘管理 - 创建货盘
    analysis_pool.CreateAnalysisPoolResp CreateAnalysisPool(1: analysis_pool.CreateAnalysisPoolReq req) (api.post = "/product_analysis/product_alert/create_analysis_pool", api.category = "分析货盘管理", agw.preserve_base = "true"),
    // 货盘管理 - 更新货盘
    analysis_pool.UpdateAnalysisPoolResp UpdateAnalysisPool(1: analysis_pool.UpdateAnalysisPoolReq req) (api.post = "/product_analysis/product_alert/update_analysis_pool", api.category = "分析货盘管理", agw.preserve_base = "true"),
    // 货盘管理 - 删除货盘
    analysis_pool.DeleteAnalysisPoolResp DeleteAnalysisPool(1: analysis_pool.DeleteAnalysisPoolReq req) (api.post = "/product_analysis/product_alert/delete_analysis_pool", api.category = "分析货盘管理", agw.preserve_base = "true"),
    // 货盘管理 - 创建货盘下游应用记录
    analysis_pool.CreateAnalysisPoolApplicationRecordResp CreateAnalysisPoolApplicationRecord(1: analysis_pool.CreateAnalysisPoolApplicationRecordReq req) (api.post = "/product_analysis/product_alert/create_analysis_pool_application_record", api.category = "分析货盘管理", agw.preserve_base = "true"),
    // dorado 回调函数
    // 获取货盘下游应用hive的任务状态
    dorado_task.GetDoradoTaskRunningCallBackResponse GetDoradoAnalysisPoolApplicationHiveCallBack(1: dorado_task.GetDoradoTaskRunningCallBackRequest req) (api.post = "/product_analysis/product_alert/get_dorado_analysis_pool_application_hive_call_back", api.category = "分析货盘管理", agw.preserve_base = "true"),

    /*
       货盘商品
     */

    // 货盘管理 - 查询某个货盘下全量商品id
    analysis_pool_product.GetAnalysisPoolProductListResp GetAnalysisPoolProductList(1: analysis_pool_product.GetAnalysisPoolProductListReq req) (api.post = "/product_analysis/product_alert/get_pool_product_list", api.category = "分析货盘商品明细", agw.preserve_base = "true"),
    // 货盘商品 - 查询货盘商品列表
    analysis_pool_product.QueryAnalysisPoolProductListResp QueryAnalysisPoolProduct(1: analysis_pool_product.QueryAnalysisPoolProductListReq req) (api.post = "/product_analysis/product_alert/query_analysis_pool_product", api.category = "分析货盘商品明细", agw.preserve_base = "true"),
    // 货盘商品 - 获取可查数据时间范围
    analysis_pool_product.GetDataAvailableDateRangeResp GetDataAvailableDateRange(1: analysis_pool_product.GetDataAvailableDateRangeReq req) (api.post = "/product_analysis/product_alert/get_data_available_date_range", api.category = "分析货盘商品明细", agw.preserve_base = "true"),
    // 货盘商品 - 导出货盘商品列表
    analysis_pool_product.DownloadAnalysisPoolProductListResp DownloadAnalysisPoolProduct(1: analysis_pool_product.DownloadAnalysisPoolProductListReq req) (api.post = "/product_analysis/product_alert/download_analysis_pool_product", api.category = "分析货盘商品明细", agw.preserve_base = "true"),
    // 货盘商品 - 货盘添加/删除商品
    analysis_pool_product.OpAnalysisPoolProductResp OpAnalysisPoolProduct(1: analysis_pool_product.OpAnalysisPoolProductReq req) (api.post = "/product_analysis/product_alert/op_analysis_pool_product", api.category = "分析货盘商品明细", agw.preserve_base = "true"),
    // 货盘商品 - 按维度查询单品数据接口
    analysis_pool_product.GetProductMultiDimResp GetProductMultiDim(1: analysis_pool_product.GetProductMultiDimReq req) (api.post = "/product_analysis/product_alert/get_product_multi_dim", api.category = "分析货盘商品明细", agw.preserve_base = "true"),
    // 货盘商品 - 导出单品按维度拆分数据接口
    analysis_pool_product.DownloadProductMultiDimResp DownloadProductMultiDim(1: analysis_pool_product.DownloadProductMultiDimReq req) (api.post = "/product_analysis/product_alert/download_product_multi_dim", api.category = "分析货盘商品明细", agw.preserve_base = "true"),
    // 货盘商品 - 货盘趋势数据
    analysis_pool_product.GetPoolProductTrendResp GetPoolProductTrend(1: analysis_pool_product.GetPoolProductTrendReq req) (api.category = "分析货盘商品明细"),

    /*
        监控规则管理
     */

    // 货品监控 - 监控规则管理 - 查询货盘下监控规则列表
    analysis_pool_alert_rule.QueryAnalysisPoolAlertRuleListResp QueryAnalysisPoolAlertRuleList(1: analysis_pool_alert_rule.QueryAnalysisPoolAlertRuleListReq req) (api.post = "/product_analysis/product_alert/query_rule_list", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 创建监控规则
    analysis_pool_alert_rule.CreateAnalysisPoolAlertRuleResp CreateAnalysisPoolAlertRule(1: analysis_pool_alert_rule.CreateAnalysisPoolAlertRuleReq req) (api.post = "/product_analysis/product_alert/create_rule", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 查询单个预警任务详情
    analysis_pool_alert_rule.GetAnalysisPoolAlertRuleDetailResp GetAnalysisPoolAlertRuleDetail(1: analysis_pool_alert_rule.GetAnalysisPoolAlertRuleDetailReq req) (api.get = "/product_analysis/product_alert/get_rule_detail", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 获取预警维度列表
    analysis_pool_alert_rule.GetAnalysisPoolAlertDimensionsResp GetAnalysisPoolAlertDimensions(1: analysis_pool_alert_rule.GetAnalysisPoolAlertDimensionsReq req) (api.get = "/product_analysis/product_alert/get_alert_dimensions", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 查询数据源列表
    analysis_pool_alert_rule.LisAnalysisPoolEventTypeResp LisAnalysisPoolEventType(1: analysis_pool_alert_rule.LisAnalysisPoolEventTypeReq req) (api.get = "/product_analysis/product_alert/list_event_type", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 获取数据指标列表
    analysis_pool_alert_rule.GetAnalysisPoolAlertIndicatorsResp GetAnalysisPoolAlertIndicators(1: analysis_pool_alert_rule.GetAnalysisPoolAlertIndicatorsReq req) (api.get = "/product_analysis/product_alert/get_alert_indicators", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 查询所有存在商品状态异常的规则
    analysis_pool_alert_rule.GetRulesWitExceptionProdStatusInfosResp GetRulesWitExceptionProdStatusInfos(1: analysis_pool_alert_rule.GetRulesWitExceptionProdStatusInfosReq req) (api.category = "监控规则管理"),
    // 货品监控 - 监控规则管理 - 删除监控规则
    analysis_pool_alert_rule.DeleteAlertRuleResp DeleteAlertRule(1: analysis_pool_alert_rule.DeleteAlertRuleReq req) (api.post = "/product_analysis/product_alert/delete_rule", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 更新监控规则
    analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleResp UpdateAnalysisPoolAlertRule(1: analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleReq req) (api.post = "/product_analysis/product_alert/update_rule", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 更新监控规则状态
    analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleStatusResp UpdateAnalysisPoolAlertRuleStatus(1: analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleStatusReq req) (api.post = "/product_analysis/product_alert/update_rule_status", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 预警规则转化
    analysis_pool_alert_rule.ConvertToAlertRuleResp ConvertToAlertRule(1: analysis_pool_alert_rule.ConvertToAlertRuleReq req) (api.post = "/product_analysis/product_alert/convert_rule", api.category = "监控规则管理", agw.preserve_base = "true"),
    // 货品监控 - 监控规则管理 - 获取商品状态监控规则枚举
    analysis_pool_alert_rule.GetAlertProdStatusRuleIndicatorResp GetAlertProdStatusRuleIndicator(1: analysis_pool_alert_rule.GetAlertProdStatusRuleIndicatorReq req) (api.post = "/product_analysis/product_alert/get_alert_prod_status_rule_indicator", api.category = "监控规则管理", agw.preserve_base = "true"),

    /*
        活动复盘 start
     */
    activity_review.CreateActivityReviewResponse CreateActivityReview(1: activity_review.CreateActivityReviewRequest req) (api.post = "/product_analysis/activity_review/create_activity_review", api.category = "创建任务", agw.preserve_base = "true"),
    activity_review.GetActivityReviewResultResponse GetActivityReviewResult(1: activity_review.GetActivityReviewResultRequest req) (api.get = "/product_analysis/activity_review/get_activity_review_result", api.category = "活动复盘", agw.preserve_base = "true"),
    activity_review.FreshActivityReviewProgressResponse FreshActivityReview(1: activity_review.FreshActivityReviewProgressRequest req) (api.get = "/product_analysis/activity_review/fresh", api.category = "活动复盘", agw.preserve_base = "true"),
    // 活动复盘-货品供给分析
    activity_review.GetActivityReviewProductSupplyProgressResponse GetActivityReviewProductSupplyProgress(1: activity_review.GetActivityReviewProductSupplyProgressRequest req) (api.post = "/product_analysis/activity_review/get_product_supply_progress", api.category = "活动复盘", agw.preserve_base = "true"),
    // 活动复盘-货品活动期流量分析
    activity_review.GetActivityReviewProductAnalysisResponse GetActivityReviewProductAnalysis(1: activity_review.GetActivityReviewProductAnalysisRequest req) (api.post = "/product_analysis/activity_review/get_product_analysis", api.category = "活动复盘", agw.preserve_base = "true"),
    // 活动复盘-货品流量AA分析
    activity_review.GetActivityReviewProductAAAnalysisResponse GetActivityReviewProductAAAnalysis(1: activity_review.GetActivityReviewProductAnalysisRequest req) (api.post = "/product_analysis/activity_review/get_product_aa_analysis", api.category = "活动复盘", agw.preserve_base = "true"),
    // 活动复盘-货品流量AA分析
    activity_review.GetActivityReviewProductAAAnalysisResponse GetActivityReviewActivityAndNonActivityProductABAnalysis(1: activity_review.GetActivityReviewProductAnalysisRequest req) (api.post = "/product_analysis/activity_review/get_activity_and_non_activity_product_ab_analysis", api.category = "活动复盘", agw.preserve_base = "true"),

    /*
       活动复盘 end
     */

    // 价格力分析-价格力AA对比-核心结论
    price_aa_compare.GetPriceAACoreConclusionResponse GetPriceAACoreConclusion(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_aa/get_core_conclusion", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-核心指标
    price_analysis.GetPriceInsightCoreOverviewResponse GetPriceAACoreOverview(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_aa/get_core_overview", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-核心指标-下载
    analysis.GetProductAnalysisDownloadResponse GetPriceAACoreOverviewDownload(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_aa/get_core_overview_download", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-流量效果达标指标
    price_analysis.GetPriceInsightCoreOverviewResponse GetPriceAAFlowStandardCoreOverview(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_aa/get_flow_standard_core_overview", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-大盘指标
    price_analysis.GetPriceInsightCoreOverviewResponse GetPriceAAMarketCoreOverview(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_aa/get_market_core_overview", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-业务收益分析-瀑布图
    price_aa_compare.GetPriceAABizIncomeTrendResponse GetPriceAABizIncomeTrend(1: price_aa_compare.GetPriceAABaseRequest req) (api.post = "/product_analysis/price_aa/get_biz_income_trend", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-业务收益分析-场域下拆指标卡
    price_analysis.GetPriceInsightCoreOverviewResponse GetPriceAABizIncomeTargetCard(1: price_aa_compare.GetPriceAABaseRequest req) (api.post = "/product_analysis/price_aa/get_biz_income_target_card", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-业务收益分析-场域下拆指标卡
    analysis.GetProductAnalysisDownloadResponse GetPriceAABizIncomeTargetCardDownload(1: price_aa_compare.GetPriceAABaseRequest req) (api.post = "/product_analysis/price_aa/get_biz_income_target_card_download", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-业务收益分析-饼图变化分布
    price_aa_compare.GetPriceAAMultiPieChartResponse GetPriceAABizIncomeDiffDistributed(1: price_aa_compare.GetPriceAABaseRequest req) (api.post = "/product_analysis/price_aa/get_biz_income_diff_distributed", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-流量变化效果-达标指标卡
    price_analysis.GetPriceInsightCoreOverviewResponse GetPriceAAFlowDiffStandardCard(1: price_aa_compare.GetPriceAABaseRequest req) (api.post = "/product_analysis/price_aa/get_flow_diff_standard_card", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-供给优化漏斗
    price_aa_compare.GetPriceAASupplyCntListResponse GetPriceAASupplyCntList(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_aa/get_supply_cnt_list", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 价格力分析-价格力AA对比-供给优化来源
    price_aa_compare.GetPriceAASupplyCntListResponse GetPriceAASupplyDistributed(1: price_aa_compare.GetPriceAASupplyDistributedRequest req) (api.post = "/product_analysis/price_aa/get_supply_distributed", api.category = "价格力AA对比", agw.preserve_base = "true"),
    // 商品流量洞察 - 价格力相关 - 获取多维分析-结论
    analysis.GetProductAnalysisMultiDimConclusionResponse GetPriceAnalysisMultiDimConclusion(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_analysis/get_multi_dim_conclusion", api.category = "价格力分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 价格力相关 - 获取多维分析-下钻列表
    analysis.GetProductAnalysisMultiDimListResponse GetPriceAnalysisMultiDimList(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_analysis/get_multi_dim_list", api.category = "价格力分析", agw.preserve_base = "true"),
    // 商品流量洞察 - 价格力相关 - 获取多维分析-下钻列表-下载
    analysis.GetProductAnalysisDownloadResponse GetPriceAnalysisMultiDimListDownload(1: analysis.GetPriceAnalysisBaseRequest req) (api.post = "/product_analysis/price_analysis/get_multi_dim_list_download", api.category = "价格力分析", agw.preserve_base = "true"),
    // 价格力趋势-元信息
    price_analysis.GetPriceInsightMetaResponse GetPriceInsightMeta(1: price_analysis.GetPriceInsightMetaRequest req) (api.post = "/product_analysis/price_trend/get_price_insight_meta", api.category = "价格力趋势", agw.preserve_base = "true"),
    // 价格力趋势-指标卡
    price_analysis.GetPriceInsightCoreOverviewResponse GetPriceInsightCoreOverview(1: price_analysis.GetPriceInsightCoreOverviewRequest req) (api.post = "/product_analysis/price_trend/get_price_insight_core_overview", api.category = "价格力趋势", agw.preserve_base = "true"),
    // 价格力趋势-分层趋势
    price_analysis.GetPriceInsightHierarchicalTrendResponse GetPriceInsightHierarchicalTrend(1: price_analysis.GetPriceInsightHierarchicalTrendRequest req) (api.post = "/product_analysis/price_trend/get_price_insight_hierarchical_trend", api.category = "价格力趋势", agw.preserve_base = "true"),
    // 价格力趋势-倍比表格
    price_analysis.GetMultipleRatioTableResponse GetMultipleRatioTable(1: price_analysis.GetMultipleRatioTableRequest req) (api.post = "/product_analysis/price_trend/get_multiple_ratio_table", api.category = "价格力趋势", agw.preserve_base = "true"),
    // 价格力趋势-倍比表格下载
    analysis.GetProductAnalysisDownloadResponse GetMultipleRatioTableDownload(1: price_analysis.GetMultipleRatioTableRequest req) (api.post = "/product_analysis/price_trend/get_multiple_ratio_table_download", api.category = "价格力趋势", agw.preserve_base = "true"),
    // 价格力趋势-气泡图
    price_analysis.GetPriceInsightBubbleChartResponse GetPriceInsightBubbleChart(1: price_analysis.GetPriceInsightBubbleChartRequest req) (api.post = "/product_analysis/price_trend/get_price_insight_bubble_chart", api.category = "价格力趋势", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-瀑布图
    price_analysis.GetOrderResponsibilityDistributedResponse GetOrderResponsibilityDistributed(1: price_analysis.GetOrderResponsibilityDistributedRequest req) (api.post = "/product_analysis/price_trend/get_price_responsibility_distributed", api.category = "价格力分工", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-指标卡数据
    price_analysis.GetOrderResponsibilityCoreOverviewResponse GetOrderResponsibilityCoreOverview(1: price_analysis.GetPriceInsightCoreOverviewRequest req) (api.post = "/product_analysis/price_trend/get_price_responsibility_core_overview", api.category = "价格力分工", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-指标卡数据-下载
    analysis.GetProductAnalysisDownloadResponse GetOrderResponsibilityCoreOverviewDownload(1: price_analysis.GetPriceInsightCoreOverviewRequest req) (api.post = "/product_analysis/price_trend/get_price_responsibility_core_overview_download", api.category = "价格力分工", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-变化图
    price_analysis.GetOrderResponsibilityChangeResponse GetOrderResponsibilityChange(1: price_analysis.GetOrderResponsibilityDistributedRequest req) (api.post = "/product_analysis/price_trend/get_price_responsibility_change", api.category = "价格力分工", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-下拆指标卡数据
    price_analysis.GetOrderResponsibilityCoreOverviewResponse GetOrderResponsibilityTargetList(1: price_analysis.GetOrderResponsibilityDistributedRequest req) (api.post = "/product_analysis/price_trend/get_price_responsibility_target_list", api.category = "价格力分工", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-下拆指标卡数据-下载
    analysis.GetProductAnalysisDownloadResponse GetOrderResponsibilityTargetListDownload(1: price_analysis.GetOrderResponsibilityDistributedRequest req) (api.post = "/product_analysis/price_trend/get_price_responsibility_target_list_download", api.category = "价格力分工", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-行业列表
    price_analysis.GetOrderResponsibilityIndustryListResponse GetOrderResponsibilityIndustryList(1: price_analysis.GetPriceInsightCoreOverviewRequest req) (api.post = "/product_analysis/price_trend/get_price_responsibility_industry_list", api.category = "价格力分工", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-行业列表-下载
    analysis.GetProductAnalysisDownloadResponse GetOrderResponsibilityIndustryListDownload(1: price_analysis.GetPriceInsightCoreOverviewRequest req) (api.post = "/product_analysis/price_trend/get_price_responsibility_industry_list_download", api.category = "价格力分工", agw.preserve_base = "true"),
    // 价格力趋势-订单分工-气泡图
    price_analysis.GetPriceInsightBubbleChartResponse GetOrderResponsibilityBubbleChart(1: price_analysis.GetOrderResponsibilityBubbleChartRequest req) (api.post = "/product_analysis/price_trend/get_order_responsibility_bubble_chart", api.category = "价格力分工", agw.preserve_base = "true"),
    // 商品明细 - 跳转位置元信息
    dimensions.GetDimensionListResponse GetProdDetailDimensions(1: price_analysis.GetProdPortraitRequest req) (api.post = "/product_analysis/price_trend/get_prod_detail_dimensions", api.category = "商品明细", agw.preserve_base = "true"),
    // 商品明细 - 商品属性分布饼图
    price_analysis.GetProdPortraitResponse GetProdPortrait(1: price_analysis.GetProdPortraitRequest req) (api.post = "/product_analysis/price_trend/get_prod_portrait", api.category = "商品明细", agw.preserve_base = "true"),
    // 商品明细-商品明细列表
    analysis.GetProductAnalysisMultiDimProductListResponse GetPordDetailList(1: price_analysis.GetPordDetailListRequest req) (api.post = "/product_analysis/price_trend/get_pord_detail_list", api.category = "商品明细", agw.preserve_base = "true"),
    // 商品明细-商品明细列表导出
    analysis.GetProductAnalysisDownloadResponse GetPordDetailListDownload(1: price_analysis.GetPordDetailListRequest req) (api.post = "/product_analysis/price_trend/get_pord_detail_list_download", api.category = "商品明细", agw.preserve_base = "true"),
    // 商品明细-需要回显的筛选性
    price_analysis.GetEchoDisplayDimsResponse GetEchoDisplayDims(1: price_analysis.GetProdPortraitRequest req) (api.post = "/product_analysis/price_trend/get_echo_display_dims", api.category = "商品明细", agw.preserve_base = "true"),

    /*
        货盘诊断
     */

    // 货盘诊断 - 查询诊断判定条件列表
    analysis_pool_diagnosis.GetDiagnosisJudgeConditionListResp GetDiagnosisJudgeConditionList(1: analysis_pool_diagnosis.GetDiagnosisJudgeConditionListReq req) (api.post = "/product_analysis/pool_product_diagnosis/judge_condition_list", api.category = "货盘诊断", agw.preserve_base = "true"),
    // 货盘诊断 - 查询诊断关键因子列表
    analysis_pool_diagnosis.GetDiagnosisFactorListResp GetDiagnosisFactorList(1: analysis_pool_diagnosis.GetDiagnosisFactorListReq req) (api.post = "/product_analysis/pool_product_diagnosis/factor_list", api.category = "货盘诊断", agw.preserve_base = "true"),
    // 货盘诊断 - 查询不同指标分类需要判定数据
    analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeResp GetDiagnosisIndicatorCategoryJudge(1: analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeReq req) (api.post = "/product_analysis/pool_product_diagnosis/indicator_category_judge", api.category = "货盘诊断", agw.preserve_base = "true"),
    // 货盘诊断 - 查询诊断商品指标列表数据
    analysis_pool_diagnosis.QueryDiagnosisProductListResp QueryDiagnosisProductList(1: analysis_pool_diagnosis.QueryDiagnosisProductListReq req) (api.post = "/product_analysis/pool_product_diagnosis/query_diagnosis_product_list", api.category = "货盘诊断", agw.preserve_base = "true"),
    // 货盘诊断 - 查询诊断商品流量空间指标列表数据
    analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListResp QueryDiagnosisFlowSpaceProductList(1: analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListReq req) (api.post = "/product_analysis/pool_product_diagnosis/query_diagnosis_flow_space_product_list", api.category = "货盘诊断", agw.preserve_base = "true"),
    // 商品基本信息
    // 商品流量洞察 - 维度管理 - 获取业务数据列表
    attribution.GetAttributionAnalysisBizListResponse GetAttributionAnalysisBizList(1: attribution.GetAttributionAnalysisBizListRequest req) (api.get = "/product_analysis/dimensions/get_attribution_analysis_biz_list", api.category = "维度管理", agw.preserve_base = "true"),
    // 异动归因-元数据信息
    attribution.GetAttributionTreeMetaListResponse GetAttributionTreeMetaList(1: attribution.GetAttributionTreeMetaListRequest req) (api.post = "/product_analysis/attribution/get_tree_meta_list", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-子模块元信息
    attribution.GetAttributionMetaInfoResponse GetAttributionMetaInfo(1: attribution.GetAttributionCommonBaseRequest req) (api.post = "/product_analysis/attribution/get_attribution_meta_info", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-归因树
    attribution.GetAttributionCoreTreeResponse GetAttributionCoreTree(1: attribution.GetAttributionCommonBaseRequest req) (api.post = "/product_analysis/attribution/get_core_tree", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因 - 归因树多维下钻
    attribution.GetAttributionMultiDimAnalysisResponse GetAttributionMultiDimAnalysis(1: attribution.GetAttributionMultiDimAnalysisRequest req) (api.post = "/product_analysis/attribution/get_attribution_multi_dim_analysis", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-平台原因-实验命中-实验列表
    attribution.GetAttributionABtestListResponse GetAttributionABtestList(1: attribution.GetAttributionABtestListRequest req) (api.post = "/product_analysis/attribution/get_abtest_list", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-平台原因-实验命中-实验列表-下载
    analysis.GetProductAnalysisDownloadResponse GetAttributionABtestListDownload(1: attribution.GetAttributionABtestListRequest req) (api.post = "/product_analysis/attribution/get_abtest_list_download", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-平台原因-实验命中-商品列表
    attribution.GetAttributionABtestListResponse GetAttributionABtestProdList(1: attribution.GetAttributionABtestProdListRequest req) (api.post = "/product_analysis/attribution/get_abtest_prod_list", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-平台原因-实验命中-商品列表-下载
    analysis.GetProductAnalysisDownloadResponse GetAttributionABtestProdListDownload(1: attribution.GetAttributionABtestProdListRequest req) (api.post = "/product_analysis/attribution/get_abtest_prod_list_download", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-商品原因-价格分布
    attribution.GetAttributionProdPriceDistributionResponse GetAttributionProdPriceDistribution(1: attribution.GetAttributionCommonBaseRequest req) (api.post = "/product_analysis/attribution/get_prod_price_distribution", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-获取指标列表接口
    attribution.GetAttributionCommonCoreOverviewResponse GetAttributionCommonCoreOverview(1: attribution.GetAttributionCommonBaseRequest req) (api.post = "/product_analysis/attribution/get_commmon_core_overview", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-猜喜获取指标列表接口
    attribution.GetAttributionCommonCoreOverviewResponse GetGuessCoreOverview(1: attribution.GetAttributionCommonBaseRequest req) (api.post = "/product_analysis/attribution/get_guess_core_overview", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-获取指标列表接口-下载
    analysis.GetProductAnalysisDownloadResponse GetAttributionCommonCoreOverviewDownload(1: attribution.GetAttributionCommonBaseRequest req) (api.post = "/product_analysis/attribution/get_commmon_core_overview_download", api.category = "异动归因", agw.preserve_base = "true"),
    // 猜喜异动归因-下载商家明细接口
    analysis.GetProductAnalysisDownloadResponse ShopDetailDownload(1: attribution.GetAttributionCommonBaseRequest req) (api.post = "/product_analysis/attribution/shop_detail_download", api.category = "异动归因", agw.preserve_base = "true"),
    // 猜喜异动归因-下载商家明细接口
    analysis.GetProductAnalysisDownloadResponse GuessAllTreeDownload(1: aggregate.AllTreeDownloadRequest req) (api.post = "/product_analysis/attribution/all_tree_download", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-获取商品明细接口
    attribution.GetAttributionCommonProdListResponse GetAttributionCommonProdList(1: attribution.GetAttributionCommonPageRequest req) (api.post = "/product_analysis/attribution/get_commmon_prod_list", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-获取商品明细接口-下载
    analysis.GetProductAnalysisDownloadResponse GetAttributionCommonProdListDownload(1: attribution.GetAttributionCommonPageRequest req) (api.post = "/product_analysis/attribution/get_commmon_prod_list_download", api.category = "异动归因", agw.preserve_base = "true"),
    // 异动归因-流量变化分布图
    attribution.GetAttributionFlowChangeResponse GetAttributionFlowChange(1: attribution.GetAttributionCommonBaseRequest req) (api.post = "/product_analysis/attribution/get_flow_change", api.category = "异动归因", agw.preserve_base = "true"),
    // dorado 回调函数
    // 获取商品池dump load hive的任务状态
    dorado_task.GetDoradoTaskRunningCallBackResponse GetDoradoDumpLoadHiveTaskRunningCallBack(1: dorado_task.GetDoradoTaskRunningCallBackRequest req) (api.post = "/product_analysis/dorado_task/dump_load_hive/callback", api.category = "Dorado任务", agw.preserve_base = "true"),

    /*
            订阅
         */

    // 订阅配置 - 获取订阅通用配置
    subscription.GetSubscriptionConfigResponse GetSubscriptionConfig(1: subscription.GetSubscriptionConfigRequest req) (api.post = "/product_analysis/subscription/get_sub_config", api.category = "订阅管理", agw.preserve_base = "true"),
    // 订阅管理 - 用户的所有订阅
    subscription.GetUserSubscriptionListResponse GetUserSubscriptionList(1: subscription.GetUserSubscriptionListRequest req) (api.post = "/product_analysis/subscription/user_subscription/list", api.category = "订阅管理", agw.preserve_base = "true"),
    // 订阅管理 - 推送预览
    subscription.PreviewUserSubscriptionResponse PreviewUserSubscription(1: subscription.PreviewUserSubscriptionRequest req) (api.post = "/product_analysis/subscription/user_subscription/preview", api.category = "订阅管理", agw.preserve_base = "true"),
    // 订阅管理 - 保存/更新/暂停推送
    subscription.SaveUserSubscriptionResponse SaveUserSubscription(1: subscription.SaveUserSubscriptionRequest req) (api.post = "/product_analysis/subscription/user_subscription/save", api.category = "订阅管理", agw.preserve_base = "true"),
    // 订阅管理 - 删除推送
    subscription.DeleteUserSubscriptionResponse DeleteUserSubscription(1: subscription.DeleteUserSubscriptionRequest req) (api.post = "/product_analysis/subscription/user_subscription/delete", api.category = "订阅管理", agw.preserve_base = "true"),
    // 订阅管理 - 保存业务配置信息获取res_id
    subscription.SaveSubscriptionFilterConfigResponse SaveSubscriptionFilterConfig(1: subscription.SaveSubscriptionFilterConfigRequest req) (api.post = "/product_analysis/subscription/user_subscription/save_subscription_config", api.category = "订阅管理", agw.preserve_base = "true"),
    // 订阅管理 - 根据res_id获取配置信息
    subscription.GetSubscriptionFilterConfigResponse GetSubscriptionFilterConfig(1: subscription.GetSubscriptionFilterConfigRequest req) (api.post = "/product_analysis/subscription/user_subscription/get_subscription_config", api.category = "订阅管理", agw.preserve_base = "true"),
    // 量价模型 - 获取实验列表
    volume_price.GetVolumePriceLibraListResponse GetVolumePriceLibraList(1: volume_price.GetVolumePriceLibraListRequest req) (api.post = "/product_analysis/volume_price/get_libra_list", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 漏斗数据
    volume_price.GetVolumePriceMarketFunnelTargetResponse GetVolumePriceMarketFunnelTarget(1: volume_price.VolumePriceCommonRequest req) (api.post = "/product_analysis/volume_price/get_market_funnel_target", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 漏斗数据 - 下载
    analysis.GetProductAnalysisDownloadResponse GetVolumePriceMarketFunnelTargetDownload(1: volume_price.VolumePriceCommonRequest req) (api.post = "/product_analysis/volume_price/get_market_funnel_target_download", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 核心数据汇总
    volume_price.GetVolumePriceLibraVersionListResponse GetVolumePriceLibraVersionList(1: volume_price.VolumePriceCommonRequest req) (api.post = "/product_analysis/volume_price/get_libra_version_list", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 核心数据汇总 - 下载
    analysis.GetProductAnalysisDownloadResponse GetVolumePriceLibraVersionListDownload(1: volume_price.VolumePriceCommonRequest req) (api.post = "/product_analysis/volume_price/get_libra_version_list_download", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 多维分析
    analysis.GetProductAnalysisMultiDimFullListResponse GetVolumePriceMultiDimFullList(1: volume_price.VolumePriceCommonRequest req) (api.post = "/product_analysis/volume_price/get_multi_dim_full_list", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 多维分析 - 下载
    analysis.GetProductAnalysisDownloadResponse GetVolumePriceMultiDimFullListDownload(1: volume_price.VolumePriceCommonRequest req) (api.post = "/product_analysis/volume_price/get_multi_dim_full_list_download", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 获取实验diff分层默认配置
    volume_price.GetVolumePriceVersionHierarchicalConfigResponse GetVolumePriceVersionHierarchicalConfig(1: volume_price.GetVolumePriceVersionHierarchicalConfigRequest req) (api.post = "/product_analysis/volume_price/get_version_hierarchical_config", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 实验diff分层数据
    volume_price.GetVolumePriceLibraVersionListResponse GetVolumePriceVersionHierarchicalList(1: volume_price.GetVolumePriceVersionHierarchicalListRequest req) (api.post = "/product_analysis/volume_price/get_version_hierarchical_list", api.category = "量价模型", agw.preserve_base = "true"),
    // 量价模型 - 实验diff分层数据 - 下载
    analysis.GetProductAnalysisDownloadResponse GetVolumePriceVersionHierarchicalListDownload(1: volume_price.GetVolumePriceVersionHierarchicalListRequest req) (api.post = "/product_analysis/volume_price/get_version_hierarchical_list_download", api.category = "量价模型", agw.preserve_base = "true"),
    // 双边实验-获取实验组合列表
    volume_price.GetExperimentCombinationResponse GetExperimentCombination(1: volume_price.GetReversalExperimentRequest req) (api.post = "/product_analysis/volume_price/get_experiment_combination", api.category = "量价模型", agw.preserve_base = "true"),
    // 双边实验 - 提交实验组合列表
    volume_price.SaveExprObjectResponse SaveExprObject(1: volume_price.SaveExprObjectRequest req) (api.post = "/product_analysis/volume_price/save_expr_object", api.category = "量价模型", agw.preserve_base = "true"),
    // 双边实验-获取核心指标
    volume_price.GetReversalExperimentCoreDataResponse GetReversalExperimentCoreData(1: volume_price.GetReversalExperimentRequest req) (api.post = "/product_analysis/volume_price/get_reversal_experiment_core_data", api.category = "量价模型", agw.preserve_base = "true"),
    // 双边实验-获取核心指标下载
    analysis.GetProductAnalysisDownloadResponse GetReversalExperimentCoreDataDownload(1: volume_price.GetReversalExperimentRequest req) (api.post = "/product_analysis/volume_price/get_reversal_experiment_core_data_download", api.category = "量价模型", agw.preserve_base = "true"),
    // 双边实验-获取实验组合列表
    volume_price.GetReversalExperimentDetailResponse GetReversalExperimentDetail(1: volume_price.GetReversalExperimentRequest req) (api.post = "/product_analysis/volume_price/get_reversal_experiment_detail", api.category = "量价模型", agw.preserve_base = "true"),
    // 双边实验-获取实验组合列表下载
    analysis.GetProductAnalysisDownloadResponse GetReversalExperimentDetailDownload(1: volume_price.GetReversalExperimentRequest req) (api.post = "/product_analysis/volume_price/get_reversal_experiment_detail_download", api.category = "量价模型", agw.preserve_base = "true"),
    // 双边实验-获取双边实验列表
    volume_price.GetVolumePriceBilateralLibraResponse GetVolumePriceBilateralLibra(1: volume_price.GetVolumePriceBilateralLibraRequest req) (api.post = "/product_analysis/volume_price/get_bilateral_libra_list", api.category = "量价模型", agw.preserve_base = "true"),
    // 双边实验-提交实验格子信息
    volume_price.SaveVolumePriceBilateralLibraResponse SaveVolumePriceBilateralLibra(1: volume_price.SaveVolumePriceBilateralLibraRequest req) (api.post = "/product_analysis/volume_price/save_bilateral_libra", api.category = "量价模型", agw.preserve_base = "true"),
    // sku簇洞察
    // sku簇洞察多维分析
    sku_cluster.GetSkuClusterCommonMultiDimFullListResponse GetSkuClusterCommonMultiDimFullList(1: sku_cluster.SkuClusterCommonRequest req) (api.post = "/product_analysis/sku_cluster_service/get_sku_cluster_common_multi_dim_full_list", api.category = "SKU簇洞察", agw.preserve_base = "true"),
    // sku簇洞察指标趋势
    analysis.GetProductAnalysisMultiDimTrendResponse GetSkuClusterCommonMultiDimTrend(1: sku_cluster.SkuClusterCommonRequest req) (api.post = "/product_analysis/sku_cluster_service/get_sku_cluster_common_multi_dim_trend", api.category = "SKU簇洞察", agw.preserve_base = "true"),
    // 簇洞察多维分析下载
    sku_cluster.GetSkuClusterCommonMultiDimFullListDownloadResponse GetSkuClusterCommonMultiDimFullListDownload(1: sku_cluster.SkuClusterCommonRequest req) (api.post = "/product_analysis/sku_cluster_service/get_sku_cluster_common_multi_dim_full_list_download", api.category = "SKU簇洞察", agw.preserve_base = "true"),
    // 核心指标列表
    sku_cluster.GetSkuClusterCommonCoreOverviewResponse GetSkuClusterCommonCoreOverview(1: sku_cluster.SkuClusterCommonRequest req) (api.post = "/product_analysis/sku_cluster_service/get_sku_cluster_common_core_overview", api.category = "SKU簇洞察", agw.preserve_base = "true"),
    // 流量趋势
    sku_cluster.GetSkuClusterFlowTrendResponse GetSkuClusterFlowTrend(1: sku_cluster.SkuClusterCommonRequest req) (api.post = "/product_analysis/sku_cluster_service/get_sku_cluster_flow_trend", api.category = "SKU簇洞察", agw.preserve_base = "true"),
    // 多维分析-稳定性
    sku_cluster.GetSkuClusterStabilityResponse GetSkuClusterStabilityMultiDimFullList(1: sku_cluster.SkuClusterCommonRequest req) (api.post = "/product_analysis/sku_cluster_service/get_sku_cluster_stability_multi_dim_full_list", api.category = "SKU簇洞察", agw.preserve_base = "true"),
    // 多维分析-稳定性-下载
    sku_cluster.GetSkuClusterCommonMultiDimFullListDownloadResponse GetSkuClusterStabilityMultiDimFullListDownload(1: sku_cluster.SkuClusterCommonRequest req) (api.post = "/product_analysis/sku_cluster_service/get_sku_cluster_stability_multi_dim_full_list_download", api.category = "SKU簇洞察", agw.preserve_base = "true"),

    /*
       超值购 ✖️ 搜索
     */

    // 配置下发
    great_value_buy.GetGreatValueBuyDiagnosisConfigResponse GetGreatValueBuyDiagnosisConfig(1: great_value_buy.GetGreatValueBuyDiagnosisConfigDataRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_config", api.category = "超值购专项", agw.preserve_base = "true"),
    // 供给分析
    great_value_buy.GetGreatValueBuySupplyAnalysisResponse GetGreatValueBuySupplyAnalysis(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_supply_analysis", api.category = "超值购专项", agw.preserve_base = "true"),
    //渠道分析
    great_value_buy.GetGreatValueBuyAttributionCoreTreeResponse GetGreatValueBuyAttributionCoreTree(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_attribution_core_tree", api.category = "超值购专项", agw.preserve_base = "true"),
    // 诊断原因下钻
    great_value_buy.GetGreatValueBuyDiagnosisMultiDimensionResponse GetGreatValueBuyDiagnosisMultiDimension(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_multi_dimension", api.category = "超值购专项", agw.preserve_base = "true"),
    // 诊断归因指标列表
    great_value_buy.GetGreatValueBuyDiagnosisCommonCoreOverviewResponse GetGreatValueBuyDiagnosisCommonCoreOverview(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_common_core_overview", api.category = "超值购专项", agw.preserve_base = "true"),
    // 单品诊断-返回sql语句给搜索
    great_value_buy.GetGreatValueBuyProdSQLResponse GetGreatValueBuyProdSQL(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_search_sql", api.category = "超值购专项", agw.preserve_base = "true"),
    // 多维下钻
    great_value_buy.GetGreatValueBuyMultiDimensionResponse GetGreatValueBuyMultiDimensionTable(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_multi_dimension_table", api.category = "超值购专项", agw.preserve_base = "true"),
    // 多维表格趋势分析
    great_value_buy.GetGreatValueBuyMultiDimTrendResponse GetGreatValueBuyMultiDimTrend(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_great_value_buy_multi_dim_trend", api.category = "超值购专项", agw.preserve_base = "true"),
    // 多维下钻 下载
    analysis.GetProductAnalysisDownloadResponse GetGreatValueBuyMultiDimensionTableDownload(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_multi_dimension_table_download", api.category = "超值购专项", agw.preserve_base = "true"),
    // 单品诊断
    great_value_buy.GetGreatValueBuyDiagnosisProductListResponse GetGreatValueBuyDiagnosisProductList(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_product_list", api.category = "超值购专项", agw.preserve_base = "true"),
    // 单品诊断 趋势
    great_value_buy.GetGreatValueBuyDiagnosisProductListTrendResponse GetGreatValueBuyDiagnosisProductListTrend(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_product_list_trend", api.category = "超值购专项", agw.preserve_base = "true"),
    // 单品诊断 下载
    analysis.GetProductAnalysisDownloadResponse GetGreatValueBuyDiagnosisProductListDownload(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_product_list_download", api.category = "超值购专项", agw.preserve_base = "true"),
    //query诊断
    great_value_buy.GetGreatValueBuyQueryAnalysisResponse GetGreatValueBuyDiagnosisQueryList(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_query_list", api.category = "超值购专项", agw.preserve_base = "true"),
    //query搜索词枚举
    great_value_buy.GetGreatValueBuyQuerySearchWordsResponse GetGreatValueBuyDiagnosisQuerySearchWords(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_query_search_words", api.category = "超值购专项", agw.preserve_base = "true"),
    //query诊断 下载
    analysis.GetProductAnalysisDownloadResponse GetGreatValueBuyDiagnosisQueryListDownload(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_query_list_download", api.category = "超值购专项", agw.preserve_base = "true"),
    //query-prod 诊断
    great_value_buy.GetGreatValueBuyQueryProdAnalysisResponse GetGreatValueBuyDiagnosisQueryProdList(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_query_prod_list", api.category = "超值购专项", agw.preserve_base = "true"),
    //query-prod 诊断 下载
    analysis.GetProductAnalysisDownloadResponse GetGreatValueBuyDiagnosisQueryProdListDownload(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_query_prod_list_download", api.category = "超值购专项", agw.preserve_base = "true"),
    // query search_pv trend
    great_value_buy.GetGreatValueBuyDiagnosisQuerySearchCntTrendResponse GetGreatValueBuyDiagnosisQuerySearchCntTrend(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_product_diagnosis_query_search_cnt_trend", api.category = "超值购专项", agw.preserve_base = "true"),
    // 通用诊断结论
    great_value_buy.GetGreatValueBuyCommonConclusionResponse GetGreatValueBuyCommonDiagnosisConclusion(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/great_value_buy/get_common_diagnosis_conclusion", api.category = "超值购专项", agw.preserve_base = "true"),
    // 可优化项列表
    great_value_buy.GetOptimizeItemDetailResponse GetOptimizeItemDetail(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/optimize/get_optimize_item_detail", api.category = "可优化项", agw.preserve_base = "true"),
    // 可优化项商品列表
    great_value_buy.GetOptimizeProductDetailResponse GetOptimizeProductDetail(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/optimize/get_optimize_product_detail", api.category = "可优化项", agw.preserve_base = "true"),
    // 下载
    great_value_buy.GetOptimizeProductDetailDownloadResponse GetOptimizeProductDetailDownload(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/optimize/get_optimize_product_detail_download", api.category = "可优化项", agw.preserve_base = "true"),
    // 可优化项总结
    great_value_buy.GetOptimizeActionInfoResponse GetOptimizeActionInfo(1: great_value_buy.GetGreatValueBuyCommonRequest req) (api.post = "/product_analysis/optimize/get_optimize_action_info", api.category = "可优化项", agw.preserve_base = "true"),
    // 推送卡片
    great_value_buy.SendAttributionReportResponse SendAttributionReport(1: great_value_buy.SendAttributionReportRequest req) (api.post = "/product_analysis/attribution/send_attribution_report", api.category = "归因", agw.preserve_base = "true"),

    /********   猜喜扶持数据洞察   *******/

    // 扶持数据洞察 - 核心指标分析
    analysis.GetProductAnalysisCoreOverviewResponse GetBoostPlanCoreOverview(1: analysis.GetProductAnalysisBaseRequest req) (api.post = "/product_analysis/boost_plan/get_core_overview", api.category = "扶持数据洞察-核心指标补充", agw.preserve_base = "true"),
    // 扶持数据洞察 - 初始化计划对应货盘（不存在则创建）
    analysis.InitPlanAnalysisPoolResponse InitPlanAnalysisPool(1: analysis.InitPlanAnalysisPoolRequest req) (api.post = "/product_analysis/boost_plan/init_analysis_pool", api.category = "扶持数据洞察-初始化计划对应货盘", agw.preserve_base = "true"),

    /** 智能分析 */

    // 新建会话
    ai_analysis.CreateSessionResponse CreateSession(1: ai_analysis.CreateSessionRequest req) (api.post = "/product_analysis/artificial_intelligence/create_session", api.category = "智能分析", agw.preserve_base = "true"),
    // 删除会话
    ai_analysis.DeleteSessionResponse DeleteSession(1: ai_analysis.DeleteSessionRequest req) (api.post = "/product_analysis/artificial_intelligence/delete_session", api.category = "智能分析", agw.preserve_base = "true"),
    // 查看会话信息
    ai_analysis.GetSessionInfoResponse GetSessionInfo(1: ai_analysis.GetSessionInfoRequest req) (api.post = "/product_analysis/artificial_intelligence/get_session_info", api.category = "智能分析", agw.preserve_base = "true"),
    // 查看会话列表
    ai_analysis.GetSessionListResponse GetSessionList(1: ai_analysis.GetSessionListRequest req) (api.post = "/product_analysis/artificial_intelligence/get_session_list", api.category = "智能分析", agw.preserve_base = "true"),
    // 更新会话名称
    ai_analysis.UpdateSessionNameResponse UpdateSessionName(1: ai_analysis.UpdateSessionNameRequest req) (api.post = "/product_analysis/artificial_intelligence/update_session_name", api.category = "智能分析", agw.preserve_base = "true"),
    // 查看消息列表
    ai_analysis.GetSessionMessagesResponse GetSessionMessages(1: ai_analysis.GetSessionMessagesRequest req) (api.post = "/product_analysis/artificial_intelligence/get_session_messages", api.category = "智能分析", agw.preserve_base = "true"),
    // AI 分析（流式）
    ai_analysis.AIStreamResponse AnalysisStream(1: ai_analysis.AIAnalysisRequest req) (streaming.mode = "server", agw.target_streaming_protocol = "sse", api.post = "/product_analysis/artificial_intelligence/analysis_stream", api.category = "智能分析", agw.preserve_base = "true"),
    // AI 分析（非流式），用来测试，生产环境无用
    ai_analysis.AIResponse Analysis(1: ai_analysis.AIAnalysisRequest req) (api.post = "/product_analysis/artificial_intelligence/analysis", api.category = "智能分析", agw.preserve_base = "true"),
    // 反馈
    ai_analysis.FeedbackResponse Feedback(1: ai_analysis.FeedbackRequest req) (api.post = "/product_analysis/artificial_intelligence/feedback", api.category = "智能分析", agw.preserve_base = "true"),
    // 创建数据集
    ai_analysis.CreateDatasetResponse CreateDataset(1: ai_analysis.CreateDatasetRequest req) (api.post = "/product_analysis/artificial_intelligence/create_dataset", api.category = "智能分析", agw.preserve_base = "true"),
    // 获取数据集列表
    ai_analysis.GetDatasetResponse GetDataset(1: ai_analysis.GetDatasetRequest req) (api.post = "/product_analysis/artificial_intelligence/get_dataset", api.category = "智能分析", agw.preserve_base = "true"),
    // 更新数据集
    ai_analysis.UpdateDatasetResponse UpdateDataset(1: ai_analysis.UpdateDatasetRequest req) (api.post = "/product_analysis/artificial_intelligence/update_dataset", api.category = "智能分析", agw.preserve_base = "true"),
    // 删除数据集
    ai_analysis.DeleteDatasetResponse DeleteDataset(1: ai_analysis.DeleteDatasetRequest req) (api.post = "/product_analysis/artificial_intelligence/delete_dataset", api.category = "智能分析", agw.preserve_base = "true"),
    // 创建分析思路
    ai_analysis.CreateAnalysisFrameworkResponse CreateAnalysisFramework(1: ai_analysis.CreateAnalysisFrameworkRequest req) (api.post = "/product_analysis/artificial_intelligence/create_analysis_framework", api.category = "智能分析", agw.preserve_base = "true"),
    // 获取分析思路
    ai_analysis.GetAnalysisFrameworkResponse GetAnalysisFramework(1: ai_analysis.GetAnalysisFrameworkRequest req) (api.post = "/product_analysis/artificial_intelligence/get_analysis_framework", api.category = "智能分析", agw.preserve_base = "true"),
    // 更新分析思路
    ai_analysis.UpdateAnalysisFrameworkResponse UpdateAnalysisFramework(1: ai_analysis.UpdateAnalysisFrameworkRequest req) (api.post = "/product_analysis/artificial_intelligence/update_analysis_framework", api.category = "智能分析", agw.preserve_base = "true"),
    // 删除分析思路
    ai_analysis.DeleteAnalysisFrameworkResponse DeleteAnalysisFramework(1: ai_analysis.DeleteAnalysisFrameworkRequest req) (api.post = "/product_analysis/artificial_intelligence/delete_analysis_framework", api.category = "智能分析", agw.preserve_base = "true"),
    // 创建知识库
    ai_analysis.CreateKnowledgeResponse CreateKnowledge(1: ai_analysis.CreateKnowledgeRequest req) (api.post = "/product_analysis/artificial_intelligence/create_knowledge", api.category = "智能分析", agw.preserve_base = "true"),
    // 获取知识库
    ai_analysis.GetKnowledgeResponse GetKnowledge(1: ai_analysis.GetKnowledgeRequest req) (api.post = "/product_analysis/artificial_intelligence/get_knowledge", api.category = "智能分析", agw.preserve_base = "true"),
    // 更新知识库
    ai_analysis.UpdateKnowledgeResponse UpdateKnowledge(1: ai_analysis.UpdateKnowledgeRequest req) (api.post = "/product_analysis/artificial_intelligence/update_knowledge", api.category = "智能分析", agw.preserve_base = "true"),
    // 删除知识库
    ai_analysis.DeleteKnowledgeResponse DeleteKnowledge(1: ai_analysis.DeleteKnowledgeRequest req) (api.post = "/product_analysis/artificial_intelligence/delete_knowledge", api.category = "智能分析", agw.preserve_base = "true"),
    // AI 结论（流式）
    ai_analysis.AIStreamResponse AIConclusionStream(1: ai_analysis.AIConclusionRequest req) (streaming.mode = "server", agw.target_streaming_protocol = "sse", api.post = "/product_analysis/artificial_intelligence/conclusion_stream", api.category = "智能分析", agw.preserve_base = "true"),
    // AI 结论（非流式）
    ai_analysis.AIResponse AIConclusion(1: ai_analysis.AIConclusionRequest req) (api.post = "/product_analysis/artificial_intelligence/conclusion", api.category = "智能分析", agw.preserve_base = "true"),
    // AI 策略生产（非流式）
    ai_analysis.AIResponse AIStrategyGen(1: ai_strategy.AIStrategyGenRequest req) (api.post = "/product_analysis/artificial_intelligence/strategy_gen", api.category = "智能分析", agw.preserve_base = "true"),
    // AI 实验分析（非流式）
    ai_analysis.AIResponse FlightAnalysis(1: ai_strategy.FlightAnalysisRequest req) (api.post = "/product_analysis/artificial_intelligence/flight_analysis", api.category = "智能分析", agw.preserve_base = "true"),
    // 创建策略
    ai_strategy.CreateStrategyResponse CreateStrategy(1: ai_strategy.CreateStrategyRequest req) (api.post = "/product_analysis/artificial_intelligence/create_strategy", api.category = "智能分析", agw.preserve_base = "true"),
    // 更新策略
    ai_strategy.UpdateStrategyResponse UpdateStrategy(1: ai_strategy.UpdateStrategyRequest req) (api.post = "/product_analysis/artificial_intelligence/update_strategy", api.category = "智能分析", agw.preserve_base = "true"),
    // 获取策略详情
    ai_strategy.GetStrategyDetailResponse GetStrategyDetail(1: ai_strategy.GetStrategyDetailRequest req) (api.post = "/product_analysis/artificial_intelligence/get_strategy_detail", api.category = "智能分析", agw.preserve_base = "true"),
    // 创建策略配置
    ai_strategy.CreateStrategyConfigResponse CreateStrategyConfig(1: ai_strategy.CreateStrategyConfigRequest req) (api.post = "/product_analysis/artificial_intelligence/create_strategy_config", api.category = "智能分析", agw.preserve_base = "true"),
    // 不采用策略配置
    ai_strategy.RejectStrategyConfigResponse RejectStrategyConfig(1: ai_strategy.RejectStrategyConfigRequest req) (api.post = "/product_analysis/artificial_intelligence/reject_strategy_config", api.category = "智能分析", agw.preserve_base = "true"),
    // 创建策略配置和实验的关联关系
    ai_strategy.CreateStrategyConfigFlightRelationResponse CreateStrategyConfigFlightRelation(1: ai_strategy.CreateStrategyConfigFlightRelationRequest req) (api.post = "/product_analysis/artificial_intelligence/create_strategy_relation", api.category = "智能分析", agw.preserve_base = "true"),
    // 将实验分析的结果导入长期记忆
    ai_strategy.ImportFlightConclusionResponse ImportFlightConclusion(1: ai_strategy.ImportFlightConclusionRequest req) (api.post = "/product_analysis/artificial_intelligence/import_flight_conclusion", api.category = "智能分析", agw.preserve_base = "true"),

    /** 飞书 */

    // 校验文档权限
    lark.CheckDocPermissionResponse CheckDocPermission(1: lark.CheckDocPermissionRequest req) (api.get = "/product_analysis/lark/check_doc_permission", api.category = "飞书", agw.preserve_base = "true"),
    // 获取文档内容
    lark.GetDocContentResponse GetDocContent(1: lark.GetDocContentRequest req) (api.get = "/product_analysis/lark/get_doc_content", api.category = "飞书", agw.preserve_base = "true"),

    /** 文件 **/

    // 上传文件
    file.UploadFileResponse UploadFile(1: file.UploadFileRequest req) (api.post = "/product_analysis/file/upload", api.category = "文件", agw.preserve_base = "true"),

    /** 调控平台活动 */

    // 调控平台活动 - 活动管理 - 创建活动
    activity.CreateActivityResponse CreateActivity(1: activity.CreateActivityRequest req) (api.post = "/flow_control/activity/create", api.category = "活动管理", agw.preserve_base = "true"),
    // 调控平台活动 - 活动管理 - 修改活动
    activity.UpdateActivityResponse UpdateActivity(1: activity.UpdateActivityRequest req) (api.post = "/flow_control/activity/update", api.category = "活动管理", agw.preserve_base = "true"),
    // 调控平台活动 - 活动管理 - 获取活动列表
    activity.GetActivityListResponse GetActivityList(1: activity.GetActivityListRequest req) (api.post = "/flow_control/activity/get", api.category = "活动管理", agw.preserve_base = "true"),
    // 调控平台活动 - 活动管理 - 活动下线
    activity.TakeOfflineActivityResponse TakeOfflineActivity(1: activity.TakeOfflineActivityRequest req) (api.post = "/flow_control/activity/take_offline", api.category = "活动管理", agw.preserve_base = "true"),
    // 活动审核接口回调
    activity.ApprovalCallbackResponse ActivityApprovalCallback(1: activity.ApprovalCallbackRequest req) (api.post = "/flow_control/activity/activity_approval/callback", api.category = "活动管理", agw.preserve_base = "true"),
    // 活动审核接口
    activity.ApprovalActivityResp ApprovalActivity(1: activity.ApprovalActivityReq req) (api.post = "/flow_control/activity/approval_activity", api.category = "活动管理", agw.preserve_base = "true"),

    /*
        货盘复盘
    */

    // 创建或新增策略
    prod_review.CreateAndUpdateProdReviewStrategyResponse CreateAndUpdateProdReviewStrategy(1: prod_review.CreateAndUpdateProdReviewStrategyRequest req) (api.post = "/product_analysis/prod_review/create_and_update_strategy", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 策略列表
    prod_review.GetProdReviewStrategyListResponse GetProdReviewStrategyList(1: prod_review.GetProdReviewStrategyListRequest req) (api.post = "/product_analysis/prod_review/get_strategy_list", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 策略类型获取
    prod_review.GetProdReviewStrategyTypeListResponse GetProdReviewStrategyTypeList(1: prod_review.GetProdReviewStrategyTypeListRequest req) (api.post = "/product_analysis/prod_review/get_strategy_type_list", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 创建或新增业务专项，或业务专项货盘
    prod_review.CreateAndUpdateProdReviewBizProjectResponse CreateAndUpdateProdReviewBizProject(1: prod_review.CreateAndUpdateProdReviewBizProjectRequest req) (api.post = "/product_analysis/prod_review/create_and_update_biz_project", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 业务专项，业务专项货盘
    prod_review.GetProdReviewBizProjectListResponse GetProdReviewBizProjectList(1: prod_review.GetProdReviewBizProjectListRequest req) (api.post = "/product_analysis/prod_review/get_biz_project_list", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 创建或新增复盘报告
    prod_review.CreateAndUpdateProdReviewReportResponse CreateAndUpdateProdReviewReport(1: prod_review.CreateAndUpdateProdReviewReportRequest req) (api.post = "/product_analysis/prod_review/create_and_update_report", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 报告列表
    prod_review.GetProdReviewReportListResponse GetProdReviewReportList(1: prod_review.GetProdReviewReportListRequest req) (api.post = "/product_analysis/prod_review/get_report_list", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 获取实验信息
    prod_review.GetLibraInfoResponse GetLibraInfo(1: prod_review.GetLibraInfoRequest req) (api.post = "/product_analysis/prod_review/get_libra_info", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 商品价值划分
    common_response.CommonAnalysisItemDataResponse ProductValueClassify(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/product_value_classify", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 商品四象限分析
    common_response.CommonAnalysisItemDataResponse ProductFourQuadrantAnalysis(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/product_four_quadrant_analysis", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 气泡图，供给分析、流量分析
    common_response.CommonAnalysisUnifiedDataResponse GetBubbleChart(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/get_bubble_chart", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 气泡图下载
    common_response.CommonAnalysisDownloadResponse BubbleChartDownload(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/bubble_chart_download", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 流量分布
    common_response.CommonAnalysisMultiDimTableResponse GetFlowDistribution(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/get_flow_distribution", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 多维表
    common_response.CommonAnalysisMultiDimTableResponse CommonAnalysisMultiDimTable(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/multi_dim_table", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 多维表下载
    common_response.CommonAnalysisDownloadResponse CommonAnalysisMultiDimTableDownload(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/multi_dim_table_download", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 诊断结论-指标模式
    common_response.CommonAnalysisItemDataResponse CommonDiagnosisConclusionByTarget(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/common_diagnosis_conclusion_by_target", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 诊断结论-结论模式
    common_response.GetDiagnosisConclusionResponse CommonDiagnosisConclusion(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/common_diagnosis_conclusion", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 目标多维表
    common_response.CommonAnalysisTargetTableResponse CommonAnalysisTargetTable(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/analysis_target", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 获取指标
    common_response.CommonAnalysisItemDataResponse CommonAnalysisItemData(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/prod_review/analysis_item_data", api.category = "货盘复盘", agw.preserve_base = "true"),
    // 获取业务线配置
    common_response.BizConfigResponse GetBizConfig(1: common_request.BizConfigRequest req) (api.post = "/product_analysis/prod_review/get_biz_config", api.category = "货盘复盘", agw.preserve_base = "true"),
    common_response.CommonMultiDimTrendResponse CommonMultiDimTrend(1: common_request.CommonAnalysisRequest req) (api.post = "/product_analysis/common/multi_dim_trend", api.category = "通用功能", agw.preserve_base = "true"),

    /* 特征圈品 */

    // 获取任务管理配置
    product_select.GetProductSelectAdministratorConfigResponse GetProductSelectAdministratorConfig(1: product_select.GetProductSelectAdministratorConfigRequest req) (api.post = "/product_analysis/product_select/get_administrator_config", api.category = "货盘圈选", agw.preserve_base = "true"),
    // 创建或更新特征圈品任务
    product_select.CreateAndUpdateProductSelectTaskResponse CreateAndUpdateProductSelectTask(1: product_select.CreateAndUpdateProductSelectTaskRequest req) (api.post = "/product_analysis/product_select/create_and_update_task", api.category = "货盘圈选", agw.preserve_base = "true"),
    // 任务列表
    product_select.GetProductSelectTaskListResponse GetProductSelectTaskList(1: product_select.GetProductSelectTaskListRequest req) (api.post = "/product_analysis/product_select/get_task_list", api.category = "货盘圈选", agw.preserve_base = "true"),
    // 任务详情
    product_select.GetProductSelectTaskDetailResponse GetProductSelectTaskDetail(1: product_select.GetProductSelectTaskDetailRequest req) (api.post = "/product_analysis/product_select/get_task_detail", api.category = "货盘圈选", agw.preserve_base = "true"),
    // 任务详情商品列表
    product_select.GetProdDetailListResponse GetProdDetailList(1: product_select.GetProdDetailListRequest req) (api.post = "/product_analysis/product_select/get_prod_detail_list", api.category = "货盘圈选", agw.preserve_base = "true"),
    // 数据预览
    product_select.GetProductSelectTaskPreviewResultResponse GetProductSelectTaskPreviewResult(1: product_select.GetProductSelectTaskPreviewResultRequest req) (api.post = "/product_analysis/product_select/get_task_preview_result", api.category = "货盘圈选", agw.preserve_base = "true"),
    // 获取用户权限
    product_select.GetUserPrivilegeResponse GetUserPrivilege(1: product_select.GetUserPrivilegeRequest req) (api.post = "/product_analysis/product_select/get_user_privilege", api.category = "货盘圈选", agw.preserve_base = "true"),
    test.TestResponse Test(1: test.TestRequest req) (api.post = "/product_analysis/test_api", api.category = "", agw.preserve_base = "true"),
}