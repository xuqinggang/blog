namespace py subscription
namespace go subscription

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../analysis/analysis.thrift"
include "../basic_info.thrift"


// ==============================    常量   ===============================
// 订阅的业务线ID
enum BusinessId {
    ProductAnalysis = 1000 // 商品流量洞察
}

// 订阅推送的内容类型
enum ContentType {
    ScreenShot = 1 // 截图
    Table      = 2 // 图表
}

enum Status {
    RUNING = 1 // 进行中
    PAUSE  = 2 // 暂停
    DELETE = -1  // 删除
}

enum DateType {
    Day   = 0 // 日
    Week  = 1 // 周
    Month = 2 // 月
    Disposable = 3 // 一次性
}


// ==============================    常量   ===============================


// ==============================    通用结构体   ===============================
struct SubscriptionConfig {
    1:  i64                     id           // 配置ID
    2:  BusinessId              business_id  // 业务线ID, 1000-商品流量洞察
    3:  string                  page_name    // 订阅内容所属页面
    4:  string                  module_name  // 订阅内容所属页面模块
    6:  list<ContentType>       content_type // 该模块支持的订阅类型（json数组)：1:截图，2:图表
    7:  map<ContentType,string> template     // 订阅的飞书内容模板
    8:  ExtraInfo               extra_info   // 订阅配置的补充信息
    9:  string                  op_user_id   // 创建配置的员工工号
    10: string                  op_user_name // 创建配置的员工姓名
    12: i64                     create_time  // 创建时间
    13: i64                     update_time  // 最后更新时间
}

struct ExtraInfo {
    1:   ScreenShotConf subscreen     // 截图的补充配置
}

// 网页截图
struct ScreenShotConf {
    1: string               url               // 目标页面地址
    2: string               cookie            // 域名下阈值的cookie，a）不同权限用户能看到的页面不一样；b）不同站点的cookie透传需要定制
    3: i64                  page_width        // 浏览器页面宽度
    4: i64                  page_height       // 浏览器页面高度
    5: double               page_scale        // 页面缩放，用于展示完整的板块
    6: list<ScreenShotTask> screen_shot_tasks // 页面截图任务，一个页面可以有多个截图
    7: optional list<string> ocr_words        // 截图时需要用来ORC检测的内容
}

struct ScreenShotTask {
    1: list<UserAction> actions             // 页面操作，一次截图前可能需要多次操作，点击、填写输入框等
    2: string           after_wait_sel      // 等待元素渲染就绪
    3: string           after_wait_sel_type // 等待元素选择器类型：by_id, by_jspath, by_query等
    4: i64              sleep_time          // 等待时间
    5: string           target_sel          // 要截图的目标元素
    6: string           target_sel_type     // 选择器类型：by_id, by_jspath, by_query等
    7: string           img_name            // 截图的图片名称，作为key返回（用户输入）
}

// 页面上单次操作的属性
struct UserAction {
    1:  string      wait_sel      // 等待元素渲染就绪
    2:  string      wait_sel_type // 等待元素选择器类型：by_id, by_jspath, by_query等
    3:  string      action_type   // 行为：click（点击），输入（input），改写value（sendKeys）
    4:  ClickAction click_action  // 点击
    30: i64         sleep_time    // 可选等待时间，单位秒
}
struct ClickAction {
    1: string sel      // 目标元素
    2: string sel_type // 选择器类型：by_id（id选择器）, by_jspath, by_query等
}

// 用户的订阅列表
struct Target {
    1: string id    // 飞书群的ocean_id或者是用户的员工号
    2: string name  // 名字（个人名字/群名）
    3: string email // 个人email
}

// 用户订阅的参数
struct SubscriptionParam {
    1: ScreenShotParam screen_param      // 截图参数

}
struct ScreenShotParam {
    1: optional map<string,string> url_params       // 用于拼接到URL上的参数
    2: optional string             target_name      // 分析对象, 如果是货盘分析则传入货盘名，如果是单品分析，则传入商品ID
}

struct PushTime {
    1: required DateType dateType  // 0:每天 1:每周 2:每月 3:一次性
    2: optional i32 DayOfWeek     // 星期几(1~7)，当interval_unit=1时取该值。
    3: optional i32 DayOfMonth    // 几号(1~31)，当interval_unit=2时取该值，每月最后一天用-1表示，若当月无31号则不推送
    4: required i32 Hour          // 触发当天的小时
    5: required i32 Minute        // 触发当天的分钟
    7: optional map<string, string> url_params // 实际推送时需要拼接到截图的URL上的参数(截图用)
//    6: required i32 subscribeType // 订阅类型 1日常推送 2预警
//    7: optional i64 pushStartTime // 推送开始日期
}

struct UserSubscription {
    1:   i64                 id                // 用户订阅的ID [测试/创建推送不填]
    2:   i64                 config_id         // 订阅配置ID
    3:   BusinessId          business_id       // 业务线ID, 1000-商品流量洞察
    4:   dimensions.BizType  biz_type          // 业务线
    5:   string              subscribe_name    // 用户自定义的订阅名,用于作用在飞书卡片标题
    6:   list<Target> target_group      // 触达的群列表
    7:   list<Target> target_user       // 触达的用户列表
    8:   list<PushTime>      push_time         // 推送的时间列表 [测试推送可不填]
    9:   ContentType         content_type      // 订阅推动的消息类型, 是配置表的子集, 1:截图, 2:图表
    10:  Status              status            // 订阅状态 [测试推送可不填]
    11:  list<Target> owner_email       // 负责人邮箱列表 [测试推送可不填]
    12:  string              creator           // 创建人邮箱 [测试/创建推送可不填]
    13:  i64                 create_time       // 创建时间 [测试/创建推送可不填]
    14:  string              updater           // 最后修改人 [测试/创建推送可不填]
    15:  i64                 update_time       // 最后更新时间 [测试/创建推送可不填]
    16:  string              business_key      // 业务唯一标识 [测试/创建推送可不填]
    17:  SubscriptionParam   param             // 订阅的动态参数
    18:  optional map<DateType,i64>        sub_center_id     // 订阅中心ID [仅返回]

    200: i64                 next_execute_time // 下一次执行的时间 [仅返回]
}

// ==============================    通用结构体   =================================


// ==============================    请求 & 返回    ===============================
// 获取订阅通用配置
struct GetSubscriptionConfigRequest {
    1:   optional string page_name    // 订阅页面(页面订阅时需要传入)
    2:   optional string module_name  // 订阅模块(页面订阅时需要传入)

    253: optional i32    page=1       // 分页的页面,默认第一页
    254: optional i32    page_size=10 // 每页个数,  默认10条
    255: optional base.Base Base
}

struct GetSubscriptionConfigData {
    1: list<SubscriptionConfig> config_list // 配置列表
    2: i64                      total       // 总数
}
struct GetSubscriptionConfigResponse {
    1: required i32                       code // 状态码 0: 成功
    2: required string                    msg  // 出错提示消息
    3: required GetSubscriptionConfigData data // 返回结果

    255: base.BaseResp BaseResp
}

// 用户的所有订阅列表
struct GetUserSubscriptionListRequest {
    1:   optional string page_name    // 订阅页面（模糊搜索）
    2:   optional string module_name  // 订阅模块（模糊搜索）
    3:   optional string sub_name     // 订阅名（模糊搜索）
    4:   optional Status status       // 订阅状态
    5:   optional i32 config_id       // 配置id

    251: optional string orderBy      // 排序字段,默认ID
    252: optional bool   isAsc=false  // 是否升序，默认降序
    253: optional i32    page=1       // 分页的页面,默认第一页
    254: optional i32    page_size=10 // 每页个数,  默认10条
    255: optional base.Base Base
}

struct GetUserSubscriptionListData {
    1: list<UserSubscription> records // 订阅列表
    2: i64                    total   // 总数
}

struct GetUserSubscriptionListResponse {
    1: required i32                         code // 状态码 0: 成功
    2: required string                      msg  // 出错提示消息
    3: required GetUserSubscriptionListData data // 返回结果

    255: base.BaseResp BaseResp
}

// 推送预览
struct PreviewUserSubscriptionRequest {
    1: required UserSubscription task
    255: optional base.Base Base
}

struct PreviewUserSubscriptionResponse {
    1: required i32    code // 状态码 0: 成功
    2: required string msg  // 出错提示消息
    3: required string data // 返回结果

    255: base.BaseResp BaseResp
}

// 保存/更新/暂停推送
struct SaveUserSubscriptionRequest {
    1: required UserSubscription task
    255: optional base.Base Base
}

struct SaveUserSubscriptionResponse {
    1: required i32              code // 状态码 0: 成功
    2: required string           msg  // 出错提示消息
    3: optional UserSubscription data // 返回结果

    255: base.BaseResp BaseResp
}

// 删除
struct DeleteUserSubscriptionRequest {
    1: required i64 sub_id // 待删除的订阅ID
    255: optional base.Base Base
}

struct DeleteUserSubscriptionResponse {
    1: required i32    code // 状态码 0: 成功
    2: required string msg  // 出错提示消息
    3: optional string data

    255: base.BaseResp BaseResp
}
// ==============================    请求 & 返回    ===============================


// 保存/获取 自定义配置信息
struct SaveSubscriptionFilterConfigRequest {
    1: required i64 config_id // 待删除的订阅ID
    2: optional map<string, string> config_filter_map // 业务自定义的配置信息
    255: optional base.Base Base
}
struct SaveSubscriptionFilterConfigResponse {
    1: required i32              code // 状态码 0: 成功
    2: required string           msg  // 出错提示消息
    3: required string res_id // 返回结果
    255: base.BaseResp BaseResp
}
// 保存/获取 自定义配置信息
struct GetSubscriptionFilterConfigRequest {
    1: required string res_id // res_id
    255: optional base.Base Base
}
struct GetSubscriptionFilterConfigResponse {
    1: required i32              code // 状态码 0: 成功
    2: required string           msg  // 出错提示消息
    3: required SubscriptionFilterConfigItem data // 返回结果
    255: base.BaseResp BaseResp
}
struct SubscriptionFilterConfigItem {
    1: required i64 config_id
    2: optional map<string, string> config_filter_map // 业务自定义的配置信息
}