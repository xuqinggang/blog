namespace py sku_cluster
namespace go sku_cluster

include "../base.thrift"
include "../analysis/analysis.thrift"
include "../dimensions/dimensions.thrift"
include "../basic_info.thrift"

enum StabilityType  {  // 稳定型周期
    T_1 = 1
    T_7 = 2
    T_14 = 3
    T_30 = 4
}

enum FlowLayerType {   // 流量分层逻辑
    GoodPrice = 1
    VolumePrice = 2
    BigLink = 3
}

enum FlowLayerTarget {   // 流量分层逻辑
    ShowPv = 1
    Gmv = 2
    OderCnt = 3
}

struct StabilityParam {
    1: optional list<StabilityType> stat_cycles  // 查询，统计周期
    2: optional string stat_date // 统计日期
}

struct FlowParam{
    1: optional FlowLayerType flow_layer, // 流量分层逻辑
    2: optional FlowLayerTarget flow_layer_target, // 流量分层逻辑
}

struct SkuClusterCommonRequest {
    1: required dimensions.ProductAnalysisBaseStruct base_req,
    2: optional bool need_cycle, // 是否环比
    3: optional bool need_trend, // 是否需要趋势
    4: optional StabilityParam stability_param, // 稳定性参数
    5: optional FlowParam flow_param, // 流量分层参数


    255: required base.Base Base,
}

// 多维分析通用接口

struct GetSkuClusterCommonTargetGroup {  //  指标组
    1: string group_name,  // 覆盖sku/商品/商家总量-去重、对SKU覆盖情况等指标组名称
    2: list<analysis.TargetCardEntity> target_list
}

struct GetSkuClusterCommonMultiDimRow {
    1: string dimension_name
    2: list<GetSkuClusterCommonTargetGroup> full_group_list  // 整体
    3: list<GetSkuClusterCommonMultiDimRow> child_rows // 下钻维度
    4: string enum_value
}

struct GetSkuClusterCommonMultiDimData {
    1: GetSkuClusterCommonMultiDimRow full_product_list         // 置顶行，全部商品
    2: GetSkuClusterCommonMultiDimRow full_cluster_list         // 置顶行，全部簇
    3: list<GetSkuClusterCommonMultiDimRow> row_list            // 多维下钻分析
}

struct GetSkuClusterCommonMultiDimFullListResponse{   //
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: required GetSkuClusterCommonMultiDimData data     // 返回结果
    255: base.BaseResp BaseResp
}

struct GetSkuClusterCommonMultiDimFullListDownloadResponse{   //
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: bool data // 是否发起下载任务成功
    255: base.BaseResp BaseResp
}


struct GetSkuClusterStabilityPeriodCol {
    1: string period_name,  //  T-1、T-7、T-14、T-30 等
    2: required GetSkuClusterCommonMultiDimData data     // 返回结果
}

struct GetSkuClusterStabilityData {
    1: list<GetSkuClusterStabilityPeriodCol> col_list
}

struct GetSkuClusterStabilityResponse{   //       重点货品池覆盖率
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: required GetSkuClusterStabilityData data     // 返回结果
    255: base.BaseResp BaseResp
}




// 流量分发

struct GetSkuClusterFlowDimension{
    1: string dimension_name,
    2: list<analysis.TargetCardEntity> target_list
}
struct GetSkuClusterFlowTrendData{
    1: list<GetSkuClusterFlowDimension> dimension_trends
}

struct GetSkuClusterFlowTrendResponse {  // 流量趋势
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: required  GetSkuClusterFlowTrendData data     // 返回结果
    255: base.BaseResp BaseResp
}

// 指标详情
struct GetSkuClusterCommonCoreOverviewData {
    1: list<analysis.TargetCardEntity> target_list
}

struct GetSkuClusterCommonCoreOverviewResponse{
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: required GetSkuClusterCommonCoreOverviewData data     // 返回结果

    255: base.BaseResp BaseResp
}