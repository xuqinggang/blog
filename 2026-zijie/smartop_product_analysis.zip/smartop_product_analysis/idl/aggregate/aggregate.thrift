namespace py aggregate
namespace go aggregate

include "../base.thrift"
include "../great_value_buy/great_value_buy.thrift"
include "../attribution/attribution.thrift"

struct AllTreeDownloadRequest {
    1: great_value_buy.GetGreatValueBuyCommonRequest  tree_req                    // 归因树入参
    2: attribution.GetAttributionCommonBaseRequest diagnosis_req                  // 命题诊断入参

    255: optional base.Base Base
}