namespace py activity
namespace go activity

include "../base.thrift"
include "../flow/flow.thrift"

struct CreateActivityRequest{
    1: required ActivityEntity activity_entity    // 活动信息

    254: optional string operator_id                   // 操作人id
    255: optional base.Base Base
}

struct CreateActivityResponse{
    1: i32 code                            // 状态码 0: 成功, -1: 代表失败
    2: string msg                          // 出错提示消息

    255: optional base.BaseResp BaseResp
}

struct UpdateActivityRequest{
    1: required string activity_id                     // 活动id
    2: required ActivityEntity activity_entity         // 活动实体信息

    254: optional string operator_id                   // 操作人id
    255: optional base.Base Base
}

struct UpdateActivityResponse{
    1: i32 code                            // 状态码 0: 成功, -1: 代表失败
    2: string msg                          // 出错提示消息
    255: optional base.BaseResp BaseResp
}

struct GetActivityListRequest {
    1: optional list<string> activity_id_list           // 活动id
    2: optional string activity_name                    // 活动名称
    3: optional list<ActivityStatus> activity_status    // 活动状态
    4: optional list<string> activity_creator_list      // 活动创建人
    5: optional list<string> activity_helper_list       // 活动协作人

    11: i32 limit                                       // 记录数量
    12: i64 cursor                                      // 游标（活动id）
    13: bool need_detail                                // 是否需要活动详情

    255: optional base.Base Base
}

struct GetActivityListResponse {
    1: i32 code                            // 状态码 0: 成功, -1: 代表失败
    2: string msg                          // 出错提示消息
    3: GetActivityListData data            // 返回结果

    255: optional base.BaseResp BaseResp
}

struct GetActivityListData {
    1: list<ActivityEntity> activity_entity_list    // 活动实体信息
    2: PermissionInfo permission_info              // 权限信息
    3: i64 total_count                             // 总数量
}

struct TakeOfflineActivityRequest {
    1: required string activity_id                     // 活动id

    254: optional string operator_id                   // 操作人id
    255: optional base.Base Base
}

struct TakeOfflineActivityResponse {
    1: i32 code                            // 状态码 0: 成功, -1: 代表失败
    2: string msg                          // 出错提示消息

    255: optional base.BaseResp BaseResp
}

struct ApprovalCallbackRequest {
    1: optional ApprovalCallbackEvent event, // 审批事件

    200: optional string challenge, // 仅用于修改回调地址后的接口可用性验证

    255: base.Base Base,
}

struct ApprovalCallbackResponse {
    200: optional string challenge, // 仅用于修改回调地址后的接口可用性验证，需要原样返回request.challenge

    255: optional base.BaseResp BaseResp
}

struct ApprovalCallbackEvent {
    1: optional string type, // 固定字段：approval_instance
    2: optional string approval_code, // 审批定义code
    3: optional string instance_code, // 审批实例code
    4: optional string status, // 实例状态
    5: optional string uuid, // 审批实例自定义唯一ID，接口创建审批时候传入
}

struct ApprovalActivityReq {
    1: string activity_id                       // 活动ID
    2: string status                            // APPROVED 审核通过、REJECTED 审核拒绝
    3: string comment                           // 审批意见

    255: optional base.Base    Base
}

struct ApprovalActivityResp {

    255: optional base.BaseResp  BaseResp
}

struct ActivityEntity {
    1: string activity_id                           // 活动id
    2: string activity_name                         // 活动名称
    3: ActivityTarget activity_target               // 活动目标
    4: string activity_description                  // 活动描述
    5: ActivityStatus activity_status               // 活动状态
    6: string activity_creator_id                   // 活动创建人
    7: list<string> activity_helper_id_list         // 活动协作人

    11: i64 activity_start_timestamp                // 活动开始时间
    12: i64 activity_end_timestamp                  // 活动结束时间
    13: i64 activity_create_timestamp               // 活动创建时间

    21: list<flow.FlowPlan> flow_plan_list          // 活动关联的投放计划
    22: list<flow.EquitySignal> flow_signal_list    // 活动关联的信号
    23: list<flow.LibraInfo> flow_libra_list        // 活动关联的libra

    31: PermissionInfo activity_permission_info      // 活动操作权限
}

enum ActivityStatus {
    Unknown = 0,

    Active = 20,        // 进行态
    Wait = 22,          // 待生效态

    Offline = 30,       // 下线态

    Reviewing = 40,     // 审核中
}

enum ActivityTarget {
    Unknown = 0,

    XTabGMV = 1,       // 新入口GMV
}

struct PermissionInfo {
    1: bool has_write_permission         // 有写操作权限
    2: bool has_edit_permission          // 有编辑操作权限
}