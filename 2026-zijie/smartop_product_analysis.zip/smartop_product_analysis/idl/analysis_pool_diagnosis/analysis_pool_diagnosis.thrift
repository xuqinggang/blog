namespace py analysis_pool_diagnosis
namespace go analysis_pool_diagnosis

include "../base.thrift"

// 货盘诊断通用结构体
struct AnalysisPoolDiagnosisBaseStruct {     
    1: required string  start_date          // 统计起始时间，格式为 yyyy-MM-dd
    2: required string  end_date            // 统计结束时间，格式为 yyyy-MM-dd
    3: optional string  pool_id             // 货盘id
    4: optional string  compare_start_date  // 对比起始时间，格式为 yyyy-MM-dd
    5: optional string  compare_end_date    // 对比结束时间，格式为 yyyy-MM-dd
    6: optional string  app                 // app
    7: optional string  industry_id         // 行业大类id
    8: optional string  leaf_cate_id        // 叶子类目id
    9: optional string  prod_id_list        // 商品id列表
}

struct DiagnosisSort {
    1: optional string  field   // 排序字段
    2: optional bool    is_asc  // 是否升序
}

struct DiagnosisFactor {
    1: optional string  factor_key   // 关键因子key
    2: optional string  factor_name  // 关键因子名称
}

struct DiagnosisIndicator {
    1: optional string        key               // 指标key
    2: optional string        name              // 指标名称
    3: optional string        judge_logic       // 判定逻辑 status_judge状态值判定 threshold_lt_compare阈值判定(lt,le,gt,ge,eq) constant_lt_compare常量值判定(lt,le,gt,ge,eq)
    4: optional i64           priority          // 优先级
    5: optional string        group             // 所属指标组名称
    6: optional i64           compare_constant  // 用于比较的常量
    7: optional list<string>  not_match_status  // 不符合判定的状态列表
    8: optional string        table_name        // 字段所属表名
    
}

struct DiagnosisJudgeCondition {
    1: optional string  judge_key                         // 判定条件key
    2: optional string  judge_name                        // 判定条件名称
    3: optional string  judge_prod_count_key_affix        // 判定商品数量取值字段后缀
    4: optional string  scene                             // 流量场景 搜索search、猜喜guessyoulike
    5: optional string  judge_key_indicator_value_prefix  // 判定条件对应指标取值字段前缀
    6: optional string  judge_prod_id_key_affix           // 判定商品id列表字段后缀
}

struct DiagnosisIndicatorJudgeConditionRelation {
    1: optional DiagnosisIndicator  indicator                     // 指标key
    2: optional string              judge_logic                   // 判定逻辑 threshold_compare阈值对比、status_judge状态判定
    3: optional string              left_cate_avg                 // 叶子类目均值对应指标key
    4: optional string              left_cate_top_twenty_percent  // 叶子类目top20%对应指标key
    5: optional list<string>        not_match_status              // 当判定逻辑 是状态判断时生效 表示未匹配的状态列表 如 ['否']
    6: optional string              scene                         // 流量场景 搜索search、猜喜guessyoulike
}

struct DiagnosisIndicatorCategory {
    1: optional string                    indicator_category    // 影响指标分类
    2: optional string                    scene                 // 流量场景 搜索search、猜喜guessyoulike
    3: optional list<DiagnosisIndicator>  judge_indicator_list  // 需要判定指标列表
    4: optional list<DiagnosisFactor>     factor_list           // 受影响的关键因子
}

struct DiagnosisFactorInfo {
    1: optional string                    scene               // 流量场景 搜索search、猜喜guessyoulike
    2: optional DiagnosisFactor           factor              // 关键因子
    3: optional DiagnosisIndicator        indicator           // 主要指标
    4: optional list<DiagnosisIndicator>  relation_indicator  // 关联指标列表
}

struct DiagnosisFactorCombine {
    1: optional DiagnosisFactorInfo  factor_info                     // 关键因子信息
    2: optional string               factor_indicator_product_count  // 关键因子判定商品数量
}

// 查询诊断判定条件列表
struct GetDiagnosisJudgeConditionListReq {
    1: optional string       scene  // 流量场景 搜索search、猜喜guessyoulike

    255: optional base.Base  Base  
}


struct GetDiagnosisJudgeConditionListData {
    1: list<DiagnosisJudgeCondition>  condition_list  // 判断条件列表
}

struct GetDiagnosisJudgeConditionListResp {
    1: required i32                                 code      // 状态码 0: 成功
    2: required string                              msg       // 出错提示消息
    3: required GetDiagnosisJudgeConditionListData  data      // 返回结果

    255: optional base.BaseResp                     BaseResp 
}
// 查询诊断关键因子列表
struct GetDiagnosisFactorListReq {
    1: optional string                           indicator_category  // 影响指标 曝光product_show、点击product_click、点击product_order
    2: optional string                           judge_key           // 判定条件 
    3: optional string                           scene               // 流量场景 搜索search、猜喜guessyoulike
    4: required AnalysisPoolDiagnosisBaseStruct  base_struct        

    255: optional base.Base                      Base               
}


struct GetDiagnosisFactorListData {
    1: list<DiagnosisFactorCombine>  factor_list  // 关键因子信息列表
}

struct GetDiagnosisFactorListResp {
    1: required i32                         code      // 状态码 0: 成功
    2: required string                      msg       // 出错提示消息
    3: required GetDiagnosisFactorListData  data      // 返回结果

    255: optional base.BaseResp             BaseResp 
}

struct DiagnosisIndicatorJudgeConditionData {
    1: optional DiagnosisJudgeCondition  judge_condition                // 判定条件
    2: optional IndicatorEntity          judge_indicator_entity         // 判定条件指标值结构体
    3: optional string                   judge_indicator_product_count  // 判定条件商品数量，和判定条件指标值二选一返回
}

struct DiagnosisIndicatorJudge {
    1: optional string                                      indicator_category    // 影响指标 曝光product_show、点击product_click、点击product_order
    2: optional DiagnosisIndicator                          indicator             // 判定指标
    3: optional IndicatorEntity                             indicator_entity      // 判定指标值结构体
    4: optional list<DiagnosisIndicatorJudgeConditionData>  judge_condition_data  // 判定条件对应的指标数据
    5: optional string                                      product_count         // 发起诊断判定的商品数量
}

// 查询不同指标分类需要判定数据
struct GetDiagnosisIndicatorCategoryJudgeReq {
    1: optional string                           indicator_category  // 影响指标 曝光product_show、点击product_click、点击product_order
    2: optional string                           judge_key           // 判定条件 
    3: optional string                           scene               // 流量场景 搜索search、猜喜guessyoulike
    4: required AnalysisPoolDiagnosisBaseStruct  base_struct        

    255: optional base.Base                      Base               
}


struct GetDiagnosisIndicatorCategoryJudgeData {
    1: list<DiagnosisIndicatorJudge>  indicator_category_list  // 判定结果数据列表
}

struct GetDiagnosisIndicatorCategoryJudgeResp {
    1: required i32                                     code      // 状态码 0: 成功
    2: required string                                  msg       // 出错提示消息
    3: required GetDiagnosisIndicatorCategoryJudgeData  data      // 返回结果

    255: optional base.BaseResp                         BaseResp 
}

struct IndicatorEntity {
    1: string            name             // 指标名(主要用于传参) eg: order_num
    2: string            value            // 指标值 eg: 1234567
    3: string            data_type        // eg: amt_std(数值)、pct(百分比)、pt(pt)
    4: string            op_code          // eg: value(指标值)、rateS(特殊变化率)、rate(变化率)、cmpValue(对比期指标值)
    5: string            tips             // 指标提示(hover文案)
    8: string            cycle_value      // 环比值
    9: optional i64      priority         // 优先级
    10: optional string  group            // 所属指标组名称
    11: string           display_name     // 指标展示名称
    12: string           cycle_data_type  // eg: amt_std(数值)、pct(百分比)、pt(pt)
    13: string           cycle_op_code    // eg: value(指标值)、rateS(特殊变化率)、rate(变化率)、cmpValue(对比期指标值)
}

struct DiagnosisProductInfo {
    1: optional string                 prod_id                // 商品ID
    2: optional string                 prod_name              // 商品名称
    3: optional string                 prod_bg_url            // 商品背景图
    4: optional list<IndicatorEntity>  indicator_entity_list  // 指标数据
}

// 查询诊断商品指标列表数据
struct QueryDiagnosisProductListReq {
    1: base.PageInfo                             page_req               // 分页参数
    2: optional string                           scene                  // 流量场景 搜索search、猜喜guessyoulike   
    3: optional list<string>                     factor_key_list        // 关键因子信息列表
    4: required AnalysisPoolDiagnosisBaseStruct  base_struct           
    5: optional list<string>                     drill_down_factor_key  // 下钻的关键因子列表
    6: optional string                           judge_key              // 判定条件 
    7: optional DiagnosisSort                    sort                   // 排序逻辑 

    255: optional base.Base                      Base                  
}

struct QueryDiagnosisProductListData {
    1: required list<DiagnosisProductInfo>  list      
    3: base.PageResp                        page_info  // 页码
}

struct QueryDiagnosisProductListResp {
    1: required i32                            code      // 状态码 0: 成功
    2: required string                         msg       // 出错提示消息
    3: required QueryDiagnosisProductListData  data      // 返回结果

    255: optional base.BaseResp                BaseResp 
}

// 查询诊断商品流量空间指标列表数据
struct QueryDiagnosisFlowSpaceProductListReq {
    1: base.PageInfo                             page_req               // 分页参数
    2: optional string                           scene                  // 流量场景 搜索search、猜喜guessyoulike   
    3: required AnalysisPoolDiagnosisBaseStruct  base_struct           
    4: optional list<string>                     drill_down_factor_key  // 下钻的关键因子列表
    5: optional string                           judge_key              // 判定条件 
    6: optional DiagnosisSort                    sort                   // 排序逻辑 

    255: optional base.Base                      Base                  
}

struct QueryDiagnosisFlowSpaceProductListData {
    1: required list<DiagnosisProductInfo>  list      
    3: base.PageResp                        page_info  // 页码
}

struct QueryDiagnosisFlowSpaceProductListResp {
    1: required i32                                     code      // 状态码 0: 成功
    2: required string                                  msg       // 出错提示消息
    3: required QueryDiagnosisFlowSpaceProductListData  data      // 返回结果

    255: optional base.BaseResp                         BaseResp 
}
