namespace py analysis_pool_product
namespace go analysis_pool_product

include "../base.thrift"
include "../basic_info.thrift"
include "../dimensions/dimensions.thrift"
include "../analysis_pool/analysis_pool.thrift"
include "../analysis/analysis.thrift"


//****************************************************************
//*********************** 货盘管理 - 货盘商品 *****************************
//****************************************************************

// 货盘商品操作类型
enum PoolProductOperateType {
    Delete = 0    // 删除
    Add    = 1    // 添加
}

struct AnalysisPoolProduct {
    1: optional string                            prod_id                 // 商品ID
    2: optional string                            prod_name               // 商品名称
    3: optional string                            prod_bg_url             // 商品背景图
    4: optional bool                              purchase_status         // 当前是否可购买
    5: optional bool                              is_allowance_product    // 当前是否超值购活动商品
    6: optional bool                              is_brand_trial_product  // 当前是否大牌试用活动商品
    7: optional i64                               campaign_stock_num_sum  // 当前活动库存
    8: optional string                            leaf_cate_id            // 叶子类目ID
    9: optional string                            leaf_cate_name          // 叶子类目名称
    10: optional string                           max_show_module         // 最大商品曝光模块
    11: optional analysis_pool.AnalysisPool       pool_info               // 货盘信息
    12: optional string                           show_pv                 // 商品曝光
    13: optional string                           click_pv                // 商品点击
    14: optional string                           pay_ord_cnt             // 支付订单
    15: optional string                           pay_gmv                 // 支付GMV(分)
    16: optional string                           opm                     // 每千次曝光产生订单
    17: optional string                           gpm                     // 每千次曝光产生GMV(分)
    18: optional string                           ctr                     // 曝光点击率
    19: optional string                           cvr                     // 点击转化率
    20: optional string                           pvr                     // 曝光转化率
    21: optional list<analysis.TargetCardEntity>  target_list             // 指标列表
    22: optional basic_info.ShopBasicInfo         shop_info               // 店铺信息
    23: optional basic_info.BrandBasicInfo        brand_info              // 品牌信息
    24: optional string                           industry_name           // 行业大类
    25: optional string                           first_level_cate_name   // 一级类目
    26: optional string                           second_level_cate_name  // 二级类目
    27: optional bool                             is_delivery_product     // 当前是否对外投放商品
    28: optional bool                             is_seckill_product      // 当前是否秒杀活动商品
    29: optional i64                             normal_stock_num_sum     // 当前普通库存
    30: optional string                             purchase_status_reason     // 当前不可售原因
    31: optional string                             spu_estimate_price_online_tag     // 普惠到手价(单品)比价状态
}

// 查询商品列表
struct QueryAnalysisPoolProductListReq {
    1: base.PageInfo              page_req      // 分页参数
    2: required string            pool_id       // 货盘ID，必传
    3: optional string            alert_msg_id  // 预警消息ID, 用于查预警消息内的商品列表
    4: optional string            product_id    // 商品ID
    5: optional string            product_name  // 商品名称
    6: optional string            start_date    // 指标计算开始时间
    7: optional string            end_date      // 指标计算结束时间
    8: optional base.OrderByInfo  order_by      // 排序参数，不传的话默认根据曝光PV倒排

    255: optional base.Base       Base         
}

struct QueryAnalysisPoolProductListData {
    1: required list<AnalysisPoolProduct>   list      
    2: optional analysis_pool.AnalysisPool  pool_info  // 货盘信息
    3: optional i64                         shop_cnt   // 涉及商家数量
    4: base.PageResp                        page_info  // 页码
}

struct QueryAnalysisPoolProductListResp {
    1: required i32                               code      // 状态码 0: 成功
    2: required string                            msg       // 出错提示消息
    3: required QueryAnalysisPoolProductListData  data      // 返回结果

    255: optional base.BaseResp                   BaseResp 
}

// 获取可查数据时间范围
struct GetDataAvailableDateRangeReq {
    1: optional string  pool_id  // 货盘ID
    255: optional base.Base  Base 
}

struct AvailableDateRange {
    1: required string  min_date  // 最小可查日期，格式：2020-01-01
    2: required string  max_date  // 最大可查日期，格式：2020-01-01
}

struct GetDataAvailableDateRangeResp {
    1: required i32                 code      // 状态码 0: 成功
    2: required string              msg       // 出错提示消息
    3: required AvailableDateRange  data      // 返回结果

    255: optional base.BaseResp     BaseResp 
}

// 导出商品列表
struct DownloadAnalysisPoolProductListReq {
    1: base.PageInfo              page_req      // 分页参数
    2: required string            pool_id       // 货盘ID，必传
    3: optional string            alert_msg_id  // 预警消息ID, 用于查预警消息内的商品列表
    4: optional string            product_id    // 商品ID
    5: optional string            product_name  // 商品名称
    6: optional string            start_date    // 指标计算开始时间
    7: optional string            end_date      // 指标计算结束时间
    8: optional base.OrderByInfo  order_by      // 排序参数，不传的话默认根据曝光PV倒排

    255: optional base.Base       Base         
}

struct DownloadAnalysisPoolProductListResp {
    1: required i32              code      // 状态码 0: 成功
    2: required string           msg       // 出错提示消息
    3: required bool             is_ok     // 是否导出成功

    255: optional base.BaseResp  BaseResp 
}

// 货盘添加/删除商品
struct OpAnalysisPoolProductReq {
    1: required string                  pool_id          // 货盘ID 必传
    2: required list<string>            product_id_list  // 商品ID 必传
    3: required PoolProductOperateType  op_type          // 0:删除; 1: 添加； 必传
    255: optional base.Base             Base            
}

struct OpAnalysisPoolProductResp {
    1: required i32              code      // 状态码 0: 成功
    2: required string           msg       // 出错提示消息
    3: required bool             is_ok     // 是否操作成功
    255: optional base.BaseResp  BaseResp 
}

// 单品多维拆分列表
struct GetProductMultiDimReq {
    1: required string                                       pool_id      // 货盘ID
    2: required string                                       product_id   // 商品ID
    3: optional string                                       start_date   // 指标计算开始时间
    4: optional string                                       end_date     // 指标计算结束时间
    5: optional list<dimensions.SelectedMultiDimensionInfo>  group_attrs  // 多维分析筛选，按维度顺序
    6: optional base.OrderByInfo                             order_by     // 排序参数，不传的话默认根据曝光PV倒排
    255: optional base.Base                                  Base        
}

struct GetProductMultiDimResp {
    1: required i32                             code           // 状态码 0: 成功
    2: required string                          msg            // 出错提示消息
    3: required list<analysis.MultiDimListRow>  dim_list_data  // 维度拆分数据
    4: required AnalysisPoolProduct             product_data   // 商品整体数据
    255: optional base.BaseResp                 BaseResp      
}

// 导出单品多维拆分数据
struct DownloadProductMultiDimReq {
    1: required string                                       pool_id      // 货盘ID
    2: required string                                       product_id   // 商品ID
    3: optional string                                       start_date   // 指标计算开始时间
    4: optional string                                       end_date     // 指标计算结束时间
    5: optional list<dimensions.SelectedMultiDimensionInfo>  group_attrs  // 多维分析筛选，按维度顺序
    6: optional base.OrderByInfo                             order_by     // 排序参数，不传的话默认根据曝光PV倒排
    255: optional base.Base                                  Base        
}

struct DownloadProductMultiDimResp {
    1: required i32              code      // 状态码 0: 成功
    2: required string           msg       // 出错提示消息
    3: required bool             is_ok     // 是否导出成功
    255: optional base.BaseResp  BaseResp 
}

// 货盘商品趋势数据
struct GetPoolProductTrendReq {
    1: required string       pool_id     // 货盘ID
    2: optional string       start_date  // 指标计算开始时间
    3: optional string       end_date    // 指标计算结束时间
    255: optional base.Base  Base       
}

struct PoolProductTrendData {
    1: optional string                           date         // 日期
    2: optional list<analysis.TargetCardEntity>  target_list  // 指标列表
}

struct GetPoolProductTrendData {
    5: optional list<PoolProductTrendData>  trend_data_list  // 趋势数据
}

struct GetPoolProductTrendResp {
    1: required i32                      code      // 状态码 0: 成功
    2: required string                   msg       // 出错提示消息
    4: required GetPoolProductTrendData  data      // 商品整体趋势数据
    255: optional base.BaseResp          BaseResp 
}

// 查询货盘全量商品
struct GetAnalysisPoolProductListReq {
    1: required string       pool_id  // 货盘ID，必传

    255: optional base.Base  Base    
}
struct GetAnalysisPoolProductListData {
    1: required list<string>  pid_list 
}

struct GetAnalysisPoolProductListResp {
    1: required i32                             code      // 状态码 0: 成功
    2: required string                          msg       // 出错提示消息
    3: required GetAnalysisPoolProductListData  data      // 货盘所有商品

    255: optional base.BaseResp                 BaseResp 
}
