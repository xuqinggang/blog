namespace py base
namespace go base
namespace java com.bytedance.thrift.base

struct TrafficEnv {
    1: bool Open = false,
    2: string Env = "",
}

struct Base {
    1: string LogID = "",
    2: string Caller = "",
    3: string Addr = "",
    4: string Client = "",
    5: optional TrafficEnv TrafficEnv,
    6: optional map<string, string> Extra,
}

struct BaseResp {
    1: string StatusMessage = "",
    2: i32 StatusCode = 0,
    3: optional map<string, string> Extra,
}

// 通用分页参数
struct PageInfo {
    1: i32 page_num  // 页数 从1开始
    2: i32 page_size // 页面大小
}

// 非指标排序字段
enum OrderByField{
    ShowPv = 1,
    PayOrderNum = 2,
    BrandLevel = 3,
    GMV = 4,
}

// 通用排序参数
struct OrderByInfo{
    1: optional OrderByField field // 非指标的排序字段（例如，品牌等级）
    2: bool is_desc // true 降序, false 升序
    3: optional string column_name // 排序的列名
}

// 通用分页返回
struct PageResp {
    1: i32 page_num  // 页数 从1开始
    2: i32 page_size // 页面大小
    3: i64 total
}

// 通用元素结构体
struct ElementValue {
    1: required string  id     // 唯一标识id
    2: required string  name   // 展示名称
}

// 操作符类型
enum OperatorType {
    IN      // 包含
    NOT_IN  // 不包含
    GREATER_EQUAL_THAN
    LESS_EQUAL_THAN
    GREATER_THAN
    LESS_THAN
    EQUAL
}

// 指标属性计算类型
enum TargetAttributeCalcType {
    Basic // 基础指标
    Derivative // 衍生指标
}

enum LogicalExprType {
    AND      // 包含
    OR       // 不包含
}

struct EmptyRequest {

    255: optional Base Base
}

struct BaseResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required string data     // 返回结果

    255: optional BaseResp BaseResp
}

enum DateType {
    DAY         // 日
    WEEK        // 周
    MONTH       // 月
}