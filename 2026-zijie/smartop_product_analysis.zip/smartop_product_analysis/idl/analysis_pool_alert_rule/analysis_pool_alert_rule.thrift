namespace py analysis_pool_alert_rule
namespace go analysis_pool_alert_rule

include "../base.thrift"
include "../analysis_pool/analysis_pool.thrift"
include "../dimensions/dimensions.thrift"



//****************************************************************
//*********************** 监控规则 *****************************
//****************************************************************

struct AlertMsgReceiverLarkGroup {
    1: required string  lark_group_id   
    2: optional string  lark_group_name 
    3: optional string  icon            
}

struct AlertMsgReceiverUser {
    1: optional string  user_id   
    2: required string  user_name 
    3: optional string  icon      
}

struct AlertMsgReceiver {
    1: required list<AlertMsgReceiverUser>       users        // 个人接收人列表
    2: required list<AlertMsgReceiverLarkGroup>  lark_groups  // 飞书群组接收人列表
}

// 告警升级
struct AlertRiseConfig {
    1: required i64               compare_type  // 比较类型
    2: required double            value         // 比较值
    3: optional AlertMsgReceiver  receiver      // 告警消息接收者
}

struct ReportStrategy {
    1: required bool  deduplicate     // 告警去重
    2: optional i64   limit           // 10分钟告警上限
    3: optional i64   alert_interval  // 告警间隔
}

struct ScheduleStrategy {
    1: required string  cron      // 定时校验频率
    2: optional i64     priority  // 任务优先级
}

struct Subscribe {
    1: required string  code 
    2: optional string  name 
}

// 触达频次控制
struct PushFrequency {
    1: required i64  time_type      // 告警统计的事件范围，枚举(1:近3日; 2:近7日; 3:近15日; 4:近30日; 5:当个自然月)
    2: required i64  max_frequency  // 最大推送次数
}

struct DehcConf {
    1: bool    switch             // 开关，true开启
    2: string  one_case_scene     // 一级问题域
    3: string  second_case_scene  // 二级问题域
    4: string  root_cause_id      // 根因
    5: string  duplicate_key      // 去重key
}

struct FilterCondition {
    1: optional list<FilterCondition>  sub_conditions  // 子过滤条件，FilterCondition递归结构
    2: optional string                 logic           // SubConditions逻辑关系，and ｜ or
    3: optional string                 dimension_code  // 维度code
    4: optional string                 op              // 算子 in ｜ not_in
    5: optional list<string>           option_values   // 维度项值列表
    6: optional string                 keyword_name    // 名称  指标预警新增
    7: optional string                 keyword_code    // 英文名  指标预警新增
}

struct Tag {
    1: required string  code   // industry_id;activity_id;live_id;app_id;time;current;current_offset
    2: required string  value 
}

struct ObjectIndicator {
    1: required string     code         // 指标code
    2: required i64        object_type  // 指标关联实体类型
    3: optional list<Tag>  tags         // 标签
}

// 事件类型指标配置信息
struct EventIndicatorConfig {
    1: required string           code          // 指标code，count类可为空
    2: required string           id            // 规则树内唯一
    3: required i64              time_type     // 1:今日累计; 2:近1分钟; 3:近3分钟; 4:近5分钟; 5:近30分钟; 6:近1小时; 7:近2小时; 8:近3小时; 9:近5小时; 10:近7日; 11:近14日; 12:近30日; 13:近1日; 14:近2日; 15:近3日; 16:近5日
    4: required i64              compare_type  // 1:绝对值;  2:环比; 3:环差; 4:相比昨天同时段-比例; 5:相比昨天同时段-差值; 6:相比上周同时段-比例; 7:相比上周同时段-差值; 8:相比前一日同时段上升百分比 9:相比前一日同时段下降百分比 10:相比前一日同时段上升绝对值 11:相比前一日同时段下降绝对值 12:相比前一周同时段上升百分比 13:相比前一周同时段下降百分比 14:相比前一周同时段上升绝对值 15:相比前一周同时段下降绝对值
    5: required string           agg_type      // 聚合方式，count；sum；avg
    6: optional FilterCondition  condition     // 过滤条件
    7: optional i64              time_range    // 数据时间范围 指标预警新增
    8: optional i64              time_unit     // 数据时间单位，1-天，2-小时 指标预警新增
    9: optional string           metrics_name  // 名称 指标预警新增
    10: optional string          metrics_code  // 英文名 指标预警新增
}

// 北冰洋二期新增
struct CustomRuleConfig {
    1: required string                       id              // 规则树内唯一
    2: required i64                          time_type       // 告警统计的事件范围，枚举(1:今日累计; 2:近1分钟; 3:近3分钟; 4:近5分钟; 5:近30分钟; 6:近1小时; 7:近2小时; 8:近3小时; 9:近5小时; 10:近7日; 11:近14日; 12:近30日; 13:近1日; 14:近2日; 15:近3日; 16:近5日)
    3: required CustomRuleIndicator          indicator       // 计算框(指标)
    4: required i64                          compare_type    // 告警统计值和阈值对比方式，枚举(1:绝对值;  2:环比; 3:环差; 4:相比昨天同时段-比例; 5:相比昨天同时段-差值; 6:相比上周同时段-比例; 7:相比上周同时段-差值; 8:相比前一日同时段上升百分比 9:相比前一日同时段下降百分比 10:相比前一日同时段上升绝对值 11:相比前一日同时段下降绝对值 12:相比前一周同时段上升百分比 13:相比前一周同时段下降百分比 14:相比前一周同时段上升绝对值 15:相比前一周同时段下降绝对值)
    5: optional IndicatorNodeValueCondition  condition       // 规则过滤条件

    6: optional i64                          time_range      // 数据时间范围
    7: optional i64                          time_unit       // 数据时间单位，1-天，2-小时
    8: optional MetricsAlertConfig           metrics_config  // 指标预警新增，关键词过滤
    9: optional string                       metrics_name    // 指标名称，指标预警简易模式
    10: optional string                      metrics_code    // 指标英文名，指标预警简易模式
}

struct MetricsAlertConfig {
    1: required string                 name     // 名称
    2: required string                 code     // 英文名
    3: required i64                    type     // 1-指标类型，2-关键词筛选类型
    4: optional list<DimensionOption>  options 
}

struct DimensionOption {
    1: required string  name 
    2: required string  code 
}

// 北冰洋二期新增
struct CustomRuleIndicator {
    1: required i64                  indicator_type  // 指标类型(0:数值型; 1:基础类型指标 2:复合类型指标)
    2: optional double               num_value       // 数值类型指标的值
    3: optional IndicatorNodeValue   node_value      // 节点值
    4: optional i64                  op              // 左右节点的逻辑运算(0: + , 1: - , 2: x , 3: /)
    5: optional CustomRuleIndicator  left_node       // 左节点
    6: optional CustomRuleIndicator  right_node      // 右节点
}

// 北冰洋二期新增
struct IndicatorNodeValue {
    1: required string                       indicator_code  // 指标code
    2: required i64                          agg_type        // 聚合方式(0: count 1: sum 2: avg  3: distinct count); 指标支持:count/sum/avg，维度支持:count/distinct count
    3: optional IndicatorNodeValueCondition  condition       // 过滤条件
    4: optional string                       metrics_name    // 名称
    5: optional string                       metrics_code    // 英文名
}

// 北冰洋二期新增
struct IndicatorNodeValueCondition {
    1: optional list<IndicatorNodeValueCondition>   conditions         // 子过滤条件(递归结构)
    2: required string                              logic              // 子过滤条件之间的逻辑关系 "and" | "or"
    3: required i64                                 condition_type     // 过滤条件类型(0:一般过滤条件 1:自定义过滤条件 2:关键词过滤条件)

    4: optional IndicatorNodeValueCommonCondition   common_condition   // 一般过滤条件
    5: optional IndicatorNodeValueCustomCondition   custom_condition   // 自定义过滤条件
    6: optional IndicatorNodeValueKeywordCondition  keyword_condition  // 关键词过滤条件
}

// 北冰洋二期新增
struct IndicatorNodeValueCommonCondition {
    1: optional string        dimension  // 维度
    2: optional string        op         // 算子
    3: optional list<string>  values     // 维度项code列表
}

// 北冰洋二期新增
struct IndicatorNodeValueCustomCondition {
    1: required IndicatorNodeValueCustomConditionIndicator  indicator       // 指标
    2: required string                                      op              // 算子 >, >=, =, <, <=
    3: required i64                                         threshold_type  // 阈值类型(0:数值 1:时间(单位s))
    4: required double                                      threshold       // 阈值
}

// 北冰洋二期新增
struct IndicatorNodeValueKeywordCondition {
    1: optional string        dimension  // 维度
    2: optional string        op         // 算子
    3: optional list<string>  values     // 维度项code列表
}

// 北冰洋二期新增
struct IndicatorNodeValueCustomConditionIndicator {
    1: required i64                                         indicator_type  // 指标类型(0:数值型; 1:基础类型指标 2:复合类型指标)
    2: optional double                                      num_value       // 数值类型指标的值
    3: optional string                                      indicator_code  // 指标code
    4: optional i64                                         op              // 左右节点的逻辑运算(0: + , 1: - , 2: x , 3: /)
    5: optional IndicatorNodeValueCustomConditionIndicator  left_node       // 左节点
    6: optional IndicatorNodeValueCustomConditionIndicator  right_node      // 右节点
}

struct Rule {
    1: optional list<Rule>            rules               // 子规则
    2: optional string                rule_name           // 规则名称
    3: optional string                logic               // and or
    4: optional string                op                  // 大于> 小于< 等于== 不等于!= 大于等于>= 小于等于<=
    5: optional double                value               // 比较值
    6: optional ObjectIndicator       indicator           // 指标
    7: optional string                desc                // 规则描述
    8: optional bool                  switch              // 规则是否开启，不填默认true
    9: optional EventIndicatorConfig  indicator_config    // 事件类型指标配置信息
    10: optional CustomRuleConfig     custom_rule_config  // 规则配置(自定义预警)
    11: optional string               rule_id             // 规则id
    12: optional i64                  version             // 1-旧版，2-新版 指标预警新增
    13: optional i64                  alert_rule_type     // 1-关键词预警，2-指标预警 指标预警新增

    14: optional AlertThreshold       alert_threshold     // 预警推送条件，如最近7天中3天命中条件
    15: optional dimensions.ProductAnalysisBaseStruct  alert_pretty_rule // 原生监控规则
    16: optional AlertIndicator       alert_indicator     // 原生sql监控阈值
}

struct AlertIndicator {
    1: required string indicator_code // 预警code
    2: required i64 compare_type   //告警统计值和阈值对比方式，枚举(1:绝对值, 2环比，3)
    3: optional i64  time_range    // 数据时间范围
    4: optional i64  time_unit     // 数据时间单位
}

struct AlertThreshold {
    1: required i64     total          // 总天数
    2: required i64     threshold      // 命中天数
    3: required string  op             // ==  > >= < <=
    4: optional bool    is_continuous  // 是否需要连续命中
}

struct RuleConfig {
    1: required string            rule_id            // 规则id
    2: required string            author_id          // 新建人id
    3: required string            business_id        // 业务id
    4: required string            object_id          // 实体id
    5: required i64               object_type        // 实体类型 1:分组 2:活动
    6: required string            rule_name          // 规则名称
    7: required Rule              rule               // 规则
    8: optional ReportStrategy    report_strategy    // 上报策略
    9: optional ScheduleStrategy  schedule_strategy  // 告警策略
    10: optional string           rule_desc          // 规则描述
    11: optional bool             switch             // 是否开启
    // 预警系统3.0新增
    12: optional string           event_type         // 事件类型
    13: optional string           event_group_by     // 分组字段
    14: optional string           change_user        // 上一次更新人
    15: optional string           rule_abstract      // 规则摘要
    // 北冰洋二期新增
    16: optional i64              data_source_type   // 数据源类型 0:实时 1:离线
    17: optional list<Subscribe>  extra_info         // 额外信息
    18: optional PushFrequency    push_frequency     // 推送频率
    19: optional DehcConf         dehc_conf          // dehc配置
}

struct EventRuleItem {
    1: optional RuleConfig        rule                    // 规则信息
    2: optional list<string>      admins                  // 管理员
    3: optional i64               alert_count             // 累计预警次数
    4: optional i64               latest_alert_timestamp  // 最近一次告警时间(时间戳，秒)
    5: optional AlertMsgReceiver  receiver                // 告警消息接收者
    6: optional AlertRiseConfig   alert_rise_config       // 告警升级配置
    7: optional bool              low_disturb             // 低打扰模式，true开启，false关闭
}

struct SelectValue {
    1: required string        name                        
    2: required string        value                       

    3: optional bool          support_group_by             // 针对维度-是否支持分组
    4: optional list<string>  support_ops                  // 针对维度-支持的算子
    5: optional string        data_source_type             // 针对数据源-数据类型:offline|real_time
    6: optional string        dimension_option_fetch_type  // 针对维度-维度项获取类 enum | custom | search
    7: optional bool          data_source_is_full          // 针对维度-数据类型是否为全量表
}

struct AlertEventTypeItem {
    1: required string  name             
    2: required string  code             
    3: required string  update_time       // 更新时间
    4: required i64     data_source_type  // 数据类型枚举(0:实时；1:离线)
    5: required i64     delay_time        // 数据延迟时间
    6: required i64     delay_unit        // 延迟产生时间单位，1-天，2-小时
}

struct ArcticAlertIndicator {
    1: required string        name           
    2: required string        code           
    3: required i64           indicator_type  // 指标类型(0:普通指标 1:时间类型指标)
    4: optional i64           data_type       // 1-decimal,2-int,3-string
    5: optional list<string>  support_ops     // 支持的算子
}

struct AlertProductStatusRuleItem {
    1: optional string        indicator  // 商品状态规则指标key
    2: optional string        op              // 大于> 小于< 等于== 不等于!= 大于等于>= 小于等于<=
    3: optional list<string>  value           // 比较值
}

struct AlertProductStatusRule {
    1: optional list<AlertProductStatusRuleItem>  rules  // 商品状态规则配置列表
}

// 根据货盘id查询监控规则列表
struct QueryAnalysisPoolAlertRuleListReq {
    1: optional string        pool_id        // 货盘ID`
    2: optional string        rule_name      // 规则名
    3: optional list<string>  creators       // 创建人
    4: optional i64           task_priority  // 任务优先级
    5: optional list<string>  event_types    // 事件类型
    255: optional base.Base   Base          
}
struct QueryAnalysisPoolAlertRuleData {
    1: optional EventRuleItem               item 
    2: optional analysis_pool.AnalysisPool  pool  // 货盘信息
}

struct QueryAnalysisPoolAlertRuleListData {
    1: optional list<QueryAnalysisPoolAlertRuleData>  list 
    2: optional analysis_pool.AnalysisPool            pool  // 货盘信息
}

struct QueryAnalysisPoolAlertRuleListResp {
    1: optional QueryAnalysisPoolAlertRuleListData  data     
    255: optional base.BaseResp                     BaseResp 
}

// 根据货盘货品创建监控
struct CreateAnalysisPoolAlertRuleReq {
    1: required string            pool_id                    // 货盘id
    2: required string            rule_name                  // 规则名称
    3: required Rule              rule                       // 规则
    4: optional ReportStrategy    report_strategy            // 上报策略
    5: optional ScheduleStrategy  schedule_strategy          // 10分钟告警上限
    // 预警系统3.0新增
    6: optional string            event_type                 // 事件类型
    7: optional string            event_group_by             // 分组字段
    8: optional string            desc                       // 规则描述
    9: optional list<string>      admins                     // 管理员列表
    10: optional list<string>     receiveUsers               // 告警消息接收者
    11: optional list<string>     receiveGroups              // 告警消息接收群组
    12: optional AlertRiseConfig  alert_rise_config          // 告警升级配置
    13: optional bool             low_disturb                // 低打扰模式，true开启，false关闭
    14: optional i64              effective                  // 是否立即执行，0-否，1-是
    15: optional list<Subscribe>  extra_info                 // 额外信息
    16: optional PushFrequency    push_frequency             // 推送频率控制
    17: optional DehcConf         dehc_conf                  // dehc配置
    18: optional i32              is_analyze_product_status  // 是否监控商品状态, 0不监控, 1监控
    19: optional string           alert_product_status_rule  // 监控商品状态规则,json string,字段参考AlertProductStatusRule
    255: optional base.Base       Base                      
}

struct CreateAnalysisPoolAlertRuleData {
    1: optional string  rule_id 
}

struct CreateAnalysisPoolAlertRuleResp {
    1: optional CreateAnalysisPoolAlertRuleData  data     
    255: optional base.BaseResp                  BaseResp 
}

// 根据货盘货品更新监控规则
struct UpdateAnalysisPoolAlertRuleReq {
    1: required string            author_id                  // 修改人id
    2: required string            business_id                // 业务id
    3: required string            rule_name                  // 规则名称
    4: required Rule              rule                       // 规则
    5: optional ReportStrategy    report_strategy            // 上报策略
    6: optional ScheduleStrategy  schedule_strategy          // 10分钟告警上限
    // 预警系统3.0新增
    7: optional string            event_type                 // 事件类型
    8: optional string            event_group_by             // 分组字段
    9: optional string            desc                       // 规则描述
    10: optional string           rule_id                    // 规则id
    11: optional string           author_email               // 修改人邮箱
    12: optional string           author_name                // 修改人中文名
    13: optional list<string>     admins                     // 管理员列表
    14: optional list<string>     receiveUsers               // 告警消息接收者
    15: optional list<string>     receiveGroups              // 告警消息接收群组
    16: optional AlertRiseConfig  alert_rise_config          // 告警升级配置
    17: optional bool             low_disturb                // 低打扰模式，true开启，false关闭
    18: optional list<Subscribe>  extra_info                 // 额外信息

    19: optional PushFrequency    push_frequency             // 推送频率控制
    20: optional DehcConf         dehc_conf                  // dehc配置

    21: optional i32              is_analyze_product_status 
    22: optional string           alert_product_status_rule  // 监控商品状态规则,json string,字段参考AlertProductStatusRule
    255: optional base.Base       Base                      
}

struct UpdateAnalysisPoolAlertRuleResp {
    255: optional base.BaseResp  BaseResp 
}

struct UpdateAnalysisPoolAlertRuleStatusReq {
    1: required string       rule_id       // db主键id，更新时，id不为空
    2: required bool         is_active     // 激活状态
    3: required string       author_id     // 修改人id
    4: required string       author_email  // 修改人邮箱
    5: required string       author_name   // 修改人中文名
    255: optional base.Base  Base         
}

struct UpdateAnalysisPoolAlertRuleStatusResp {
    255: optional base.BaseResp  BaseResp 
}

// 查询单个预警任务详情
struct GetAnalysisPoolAlertRuleDetailReq {
    1: required string       rule_id 
    2: optional i64          version 
    255: optional base.Base  Base    
}

struct GetAnalysisPoolAlertRuleDetailData {
    1: optional EventRuleItem  ruleData                  
    2: optional list<string>   receiveUsers              
    3: optional list<string>   receiveGroups             
    4: optional i32            is_analyze_product_status 
    5: optional string           alert_product_status_rule  // 监控商品状态规则,json string,字段参考AlertProductStatusRule
}

struct GetAnalysisPoolAlertRuleDetailResp {
    1: optional GetAnalysisPoolAlertRuleDetailData  data     
    255: optional base.BaseResp                     BaseResp 
}

// 获取预警维度列表
struct GetAnalysisPoolAlertDimensionsReq {
    1: optional string       event_type 
    255: optional base.Base  Base       
}

struct GetAnalysisPoolAlertDimensionsData {
    1: optional list<SelectValue>  dimensions 
}

struct GetAnalysisPoolAlertDimensionsResp {
    1: optional GetAnalysisPoolAlertDimensionsData  data     
    255: optional base.BaseResp                     BaseResp 
}

// 查询数据源列表
struct LisAnalysisPoolEventTypeReq {
}

struct LisAnalysisPoolEventTypeData {
    1: optional list<AlertEventTypeItem>  items 
}

struct LisAnalysisPoolEventTypeResp {
    1: optional LisAnalysisPoolEventTypeData  data     
    255: optional base.BaseResp               BaseResp 
}

// 获取数据指标列表
struct GetAnalysisPoolAlertIndicatorsReq {
    1: required string       event_type        // 事件类型code
    2: required i64          data_source_type  // 数据类型枚举(0:实时；1:离线)
    3: optional string       metrics           // 指标列表, 根据指标获取维度列表
    255: optional base.Base  Base             
}

struct GetAnalysisPoolAlertIndicatorsData {
    1: optional list<ArcticAlertIndicator>  indicators  // 维度列表
}

struct GetAnalysisPoolAlertIndicatorsResp {
    1: optional GetAnalysisPoolAlertIndicatorsData  data     
    255: optional base.BaseResp                     BaseResp 
}

struct ExceptionProductInfo {
    1: required string  product_id    // 商品id
    2: optional string  product_name  // 商品名称
}

struct AlertProdStatusExceptionInfo {
    1: optional bool                        wrong             // 是否异常
    2: optional string                      wrong_abstruct    // 判定规则描述
    3: optional i64                         wrong_prod_count  // 判定异常商品数量
    4: optional list<ExceptionProductInfo>  wrong_prods       // 判定异常用于展示商品列表
    5: optional string  alert_msg_id       // 商品状态异常预警信息id
}

struct RuleWitExceptionProdInfos {
    1: optional string                                     rule_id          // 规则id
    2: optional map<string, AlertProdStatusExceptionInfo>  exception_infos  // 规则下异常信息
}

// 查询所有存在商品状态异常的规则
struct GetRulesWitExceptionProdStatusInfosReq {
    255: optional base.Base  Base 
}

struct GetRulesWitExceptionProdStatusInfosResp {
    1: optional list<RuleWitExceptionProdInfos>  data     
    255: optional base.BaseResp                  BaseResp 
}

// 删除规则
struct DeleteAlertRuleReq {
    1: required string       rule_id  // 规则id
    255: optional base.Base  Base    
}

struct DeleteAlertRuleRespData {}

struct DeleteAlertRuleResp {
    1: optional DeleteAlertRuleRespData  data     
    255: optional base.BaseResp          BaseResp 
}

struct ConvertToAlertRuleReq {
    1: required dimensions.BizType                    biz_type    
    2: optional dimensions.ProductAnalysisBaseStruct  base_struct  // 货盘规则
    3: optional bool                                  is_total    
}

struct ConvertToAlertRuleResp {
    1: optional IndicatorNodeValueCondition  data     
    255: optional base.BaseResp              BaseResp 
}

struct AlertProdStatusRuleIndicatorOption {
    1: optional string  code 
    2: optional string  name 
}

struct AlertProdStatusRuleIndicator {
    1: optional string                                    indicator 
    2: optional string                                    name      
    3: optional string                                    show_type 
    4: optional list<AlertProdStatusRuleIndicatorOption>  options   
    5: optional string                                      assist_indicator    
    6: optional string                                    tips  
}

// 查询商品状态监控规则枚举数据
struct GetAlertProdStatusRuleIndicatorReq {
    255: optional base.Base  Base 
}

struct GetAlertProdStatusRuleIndicatorData {
    1: optional list<AlertProdStatusRuleIndicator>  indicator_list 
}

struct GetAlertProdStatusRuleIndicatorResp {
    1: optional GetAlertProdStatusRuleIndicatorData  data     
    255: optional base.BaseResp                      BaseResp 
}
