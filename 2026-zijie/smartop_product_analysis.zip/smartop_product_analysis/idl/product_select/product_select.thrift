namespace py product_select
namespace go product_select

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../analysis/analysis.thrift"
include "../analysis/price_analysis.thrift"

// 业务类型枚举
enum BusinessType {
    Unknown                    = 0     // 未知业务类型
    ZeroSubsidyExplode         = 1000  // 0补爆品业务类型, 和BizType=300000对应
    AggregationLinks           = 1001  // 聚合链接业务类型, 和BizType=300001对应
    FastConsumer               = 1002  // 行业快消业务类型, 和BizType=300002对应
    ZeroSubsidyChannelExplode  = 1003  // 0补频道爆品业务类型, 和BizType=300003对应
}

// 预览场景枚举
enum PreviewScene {
    TaskCreate         = 1  // 任务创建时的预览场景
    TaskResult         = 2  // 任务结果展示时的预览场景
}

// 用户权限类型枚举
enum PrivilegeType {
    Unknown = 0,            // 无权限：无法访问或使用产品选择功能
    Normal = 1,             // 普通权限：能够创建任务, 编辑自己的任务
    Administrator = 10,     // 管理员权限：拥有所有权限，包括查看和编辑所有任务
}

// 页面模块类型枚举
enum PageModuleType {
    HotSale         = 1  // 热销
    Addition        = 2  // 补品
}

// 特征信息结构体
struct FeatureInfo {
    1: string  feature       // 特征名
    2: string  feature_name  // 特征中文名
    3: double  score         // 特征得分
    4: string  description   // 特征描述
}

// 零补贴爆品特征结构体
struct ZeroSubsidyExplodeFeature  {
    1: list<FeatureInfo>  feature_info                // 特征信息
    2: i64                update_time                 // 更新时间
    3: i64                analysis_pool_prod_count    // 分析池商品数量
    4: i64                analysis_select_prod_count  // 符合目标的商品数量
    5: string             business_date               // 业务日期
}

// 扩展信息结构体
struct Extra {
    1: ZeroSubsidyExplodeFeature  zero_subsidy_explode_feature  // 零补贴爆品特征
    2: list<FeatureInfo>          used_feature_info             // 已使用的特征信息
    3: i64                        base_pool_prod_count          // 底池商品数量
    4: i64                        select_prod_count             // 圈选商品数量
    5: string                     pool_rule                     // 圈选规则
    6: BusinessType               business_type                 // 业务类型
    7: bool                       is_manual                     // 是否人工圈选
    8: string                     dimension_sql                 // 圈选规则sql
    9: string                     selected_page_module_config   // 已选模块配置
}

// 选品任务结构体
struct ProductSelectTask  {
    1: dimensions.BizType  biz_type       // 业务类型
    2: string              task_id        // 任务ID
    3: string              task_name      // 任务名称
    4: i64                 target_amount  // 目标圈品数量
    5: string              create_user_id // 创建用户ID
    6: string              update_user_id // 更新用户ID
    7: i64                 create_time    // 创建时间
    8: i64                 update_time    // 更新时间
    9: i32                 is_del         // 是否删除(0=正常, 1=删除)
    10: i32                task_status    // 任务状态（0=进行中, 1=已完成, 2=已失败）
    11: string             pool_id        // 圈品池ID
    12: Extra              extra          // 扩展信息
}

//  -----------------------------  选品任务配置与管理相关接口  ------------------
// 获取选品管理员配置请求
struct GetProductSelectAdministratorConfigRequest {
    1: BusinessType                business_type            // 业务类型
    2: optional dimensions.BizType biz_type                 // 用户业务线

    255: optional base.Base        base_info                // 通用元信息
}

struct PageModuleConfig {
    1: optional list<string> dimension_ids      // 规则Id列表
    2: optional list<string> threshold_attr_ids // 指标Id列表
}

struct ProductSelectTypeConfig {
    1: optional dimensions.BizType biz_type // 业务类型
    2: optional BusinessType business_type  // 业务类型
    3: optional string type_name            // 业务类型名称
    4: optional string hive_table           // hive表名
    5: optional bool is_manual              // 是否人工圈选
}

// 获取选品管理员配置响应
struct GetProductSelectAdministratorConfigResponse {
    1: required i32                code      // 状态码 0: 成功
    2: required string             msg       // 出错提示消息

    5: optional list<dimensions.SelectedDimensionInfo> required_dimensions // 用户必选规则
    6: optional list<ProductSelectTypeConfig> type_configs                 // 选品类型配置

    10: optional list<dimensions.SelectedDimensionInfo>              target_dimensions  // 业务目标规则
    11: optional list<dimensions.SelectedDimensionInfo>              feature_dimensions // 特征分析底池规则
    12: optional map<string, list<dimensions.SelectedDimensionInfo>> quick_dimensions   // 快速规则映射

    20: optional map<PageModuleType, PageModuleConfig> page_module_config // 页面模块配置

    255: optional base.BaseResp          BaseResp
}

struct SelectedPageModuleConfig {
    1: optional list<dimensions.SelectedDimensionInfo> dimensions  // 维度筛选
    2: optional list<dimensions.ThresholdAttr> threshold_attrs     // 指标筛选
}

// 创建或更新选品任务请求
struct CreateAndUpdateProductSelectTaskRequest  {
    1: ProductSelectTask     task  // id 为空时创建，否则更新
    2: optional list<dimensions.SelectedDimensionInfo> dimensions                 // 选品规则列表

    10: map<PageModuleType, SelectedPageModuleConfig> selected_page_module_config // 页面模块配置

    255: optional base.Base  Base
}

// 创建或更新选品任务响应
struct CreateAndUpdateProductSelectTaskResponse {
    1: required i32              code      // 状态码 0: 成功
    2: required string           msg       // 出错提示消息
    3: required bool             data      // 返回结果

    255: optional base.BaseResp  BaseResp 
}

//  -----------------------------  选品任务查询相关接口  ------------------
// 获取选品任务列表请求
struct GetProductSelectTaskListRequest {
    1: dimensions.BizType    biz_type        // 业务线
    2: string                create_user_id  // 创建人

    11: i32                  page_num        // 页号（第一页传0）
    12: i32                  page_size       // 记录数量

    255: optional base.Base  Base           
}

// 获取选品任务列表响应
struct GetProductSelectTaskListResponse {
    1: required i32                      code         // 状态码 0: 成功
    2: required string                   msg          // 出错提示消息
    3: required list<ProductSelectTask>  data         // 返回结果
    4: required i64                      total_count  // 总记录数

    255: optional base.BaseResp          BaseResp    
}

//  -----------------------------  选品任务详情查询接口  ------------------
// 获取选品任务详情请求
struct GetProductSelectTaskDetailRequest {
    1: string                task_id  // 任务id

    255: optional base.Base  Base    
}

// 获取选品任务详情响应
struct GetProductSelectTaskDetailResponse {
    1: required i32                code      // 状态码 0: 成功
    2: required string             msg       // 出错提示消息
    3: required ProductSelectTask  data      // 返回结果
    4: optional list<dimensions.SelectedDimensionInfo> dimensions      // 选品规则列表

    10: map<PageModuleType, SelectedPageModuleConfig> selected_page_module_config // 页面模块配置

    255: optional base.BaseResp    BaseResp
}

// 获取商品详情列表请求
struct GetProdDetailListRequest{
    1: ProdDetailBaseRequest base_req      // 基础请求参数

    10: base.PageInfo page_req             // 分页信息
    11: optional base.OrderByInfo order_by // 排序参数, 不传的话默认根据曝光PV倒排

    255: optional base.Base Base
}

// 商品详情基础请求参数
struct ProdDetailBaseRequest{
    1: optional string start_date          // 开始日期
    2: optional string end_date            // 结束日期
    3: optional string task_id             // 任务ID
    4: optional list<dimensions.SelectedDimensionInfo> dimensions // 筛选字段列表
}

// 获取商品详情列表响应
struct GetProdDetailListResponse{
    1: required i32 code                     // 状态码 0: 成功
    2: required string msg                   // 出错提示消息
    3: required GetProdDetailListData data   // 返回结果

    255: base.BaseResp BaseResp
}

// 商品详情列表数据
struct GetProdDetailListData {
    1: list<analysis.MultiDimProductInfo> product_list // 商品列表
    2: base.PageResp page_info // 分页信息
}

// 任务预览类型枚举
enum TaskPreviewType {
  ProductTotal = 1  // 圈品数量
  BrandLevelDistribution = 2 // 品牌等级分布
  ShopLevelDistribution = 3  // 店铺类型分布
  IndustryDistribution = 4 // 行业塞道分布
  ShopTotal = 5 // 商家数量
  FirstCategoryTotal = 6 // 一级类目数量
  LeafCategoryTotal = 7 // 叶子类目数量
  BrandTotal = 8 // 品牌数量
  OrderTotal = 9 // 订单数量
  OPGroupDistribution = 10 // 频道大组分布

  HotSaleProductTotal = 11 // 热销商品数量
  HotSaleProductGMV = 12 // 热销商品GMV
  HotSaleProductGMVRate = 13 // 热销商品GMV渗透率
  AdditionProductTotal = 14 // 补品商品数量
  AdditionProductGMV = 15 // 补品商品GMV
  AdditionProductGMVRate = 16 // 补品商品GMV渗透率
  AdditionFrameCount = 17 // 补品覆盖领航框数量
}

// 获取选品任务预览结果请求
struct GetProductSelectTaskPreviewResultRequest {
    1: required PreviewScene preview_scene // 预览场景
    2: optional string       task_id       // 任务id
    3: optional string       start_date    // 指标计算开始时间
    4: optional string       end_date      // 指标计算结束时间
    5: optional list<dimensions.SelectedDimensionInfo>   dimensions         // 选品规则列表
    6: optional list<TaskPreviewType> preview_types // 预览类型列表
    7: optional map<PageModuleType, SelectedPageModuleConfig> selected_page_module_config // 页面模块配置

    10: optional dimensions.BizType bizType // 业务类型

    255: optional base.Base  Base
}

// 获取选品任务预览结果响应
struct GetProductSelectTaskPreviewResultResponse { 
    1: required i32                 code          // 状态码 0: 成功
    2: required string              msg           // 出错提示消息

    5: optional map<TaskPreviewType, analysis.TargetCardEntity> StringResult      // 字符串预览结果
    6: optional map<TaskPreviewType, list<analysis.TargetTrendPoint>> TrendResult // 趋势图预览结果
    7: optional map<TaskPreviewType, price_analysis.PieGraphItem> PieResult       // 饼图预览结果

    255: optional base.BaseResp     BaseResp
}

// 获取用户权限请求
struct GetUserPrivilegeRequest {
    1: dimensions.BizType biz_type // 业务类型：用于确定用户在特定业务下的权限
    2: optional string employee_id // 员工Id：用于标识特定员工的权限

    255: optional base.Base Base // 基础信息
}

struct PrivilegeItem {
    1: optional string data_privilege_id // 数据权限ID
    2: optional string data_privilege_primary_id // 数据数据权限一级ID
    3: optional list<string> data_privilege_secondary_id_list // 数据权限二级ID列表
}

// 获取用户权限响应
struct GetUserPrivilegeResponse {
    1: required i32           code     // 状态码 0: 成功
    2: required string        msg      // 出错提示消息

    5: required PrivilegeType privilege_type      // 用户权限类型：返回用户在指定业务下的权限级别
    6: optional PrivilegeItem can_apply_privilege // 可申请权限
    7: optional PrivilegeItem applied_privilege   // 已申请权限

    255: optional base.BaseResp BaseResp // 基础响应信息
}