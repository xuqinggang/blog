// 商品基础信息
struct ProductBasicInfo {
    1: string id           // 商品id
    2: string name         // 商品名称
    3: list<string> images // 商品图片列表
    4: string main_image          // 商品主图
}

struct SkuClusterInfo {
    1: string sku_id           // 商品id
    2: string sku_name         // 商品名称
    3: double sku_quality_score // 商品质量分
    4: string sku_out_compare_price_tag // 站外比价标签
    5: string sku_in_compare_price_tag // 站内比价标签
    6: string sku_cluster_id // sku簇id
    7: string sku_cluster_name // sku簇名称
    8: double sku_cluster_quality_score // sku簇质量分
}


// 店铺基础信息
struct ShopBasicInfo {
    1: string          id          // 店铺id
    2: string          name        // 店铺名称
    3: string          logo        // 店铺logo
//    4: string          url         // 店铺url
    5: string          level       // 店铺等级
    6: string          type        // 店铺类型
}

// 品牌基础信息
struct BrandBasicInfo {
    1: string id // 品牌id
    2: string name // 品牌名称
    3: string image // 品牌图片
    4: string level // 品牌等级
}

// 活动基础信息
struct ActivityBasicInfo {
    1: string id // 活动id
    2: string name // 活动名称
}

struct ABtestBasicInfo {
    1: string version_id // 实验id
    2: string version_name // 实验名称
    3: string version_start_time // 实验开始时间
    4: string version_end_time // 实验结束时间
    5: string version_status  // 实验状态
    6: string version_link   // 实验链接
    7: string version_type    // 实验类型
}

// 实验
struct LibraBasicInfo {
    1: string flight_id         // 实验id
    2: string flight_name       // 实验名称
    3: string flight_start_time // 实验开始时间
    4: string flight_end_time   // 实验结束时间
    5: string flight_status     // 实验状态
    6: string flight_link       // 实验链接
    7: string flight_type       // 实验类型
    8: list<string> flight_owners       // 实验负责人
}

// 实验组

// 0代表对照，1实验组
enum LibraVersionType {
    ControlGroup
    ExperimentalGroup
}
struct LibraVersionBasicInfo {
    1: string version_id // 实验组id
    2: string version_name // 实验组名称
    3: string version_start_time // 实验组开始时间
    4: string version_end_time // 实验组结束时间
    5: i64 version_sort // 实验组序号
    7: LibraVersionType version_type    // 实验组类型
}

// 商品基础信息
struct SkuBasicInfo {
    1: string id           // 商品id
    2: string name         // 商品名称
    3: string sku_cluster_id // 商品簇id
    4: string sku_cluster_name // 商品簇名称
    5: string out_compare_price_tag // 站外比价
    6: string in_compare_price_tag // 站内比价标签
}