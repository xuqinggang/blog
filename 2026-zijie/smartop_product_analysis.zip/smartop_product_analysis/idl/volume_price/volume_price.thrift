namespace py volume_price
namespace go volume_price

include "../base.thrift"
include "../analysis/analysis.thrift"
include "../dimensions/dimensions.thrift"
include "../basic_info.thrift"

enum LibraType {
    LibraTypeCombination  // 双边分析
    LibraTypeB // B侧收益
    LibraTypeC // C侧收益
    LibraTypeCluster // 簇分流
}

struct GetVolumePriceLibraListRequest {
    1: required string start_date // 起始时间，格式为 yyyy-MM-dd
    2: required string end_date
    3: optional LibraType libra_type // 实验类型

    255: optional base.Base Base
}

// 分析场景：猜喜 or 搜索
enum AnalyzeScenarios {
    All    = -1 // 全量
    Guess  = 0 // 猜喜
    Search = 1 // 搜索
}
struct LibraFlightInfo {
    1: basic_info.LibraBasicInfo flight_info // 实验信息
    2: list<basic_info.LibraVersionBasicInfo> version_list // 实验组列表
    3: AnalyzeScenarios scenarios
    4: string scenarios_name
}
struct GetVolumePriceLibraListData {
    1: list<LibraFlightInfo> libra_list
}
struct GetVolumePriceLibraListResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetVolumePriceLibraListData data

    255: base.BaseResp BaseResp
}

struct LibraParamInfo {
    1: string flight_id // 实验信息
    2: AnalyzeScenarios scenarios // 场景
}
struct VolumePriceLibraParams {
    1: list<string> flight_ids // 实验id
    2: string control_group_version_id // 对照组id
    3: string experimental_group_version_id // 实验组id
    4: list<LibraParamInfo> flight_param_list // 实验信息入参
}

struct VolumePriceCommonRequest {
    1: dimensions.ProductAnalysisBaseStruct base_req
    2: VolumePriceLibraParams libra_param

    255: optional base.Base Base
}

struct GetVolumePriceMarketFunnelTargetData {
    1: list<analysis.TargetCardEntity> target_list
    2: list<analysis.RatioOption> ratio_option // 漏斗图中指标与指标之间的转化率
}

struct GetVolumePriceMarketFunnelTargetResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetVolumePriceMarketFunnelTargetData data

    255: base.BaseResp BaseResp
}

struct LibraVersionListRow {
    1: basic_info.LibraVersionBasicInfo version_basic_info // 实验组信息
    2: list<analysis.TargetCardEntity> target_list // 指标列表，顺序按照设计稿上固定
    50: string prod_tag_code // 查看商品画像的标签
}
struct LibraFlightInfoData {
    1: basic_info.LibraBasicInfo flight_info // 实验信息
    2: list<LibraVersionListRow> version_list // 实验组列表
    3: AnalyzeScenarios scenarios
    4: string scenarios_name
}
struct GetVolumePriceLibraVersionListData {
    1: list<LibraFlightInfoData> libra_list
}
struct GetVolumePriceLibraVersionListResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetVolumePriceLibraVersionListData data

    255: base.BaseResp BaseResp
}

// 实验分层diff接口
enum TargetType {
    PayCnt
    PayAmt
    ShowCnt
}

struct OperatorValue {
    1: i64 value
    2: base.OperatorType operator // 计算符，支持 >=、>、<=、<
}

struct OperatorInfo {
    1: string label
    2: list<OperatorValue> operator_value // 表达式集合
}

struct GetVolumePriceVersionHierarchicalListRequest {
    1: dimensions.ProductAnalysisBaseStruct base_req
    2: VolumePriceLibraParams libra_param
    3: TargetType target_type
    4: list<OperatorInfo> operator_list

    255: optional base.Base Base
}

struct GetVolumePriceVersionHierarchicalConfigRequest {
    1: TargetType target_type

    255: optional base.Base Base
}

struct GetVolumePriceVersionHierarchicalConfigData {
    1: list<OperatorInfo> operator_list
}

struct GetVolumePriceVersionHierarchicalConfigResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetVolumePriceVersionHierarchicalConfigData data

    255: base.BaseResp BaseResp
}

struct GetReversalExperimentRequest{
    1: dimensions.ProductAnalysisBaseStruct base_req
    2: optional string flight_id // 实验信息
    3: optional list<ExperimentCombination> combination // 实验评估对象
    4: ContentType content_type // 载体

    255: optional base.Base Base
}

enum ContentType{
    All
    Video // 短视频
    Live // 直播
    ProductCard // 商品卡
    HardAdVideo // 短视频硬广
}

// 实验评估对象
struct ExperimentCombination{
    1: string name // 评估对象名称
    2: string code // 评估对象ID (新增的分析对象不用传)
    3: bool is_default // 是否默认选择
    4: string expr_group_id // 实验组ID
    5: string compare_group_id // 对照组ID
    6: ExprObjectType object_type // 评估对象的类别
    7: string expr_group_name // 实验组名称
    8: string compare_group_name // 对照组名称
    9: string b_side_libra_id // B侧实验ID
    10: string c_side_libra_id // C侧实验ID
}

enum ExprObjectType{
    BCTwoSide
    BSide
    CSide
}

struct GetReversalExperimentCoreDataResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: ReversalExperimentCoreDataItem data

    255: base.BaseResp BaseResp
}

struct ReversalExperimentCoreDataItem{
    1: list<ReversalExperimentCoreDataRow> object_list, // 评估对象列表
    2: list<ReversalExperimentCoreDataRow> two_side_list // 关联的双边实验枚举列表
}

struct ReversalExperimentCoreDataRow{
    1: list<analysis.TargetCardEntity> target_list
    2: string row_type // object评估对象, two_side双边, single_side单边
    3: string code // 实验组code
    4: string group_name // 实验组名称
    5: string distribution_type // 分流方式
}

struct GetReversalExperimentDetailResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetReversalExperimentDetailItem data

    255: base.BaseResp BaseResp
}

struct GetReversalExperimentDetailItem{
    1: list<ReversalExperimentCoreDataRow> rows // 明细数据
}

struct GetExperimentCombinationResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetExperimentCombinationItem data

    255: base.BaseResp BaseResp
}

struct GetExperimentCombinationItem{
    1: list<ExperimentCombination> combinations // 实验组合列表
    2: bool has_auth // 是否有编辑权限
}

// 双边实验单元格信息
struct GetVolumePriceBilateralLibraRequest {
    1: string start_date // 起始时间，格式为 yyyy-MM-dd
    2: string end_date
    3: string flight_id // 实验ID
    255: optional base.Base Base
}
struct BilateralLibraCell{
    1: ExprObjectType object_type // 评估对象名称
    2: string object_name    // 对象名称
    3: string object_code    // 对象唯一标识
    4: string object_desc    // 对象描述
    5: string c_side_fid     // c侧实验ID(单边实验没有时默认-1)
    6: string c_side_vid     // c侧实验组ID(单边实验没有时默认-1)
    7: string c_side_v_name  // c侧实验组原始name

    11: string b_side_fid     // b侧实验ID(单边实验没有时默认-1)
    12: string b_side_vid     // b侧实验组ID(单边实验没有时默认-1)
    13: string b_side_v_name  // b侧实验组原始name
}
struct VolumePriceBilateralLibraInfo {
    1: bool has_auth // 是否有编辑权限
    2: list<BilateralLibraCell> c_side_list      // c侧实验组列表
    3: list<BilateralLibraCell> b_side_list      // b侧实验组列表
    4: list<BilateralLibraCell> bc_side_list     // 单元格列表
}
struct GetVolumePriceBilateralLibraResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: VolumePriceBilateralLibraInfo data

    255: base.BaseResp BaseResp
}
struct SaveVolumePriceBilateralLibraRequest {
    1: string flight_id // 实验ID
    2: VolumePriceBilateralLibraInfo info

    255: optional base.Base Base
}
struct SaveVolumePriceBilateralLibraResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: bool data // 是否成功

    255: base.BaseResp BaseResp
}

struct SaveExprObjectRequest{
    1: GetReversalExperimentRequest common_req,
    2: list<ExperimentCombination> expr_objects // 分析对象

    255: optional base.Base Base
}

struct SaveExprObjectResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: bool data // 是否成功

    255: base.BaseResp BaseResp
}
