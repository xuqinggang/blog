namespace py great_value_buy
namespace go great_value_buy

include "../base.thrift"
include "../analysis/analysis.thrift"
include "../dimensions/dimensions.thrift"
include "../basic_info.thrift"

enum TargetGranularityType {                               // 指标粒度
    Product = 1,               // 商品
    SkuCluster = 2,            // SKU簇
    BigLinkCluster = 3,        // 聚合链接同款簇
    BigLink = 4,               // 聚合链接
    BigLinkHaveClusterSku = 5, // 聚合链接已建簇SKU
}

struct TargetGranularityInfo {
    1: TargetGranularityType target_granularity,
    2: string target_granularity_name,
    3: TargetGranularityInfo children,
}

enum TargetDrillType {
    DiffValue = 1, // diff绝对值
    DiffRatio = 2, // diff波动
    Value = 3,     // 绝对值
}


enum CoreTreeType {
    DimensionSummary = 1 // 维度汇总
    FunnelAnalysis = 2 // 漏斗分析
}


enum SearchChannelDrillType {
    Enable = 1, // 可以按搜索渠道下钻
    Disable = 0, // 不可
}



enum BigActIncreaseTagType {
     Diff_AccumulateIncreaseGMV, // 大小比较-累计增量GMV比较
     Diff_ValidProdAvgIncreaseGMV, // 大小比较-动销商品品均增量GMV比较
     Ratio_AccumulateGMVInOverallRate, // 比例比较-累计GMV占比大盘阈值
     Ratio_AccumulateGMVInOverallTotalRate, // 比例比较-累计GMV占比大盘整体阈值
}

// 操作符类型
enum ThresholdOperatorType {
    GREATER_EQUAL_THAN,
    LESS_EQUAL_THAN,
    GREATER_THAN,
    LESS_THAN,
}

struct BigActIncreaseTagConfig {
    1: BigActIncreaseTagType big_act_increase_tag_type,
    2: optional ThresholdOperatorType operate_type,
    3: optional double threshold_value,
}

struct GOVTargetConfig {
    1: bool act_need_gov,
    2: bool overall_need_gov,
}


struct TargetConfigData {
    1: GOVTargetConfig gov_target_config,
    2: BigActIncreaseTagConfig big_act_increase_tag_config,
}

struct GetGreatValueBuyCommonRequest {
    1: dimensions.ProductAnalysisBaseStruct base_req,
    2: bool need_trend,                                                      // 是否需要趋势图
    3: bool need_cycle,                                                      // 需要环比
    4: bool need_sync,                                                       // 是否需要同比
    5: list<TargetGranularityType> target_granularity_list,                  // 指标粒度
    6: list<GetGreatValueBuyDiagnosisTopicTargetInfo> diagnosis_target_list, // 诊断指标
    7: list<GetGreatValueBuyDiagnosisTargetType> target_type_list,           // 指标计算方式
    8: TargetDrillType target_drill_type,                                    // 下钻类型
    9: optional list<string> select_sku_id_list,                              // 筛选的sku_id
    10: optional list<string> common_select_list,                             //筛选的选项
    11: optional list<OptimizeItem> optimize_items                            // 可优化项
    12: optional list<CrmTask> crm_actions                                    // CRM任务
    13: optional CoreTreeType core_tree_type                                  // 归因树类型
    14: list<analysis.TargetCardEntity> dependent_target_list                  // 依赖指标
    15: bool need_total                                                        // 是否需要整体卡片
    16: optional TargetConfigData target_config_list                         // 指标配置

    100: optional base.PageInfo page_req
    101: optional base.OrderByInfo order_by
    102: analysis.OverallCommonRequest overall_common_req

    255: optional base.Base Base,
}

struct GetGreatValueBuyDiagnosisConfigDataRequest {
    1: dimensions.BizType biz_type,
}

// 供给分析
struct GetGreatValueBuySupplyAnalysisTarget {
    1: analysis.TargetCardEntity target,                            //
    2: dimensions.DimensionInfo dimension_info,                     //结构体返回
    3: list<GetGreatValueBuySupplyAnalysisTarget> children_targets,
}

struct GetGreatValueBuySupplyAnalysisData {
    1: list<GetGreatValueBuySupplyAnalysisTarget> target_list, // 指标列表
}

struct GetGreatValueBuySupplyAnalysisResponse {
    1: required i32 code,
    2: required string msg,
    3: required GetGreatValueBuySupplyAnalysisData data,
    4: base.BaseResp BaseResp,
}

// 归因树
struct GetGreatValueBuyAttributionCoreTreeData {
    1: string name,
    2: list<analysis.TargetCardEntity> target_list,
    3: list<GetGreatValueBuyAttributionCoreTreeData> children,
    4: string code,
    5: string dim_key // 维度标识
    6: string prod_tag_code // 查看商品画像的标签
}

struct GetGreatValueBuyAttributionCoreTreeDataList {
    1: list<GetGreatValueBuyAttributionCoreTreeData> data_list,
}

struct GetGreatValueBuyAttributionCoreTreeResponse {
    1: required i32 code,                                         // 状态码 0: 成功
    2: required string msg,                                       // 出错提示消息
    3: required GetGreatValueBuyAttributionCoreTreeDataList data, // 返回结果
    255: base.BaseResp BaseResp,
}

// 指标计算方式
enum GetGreatValueBuyDiagnosisTargetType {
    CurrValue = 1,            // A
    CompareValue = 2,         // B
    CurrMarketPercent = 3,    // 占比
    CurrDiffCompareValue = 4, // A-B
    CurrDiffCompareRatio = 5, // (A-B)/A
}

struct GetGreatValueBuyDiagnosisTargetTypeInfo {
    1: GetGreatValueBuyDiagnosisTargetType target_type,
    2: string target_type_name,
    3: string field_path,                               // 字段路径
}

struct DrillDimension {
    1: string dimension_name,                     // 一二级坑位，一二级模块
    2: list<dimensions.DimensionInfo> drill_list,
}

enum GetGreatValueBuyDiagnosisTopicTargetType {                        // 诊断指标类型
    ClusterDiff = 1,    // 跟同款簇对比
    WholeDiff = 2,      // 跟大盘对比
    ClusterAvgDiff = 3, // 簇均链接数对比
    CommonScore = 4,    // 质量分
    CommonPrice = 5,    // 价格
    SearchOptimize = 6, // 搜索优化
    SearchSupply = 7,   // 搜索供给
    SearchQueryCnt = 8,    // 搜索query数
    SearchTopQueryCnt = 9, // 搜索TopQuery数

    SearchKeyInSupplyProdCnt = 10, // 重点引入供给
    SearchSuggestInSupplyProdCnt = 11, // 建议引入供给

    BigActivityShowPvDiagnosis = 12, // 曝光诊断
    BigActivityGpmQualityDiagnosis = 13, // 质量分诊断
    BigActivityGpmContentPvDiagnosis = 14, // 内容曝光
    BigActivityOpportunityProdDiagnosis = 15,  // 机会品诊断
    BigActivityProdCommissionDiagnosis = 16, // 佣金率诊断
}

enum DiagnosisTopicTargetActionType {
    NoAction = 0, // 无动作
    Drill = 1, // 下钻
    Query = 2, // query清单
}

struct SuggestAction{
    1: string action_name  // 动作名称
    2: OptimizeItem optimize_item // 优化项
    3: CrmTask crm_task // CRM任务
}


struct GetGreatValueBuyDiagnosisTopicTargetInfo {
    1: GetGreatValueBuyDiagnosisTopicTargetType target_type,
    2: string target_display_name,                           // 指标展示名称（中文）
    3: string target_name,                                   // 字段名
    4: DiagnosisTopicTargetActionType action_type,           // 动作类型
    5: bool enable_diagnosis   // 是否可以诊断
    6: string prod_detail_button_name // 商品明细按钮名称
    7: string label_decision_target // 标签决策指标
    8: SuggestAction suggest_action // 建议动作
    9: list<dimensions.SelectedDimensionInfo> bind_dimension_list // 绑定维度
    10: list<dimensions.DimensionInfo> drill_list // 下钻维度
    11: SearchChannelDrillType enable_search_channel_analysis   // 1支持诊断归因指标按照渠道下钻
    12: optional i64  sub_scenario_info  // for商品详情的诊断
}

struct GetGreatValueBuyDiagnosisTopic {
    1: string topic_name,
    3: list<GetGreatValueBuyDiagnosisTopicTargetInfo> target_list,
}

struct AnalysisMethod{
    1: string method_name
    2: bool disabled
    3: list<string> target_name_list
}

struct GetGreatValueBuyDiagnosisTopicDimList {
    1: GetGreatValueBuyDiagnosisTopicTargetType target_type,
    2: list<dimensions.DimensionInfo> drill_list,
}

struct GetGreatValueBuyTargetConfig {
    1: list<dimensions.TargetMetaInfo> show_target_list,               // 展示指标
    2: list<GetGreatValueBuyDiagnosisTargetTypeInfo> target_type_list, // 指标计算类型
    3: list<TargetGranularityInfo> target_granularity_list,            // 指标粒度
    4: list<string> default_show_target_list,       // 默认展示指标
    5: list<string> first_show_target              //  优先展示指标
    6: list<AnalysisMethod> analysis_methods       //  漏斗层分析方式
}

// 优化动作配置
struct OptimizeActionConfig{
    1: list<OptimizeItem> optimize_items
    2: list<CrmTask> crm_actions
    3: map<string, string> optimize_crm_map
}

struct GetGreatValueBuyDiagnosisConfigData {
    1: list<GetGreatValueBuyDiagnosisTopic> topic_list,
    2: list<GetGreatValueBuyDiagnosisTopicTargetInfo> common_diagnosis_target_list, // 通用诊断指标（聚合链接）
    3: GetGreatValueBuyTargetConfig target_config,
    4: list<DrillDimension> tree_drill,
    5: OptimizeActionConfig optimize_action_config
    6: list<GetGreatValueBuyDiagnosisTopicDimList> topic_dim_list,

}

struct GetGreatValueBuyDiagnosisConfigResponse {
    1: required i32 code,                                 // 状态码 0: 成功
    2: required string msg,                               // 出错提示消息
    3: required GetGreatValueBuyDiagnosisConfigData data, // 返回结果
    255: base.BaseResp BaseResp,
}

// 指标列表
struct GetGreatValueBuyDiagnosisCommonCoreOverviewData {
    1: list<analysis.TargetCardEntity> target_list,
}

struct GetGreatValueBuyDiagnosisCommonCoreOverviewResponse {
    1: required i32 code,                                             // 状态码 0: 成功
    2: required string msg,                                           // 出错提示消息
    3: required GetGreatValueBuyDiagnosisCommonCoreOverviewData data, // 返回结果
    255: base.BaseResp BaseResp,
}

struct GetGreatValueBuyDiagnosisMultiDimensionData {
    2: list<GetGreatValueBuyMultiDimRow> rows,
}

struct GetGreatValueBuyDiagnosisMultiDimensionResponse {
    1: required i32 code,                                         // 状态码 0: 成功
    2: required string msg,                                       // 出错提示消息
    3: required GetGreatValueBuyDiagnosisMultiDimensionData data, // 返回结果
    255: base.BaseResp BaseResp,
}

// 数据透视表（多维下钻）
struct GetGreatValueBuyMultiDimRow {
    1: string display_name,
    2: string enum_value,
    3: list<analysis.TargetCardEntity> target_list,
    4: list<GetGreatValueBuyMultiDimRow> children,
    5: string dim_key // 维度标识
    6: string prod_tag_code // 查看商品画像的标签
    7: dimensions.DimensionInfo dimension_info
    8: string bigact_increase_tag // 大促商品增量标签 （大促商品增量GMV贡献达标、大促商品增量GMV贡献不足）
}

struct GetGreatValueBuyMultiDimensionData {
    1: GetGreatValueBuyMultiDimRow total,
    2: list<GetGreatValueBuyMultiDimRow> rows,
}

struct GetGreatValueBuyMultiDimensionResponse {
    1: required i32 code,                                // 状态码 0: 成功
    2: required string msg,                              // 出错提示消息
    3: required GetGreatValueBuyMultiDimensionData data, // 返回结果
    255: base.BaseResp BaseResp,
}

struct GreatValueBuyDiagnosisProductData {
    1: basic_info.ProductBasicInfo product_info,
    2: list<analysis.TargetCardEntity> target_list,
    3: basic_info.SkuClusterInfo sku_cluster_info,
}

// 单品诊断
struct GetGreatValueBuyDiagnosisProductData {
    1: list<GreatValueBuyDiagnosisProductData> full_list
    2: base.PageResp page_info // 分页信息
}

struct GetGreatValueBuyDiagnosisProductListResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required GetGreatValueBuyDiagnosisProductData data, // 返回结果
    255: base.BaseResp BaseResp,
}

struct GetGreatValueBuyMultiDimTrendInfo {
    1: list<analysis.TargetTrendPoint> target_list
    2: string target_name
    3: string enum_value
}
struct GetGreatValueBuyMultiDimTrendData {
    1: list<GetGreatValueBuyMultiDimTrendInfo> trend_list
}
struct GetGreatValueBuyMultiDimTrendResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetGreatValueBuyMultiDimTrendData data

    255: base.BaseResp BaseResp
}

struct GetGreatValueBuyDiagnosisProductListTrendData {
    1: list<GetGreatValueBuyMultiDimTrendInfo> trend_list
}

struct GetGreatValueBuyDiagnosisProductListTrendResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required GetGreatValueBuyDiagnosisProductListTrendData data, // 返回结果

    255: base.BaseResp BaseResp
}


// 单品诊断-返回sql接口
struct GetGreatValueBuyProdSQLResponse {
    1: required i32 code
    2: required string msg
    3: required string  data
    4: base.BaseResp BaseResp
}

struct GetGreatValueBuyQueryAnalysisTarget {
   1: string query_name
   2: list<analysis.TargetCardEntity> target_list

}
struct GetGreatValueBuyQueryAnalysisData {
  1: list<GetGreatValueBuyQueryAnalysisTarget> query
  2: base.PageResp page_info // 分页信息
}

// query 诊断-返回query info list
struct GetGreatValueBuyQueryAnalysisResponse {
    1: required i32 code
    2: required string msg
    3: required GetGreatValueBuyQueryAnalysisData data
    4: base.BaseResp BaseResp
}
// Query 导出接口
struct GetQueryReportTableDownloadResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: bool data // 是否发起下载任务成功
    255: base.BaseResp BaseResp
}

struct GetGreatValueBuyQueryProdsAnalysisTarget {
   1: basic_info.ProductBasicInfo product_info
   2: list<analysis.TargetCardEntity> target_list
   3: string query_name

}
struct GetGreatValueBuyQueryProdAnalysisData {
  1: list<GetGreatValueBuyQueryProdsAnalysisTarget> prods
  2: base.PageResp page_info // 分页信息
}
// query 诊断下- 返回prod info list
struct GetGreatValueBuyQueryProdAnalysisResponse {
    1: required i32 code
    2: required string msg
    3: required GetGreatValueBuyQueryProdAnalysisData data
    4: base.BaseResp BaseResp
}

// Query 下 商品导出接口
struct GetProductReportTableDownloadResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: bool data // 是否发起下载任务成功
    255: base.BaseResp BaseResp
}


// query 下
struct GetGreatValueBuyDiagnosisQuerySearchCntTrendResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required GetGreatValueBuyDiagnosisProductListTrendData data, // 返回结果

    255: base.BaseResp BaseResp
}

struct GetGreatValueBuyQuerySearchWordsData {
    1: list<dimensions.EnumElement> search_words,
    2: base.PageResp page_info // 分页信息
}

struct GetGreatValueBuyQuerySearchWordsResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required GetGreatValueBuyQuerySearchWordsData data, // 返回结果

    255: base.BaseResp BaseResp
}


struct  GetMultiDimCoreConclusion{
    1: list<dimensions.SelectedDimensionInfo> dimensions // 人货场属性筛选
    2: string conclusion_format_text
}


struct GetMultiDimCoreConclusionGroup{
    1: string name
    2: GetMultiDimCoreConclusion conclusions
}

struct GetMultiDimCoreConclusionData {
    1: list<GetMultiDimCoreConclusionGroup> group_list
}

struct GetGreatValueBuyCommonConclusionResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required GetMultiDimCoreConclusionData data, // 返回结果

    255: base.BaseResp BaseResp
}

struct OptimizeItem {
    1: string code
    2: string name
}

struct CrmTask {
    1: string code
    2: string name
}



struct OptimizeItemDetail{
    1: OptimizeItem optimize_item
    2: CrmTask crm_task
    3: i64 can_optimize_prod_cnt    // 可优化商品数
    4: double big_promotion_rate    // 占比大促商品
    5: string gmv_revenue           // gmv 收益
}



struct GetOptimizeItemDetailData{
    1: list<OptimizeItemDetail> optimize_item_detail_list
    2: base.PageResp page_info // 分页信息
}


struct GetOptimizeItemDetailResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required GetOptimizeItemDetailData data, // 返回结果
    255: base.BaseResp BaseResp
}

struct GetOptimizeProductDetail {
    1: basic_info.ProductBasicInfo product_info
    2: OptimizeItem optimize_item
    3: CrmTask crm_task
    4: list<analysis.TargetCardEntity> target_list
}

struct GetOptimizeProductDetailData{
    1: list<GetOptimizeProductDetail> prods // 商品列表
    2: base.PageResp page_info              // 分页信息
}

struct GetOptimizeProductDetailResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required GetOptimizeProductDetailData data,         // 返回结果

    255: base.BaseResp BaseResp
}

struct GetOptimizeProductDetailDownloadResponse{
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required bool data,                                 // 下载结果

    255: base.BaseResp BaseResp
}

struct OptimizeActionInfo {
	1: OptimizeItem        optimize_item
	2: CrmTask             crm_task
	3: string              estimate_increase_gmv  // 预估增量GMV
}

struct DimensionActionIncomeSummary {
    1: list<dimensions.DimensionInfo> reach_dimensions,
    2: list<dimensions.DimensionInfo> non_reach_dimensions,
    3: list<OptimizeActionInfo> optimize_infos,
    4: string estimate_accumulate_gmv,
    5: string estimate_accumulate_increase_gmv,
    6: string estimate_accumulate_gmv_burst_rate,
}

struct GetOptimizeActionInfoResponse {
    1: required i32 code,                                  // 状态码 0: 成功
    2: required string msg,                                // 出错提示消息
    3: required DimensionActionIncomeSummary data,         // 返回结果
    255: base.BaseResp BaseResp
}

struct LarkUnit {
    1: required string id,
    2: required string name,
}

struct SendAttributionReportRequest {
    1: required GetGreatValueBuyCommonRequest originReq,
    2: required list<LarkUnit> users,
    3: required list<LarkUnit> groups,
    4: required string resId,
    5: required bool isTest,
    255: optional base.Base Base,
}

struct SendAttributionReportResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}