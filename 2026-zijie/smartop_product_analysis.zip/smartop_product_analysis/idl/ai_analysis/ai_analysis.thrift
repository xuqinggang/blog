namespace py ai_analysis
namespace go ai_analysis

include "../base.thrift"
include "../attribution/attribution.thrift"
include "../dimensions/dimensions.thrift"

struct STDIOServerConfig {
    1: required string command,
    2: required list<string> args,
    3: optional map<string, string> env,
}

struct SSEServerConfig {
    1: required string url,
    2: optional list<string> headers,
}

struct ArtificialIntelligenceConfig {
    1: required string sophon_key,
    2: required map<string, string> sophon_api_map,
    3: required map<string, string> extra_info,
    4: required map<string, string> model,
    5: optional map<string, SSEServerConfig> mcp_server_sse,     // mcp sse配置
    6: optional map<string, STDIOServerConfig> mcp_server_stdio, // mcp stdio配置
    7: optional map<string, list<string>> mcp_server_psm,        // faas mcp psm列表
}

struct ByteRAGConfig {
    1: required string token,
    2: required string auth_id,
    3: required map<string, string> dataset,
}

struct ArkConfig {
    1: required string api_key,
    2: required map<string, string> endpoint,
    3: required string access_key,
    4: required string secret_key,
    5: required string knowledge_resource_id,
}

struct FornaxConfig {
    1: required string access_key,
    2: required string secret_key,
}

struct DorisConfig {
    1: required string user,
    2: required string password,
    3: required string psm,
}

struct AIResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    3: required string data,              // 返回结果
    255: required base.BaseResp BaseResp,
}

struct SessionInfo {
    1: required string session_id (go.tag = "bson:\"session_id\" json:\"session_id\""),                      // 会话的唯一标识
    2: required string creator (go.tag = "bson:\"creator\" json:\"creator\""),                               // 会话的创建人employeeId
    3: required string create_time (go.tag = "bson:\"create_time\" json:\"create_time\""),                   // 会话创建时间，格式为 "2006-01-02 15:04:05"
    4: optional string update_time (go.tag = "bson:\"update_time\" json:\"update_time\""),                   // 会话更新时间，格式为 "2006-01-02 15:04:05"
    5: optional string name (go.tag = "bson:\"name\" json:\"name\""),                                        // 会话名称（通过AI自动生成）
    6: optional string parent_session_id (go.tag = "bson:\"parent_session_id\" json:\"parent_session_id\""), // 父会话ID，用于克隆会话
    7: optional list<string> operator (go.tag = "bson:\"operator\" json:\"operator\""),                      // 会话的操作人employeeId列表
}

struct CreateSessionRequest {
    1: optional string share_session_id, // 分享会话ID
    2: optional string name,             // 会话名称
    255: optional base.Base Base,
}

struct CreateSessionResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    3: required string session_id,        // 返回结果
    255: required base.BaseResp BaseResp,
}

struct DeleteSessionRequest {
    1: required string session_id, // 会话的唯一标识
    255: optional base.Base Base,
}

struct DeleteSessionResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct GetSessionListRequest {
    1: optional base.PageInfo page_info, // 页数 从1开始
    255: optional base.Base Base,
}

struct GetSessionListResponseData {
    1: required list<SessionInfo> session_list, // 返回结果
    2: required base.PageResp page_resp,
}

struct GetSessionListResponse {
    1: required i32 code,                        // 状态码 0: 成功
    2: required string msg,                      // 出错提示消息
    3: required GetSessionListResponseData data, // 返回结果
    255: required base.BaseResp BaseResp,
}

struct UpdateSessionNameRequest {
    1: required string session_id, // 会话的唯一标识
    2: required string name,       // 会话名称
    255: optional base.Base Base,
}

struct UpdateSessionNameResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct FunctionCall {
    1: optional string name (go.tag = "bson:\"name\" json:\"name\""),                // 函数的名称
    2: optional string arguments (go.tag = "bson:\"arguments\" json:\"arguments\""), // 函数的参数，JSON 格式的字符串
}

struct ToolCall {
    1: required string id (go.tag = "bson:\"id\" json:\"id\""),                         // 工具调用的唯一标识
    2: required string type (go.tag = "bson:\"type\" json:\"type\""),                   // 工具调用的类型，取值为 "function"
    3: required FunctionCall function (go.tag = "bson:\"function\" json:\"function\""), // 工具调用的函数
}

struct TokenUsage {
    1: required i64 prompt_tokens (go.tag = "bson:\"prompt_tokens\" json:\"prompt_tokens\""),             // 输入的 prompt token 数量
    2: required i64 completion_tokens (go.tag = "bson:\"completion_tokens\" json:\"completion_tokens\""), // 模型生成的 token 数量
    3: required i64 total_tokens (go.tag = "bson:\"total_tokens\" json:\"total_tokens\""),                // 本次请求消耗的总 token 数量（输入 + 输出）
}

struct ResponseMeta {
    1: optional string finish_reason (go.tag = "bson:\"finish_reason\" json:\"finish_reason\""), // 模型停止生成 token 的原因，取值为 "stop"、"length"、"function_call"、"content_filter"
    2: optional TokenUsage usage (go.tag = "bson:\"usage\" json:\"usage\""),                     // 用量信息
}

struct ChatMessage {
    1: required string message_id (go.tag = "bson:\"message_id\" json:\"message_id\""),                                   // 消息的唯一标识
    2: required string session_id (go.tag = "bson:\"session_id\" json:\"session_id\""),                                   // 消息所属的会话的唯一标识
    3: required string role (go.tag = "bson:\"role\" json:\"role\""),                                                     // 消息的角色，取值为 "user"、"assistant"、"system"、"tool"
    4: required string content (go.tag = "bson:\"content\" json:\"content\""),                                            // 消息的内容，文本格式
    5: required MessageType type (go.tag = "bson:\"type\" json:\"type\""),                                                // 消息的类型
    6: required string name (go.tag = "bson:\"name\" json:\"name\""),                                                     // 消息的名称，用于区分不同的消息
    7: optional string parent_message_id (go.tag = "bson:\"parent_message_id\" json:\"parent_message_id\""),              // 父消息的唯一标识
    8: required string create_time (go.tag = "bson:\"create_time\" json:\"create_time\""),                                // 消息创建时间，格式为 "2006-01-02 15:04:05"
    9: optional string update_time (go.tag = "bson:\"update_time\" json:\"update_time\""),                                // 消息更新时间，格式为 "2006-01-02 15:04:05"
    10: optional string reasoning_content (go.tag = "bson:\"reasoning_content\" json:\"reasoning_content\""),             // 推理内容（cot），只对type为assistant的消息有效
    11: optional list<DataInfo> data (go.tag = "bson:\"data\" json:\"data\""),                                            // 数据列表
    12: optional list<FileInfo> files (go.tag = "bson:\"files\" json:\"files\""),                                         // 文件列表
    13: optional SimpleFramework analysis_framework (go.tag = "bson:\"analysis_framework\" json:\"analysis_framework\""), // 分析思路
    14: optional list<ChatMessage> child_messages (go.tag = "bson:\"child_messages\" json:\"child_messages\""),           // 子消息列表
    15: required bool no_wrap (go.tag = "bson:\"no_wrap\" json:\"no_wrap\""),                                             // 是否无需包裹，针对ToolStart和ToolEnd消息有效
    16: optional list<ToolCall> tool_calls (go.tag = "bson:\"tool_calls\" json:\"tool_calls\""),                          // 工具调用列表
    17: required i32 order (go.tag = "bson:\"order\" json:\"order\""),                                                    // 消息的顺序，用于排序
}

enum MessageType {
    Unknown = 0,
    User = 1,      // 用户消息
    LLM = 2,       // 大模型消息
    ToolStart = 3, // 工具调用开始消息
    ToolEnd = 4,   // 工具调用结束消息
    # Plan = 5,      // 计划消息（容器）
    Task = 6,      // 任务消息（容器）
    Assistant = 7, // 助手消息（容器）
}

struct ContextMessage {
    1: required string message_id (go.tag = "bson:\"message_id\" json:\"message_id\""),                       // 消息的唯一标识
    2: required string session_id (go.tag = "bson:\"session_id\" json:\"session_id\""),                       // 消息所属的会话的唯一标识
    3: required string role (go.tag = "bson:\"role\" json:\"role\""),                                         // 消息的角色，取值为 "user"、"assistant"、"system"、"tool"
    4: required string content (go.tag = "bson:\"content\" json:\"content\""),                                // 消息的内容，文本格式
    5: optional string name (go.tag = "bson:\"name\" json:\"name\""),                                         // 消息的名称，用于区分不同的消息
    6: optional list<ToolCall> tool_calls (go.tag = "bson:\"tool_calls\" json:\"tool_calls\""),               // 工具调用列表
    7: optional string tool_call_id (go.tag = "bson:\"tool_call_id\" json:\"tool_call_id\""),                 // 工具ID，用于工具返回的消息中
    8: optional string tool_name (go.tag = "bson:\"tool_name\" json:\"tool_name\""),                          // 工具名称，用于区分不同的工具
    9: optional map<string, string> extra (go.tag = "bson:\"extra\" json:\"extra\""),                         // 额外信息，例如 ark-reasoning-content、ark-request-id 等
    10: optional ResponseMeta response_meta (go.tag = "bson:\"response_meta\" json:\"response_meta\""),       // 响应元信息，包括用量信息、模型停止生成 token 的原因、方舟 request_id 等
    11: required string create_time (go.tag = "bson:\"create_time\" json:\"create_time\""),                   // 消息创建时间，格式为 "2006-01-02 15:04:05"
    12: optional string update_time (go.tag = "bson:\"update_time\" json:\"update_time\""),                   // 消息更新时间，格式为 "2006-01-02 15:04:05"
    13: optional string reasoning_content (go.tag = "bson:\"reasoning_content\" json:\"reasoning_content\""), // 推理内容（cot），只对type为assistant的消息有效
}

struct GetSessionInfoRequest {
    1: required string session_id, // 会话的唯一标识
    255: optional base.Base Base,
}

struct GetSessionInfoResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    3: required SessionInfo data,         // 返回结果
    255: required base.BaseResp BaseResp,
}

struct GetSessionMessagesRequest {
    1: required string session_id, // 会话的唯一标识
    255: optional base.Base Base,
}

struct GetSessionMessagesResponseData {
    1: optional list<ChatMessage> messages, // 返回结果
}

struct GetSessionMessagesResponse {
    1: required i32 code,                            // 状态码 0: 成功
    2: required string msg,                          // 出错提示消息
    3: required GetSessionMessagesResponseData data, // 返回结果
    255: required base.BaseResp BaseResp,
}

enum AIAnalysisType {
    Unknown = 0,
    Diagnosis = 1,       // 大盘、猜喜异动归因
    ProductAnalysis = 2, // 货品分析
}

struct DataInfo {
    1: required list<list<string>> data, // 查询到的数据
    2: required string description,      // 数据描述
    3: optional string object_key,       // 当前数据查询结果在TOS中的key
}

struct FileInfo {
    1: required string object_key, // 当前数据查询结果在TOS中的key
    2: required string file_name,  // 文件名称
    3: required string file_type,  // 文件类型
    4: required string url,        // 文件url
}

struct SimpleFramework {
    1: required string framework_id,      // 分析思路id
    2: required string framework_name,    // 分析思路名称
    3: required string framework_content, // 分析思路内容
}

struct AIAnalysisRequest {
    1: required string query,                        // 用户问题
    2: required string employee_id,                  // 用户employee_id
    3: required dimensions.BizType biz_type,         // 业务类型
    4: required AIAnalysisType type,                 // 分析类型
    5: required string base_req,                     // 筛选条件（JSON格式）TODO：后续变成optional
    6: optional string query_id,                     // 查询id
    7: optional string session_id,                   // 会话的唯一标识，如果没有则创建新会话
    8: optional list<DataInfo> data,                 // 额外数据
    9: optional string share_session_id,             // 分享的会话id
    10: optional string checkpoint_id,               // 检查点id
    11: optional SimpleFramework analysis_framework, // 分析思路
    12: optional list<FileInfo> files,               // 额外文件
    255: optional base.Base Base,
}

struct AIErrorResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct AIStreamResponse {
    1: required string data (agw.target = "sse", agw.key = "data"),   // 返回结果，json字符串（https://bytedance.larkoffice.com/docx/Mmm8duWFlovXJBxwWSTcdJhxnTe）
    2: required string Event (agw.target = "sse", agw.key = "event"), // 声明映射为sse字段，并使用agw.key重命名，最终对应到sse event（https://bytedance.larkoffice.com/docx/Mmm8duWFlovXJBxwWSTcdJhxnTe）
}

enum FeedbackType {
    POSITIVE = 1, // 正向反馈
    NEGATIVE = 2, // 负向反馈
}

struct FeedbackRequest {
    1: required string message_id, // 消息的唯一标识
    2: required string session_id, // 会话的唯一标识
    3: required FeedbackType type, // 反馈类型，取值为：1: 正向反馈，2: 负向反馈
    4: optional string content,    // 反馈内容，文本格式
    5: optional string reason,     // 反馈原因，文本格式
    255: optional base.Base Base,
}

struct FeedbackResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

enum DatasetType {
    LOCAL_FILE = 0,       // 本地文件
    PRODUCT_ANALYSIS = 1, // 商品流量洞察数据
    AEOLUS_DATASET = 2,   // 风神数据集
    FEISHU_TABLE = 3,     // 飞书表格
}

enum DatasetUpdateType {
    STATIC = 0,  // 静态数据集
    DYNAMIC = 1, // 动态数据集
}

enum ProductDatasetSource {
    MULTI_DIM_ANALYSIS = 0, // 多维度分析数据集
    PRODUCT_METRICS = 1,    // 商品核心指标数据集
    TREND_ANALYSIS = 2,     // 趋势分析数据集
    PRODUCT_RANKING = 3,    // 商品榜单数据集
}

enum AnalysisFrameworkType {
    TEXT = 0,     // 文本
    LARK_DOC = 1, // 飞书文档
}

struct Dataset {
    1: required string dataset_id (go.tag = "bson:\"dataset_id\" json:\"dataset_id\""),                                                    // 数据集ID
    2: required string dataset_name (go.tag = "bson:\"dataset_name\" json:\"dataset_name\""),                                              // 数据集名称
    3: optional string dataset_description (go.tag = "bson:\"dataset_description\" json:\"dataset_description\""),                         // 数据集描述
    4: required string create_time (go.tag = "bson:\"create_time\" json:\"create_time\""),                                                 // 创建时间
    5: optional string update_time (go.tag = "bson:\"update_time\" json:\"update_time\""),                                                 // 更新时间
    6: required string creator (go.tag = "bson:\"creator\" json:\"creator\""),                                                             // 创建者工号
    7: optional string updater (go.tag = "bson:\"updater\" json:\"updater\""),                                                             // 更新者工号
    8: required list<string> owner (go.tag = "bson:\"owner\" json:\"owner\""),                                                             // 负责人工号，多个逗号分割
    9: required DatasetType dataset_type (go.tag = "bson:\"dataset_type\" json:\"dataset_type\""),                                         // 数据源类型，0=本地文件，1=商品流量洞察数据，2=风神数据集，3=飞书表格
    10: optional DatasetUpdateType update_type (go.tag = "bson:\"update_type\" json:\"update_type\""),                                     // 是否动态更新，针对飞书表格数据源有效，0=否，1=是，默认不动态更新
    11: optional ProductDatasetSource product_dataset_source (go.tag = "bson:\"product_dataset_source\" json:\"product_dataset_source\""), // 商品流量洞察数据源类型，只对商品流量洞察数据源生效，0=多维分析，1=货盘核心指标，2=趋势分析，3=商品榜单
    12: optional string dataset_content (go.tag = "bson:\"dataset_content\" json:\"dataset_content\""),                                    // 数据集内容，静态数据，针对本地文件数据源和飞书数据源生效
    13: optional string dataset_config (go.tag = "bson:\"dataset_config\" json:\"dataset_config\""),                                       // 数据集配置，json格式
}

struct CreateDatasetRequest {
    1: required string dataset_name,                         // 数据集名称
    2: optional string dataset_description,                  // 数据集描述
    3: required list<string> owner,                          // 负责人工号，多个逗号分割
    4: required DatasetType dataset_type,                    // 数据源类型，0=本地文件，1=商品流量洞察数据，2=风神数据集，3=飞书表格
    5: optional DatasetUpdateType update_type,               // 是否动态更新，针对飞书表格数据源有效，0=否，1=是，默认不动态更新
    6: optional ProductDatasetSource product_dataset_source, // 商品流量洞察数据源类型，只对商品流量洞察数据源生效，0=多维分析，1=货盘核心指标，2=趋势分析，3=商品榜单
    7: optional string dataset_content,                      // 数据集内容，静态数据，针对本地文件数据源和飞书数据源生效
    8: optional string dataset_config,                       // 数据集配置，json格式
    255: optional base.Base Base,
}

struct CreateDatasetResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct GetDatasetRequest {
    1: optional list<string> dataset_ids, // 数据集ID列表
    2: optional DatasetType dataset_type, // 数据集类型
    3: optional string keyword,           // 搜索关键词
    255: optional base.Base Base,
}

struct GetDatasetResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    3: required list<Dataset> data,       // 返回结果
    255: required base.BaseResp BaseResp,
}

struct UpdateDatasetRequest {
    1: required string dataset_id,                           // 数据集ID
    2: optional string dataset_name,                         // 数据集名称
    3: optional string dataset_description,                  // 数据集描述
    4: optional list<string> owner,                          // 负责人工号，多个逗号分割
    5: optional DatasetType dataset_type,                    // 数据源类型，0=本地文件，1=商品流量洞察数据，2=风神数据集，3=飞书表格
    6: optional DatasetUpdateType update_type,               // 是否动态更新，针对飞书表格数据源有效，0=否，1=是，默认不动态更新
    7: optional ProductDatasetSource product_dataset_source, // 商品流量洞察数据源类型，只对商品流量洞察数据源生效，0=多维分析，1=货盘核心指标，2=趋势分析，3=商品榜单
    8: optional string dataset_content,                      // 数据集内容，静态数据，针对本地文件数据源和飞书数据源生效
    9: optional string dataset_config,                       // 数据集配置，json格式
    255: optional base.Base Base,
}

struct UpdateDatasetResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct DeleteDatasetRequest {
    1: required string dataset_id, // 数据集ID
    255: optional base.Base Base,
}

struct DeleteDatasetResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct AnalysisFramework {
    1: required string framework_id (go.tag = "bson:\"framework_id\" json:\"framework_id\""),                      // 分析思路ID
    2: required string framework_name (go.tag = "bson:\"framework_name\" json:\"framework_name\""),                // 分析思路名称
    3: optional string framework_content (go.tag = "bson:\"framework_content\" json:\"framework_content\""),       // 分析思路内容
    4: required AnalysisFrameworkType framework_type (go.tag = "bson:\"framework_type\" json:\"framework_type\""), // 分析思路类型
    5: required string create_time (go.tag = "bson:\"create_time\" json:\"create_time\""),                         // 创建时间
    6: optional string update_time (go.tag = "bson:\"update_time\" json:\"update_time\""),                         // 更新时间
    7: required string creator (go.tag = "bson:\"creator\" json:\"creator\""),                                     // 创建者工号
    8: optional string updater (go.tag = "bson:\"updater\" json:\"updater\""),                                     // 更新者工号
    9: required list<string> owner (go.tag = "bson:\"owner\" json:\"owner\""),                                     // 负责人工号，多个逗号分割
    10: optional string framework_doc_url (go.tag = "bson:\"framework_doc_url\" json:\"framework_doc_url\""),      // 分析思路文档URL，只有当framework_type为飞书文档时生效
}

struct CreateAnalysisFrameworkRequest {
    1: required string framework_name,                // 分析思路名称
    2: optional string framework_content,             // 分析思路内容
    3: required list<string> owner,                   // 负责人工号，多个逗号分割
    4: required AnalysisFrameworkType framework_type, // 分析思路类型
    5: optional string framework_doc_url,             // 分析思路文档URL，只有当framework_type为飞书文档时生效
    255: optional base.Base Base,
}

struct CreateAnalysisFrameworkResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct GetAnalysisFrameworkRequest {
    1: optional list<string> framework_ids, // 分析思路ID列表
    2: optional string keyword,             // 搜索关键词
    255: optional base.Base Base,
}

struct GetAnalysisFrameworkResponse {
    1: required i32 code,                     // 状态码 0: 成功
    2: required string msg,                   // 出错提示消息
    3: required list<AnalysisFramework> data, // 返回结果
    255: required base.BaseResp BaseResp,
}

struct UpdateAnalysisFrameworkRequest {
    1: required string framework_id,                  // 分析思路ID
    2: optional string framework_name,                // 分析思路名称
    3: optional string framework_content,             // 分析思路内容
    4: optional list<string> owner,                   // 负责人工号，多个逗号分割
    5: optional AnalysisFrameworkType framework_type, // 分析思路类型
    6: optional string framework_doc_url,             // 分析思路文档URL，只有当framework_type为飞书文档时生效
    255: optional base.Base Base,
}

struct UpdateAnalysisFrameworkResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct DeleteAnalysisFrameworkRequest {
    1: required string framework_id, // 分析思路ID
    255: optional base.Base Base,
}

struct DeleteAnalysisFrameworkResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct CheckDocPermissionRequest {
    1: required string doc_url,   // 文档URL
    255: optional base.Base Base,
}

struct CheckDocPermissionResponseData {
    1: required bool has_permission, // 是否有权限
}

struct CheckDocPermissionResponse {
    1: required i32 code,                            // 状态码 0: 成功
    2: required string msg,                          // 出错提示消息
    3: required CheckDocPermissionResponseData data, // 返回结果
    255: required base.BaseResp BaseResp,
}

struct Knowledge {
    1: required string knowledge_id (go.tag = "bson:\"knowledge_id\" json:\"knowledge_id\""),                            // 知识ID
    2: required string knowledge_name (go.tag = "bson:\"knowledge_name\" json:\"knowledge_name\""),                      // 知识名称
    3: required string knowledge_description (go.tag = "bson:\"knowledge_description\" json:\"knowledge_description\""), // 知识描述
    4: required string create_time (go.tag = "bson:\"create_time\" json:\"create_time\""),                               // 创建时间
    5: optional string update_time (go.tag = "bson:\"update_time\" json:\"update_time\""),                               // 更新时间
    6: required string creator (go.tag = "bson:\"creator\" json:\"creator\""),                                           // 创建者工号
    7: optional string updater (go.tag = "bson:\"updater\" json:\"updater\""),                                           // 更新者工号
    8: required list<string> owner (go.tag = "bson:\"owner\" json:\"owner\""),                                           // 负责人工号，多个逗号分割
}

struct CreateKnowledgeRequest {
    1: required string knowledge_name,        // 知识名称
    2: required string knowledge_description, // 知识描述
    3: required list<string> owner,           // 负责人工号，多个逗号分割
    255: optional base.Base Base,
}

struct CreateKnowledgeResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct GetKnowledgeRequest {
    1: optional list<string> knowledge_ids, // 知识ID列表
    2: optional string keyword,             // 搜索关键词
    255: optional base.Base Base,
}

struct GetKnowledgeResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    3: required list<Knowledge> data,     // 返回结果
    255: required base.BaseResp BaseResp,
}

struct UpdateKnowledgeRequest {
    1: required string knowledge_id,          // 知识ID
    2: optional string knowledge_name,        // 知识名称
    3: optional string knowledge_description, // 知识描述
    4: optional list<string> owner,           // 负责人工号，多个逗号分割
    255: optional base.Base Base,
}

struct UpdateKnowledgeResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct DeleteKnowledgeRequest {
    1: required string knowledge_id, // 知识ID列表
    255: optional base.Base Base,
}

struct DeleteKnowledgeResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

struct TosConfig {
    1: required string access_key,  // 访问密钥ID
    2: required string secret_key,  // 访问密钥
    3: required string endpoint,    // TOS 服务端地址
    4: required string bucket_name, // 存储桶名称
    5: required string remote_psm,  // 调用者 PSM
}

struct LibraConfig {
    1: required string app_id,     // 应用ID
    2: required string app_secret, // 应用密钥
    3: required string url,        // 调用地址
}

// AI 提示词变量
typedef map<string, string> PromptVariables

// AI 结论模块枚举值
enum AIConclusionModule {
    Unknown = 0,
    // 货盘复盘-专项-目标分析
    ProdReviewAllowanceTarget = 1,
    // 货盘复盘-专项-供给分析
    ProdReviewAllowanceSupply = 2,
    // 货盘复盘-单一策略-人货场洞察
    ProdReviewSingleStrategyMultiDim = 3,
    // 货盘复盘-单一策略-供给分析
    ProdReviewSingleStrategySupply = 4,
    // 异动归因诊断
    AttributionDiagnosis = 5,
    //货盘复盘-单策略-供给-四象限
    ProdReviewSingleStrategySupplyQuadrant = 6,
    //货盘复盘-单策略-供给-气泡图
    ProdReviewSingleStrategySupplyBubble = 7,
    //货盘复盘-单策略-流量-分布
    ProdReviewSingleStrategyFlowDistribution = 8,
    //货盘复盘-单策略-流量-气泡图
    ProdReviewSingleStrategyFlowBubble = 9,
    //货盘复盘-专项-人货场洞察
    ProdReviewAllowanceMultiDim = 10,
    //货盘复盘-专项-供给-四象限
    ProdReviewAllowanceSupplyQuadrant = 11,
    //货盘复盘-专项-供给-气泡图
    ProdReviewAllowanceSupplyBubble = 12,
    //货盘复盘-专项-流量-分布
    ProdReviewAllowanceFlowDistribution = 13,
    //货盘复盘-专项-流量-气泡图
    ProdReviewAllowanceFlowBubble = 14,
    // 选品任务
    ProductSelectTask = 15,
    // 单策略-漏斗图分析
    ProdReviewSingleStrategyFunnel = 16,
    // 单策略-漏斗下钻分析
    ProdReviewSingleStrategyFunnelDrill = 17,
    // 单策略-商品分化分析
    ProdReviewSingleStrategyProdClassify = 18,
    //专项-漏斗图分析
    ProdReviewSpecialItemFunnel = 20,
    //专项-漏斗下钻分析
    ProdReviewSpecialItemFunnelDrill = 21,
    //专项-商品分化分析
    ProdReviewSpecialItemProdClassify = 22,
    //专项-贡献度分析
    ProdReviewSpecialItemContribution = 23,
    // 货品分析 - 营销引擎- 补贴画像
    ProdAnalysisSubsidyPortrait = 24,
    // 货盘复盘 - 经分实验
    ProdReviewLibraMetricGroupAnalysis = 25,
}

struct AIConclusionRequest {
    1: required string employee_id,    // 用户employee_id
    2: required AIConclusionModule id, // 模块唯一标识
    3: required string req_json,       // 请求体json格式，为了适配更多业务方，需要在取数方法里面解析
    255: optional base.Base Base,
}

struct CoralOpenAPIConfig {
    1: required string auth_key, // 授权密钥
}