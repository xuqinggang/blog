namespace py ai_analysis
namespace go ai_analysis

include "../base.thrift"

// 操作符类型
enum OperatorType {
    GREATER_EQUAL_THAN = 1, // 大于等于
    LESS_EQUAL_THAN = 2,    // 小于等于
    GREATER_THAN = 3,       // 大于
    LESS_THAN = 4,          // 小于
    EQUAL = 5,              // 等于
}

// 评估指标阈值定义
struct Threshold {
    1: required OperatorType operator, // 操作符
    2: required double value,          // 阈值
}

// 评估指标定义
struct EvaluateTargetItem {
    1: required string name,         // 指标名
    2: required string description,  // 指标描述
    3: optional Threshold threshold, // 指标阈值
}

// 评估策略的sql变量定义
struct EvaluateSqlVariable {
    1: required string name,        // 变量名
    2: required string type,        // 变量类型，'string' | 'int'
    3: required string description, // 变量描述
}

// 评估策略的sql模版和变量
struct EvaluateSql {
    1: required string template,                     // 评估策略的sql模版，${xxx}代表变量
    2: required list<EvaluateSqlVariable> variables, // 变量列表
}

// 策略拆分的维度定义
struct StrategyDimension {
    1: required string name,        // 维度名
    2: required string description, // 维度描述
}

// 策略核心观测指标
struct CoreMetric {
    1: required string name,        // 指标名
    2: required string key,         // 指标key
    3: optional string description, // 指标描述
}

// 策略详情
struct StrategyDetail {
    1: required string strategy_key,                      // 策略的唯一标识
    2: required string strategy_desc,                     // 对策略的详细说明
    3: optional string reference_doc,                     // 参考文档，提供提供背景知识、业务知识等
    4: optional string reference_info,                    // 参考信息，提供提供背景知识、业务知识等，和文档同时生效
    5: required list<string> hive_tables,                 // hive数据表，作为策略维度拆分的依据；同时通过数据回溯的方式来验证候选策略的效果，作为验证策略是否可行的依据
    6: required list<EvaluateTargetItem> evaluate_target, // 评估指标，用于执行sql初步评估策略的效果，包括指标、阈值等，作为候选策略的筛选依据
    7: required EvaluateSql evaluate_sql,                 // 评估策略的sql模板和变量，模板使用 Go 语言的模板引擎，通过将策略配置的变量替换到模板中，生成最终的评估sql；执行该sql，得到评估指标的数值
    8: required list<StrategyDimension> dimensions,       // 策略拆分的维度，根据不同的维度取值，组合成不同的策略，例如date_cnt=10, popup_show_cnt=2, popup_close_ratio=1，表示统计10天内弹窗曝光2次且关闭率等于1的用户
    9: required list<CoreMetric> core_metrics,            // 策略核心观测指标，用于开启实验观测策略的效果
    10: required string created_at,                       // 创建时间
    11: required string updated_at,                       // 更新时间
    12: optional list<string> tags,                       // 策略标签，用于筛选策略，多个标签使用逗号分隔
}

// 更新策略请求
struct UpdateStrategyRequest {
    1: required string strategy_key,                      // 策略的唯一标识
    2: optional string strategy_desc,                     // 对策略的详细说明
    3: optional string reference_doc,                     // 参考文档，提供提供背景知识、业务知识等
    4: optional string reference_info,                    // 参考信息，提供提供背景知识、业务知识等，和文档同时生效
    5: optional list<string> hive_tables,                 // hive数据表，作为策略维度拆分的依据；同时通过数据回溯的方式来验证候选策略的效果，作为验证策略是否可行的依据
    6: optional list<EvaluateTargetItem> evaluate_target, // 评估指标，用于执行sql初步评估策略的效果，包括指标、阈值等，作为候选策略的筛选依据
    7: optional EvaluateSql evaluate_sql,                 // 评估策略的sql模板和变量，模板使用 Go 语言的模板引擎，通过将策略配置的变量替换到模板中，生成最终的评估sql；执行该sql，得到评估指标的数值
    8: optional list<StrategyDimension> dimensions,       // 策略拆分的维度，根据不同的维度取值，组合成不同的策略，例如date_cnt=10, popup_show_cnt=2, popup_close_ratio=1，表示统计10天内弹窗曝光2次且关闭率等于1的用户
    9: optional list<CoreMetric> core_metrics,            // 策略核心观测指标，用于开启实验观测策略的效果
    10: optional list<string> tags,                       // 策略标签，用于筛选策略，多个标签使用逗号分隔
    255: optional base.Base Base,
}

struct UpdateStrategyResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

// 创建策略请求
struct CreateStrategyRequest {
    1: required string strategy_key,                      // 策略的唯一标识
    2: required string strategy_desc,                     // 对策略的详细说明
    3: optional string reference_doc,                     // 参考文档，提供提供背景知识、业务知识等
    4: optional string reference_info,                    // 参考信息，提供提供背景知识、业务知识等，和文档同时生效
    5: required list<string> hive_tables,                 // hive数据表，作为策略维度拆分的依据；同时通过数据回溯的方式来验证候选策略的效果，作为验证策略是否可行的依据
    6: required list<EvaluateTargetItem> evaluate_target, // 评估指标，用于执行sql初步评估策略的效果，包括指标、阈值等，作为候选策略的筛选依据
    7: required EvaluateSql evaluate_sql,                 // 评估策略的sql模板和变量，模板使用 Go 语言的模板引擎，通过将策略配置的变量替换到模板中，生成最终的评估sql；执行该sql，得到评估指标的数值
    8: required list<StrategyDimension> dimensions,       // 策略拆分的维度，根据不同的维度取值，组合成不同的策略，例如date_cnt=10, popup_show_cnt=2, popup_close_ratio=1，表示统计10天内弹窗曝光2次且关闭率等于1的用户
    9: required list<CoreMetric> core_metrics,            // 策略核心观测指标，用于开启实验观测策略的效果
    10: optional list<string> tags,                       // 策略标签，用于筛选策略，多个标签使用逗号分隔
    255: optional base.Base Base,
}

struct CreateStrategyResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

// 查询策略详情请求
struct GetStrategyDetailRequest {
    1: required string strategy_key, // 策略的唯一标识
    255: optional base.Base Base,
}

// 查询策略详情响应
struct GetStrategyDetailResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    3: optional StrategyDetail data,      // 策略详情
    255: required base.BaseResp BaseResp,
}

// 批量创建策略配置请求
struct StrategyConfig {
    1: required string strategy_key,         // 策略的唯一标识
    2: required string description,          // 策略配置描述
    3: optional string reason,               // 选取该策略配置的原因和策略配置得分的计算逻辑解释
    4: optional string score,                // 策略配置的综合评估得分，1分为满分，用于横向对比所有候选策略配置
    5: required string config,               // 策略配置参数，key为维度名，value为维度取值，json格式
    6: optional string evaluate_result,      // 策略配置评估结果，json格式
    7: optional i32 is_adopt = 0,            // 是否采用 0: 不采用 1: 采用
    8: optional string reject_reason,        // 不采用原因
    9: optional string strategy_gen_task_id, // 策略生成任务id
}

struct CreateStrategyConfigRequest {
    1: required list<StrategyConfig> strategy_configs, // 策略配置
    255: optional base.Base Base,
}

struct CreateStrategyConfigResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

// AI 策略生成请求
struct AIStrategyGenRequest {
    1: required string strategy_key, // 策略的唯一标识
    2: required string employeeId,   // 员工id
    3: optional string query,        // 策略生成的查询语句
    4: optional string task_name,    // 策略生成任务名称
    5: optional string session_id,   // 会话id
    255: optional base.Base Base,
}

// 不采用策略配置请求
struct RejectStrategyConfigRequest {
    1: required list<string> strategy_config_ids, // 策略配置id列表
    2: required string reject_reason,             // 不采用原因
    255: optional base.Base Base,
}

// 不采用策略配置响应
struct RejectStrategyConfigResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

// 策略关联实验请求
struct StrategyRelation {
    1: required string strategy_config_id, // 策略配置id
    2: required i64 flight_id,             // 实验id
    3: required i64 version_id,            // 实验分组id
    4: optional i32 display_order = 1,     // 展示顺序，默认从1开始
}

// 策略配置关联实验请求
struct CreateStrategyConfigFlightRelationRequest {
    1: required list<StrategyRelation> strategy_relations, // 策略关联实验列表
    255: optional base.Base Base,
}

// 策略配置关联实验响应
struct CreateStrategyConfigFlightRelationResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

// 实验分析输入参数定义
struct FlightAnalysisConfig {
    1: required i64 flight_id,                  // 实验id
    2: required i64 app_id,                     // 应用id
    3: optional string reference_doc,           // 实验背景文档链接
    4: optional string reference_info,          // 实验背景文档补充信息
    5: optional list<MetricGroup> core_metrics, // 核心指标，以指标组为单位
}

/** 指标组 */
struct MetricGroup {
    1: required i64 metric_group_id,        // 指标组ID
    2: required list<i64> metric_id_list,   // 指标ID列表
    3: optional list<Dimension> dimensions, // 维度列表
}

/** 维度 */
struct Dimension {
    1: required string name,                     // 维度名称
    2: required string dim_key,                  // 维度键名
    3: required list<DimensionValue> dim_values, // 维度值列表
}

/** 维度值 */
struct DimensionValue {
    1: required string value_key, // 维度值键名
}

struct FlightAnalysisRequest {
    1: required FlightAnalysisConfig config,
    2: required string employeeId,
    3: optional string query,                // 实验分析的查询语句
    4: optional string task_name,            // 实验分析任务名称
    5: optional string session_id,           // 会话id
    255: optional base.Base Base,
}

// 将实验分析的结果导入长期记忆
struct ImportFlightConclusionRequest {
    1: required list<i64> flight_analysis_ids, // 实验分析id列表
    255: optional base.Base Base,
}

struct ImportFlightConclusionResponse {
    1: required i32 code,                 // 状态码 0: 成功
    2: required string msg,               // 出错提示消息
    255: required base.BaseResp BaseResp,
}

// 流量效率策略生产tcc配置
struct FlowStrategyConfig {
    1: required string flight_metric_sql_template,     // 实验指标取数的sql模版
    2: required list<MetricGroup> flight_core_metrics, // 实验核心指标，以指标组为单位
}