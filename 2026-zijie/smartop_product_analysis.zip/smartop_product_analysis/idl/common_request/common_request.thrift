namespace py common_request
namespace go common_request

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../analysis/analysis.thrift"
include "../basic_info.thrift"
include "../prod_review/prod_review.thrift"
include "../diagnosis/diagnosis.thrift"
include "../module_name/module_name.thrift"



struct CommonAnalysisRequest {
    1: optional  dimensions.ProductAnalysisBaseStruct base_req    // 当前货盘
    2: optional  dimensions.ProductAnalysisBaseStruct compare_req  // 对比货盘
    3: optional  BizExtraInfo biz_extra_info // 业务扩展信息


    255: base.Base Base
}

struct BizExtraInfo {
    1: required module_name.ModuleName module_name
    2: optional prod_review.ProdReviewParams prod_review_params // 商品复盘参数
    3: optional diagnosis.DiagnosisParams diagnosis_params // 诊断参数

    253: optional base.OrderByInfo order_by_info // 排序参数
    254: optional base.PageInfo page_info        // 页数 从1开始
}


// 业务线配置
struct BizConfigRequest {
    1: dimensions.BizType biz_type

    255: base.Base Base
}

