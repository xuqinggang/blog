namespace py dorado_task
namespace go dorado_task

include "../base.thrift"

struct GetDoradoTaskRunningCallBackRequest {
    1: i64 taskId // 任务ID
    2: i64 instanceId // 运行实例ID
    3: i64 projectId // 项目ID
    4: string taskName, // 任务名称
    5: string taskTime, // 任务执行时间 cn: utc+8
    6: i64 instanceStatus // 实例状态
    // 1: "every_failed": "每一次失败",  2: "success": "实例运行成功",  3: "running_timeout": "实例运行时间超过阈值",  4: "retry_failed": "实例重试结束仍失败",  5: "failed_from_n_times": "从第N次重试失败",  6: "latest_not_start": "实例超过设定时间未开始",  7: "latest_not_end": "实例超过设定时间未运行结束",  8: "latest_not_success": "实例超过设定时间未运行成功",  9: "fixed_time_not_success": "实例超过设定截止时间未运行成功");
    7: string region // 取值：cn,i18n,alisg
    8: i64 alarmRuleType
    /*
    *     (1, "every_failed", "每一次失败"),
          (2, "success", "实例运行成功"),
          (3, "running_timeout", "实例运行时间超过阈值"),
          (4, "retry_failed", "实例重试结束仍失败"),
          (5, "failed_from_n_times", "从第N次重试失败"),
          (6, "latest_not_start", "实例超过设定时间未开始"),
          (7, "latest_not_end", "实例超过设定时间未运行结束"),
          (8, "latest_not_success", "实例超过设定时间未运行成功"),
          (9, "fixed_time_not_success", "实例超过设定截止时间未运行成功");
    * */
    9: string scheduleRunTime // 设定的运行时间
    10: string startTime // 开始运行时间
    11: string endTime // 结束运行时间
    12: string businessId // 实例 businessId
    13: string triggerTypeAlias // 任务调度类型
    // 1 system 系统调度, 2 manual 手动调度, 10 rerun 实例重跑, 11 backfill 回溯, 13 debug 任务调试, 14 query 临时查询, 15 trigger 外部触发调度, 16 backfill_split 回溯：下游分批执行,
    14: i64 triggerId // 实例Trigger Id
    15: i64 triggerType // 实例Trigger 类型(例行，重跑等)
    16: i64 retryCount // 第几次重试
    255: optional base.Base  Base,
}

struct GetDoradoTaskRunningCallBackResponse {
    255: optional base.BaseResp  BaseResp
}