namespace py activity_review
namespace go activity_review

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../analysis/analysis.thrift"

// 通用结构体
struct BigPromotionReviewBaseStruct {
    1: required dimensions.BizType biz_type
    3: string start_date // 起始时间，格式为 yyyy-MM-dd
    4: string end_date
    5: optional base.DateType date_type // 日/周/月
    6: optional dimensions.AnalysisGranularity granularity // 分析粒度
    7: required string main_project_id
    8: string main_activity_id
    9: list<string> activity_id
    10: list<string> pick_plan_id_list

    11: string compare_start_date // 对比时间
    12: string compare_end_date // 对比时间
    13: required string compare_main_project_id // 对比项目id
    14: string compare_main_activity_id
    15: list<string> compare_activity_id
    16: list<string> compare_pick_plan_id_list

    30: optional list<dimensions.SelectedDimensionInfo> dimensions // 人货场属性筛选
//    31: optional list<dimensions.ThresholdAttr> threshold_attrs // 指标阈值筛选
    32: optional base.LogicalExprType threshold_expr // 且，或
    33: list<dimensions.SelectedMultiDimensionInfo> group_attrs // 多维分析筛选，按维度顺序
    35: list<string> target_meta_list   //要获取的指标列表，值为业务指标唯一标识的name,传入顺序就是返回顺序
}

struct GetActivityReviewProductSupplyProgressRequest {
    1: BigPromotionReviewBaseStruct base_req
    255: optional base.Base Base
}

struct GetActivityReviewProductSupplyProgressInfo {
    1: string name                     // 指标名
    2: string display_name             // 指标显示名
    5: double value        // 指标整体值
    6: string display_value // 展示值
    7: string unit // 指标单位
}

struct CommonRow {
    1: string enum_value // 维度枚举名（用于传参），例如 male
    2: string display_name // 维度展示名 例如 男性
    20: list<analysis.TargetCardEntity> target_data // 指标信息
}

struct ProductAnalysisHierarchicalInfo {
    1: string name                     // 指标名
    2: string display_name             // 指标显示名
    3: bool show_percent_flag // true 该指标需要展示百分比，false不需要展示百分比
    4: list<analysis.DimensionEntity> dim_hierarchical // 各个维度的分层数据
    5: double value        // 指标整体值
    6: string display_value // 展示值
    7: string unit // 指标单位
}

// 货品供给分析
struct GetActivityReviewProductSupplyProgressData {
    1: string invest_start_date                            // 招商开始时间
    2: string invest_end_date                              // 招商结束时间
    3: double time_progress_percentage                        // 招商时间进度
    4: list<CommonRow> supply_data                // 供给进度列表
}

struct GetActivityReviewProductSupplyProgressResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetActivityReviewProductSupplyProgressData data
    255: base.BaseResp BaseResp
}

struct GetActivityReviewProductAnalysisRequest  {
    1: BigPromotionReviewBaseStruct base_req
    255: optional base.Base Base
}

struct GetActivityReviewProductAnalysisData {
    1: analysis.MultiDimFullListRow total                // 整体流量分析数据
    2: list<analysis.MultiDimFullListRow> fullList                // 多维分析流量分析数据
}

struct GetActivityReviewProductAnalysisResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetActivityReviewProductAnalysisData data
    255: base.BaseResp BaseResp
}

struct GetActivityReviewProductAAAnalysisResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetActivityReviewProductAnalysisData data
    255: base.BaseResp BaseResp
}



// 以下是MVP
struct ProductDim{
    249: optional bool is_new_signup,
    248: optional bool has_subsidy,
    247: optional list<string> first_level_cate_name,
    246: optional list<string> complex_brand_s_level,
    245: optional bool is_sup_purchase_3k_prod,
    244: optional bool is_sup_purchase_k300_prod,
    243: optional bool is_super_subsidy_white_prod,
}
struct CreateActivityReviewMeta {
    1: required string activity_tag,                  #  大的业务类型
    2: required string activity_sub_tag,              // 子业务类型
    3: required string activity_id,
    4: required string activity_start_pdate,          // 必传，分析周期：开始日期
    5: required string activity_end_pdate,            //必传，分析周期：结束日期
    6: required string compare_start_pdate,           # 可选，仅 compare_periods_flag = 0 时有效
    7: required string compare_end_pdate, 

    40: required string positive_target_channel,
    41: required string positive_target_matrix,
    42: required i16 positive_target_matrix_threshold,

    50: optional string task_desc,
    51: optional ProductDim product_dim ,
    
    60: optional list<string> product_id_list,
}

struct CreateActivityReviewRequest {
    1: required CreateActivityReviewMeta query,
    255: optional base.Base Base
}

struct CreateActivityReviewResponseData {
    1: required string task_id,
}

struct CreateActivityReviewResponse {
    1: required CreateActivityReviewResponseData data,
    # 分析任务ID
    255: optional base.BaseResp BaseResp,
}

###### 分析任务详情 ######
struct GetActivityReviewResultRequest {
    # 分析任务ID
    1: required string task_id,
}

struct AnalysisUnit {
    1: required string more,
    2: required string less,
}

struct AnalysisTable {
    1: required AnalysisUnit complex_brand_s_level,
    2: required AnalysisUnit hot_price_30d_bins,
}

struct AnalysisTableStr {
    1: required string complex_brand_s_level,
    2: required string hot_price_30d_bins,
}

union AnalysisResult {
    1: optional AnalysisTable anslysi_result,
    2: optional AnalysisTableStr anslysi_result_str,
    3: optional string string,
    4: optional i64 i64,
}

struct ActivityReviewResultItem {
    2: required string type,
    3: required string result,
}

struct ActivityReviewResult {
    2: required list<ActivityReviewResultItem> results,
    3: required string query_info,
}

struct GetActivityReviewResultResponse {
    1: required ActivityReviewResult data,

    255: optional base.BaseResp BaseResp,
}

struct FreshActivityReviewProgressRequest { 
    1: required string task_id,
    254: optional i64 err_code,
    255: optional  string error_msg,
}

struct FreshActivityReviewProgressResponse { 
    255: optional base.BaseResp BaseResp,
}
