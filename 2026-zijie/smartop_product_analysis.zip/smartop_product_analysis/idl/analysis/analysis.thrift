namespace py analysis
namespace go analysis

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../dimensions/price_dimensions.thrift"
include "../basic_info.thrift"

struct OverallCommonRequest{
    1: dimensions.ProductAnalysisBaseStruct base_req
    2: bool is_open_yoy     // 是否打开大盘yoy分析
}

// 获取核心指标
struct GetProductAnalysisBaseRequest {
    1: dimensions.ProductAnalysisBaseStruct base_req
    2: bool need_trend
    3: bool is_total
    4: optional string redis_sql_key, // 功能嵌出是，基于prod_id的redis_key
    5: optional OverallCommonRequest overall_req // 大盘请求

    255: optional base.Base Base
}

// 获取核心指标
struct GetPriceAnalysisBaseRequest {
    1: price_dimensions.PriceAnalysisBaseStruct base_req
    2: bool need_trend
    255: optional base.Base Base
}

enum TipInfoType {
    Suggestion = 1 // 建议关注
    Gain = 2 // 预计增益
}

struct TipInfo {
     1: string tips // 建议，建议话术
     2: string code // 商品明细code
     3: string sql // 跳转搜索的sql
     4: TipInfoType type // 提示信息类型
     6: string action_tag // 动作类型，建议动作
}

struct CompareProdPoolDiffData {
    1: double compare_change_ratio       // 对比货盘变化率 eg: -0.02
    2: double compare_diff               // 对比差值
    3: bool is_show_compare              // 是否展示对比周期货盘数据
    4: string compare_diff_display_value // 对比货盘差值展示值
}

struct CompareProdPoolData{
    1: TargetCardEntity target
    2: CompareProdPoolDiffData diff_data
}

struct TargetCardEntity {
    1: string name                     // 指标名(主要用于传参) eg: order_num
    2: double value                    // 指标值 eg: 1234567
    3: string display_value            // 指标展示值 123.46万单
    4: string display_name             // 指标显示名 eg: 支付订单数
    5: string tips                     // 指标提示(hover文案)
    8: double cycle_value              // 环比值
    9: string cycle_display_value       // 环比展示值 123.46万单
    10: double cycle_change_ratio       // 环比变化率 eg: -0.02
    11: string unit // 指标的单位 eg: 单
    12: list<TargetTrendPoint> trend_data // 趋势图数据
    13: TargetCardExtraInfo extra // 额外展示信息, 大盘占比等
    14: i64 display_order         // 展示顺序
    15: bool need_second_query // 是否需要再次查询 (对于UV类指标，需要点击再次查询)
    16: bool is_use_pp, // 表示环比值是pp值还是百分比
    17: TargetCardGroupInfo group_info, // 多维分析下拆信息
    18: DiffExtraInfo diff_extra // 提升幅度相关参数
    19: list<TargetBasicInfo> sub_target_list // 子指标列表，外层为主指标（例如，主指标订单数，副指标GMV、商品数）
    20: list<TargetTrendPoint> compare_trend_data // 对比周期趋势图数据
    21: ComparePeriodData compare_period_data // 同步、对比周期数据
    22: string value_type // 指标数值类型(int,float)
    23: i64 target_precision // 指标精度
    24: bool is_show // 是否展示
    25: list<TipInfo> tip_info_list // tips
    26: list<ExpValueItem> ab_exp_data   // ab 实验数据
    28: optional CompareProdPoolData compare_prod_pool_data
}

struct ComparePeriodData{
    1: double sync_value              // 同比值
    2: string sync_display_value       // 同比展示值 123.46万单
    3: double sync_change_ratio       // 同比变化率 eg: -0.02
    4: double sync_diff, // 同比差值
    5: double compare_value              // 对比周期值
    6: string compare_display_value       // 对比周期展示值 123.46万单
    7: double compare_change_ratio       // 对比周期变化率 eg: -0.02
    8: double compare_diff // 对比差值
    9: bool is_show_compare // 是否展示对比周期数据
    10: string sync_target_tag // 同比的异动关注标记
    11: string compare_target_tag // 对比周期异动关注标记
    12: double sync_contribution // 环比贡献度
    13: double compare_contribution // 对比周期贡献度
    14: string sync_diff_display_value // 同比差值展示值
    15: string compare_diff_display_value // 对比周期差值展示值
    16: double distribution_value           // 对比周期值的贡献度
    17: double distribution_value_ratio     // 贡献度的aa增幅
}

struct ExpValueItem {
    1: i64 version_id
    2: double value
    3: string display_value
    4: double ab_change_ratio  // ab 增幅，对照组为0
    5: double ab_diff // ab 增量，对照组为0
    6: string ab_diff_display_value // ab 增量
    7: bool is_show_ab_exp // 是否展示ab实验数据
    8: double compare_value
    9: string compare_display_value
    10: ABSignificance ab_significance // AB显著性
    11: double ab_contribution // ab实验贡献度
}

// ab实验显著性
enum ABSignificance {
    Unknown = 0
    IsSignificance = 1 // 显著
    NotSignificance = 2 // 不显著
    UnsupportedSignificance = 3 // 不支持显著性
}


struct TargetCardGroupInfo{
    1: string name, // 维度值名
    2: string display_name, // 展示名
    3: list<TargetCardEntity> group_list, // 下拆的多维分析列表(目前最多两层)
    4: double percent, // 当前维度值占比
    5: bool is_show_percent // 是否展示占比，true展示(均值类，比率类指标没法展示占比)
}

struct DiffExtraInfo{
    1: double diff // 最后一个粒度 - 第一个粒度
    2: string display_value // diff的展示值
    3: double diff_ratio // 提升幅度，可能为负值
    4: double diff_contribution // 差异贡献度
}

// 变化趋势标签
enum ChangeTrendFlag{
    NoChange      = 0  // 无变化
    Rise  = 1  // 上升
    Fall = 2  // 下降
}

struct TargetCardExtraInfo {
    1: double market_value   // 大盘属性值
    2: string display_value // 展示值
    3: bool percent_flag // true 该指标需要展示大盘占比
    4: double market_percent // 大盘占比(percent_flag 为true时再取)
    5: bool is_larger_advantage // 当前指标是否越大越有优势，例如 高价率 这种指标是越小越好
    6: bool distribution_flag //  是否展示分布值
    7: double distribution_value // 分布值
    8: string prod_tag_code // 商品画像的标记code
    9: string target_tag         // 指标标签
    10: optional double leaf_avg_value // 叶子类目指标均值
    11: optional bool leaf_compare_flag // 是否比较和叶子类目的均值差异
    12: optional bool is_better_than_leaf // 是否优于叶子类目均值
    13: optional string target_goal_display_value // 目标值
    14: optional double target_goal_complete_ratio // 目标完成率
    15: optional double target_goal_contribute_ratio // 目标贡献率

    20: string attribute_type // 指标分类
    21: bool is_default_show // 是否默认展示
    22: TargetType target_type   // 指标类型，大促指标、大盘指标
    23: double burst_rate //  爆发系数
    24: string suggest_script //  建议话术
    25: string suggest_action //  建议动作
    26: dimensions.BizType biz_type // 业务线ID
}

enum TargetType{
    BigActivity  = 0  // 大促
    Overall = 1   // 大盘
    BigActivityVsOverallDiff = 2   // 大促vs大盘diff
}

struct TargetTrendPoint {
    1: double value            // 指标值
    2: string display_value    // 指标显示值
    3: string name             // 指标名
    4: string display_name     // 指标显示名
    5: string x                // 横坐标 eg: 2024-04-30(周二)
    6: list<TargetBasicInfo> sub_target_list // 子指标列表，外层为主指标（例如，主指标订单数，副指标GMV、商品数）
    7: string dim_display_name // 维度展示名, 外层一般是汇总，内层是多维分析拆分的维度值，eg:高价_非高价
    8: string dim_name // 维度值
    9: double percent // 占汇总值的比例
    10: list<TargetTrendPoint> children // 下拆的价格力趋势节点（eg:高价_非高价,非高价_高价）
    11: list<TargetTrendPoint> group_list // 多维分析下拆(eg: 价格带下拆)
    12: string prod_tag_code // 商品画像的标记code
    13: string x_value // x轴具体数值
}

struct TargetBasicInfo{
    1: double value            // 指标值
    2: string display_value    // 指标显示值
    3: string name             // 指标名
    4: string display_name     // 指标显示名
    5: double percent // 当前指标占汇总值的比例
    6: string tips // 指标tips
    7: i64 display_order         // 展示顺序
    8: string target_tag         // 指标标签
    11: string prod_tag_code // 商品画像的标记code

    12: double cycle_value          // 环比值
    13: string cycle_display_value  // 环比展示值 123.46万单
    14: double cycle_change_ratio   // 环比变化率 eg: -0.02

    15: string diff_base_curr_display_name        // 当前周期的和基准指标的差值
    16: string diff_base_compare_display_name     // 对比周期的和基准指标的差值
    17: double diff_base_ratio       // 和基准指标的对比变化率 = （diff_base_curr-diff_base_compare）/diff_base_compare eg: -0.02
}

struct TargetCategoryList{
    1: list<TargetCardEntity> target_list
    2: string category_name // 类别名称 eg: 货品指标，流量指标
}

// 获取核心指标-总览
struct GetProductAnalysisCoreOverviewResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<TargetCategoryList> data

    255: base.BaseResp BaseResp
}

// 获取核心指标-点查
struct GetProductAnalysisCoreTargetResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: TargetCardEntity data // 指标卡

    255: base.BaseResp BaseResp
}

// 获取核心指标-分层结构
struct HierarchicalEntity {
    1: string name         // 分层名称
    2: double value        // 具体值
    3: double ratio        // 百分比 (均值类指标不需要展示)
    4: string display_value // 展示值
    5: bool conclusion_flag // 是否用于结论
}

// 维度分层数据
struct DimensionEntity{
    1: string name, // 维度名
    2: string display_name, // 维度展示名
    3: list<HierarchicalEntity> hierarchical, // 分层数据
    4: bool is_show, // 是否展示（核心结论处需要用到部分线上不展示的分层）
}

struct GetProductAnalysisCoreHierarchicalInfo {
    1: string name                     // 指标名
    2: string display_name             // 指标显示名
    3: bool show_percent_flag // true 该指标需要展示百分比，false不需要展示百分比
    4: list<DimensionEntity> dim_hierarchical // 各个维度的分层数据
    5: double value        // 指标整体值
    6: string display_value // 展示值
    7: string unit // 指标单位
}

struct GetProductAnalysisCoreHierarchicalResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<GetProductAnalysisCoreHierarchicalInfo> data

    255: base.BaseResp BaseResp
}

// 多维分析额外嵌入指标-结构体
struct MultiDimExtraTargetListRow{
    1: string enum_value // 维度枚举名（用于传参），例如 male
    2: list<TargetCardEntity> target_list // 指标列表，顺序按照设计稿上固定(最后两列为货补数据)
}

struct MultiDimExtraTargetItem{
    1: list<MultiDimExtraTargetListRow> extra_target_list
}

struct GetMultiDimExtraTargetListResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: MultiDimExtraTargetItem data

    255: base.BaseResp BaseResp
}

// 获取多维分析指标-下钻
struct MultiDimListRow{
    1: string enum_value // 维度枚举名（用于传参），例如 male
    2: string display_name // 维度展示名 例如 男性
    3: list<TargetCardEntity> target_list // 指标列表，顺序按照设计稿上固定(最后两列为货补数据)
    4: bool has_subsidy_data_permission // 是否有货补权限(没有货补权限就不展示成本明细)
    5: string prod_tag_code // 商品画像的标记code
}

struct GetProductAnalysisMultiDimListResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<MultiDimListRow> data

    255: base.BaseResp BaseResp
}

struct GetProductAnalysisCoreTargetRequest{
    1: dimensions.ProductAnalysisBaseStruct base_req
    2: string target_name // 指标英文名
    255: base.BaseResp BaseResp
}

// 获取多维分析指标-商品明细
struct GetProductAnalysisMultiDimProductListRequest {
    1: required dimensions.ProductAnalysisBaseStruct base_req
    2: base.PageInfo page_req
    3: optional base.OrderByInfo order_by // 排序参数，不传的话默认根据曝光PV倒排
    4: optional string redis_sql_key, // 功能嵌出是，基于prod_id的redis_key

    255: optional base.Base Base
}


// 获取多维分析指标-下钻列表
struct GetProductAnalysisMultiDimListRequest {
    1: required dimensions.ProductAnalysisBaseStruct base_req
    2: bool need_trend // 是否需要趋势图

    255: optional base.Base Base
}

// 待和产品确认hover的展示内容
struct MultiDimProductInfo {
    1: basic_info.ProductBasicInfo product_info
    2: basic_info.ShopBasicInfo shop_info
    3: basic_info.BrandBasicInfo brand_info
    4: i64 show_pv // 曝光PV
    5: i64 order_num // 商品订单数
    6: string industry_name // 行业大类
    7: string first_level_cate_name // 一级类目
    8: string second_level_cate_name // 二级类目
    9: string leaf_cate_name // 叶子类目
    10: list<TargetCardEntity> target_list // 指标列表
    11: ProdSubsidyData prod_subsidy_data // 货补指标
    12: string online_status, // 在线状态
    13: string sell_status, // 可售状态
    14: string product_price_belt // 图谱价格带
    15: string price_range // 绝对值价格带
    16: map<string, string> dim_map // 额外的商品维度（已有的维度字段不迁移，后续新增的维度字段都放在这里）
    17: basic_info.SkuBasicInfo sku_info // sku信息
}

// 受限于交互方式，货补指标不支持排序
struct ProdSubsidyData{
    1: list<TargetCardEntity> target_list // 货补指标，没权限时是空数组
    2: bool has_subsidy_data_permission // 是否有货补权限(没有货补权限就不展示成本明细)
}

struct GetProductAnalysisMultiDimProductListData {
    1: list<MultiDimProductInfo> product_list
    2: base.PageResp page_info // 分页信息
    3: i64 shop_cnt // 涉及商家数量
}

struct GetProductAnalysisMultiDimProductListResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetProductAnalysisMultiDimProductListData data     // 返回结果

    255: base.BaseResp BaseResp
}

// 核心指标-结论
// 置信度警告信息
struct ConfidenceWarnInfo {
    1: bool is_warn // 是否警告
    2: map<string, double> target_value // 指标值 key = prod_cnt 商品数量 \ pay_cnt 成交订单数
    3: map<string, double> threshold // 警告阈值 key = prod_cnt 商品数量 \ pay_cnt 成交订单数
}

// 结论-指标类列表结构
struct ProductAnalysisConclusionInfo {
    1: string text // 纯文本
    2: list<dimensions.SelectedDimensionInfo> drill_down_dimensions // 下钻的补充维度，存在则该行有一个下钻按钮
}

struct ConclusionProdDimCntInfo {
    1: string dim_name // 维度名称
    2: i64 dim_cnt // 维度涉及数量
}

struct ConclusionProdDimContributionInfo {
    1: list<dimensions.SelectedDimensionInfo> dim_info // 维度信息
    2: list<TargetCardEntity> target_entity // 指标(名称+值)
    3: double contribution                // 贡献度
    4: optional string order_target_name  // 排序的指标名称
    5: optional bool is_total             // 是否表头展示
    6: optional double market_diff        // 与大盘的差值
}

struct HierarchicalColInfo {
    1: string col_name // 分层列名
    2: list<string> target_name // 指标列表
}
struct ConclusionProdConstructInfo {
    1: list<ConclusionProdDimCntInfo> relate_dims // 涉及的维度数量
    2: list<ConclusionProdDimContributionInfo> dim_contribution // 贡献度信息
    3: list<HierarchicalColInfo> hierarchical_col_info // 展示的分层信息
}

struct HierarchicalInfo {
    1: string col_name // 分层列名
    2: list<TargetCardEntity> target_name // 指标列表
}

struct ProductAnalysisCoreConclusionData {
    1: list<TargetCardEntity> business_ret // 业务结果
    2: ConclusionProdConstructInfo prod_construction // 货品结构
    3: list<TargetCardEntity> flow_efficiency // 流量效率
    4: list<TargetCardEntity> prod_efficiency // 货品效率 - 流量指标
    5: list<HierarchicalInfo> prod_hierarchical // 货品效率 - 单量分层

    10: ConfidenceWarnInfo warn_info // 警告信息
}

struct GetProductAnalysisCoreConclusionResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: ProductAnalysisCoreConclusionData data

    255: base.BaseResp BaseResp
}

// 多维分析-结论

// 多维-异动分析信息
struct MultiDimConclusionAbnormalInfo {
    1: dimensions.SelectedDimensionInfo dim_info // 维度信息 - 为空则是根结点
    2: TargetCardEntity target_entity // 指标信息
    3: double contribution // 贡献度
    4: MultiDimConclusionAbnormalInfo sub_dim_info // 维度异动
}

struct MultiDimConclusionAbnormalData {
    1: list<TargetCardEntity> target_entity // 指标信息
    2: list<MultiDimConclusionAbnormalInfo> abnormal_info // 异动信息
    3: string warn_msg // 未发现波动的文案
}

struct ProductAnalysisMultiDimConclusionData {
    1: ConclusionMultiBizRetInfo biz_ret // 业务结果
    2: list<ConclusionProdDimContributionInfo> flow_trans // 流量转化
    3: list<MultiDimConclusionAbnormalData> abnormal_data // 异动分析

    10: ConfidenceWarnInfo warn_info // 警告信息
}

struct ConclusionMultiBizRetInfo {
     1: list<ConclusionMultiBizTotalInfo> total_info
     2: list<ConclusionMultiBizListInfo> list_info
}

struct ConclusionMultiBizTotalInfo {
    1: TargetCardEntity total_target
    2: list<ConclusionMultiContributionInfo> multi_contribution_info
}

struct ConclusionMultiBizListInfo {
    1: ConclusionMultiContributionInfo title_dim
    2: list<ConclusionMultiContributionInfo> sub_dim_tree
}

struct ConclusionMultiContributionInfo {
    1: dimensions.SelectedDimensionInfo dim_info // 维度信息
    2: TargetCardEntity target_entity            // 指标信息
    3: double contribution                       // 贡献度-占比
    4: double market_percent                     // 大盘维度下的占比值
    5: ConclusionMultiContributionInfo sub_info  // 孩子节点
}

struct GetProductAnalysisMultiDimConclusionResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: ProductAnalysisMultiDimConclusionData data

    255: base.BaseResp BaseResp
}

// 下载返回体
struct GetProductAnalysisDownloadResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: bool data // 是否发起下载任务成功

    255: base.BaseResp BaseResp
}

struct GetProductAnalysisProdCntResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetProductAnalysisProdCntItem data

    255: base.BaseResp BaseResp
}

struct GetProductAnalysisProdCntItem{
    1: i64 prod_cnt // 商品数
    2: i64 shop_cnt // 涉及商家数量
    3: i64 big_link_cnt  // 大链接商品数量
    4: i64 overall_prod_cnt // 大盘商品数
}

// 反馈
struct AddFeedBackRequest{
    1: required dimensions.ConclusionModule module, // 点踩点赞的结论所属模块
    2: required dimensions.ProductAnalysisBaseStruct base_req, // 通用入参
    3: required string conclusion, // 当前的结论文本
    4: required bool is_positive, // true 好评， false 差评

    255: optional base.Base Base
}

struct AddFeedBackResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: bool data // 是否下载成功

    255: optional base.BaseResp BaseResp,
}

// 获取多维分析指标-下钻
struct GetProductAnalysisMultiDimFullListRequest {
    1: dimensions.ProductAnalysisBaseStruct base_req
    2: bool need_incr
    255: optional base.Base Base
}
struct MultiDimFullListRow {
    1: string enum_value // 维度枚举名（用于传参），例如 male
    2: string display_name // 维度展示名 例如 男性
    3: list<TargetCardEntity> target_list // 指标列表，顺序按照设计稿上固定
    4: string dim_key // 维度标识
    5: list<MultiDimFullListRow> children
    50: string prod_tag_code // 查看商品画像的标签
}
struct GetProductAnalysisMultiDimFullListData {
    1: MultiDimFullListRow total // 整体
    2: MultiDimFullListRow all_total // 全量整体
    5: list<MultiDimFullListRow> full_list
}
struct GetProductAnalysisMultiDimFullListResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetProductAnalysisMultiDimFullListData data

    255: base.BaseResp BaseResp
}
struct DimEnumTargetCard{
    1: string target_name, // 指标名(主要用于传参) eg: prod_cnt
    2: double target_value,  // 指标值 eg: 1234567
    3: string display_value, // 指标展示值 123.46万
    4: string display_name,  // 指标显示名 eg: 商品数
    5: string enum_code, // 维度枚举值code
    6: string enum_name, // 维度枚举值展示名
    7: string dimension_id, // 维度ID
    8: string dimension_name, // 维度名
    9: double percent, // 当前维度枚举指标占比
    10: bool is_fake_dim_id, // 是否是假dimID(其他这种非原生枚举值，不能直接回传)
}

struct GetProductAnalysisMultiDimTrendInfo {
    1: list<TargetTrendPoint> target_list
    2: string target_name
    3: string enum_value
}
struct GetProductAnalysisMultiDimTrendData {
    1: list<GetProductAnalysisMultiDimTrendInfo> trend_list
}
struct GetProductAnalysisMultiDimTrendResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetProductAnalysisMultiDimTrendData data

    255: base.BaseResp BaseResp
}

struct GetProductDetailRequest{
    1: required string prod_id

    255: base.BaseResp BaseResp
}

struct GetProductDetailResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required MultiDimProductInfo data     // 返回结果

    255: base.BaseResp BaseResp
}

struct GetProductDetailBy360Response{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetProductBriefInfoData data     // 返回结果

    255: base.BaseResp BaseResp
}

struct GetProductBriefInfoData {
    1: map<string, BasicFormatItem> brief
}

struct BasicFormatItem{
    1: string name, // 名字
    2: optional string value
    3: string data_type // 数值类型, 如果该数值类型为列表，则带有前缀list_如list_raw，代表string数组 具体参见文档：https://bytedance.feishu.cn/wiki/wikcny4M1vcYfWBVeNXQ6HfmECb#doxcnoyKmSW6kGoIwJO2wvmMkms
    4: optional bool reverse // 是否反转指标
    5: map<string, string> extra // 扩展信息，后续一些个性化的case可以基于这个配置下发
}

// 获取商品分析报表
struct GetProductReportTableRequest {
    1: dimensions.ProductAnalysisBaseStruct base_req
    2: dimensions.AnalysisAggregationType aggr_type // 分析口径(日均/汇总)
    3: i64         compare_type  // 1:绝对值;  2:环比; 3:环差
    4: optional i64         lark_subscribe_type  // 1:日报 2:周报
    255: optional base.Base Base
}

// 周报/日报返回体
struct GetProductAnalysisSubscribeResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: optional string data // 订阅数据 json结构 通用取数返回体
    255: base.BaseResp BaseResp
}

struct GetProductReportTableData {
    1: list<MultiDimFullListRow> full_list // 完整数据行
    5: i64 total
}
struct GetProductReportTableResponse {
    1: required i32 code                            // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetProductReportTableData data

    255: base.BaseResp BaseResp
}

// 获取漏斗图默认信息
struct GetProductAnalysisDefaultFunnelMateRequest {
    1: dimensions.BizType biz_type

    255: optional base.Base Base
}
struct RatioOption {
    1: string label // 转化率指标名称，eg: 商品曝光-动销率
    2: string from  // 转化率分母指标
    3: string to    // 转化率分子指标
}
struct CoreOverviewFunnelData {
    1: list<string> targets // 漏斗图中默认展示的指标列表，eg: pay_ord_cnt
    2: list<RatioOption> ratio_option // 漏斗图中指标与指标之间的转化率
    3: list<dimensions.SelectedDimensionInfo> dimensions // 筛选条件
}
struct GetProductAnalysisDefaultFunnelMateResponse {
    1: required i32 code                            // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<CoreOverviewFunnelData> data

    255: base.BaseResp BaseResp
}

struct ProductLabel {
    1: required string   product_id
    2: required i32      label    // 0 或 1
}

struct InflectionPointInsightRequest {
    1: required list<ProductLabel> product_labels // 商品id和标签
    2: required i64 top_dimensions   // 存在明显拐点的top维度

    254: optional base.PageInfo page_req    // 分页信息
    255: optional base.Base Base
}

struct InflectionPointInsightData {
    1: list<MultiDimFullListRow> full_list // 完整数据行

    254: base.PageResp page_info // 分页信息
}

struct InflectionPointInsightResponse {
    1: required InflectionPointInsightData data

    255: base.BaseResp BaseResp
}


struct InflectionPointInsightDownloadRequest {
    1: optional string download_dimension_name   // 导出维度名称，不传则导出全部维度
    2: required list<ProductLabel> product_labels
    3: required i64 top_dimensions   // 存在明显拐点的top维度

    255: optional base.Base Base
}

struct InflectionPointInsightDownloadResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: bool data                                     // 是否发起下载任务成功

    255: base.BaseResp BaseResp
}


struct GetSimilarProductRequest {
    1: required dimensions.ProductAnalysisBaseStruct base_req // 通用入参
    2: optional list<string> seed_prod_ids // 种子品id
    3: optional list<string> seed_pool_ids // 种子品货盘id（种子品id和货盘id如果都传，会以输入id为准）
    4: optional list<string> similar_prod_ids // 相似品id
    5: optional list<string> similar_pool_ids // 相似品货盘id （相似品id和货盘id如果都传，会以输入id为准）
    6: optional list<dimensions.SelectedDimensionInfo> seed_filter_dimensions // 种子品筛选条件
    7: optional list<dimensions.SelectedDimensionInfo> similar_filter_dimensions // 相似品筛选条件
    8: required i64 similar_count_limit     // 每个种子品匹配多少相似品

    254: optional base.PageInfo page_req
    255: optional base.Base Base
}

struct GetSimilarProductItem {
    1: required MultiDimProductInfo seed_product          // 种子品
    2: required MultiDimProductInfo similar_product       // 相似品
    3: required double similar_score                      // 相似分
}

struct GetSimilarProductResponseItem {
    1: required list<GetSimilarProductItem> similar_product_list
    2: required i64  pass_seed_cnt        // 通过支付UV筛选种子品数量
    3: required i64  no_pass_seed_cnt     // 未通过支付UV筛选种子品数量

    254: base.PageResp page_info // 分页信息
}

struct GetSimilarProductResponse {
    1: required GetSimilarProductResponseItem data                              // 状态码 0: 成功
    255: base.BaseResp BaseResp
}

struct GetSimilarProductDownloadRequest {
    1: required dimensions.ProductAnalysisBaseStruct base_req // 通用入参
    2: optional list<string> seed_prod_ids  // 种子品id
    3: optional list<string> seed_pool_ids  // 种子品货盘id（种子品id和货盘id如果都传，会以输入id为准）
    4: optional list<string> similar_prod_ids   // 相似品id
    5: optional list<string> similar_pool_ids   // 相似品货盘id （相似品id和货盘id如果都传，会以输入id为准）
    6: optional list<dimensions.SelectedDimensionInfo> seed_filter_dimensions   // 种子品筛选条件
    7: optional list<dimensions.SelectedDimensionInfo> similar_filter_dimensions    // 相似品筛选条件
    8: required i64 similar_count_limit     // 每个种子品匹配多少相似品
    9: required bool is_download_seed_filtered_detail   // 是否下载未通过校验的种子品筛选明细

    255: optional base.Base Base
}

struct GetSimilarProductDownloadResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                           // 出错提示消息
    3: bool data                                     // 是否发起下载任务成功

    255: base.BaseResp BaseResp
}

struct CreateGetSimilarProductPoolRequest {
    1: required dimensions.ProductAnalysisBaseStruct base_req // 通用入参
    2: optional list<string> seed_prod_ids  // 种子品id
    3: optional list<string> seed_pool_ids  // 种子品货盘id（种子品id和货盘id如果都传，会以输入id为准）
    4: optional list<string> similar_prod_ids   // 相似品id
    5: optional list<string> similar_pool_ids   // 相似品货盘id （相似品id和货盘id如果都传，会以输入id为准）
    6: optional list<dimensions.SelectedDimensionInfo> seed_filter_dimensions   // 种子品筛选条件
    7: optional list<dimensions.SelectedDimensionInfo> similar_filter_dimensions    // 相似品筛选条件
    8: required i64 similar_count_limit     // 每个种子品匹配多少相似品

    9: required i64 create_type             // 创建货盘 1：种子品 2：相似品
    10: required string pool_name           // 货盘名称

    255: optional base.Base Base
}

struct CreateGetSimilarProductPoolResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required string           data               // 货盘id

    255: base.BaseResp BaseResp
}

struct InitPlanAnalysisPoolRequest {
    1: required string plan_id                               // 计划ID

    255: optional base.Base Base
}

struct InitPlanAnalysisPoolResponse {
    1: required i32 code                                // 状态码 0: 成功
    2: required string msg                              // 出错提示消息
    3: required string           data                   // 货盘id

    255: base.BaseResp BaseResp
}