namespace py analysis
namespace go analysis

include "../base.thrift"
include "analysis.thrift"
include "../dimensions/price_dimensions.thrift"
include "../dimensions/dimensions.thrift"

struct GetPriceInsightCoreOverviewRequest{
    1: price_dimensions.PriceAnalysisBaseStruct base_req
    2: bool is_price_change, // 是否改价的分层趋势

    255: optional base.Base Base
}

// 价格力核心指标卡返回结构
struct GetPriceInsightCoreOverviewResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<analysis.TargetCardEntity> data

    255: base.BaseResp BaseResp
}

struct GetPriceInsightMetaRequest{
    1: price_dimensions.PriceAnalysisBaseStruct base_req

    255: optional base.Base Base
}

struct GetPriceInsightMetaResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetPriceInsightMetaItem data

    255: base.BaseResp BaseResp
}

struct GetPriceInsightMetaItem{
    1: HierarchicalTrendMeta price_trend_meta, // 分层趋势的元信息
    2: HierarchicalTrendMeta price_change_trend_meta, // 分层趋势的元信息
    3: MultipleRatioTableMeta multiple_ratio_table_meta, // 倍比表格元信息
    4: GetPriceInsightBubbleChartMeta price_bubble_meta, // 气泡图元信息
    5: GetPriceInsightBubbleChartMeta price_change_bubble_meta, // 气泡图元信息
}

struct HierarchicalTrendMeta{
    1: list<analysis.TargetBasicInfo> targets, // 数组第一项是默认指标
    2: dimensions.DimensionInfo source_field, // 来源场域
    3: list<dimensions.DimensionInfo> drill_dimensions, // 支持下钻的维度列表(价格力分层、场域)
    4: list<dimensions.SelectedMultiDimensionInfo> default_group_dimension, // 默认的多维分析维度
}

struct MultipleRatioTableMeta{
    1: list<analysis.TargetBasicInfo> targets, // 数组第一项是默认指标
}

struct GetPriceInsightBubbleChartMeta{
    1: list<analysis.TargetBasicInfo> targets, // 数组第一项是默认x轴指标，第二项为y轴指标
    2: list<dimensions.DimensionInfo> analysis_dimensions, // 主图的分析维度列表(价格力分层)
    3: list<dimensions.DimensionInfo> drill_dimensions, // 支持下钻的维度列表(场域等)
    4: list<dimensions.SelectedMultiDimensionInfo> default_group_dimension, // 默认的多维分析维度
}

// 分层趋势的入参，多维分析参数拼到base_req的多维分析参数
struct GetPriceInsightHierarchicalTrendRequest{
    1: price_dimensions.PriceAnalysisBaseStruct base_req,
    2: dimensions.SelectedDimensionInfo drill_dimension, // 下钻的维度(价格力分层、场域)
    3: string target_name, // 趋势图主指标的指标名(通过一个元信息接口拿到)
    4: optional dimensions.SelectedDimensionInfo source_field, // 来源场域
    5: optional bool is_ad, // 是否广告(曝光价格力是广告流量、SKU订单是广告订单)
    6: optional dimensions.SelectedDimensionInfo group_dimension, // 多维分析参数
    7: bool is_price_change, // 是否改价的分层趋势
    255: optional base.Base Base
}

// 分层趋势
struct GetPriceInsightHierarchicalTrendResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required PriceInsightHierarchicalTrendItem data

    255: base.BaseResp BaseResp
}

struct PriceInsightHierarchicalTrendItem{
    1: list<analysis.TargetTrendPoint> target_trend, // 指标趋势
    2: list<dimensions.EnumElement> main_legend, // 下钻的图例，代表主指标大盘、以及主指标各个下钻维度
    3: list<dimensions.EnumElement> sub_legend, // 趋势子图的图例
}

struct GetMultipleRatioTableRequest{
    1: price_dimensions.PriceAnalysisBaseStruct base_req,
    2: string target_name, // 倍比下钻指标
    3: optional bool is_ad, // 是否广告(曝光价格力是广告流量、SKU订单是广告订单)
    255: optional base.Base Base
}

struct GetMultipleRatioTableResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required list<MultipleRatioTableItem> data

    255: base.BaseResp BaseResp
}

struct MultipleRatioTableItem{
    1: string table_name // 表名，拆分的场域名
    2: string analysis_range // 分析区间(20240501-20240530)
    3: double overall_data // 大盘指标数据
    4: list<MultipleRatioRowItem> item
}

struct MultipleRatioRowItem{
    1: string row_name // 行名（站内站外价格力拆解标签）
    2: analysis.TargetCardEntity target_info,
    3: double multiple_ratio, // 倍比
    4: list<analysis.TargetTrendPoint> multiple_ratio_trend, // 倍比趋势
}

// 多维分析，需要把维度塞到base_req中
struct GetPriceInsightBubbleChartRequest{
    1: price_dimensions.PriceAnalysisBaseStruct base_req,
    2: string x_axis_target_name, // x轴指标
    3: string y_axis_target_name, // y轴指标
    4: dimensions.SelectedDimensionInfo analysis_dimension, // 分析的维度(价格力分层)，下钻时需要把选中的枚举值传进来。
    5: optional dimensions.SelectedDimensionInfo drill_dimension, // 副图的下钻维度，枚举值过多时展示Top10。(请求主图时不传)
    6: optional dimensions.SelectedDimensionInfo group_dimension, // 多维分析维度，枚举值过多时展示Top10。(用户没选时不用传)
    7: CoordinateAxisType type, // 坐标轴类型（均值、分位数）
    8: bool is_price_change, // 是否改价的气泡图
    255: optional base.Base Base
}

enum CoordinateAxisType{
    Avg = 1, // 均值(默认)
    P50 = 2, // 50分位数(中位数)
}

struct GetPriceInsightBubbleChartResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required PriceInsightBubbleChartItem data

    255: base.BaseResp BaseResp
}

// 坐标轴点
struct AxisPoint{
    1: analysis.TargetCardEntity x_axis, // x轴指标值
    2: analysis.TargetCardEntity y_axis, // y轴指标值
    3: analysis.TargetCardEntity z_axis, // z轴指标值
    4: list<analysis.TargetCardEntity> target_list, // hover指标信息 - 预留字段
    5: string legend_code, // 图例分组code
    6: string show_name // 展示名称
    7: string prod_tag_code // 商品画像的标记code
}

struct PriceInsightBubbleChartItem{
    1: list<AxisPoint> point_list, // 气泡列表
    2: double x_coordinate_axis_value, // x坐标轴零值(均值或者分位数)
    3: string x_display_name, // x坐标轴零值的展示值
    4: double y_coordinate_axis_value, // y坐标轴零值(均值或者分位数)
    5: string y_display_name, // y坐标轴零值的展示值
    6: list<dimensions.EnumElement> legend, // 图例信息
}

struct AxisInfo{
    1: analysis.TargetCardEntity target, // 第一层指标卡：指标汇总值，第二层下拆维度得指标值，第三层下拆维度*多维分析维度的指标值
    2: double coordinate_axis_value, // 坐标轴值(均值或者分位数)
    3: string display_name, // 坐标轴值的展示值
}

// 商品明细入参
struct ProdDetailBaseRequest{
    1: required string start_date,
    2: required string end_date,
    3: required string router, // hover查看商品明细的方法路由
    4: required string req_marshal, // hover模块的方法入参序列化后的字符串
    5: string code, // hover所属位置的额外参数,可以不传(例如多维分析的"整体")
    6: optional list<dimensions.SelectedDimensionInfo> dimensions // 商品明细页顶部筛选区的人货场属性筛选
    7: optional bool is_native // 是否原生画像请求（非从某些功能模块跳转的画像），为true时router和code不生效，req_marshal请传货品分析的入参
    8: optional SubScenarioType sub_scenario_info// 超值购搜索 引入供给 的商品明细中需要用到
}

enum SubScenarioType {
    Search = 0
}

struct GetProdPortraitRequest{
    1: ProdDetailBaseRequest base_req

    255: optional base.Base Base
}

struct GetProdPortraitResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required list<PieGraphItem> data

    255: base.BaseResp BaseResp
}

struct GetEchoDisplayDimsResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required list<dimensions.SelectedDimensionInfo> data

    255: base.BaseResp BaseResp
}

struct PieGraphItem{
    1: string name, // 饼图名称
    2: list<analysis.DimEnumTargetCard> value,
}

struct GetPordDetailListRequest{
    1: ProdDetailBaseRequest base_req
    2: base.PageInfo page_req
    3: optional base.OrderByInfo order_by // 排序参数，不传的话默认根据曝光PV倒排

    255: optional base.Base Base
}

// 订单价格力分工
enum ResponsibilityAllType {
    SUPPLY // 供给分工
    FLOW   // 流量分工
}

struct GetOrderResponsibilityDistributedRequest{
    1: price_dimensions.PriceAnalysisBaseStruct base_req
    2: optional ResponsibilityAllType responsibility_all // 分工类型，供给/流量 - 空 为 全部
//    3: optional string responsibility_first // 一级分工 - 空时 为 全部
    4: optional list<dimensions.SelectedDimensionInfo> filter_dimensions // 过滤属性，目前有：体裁 + 价格带

    255: optional base.Base Base
}

struct GetOrderResponsibilityDistributedData {
    1: list<analysis.TargetTrendPoint> target_list
}

struct GetOrderResponsibilityDistributedResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetOrderResponsibilityDistributedData data

    255: base.BaseResp BaseResp
}

struct GetOrderResponsibilityCoreOverviewData {
    1: list<analysis.TargetCardEntity> responsibility_total_targets // 不同分工高价率
    2: list<analysis.TargetCardEntity> responsibility_same_targets  // 有同款高价率
}

struct GetOrderResponsibilityCoreOverviewResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetOrderResponsibilityCoreOverviewData data

    255: base.BaseResp BaseResp
}

struct GetOrderResponsibilityChangeTargetInfo {
    1: string show_name // 名称
    2: list<analysis.TargetTrendPoint> targets
}

struct GetOrderResponsibilityChangeData {
    1: list<GetOrderResponsibilityChangeTargetInfo> info
}

struct GetOrderResponsibilityChangeResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetOrderResponsibilityChangeData data

    255: base.BaseResp BaseResp
}

enum ResponsibilityIndustryType {
    A_GROUP
    B_GROUP
}

struct GetOrderResponsibilityIndustryInfo {
    1: string name // 展示名称
    2: ResponsibilityIndustryType type // a组 b组
    3: list<analysis.TargetCardEntity> targets // 指标
    4: list<GetOrderResponsibilityIndustryInfo> children
}

struct GetOrderResponsibilityIndustryListData {
    1: list<analysis.TargetCardEntity> total
    2: list<GetOrderResponsibilityIndustryInfo> industry_list
}

struct GetOrderResponsibilityIndustryListResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetOrderResponsibilityIndustryListData data

    255: base.BaseResp BaseResp
}

// 订单分工气泡图请求体
struct GetOrderResponsibilityBubbleChartRequest{
    1: price_dimensions.PriceAnalysisBaseStruct base_req,
    2: string dim_id // 维度ID
    255: optional base.Base Base
}