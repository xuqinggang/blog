namespace py activity
namespace go activity

include "../base.thrift"

struct FlowPlan {
    1: string id                                       // id
    2: i32 biz                                      // 业务，枚举见supply_common.PlanBiz
    3: string biz_id                                // 业务id，业务方唯一键
    4: i32 strategy                                 // 调控策略 1同款替换 2爆款
    5: i32 status                                   // 10（待开始）、20（进行中）、80（已结束）、100（已取消）
    6: i64 start_at                                 // 生效时间
    7: i64 finish_at                                // 失效时间
    8: i32 sync_topic                               // 同步topic，0：通用在线链路、1通用离线链路（10w记录&延时不敏感）
    9: string desc                                  // 计划描述信息
    10: optional string name                        // 计划名称
    16: optional list<i64> cooperator               // 协作人
    17: optional i64 creator                        // 创建人
    19: i64 created_at                              // 创建时间
    20: i64 updated_at                              // 更新时间
    21: i64 updater                                 // 更新人
    23: i64 signal_id                               // 信号ID
    24: double boost_value                          // 加权系数
    25: EquitySignal signal                         // 权益信号
}


struct EquitySignal {
    1:  string          id                                  // 信号ID
    2:  string          name                                // 信号名称
    3:  list<LibraInfo> libras                              // 实验信息
    4:  i64             created_at                          // 创建时间
    5:  i64             updated_at                          // 更新时间
    6:  Valid      valid                      // 是否有效
    7:  SignalType type                       // 信号类型
    8:  i32 level                                           // 权益级别0~1000，越大则权益越大
    9:  string type_name                                    // 信号类型名称
    10: i32 test                                            // 是否测试数据，0否、1测试数据
    11: i64 creator                                         // 创建人
    12: i64 updater                                         // 更新人
    13: list<i64> cooperator                                // 协作人
    14: string biz_code                                     // 业务线
    15: string biz_name                                     // 业务线名称
    16: string project_name                                 // 项目名称
    17: i32 assign_open                                     // 开启搜推同步，0默认关闭、1开启
    18: i64 assign_id                                       // 素材包ID
}

struct LibraInfo {
    1:  i64             signal_id                           // 信号ID
    2:  i64             plan_id                             // 计划ID
    3:  i64             libra_id                            // 实验ID
    4:  i64             libra_layer_id                      // 实验组ID
    5:  i64             created_at                          // 创建时间
    6:  i64             updated_at                          // 编辑时间
    7:  i32             status                              // 实验状态 0/91:已结束, 1:进行中, 2:待调度, 3:调试中, 4:已暂停
}


enum Valid {
    InValid         = 0              // 无效
    Valid           = 1              // 有效
}

enum SignalType {
    Guess = 1                    // 首页猜喜
    ChannelGuess = 2             // 频道猜喜
    Common = 10                  // 通用/全域
}
