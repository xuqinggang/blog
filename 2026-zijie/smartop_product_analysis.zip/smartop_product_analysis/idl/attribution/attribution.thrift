namespace py analysis
namespace go analysis

include "../base.thrift"
include "../dimensions/dimensions.thrift"
include "../analysis/analysis.thrift"
include "../basic_info.thrift"

// 洞察粒度
enum AttributionInsightType {
    ProdPool   // 货盘
    ProdID     // 单品
}

// PV增减符号
enum AttributionPVIncrType {
    EQUAL
    GREATER_THAN
    LESS_THAN
}

struct AttributionCommonBaseStruct {
    1: required dimensions.BizType biz_type // 模块ID
    2: optional dimensions.BizType object_biz_type // 分析对象bizType，不传默认是40000（大盘），另外有41000（猜喜）
    3: required AttributionInsightType insight_type // 洞察粒度
    4: required string start_date // 起始时间，格式为 yyyy-MM-dd
    5: required string end_date   // 结束时间，格式为 yyyy-MM-dd
    6: required string compare_start_date // 对比时间
    7: required string compare_end_date // 对比时间
    8: optional SyncType sync_type // 同比类型，默认不需要

    11: optional list<dimensions.SelectedDimensionInfo> dimensions // 人货场属性筛选
    12: optional list<dimensions.SelectedMultiDimensionInfo> group_attrs // 多维分析筛选，按维度顺序
    13: optional list<dimensions.ThresholdAttr> threshold_attrs // 指标阈值筛选
    14: optional base.LogicalExprType threshold_expr // 且，或

    21: optional bool need_trend // 是否需要趋势图
    22: optional AttributionPVIncrType pv_incr_type // pv增减标记
    23: base.OrderByInfo order_by // 排序参数，不传的话默认 根据曝光PV倒排
}

enum SyncType{
    NotNeed = 0
    Week = 1
    Month = 2
}


// 异动归因的核心指标列表
struct GetAttributionCommonBaseRequest {
    1: AttributionCommonBaseStruct base_req

    255: optional base.Base Base
}

struct GetAttributionCommonCoreOverviewData {
    1: list<analysis.TargetCardEntity> target_list
}

struct GetAttributionCommonCoreOverviewResponse{
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: required GetAttributionCommonCoreOverviewData data     // 返回结果

    255: base.BaseResp BaseResp
}

// 异动归因的商品明细列表
struct GetAttributionCommonPageRequest {
    1: AttributionCommonBaseStruct base_req
    2: base.PageInfo page_req
    3: base.OrderByInfo order_by // 排序参数，不传的话默认 根据曝光PV倒排

    255: optional base.Base Base
}

// 待和产品确认hover的展示内容
struct GetAttributionCommonProd {
    1: basic_info.ProductBasicInfo product_info
    2: basic_info.ShopBasicInfo shop_info

    10: string first_level_cate_name // 一级类目
    11: string second_level_cate_name // 二级类目
    12: string leaf_cate_name // 叶子类目

    20: list<analysis.TargetCardEntity> target_list // 指标列表
}

struct GetAttributionCommonProdList{
    1: list<GetAttributionCommonProd> product_list
    2: base.PageResp page_info // 分页信息
    3: i64 shop_cnt
}

struct GetAttributionCommonProdListResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetAttributionCommonProdList data     // 返回结果

    255: base.BaseResp BaseResp
}


// 流量变化分布图
struct GetAttributionFlowChangeData {
    1: list<analysis.TargetTrendPoint> targets
}

struct GetAttributionFlowChangeResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetAttributionFlowChangeData data

    255: base.BaseResp BaseResp
}

// 元数据结构树
struct GetAttributionTreeMetaListRequest {
    1: required AttributionInsightType insight_type // 洞察粒度

    255: optional base.Base Base
}

struct GetAttributionMetaInfo {
    1: string name
    2: dimensions.BizType biz_type
    3: bool need_conclusion // 是否用于结论
    4: bool disable // 是否禁用
    5: bool has_detail_table // 是否有明细表格
}

// 原因元信息
struct GetAttributionTreeMetaData {
    1: string name // 原因名称
    2: list<GetAttributionMetaInfo> children // 子原因
    3: optional dimensions.BizType biz_type // 当前层级原因的biz_type
    4: list<dimensions.DimensionInfo> dimensions // 属性筛选
    5: list<DimDepend> drill_dim // 旧版多维分析维度配置(废弃)
    6: bool has_detail_table // 是否有明细表格
    7: bool need_connect_tree // 是否需要和归因树联动
}

struct GetAttributionTreeMetaListResponse{
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: required list<GetAttributionTreeMetaData> data     // 返回结果

    255: base.BaseResp BaseResp
}

// 归因树
struct GetAttributionCoreTreeData {
    1: string name
    2: list<analysis.TargetCardEntity> target_list
    3: list<GetAttributionCoreTreeData> children
    4: i64 contribute_prod_cnt, // 同向贡献的商品数
    5: string code
}

struct GetAttributionCoreTreeResponse{
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: required GetAttributionCoreTreeData data     // 返回结果

    255: base.BaseResp BaseResp
}

struct GetAttributionMetaInfoResponse{
    1: required i32 code                                      // 状态码 0: 成功
    2: required string msg                                    // 出错提示消息
    3: required GetAttributionMetaInfoItem data     // 返回结果

    255: base.BaseResp BaseResp
}

struct GetAttributionMetaInfoItem{
    1: AttributionTreeMeta tree_meta, // 归因树维度元信息
    2: FlowChangeMeta flow_change_meta, // 流量变化元信息
    3: AttributionTreeMeta reason_meta, // 原因元信息
}

struct AttributionTreeMeta{
    1: list<dimensions.DimensionInfo> group_attrs // 多维分析筛选，按维度顺序
    2: list<dimensions.DimensionInfo> dimensions // 属性筛选
}

struct FlowChangeMeta{
    1: list<DimDepend> group_relations // 多维分析筛选，按维度顺序
    2: list<dimensions.DimensionInfo> dimensions // 属性筛选
}

struct DimDepend{
    1: dimensions.DimensionInfo main_dim
    2: dimensions.DimensionInfo child_dim
}

// 实验命中
struct GetAttributionABtestListRequest {
    1: AttributionCommonBaseStruct base_req
    2: base.PageInfo page_req
    3: base.OrderByInfo order_by // 排序参数，不传的话默认 根据曝光PV倒排
    4: optional string prod_id
    5: optional string start_range_start_date // 起始日期范围，开始时间，格式为 yyyy-MM-dd
    6: optional string start_range_end_date   // 起始日期范围，结束时间，格式为 yyyy-MM-dd
    7: optional string end_range_start_date // 结束日期范围，开始时间，格式为 yyyy-MM-dd
    8: optional string end_range_end_date   // 结束日期范围，结束时间，格式为 yyyy-MM-dd

    255: optional base.Base Base
}

struct GetAttributionABtestInfo {
    1: basic_info.ABtestBasicInfo version_info // 实验信息 - 只有传入prod_id时展示
    2: i64 cnt // 涉及商品/实验 的数量
    3: basic_info.ProductBasicInfo product_info // 商品信息 - 只有传入prod_id时展示
    11: list<analysis.TargetCardEntity> target_list // 指标列表
}

struct GetAttributionABtestList{
    1: list<GetAttributionABtestInfo> product_list
    2: base.PageResp page_info // 分页信息
}

struct GetAttributionABtestListResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetAttributionABtestList data     // 返回结果

    255: base.BaseResp BaseResp
}

struct GetAttributionABtestProdListRequest {
    1: AttributionCommonBaseStruct base_req
    2: base.PageInfo page_req
    3: base.OrderByInfo order_by // 排序参数，不传的话默认 根据曝光PV倒排
    4: optional string version_id

    255: optional base.Base Base
}


// 商品原因-价格分布
struct GetAttributionProdPriceDistributionData {
    1: list<analysis.TargetTrendPoint> price_out
    2: list<analysis.TargetTrendPoint> price_xd
}

struct GetAttributionProdPriceDistributionResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetAttributionProdPriceDistributionData data

    255: base.BaseResp BaseResp
}


struct GetAttributionAnalysisBizListRequest{
    1: optional dimensions.BizType object_biz_type // 分析对象ID, 不传的话默认返回大盘
    255: optional base.Base Base
}

struct GetAttributionAnalysisBizListResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetAttributionAnalysisBizListItem data // 返回结果

    255: base.BaseResp BaseResp
}

struct GetAttributionAnalysisBizListItem{
    1: list<GetProductAnalysisBizInfo> biz_list
}

struct GetProductAnalysisBizInfo {
    1: dimensions.BizType object_biz_type // 分析对象的biz_type
    2: string biz_name
    3: list<GetAttributionTreeMetaData> support_biz_modules // 原因模块元信息，包含归因树原因下钻列表、原因的名称ID映射，筛选项
    4: AttributionTreeMeta tree_meta, // 归因树维度元信息
    5: FlowChangeMeta flow_change_meta, // 流量变化元信息
}

struct GetAttributionMultiDimAnalysisRequest{
    1: AttributionCommonBaseStruct base_req,
    2: string drill_target, // 下钻的指标
    3: optional bool need_cycle, // 是否下钻环比
    4: optional bool need_sync, // 是否下钻同比
    5: optional bool need_compare // 是否下钻对比时间

    255: optional base.Base Base
}

struct GetAttributionMultiDimAnalysisResponse{
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: required GetAttributionMultiDimAnalysisItem data // 返回结果

    255: base.BaseResp BaseResp
}

// 这里需要根据三个时间排序分别取Top3
struct GetAttributionMultiDimAnalysisItem{
    1: list<analysis.MultiDimFullListRow> cycle_list // 多维分析结果 - 环比
    2: list<analysis.MultiDimFullListRow> sync_list // 多维分析结果 - 同比
    3: list<analysis.MultiDimFullListRow> compare_list // 多维分析结果 - 对比时间
}
