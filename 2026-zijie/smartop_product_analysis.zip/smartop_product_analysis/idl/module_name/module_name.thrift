namespace py module_name
namespace go module_name

enum ModuleName {
    Unknown = 0
    // 诊断多维趋势分析
    DiagnosisMultiDimTrend = 1001
    // 货品分析多维分析
    ProductMultiDimAnalysis = 1002
    // 货品分析多维趋势分析
    ProductMultiDimTrend = 1003
    // XXXXX
    LibraMetricGroupAnalysis = 1004
}