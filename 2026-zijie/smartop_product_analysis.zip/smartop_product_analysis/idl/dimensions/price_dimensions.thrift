namespace py dimensions
namespace go dimensions

include "../base.thrift"
include "dimensions.thrift"

// 通用结构体
struct PriceAnalysisBaseStruct {
    1: required dimensions.BizType biz_type
    2: required dimensions.PriceComparisonType price_comparison_type // 比价类型
    3: required string start_date // 起始时间，格式为 yyyy-MM-dd
    4: required string end_date
    5: required base.DateType date_type // 日/周/月
    6: optional dimensions.AnalysisGranularity granularity // 分析粒度

    11: optional list<dimensions.SelectedDimensionInfo> dimensions // 人货场属性筛选
    12: optional list<dimensions.SelectedMultiDimensionInfo> group_attrs // 多维分析筛选，按维度顺序
}

// 价格力站内站外类型
enum PriceInOutType {
    PRICE_IN = 1
    PRICE_OUT = 2
}

// 价格力站内站外类型
enum PriceFlowStandardType {
    FlowStandard_NONE = 0
    FlowStandard_ALL  = 1
    FlowStandard_AA   = 2
    FlowStandard_CSPU = 3
}
