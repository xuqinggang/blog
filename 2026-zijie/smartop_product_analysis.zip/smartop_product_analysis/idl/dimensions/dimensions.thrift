namespace py dimensions
namespace go dimensions

include "../base.thrift"

// 业务线实体
enum PriceComparisonType {
    Hybrid   = 1    // B店混比(超值购) - 商品分析
    NewStage = 2    // 新阶梯(大盘用增)-商品策略 - 商品分析
}

// 业务线 - 最小粒度指标集合
enum BizType {
    Unknown                         = 0         // 未知
    GreatValueBuy                   = 1         // 超值购 - 商品分析
    GrowthProductStrategy           = 2         // 用增-商品策略 - 商品分析

    ProdDetail                      = 10001     // 商品画像
    A1GrowthProductStrategy         = 10002     // A1-大盘商品
    A2GrowthProductStrategy         = 10003     // A2-大盘商品
    A3GrowthProductStrategy         = 10004     // A3-大盘商品
    BGrowthProductStrategy          = 10005     // B-大盘商品
    ProdSeckill                     = 10006     // 秒杀商品
    GuessProduct                    = 10007     // 猜喜商品
    MorningMarketProduct            = 10008     // 早市商品
    GreatValueBuyLiquor             = 10009     // 超值购酒类商品
    DouyineCommerce                 = 10010     // 独立端全端商品
    DouyineMallCommerce             = 10011     // 独立端商城商品
    BrandTrial                      = 10012     // 试用商品
    MatchingBrain                   = 10013     // 选品大脑
    MixProduct                      = 10021     // Mix商品
    InflectionInsight               = 10023 
    SimilarProduct                  = 10024     // 相似商品
    MarketProjectProduct            = 10028     // 市集活动
    MarketingEngine                 = 10029     // 营销引擎
    PriceTrendSku                   = 20001     // sku价格力
    PriceTrendOrder                 = 20002     // 订单价格力
    PriceTrendShow                  = 20003     // 曝光价格力

    PriceAACompare                  = 30001     // 价格力变化AA分析

    AttributionCore                 = 40000     // 归因-整体
    AttributionFlowDistribute       = 40001     // 归因-流量分布
    AttributionPlatformGovrn        = 40101     // 归因-平台-治理
    AttributionPlatformlibra        = 40102     // 归因-平台-实验
    AttributionPlatformMarket       = 40103     // 归因-平台-营销活动
    AttributionPlatformBusiness     = 40104     // 归因-平台-经营动作

    AttributionProdBase             = 40201     // 归因-商品-基础
    AttributionProdQuality          = 40202     // 归因-商品-质量
    AttributionProdPrice            = 40203     // 归因-商品-价格
    AttributionProdService          = 40204     // 归因-商品-服务权益

    AttributionShopService          = 40301     // 归因-店铺-服务质量
    AttributionShopBusiness         = 40302     // 归因-店铺-经营动作

    AttributionContentSupplyQuality = 40401     // 归因-内容-载体供给与质量

    AttributionCoreGuess            = 41000     // 猜喜归因树 - 整体
    AttributionSupply               = 41101     // 供给原因
    AttributionFlow                 = 41201     // 流量原因
    AttributionQuality              = 41301     // 质量原因

    AttributionCoreGuessV2            = 42000   // 猜喜归因树V2

    ActivityReview                  = 50000     // 活动复盘
    BigPromotionSupply              = 50001     // 大促供给

    VolumePrice                     = 60001     // 量价模型
    ReversalExperiment              = 60002     // 大反转实验

    GuessDress                      = 70001     // 猜喜服饰大盘
    GuessDressA1                    = 70002     // 猜喜服饰A1
    GuessDressB                     = 70003     // 猜喜服饰B组


    SkuClusterCore                  = 80000     // SKU簇洞察
    SkuClusterBasicConstitution     = 80100     // SKU簇洞察-基本构成
    SkuClusterScaleAndMount         = 80101     // SKU簇洞察-簇规模和挂载
    SkuClusterCoverage              = 80102     // SKU簇洞察-大盘和重点品池覆盖率
    SkuClusterStability             = 80103     // SKU簇洞察-簇稳定性
    SkuClusterSupplyInsight         = 80200     // SKU簇洞察-供给质量
    SkuClusterSupplyQuality         = 80201     // SKU簇洞察-供给质量
    SkuClusterFlowInsight           = 80300     // SKU簇洞察-流量与效率洞察
    SkuClusterFlow                  = 80301     // SKU簇洞察-簇流量分发

    GuessBoostData                  = 90001     // 猜喜扶持效果
    BillionSupply                   = 90002     // 超值购供给

    GreatValueBuySearch             = 102000    // 超值购✖️搜索
    GreatValueBuyBigLink            = 101000    // 超值购✖️聚合链接

    BigActivityCore                 = 103000    // 大促整体
    BigActivityA1                   = 103001    // 大促xA1

    ProdReviewCore = 200000 // 复盘-大盘
    ProdReviewMarket = 200001 // 复盘-市集
    ProdReviewGreatValueBuy = 201000 // 复盘-超值购
    ProdReviewBigPromotion = 200200 // 复盘-大促
    ProdReviewSeckill = 200300 // 复盘-秒杀
    ProdReviewGovSubsidy = 200400 // 复盘-政府补贴
    ProdReviewGuess = 200500 // 复盘-猜喜
    ProdReviewSearch = 200600 // 复盘-搜索
    ProdReviewLibraMetricGroup = 210000 // 复盘-指标组分析



    ProdSelectAlgorithm             = 300000    // 选品-0补爆品
    ProdSelectZeroChannelSubsidy    = 300100    // 选品-0补频道爆品
    ProdSelectManual                = 300200    // 选品-人工
    ProdSelectNavigation            = 310000    // 选品-领航
}

// 粒度 - 商品 SKU
enum AnalysisGranularity {
    PROD = 1    // 商品粒度
    SKU  = 2    // sku粒度
}

// 货品池类型
enum ProductPoolType{
    PotentialCustomerPool  = 1    // 潜客曝光池
    NewCustomerConvertPool = 2    // 拉新转化池
    RecallShowPool         = 3    // 召回曝光池
    RecallConvertPool      = 4    // 召回转化池
    ExplosiveSubsidyPool   = 5    // 超值购报名货品池
}

// 枚举类型
enum EnumType {
    NoEnum      = 0    // 无枚举
    StaticEnum  = 1    // 静态枚举
    DynamicEnum = 2    // 动态枚举
}

// 维度属性类型
enum DimensionAttributeType {
    User    = 1    // 用户属性
    Product = 2    // 商品属性
    Place   = 3    // 场域属性
    Order   = 4    // 订单属性
}

enum ConclusionModule{
    TargetCard    = 1    // 指标卡核心结论
    GroupAnaglsis = 2    // 多维分析核心结论
}

// 过滤维度的筛选类型
enum FilterDimCategory {
    None           = 0    // 无
    PotentialUsers = 1    // 潜客
    NewUser        = 2    // 新客首单
    RecallUser     = 3    // 召回首单
}

// 分析对比类型
enum CompareType {
    DateCompare                          = 10001    // 内部-时间周期对比
    MarketingPromotionGrowthLibraCompare = 20001    // 外部-增长数据平台-实验组对照组对比
}

// 分析口径
enum AnalysisAggregationType {
    WeekDaily  = 1    // 周日均
    WeekSum    = 2    // 周累计
    MonthDaily = 3    // 月日均
    MonthSum   = 4    // 月累计
}

struct GetDataReadyTimeRequest{
    1: required BizType      biz_type

    255: optional base.Base  Base
}

struct GetDataReadyTimeResponse{
    1: DataReadyTime             data

    255: optional base.BaseResp  BaseResp
}

struct DataReadyTime{
    1: string           oldest_partition  // 最早的筛选时间
    2: string           newest_partition  // 最新的筛选时间
    3: i64              max_date_range    // 最大可选时间跨度
    4: list<DateRange>  date_range_info   // 选择时间跨度信息
}

struct DateRange {
    1: base.DateType  date_type       // 时间类型
    2: i64            min_date_range  // 最小可选时间跨度
    3: i64            max_date_range  // 最大可选时间跨度
}

// 获取维度列表
struct GetDimensionListRequest {
    1: required BizType      biz_type

    255: optional base.Base  Base
}

enum BizModule {
    AbnormalAttribution = 0 // 异动归因
    Guess = 1  // 猜喜
    GreatValueBuy = 2  // 超值购
    BigActivity = 3  // 大促视图
    ProdPoolReview = 4 // 货盘复盘
    ProdPoolReviewCore          = 5    // 货盘复盘-大盘
    ProdPoolReviewMarket          = 6    // 货盘复盘-商城加补
    ProdPoolReviewGreatValueBuy          = 7    // 货盘复盘-超值购
    ProdPoolReviewBigPromotion = 8       // 货盘复盘-大促
    ProdPoolReviewSeckill = 9            // 货盘复盘-秒杀
    ProdPoolReviewGovSubsidy = 10        // 货盘复盘-政府补贴
    ProdPoolReviewGuess = 11             // 货盘复盘-猜喜
    ProdPoolReviewSearch = 12            // 货盘复盘-搜索
    GuessAbnormalAttribution = 13        // 猜喜异动归因
    MarketingEngine = 14            // 营销引擎
    ProdPoolReviewLibraMetricGroup = 15 // 货盘复盘-指标组分析
}


// 获取维度列表
struct GetProductAnalysisBizListRequest {
    1: BizModule             biz_module
    255: optional base.Base  Base
}

// 维度简单版本
struct DimSimpleElement {
    1: string  id    // 维度ID
    2: string  code  // 枚举code
    3: string  name  // 枚举名称
}

// 枚举信息
struct EnumElement {
    1: string                  code             // 枚举code
    2: string                  name             // 枚举名称
    3: list<string>            type_value       // 当展示组建类型为范围时，第一个元素 = NEGATIVE_INFINITY 表示负无穷（<=），第二个元素 = POSITIVE_INFINITY 表示正无穷（>=）

    5: list<DimSimpleElement>  depend_code      // 依赖枚举code
    6: bool                    is_default_show  // 该枚举是否默认选择

    100: LegendExtraInfo       legend_extra     // 图例相关的额外参数
    101: string                create_user_id   // 创建人
    102: string                link_url         // 相关跳转链接

    103: string                extra_info       // 额外信息，json
}

struct LegendExtraInfo{
    1: bool       is_main    // 是否主体维度项(分层趋势图用于区分整体指标值和下钻的维度枚举)
    2: graphType  show_type  // 该图例的展示形式
}

enum graphType{
    LineChart = 1,    // 折线图
    BarChart  = 2,    // 柱状图
}

enum DimGroup{
    BigActivity = 0    // 大促
    Overall     = 1    // 大盘
}

struct DimensionInfo {
    1: string                  id                         // 维度ID
    2: string                  show_name                  // 展示名称
    3: string                  show_type                  // 展示类型 multi_select=复选，single_select=单选，amount_range_input=金额范围输入，tree_select=级联
    4: DimensionAttributeType  dimension_category         // 属性类型：人 货 场
    5: bool                    is_multi_dim               // 是否支持 多维分析
    7: bool                    is_default_show            // 是否默认展示
    8: EnumType                enum_type                  // 枚举类型
    9: list<EnumElement>       values                     // 枚举值

    10: list<string>           reject_dim_ids             // 互斥维度IDs

    11: bool                   need_page_search           // 动态枚举情况下，是否需要分页2次查询

    21: string                 dimension_group            // 维度分组
    22: i64                    dimension_group_order      // 维度分组排序
    23: i64                    dimension_group_dim_order  // 维度分组下维度的顺序
    24: list<DimGroup>         dim_groups                 // 业务线下所属分组
}

// 指标通用结构体
struct TargetElementValue {
    1: required string  id       // 唯一标识id
    2: required string  name     // 展示名称
    3: required string  formula  // 公式
}

struct ThresholdAttrMeta {
    1: ThresholdType             type        // 计算指标阈值的类型
    2: list<TargetElementValue>  value_list  // 可以筛选的指标
}

struct GetDimensionListData {
    1: list<DimensionInfo>               user_dimensions      // 用户属性维度
    2: list<DimensionInfo>               product_dimensions   // 商品属性维度
    3: list<DimensionInfo>               place_dimensions     // 场域属性维度
    4: list<ThresholdAttrMeta>           threshold_attr_meta  // 指标阈值筛选信息
    5: list<SelectedMultiDimensionInfo>  default_group_attrs  // 默认多维分析维度

    6: list<DimensionInfo>               order_dimensions     // 订单属性维度
}

struct GetDimensionListResponse {
    1: required i32                   code      // 状态码 0: 成功
    2: required string                msg       // 出错提示消息
    3: required GetDimensionListData  data      // 返回结果

    255: optional base.BaseResp       BaseResp
}


// 获取维度、枚举搜索列表
struct GetDimensionEnumSearchListRequest {
    1: required BizType      biz_type
    2: string                search_key

    255: optional base.Base  Base
}

struct GetDimensionEnumSearchListResponse {
    1: required i32                  code      // 状态码 0: 成功
    2: required string               msg       // 出错提示消息
    3: required list<DimensionInfo>  data      // 返回结果

    255: optional base.BaseResp      BaseResp
}

// 分页动态枚举
struct GetDimensionPageEnumListRequest {
    1: required string                       dimension_id           // 维度ID
    2: optional string                       search_enum_name       // 搜索枚举值名称，不传则返回全部
    3: optional list<string>                 search_enum_name_list  // 搜索枚举值名称列表，不传则返回全部
    4: optional list<SelectedDimensionInfo>  depend_dims            // 已经选择的依赖维度
    5: base.PageInfo                         page_info              // 页数 从1开始
    6: optional list<string>                 enum_code_list         // 枚举code列表
    7: optional BizType                      biz_type               // 业务线

    255: optional base.Base                  Base
}

struct GetDimensionPageEnumInfo {
    1: list<EnumElement>  enum_list  // 枚举信息
    2: base.PageResp      page_info  // 页码
}

// 标签-获取标签组件复杂查询-分页枚举返回体
struct GetDimensionPageEnumListResponse {
    1: required i32                       code      // 状态码 0: 成功
    2: required string                    msg       // 出错提示消息
    3: required GetDimensionPageEnumInfo  data      // 返回结果

    255: base.BaseResp                    BaseResp
}

/**
* 构建通用结构体
**/
struct SelectedDimensionInfo {
    1: string                  id                 // 维度ID
    2: string                  name               // 维度name
    3: DimensionAttributeType  attr_type          // 人货场属性类型
    7: base.OperatorType       selected_operator  // 已选择的操作符
    8: list<EnumElement>       selected_values    // 已选择的枚举信息
    9: i32                     editable           // 是否可编辑
    99: bool                   is_group           // 是否多维分析的参数
}

// 多维分析的基础info
struct SelectedMultiDimensionInfo {
    1: required SelectedDimensionInfo  dim_info
    2: bool                            need_drill_down  // 是否下钻
    3: EnumElement                     value            // 所下钻的枚举值value
}

// 指标阈值筛选类型
enum ThresholdType {
    TOP_THRESHOLD                // 指标排序TopN的商品
    CONTRIBUTION_THRESHOLD       // 贡献度top n%的商品
    ACC_THRESHOLD                // 精准阈值 eg：曝光pv>10000
    BIGSALE_HOT_SCORE_THRESHOLD  // 大促爆发系数

    TOP_THRESHOLD_ABSOLUTE_DATE  // 指标排序TopN的商品-绝对日期范围
    ACC_THRESHOLD_ABSOLUTE_DATE  // 精准阈值-绝对日期范围
    TOP_THRESHOLD_RELATIVE_DATE  // 指标排序TopN的商品-相对日期范围
    ACC_THRESHOLD_RELATIVE_DATE  // 精准阈值-相对日期范围
}

enum DateRuleType {
    AbsoluteDateRange = 1 // 绝对日期范围
    RelativeDateRange = 2 // 相对日期范围
}

struct DateRule {
    1: required DateRuleType type  // 日期规则类型
    10: optional string start_date // 指标开始时间
    11: optional string end_date   // 指标结束时间
    15: optional i64 day           // 近day天
}

// 指标阈值筛选，top_percent和acc_threshold只能传一个，有互斥关系
struct ThresholdAttr {
    1: required ThresholdType  type           // 计算指标阈值的类型
    2: required string         key            // 需要计算阈值的指标英文名
    3: optional i64            top_n          // TopN or 贡献度 top n%, 根据type取不同含义
    4: optional AccThreshold   acc_threshold  // 精准阈值

    10: optional DateRule      date_rule      // 日期规则
}

struct AccThreshold{
    1: base.OperatorType  operator   // 计算符，支持 >=、>、<=、<
    2: double             threshold  // 阈值
}

// 通用结构体
struct ProductAnalysisBaseStruct {
    1: required BizType                            biz_type            // 业务线
    2: required string                             start_date          // 起始时间，格式为 yyyy-MM-dd
    3: required string                             end_date
    4: required string                             compare_start_date  // 对比时间
    5: required string                             compare_end_date    // 对比时间
    7: optional list<SelectedDimensionInfo>        dimensions          // 人货场属性筛选
    8: optional list<ThresholdAttr>                threshold_attrs     // 指标阈值筛选
    9: optional base.LogicalExprType               threshold_expr      // 且，或

    10: optional list<SelectedMultiDimensionInfo>  group_attrs         // 多维分析筛选，按维度顺序
    11: optional bool                              uv_flag             // true 计算uv指标，false不计算，默认不计算（不传也是不计算）
    12: list<string>                               target_meta_list    // 要获取的指标列表，值为业务指标唯一标识的name,传入顺序就是返回顺序
    13: optional CompareType                       compare_type
    14: optional bool                              is_total            // 标识是否是整体规则（主要影响group_attrs的逻辑计算）
    15: optional bool                              no_compare          // 无需对比
}

// 自然语言处理分析
struct GenerateDimensionWithNlpRequest {
    1: required BizType      biz_type
    2: required string       text      // 输入的语言文字

    255: optional base.Base  Base
}

struct GenerateDimensionWithNlpData {
    1: ProductAnalysisBaseStruct  base_struct  // 基础属性筛选
    2: i32                        warn_code    // 0 解析成功， 1 存在警告，提示警告文案
    3: string                     warn_msg     // 警告信息，存在则提示警告文案
}

struct GenerateDimensionWithNlpResponse {
    1: required i32                           code      // 状态码 0: 成功
    2: required string                        msg       // 出错提示消息
    3: required GenerateDimensionWithNlpData  data      // 返回结果

    255: base.BaseResp                        BaseResp
}

struct GetPriceHybridTagEnumListRequest {
    1: required BizType      biz_type

    255: optional base.Base  Base
}

struct GetPriceHybridTagEnumListResponse {
    1: required i32                     code      // 状态码 0: 成功
    2: required string                  msg       // 出错提示消息
    3: required list<DimSimpleElement>  data      // 返回结果

    255: base.BaseResp                  BaseResp
}

struct GetProductAnalysisBizInfo {
    1: BizType biz_type
    2: string biz_name
    3: list<SelectedDimensionInfo> required_dim_info
    4: string user_dimension_code
    5: bool have_permission
    6: list<string> hidden_module // 隐藏模块
    7: bool is_directory // 是否是目录
    8: string directory_name // 目录名称
    9: list<GetProductAnalysisBizInfo> children // 子目录
    10: i64 depend_biz_id // 依赖的业务线ID
}

struct GetProductAnalysisBizData {
    1: list<GetProductAnalysisBizInfo>  biz_list
    2: string                           parent_user_dimension_code
}

struct GetProductAnalysisBizListResponse {
    1: required i32                        code      // 状态码 0: 成功
    2: required string                     msg       // 出错提示消息
    3: required GetProductAnalysisBizData  data      // 返回结果

    255: base.BaseResp                     BaseResp
}

enum SystemSource {
    Common      = 0    // 普通指标
    GoodsSupply = 1    // 货补指标
    Uv          = 2    // UV指标
}

struct TargetMetaInfo {
    1: string        name                          // 指标名(主要用于传参) eg: order_num
    2: string         display_name                  // 指标显示名 eg: 支付订单数
    3: string         tips                          // 指标提示(hover文案)
    4: i64            display_order                 // 展示顺序
    5: i64            target_precision
    6: string         calc_agg_method
    7: string         calc_agg_expr
    8: i64            calc_type
    9: string         value_type
    10: string        value_unit                    // 指标的单位 eg: 单
    11: string        attribute_type
    12: bool          is_potential_customer_target
    13: bool          is_distribution
    14: bool          is_target_distribution
    15: bool          is_compute_percent
    16: bool          is_larger_advantage
    17: bool          need_second_query
    18: bool          is_use_pp
    19: string        effect_module
    20: SystemSource  system_source                 // 系统来源  1 货补指标  2 UV指标
    21: bool          is_default_show               // 是否默认展示
    22: BizType       biz_type                      // 业务线 eg: 用增、超值购、SKU价格力等
    23: i64           attribute_type_order          // 组排序
}

struct GetProductAnalysisTargetMetaListRequest {
    1: required BizType      biz_type
    255: optional base.Base  Base
}

struct GetProductAnalysisTargetMetaListResponse {
    1: required i32                   code      // 状态码 0: 成功
    2: required string                msg       // 出错提示消息
    3: required list<TargetMetaInfo>  data      // 返回指标列表

    255: optional base.BaseResp       BaseResp
}

struct UpdatePoolStatusRequest{
    255: optional base.Base  Base
}

struct UpdatePoolStatusResponse{
    1: required i32              code      // 状态码 0: 成功
    2: required string           msg       // 出错提示消息
    255: optional base.BaseResp  BaseResp
}

enum RegisterDimensionType {
    InvestmentSelectProd = 1 // 招商选品包
    SelectProd360 = 2        // 360选品包
    CrowdPackage = 3         //  人群包
    RecruitProd = 4          //  招募策略商品包
}

struct DimensionSyncMap {
    1: required list<string> InvestmentSelectProd // 招商选品包
    2: required list<string> SelectProd360        // 360选品包
    3: required list<string> CrowdPackage         // 人群包
    4: required list<string> RecruitProd          // 招募策略商品包
}

struct RegisterNeedDumpDimensionRequest{
    1: list<string>           entity_ids
    2: RegisterDimensionType  register_dimension_type
    3: map<RegisterDimensionType, list<string>> register_dimension_map // 批量同步注册

    255: optional base.Base   Base
}

struct RegisterNeedDumpDimensionResponse{
    1: required i32              code      // 状态码 0: 成功
    2: required string           msg       // 出错提示消息
    3: required bool             data      // 返回指标列表

    255: optional base.BaseResp  BaseResp
}

// 获取维度同步状态
struct GetDumpDimensionStatusRequest {
    1: map<RegisterDimensionType, list<string>> query_dimension_map // 批量获取维度状态
    255: optional base.Base Base
}

// 商品流量洞察平台状态
enum AnalysisStatus {
    UnRegister = 0    // 未注册
    FinishDump = 1    // 以同步
    NotFinishDump = 2 // 未同步
    DumpIng = 3       // 同步中
}

// 平台状态
enum PlatformStatus {
    UnRegister = 0   // 未注册
    Registered = 1  // 已注册
    Deleted = 2     // 已删除
    Expired = 3     // 已过期
    Calculating = 4 // 计算中
}

struct DumpDimensionInfo {
    1: string entity_id
    2: string entity_name
    3: RegisterDimensionType dimension_type // 维度
    4: string creator                       // 创建人
    5: AnalysisStatus analysis_status       // 商品流量洞察的状态，如：同步中，已同步，未同步等
    6: PlatformStatus platform_status       // 在平台的状态，如：已注册、已删除、已过期等
    7: string create_time                   // 创建时间
    8: string update_time                   // 更新时间
    9: list<string> have_dump_dates         // 已经同步的日期，[20260101,20260102,20260103]
    10: string extra_info                   // 其它信息
    11: i32 is_del                          // 是否删除
}

struct DumpDimensionStatusResponse {
    1: required i32 code                 // 状态码 0: 成功
    2: required string msg               // 出错提示消息
    3: required list<DumpDimensionInfo> data // 返回指标列表
    255: optional base.BaseResp BaseResp
}