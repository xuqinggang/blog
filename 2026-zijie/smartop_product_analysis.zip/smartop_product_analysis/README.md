# 商品流量洞察服务

## 研发指南
- Go版本：1.19
- Kitex生成命令：`make gen`