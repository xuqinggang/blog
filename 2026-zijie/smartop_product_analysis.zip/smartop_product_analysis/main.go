package main

import (
	"log"

	"code.byted.org/ecom/dogo/extension"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/fornax"
	"code.byted.org/ecom/smartop_product_analysis/biz/ai_infra/mcp"
	"code.byted.org/ecom/smartop_product_analysis/biz/extension_domain"

	arctic_framework_sdk "code.byted.org/ecom/smartop_arctic_framework_sdk"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/redis"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc"

	// "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"

	"code.byted.org/ecom/smartop_product_analysis/biz/service/cronjob"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/libra"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tos"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/tqs"
	"code.byted.org/ecom/smartop_product_analysis/eventbus/consumer/subscription"
	product_analysis "code.byted.org/ecom/smartop_product_analysis/kitex_gen/ecom/smartop/product_analysis/smartopproductanalysisservice"
	"code.byted.org/ecom/smartop_product_analysis/middleware"
	"code.byted.org/kite/kitex/server"
	"github.com/cloudwego/kitex/pkg/remote/codec/thrift"
)

func main() {
	opts := []server.Option{
		server.WithMiddleware(middleware.CtxLog),
		server.WithMiddleware(middleware.CacheHit),
		server.WithPayloadCodec(thrift.NewThriftCodecWithConfig(thrift.FrugalWrite | thrift.FrugalRead | thrift.EnableSkipDecoder)),
	}
	svr := product_analysis.NewServer(new(SmartopProductAnalysisServiceImpl), opts...)

	redis.Init()
	mysql.Init()
	tcc.Init()
	// ai_analysis_service.Init()
	arctic_framework_sdk.Init()
	fornax.Init()
	tqs.Init()
	tos.Init()
	mcp.Init()
	libra.Init()
	lark_service.Init()
	biz_utils.InitOneserviceClient()
	biz_utils.SupplementLogicTableIdMap()
	cronjob.StartPoolSyncCronJob()
	cronjob.StartProductSelectTaskCronJob()
	cronjob.StartDorisEmbeddingCronJob()
	cronjob.StartDimensionsSyncCronJob()
	subscription.ConsumerRun()
	//lark.MarketLarkInit()
	// 扩展点框架
	extension.Init()
	// 初始化 extension_domain 扩展点
	extension_domain.Init()
	// 业务扩展点注册

	err := svr.Run()
	if err != nil {
		log.Println(err.Error())
	}
}
