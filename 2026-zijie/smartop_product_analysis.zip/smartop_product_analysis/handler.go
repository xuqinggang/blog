package main

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/aggregate"
	file "code.byted.org/ecom/smartop_product_analysis/kitex_gen/file"
	test "code.byted.org/ecom/smartop_product_analysis/kitex_gen/test"

	multi_dim_trend_service "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_trend_domain/service"
	ai_strategy_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/ai_strategy"
	file_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/file"
	multi_dim_table_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/multi_dim_table"
	multi_dim_trend_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/multi_dim_trend"

	multi_dim_table_service "code.byted.org/ecom/smartop_product_analysis/biz/extension_domain/multi_dim_table_domain/service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/activity_service"
	ai_analysis_tools "code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service/tools"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_conclusion_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_strategy_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/cronjob"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/file_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/lark_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_review_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/product_select_service"
	"code.byted.org/gopkg/jsonx"

	activity_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/activity"
	ai_analysis_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/ai_analysis"
	lark_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/lark"
	product_review_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/product_review"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/ai_analysis_service"
	common_request "code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_request"
	common_response "code.byted.org/ecom/smartop_product_analysis/kitex_gen/common_response"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ecom/smartop/product_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/lark"
	prod_review "code.byted.org/ecom/smartop_product_analysis/kitex_gen/prod_review"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/product_select"

	"code.byted.org/ecom/smartop_product_analysis/biz/handler/attribution"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/big_activity_optimize"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/dorado_task_handler"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/plan_boost"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/price_aa_analysis"
	sku_cluster_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/sku_cluster"
	subscription_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/subscription"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/volume_price_handler"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_dump_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/attribution_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/great_value_buy_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_aa_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/price_analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/prod_portrait"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/sku_cluster_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/volume_price_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	activity "code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity"

	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/ai_analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dorado_task"
	great_value_buy "code.byted.org/ecom/smartop_product_analysis/kitex_gen/great_value_buy"
	sku_cluster "code.byted.org/ecom/smartop_product_analysis/kitex_gen/sku_cluster"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	activity_review_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/activity_review"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/alert"
	analysis_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/analysis"
	analysis_pool_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/analysis_pool"
	analysis_pool_diagnosis_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/analysis_pool_diagnosis"
	analysis_pool_product_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/analysis_pool_product"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/dimension"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/export"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/feedback"
	great_value_buy_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/great_value_buy"
	product_select_handler "code.byted.org/ecom/smartop_product_analysis/biz/handler/product_select"
	"code.byted.org/ecom/smartop_product_analysis/biz/handler/template"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/activity_review_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/alert_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_diagnosis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_product_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_pool_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/analysis_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/export_data"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/feedback_service"
	subscription_service "code.byted.org/ecom/smartop_product_analysis/biz/service/subscription"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/template_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_alert_rule"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_diagnosis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis_pool_product"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/subscription"
	volume_price "code.byted.org/ecom/smartop_product_analysis/kitex_gen/volume_price"
	"code.byted.org/gopkg/logs"
)

// 依赖分层 Main --> Handler --> Service --> Dao
var DimensionListDao = &dao.DimensionListDao{}
var DimensionEnumDao = &dao.DimensionEnumDao{}
var ActivityDao = &dao.ActivityDao{}
var ProductReviewStrategyDao = &dao.ProductReviewStrategyDao{}
var ProductReviewReportDao = &dao.ProductReviewReportDao{}
var ProductSelectTaskDao = &dao.ProductSelectTaskDao{}
var ProductReviewStrategyTypeDao = &dao.ProductReviewStrategyTypeDao{}
var ProductReviewBizProjectDao = &dao.ProductReviewBizProjectDao{}
var ProductReviewStrategyRelationDao = &dao.ProductReviewStrategyRelationDao{}
var DimensionBizListDao = &dao.DimensionBizListDao{}
var AttributeDao = &dao.AttributeDao{}
var VolumePriceDao = &dao.VolumePriceDao{}
var PoolDumpStatusDao = &dao.PoolDumpStatusDao{}
var ActivityReviewSupplyDao = &dao.ActivityReviewSupplyDao{}
var AIConclusionDao = &dao.AIConclusionDao{}
var AIStrategyDao = &dao.AIStrategyDao{}
var AIStrategyTaskDao = &dao.AIStrategyTaskDao{}
var FlightAnalysisDao = &dao.FlightAnalysisDao{}

var DimensionService = &dimension_service.DimensionService{
	DimensionListDao:    DimensionListDao,
	DimensionEnumDao:    DimensionEnumDao,
	AttributeDao:        AttributeDao,
	DimensionBizListDao: DimensionBizListDao,
}

var AnalysisService = &analysis_service.AnalysisService{
	DimensionListDao: DimensionListDao,
	DimensionEnumDao: DimensionEnumDao,
	AttributeDao:     AttributeDao,
	DimensionService: DimensionService,
}

var CommonTool = &ai_analysis_tools.CommonTool{
	DimensionService: DimensionService,
}
var AIAnalysisService = &ai_analysis_service.AIAnalysisService{
	DimensionBizListDao: DimensionBizListDao,
	DimensionEnumDao:    DimensionEnumDao,
	DimensionService:    DimensionService,
	DimensionListDao:    DimensionListDao,
	AnalysisService:     AnalysisService,
	ProdPortraitService: ProdPortraitService,
	LarkService:         LarkService,
	CommonTool:          CommonTool,
}
var DynamicGetData = &ai_conclusion_service.DynamicGetData{
	ProductReviewService: ProductReviewService,
	DimensionService:     DimensionService,
	DimensionBizListDao:  DimensionBizListDao,
	MultiDimTableService: MultiDimTableService,
	AIAnalysisService:    AIAnalysisService,
	DimensionListDao:     DimensionListDao,
	CommonTool:           CommonTool,
}
var AIConclusionService = &ai_conclusion_service.AIConclusion{
	AIConclusionDao: AIConclusionDao,
	DynamicGetData:  DynamicGetData,
}
var AIStrategyService = &ai_strategy_service.AIStrategyService{
	LarkService:       LarkService,
	AIAnalysisService: AIAnalysisService,
	AIStrategyDao:     AIStrategyDao,
	AIStrategyTaskDao: AIStrategyTaskDao,
	FlightAnalysisDao: FlightAnalysisDao,
}
var ActivityService = &activity_service.ActivityService{
	ActivityDao: ActivityDao,
}
var ProductReviewService = &product_review_service.ProductReviewService{
	BizProjectDao:        ProductReviewBizProjectDao,
	StrategyDao:          ProductReviewStrategyDao,
	ReportDao:            ProductReviewReportDao,
	StrategyTypeDao:      ProductReviewStrategyTypeDao,
	StrategyRelationDao:  ProductReviewStrategyRelationDao,
	AnalysisService:      AnalysisService,
	DimensionService:     DimensionService,
	MultiDimTableService: MultiDimTableService,
	DimensionListDao:     DimensionListDao,
	BizListDao:           DimensionBizListDao,
}
var ProductSelectService = &product_select_service.ProductSelectService{
	SelectTaskDao: ProductSelectTaskDao,
}
var TemplateService = &template_service.TemplateService{
	AnalysisService: AnalysisService,
}
var FeedBackService = &feedback_service.FeedBackService{}
var ExportService = &export_data.ExportService{
	AnalysisService:      AnalysisService,
	DimensionListDao:     DimensionListDao,
	PriceAAService:       PriceAAService,
	PriceAnalysisService: PriceAnalysisService,
	ProdPortraitService:  ProdPortraitService,
}
var PriceAnalysisService = &price_analysis_service.PriceAnalysisService{
	DimensionListDao: DimensionListDao,
	DimensionEnumDao: DimensionEnumDao,
	AttributeDao:     AttributeDao,
	DimensionService: DimensionService,
}

var ProdPortraitService = &prod_portrait.ProdPortraitService{
	DimensionListDao: DimensionListDao,
	DimensionEnumDao: DimensionEnumDao,
	AttributeDao:     AttributeDao,
	DimensionService: DimensionService,
}

var AttributionService = &attribution_service.AttributionService{
	DimensionListDao: DimensionListDao,
	DimensionEnumDao: DimensionEnumDao,
	AttributeDao:     AttributeDao,
	DimensionService: DimensionService,
}

var GreatValueBuyService = &great_value_buy_service.GreatValueBuyService{
	DimensionListDao:    DimensionListDao,
	DimensionEnumDao:    DimensionEnumDao,
	AttributeDao:        AttributeDao,
	DimensionService:    DimensionService,
	DimensionBizListDao: DimensionBizListDao,
	AnalysisService:     AnalysisService,
}

var VolumePriceService = &volume_price_service.VolumePriceService{
	DimensionListDao: DimensionListDao,
	DimensionEnumDao: DimensionEnumDao,
	AttributeDao:     AttributeDao,
	DimensionService: DimensionService,
	AnalysisService:  AnalysisService,
	VolumePriceDao:   VolumePriceDao,
}

var SkuClusterService = &sku_cluster_service.SkuClusterService{
	DimensionListDao:   DimensionListDao,
	DimensionEnumDao:   DimensionEnumDao,
	AttributeDao:       AttributeDao,
	DimensionService:   DimensionService,
	AnalysisService:    AnalysisService,
	AttributionService: AttributionService,
}

var MultiDimTableService = &multi_dim_table_service.MultiDimTableService{
	BizProjectDao:       ProductReviewBizProjectDao,
	StrategyDao:         ProductReviewStrategyDao,
	ReportDao:           ProductReviewReportDao,
	StrategyTypeDao:     ProductReviewStrategyTypeDao,
	StrategyRelationDao: ProductReviewStrategyRelationDao,
	AnalysisService:     AnalysisService,
	DimensionService:    DimensionService,
}

var AnalysisPoolDumpService = &analysis_pool_dump_service.AnalysisPoolDumpService{
	PoolDumpStatusDao: PoolDumpStatusDao,
}

var LarkService = &lark_service.LarkService{}

var MultiDimTrendService = &multi_dim_trend_service.MultiDimTrendService{}

var SubscriptionService = &subscription_service.SubscriptionService{DimensionService: DimensionService}

var DimensionHandler = &dimension.DimensionHandler{DimensionService: DimensionService}
var AnalysisHandler = &analysis_handler.AnalysisHandler{AnalysisService: AnalysisService}
var TemplateHandler = &template.TemplateHandler{TemplateService: TemplateService}
var ExportHandler = &export.ExportHandler{ExportService: ExportService}
var FeedbackHandler = &feedback.FeedbackHandler{FeedbackService: FeedBackService}
var PriceAnalysisHandler = &analysis_handler.PriceAnalysis{PriceAnalysisService: PriceAnalysisService}
var ProdPortraitHandler = &analysis_handler.ProdPortraitHandler{ProdPortraitService: ProdPortraitService}
var AttributionHandler = &attribution.AttributionHandler{AttributionService: AttributionService}
var GreatValueBuyHandler = &great_value_buy_handler.GreatValueBuyHandler{GreatValueBuyService: GreatValueBuyService}
var VolumePriceHandler = &volume_price_handler.VolumePriceHandler{VolumePriceService: VolumePriceService}
var DoradoTaskHandler = &dorado_task_handler.DoradoTaskHandler{AnalysisPoolDumpService: AnalysisPoolDumpService}
var SubscriptionHandler = &subscription_handler.SubscriptionHandler{SubscriptionService: SubscriptionService}
var SkuClusterHandler = &sku_cluster_handler.SkuClusterHandler{SkuClusterService: SkuClusterService}
var ActivityHandler = &activity_handler.ActivityHandler{ActivityService: ActivityService}
var AIAnalysisHandler = &ai_analysis_handler.AIAnalysisHandler{AIAnalysisService: AIAnalysisService, AIConclusionService: AIConclusionService}
var AIStrategyHandler = &ai_strategy_handler.AIStrategyHandler{AIStrategyService: AIStrategyService}
var ProductReviewHandler = &product_review_handler.ProductReviewHandler{ProductReviewService: ProductReviewService, DimensionService: DimensionService}
var ProductSelectHandler = &product_select_handler.ProductSelectHandler{ProductSelectService: ProductSelectService}
var LarkHandler = &lark_handler.LarkHandler{LarkService: LarkService}
var MultiDimTrendHandler = &multi_dim_trend_handler.MultiDimTrendHandler{MultiDimTrendService: MultiDimTrendService}
var MultiDimTableHandler = &multi_dim_table_handler.MultiDimTableHandler{MultiDimTableService: MultiDimTableService, ProductReviewHandler: ProductReviewHandler}

var AlertService = &alert_service.AlertService{
	DimensionListDao: DimensionListDao,
}
var AnalysisPoolService = &analysis_pool_service.AnalysisPoolService{
	DimensionService:        DimensionService,
	AnalysisPoolDumpService: AnalysisPoolDumpService,
}
var AnalysisPoolProductService = &analysis_pool_product_service.AnalysisPoolProductService{
	DimensionListDao: DimensionListDao,
}
var AnalysisPoolDiagnosisService = &analysis_pool_diagnosis_service.AnalysisPoolDiagnosisService{}
var FileService = &file_service.FileService{}
var FileHandler = &file_handler.FileHandler{FileService: FileService}

var AlertHandler = &alert.AlertHandler{AlertService: AlertService}
var AnalysisPoolHandler = &analysis_pool_handler.AnalysisPoolHandler{AnalysisPoolService: AnalysisPoolService}
var AnalysisPoolDiagnosisHandler = &analysis_pool_diagnosis_handler.AnalysisPoolDiagnosisHandler{AnalysisPoolDiagnosisService: AnalysisPoolDiagnosisService}
var AnalysisPoolProductHandler = &analysis_pool_product_handler.AnalysisPoolProductHandler{AnalysisPoolProductService: AnalysisPoolProductService}

var ActivityReviewService = &activity_review_service.ActivityReviewService{
	DimensionService:        DimensionService,
	DimensionListDao:        DimensionListDao,
	ActivityReviewSupplyDao: ActivityReviewSupplyDao,
}
var ActivityReviewHandler = &activity_review_handler.ActivityReviewHandler{ActivityReviewService: ActivityReviewService}

var PriceAAService = &price_aa_service.PriceAAService{
	DimensionListDao: DimensionListDao,
	DimensionEnumDao: DimensionEnumDao,
	AttributeDao:     AttributeDao,
	DimensionService: DimensionService,
}
var PriceAAHandler = &price_aa_analysis.AnalysisAAHandler{PriceAAService: PriceAAService}
var BoostAnalysisHandler = &plan_boost.BoostAnalysisHandler{
	AnalysisService:     AnalysisService,
	AnalysisPoolHandler: AnalysisPoolHandler,
}

var BigActivityOptimize = &big_activity_optimize.BigActivityOptimize{
	GreatValueBuyService: GreatValueBuyService,
}

// SmartopProductAnalysisServiceImpl implements the last service interface defined in the IDL.
type SmartopProductAnalysisServiceImpl struct{}

// GetDimensionList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDimensionList(ctx context.Context, req *dimensions.GetDimensionListRequest) (resp *dimensions.GetDimensionListResponse, err error) {
	resp, err = DimensionHandler.HandlerGetDimensionList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetDimensionListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisCoreOverview(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreOverviewResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisCoreOverview(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisCoreHierarchical implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisCoreHierarchical(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreHierarchicalResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisCoreHierarchical(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisCoreHierarchicalResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisMultiDimProductList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimProductList(ctx context.Context, req *analysis.GetProductAnalysisMultiDimProductListRequest) (resp *analysis.GetProductAnalysisMultiDimProductListResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisMultiDimProductList(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisMultiDimProductListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// CreateTemplate implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateTemplate(ctx context.Context, req *dimensions.CreateOrUpdateTemplateRequest) (resp *dimensions.CreateOrUpdateTemplateResponse, err error) {
	resp, err = TemplateHandler.HandleCreateTemplate(ctx, req)
	if resp == nil {
		resp = &dimensions.CreateOrUpdateTemplateResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// UpdateTemplate implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateTemplate(ctx context.Context, req *dimensions.CreateOrUpdateTemplateRequest) (resp *dimensions.CreateOrUpdateTemplateResponse, err error) {
	resp, err = TemplateHandler.HandleUpdateTemplate(ctx, req)
	if resp == nil {
		resp = &dimensions.CreateOrUpdateTemplateResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// DeleteTemplate implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DeleteTemplate(ctx context.Context, req *dimensions.DeleteTemplateRequest) (resp *dimensions.DeleteTemplateResponse, err error) {
	resp, err = TemplateHandler.HandleDeleteTemplate(ctx, req)
	if resp == nil {
		resp = &dimensions.DeleteTemplateResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetTemplateList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetTemplateList(ctx context.Context, req *dimensions.GetTemplateListRequest) (resp *dimensions.GetTemplateListResponse, err error) {
	resp, err = TemplateHandler.HandleGetTemplateList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetTemplateListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetTemplateDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetTemplateDetail(ctx context.Context, req *dimensions.GetTemplateDetailRequest) (resp *dimensions.GetTemplateDetailResponse, err error) {
	resp, err = TemplateHandler.HandleGetTemplateDetail(ctx, req)
	if resp == nil {
		resp = &dimensions.GetTemplateDetailResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GenerateDimensionWithNlp implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GenerateDimensionWithNlp(ctx context.Context, req *dimensions.GenerateDimensionWithNlpRequest) (resp *dimensions.GenerateDimensionWithNlpResponse, err error) {
	resp, err = DimensionHandler.GenerateDimensionWithNlp(ctx, req)
	if resp == nil {
		resp = &dimensions.GenerateDimensionWithNlpResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisCoreOverviewDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisCoreOverviewDownload(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetProductAnalysisCoreOverviewDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisMultiDimListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimListDownload(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetProductAnalysisMultiDimListDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisMultiDimProductListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimProductListDownload(ctx context.Context, req *analysis.GetProductAnalysisMultiDimProductListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetProductAnalysisMultiDimProductListDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetReadyTime implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetReadyTime(ctx context.Context, req *dimensions.GetDataReadyTimeRequest) (resp *dimensions.GetDataReadyTimeResponse, err error) {
	resp, err = DimensionHandler.GetReadyTime(ctx, req)
	if resp == nil {
		resp = &dimensions.GetDataReadyTimeResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// AddFeedBack implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) AddFeedBack(ctx context.Context, req *analysis.AddFeedBackRequest) (resp *analysis.AddFeedBackResponse, err error) {
	resp, err = FeedbackHandler.HandleAddFeedBack(ctx, req)
	if resp == nil {
		resp = &analysis.AddFeedBackResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisCoreConclusion implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisCoreConclusion(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreConclusionResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisCoreConclusion(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisCoreConclusionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisMultiDimConclusion implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimConclusion(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisMultiDimConclusionResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisMultiDimConclusion(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisMultiDimConclusionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetDimensionPageEnumList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDimensionPageEnumList(ctx context.Context, req *dimensions.GetDimensionPageEnumListRequest) (resp *dimensions.GetDimensionPageEnumListResponse, err error) {
	resp, err = DimensionHandler.GetDimensionPageEnumList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetDimensionPageEnumListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisCoreTarget implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisCoreTarget(ctx context.Context, req *analysis.GetProductAnalysisCoreTargetRequest) (resp *analysis.GetProductAnalysisCoreTargetResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisCoreTarget(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisCoreTargetResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisMultiDimList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimList(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisMultiDimListResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisMultiDimList(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisMultiDimListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GenreateTemplateCache implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GenreateTemplateCache(ctx context.Context, req *base.EmptyRequest) (resp *base.BaseResponse, err error) {
	// 废弃
	resp, err = TemplateHandler.GenreateTemplateCache(ctx)
	if resp == nil {
		resp = &base.BaseResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// QueryAnalysisPool implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) QueryAnalysisPool(ctx context.Context, req *analysis_pool.QueryAnalysisPoolListReq) (resp *analysis_pool.QueryAnalysisPoolListResp, err error) {
	resp, err = AnalysisPoolHandler.HandleQueryAnalysisPoolList(ctx, req)
	if resp == nil {
		resp = &analysis_pool.QueryAnalysisPoolListResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// CreateAnalysisPool implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateAnalysisPool(ctx context.Context, req *analysis_pool.CreateAnalysisPoolReq) (resp *analysis_pool.CreateAnalysisPoolResp, err error) {
	resp, err = AnalysisPoolHandler.HandleCreateAnalysisPool(ctx, req)
	if resp == nil {
		resp = &analysis_pool.CreateAnalysisPoolResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// UpdateAnalysisPool implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateAnalysisPool(ctx context.Context, req *analysis_pool.UpdateAnalysisPoolReq) (resp *analysis_pool.UpdateAnalysisPoolResp, err error) {
	resp, err = AnalysisPoolHandler.HandleUpdateAnalysisPool(ctx, req)
	if err != nil {
		return nil, err
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// DeleteAnalysisPool implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DeleteAnalysisPool(ctx context.Context, req *analysis_pool.DeleteAnalysisPoolReq) (resp *analysis_pool.DeleteAnalysisPoolResp, err error) {
	resp, err = AnalysisPoolHandler.HandleDeleteAnalysisPool(ctx, req)
	if resp == nil {
		resp = &analysis_pool.DeleteAnalysisPoolResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// QueryAnalysisPoolAlertRuleList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) QueryAnalysisPoolAlertRuleList(ctx context.Context, req *analysis_pool_alert_rule.QueryAnalysisPoolAlertRuleListReq) (resp *analysis_pool_alert_rule.QueryAnalysisPoolAlertRuleListResp, err error) {
	resp, err = AlertHandler.HandleQueryRuleByPool(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.QueryAnalysisPoolAlertRuleListResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// CreateAnalysisPoolAlertRule implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateAnalysisPoolAlertRule(ctx context.Context, req *analysis_pool_alert_rule.CreateAnalysisPoolAlertRuleReq) (resp *analysis_pool_alert_rule.CreateAnalysisPoolAlertRuleResp, err error) {
	logs.CtxInfo(ctx, "CreateAnalysisPoolAlertRule is %v", req)
	resp, err = AlertHandler.HandleAddRule(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.CreateAnalysisPoolAlertRuleResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAnalysisPoolAlertRuleDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAnalysisPoolAlertRuleDetail(ctx context.Context, req *analysis_pool_alert_rule.GetAnalysisPoolAlertRuleDetailReq) (resp *analysis_pool_alert_rule.GetAnalysisPoolAlertRuleDetailResp, err error) {
	resp, err = AlertHandler.HandleGetAlertRuleDetail(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.GetAnalysisPoolAlertRuleDetailResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// LisAnalysisPoolEventType implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) LisAnalysisPoolEventType(ctx context.Context, req *analysis_pool_alert_rule.LisAnalysisPoolEventTypeReq) (resp *analysis_pool_alert_rule.LisAnalysisPoolEventTypeResp, err error) {
	resp, err = AlertHandler.HandleListAlertEventType(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.LisAnalysisPoolEventTypeResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetRulesWitExceptionProdStatusInfos implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetRulesWitExceptionProdStatusInfos(ctx context.Context, req *analysis_pool_alert_rule.GetRulesWitExceptionProdStatusInfosReq) (resp *analysis_pool_alert_rule.GetRulesWitExceptionProdStatusInfosResp, err error) {
	resp, err = AlertHandler.HandleGetRulesWitExceptionProdStatusInfos(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.GetRulesWitExceptionProdStatusInfosResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAnalysisPoolAlertDimensions implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAnalysisPoolAlertDimensions(ctx context.Context, req *analysis_pool_alert_rule.GetAnalysisPoolAlertDimensionsReq) (resp *analysis_pool_alert_rule.GetAnalysisPoolAlertDimensionsResp, err error) {
	resp, err = AlertHandler.HandleGetAlertDimensions(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.GetAnalysisPoolAlertDimensionsResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAnalysisPoolAlertIndicators implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAnalysisPoolAlertIndicators(ctx context.Context, req *analysis_pool_alert_rule.GetAnalysisPoolAlertIndicatorsReq) (resp *analysis_pool_alert_rule.GetAnalysisPoolAlertIndicatorsResp, err error) {
	resp, err = AlertHandler.HandleGetAlertIndicators(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.GetAnalysisPoolAlertIndicatorsResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		logs.CtxError(ctx, "ctx=%v,err=%v", ctx, err)
		return resp, nil
	}
	return resp, nil
}

// GetAnalysisPoolProductList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAnalysisPoolProductList(ctx context.Context, req *analysis_pool_product.GetAnalysisPoolProductListReq) (resp *analysis_pool_product.GetAnalysisPoolProductListResp, err error) {
	resp, err = AnalysisPoolProductHandler.HandleGetAnalysisPoolProductList(ctx, req)
	if resp == nil {
		resp = &analysis_pool_product.GetAnalysisPoolProductListResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// QueryAnalysisPoolProduct implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) QueryAnalysisPoolProduct(ctx context.Context, req *analysis_pool_product.QueryAnalysisPoolProductListReq) (resp *analysis_pool_product.QueryAnalysisPoolProductListResp, err error) {
	resp, err = AnalysisPoolProductHandler.HandleQueryAnalysisPoolProductList(ctx, req)
	if resp == nil {
		resp = &analysis_pool_product.QueryAnalysisPoolProductListResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPoolProductTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPoolProductTrend(ctx context.Context, req *analysis_pool_product.GetPoolProductTrendReq) (resp *analysis_pool_product.GetPoolProductTrendResp, err error) {
	resp, err = AnalysisPoolProductHandler.HandleGetPoolProductTrend(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis_pool_product.GetPoolProductTrendResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetDataAvailableDateRange implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDataAvailableDateRange(ctx context.Context, req *analysis_pool_product.GetDataAvailableDateRangeReq) (resp *analysis_pool_product.GetDataAvailableDateRangeResp, err error) {
	resp, err = AnalysisPoolProductHandler.HandleGetDataAvailableDateRange(ctx, req)
	if resp == nil {
		resp = &analysis_pool_product.GetDataAvailableDateRangeResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// DeleteAlertRule implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DeleteAlertRule(ctx context.Context, req *analysis_pool_alert_rule.DeleteAlertRuleReq) (resp *analysis_pool_alert_rule.DeleteAlertRuleResp, err error) {
	resp, err = AlertHandler.DeleteAlertRule(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.DeleteAlertRuleResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// DownloadAnalysisPoolProduct implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DownloadAnalysisPoolProduct(ctx context.Context, req *analysis_pool_product.DownloadAnalysisPoolProductListReq) (resp *analysis_pool_product.DownloadAnalysisPoolProductListResp, err error) {
	resp, err = AnalysisPoolProductHandler.HandleDownloadAnalysisPoolProductList(ctx, req)
	if resp == nil {
		resp = &analysis_pool_product.DownloadAnalysisPoolProductListResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// OpAnalysisPoolProduct implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) OpAnalysisPoolProduct(ctx context.Context, req *analysis_pool_product.OpAnalysisPoolProductReq) (resp *analysis_pool_product.OpAnalysisPoolProductResp, err error) {
	resp, err = AnalysisPoolProductHandler.HandleOpAnalysisPoolProduct(ctx, req)
	if resp == nil {
		resp = &analysis_pool_product.OpAnalysisPoolProductResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductMultiDim implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductMultiDim(ctx context.Context, req *analysis_pool_product.GetProductMultiDimReq) (resp *analysis_pool_product.GetProductMultiDimResp, err error) {
	resp, err = AnalysisPoolProductHandler.HandleGetProductMultiDim(ctx, req)
	if resp == nil {
		resp = &analysis_pool_product.GetProductMultiDimResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// DownloadProductMultiDim implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DownloadProductMultiDim(ctx context.Context, req *analysis_pool_product.DownloadProductMultiDimReq) (resp *analysis_pool_product.DownloadProductMultiDimResp, err error) {
	resp, err = AnalysisPoolProductHandler.HandleDownloadProductMultiDim(ctx, req)
	if resp == nil {
		resp = &analysis_pool_product.DownloadProductMultiDimResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// UpdateAnalysisPoolAlertRule implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateAnalysisPoolAlertRule(ctx context.Context, req *analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleReq) (resp *analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleResp, err error) {
	resp, err = AlertHandler.HandleUpdateAnalysisPoolAlertRule(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleResp{}
		defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
		resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
		resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}

	return resp, nil
}

// UpdateAnalysisPoolAlertRuleStatus implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateAnalysisPoolAlertRuleStatus(ctx context.Context, req *analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleStatusReq) (resp *analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleStatusResp, err error) {
	// TODO: Your code here...
	resp, err = AlertHandler.HandleUpdateAnalysisPoolAlertRuleStatus(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.UpdateAnalysisPoolAlertRuleStatusResp{}
		defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
		resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
		resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// ConvertToAlertRule implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) ConvertToAlertRule(ctx context.Context, req *analysis_pool_alert_rule.ConvertToAlertRuleReq) (resp *analysis_pool_alert_rule.ConvertToAlertRuleResp, err error) {
	// TODO: Your code here...
	resp, err = AlertHandler.HandleConvertToAlertRule(ctx, req)
	if resp == nil {
		resp = &analysis_pool_alert_rule.ConvertToAlertRuleResp{}
		defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
		resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
		resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}

	return resp, nil
}

// GetActivityReviewResult_ implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetActivityReviewResult_(ctx context.Context, req *activity_review.GetActivityReviewResultRequest) (resp *activity_review.GetActivityReviewResultResponse, err error) {
	resp, err = ActivityReviewHandler.GetActivityReviewResult(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// CreateActivityReview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateActivityReview(ctx context.Context, req *activity_review.CreateActivityReviewRequest) (resp *activity_review.CreateActivityReviewResponse, err error) {
	resp, err = ActivityReviewHandler.CreateActivityReview(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// FreshActivityReview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) FreshActivityReview(ctx context.Context, req *activity_review.FreshActivityReviewProgressRequest) (resp *activity_review.FreshActivityReviewProgressResponse, err error) {
	resp, err = ActivityReviewHandler.FreshActivityReview(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetActivityReviewProductSupplyProgress implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetActivityReviewProductSupplyProgress(ctx context.Context, req *activity_review.GetActivityReviewProductSupplyProgressRequest) (resp *activity_review.GetActivityReviewProductSupplyProgressResponse, err error) {
	resp, err = ActivityReviewHandler.GetActivityReviewProductSupplyResult(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetActivityReviewProductAnalysis implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetActivityReviewProductAnalysis(ctx context.Context, req *activity_review.GetActivityReviewProductAnalysisRequest) (resp *activity_review.GetActivityReviewProductAnalysisResponse, err error) {
	resp, err = ActivityReviewHandler.GetActivityReviewProductAnalysis(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetActivityReviewProductAAAnalysis implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetActivityReviewProductAAAnalysis(ctx context.Context, req *activity_review.GetActivityReviewProductAnalysisRequest) (resp *activity_review.GetActivityReviewProductAAAnalysisResponse, err error) {
	resp, err = ActivityReviewHandler.GetActivityReviewProductAAAnalysis(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetActivityReviewActivityAndNonActivityProductABAnalysis implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetActivityReviewActivityAndNonActivityProductABAnalysis(ctx context.Context, req *activity_review.GetActivityReviewProductAnalysisRequest) (resp *activity_review.GetActivityReviewProductAAAnalysisResponse, err error) {
	resp, err = ActivityReviewHandler.GetActivityReviewActivityAndNonActivityProductABAnalysis(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAACoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAACoreOverview(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAACoreOverview(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAACoreOverviewDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAACoreOverviewDownload(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetPriceAACoreOverviewDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAAFlowStandardCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAAFlowStandardCoreOverview(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAAFlowStandardCoreOverview(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAAMarketCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAAMarketCoreOverview(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAAMarketCoreOverview(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAABizIncomeTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAABizIncomeTrend(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetPriceAABizIncomeTrendResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAABizIncomeTrend(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceAABizIncomeTrendResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAABizIncomeTargetCard implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAABizIncomeTargetCard(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAABizIncomeTargetCard(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAABizIncomeDiffDistributed implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAABizIncomeDiffDistributed(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetPriceAAMultiPieChartResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAABizIncomeDiffDistributed(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceAAMultiPieChartResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAAFlowDiffStandardCard implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAAFlowDiffStandardCard(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAAFlowDiffStandardCard(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAASupplyCntList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAASupplyCntList(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceAASupplyCntListResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAASupplyCntList(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceAASupplyCntListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAASupplyDistributed implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAASupplyDistributed(ctx context.Context, req *analysis.GetPriceAASupplyDistributedRequest) (resp *analysis.GetPriceAASupplyCntListResponse, err error) {
	resp, err = PriceAAHandler.GetPriceAASupplyDistributed(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceAASupplyCntListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAnalysisMultiDimConclusion implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAnalysisMultiDimConclusion(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetProductAnalysisMultiDimConclusionResponse, err error) {
	// TODO: Your code here...
	return
}

// GetPriceAnalysisMultiDimList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAnalysisMultiDimList(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetProductAnalysisMultiDimListResponse, err error) {
	// TODO: Your code here...
	return
}

// GetPriceAnalysisMultiDimListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAnalysisMultiDimListDownload(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	// TODO: Your code here...
	return
}

// GetPriceInsightMeta implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceInsightMeta(ctx context.Context, req *analysis.GetPriceInsightMetaRequest) (resp *analysis.GetPriceInsightMetaResponse, err error) {
	resp, err = PriceAnalysisHandler.GetPriceInsightMeta(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightMetaResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceInsightCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceInsightCoreOverview(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetPriceInsightCoreOverviewResponse, err error) {
	resp, err = PriceAnalysisHandler.GetPriceInsightCoreOverview(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceHybridTagEnumList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceHybridTagEnumList(ctx context.Context, req *dimensions.GetPriceHybridTagEnumListRequest) (resp *dimensions.GetPriceHybridTagEnumListResponse, err error) {
	resp, err = DimensionHandler.GetPriceHybridTagEnumList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetPriceHybridTagEnumListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceInsightHierarchicalTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceInsightHierarchicalTrend(ctx context.Context, req *analysis.GetPriceInsightHierarchicalTrendRequest) (resp *analysis.GetPriceInsightHierarchicalTrendResponse, err error) {
	resp, err = PriceAnalysisHandler.GetPriceInsightHierarchicalTrend(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightHierarchicalTrendResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetMultipleRatioTable implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetMultipleRatioTable(ctx context.Context, req *analysis.GetMultipleRatioTableRequest) (resp *analysis.GetMultipleRatioTableResponse, err error) {
	resp, err = PriceAnalysisHandler.GetMultipleRatioTable(ctx, req)
	if resp == nil {
		resp = &analysis.GetMultipleRatioTableResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetMultipleRatioTableDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetMultipleRatioTableDownload(ctx context.Context, req *analysis.GetMultipleRatioTableRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetMultipleRatioTableDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceInsightBubbleChart implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceInsightBubbleChart(ctx context.Context, req *analysis.GetPriceInsightBubbleChartRequest) (resp *analysis.GetPriceInsightBubbleChartResponse, err error) {
	resp, err = PriceAnalysisHandler.GetPriceInsightBubbleChart(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightBubbleChartResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityDistributed implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityDistributed(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp *analysis.GetOrderResponsibilityDistributedResponse, err error) {
	resp, err = PriceAnalysisHandler.GetOrderResponsibilityDistributed(ctx, req)
	if resp == nil {
		resp = &analysis.GetOrderResponsibilityDistributedResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityCoreOverview(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetOrderResponsibilityCoreOverviewResponse, err error) {
	resp, err = PriceAnalysisHandler.GetOrderResponsibilityCoreOverview(ctx, req)
	if resp == nil {
		resp = &analysis.GetOrderResponsibilityCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityChange implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityChange(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp *analysis.GetOrderResponsibilityChangeResponse, err error) {
	resp, err = PriceAnalysisHandler.GetOrderResponsibilityChange(ctx, req)
	if resp == nil {
		resp = &analysis.GetOrderResponsibilityChangeResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityTargetList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityTargetList(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp *analysis.GetOrderResponsibilityCoreOverviewResponse, err error) {
	resp, err = PriceAnalysisHandler.GetOrderResponsibilityTargetList(ctx, req)
	if resp == nil {
		resp = &analysis.GetOrderResponsibilityCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityIndustryList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityIndustryList(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetOrderResponsibilityIndustryListResponse, err error) {
	resp, err = PriceAnalysisHandler.GetOrderResponsibilityIndustryList(ctx, req)
	if resp == nil {
		resp = &analysis.GetOrderResponsibilityIndustryListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityBubbleChart implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityBubbleChart(ctx context.Context, req *analysis.GetOrderResponsibilityBubbleChartRequest) (resp *analysis.GetPriceInsightBubbleChartResponse, err error) {
	resp, err = PriceAnalysisHandler.GetOrderResponsibilityBubbleChart(ctx, req)
	if resp == nil {
		resp = &analysis.GetPriceInsightBubbleChartResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProdPortrait implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProdPortrait(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp *analysis.GetProdPortraitResponse, err error) {
	resp, err = ProdPortraitHandler.GetProdPortrait(ctx, req)
	if resp == nil {
		resp = &analysis.GetProdPortraitResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPordDetailList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPordDetailList(ctx context.Context, req *analysis.GetPordDetailListRequest) (resp *analysis.GetProductAnalysisMultiDimProductListResponse, err error) {
	resp, err = ProdPortraitHandler.GetPordDetailList(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisMultiDimProductListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPordDetailListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPordDetailListDownload(ctx context.Context, req *analysis.GetPordDetailListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetPordDetailListDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAABizIncomeTargetCardDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAABizIncomeTargetCardDownload(ctx context.Context, req *analysis.GetPriceAABaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetPriceAABizIncomeTargetCardDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityIndustryListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityIndustryListDownload(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetOrderResponsibilityIndustryListDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityCoreOverviewDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityCoreOverviewDownload(ctx context.Context, req *analysis.GetPriceInsightCoreOverviewRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetOrderResponsibilityCoreOverviewDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOrderResponsibilityTargetListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOrderResponsibilityTargetListDownload(ctx context.Context, req *analysis.GetOrderResponsibilityDistributedRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = ExportHandler.HandleGetOrderResponsibilityTargetListDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetPriceAACoreConclusion implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetPriceAACoreConclusion(ctx context.Context, req *analysis.GetPriceAnalysisBaseRequest) (resp *analysis.GetPriceAACoreConclusionResponse, err error) {
	// TODO: Your code here...
	return
}

// GetProductAnalysisMultiDimFullList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimFullList(ctx context.Context, req *analysis.GetProductAnalysisMultiDimFullListRequest) (resp *analysis.GetProductAnalysisMultiDimFullListResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisMultiDimFullList(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisMultiDimFullListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisBizList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp, err = DimensionHandler.GetProductAnalysisBizList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetProductAnalysisBizListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisMultiDimTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimTrend(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisMultiDimTrendResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisMultiDimTrend(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisMultiDimTrendResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisMultiDimProdCostData implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimProdCostData(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetMultiDimExtraTargetListResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisMultiDimProdCostData(ctx, req)
	if resp == nil {
		resp = &analysis.GetMultiDimExtraTargetListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisTargetMetaList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisTargetMetaList(ctx context.Context, req *dimensions.GetProductAnalysisTargetMetaListRequest) (resp *dimensions.GetProductAnalysisTargetMetaListResponse, err error) {
	// TODO: Your code here...
	resp, err = DimensionHandler.GetProductAnalysisTargetMetaList(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &dimensions.GetProductAnalysisTargetMetaListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetEchoDisplayDims implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetEchoDisplayDims(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp *analysis.GetEchoDisplayDimsResponse, err error) {
	resp, err = ProdPortraitHandler.GetEchoDisplayDims(ctx, req)
	if err != nil {
		return nil, err
	}
	if resp == nil {
		resp = &analysis.GetEchoDisplayDimsResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetDiagnoseJudgeConditionList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDiagnosisJudgeConditionList(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisJudgeConditionListReq) (resp *analysis_pool_diagnosis.GetDiagnosisJudgeConditionListResp, err error) {
	resp, err = AnalysisPoolDiagnosisHandler.HandleGetDiagnosisJudgeConditionList(ctx, req)

	if err != nil {
		return nil, err
	}
	if resp == nil {
		resp = &analysis_pool_diagnosis.GetDiagnosisJudgeConditionListResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetDiagnoseFactorList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDiagnosisFactorList(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisFactorListReq) (resp *analysis_pool_diagnosis.GetDiagnosisFactorListResp, err error) {
	resp, err = AnalysisPoolDiagnosisHandler.HandleGetDiagnosisFactorList(ctx, req)
	if err != nil {
		return nil, err
	}
	if resp == nil {
		resp = &analysis_pool_diagnosis.GetDiagnosisFactorListResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetDiagnoseIndicatorCategoryJudge implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDiagnosisIndicatorCategoryJudge(ctx context.Context, req *analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeReq) (resp *analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeResp, err error) {
	resp, err = AnalysisPoolDiagnosisHandler.HandleGetDiagnosisIndicatorCategoryJudge(ctx, req)
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis_pool_diagnosis.GetDiagnosisIndicatorCategoryJudgeResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// QueryDiagnoseProductList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) QueryDiagnosisProductList(ctx context.Context, req *analysis_pool_diagnosis.QueryDiagnosisProductListReq) (resp *analysis_pool_diagnosis.QueryDiagnosisProductListResp, err error) {
	resp, err = AnalysisPoolDiagnosisHandler.HandleQueryDiagnosisProductList(ctx, req)
	if err != nil {
		return nil, err
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// QueryDiagnosisFlowSpaceProductList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) QueryDiagnosisFlowSpaceProductList(ctx context.Context, req *analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListReq) (resp *analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListResp, err error) {
	resp, err = AnalysisPoolDiagnosisHandler.HandleQueryDiagnosisFlowSpaceProductList(ctx, req)
	if err != nil {
		return nil, err
	}
	if resp == nil {
		resp = &analysis_pool_diagnosis.QueryDiagnosisFlowSpaceProductListResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAttributionTreeMetaList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionTreeMetaList(ctx context.Context, req *analysis.GetAttributionTreeMetaListRequest) (resp *analysis.GetAttributionTreeMetaListResponse, err error) {
	resp, err = AttributionHandler.GetAttributionTreeMetaList(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionTreeMetaListResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionTreeMetaListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionCoreTree implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionCoreTree(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionCoreTreeResponse, err error) {
	resp, err = AttributionHandler.GetAttributionCoreTree(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionCoreTreeResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionCoreTreeResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionABtestList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionABtestList(ctx context.Context, req *analysis.GetAttributionABtestListRequest) (resp *analysis.GetAttributionABtestListResponse, err error) {
	resp, err = AttributionHandler.GetAttributionABtestList(ctx, req)
	if err != nil {
		return nil, err
	}
	if resp == nil {
		resp = &analysis.GetAttributionABtestListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAttributionABtestListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionABtestListDownload(ctx context.Context, req *analysis.GetAttributionABtestListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = AttributionHandler.GetAttributionABtestListDownload(ctx, req)
	if err != nil {
		return nil, err
	}
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAttributionABtestProdList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionABtestProdList(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) (resp *analysis.GetAttributionABtestListResponse, err error) {
	resp, err = AttributionHandler.GetAttributionABtestProdList(ctx, req)
	if err != nil {
		return nil, err
	}
	if resp == nil {
		resp = &analysis.GetAttributionABtestListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAttributionABtestProdListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionABtestProdListDownload(ctx context.Context, req *analysis.GetAttributionABtestProdListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = AttributionHandler.GetAttributionABtestProdListDownload(ctx, req)
	if err != nil {
		return nil, err
	}
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAttributionProdPriceDistribution implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionProdPriceDistribution(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionProdPriceDistributionResponse, err error) {
	resp, err = AttributionHandler.GetAttributionProdPriceDistribution(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionProdPriceDistributionResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionProdPriceDistributionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionCommonCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionCommonCoreOverview(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionCommonCoreOverviewResponse, err error) {
	resp, err = AttributionHandler.GetAttributionCommonCoreOverview(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionCommonCoreOverviewResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionCommonCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionCommonCoreOverviewDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionCommonCoreOverviewDownload(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = AttributionHandler.GetAttributionCommonCoreOverviewDownload(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetProductAnalysisDownloadResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionCommonProdList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionCommonProdList(ctx context.Context, req *analysis.GetAttributionCommonPageRequest) (resp *analysis.GetAttributionCommonProdListResponse, err error) {
	resp, err = AttributionHandler.GetAttributionCommonProdList(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionCommonProdListResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionCommonProdListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionCommonProdListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionCommonProdListDownload(ctx context.Context, req *analysis.GetAttributionCommonPageRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = AttributionHandler.GetAttributionCommonProdListDownload(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetProductAnalysisDownloadResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionFlowChange implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionFlowChange(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionFlowChangeResponse, err error) {
	resp, err = AttributionHandler.GetAttributionFlowChange(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionFlowChangeResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionFlowChangeResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionMetaInfo implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionMetaInfo(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionMetaInfoResponse, err error) {
	resp, err = AttributionHandler.GetAttributionMetaInfo(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionMetaInfoResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionMetaInfoResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// QueryAnalysisPoolDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) QueryAnalysisPoolDetail(ctx context.Context, req *analysis_pool.QueryAnalysisPoolDetailReq) (resp *analysis_pool.QueryAnalysisPoolDetailResp, err error) {
	resp, err = AnalysisPoolHandler.HandleQueryAnalysisPoolDetail(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis_pool.QueryAnalysisPoolDetailResp{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis_pool.QueryAnalysisPoolDetailResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetProductDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductDetail(ctx context.Context, req *analysis.GetProductDetailRequest) (resp *analysis.GetProductDetailResponse, err error) {
	resp, err = AttributionHandler.GetProductDetail(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetProductDetailResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetProductDetailResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetProductDetailBy360 implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductDetailBy360(ctx context.Context, req *analysis.GetProductDetailRequest) (resp *analysis.GetProductDetailBy360Response, err error) {
	resp, err = AttributionHandler.GetProductDetailBy360(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetProductDetailBy360Response{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetProductDetailBy360Response{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetProductReportTable implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductReportTable(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *analysis.GetProductReportTableResponse, err error) {
	resp, err = AnalysisHandler.GetProductReportTable(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductReportTableResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisDefaultFunnelMate implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisDefaultFunnelMate(ctx context.Context, req *analysis.GetProductAnalysisDefaultFunnelMateRequest) (resp *analysis.GetProductAnalysisDefaultFunnelMateResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisDefaultFunnelMate(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDefaultFunnelMateResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductReportTableDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductReportTableDownload(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = AnalysisHandler.GetProductReportTableDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisProdCnt implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisProdCnt(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisProdCntResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisProdCnt(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisProdCntResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// UpdatePoolStatus implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdatePoolStatus(ctx context.Context, req *dimensions.UpdatePoolStatusRequest) (resp *dimensions.UpdatePoolStatusResponse, err error) {
	resp, err = DimensionHandler.UpdatePoolStatus(ctx, req)
	if resp == nil {
		resp = &dimensions.UpdatePoolStatusResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAlertProdStatusRuleIndicator implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAlertProdStatusRuleIndicator(ctx context.Context, req *analysis_pool_alert_rule.GetAlertProdStatusRuleIndicatorReq) (resp *analysis_pool_alert_rule.GetAlertProdStatusRuleIndicatorResp, err error) {
	resp, err = AlertHandler.HandleGetAlertProdStatusRuleIndicator(ctx, req)
	if err != nil {
		return nil, err
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetDoradoDumpLoadHiveTaskRunningCallBack implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDoradoDumpLoadHiveTaskRunningCallBack(ctx context.Context, req *dorado_task.GetDoradoTaskRunningCallBackRequest) (resp *dorado_task.GetDoradoTaskRunningCallBackResponse, err error) {
	resp, err = DoradoTaskHandler.HandlerGetDoradoDumpLoadHiveTaskRunningCallBack(ctx, req)
	if resp == nil {
		resp = &dorado_task.GetDoradoTaskRunningCallBackResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProdDetailDimensions implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProdDetailDimensions(ctx context.Context, req *analysis.GetProdPortraitRequest) (resp *dimensions.GetDimensionListResponse, err error) {
	resp, err = ProdPortraitHandler.GetProdDetailDimensions(ctx, req)
	if resp == nil {
		resp = &dimensions.GetDimensionListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetSubscriptionConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSubscriptionConfig(ctx context.Context, req *subscription.GetSubscriptionConfigRequest) (resp *subscription.GetSubscriptionConfigResponse, err error) {
	resp, err = SubscriptionHandler.GetSubscriptionConfig(ctx, req)
	if resp == nil {
		resp = &subscription.GetSubscriptionConfigResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "GetSubscriptionConfig: ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetUserSubscriptionList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetUserSubscriptionList(ctx context.Context, req *subscription.GetUserSubscriptionListRequest) (resp *subscription.GetUserSubscriptionListResponse, err error) {
	resp, err = SubscriptionHandler.GetUserSubscriptionList(ctx, req)
	if resp == nil {
		resp = &subscription.GetUserSubscriptionListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "GetUserSubscriptionList: ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// PreviewUserSubscription implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) PreviewUserSubscription(ctx context.Context, req *subscription.PreviewUserSubscriptionRequest) (resp *subscription.PreviewUserSubscriptionResponse, err error) {
	resp = &subscription.PreviewUserSubscriptionResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if err = SubscriptionHandler.PreviewUserSubscription(ctx, req); err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "PreviewUserSubscription: ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// SaveUserSubscription implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) SaveUserSubscription(ctx context.Context, req *subscription.SaveUserSubscriptionRequest) (resp *subscription.SaveUserSubscriptionResponse, err error) {
	resp, err = SubscriptionHandler.SaveUserSubscription(ctx, req)
	if resp == nil {
		resp = &subscription.SaveUserSubscriptionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "SaveUserSubscription: ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// DeleteUserSubscription implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DeleteUserSubscription(ctx context.Context, req *subscription.DeleteUserSubscriptionRequest) (resp *subscription.DeleteUserSubscriptionResponse, err error) {
	resp = &subscription.DeleteUserSubscriptionResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if err = SubscriptionHandler.DeleteUserSubscription(ctx, req); err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "DeleteUserSubscription: ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceLibraList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceLibraList(ctx context.Context, req *volume_price.GetVolumePriceLibraListRequest) (resp *volume_price.GetVolumePriceLibraListResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceLibraList(ctx, req)
	if resp == nil {
		resp = &volume_price.GetVolumePriceLibraListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceMarketFunnelTarget implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceMarketFunnelTarget(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *volume_price.GetVolumePriceMarketFunnelTargetResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceMarketFunnelTarget(ctx, req)
	if resp == nil {
		resp = &volume_price.GetVolumePriceMarketFunnelTargetResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceLibraVersionList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceLibraVersionList(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *volume_price.GetVolumePriceLibraVersionListResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceLibraVersionList(ctx, req)
	if resp == nil {
		resp = &volume_price.GetVolumePriceLibraVersionListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.If(len(err.Error()) > 100, defaultStCode.String(), err.Error()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceMultiDimFullList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceMultiDimFullList(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisMultiDimFullListResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceMultiDimFullList(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisMultiDimFullListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceMarketFunnelTargetDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceMarketFunnelTargetDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceMarketFunnelTargetDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceLibraVersionListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceLibraVersionListDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceLibraVersionListDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceMultiDimFullListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceMultiDimFullListDownload(ctx context.Context, req *volume_price.VolumePriceCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceMultiDimFullListDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceVersionHierarchicalList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceVersionHierarchicalList(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalListRequest) (resp *volume_price.GetVolumePriceLibraVersionListResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceVersionHierarchicalList(ctx, req)
	if resp == nil {
		resp = &volume_price.GetVolumePriceLibraVersionListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceVersionHierarchicalListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceVersionHierarchicalListDownload(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalListRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceVersionHierarchicalListDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceVersionHierarchicalConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceVersionHierarchicalConfig(ctx context.Context, req *volume_price.GetVolumePriceVersionHierarchicalConfigRequest) (resp *volume_price.GetVolumePriceVersionHierarchicalConfigResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceVersionHierarchicalConfig(ctx, req)
	if resp == nil {
		resp = &volume_price.GetVolumePriceVersionHierarchicalConfigResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAttributionAnalysisBizList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionAnalysisBizList(ctx context.Context, req *analysis.GetAttributionAnalysisBizListRequest) (resp *analysis.GetAttributionAnalysisBizListResponse, err error) {
	resp, err = AttributionHandler.GetAttributionAnalysisBizList(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionAnalysisBizListResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionAnalysisBizListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetAttributionMultiDimAnalysis implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionMultiDimAnalysis(ctx context.Context, req *analysis.GetAttributionMultiDimAnalysisRequest) (resp *analysis.GetAttributionMultiDimAnalysisResponse, err error) {
	resp, err = AttributionHandler.GetAttributionMultiDimAnalysis(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionMultiDimAnalysisResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionMultiDimAnalysisResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetProductAnalysisMultiDimUvTargets implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisMultiDimUvTargets(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetMultiDimExtraTargetListResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisMultiDimUvTargets(ctx, req)
	if resp == nil {
		resp = &analysis.GetMultiDimExtraTargetListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductAnalysisUVCore implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductAnalysisUVCore(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreOverviewResponse, err error) {
	resp, err = AnalysisHandler.GetProductAnalysisUVCore(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetAttributionTreeBizList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAttributionTreeBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp, err = DimensionHandler.GetAttributionTreeBizList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetProductAnalysisBizListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGuessDressBizList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGuessDressBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp, err = DimensionHandler.GetGuessDressBizList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetProductAnalysisBizListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetExperimentCombination implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetExperimentCombination(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.GetExperimentCombinationResponse, err error) {
	resp, err = VolumePriceHandler.GetExperimentCombination(ctx, req)
	if resp == nil {
		resp = &volume_price.GetExperimentCombinationResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetReversalExperimentCoreData implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetReversalExperimentCoreData(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.GetReversalExperimentCoreDataResponse, err error) {
	resp, err = VolumePriceHandler.GetReversalExperimentCoreData(ctx, req)
	if resp == nil {
		resp = &volume_price.GetReversalExperimentCoreDataResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetReversalExperimentCoreDataDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetReversalExperimentCoreDataDownload(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = VolumePriceHandler.GetReversalExperimentCoreDataDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetReversalExperimentDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetReversalExperimentDetail(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *volume_price.GetReversalExperimentDetailResponse, err error) {
	resp, err = VolumePriceHandler.GetReversalExperimentDetail(ctx, req)
	if resp == nil {
		resp = &volume_price.GetReversalExperimentDetailResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetReversalExperimentDetailDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetReversalExperimentDetailDownload(ctx context.Context, req *volume_price.GetReversalExperimentRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = VolumePriceHandler.GetReversalExperimentDetailDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetVolumePriceBilateralLibra implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetVolumePriceBilateralLibra(ctx context.Context, req *volume_price.GetVolumePriceBilateralLibraRequest) (resp *volume_price.GetVolumePriceBilateralLibraResponse, err error) {
	resp, err = VolumePriceHandler.GetVolumePriceBilateralLibra(ctx, req)
	if resp == nil {
		resp = &volume_price.GetVolumePriceBilateralLibraResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// SaveVolumePriceBilateralLibra implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) SaveVolumePriceBilateralLibra(ctx context.Context, req *volume_price.SaveVolumePriceBilateralLibraRequest) (resp *volume_price.SaveVolumePriceBilateralLibraResponse, err error) {
	resp, err = VolumePriceHandler.SaveVolumePriceBilateralLibra(ctx, req)
	if resp == nil {
		resp = &volume_price.SaveVolumePriceBilateralLibraResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// SaveExprObject implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) SaveExprObject(ctx context.Context, req *volume_price.SaveExprObjectRequest) (resp *volume_price.SaveExprObjectResponse, err error) {
	resp, err = VolumePriceHandler.SaveExprObject(ctx, req)
	if resp == nil {
		resp = &volume_price.SaveExprObjectResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetProductReportTableSubscribe implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductReportTableSubscribe(ctx context.Context, req *analysis.GetProductReportTableRequest) (resp *analysis.GetProductAnalysisSubscribeResponse, err error) {
	resp, err = AnalysisHandler.GetProductReportTableSubscribe(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisSubscribeResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// SaveSubscriptionFilterConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) SaveSubscriptionFilterConfig(ctx context.Context, req *subscription.SaveSubscriptionFilterConfigRequest) (resp *subscription.SaveSubscriptionFilterConfigResponse, err error) {
	resp, err = SubscriptionHandler.SaveSubscriptionFilterConfig(ctx, req)
	if resp == nil {
		resp = &subscription.SaveSubscriptionFilterConfigResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
	}
	return
}

// GetSubscriptionFilterConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSubscriptionFilterConfig(ctx context.Context, req *subscription.GetSubscriptionFilterConfigRequest) (resp *subscription.GetSubscriptionFilterConfigResponse, err error) {
	resp, err = SubscriptionHandler.GetSubscriptionFilterConfig(ctx, req)
	if resp == nil {
		resp = &subscription.GetSubscriptionFilterConfigResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
	}
	return
}

// GetSkuClusterCommonMultiDimFullList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSkuClusterCommonMultiDimFullList(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterCommonMultiDimFullListResponse, err error) {
	resp, err = SkuClusterHandler.GetSkuClusterCommonMultiDimFullList(ctx, req)
	if resp == nil {
		resp = &sku_cluster.GetSkuClusterCommonMultiDimFullListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetSkuClusterCommonMultiDimFullListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSkuClusterCommonMultiDimFullListDownload(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterCommonMultiDimFullListDownloadResponse, err error) {
	resp, err = SkuClusterHandler.GetSkuClusterCommonMultiDimFullListDownload(ctx, req)
	if resp == nil {
		resp = &sku_cluster.GetSkuClusterCommonMultiDimFullListDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetSkuClusterCommonCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSkuClusterCommonCoreOverview(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterCommonCoreOverviewResponse, err error) {
	resp, err = SkuClusterHandler.GetSkuClusterCommonCoreOverview(ctx, req)
	if resp == nil {
		resp = &sku_cluster.GetSkuClusterCommonCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetSkuClusterFlowTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSkuClusterFlowTrend(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterFlowTrendResponse, err error) {
	resp, err = SkuClusterHandler.GetSkuClusterFlowTrend(ctx, req)
	if resp == nil {
		resp = &sku_cluster.GetSkuClusterFlowTrendResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetSkuClusterCommonMultiDimTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSkuClusterCommonMultiDimTrend(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *analysis.GetProductAnalysisMultiDimTrendResponse, err error) {
	resp, err = SkuClusterHandler.GetSkuClusterCommonMultiDimTrend(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisMultiDimTrendResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetSkuClusterStabilityMultiDimFullList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSkuClusterStabilityMultiDimFullList(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterStabilityResponse, err error) {
	resp, err = SkuClusterHandler.GetSkuClusterStabilityMultiDimFullList(ctx, req)
	if resp == nil {
		resp = &sku_cluster.GetSkuClusterStabilityResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetSkuClusterStabilityMultiDimFullListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSkuClusterStabilityMultiDimFullListDownload(ctx context.Context, req *sku_cluster.SkuClusterCommonRequest) (resp *sku_cluster.GetSkuClusterCommonMultiDimFullListDownloadResponse, err error) {
	resp, err = SkuClusterHandler.GetSkuClusterStabilityMultiDimFullListDownload(ctx, req)
	if resp == nil {
		resp = &sku_cluster.GetSkuClusterCommonMultiDimFullListDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// InflectionPointInsight implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) InflectionPointInsight(ctx context.Context, req *analysis.InflectionPointInsightRequest) (resp *analysis.InflectionPointInsightResponse, err error) {
	resp, err = AnalysisHandler.InflectionPointInsight(ctx, req)
	if resp == nil {
		resp = &analysis.InflectionPointInsightResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return
}

// InflectionPointInsightDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) InflectionPointInsightDownload(ctx context.Context, req *analysis.InflectionPointInsightDownloadRequest) (resp *analysis.InflectionPointInsightDownloadResponse, err error) {
	resp, err = AnalysisHandler.InflectionPointInsightDownload(ctx, req)
	if resp == nil {
		resp = &analysis.InflectionPointInsightDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
	}
	return
}

// GetSimilarProduct implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSimilarProduct(ctx context.Context, req *analysis.GetSimilarProductRequest) (resp *analysis.GetSimilarProductResponse, err error) {
	resp, err = AnalysisHandler.GetSimilarProduct(ctx, req)
	if resp == nil {
		resp = &analysis.GetSimilarProductResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return
}

// GetSimilarProductDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSimilarProductDownload(ctx context.Context, req *analysis.GetSimilarProductDownloadRequest) (resp *analysis.GetSimilarProductDownloadResponse, err error) {
	resp, err = AnalysisHandler.GetSimilarProductDownload(ctx, req)
	if resp == nil {
		resp = &analysis.GetSimilarProductDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return
}

// CreateGetSimilarProductPool implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateGetSimilarProductPool(ctx context.Context, req *analysis.CreateGetSimilarProductPoolRequest) (resp *analysis.CreateGetSimilarProductPoolResponse, err error) {
	resp, err = AnalysisHandler.CreateGetSimilarProductPool(ctx, req)
	if resp == nil {
		resp = &analysis.CreateGetSimilarProductPoolResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
	}
	return
}

// GetBoostPlanCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetBoostPlanCoreOverview(ctx context.Context, req *analysis.GetProductAnalysisBaseRequest) (resp *analysis.GetProductAnalysisCoreOverviewResponse, err error) {
	resp, err = BoostAnalysisHandler.GetBoostPlanCoreOverview(ctx, req)
	if resp == nil {
		resp = &analysis.GetProductAnalysisCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "GetPlanAACoreOverview|ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisConfig(ctx context.Context, req *great_value_buy.GetGreatValueBuyDiagnosisConfigDataRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisConfigResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisConfig(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetGreatValueBuyDiagnosisConfigResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &great_value_buy.GetGreatValueBuyDiagnosisConfigResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetGreatValueBuySupplyAnalysis implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuySupplyAnalysis(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuySupplyAnalysisResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuySupplyAnalysis(ctx, req)
	if resp == nil {
		resp = great_value_buy.NewGetGreatValueBuySupplyAnalysisResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyAttributionCoreTree implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyAttributionCoreTree(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyAttributionCoreTreeResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyAttributionCoreTree(ctx, req)
	if resp == nil {
		resp = great_value_buy.NewGetGreatValueBuyAttributionCoreTreeResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisMultiDimension implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisMultiDimension(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisMultiDimensionResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisMultiDimension(ctx, req)
	if resp == nil {
		resp = great_value_buy.NewGetGreatValueBuyDiagnosisMultiDimensionResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisCommonCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisCommonCoreOverview(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisCommonCoreOverviewResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisCommonCoreOverview(ctx, req)
	if resp == nil {
		resp = great_value_buy.NewGetGreatValueBuyDiagnosisCommonCoreOverviewResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyMultiDimensionTable implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyMultiDimensionTable(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyMultiDimensionResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyMultiDimensionTable(ctx, req)
	if resp == nil {
		resp = great_value_buy.NewGetGreatValueBuyMultiDimensionResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyMultiDimensionTableDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyMultiDimensionTableDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyMultiDimensionTableDownload(ctx, req)
	if resp == nil {
		resp = analysis.NewGetProductAnalysisDownloadResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisProductList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisProductList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductListResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisProductList(ctx, req)
	if resp == nil {
		resp = great_value_buy.NewGetGreatValueBuyDiagnosisProductListResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisProductListTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisProductListTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisProductListTrendResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisProductListTrend(ctx, req)
	if resp == nil {
		resp = great_value_buy.NewGetGreatValueBuyDiagnosisProductListTrendResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisProductListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisProductListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisProductListDownload(ctx, req)
	if resp == nil {
		resp = analysis.NewGetProductAnalysisDownloadResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyBizList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp, err = DimensionHandler.GetGreatValueBuyBizList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetProductAnalysisBizListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyMultiDimTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyMultiDimTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyMultiDimTrendResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyMultiDimTrend(ctx, req)
	if resp == nil {
		resp = &great_value_buy.GetGreatValueBuyMultiDimTrendResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGuessAttributionBizList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGuessAttributionBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp, err = DimensionHandler.GetGuessAttributionBizList(ctx, req)
	if resp == nil {
		resp = &dimensions.GetProductAnalysisBizListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyProdSQL implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyProdSQL(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyProdSQLResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyProdSQL(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetGreatValueBuyProdSQLResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &great_value_buy.GetGreatValueBuyProdSQLResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisQueryList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisQueryList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQueryAnalysisResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisQueryList(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetGreatValueBuyQueryAnalysisResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &great_value_buy.GetGreatValueBuyQueryAnalysisResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil

}

// GetGreatValueBuyDiagnosisQuerySearchWords implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisQuerySearchWords(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQuerySearchWordsResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisQuerySearchWords(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetGreatValueBuyQuerySearchWordsResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &great_value_buy.GetGreatValueBuyQuerySearchWordsResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisQueryListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisQueryListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisQueryListDownload(ctx, req)
	if resp == nil {
		resp = analysis.NewGetProductAnalysisDownloadResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisQueryProdList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisQueryProdList(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyQueryProdAnalysisResponse, err error) {
	// TODO: Your code here...
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisQueryProdList(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetGreatValueBuyQueryProdAnalysisResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &great_value_buy.GetGreatValueBuyQueryProdAnalysisResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisQueryProdListDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisQueryProdListDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisQueryProdListDownload(ctx, req)
	if resp == nil {
		resp = analysis.NewGetProductAnalysisDownloadResponse()
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyDiagnosisQuerySearchCntTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyDiagnosisQuerySearchCntTrend(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyDiagnosisQuerySearchCntTrendResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyDiagnosisQuerySearchCntTrend(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetGreatValueBuyDiagnosisQuerySearchCntTrendResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetGreatValueBuyCommonDiagnosisConclusion implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGreatValueBuyCommonDiagnosisConclusion(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetGreatValueBuyCommonConclusionResponse, err error) {
	resp, err = GreatValueBuyHandler.GetGreatValueBuyCommonDiagnosisConclusion(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetGreatValueBuyCommonConclusionResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return
}

// CreateSession implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateSession(ctx context.Context, req *ai_analysis.CreateSessionRequest) (resp *ai_analysis.CreateSessionResponse, err error) {
	resp, err = AIAnalysisHandler.CreateSession(ctx, req)
	if resp == nil {
		resp = &ai_analysis.CreateSessionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// GetSessionInfo implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSessionInfo(ctx context.Context, req *ai_analysis.GetSessionInfoRequest) (resp *ai_analysis.GetSessionInfoResponse, err error) {
	resp, err = AIAnalysisHandler.GetSessionInfo(ctx, req)
	if resp == nil {
		resp = &ai_analysis.GetSessionInfoResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// GetSessionMessages implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSessionMessages(ctx context.Context, req *ai_analysis.GetSessionMessagesRequest) (resp *ai_analysis.GetSessionMessagesResponse, err error) {
	resp, err = AIAnalysisHandler.GetSessionMessages(ctx, req)
	if resp == nil {
		resp = &ai_analysis.GetSessionMessagesResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// Feedback implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) Feedback(ctx context.Context, req *ai_analysis.FeedbackRequest) (resp *ai_analysis.FeedbackResponse, err error) {
	resp, err = AIAnalysisHandler.Feedback(ctx, req)
	if resp == nil {
		resp = &ai_analysis.FeedbackResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// InitPlanAnalysisPool implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) InitPlanAnalysisPool(ctx context.Context, req *analysis.InitPlanAnalysisPoolRequest) (resp *analysis.InitPlanAnalysisPoolResponse, err error) {
	resp = BoostAnalysisHandler.InitPlanAnalysisPool(ctx, req)
	if resp == nil {
		resp = &analysis.InitPlanAnalysisPoolResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "InitPlanAnalysisPool|ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// RegisterNeedDumpDimension implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) RegisterNeedDumpDimension(ctx context.Context, req *dimensions.RegisterNeedDumpDimensionRequest) (resp *dimensions.RegisterNeedDumpDimensionResponse, err error) {
	resp, err = DimensionHandler.RegisterNeedDumpDimension(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &dimensions.RegisterNeedDumpDimensionResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetRegisterNeedDumpDimensionStatus implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetRegisterNeedDumpDimensionStatus(ctx context.Context, req *dimensions.GetDumpDimensionStatusRequest) (resp *dimensions.DumpDimensionStatusResponse, err error) {
	resp, err = DimensionHandler.GetRegisterNeedDumpDimensionStatus(ctx, req)
	if resp == nil {
		resp = &dimensions.DumpDimensionStatusResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetDiagnosisBizList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDiagnosisBizList(ctx context.Context, req *dimensions.GetProductAnalysisBizListRequest) (resp *dimensions.GetProductAnalysisBizListResponse, err error) {
	resp, err = DimensionHandler.GetDiagnosisBizList(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &dimensions.GetProductAnalysisBizListResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOptimizeItemDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOptimizeItemDetail(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetOptimizeItemDetailResponse, err error) {
	resp, err = BigActivityOptimize.GetOptimizeItemDetail(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetOptimizeItemDetailResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOptimizeProductDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOptimizeProductDetail(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetOptimizeProductDetailResponse, err error) {
	resp, err = BigActivityOptimize.GetOptimizeProductDetail(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetOptimizeProductDetailResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOptimizeProductDetailDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOptimizeProductDetailDownload(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetOptimizeProductDetailDownloadResponse, err error) {
	resp, err = BigActivityOptimize.GetOptimizeProductDetailDownload(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetOptimizeProductDetailDownloadResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetOptimizeActionInfo implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetOptimizeActionInfo(ctx context.Context, req *great_value_buy.GetGreatValueBuyCommonRequest) (resp *great_value_buy.GetOptimizeActionInfoResponse, err error) {
	resp, err = GreatValueBuyHandler.GetOptimizeActionInfo(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.GetOptimizeActionInfoResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

func (s *SmartopProductAnalysisServiceImpl) AnalysisStream(req *ai_analysis.AIAnalysisRequest, stream product_analysis.SmartopProductAnalysisService_AnalysisStreamServer) (err error) {
	return AIAnalysisHandler.AnalysisStream(req, stream)
}

// Analysis implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) Analysis(ctx context.Context, req *ai_analysis.AIAnalysisRequest) (resp *ai_analysis.AIResponse, err error) {
	resp, err = AIAnalysisHandler.Analysis(ctx, req)
	if resp == nil {
		resp = &ai_analysis.AIResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// SendAttributionReport implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) SendAttributionReport(ctx context.Context, req *great_value_buy.SendAttributionReportRequest) (resp *great_value_buy.SendAttributionReportResponse, err error) {
	resp, err = GreatValueBuyHandler.SendAttributionReport(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &great_value_buy.SendAttributionReportResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CreateActivity implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateActivity(ctx context.Context, req *activity.CreateActivityRequest) (resp *activity.CreateActivityResponse, err error) {
	resp, err = ActivityHandler.CreateActivity(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &activity.CreateActivityResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.SetCode(defaultStCode.Int())
			resp.SetMsg(defaultStCode.String())
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	} else {
		resp.SetCode(stcodes.StatusCodeSuccess.Int())
		resp.SetMsg(stcodes.StCodeMsgMap[stcodes.StatusCodeSuccess])
	}
	return resp, nil
}

// UpdateActivity implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateActivity(ctx context.Context, req *activity.UpdateActivityRequest) (resp *activity.UpdateActivityResponse, err error) {
	resp, err = ActivityHandler.UpdateActivity(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &activity.UpdateActivityResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.SetCode(defaultStCode.Int())
			resp.SetMsg(defaultStCode.String())
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	} else {
		resp.SetCode(stcodes.StatusCodeSuccess.Int())
		resp.SetMsg(stcodes.StCodeMsgMap[stcodes.StatusCodeSuccess])
	}
	return resp, nil
}

// GetActivityList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetActivityList(ctx context.Context, req *activity.GetActivityListRequest) (resp *activity.GetActivityListResponse, err error) {
	resp, err = ActivityHandler.GetActivityList(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &activity.GetActivityListResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.SetCode(defaultStCode.Int())
			resp.SetMsg(defaultStCode.String())
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	} else {
		resp.SetCode(stcodes.StatusCodeSuccess.Int())
		resp.SetMsg(stcodes.StCodeMsgMap[stcodes.StatusCodeSuccess])
	}

	logs.CtxInfo(ctx, "resp=%s", jsonx.ToString(resp))
	return resp, nil
}

// TakeOfflineActivity implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) TakeOfflineActivity(ctx context.Context, req *activity.TakeOfflineActivityRequest) (resp *activity.TakeOfflineActivityResponse, err error) {
	resp, err = ActivityHandler.TakeOfflineActivity(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &activity.TakeOfflineActivityResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.SetCode(defaultStCode.Int())
			resp.SetMsg(defaultStCode.String())
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	} else {
		resp.SetCode(stcodes.StatusCodeSuccess.Int())
		resp.SetMsg(stcodes.StCodeMsgMap[stcodes.StatusCodeSuccess])
	}
	return resp, nil
}

// CreateAndUpdateProdReviewStrategy implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateAndUpdateProdReviewStrategy(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewStrategyRequest) (resp *prod_review.CreateAndUpdateProdReviewStrategyResponse, err error) {
	resp, err = ProductReviewHandler.CreateAndUpdateProdReviewStrategy(ctx, req)
	if resp == nil {
		resp = &prod_review.CreateAndUpdateProdReviewStrategyResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// GetProdReviewStrategyList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProdReviewStrategyList(ctx context.Context, req *prod_review.GetProdReviewStrategyListRequest) (resp *prod_review.GetProdReviewStrategyListResponse, err error) {
	resp, err = ProductReviewHandler.GetProdReviewStrategyList(ctx, req)
	if resp == nil {
		resp = &prod_review.GetProdReviewStrategyListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CreateAndUpdateProdReviewBizProject implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateAndUpdateProdReviewBizProject(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewBizProjectRequest) (resp *prod_review.CreateAndUpdateProdReviewBizProjectResponse, err error) {
	resp, err = ProductReviewHandler.CreateAndUpdateProdReviewBizProject(ctx, req)
	if resp == nil {
		resp = &prod_review.CreateAndUpdateProdReviewBizProjectResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// GetProdReviewBizProjectList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProdReviewBizProjectList(ctx context.Context, req *prod_review.GetProdReviewBizProjectListRequest) (resp *prod_review.GetProdReviewBizProjectListResponse, err error) {
	resp, err = ProductReviewHandler.GetProdReviewBizProjectList(ctx, req)
	if resp == nil {
		resp = &prod_review.GetProdReviewBizProjectListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CreateAndUpdateProdReviewReport implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateAndUpdateProdReviewReport(ctx context.Context, req *prod_review.CreateAndUpdateProdReviewReportRequest) (resp *prod_review.CreateAndUpdateProdReviewReportResponse, err error) {
	resp, err = ProductReviewHandler.CreateAndUpdateProdReviewReport(ctx, req)
	if resp == nil {
		resp = &prod_review.CreateAndUpdateProdReviewReportResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// GetProdReviewReportList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProdReviewReportList(ctx context.Context, req *prod_review.GetProdReviewReportListRequest) (resp *prod_review.GetProdReviewReportListResponse, err error) {
	resp, err = ProductReviewHandler.GetProdReviewReportList(ctx, req)
	if resp == nil {
		resp = &prod_review.GetProdReviewReportListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// ProductValueClassify implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) ProductValueClassify(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisItemDataResponse, err error) {
	resp, err = ProductReviewHandler.ProductValueClassify(ctx, req)
	if resp == nil {
		resp = &common_response.CommonAnalysisItemDataResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// CreateAnalysisFramework implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateAnalysisFramework(ctx context.Context, req *ai_analysis.CreateAnalysisFrameworkRequest) (resp *ai_analysis.CreateAnalysisFrameworkResponse, err error) {
	resp, err = AIAnalysisHandler.CreateAnalysisFramework(ctx, req)
	if resp == nil {
		resp = &ai_analysis.CreateAnalysisFrameworkResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// GetAnalysisFramework implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetAnalysisFramework(ctx context.Context, req *ai_analysis.GetAnalysisFrameworkRequest) (resp *ai_analysis.GetAnalysisFrameworkResponse, err error) {
	resp, err = AIAnalysisHandler.GetAnalysisFramework(ctx, req)
	if resp == nil {
		resp = &ai_analysis.GetAnalysisFrameworkResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// UpdateAnalysisFramework implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateAnalysisFramework(ctx context.Context, req *ai_analysis.UpdateAnalysisFrameworkRequest) (resp *ai_analysis.UpdateAnalysisFrameworkResponse, err error) {
	resp, err = AIAnalysisHandler.UpdateAnalysisFramework(ctx, req)
	if resp == nil {
		resp = &ai_analysis.UpdateAnalysisFrameworkResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// DeleteAnalysisFramework implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DeleteAnalysisFramework(ctx context.Context, req *ai_analysis.DeleteAnalysisFrameworkRequest) (resp *ai_analysis.DeleteAnalysisFrameworkResponse, err error) {
	resp, err = AIAnalysisHandler.DeleteAnalysisFramework(ctx, req)
	if resp == nil {
		resp = &ai_analysis.DeleteAnalysisFrameworkResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CreateKnowledge implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateKnowledge(ctx context.Context, req *ai_analysis.CreateKnowledgeRequest) (resp *ai_analysis.CreateKnowledgeResponse, err error) {
	// TODO: Your code here...
	return
}

// ProductFourQuadrantAnalysis implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) ProductFourQuadrantAnalysis(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisItemDataResponse, err error) {
	resp, err = ProductReviewHandler.ProductFourQuadrantAnalysis(ctx, req)
	if resp == nil {
		resp = &common_response.CommonAnalysisItemDataResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// GetKnowledge implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetKnowledge(ctx context.Context, req *ai_analysis.GetKnowledgeRequest) (resp *ai_analysis.GetKnowledgeResponse, err error) {
	// TODO: Your code here...
	return
}

// GetBubbleChart implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetBubbleChart(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisUnifiedDataResponse, err error) {
	resp, err = ProductReviewHandler.GetBubbleChart(ctx, req)
	if resp == nil {
		resp = &common_response.CommonAnalysisUnifiedDataResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// UpdateKnowledge implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateKnowledge(ctx context.Context, req *ai_analysis.UpdateKnowledgeRequest) (resp *ai_analysis.UpdateKnowledgeResponse, err error) {
	// TODO: Your code here...
	return
}

// GetFlowDistribution implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetFlowDistribution(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisMultiDimTableResponse, err error) {
	// TODO: Your code here...
	resp, err = MultiDimTableHandler.CommonAnalysisMultiDimTable(ctx, req)
	if resp == nil {
		resp = &common_response.CommonAnalysisMultiDimTableResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	extraInfo, err := ProductReviewHandler.StrategyCoverageRatioExtraInfo(ctx, req)
	if err != nil {
		return resp, err
	}
	if resp.Data != nil {
		resp.Data.ExtraInfo = extraInfo
	}
	return
}

// DeleteKnowledge implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DeleteKnowledge(ctx context.Context, req *ai_analysis.DeleteKnowledgeRequest) (resp *ai_analysis.DeleteKnowledgeResponse, err error) {
	// TODO: Your code here...
	return
}

// CommonMultiDimTrend implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CommonMultiDimTrend(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonMultiDimTrendResponse, err error) {
	resp, err = MultiDimTrendHandler.CommonAnalysisMultiDimTrend(ctx, req)
	if resp == nil {
		resp = &common_response.CommonMultiDimTrendResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// CommonAnalysisMultiDimTable implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CommonAnalysisMultiDimTable(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisMultiDimTableResponse, err error) {
	resp, err = MultiDimTableHandler.CommonAnalysisMultiDimTable(ctx, req)
	if resp == nil {
		resp = &common_response.CommonAnalysisMultiDimTableResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// CommonAnalysisMultiDimTableDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CommonAnalysisMultiDimTableDownload(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisDownloadResponse, err error) {
	resp, err = MultiDimTableHandler.CommonAnalysisMultiDimTableDownload(ctx, req)
	if resp == nil {
		resp = &common_response.CommonAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

// CommonDiagnosisConclusionByTarget implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CommonDiagnosisConclusionByTarget(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisItemDataResponse, err error) {
	// TODO: Your code here...
	return
}

// CommonDiagnosisConclusion implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CommonDiagnosisConclusion(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.GetDiagnosisConclusionResponse, err error) {
	// TODO: Your code here...
	return
}

// GetProdReviewStrategyTypeList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProdReviewStrategyTypeList(ctx context.Context, req *prod_review.GetProdReviewStrategyTypeListRequest) (resp *prod_review.GetProdReviewStrategyTypeListResponse, err error) {
	resp, err = ProductReviewHandler.GetProductReviewStrategyTypeList(ctx, req)
	if resp == nil {
		resp = &prod_review.GetProdReviewStrategyTypeListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// GetLibraInfo implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetLibraInfo(ctx context.Context, req *prod_review.GetLibraInfoRequest) (resp *prod_review.GetLibraInfoResponse, err error) {
	resp, err = ProductReviewHandler.GetLibraInfo(ctx, req)
	if resp == nil {
		resp = &prod_review.GetLibraInfoResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CommonAnalysisTargetTable implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CommonAnalysisTargetTable(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisTargetTableResponse, err error) {
	return ProductReviewHandler.CommonAnalysisTargetTable(ctx, req), nil
}

// CommonAnalysisItemData implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CommonAnalysisItemData(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisItemDataResponse, err error) {
	// TODO: Your code here...
	return ProductReviewHandler.CommonAnalysisItemData(ctx, req)
}

// ActivityApprovalCallback implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) ActivityApprovalCallback(ctx context.Context, req *activity.ApprovalCallbackRequest) (resp *activity.ApprovalCallbackResponse, err error) {
	resp, err = ActivityHandler.ActivityApprovalCallback(ctx, req)
	if resp == nil {
		resp = &activity.ApprovalCallbackResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// ApprovalActivity implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) ApprovalActivity(ctx context.Context, req *activity.ApprovalActivityReq) (resp *activity.ApprovalActivityResp, err error) {
	resp, err = ActivityHandler.ApprovalActivity(ctx, req)
	if resp == nil {
		resp = &activity.ApprovalActivityResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// GetBizConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetBizConfig(ctx context.Context, req *common_request.BizConfigRequest) (resp *common_response.BizConfigResponse, err error) {
	return ProductReviewHandler.GetBizConfig(ctx, req)
}

// CreateAnalysisPoolApplicationRecord implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateAnalysisPoolApplicationRecord(ctx context.Context, req *analysis_pool.CreateAnalysisPoolApplicationRecordReq) (resp *analysis_pool.CreateAnalysisPoolApplicationRecordResp, err error) {
	resp, err = AnalysisPoolHandler.HandleCreateAnalysisPoolApplicationRecord(ctx, req)
	if resp == nil {
		resp = &analysis_pool.CreateAnalysisPoolApplicationRecordResp{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "req=%s, err=%s", jsonx.ToString(req), err)
	}
	return resp, nil
}

// GetDoradoAnalysisPoolApplicationHiveCallBack implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDoradoAnalysisPoolApplicationHiveCallBack(ctx context.Context, req *dorado_task.GetDoradoTaskRunningCallBackRequest) (resp *dorado_task.GetDoradoTaskRunningCallBackResponse, err error) {
	resp, err = AnalysisPoolHandler.HandleGetDoradoAnalysisPoolApplicationHiveCallBack(ctx, req)
	if resp == nil {
		resp = &dorado_task.GetDoradoTaskRunningCallBackResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}

	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "req=%s, err=%s", jsonx.ToString(req), err)
		return resp, nil
	}
	return resp, nil
}

// CreateAndUpdateProductSelectTask implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateAndUpdateProductSelectTask(ctx context.Context, req *product_select.CreateAndUpdateProductSelectTaskRequest) (resp *product_select.CreateAndUpdateProductSelectTaskResponse, err error) {
	resp, err = ProductSelectHandler.CreateAndUpdateProductSelectTask(ctx, req)
	if resp == nil {
		resp = &product_select.CreateAndUpdateProductSelectTaskResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "req=%s, err=%s", jsonx.ToString(req), err)
	}
	return resp, nil
}

// GetProductSelectTaskList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductSelectTaskList(ctx context.Context, req *product_select.GetProductSelectTaskListRequest) (resp *product_select.GetProductSelectTaskListResponse, err error) {
	resp, err = ProductSelectHandler.GetProductSelectTaskList(ctx, req)
	if resp == nil {
		resp = &product_select.GetProductSelectTaskListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "req=%s, err=%s", jsonx.ToString(req), err)
	}
	return resp, nil
}

// GetProductSelectTaskDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductSelectTaskDetail(ctx context.Context, req *product_select.GetProductSelectTaskDetailRequest) (resp *product_select.GetProductSelectTaskDetailResponse, err error) {
	resp, err = ProductSelectHandler.GetProductSelectTaskDetail(ctx, req)
	if resp == nil {
		resp = &product_select.GetProductSelectTaskDetailResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "req=%s, err=%s", jsonx.ToString(req), err)
	}
	return resp, nil
}

// GetDocContent implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDocContent(ctx context.Context, req *lark.GetDocContentRequest) (resp *lark.GetDocContentResponse, err error) {
	resp, err = LarkHandler.GetDocContent(ctx, req)
	if resp == nil {
		resp = &lark.GetDocContentResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CheckDocPermission implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CheckDocPermission(ctx context.Context, req *lark.CheckDocPermissionRequest) (resp *lark.CheckDocPermissionResponse, err error) {
	resp, err = LarkHandler.CheckDocPermission(ctx, req)
	if resp == nil {
		resp = &lark.CheckDocPermissionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// BubbleChartDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) BubbleChartDownload(ctx context.Context, req *common_request.CommonAnalysisRequest) (resp *common_response.CommonAnalysisDownloadResponse, err error) {
	resp, err = ProductReviewHandler.BubbleChartDownload(ctx, req)
	if resp == nil {
		resp = &common_response.CommonAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return
}

func (s *SmartopProductAnalysisServiceImpl) AIConclusionStream(req *ai_analysis.AIConclusionRequest, stream product_analysis.SmartopProductAnalysisService_AIConclusionStreamServer) (err error) {
	return AIAnalysisHandler.AIConclusionStream(req, stream)
}

// AIConclusion implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) AIConclusion(ctx context.Context, req *ai_analysis.AIConclusionRequest) (resp *ai_analysis.AIResponse, err error) {
	resp, err = AIAnalysisHandler.AIConclusion(ctx, req)
	if resp == nil {
		resp = &ai_analysis.AIResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// GetProdDetailList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProdDetailList(ctx context.Context, req *product_select.GetProdDetailListRequest) (resp *product_select.GetProdDetailListResponse, err error) {
	resp, err = ProductSelectHandler.GetProdDetailList(ctx, req)
	if resp == nil {
		resp = &product_select.GetProdDetailListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "req=%s, err=%s", jsonx.ToString(req), err)
	}

	return resp, nil
}

// GetProductSelectAdministratorConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductSelectAdministratorConfig(ctx context.Context, req *product_select.GetProductSelectAdministratorConfigRequest) (resp *product_select.GetProductSelectAdministratorConfigResponse, err error) {
	resp, err = ProductSelectHandler.GetProductSelectAdministratorConfig(ctx, req)
	if resp == nil {
		resp = &product_select.GetProductSelectAdministratorConfigResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "req=%s, err=%s", jsonx.ToString(req), err)
	}
	logs.CtxInfo(ctx, "GetProductSelectAdministratorConfig resp, %s", jsonx.ToString(resp))

	return resp, nil
}

// GetProductSelectTaskPreviewResult_ implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetProductSelectTaskPreviewResult_(ctx context.Context, req *product_select.GetProductSelectTaskPreviewResultRequest) (resp *product_select.GetProductSelectTaskPreviewResultResponse, err error) {
	resp, err = ProductSelectHandler.GetProductSelectTaskPreviewResult(ctx, req)
	if resp == nil {
		resp = &product_select.GetProductSelectTaskPreviewResultResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "req=%s, err=%s", jsonx.ToString(req), err)
	}

	return resp, nil
}

// GetUserPrivilege implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetUserPrivilege(ctx context.Context, req *product_select.GetUserPrivilegeRequest) (resp *product_select.GetUserPrivilegeResponse, err error) {
	logs.CtxInfo(ctx, "GetUserPrivilege request received, biz_type=%v, employee_id=%s", req.GetBizType(), req.GetEmployeeId())
	resp, err = ProductSelectHandler.GetUserPrivilege(ctx, req)
	if resp == nil {
		resp = &product_select.GetUserPrivilegeResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// AIStrategyGen implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) AIStrategyGen(ctx context.Context, req *ai_analysis.AIStrategyGenRequest) (resp *ai_analysis.AIResponse, err error) {
	resp, err = AIStrategyHandler.AIStrategyGen(ctx, req)
	if resp == nil {
		resp = &ai_analysis.AIResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// FlightAnalysis implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) FlightAnalysis(ctx context.Context, req *ai_analysis.FlightAnalysisRequest) (resp *ai_analysis.AIResponse, err error) {
	resp, err = AIStrategyHandler.FlightAnalysis(ctx, req)
	if resp == nil {
		resp = &ai_analysis.AIResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CreateStrategy implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateStrategy(ctx context.Context, req *ai_analysis.CreateStrategyRequest) (resp *ai_analysis.CreateStrategyResponse, err error) {
	resp, err = AIStrategyHandler.CreateStrategy(ctx, req)
	if resp == nil {
		resp = &ai_analysis.CreateStrategyResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// UpdateStrategy implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateStrategy(ctx context.Context, req *ai_analysis.UpdateStrategyRequest) (resp *ai_analysis.UpdateStrategyResponse, err error) {
	resp, err = AIStrategyHandler.UpdateStrategy(ctx, req)
	if resp == nil {
		resp = &ai_analysis.UpdateStrategyResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// GetStrategyDetail implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetStrategyDetail(ctx context.Context, req *ai_analysis.GetStrategyDetailRequest) (resp *ai_analysis.GetStrategyDetailResponse, err error) {
	resp, err = AIStrategyHandler.GetStrategyDetail(ctx, req)
	if resp == nil {
		resp = &ai_analysis.GetStrategyDetailResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// ImportFlightConclusion implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) ImportFlightConclusion(ctx context.Context, req *ai_analysis.ImportFlightConclusionRequest) (resp *ai_analysis.ImportFlightConclusionResponse, err error) {
	resp, err = AIStrategyHandler.ImportFlightConclusion(ctx, req)
	if resp == nil {
		resp = &ai_analysis.ImportFlightConclusionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CreateStrategyConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateStrategyConfig(ctx context.Context, req *ai_analysis.CreateStrategyConfigRequest) (resp *ai_analysis.CreateStrategyConfigResponse, err error) {
	resp, err = AIStrategyHandler.CreateStrategyConfig(ctx, req)
	if resp == nil {
		resp = &ai_analysis.CreateStrategyConfigResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// RejectStrategyConfig implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) RejectStrategyConfig(ctx context.Context, req *ai_analysis.RejectStrategyConfigRequest) (resp *ai_analysis.RejectStrategyConfigResponse, err error) {
	resp, err = AIStrategyHandler.RejectStrategyConfig(ctx, req)
	if resp == nil {
		resp = &ai_analysis.RejectStrategyConfigResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CreateStrategyConfigFlightRelation implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateStrategyConfigFlightRelation(ctx context.Context, req *ai_analysis.CreateStrategyConfigFlightRelationRequest) (resp *ai_analysis.CreateStrategyConfigFlightRelationResponse, err error) {
	resp, err = AIStrategyHandler.CreateStrategyConfigFlightRelation(ctx, req)
	if resp == nil {
		resp = &ai_analysis.CreateStrategyConfigFlightRelationResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
	}
	return resp, nil
}

// CreateDataset implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) CreateDataset(ctx context.Context, req *ai_analysis.CreateDatasetRequest) (resp *ai_analysis.CreateDatasetResponse, err error) {
	// TODO: Your code here...
	return
}

// GetDataset implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetDataset(ctx context.Context, req *ai_analysis.GetDatasetRequest) (resp *ai_analysis.GetDatasetResponse, err error) {
	// TODO: Your code here...
	return
}

// UpdateDataset implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateDataset(ctx context.Context, req *ai_analysis.UpdateDatasetRequest) (resp *ai_analysis.UpdateDatasetResponse, err error) {
	// TODO: Your code here...
	return
}

// DeleteDataset implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DeleteDataset(ctx context.Context, req *ai_analysis.DeleteDatasetRequest) (resp *ai_analysis.DeleteDatasetResponse, err error) {
	// TODO: Your code here...
	return
}

// GuessAllTreeDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GuessAllTreeDownload(ctx context.Context, req *aggregate.AllTreeDownloadRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	resp, err = AttributionHandler.GuessAllTreeDownload(ctx, GreatValueBuyHandler, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetProductAnalysisDownloadResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetProductAnalysisDownloadResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// GetGuessCoreOverview implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetGuessCoreOverview(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetAttributionCommonCoreOverviewResponse, err error) {
	resp, err = AttributionHandler.GetGuessCoreOverview(ctx, req)
	if err != nil {
		if resp == nil {
			resp = &analysis.GetAttributionCommonCoreOverviewResponse{}
			resp.SetBaseResp(base.NewBaseResp())
		}
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(defaultStCode.String())
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	if resp == nil {
		resp = &analysis.GetAttributionCommonCoreOverviewResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	return resp, nil
}

// ShopDetailDownload implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) ShopDetailDownload(ctx context.Context, req *analysis.GetAttributionCommonBaseRequest) (resp *analysis.GetProductAnalysisDownloadResponse, err error) {
	// TODO: Your code here...
	return
}

// UploadFile implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UploadFile(ctx context.Context, req *file.UploadFileRequest) (resp *file.UploadFileResponse, err error) {
	resp, err = FileHandler.UploadFile(ctx, req)
	if resp == nil {
		resp = &file.UploadFileResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetSessionList implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) GetSessionList(ctx context.Context, req *ai_analysis.GetSessionListRequest) (resp *ai_analysis.GetSessionListResponse, err error) {
	resp, err = AIAnalysisHandler.GetSessionList(ctx, req)
	if resp == nil {
		resp = &ai_analysis.GetSessionListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// DeleteSession implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) DeleteSession(ctx context.Context, req *ai_analysis.DeleteSessionRequest) (resp *ai_analysis.DeleteSessionResponse, err error) {
	resp, err = AIAnalysisHandler.DeleteSession(ctx, req)
	if resp == nil {
		resp = &ai_analysis.DeleteSessionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// UpdateSessionName implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) UpdateSessionName(ctx context.Context, req *ai_analysis.UpdateSessionNameRequest) (resp *ai_analysis.UpdateSessionNameResponse, err error) {
	resp, err = AIAnalysisHandler.UpdateSessionName(ctx, req)
	if resp == nil {
		resp = &ai_analysis.UpdateSessionNameResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// Test implements the SmartopProductAnalysisServiceImpl interface.
func (s *SmartopProductAnalysisServiceImpl) Test(ctx context.Context, req *test.TestRequest) (resp *test.TestResponse, err error) {
	// TODO: Your code here...
	resp = &test.TestResponse{}
	resp.SetCode(int32(stcodes.StatusCodeSuccess.Int()))
	resp.SetMsg(stcodes.StatusCodeSuccess.String())
	err = cronjob.BatchSyncDimendionsStatus(ctx)
	return
}
