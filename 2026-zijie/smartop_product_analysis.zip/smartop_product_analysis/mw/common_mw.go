package mw

import (
	"context"
	"fmt"
	"strconv"

	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/tcc/biz_info"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
)

// CheckBaseStructStreamParams 校验通用取数的参数与权限问题
func CheckBaseStructStreamParams(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct, employeeId *string) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	logs.CtxInfo(ctx, "接口请求体入参：\n %s", convert.ToJSONString(req))
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	if req == nil {
		return false, stcodes.StatusCodeParamError, "传入参数为空", ctx
	}

	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}
	ctx = context.WithValue(ctx, consts.CtxBizMetaInfo, bizInfo)
	//if strings.Contains(bizInfo.EffectModule, "货盘复盘") {
	//	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)
	//}
	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)
	// 获取业务线的维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionAllList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimMap, dimMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimColMap, dimColMap)

	// 获取业务线的维度信息
	dimList, err = new(dao.DimensionListDao).GetDimensionList(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap = make(map[int64]*dao.DimensionInfo)
	dimColMap = make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}

	ctx = context.WithValue(ctx, consts.CtxBizInfoDimMap, dimMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoDimColMap, dimColMap)

	// 判断比较类型
	if req.CompareType != nil && *req.CompareType == dimensions.CompareType_MarketingPromotionGrowthLibraCompare {
		// 等于实验组对比类型时
		req.CompareStartDate = req.StartDate
		req.CompareEndDate = req.EndDate
	}

	if len(req.StartDate) == 0 || len(req.EndDate) == 0 || len(req.CompareStartDate) == 0 || len(req.CompareEndDate) == 0 {
		return false, stcodes.StatusCodeParamError, "未配置选择时间范围信息", ctx
	}

	//判断是否有该业务线的权限
	if !env.IsBoe() && len(bizInfo.UserDimensionCode) > 0 {
		userDimensionMap, err := utils.GetStreamUserDimensionMap(ctx, employeeId)
		if err != nil {
			return false, stcodes.StatusCodeDefaultError, "获取数据权限失败", ctx
		}
		if !utils.CheckUserDimension(userDimensionMap, bizInfo.UserDimensionCode) {
			return false, stcodes.StatusUserAuthError, "无该业务线数据权限", ctx
		}
	}

	var templateFlag bool
	// 模版不需要校验时间和指标阈值
	if _, ok := ctx.Value(consts.CtxTemplateFlag).(string); ok {
		templateFlag = true
		return
	}

	// 填充默认的指标信息
	if len(req.TargetMetaList) == 0 {
		req.TargetMetaList = dimension_service.GetDefaultTargetMetaList(ctx, req.BizType)
	}
	// TODO: 暂时注释掉，获取货补指标需要调用RPC接口，流式接口ctx没有用户信息，暂时无法获取
	// else if !dimension_service.CheckTargetMetaListValid(ctx, req.BizType, req.TargetMetaList) {
	// 	logs.CtxWarn(ctx, "CheckTargetMetaListValid 传入指标列表无权限, req = %s", convert.ToJSONString(req))
	// 	return false, stcodes.StatusUserAuthError, "传入指标列表无权限", ctx
	// }

	// 若该业务线有必选项，则填充
	if len(bizInfo.RequiredDimInfo) > 0 && !isEditable(bizInfo.RequiredDimInfo) {
		if req.Dimensions == nil {
			req.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		}
		req.Dimensions = append(req.Dimensions, bizInfo.RequiredDimInfo...)
	}
	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)

	if !templateFlag {
		// 校验时间选择是否越界限
		dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, req.BizType)
		if err != nil {
			logs.CtxError(ctx, "获取os最新时间失败, err = %v+", err)
			return false, stcodes.StatusCodeDefaultError, "获取os最新时间失败", ctx
		}
		isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.StartDate, req.EndDate, bizInfo, dataInfo)
		if !isOk {
			logs.CtxWarn(ctx, "当前周期校验时间失败，msg=%s", msg)
			return
		}

		isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.CompareStartDate, req.CompareEndDate, bizInfo, dataInfo)
		if !isOk {
			logs.CtxWarn(ctx, "对比周期校验时间失败，msg=%s", msg)
			return
		}
	}

	// 校验枚举数据类型与枚举传入的参数是否匹配
	if len(req.Dimensions) > 0 || len(req.GroupAttrs) > 0 {
		if len(req.Dimensions) > 0 {
			for _, reqDim := range req.Dimensions {
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim, dimMap, false)
				if !isOk {
					return
				}
				if haveUse && reqDim.Id == consts.IsRcmdPoolProdDim {
					ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, []consts.DateType{consts.DateType_DAY})
				}
			}
		}

		if len(req.GroupAttrs) > 0 {
			for _, reqDim := range req.GroupAttrs {
				if reqDim == nil {
					continue
				}
				if reqDim.DimInfo != nil {
					reqDim.DimInfo.IsGroup = true
				}
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim.DimInfo, dimMap, true)
				if !isOk {
					return
				}
				if haveUse && reqDim != nil && reqDim.DimInfo != nil && (reqDim.DimInfo.AttrType != dimensions.DimensionAttributeType_Product ||
					reqDim.DimInfo.Id == consts.IsNewPayCntDim || reqDim.DimInfo.Id == consts.IsRecallPayCntDim) {
					//useProdTable = false
				}
			}
		}
	}

	if len(req.ThresholdAttrs) > 0 && !templateFlag {
		thresholdType := req.ThresholdAttrs[0].Type
		for _, t := range req.ThresholdAttrs {
			if thresholdType != t.Type {
				return false, stcodes.StatusCodeParamError, "所选的指标阈值类型存在不一致", ctx
			}

			switch t.Type {
			case dimensions.ThresholdType_TOP_THRESHOLD:
				if t.TopN == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if *t.TopN < 0 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
				if t.TopN == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if *t.TopN < 0 || *t.TopN >= 100 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			case dimensions.ThresholdType_ACC_THRESHOLD:
				if t.AccThreshold == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if t.AccThreshold.Threshold < 0 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			default:
				return false, stcodes.StatusCodeParamError, "所选的指标阈值类型不存在", ctx
			}
		}
	}
	return isOk, stCode, msg, ctx
}

// CheckBaseStructParams 校验通用取数的参数与权限问题
func CheckBaseStructParams(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	logs.CtxInfo(ctx, "接口请求体入参：\n %s", convert.ToJSONString(req))
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	if req == nil {
		return false, stcodes.StatusCodeParamError, "传入参数为空", ctx
	}

	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}
	ctx = context.WithValue(ctx, consts.CtxBizMetaInfo, bizInfo)
	//if strings.Contains(bizInfo.EffectModule, "货盘复盘") {
	//	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)
	//}
	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)
	// 获取维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionAllList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimMap, dimMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimColMap, dimColMap)

	// 获取业务线的维度信息
	dimList, err = new(dao.DimensionListDao).GetDimensionList(ctx, req.BizType)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap = make(map[int64]*dao.DimensionInfo)
	dimColMap = make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}

	ctx = context.WithValue(ctx, consts.CtxBizInfoDimMap, dimMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoDimColMap, dimColMap)

	if bizInfo.EffectModule == "大促视图" {
		// 大促视图校验
		isBigActView := false
		for _, dim := range req.Dimensions {
			if dim != nil && dim.Id == "10366" {
				isBigActView = true
				break
			}
		}
		if isBigActView {
			isOk, stCode, msg = handleBigActViewDimensions(ctx, req)
			if !isOk {
				return isOk, stCode, msg, ctx
			}
		}
	}

	// 判断比较类型
	if req.CompareType != nil && *req.CompareType == dimensions.CompareType_MarketingPromotionGrowthLibraCompare {
		// 等于实验组对比类型时
		req.CompareStartDate = req.StartDate
		req.CompareEndDate = req.EndDate
	}

	if len(req.StartDate) == 0 || len(req.EndDate) == 0 || len(req.CompareStartDate) == 0 || len(req.CompareEndDate) == 0 {
		return false, stcodes.StatusCodeParamError, "未配置选择时间范围信息", ctx
	}

	//判断是否有该业务线的权限
	if !env.IsBoe() && len(bizInfo.UserDimensionCode) > 0 {
		userDimensionMap, err := utils.GetUserDimensionMap(ctx)
		if err != nil {
			return false, stcodes.StatusCodeDefaultError, "获取数据权限失败", ctx
		}
		if !utils.CheckUserDimension(userDimensionMap, bizInfo.UserDimensionCode) {
			return false, stcodes.StatusUserAuthError, "无该业务线数据权限", ctx
		}
	}

	var templateFlag bool
	// 模版不需要校验时间和指标阈值
	if _, ok := ctx.Value(consts.CtxTemplateFlag).(string); ok {
		templateFlag = true
		return
	}

	// 判断指标信息
	if len(req.TargetMetaList) == 0 {
		req.TargetMetaList = dimension_service.GetDefaultTargetMetaList(ctx, req.BizType)
	} else if !dimension_service.CheckTargetMetaListValid(ctx, req.BizType, req.TargetMetaList) {
		logs.CtxWarn(ctx, "CheckTargetMetaListValid 传入指标列表无权限, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusUserAuthError, "传入指标列表无权限", ctx
	}

	// 若该业务线有必选项，则填充
	if len(bizInfo.RequiredDimInfo) > 0 && !isEditable(bizInfo.RequiredDimInfo) {
		if req.Dimensions == nil {
			req.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		}
		req.Dimensions = append(req.Dimensions, bizInfo.RequiredDimInfo...)
	}
	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)

	if !templateFlag {
		// 校验时间选择是否越界限
		dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, req.BizType)
		if err != nil {
			logs.CtxError(ctx, "获取os最新时间失败, err = %v+", err)
			return false, stcodes.StatusCodeDefaultError, "获取os最新时间失败", ctx
		}
		isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.StartDate, req.EndDate, bizInfo, dataInfo)
		if !isOk {
			logs.CtxWarn(ctx, "当前周期校验时间失败，msg=%s", msg)
			return
		}

		isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.CompareStartDate, req.CompareEndDate, bizInfo, dataInfo)
		if !isOk {
			logs.CtxWarn(ctx, "对比周期校验时间失败，msg=%s", msg)
			return
		}
	}

	// 校验枚举数据类型与枚举传入的参数是否匹配
	if len(req.Dimensions) > 0 || len(req.GroupAttrs) > 0 {
		if len(req.Dimensions) > 0 {
			for _, reqDim := range req.Dimensions {
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim, dimMap, false)
				if !isOk {
					return
				}
				if haveUse && reqDim.Id == consts.IsRcmdPoolProdDim {
					ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, []consts.DateType{consts.DateType_DAY})
				}
			}
		}

		if len(req.GroupAttrs) > 0 {
			for _, reqDim := range req.GroupAttrs {
				if reqDim == nil {
					continue
				}
				if reqDim.DimInfo != nil {
					reqDim.DimInfo.IsGroup = true
				}
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim.DimInfo, dimMap, true)
				if !isOk {
					return
				}
				if haveUse && reqDim != nil && reqDim.DimInfo != nil && (reqDim.DimInfo.AttrType != dimensions.DimensionAttributeType_Product ||
					reqDim.DimInfo.Id == consts.IsNewPayCntDim || reqDim.DimInfo.Id == consts.IsRecallPayCntDim) {
					//useProdTable = false
				}
			}
		}
	}

	if len(req.ThresholdAttrs) > 0 && !templateFlag {
		thresholdType := req.ThresholdAttrs[0].Type
		for _, t := range req.ThresholdAttrs {
			if thresholdType != t.Type {
				return false, stcodes.StatusCodeParamError, "所选的指标阈值类型存在不一致", ctx
			}

			switch t.Type {
			case dimensions.ThresholdType_TOP_THRESHOLD:
				if t.TopN == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if *t.TopN < 0 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
				if t.TopN == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if *t.TopN < 0 || *t.TopN >= 100 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			case dimensions.ThresholdType_ACC_THRESHOLD:
				if t.AccThreshold == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if t.AccThreshold.Threshold < 0 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			default:
				return false, stcodes.StatusCodeParamError, "所选的指标阈值类型不存在", ctx
			}
		}
	}
	return isOk, stCode, msg, ctx
}

// handleBigActViewDimensions 处理大促视图下的特殊维度逻辑
func handleBigActViewDimensions(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (isOk bool, stCode stcodes.StCode, msg string) {
	var hasSignUpDim bool
	var signUpDim *dimensions.SelectedDimensionInfo

	// 查找并移除已有的报名状态维度，后续会重新添加，确保其在最后
	for i, dim := range req.Dimensions {
		if dim.Id == "10372" {
			signUpDim = dim
			hasSignUpDim = true
			req.Dimensions = append(req.Dimensions[:i], req.Dimensions[i+1:]...)
			break
		}
	}

	// 如果请求中没有报名状态维度，则创建一个新的
	if !hasSignUpDim {
		signUpDim = &dimensions.SelectedDimensionInfo{
			Id:             "10372",
			Name:           "大促报名状态",
			SelectedValues: []*dimensions.EnumElement{},
		}
	}

	// 如果报名状态维度没有选定值，则自动填充默认值 "主动报名+氛围圈选"
	if len(signUpDim.SelectedValues) == 0 {
		selectedValuesMap, err := new(dao.DimensionEnumDao).GetEnumByDimIds(ctx, []int64{convert.ToInt64(signUpDim.Id)}...)
		if err != nil || selectedValuesMap == nil || len(selectedValuesMap[convert.ToInt64(signUpDim.Id)]) == 0 {
			logs.CtxError(ctx, "大促视图-报名状态枚举值获取错误")
			return false, stcodes.StatusCodeDefaultError, "大促视图-报名状态枚举值获取错误"
		}

		foundDefaultEnum := false
		for _, enum := range selectedValuesMap[convert.ToInt64(signUpDim.Id)] {
			if enum.Name == "主动报名+氛围圈选" {
				signUpDim.SelectedValues = append(signUpDim.SelectedValues, enum)
				foundDefaultEnum = true
				break
			}
		}

		if !foundDefaultEnum {
			logs.CtxError(ctx, "大促视图-未找到默认的报名状态枚举值[主动报名+氛围圈选]")
			return false, stcodes.StatusCodeDefaultError, "大促视图-报名状态枚举值获取错误"
		}
	}

	// 将处理好的报名状态维度添加回请求中
	req.Dimensions = append(req.Dimensions, signUpDim)
	return true, stcodes.StatusCodeSuccess, ""
}

func isEditable(requireds []*dimensions.SelectedDimensionInfo) bool {
	for _, v := range requireds {
		if v != nil && v.Editable == 1 {
			return true
		}
	}
	return false
}

func checkDateTypeRange(ctx context.Context, startDate, endDate string, bizInfo *biz_utils.BizMetaInfo, readyDateInfo *dimensions.DataReadyTime, dateType base.DateType) (isOk bool, stCode stcodes.StCode, msg string) {
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	daysTypeList := make([]consts.DateType, 0)
	daysTypeList = append(daysTypeList, consts.DateType_DAY)
	switch dateType {
	case base.DateType_WEEK:
		daysTypeList = append(daysTypeList, consts.DateType_WEEK)
	case base.DateType_MONTH:
		daysTypeList = append(daysTypeList, consts.DateType_MONTH)
	default:
	}

	// 开始进行时间函数解析
	dateTypeSplitMap, err := time_utils.GetCustomTimeStrSplit(startDate, endDate, daysTypeList)
	if err != nil {
		return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String()
	}

	if len(dateTypeSplitMap) == 0 {
		return false, stcodes.StatusCodeParamError, "时间周期选择有误，请检查后重新选择"
	}

	if dateType != base.DateType_DAY && len(dateTypeSplitMap[consts.DateType_DAY]) > 0 {
		return false, stcodes.StatusCodeParamError, "时间周期选择有误，时间粒度与选择范围不匹配"
	}

	for _, info := range bizInfo.DateRangeInfo {
		if info.DateType == dateType {
			var currRange int64
			switch dateType {
			case base.DateType_WEEK:
				currRange = int64(len(dateTypeSplitMap[consts.DateType_WEEK]))
			case base.DateType_MONTH:
				currRange = int64(len(dateTypeSplitMap[consts.DateType_MONTH]))
			default:
				continue
			}
			if currRange < info.MinDateRange || currRange > info.MaxDateRange {
				return false, stcodes.StatusCodeParamError, "超出时间周期最大可选范围"
			}
		}
	}

	if checkDataRange(startDate, readyDateInfo) {
		return false, stcodes.StatusCodeParamError, "超出所选时间范围"
	}
	if checkDataRange(endDate, readyDateInfo) {
		return false, stcodes.StatusCodeParamError, "超出所选时间范围"
	}

	return
}

func checkCustomWithDaysTypeDate(ctx context.Context, startDate, endDate string, bizInfo *biz_utils.BizMetaInfo, readyDateInfo *dimensions.DataReadyTime) (isOk bool, stCode stcodes.StCode, msg string) {
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty
	// 开始进行时间函数解析
	dateTypeSplitMap, err := time_utils.GetCustomTimeStrSplit(startDate, endDate, bizInfo.DaysTypeList)
	if err != nil {
		return false, stcodes.StatusCodeDefaultError, "时间周期传入错误"
	}

	if len(dateTypeSplitMap) == 0 {
		return false, stcodes.StatusCodeParamError, "时间周期选择有误，请检查后重新选择"
	}

	// 校验时间周期的范围比较
	currRange := time_utils.DateDiffAbsWithFormat(startDate, endDate, consts.Fmt_Date)
	if bizInfo.SelectRangeDay < currRange {
		return false, stcodes.StatusCodeParamError, fmt.Sprintf("时间周期最大可选范围%d天", bizInfo.SelectRangeDay)
	}

	for _, dateList := range dateTypeSplitMap {
		for _, d := range dateList {
			if checkDataRange(d.EndDate, readyDateInfo) {
				return false, stcodes.StatusCodeParamError, "超出所选时间范围"
			}
		}
	}

	return
}

func checkDimInfo(ctx context.Context, reqDim *dimensions.SelectedDimensionInfo, dimMap map[int64]*dao.DimensionInfo, isGroup bool) (isOk bool, stCode stcodes.StCode, msg string, haveUse bool) {
	isOk, stCode, msg, haveUse = true, stcodes.StatusCodeSuccess, consts.Empty, true

	dimInfo, exist := dimMap[convert.ToInt64(reqDim.Id)]
	if !exist {
		logs.CtxWarn(ctx, "选择维度与业务线不匹配，reqDim=%s", convert.ToJSONString(reqDim))
		return false, stcodes.StatusCodeParamError, fmt.Sprintf("您设置的维度【%s】不属于该业务线", reqDim.Name), false
	}

	if reqDim.Id == consts.ProdIDDim {
		if len(reqDim.SelectedValues) == 0 || len(reqDim.SelectedValues[0].TypeValue) == 0 {
			logs.CtxWarn(ctx, "商品ID筛选未填充有效信息，reqDim=%s", convert.ToJSONString(reqDim))
			return isOk, stCode, msg, false
		}

		if len(reqDim.SelectedValues[0].TypeValue) > 10000 {
			logs.CtxWarn(ctx, "填充了超过10000个商品ID的筛选条件，req=%s", convert.ToJSONString(reqDim))
			return false, stcodes.StatusCodeParamError, "填充了超过10000个商品ID的筛选条件", false
		}
	}

	if slices.ContainsString(consts.HaveEnumCodeShowTypeList, dimInfo.ShowType) {
		if len(reqDim.SelectedValues) == 0 {
			logs.CtxWarn(ctx, "未配置具体的枚举值，reqDim=%s", convert.ToJSONString(reqDim))
			return isOk, stCode, msg, false
		}

		if isGroup && len(reqDim.SelectedValues) > biz_info.GetMultiDimEnumMaxNum(ctx) {
			logs.CtxWarn(ctx, "维度包含的枚举值过多，最多筛选%d个，reqDim=%s", biz_info.GetMultiDimEnumMaxNum(ctx), convert.ToJSONString(reqDim))
			return false, stcodes.StatusCodeParamError, fmt.Sprintf("您设置的维度【%s】包含的枚举值过多，请筛选后查看结果（最多筛选%d个）～", dimInfo.ShowName, biz_info.GetMultiDimEnumMaxNum(ctx)), false
		}

		if !isGroup && (consts.Show_Type_Single_Select == dimInfo.ShowType ||
			consts.Show_Type_Bool_Single_Select == dimInfo.ShowType) && len(reqDim.SelectedValues) != 1 {
			logs.CtxWarn(ctx, "设置的维度为单选，所选枚举值过多，reqDim=%s", convert.ToJSONString(reqDim))
			return false, stcodes.StatusCodeParamError, fmt.Sprintf("您设置的维度【%s】为单选，所选枚举值过多～", dimInfo.ShowName), false
		}
	}

	if slices.ContainsString(consts.HaveEnumRangeShowTypeList, dimInfo.ShowType) && len(reqDim.SelectedValues) == 0 {
		logs.CtxWarn(ctx, "未输入具体的范围数据，reqDim=%s", convert.ToJSONString(reqDim))
		return isOk, stCode, msg, false
	}

	if slices.ContainsString(consts.HaveEnumRangeShowTypeList, dimInfo.ShowType) &&
		(len(reqDim.SelectedValues) == 0 || len(reqDim.SelectedValues[0].TypeValue) != 2) {
		logs.CtxWarn(ctx, "未输入具体的范围数据，reqDim=%s", convert.ToJSONString(reqDim))
		return false, stcodes.StatusCodeParamError, fmt.Sprintf("您设置的维度【%s】，未输入具体的范围数据", dimInfo.ShowName), false
	}

	if !isGroup && len(reqDim.SelectedValues) > 0 {
		for _, reqEnum := range reqDim.SelectedValues {
			switch dimInfo.ShowType {
			case consts.Show_Type_Amount_Range_Input, consts.Show_Type_Number_Range_Input:
				isOk = checkRangeStr(
					reqEnum.TypeValue[0], reqEnum.TypeValue[1], convert.ToFloat64E,
					func(t float64) bool {
						return t >= float64(0)
					}, func(s, e float64) bool {
						return e >= s
					})
				if !isOk {
					stCode = stcodes.StatusCodeParamError
					msg = "输入框数字填写错误～请纠正"
				}
			case consts.Show_Type_Ratio_Range_Input:
				isOk = checkRangeStr(
					reqEnum.TypeValue[0], reqEnum.TypeValue[1], convert.ToFloat64E,
					func(t float64) bool {
						return t >= float64(0) && t <= float64(100)
					}, func(s, e float64) bool {
						return e >= s
					})
				if !isOk {
					stCode = stcodes.StatusCodeParamError
					msg = "输入框数字填写错误～请纠正"
				}
			default:
				continue
			}
		}
	}

	return
}

// checkRangeStr 校验范围输入框类型的枚举值
func checkRangeStr[T any](startStr, endStr string, convertFunc func(interface{}) (T, error), checkFunc func(T) bool, compareFunc func(s, e T) bool) bool {
	startV, err := convertFunc(startStr)
	if startStr != consts.Negetive_Infinity && err != nil {
		return false
	}

	if startStr != consts.Negetive_Infinity && checkFunc != nil && !checkFunc(startV) {
		return false
	}

	endV, err := convertFunc(endStr)
	if endStr != consts.Positive_Infinity && err != nil {
		return false
	}

	if endStr != consts.Positive_Infinity && checkFunc != nil && !checkFunc(endV) {
		return false
	}

	if startStr != consts.Negetive_Infinity && endStr != consts.Positive_Infinity && compareFunc != nil && !compareFunc(startV, endV) {
		return false
	}

	return true
}

func checkDataRange(date string, dateRange *dimensions.DataReadyTime) bool {
	return date < dateRange.OldestPartition || date > dateRange.NewestPartition_
}

func CheckPriceBaseStructParams(ctx context.Context, req *dimensions.PriceAnalysisBaseStruct) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	logs.CtxInfo(ctx, "接口请求体入参：\n %s", convert.ToJSONString(req))
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	if req == nil {
		return false, stcodes.StatusCodeParamError, "传入参数为空", ctx
	}

	ctx = context.WithValue(ctx, consts.CtxBizInfoPriceComparisonType, req.PriceComparisonType)

	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}

	var templateFlag bool
	// 模版不需要校验时间和指标阈值
	if _, ok := ctx.Value(consts.CtxTemplateFlag).(string); ok {
		templateFlag = true
	}
	if !templateFlag {
		// 校验时间选择是否越界限
		dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, req.BizType)
		if err != nil {
			return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String(), ctx
		}
		isOk, stCode, msg = checkDateTypeRange(ctx, req.StartDate, req.EndDate, bizInfo, dataInfo, req.DateType)
		if !isOk {
			return
		}
	}

	// 价格力变化条件标识
	var priceChangeInOutType *dimensions.PriceInOutType
	var priceChangeName string

	// 校验枚举数据类型与枚举传入的参数是否匹配
	if len(req.Dimensions) > 0 || len(req.GroupAttrs) > 0 {
		dimMap, err := (&dao.DimensionListDao{}).GetDimensionMap(ctx, req.BizType)
		if err != nil {
			return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String(), ctx
		}

		if len(req.Dimensions) > 0 {
			for _, reqDim := range req.Dimensions {
				isOk, stCode, msg, _ = checkDimInfo(ctx, reqDim, dimMap, false)
				if !isOk {
					return
				}
				if reqDim.Id == consts.OutPriceChangeTypeDim || reqDim.Id == consts.XdPriceChangeTypeDim {
					if len(reqDim.SelectedValues) > 0 {
						priceChangeName = reqDim.SelectedValues[0].Name
						enums, err := (&dao.DimensionEnumDao{}).GetEnumByDimId(ctx, convert.ToInt64(reqDim.Id))
						if err != nil {
							return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String(), ctx
						}
						var haveEnum bool
						for _, enum := range enums {
							if enum.Name == priceChangeName {
								haveEnum = true
								break
							}
						}
						if !haveEnum {
							return false, stcodes.StatusCodeParamError, "价格力变化筛选条件未匹配", ctx
						}
						switch reqDim.Id {
						case consts.OutPriceChangeTypeDim:
							priceChangeInOutType = dimensions.PriceInOutTypePtr(dimensions.PriceInOutType_PRICE_OUT)
						case consts.XdPriceChangeTypeDim:
							priceChangeInOutType = dimensions.PriceInOutTypePtr(dimensions.PriceInOutType_PRICE_IN)
						default:
							priceChangeInOutType = nil
						}
					}
				}
			}
		}

		if len(req.GroupAttrs) > 0 {
			for _, reqDim := range req.GroupAttrs {
				isOk, stCode, msg, _ = checkDimInfo(ctx, reqDim.DimInfo, dimMap, true)
				if !isOk {
					return
				}
			}
		}
	}

	// 如果是价格力变化，并且用户没有选择价格力变化的筛选，则报错
	if req.BizType == dimensions.BizType_PriceAACompare {
		if req.Granularity == nil {
			return false, stcodes.StatusCodeParamError, "价格力变化未选择商品/SKU粒度信息", ctx
		}

		if priceChangeInOutType == nil {
			return false, stcodes.StatusCodeParamError, "未选择价格力变化筛选条件", ctx
		}

		ctx = context.WithValue(ctx, consts.CtxBizInfoPriceAAInOutType, *priceChangeInOutType)
		ctx = context.WithValue(ctx, consts.CtxBizInfoPriceAAChangeName, priceChangeName)
	}

	return isOk, stCode, msg, ctx
}

// CheckProdPortraitBaseStructParams bizType先写死大盘
func CheckProdPortraitBaseStructParams(ctx context.Context, req *analysis.ProdDetailBaseRequest) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	//// 获取业务线信息
	//bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, dimensions.BizType_GrowthProductStrategy)
	//if err != nil || bizInfo == nil {
	//	logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
	//	return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	//}
	//// 校验时间选择是否越界限
	//dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, dimensions.BizType_GrowthProductStrategy)
	//if err != nil {
	//	return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String(), ctx
	//}
	//isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.StartDate, req.EndDate, bizInfo, dataInfo)
	//if !isOk {
	//	return
	//}
	// 获取业务线的维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionAllList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimMap, dimMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimColMap, dimColMap)
	return true, stCode, msg, ctx
}

// CheckInflectionInsightBaseParams 拐点洞察入参校验（写死业务线）
func CheckInflectionInsightBaseParams(ctx context.Context, productLabels []*analysis.ProductLabel) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	logs.CtxInfo(ctx, "接口请求体入参：\n %s", convert.ToJSONString(productLabels))
	if len(productLabels) == 0 {
		return false, stcodes.StatusCodeParamError, "商品标签不能为空", ctx
	}
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, dimensions.BizType_InflectionInsight)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(dimensions.BizType_InflectionInsight))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}

	// 获取业务线的维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionList(ctx, dimensions.BizType_InflectionInsight)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}

	ctx = context.WithValue(ctx, consts.CtxBizInfoDimColMapPrefix+strconv.Itoa(int(dimensions.BizType_InflectionInsight)), dimColMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoDimMapPrefix+strconv.Itoa(int(dimensions.BizType_InflectionInsight)), dimMap)

	for _, productInfo := range productLabels {
		productId, err := utils.String2Int64(productInfo.ProductId)
		if err != nil || productId < 100000000000000000 {
			logs.CtxWarn(ctx, "存在商品ID格式错误,问题商品ID为: %s", productInfo.ProductId)
			return false, stcodes.StatusCodeParamError, "存在商品ID格式错误", ctx
		}
		if productInfo.Label != 0 && productInfo.Label != 1 {
			logs.CtxWarn(ctx, "存在商品标签格式错误,问题商品ID为: %v, label为: %v", productInfo.ProductId, productInfo.Label)
			return false, stcodes.StatusCodeParamError, "存在商品标签格式错误", ctx
		}
	}

	return isOk, stCode, msg, ctx
}

func CheckGetSimilarProductBaseParams(ctx context.Context, req *analysis.GetSimilarProductRequest) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	logs.CtxInfo(ctx, "接口请求体入参：\n %s", convert.ToJSONString(req))
	if req == nil {
		return false, stcodes.StatusCodeParamError, "传入参数为空", ctx
	}
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BaseReq.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}
	// 获取业务线的维度信息(写死业务线，因为相似品洞察可能请求相似品池， 所以需要获取所有维度信息)
	dimList, err := new(dao.DimensionListDao).GetDimensionAllList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}

	ctx = context.WithValue(ctx, consts.CtxBizInfoDimColMapPrefix+strconv.Itoa(int(req.BaseReq.BizType)), dimColMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoDimMapPrefix+strconv.Itoa(int(req.BaseReq.BizType)), dimMap)

	// 校验时间选择是否越界限
	if len(req.BaseReq.StartDate) == 0 || len(req.BaseReq.EndDate) == 0 {
		return false, stcodes.StatusCodeParamError, "未配置选择时间范围信息", ctx
	}
	dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, req.BaseReq.BizType)
	if err != nil {
		return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String(), ctx
	}
	isOk, stCode, msg = checkDateTypeRange(ctx, req.BaseReq.StartDate, req.BaseReq.EndDate, bizInfo, dataInfo, 0)
	if !isOk {
		return
	}

	if len(req.SeedProdIds) == 0 && len(req.SeedPoolIds) == 0 {
		return false, stcodes.StatusCodeParamError, "种子商品查询失败，请录入种子商品ID或种子商品池ID", ctx
	}
	//if len(req.SimilarProdIds) == 0 && len(req.SimilarPoolIds) == 0 {
	//	return false, stcodes.StatusCodeParamError, "相似商品查询失败，请录入相似商品ID或相似商品池ID", ctx
	//}

	if len(req.BaseReq.Dimensions) > 0 || len(req.SeedFilterDimensions) > 0 || len(req.SimilarFilterDimensions) > 0 {
		selectDimensions := make([]*dimensions.SelectedDimensionInfo, 0)
		selectDimensions = append(selectDimensions, req.BaseReq.Dimensions...)
		selectDimensions = append(selectDimensions, req.SeedFilterDimensions...)
		selectDimensions = append(selectDimensions, req.SimilarFilterDimensions...)
		for _, reqDim := range selectDimensions {
			haveUse := true
			isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim, dimMap, false)
			if !isOk {
				return
			}
			if haveUse && reqDim.Id == consts.IsRcmdPoolProdDim {
				ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, []consts.DateType{consts.DateType_DAY})
			}
		}
	}

	return isOk, stCode, msg, ctx
}

// CheckBigDayOptimizeParams 校验通用取数的参数与权限问题
func CheckBigDayOptimizeParams(ctx context.Context, req *dimensions.ProductAnalysisBaseStruct) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	logs.CtxInfo(ctx, "接口请求体入参：\n %s", convert.ToJSONString(req))
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	if req == nil {
		return false, stcodes.StatusCodeParamError, "传入参数为空", ctx
	}

	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}
	ctx = context.WithValue(ctx, consts.CtxBizMetaInfo, bizInfo)
	// 获取业务线的维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionAllList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimMap, dimMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimColMap, dimColMap)

	// 判断比较类型
	if req.CompareType != nil && *req.CompareType == dimensions.CompareType_MarketingPromotionGrowthLibraCompare {
		// 等于实验组对比类型时
		req.CompareStartDate = req.StartDate
		req.CompareEndDate = req.EndDate
	}

	if len(req.StartDate) == 0 || len(req.EndDate) == 0 || len(req.CompareStartDate) == 0 || len(req.CompareEndDate) == 0 {
		return false, stcodes.StatusCodeParamError, "未配置选择时间范围信息", ctx
	}

	//判断是否有该业务线的权限
	if !env.IsBoe() && len(bizInfo.UserDimensionCode) > 0 {
		userDimensionMap, err := utils.GetUserDimensionMap(ctx)
		if err != nil {
			return false, stcodes.StatusCodeDefaultError, "获取数据权限失败", ctx
		}
		if !utils.CheckUserDimension(userDimensionMap, bizInfo.UserDimensionCode) {
			return false, stcodes.StatusUserAuthError, "无该业务线数据权限", ctx
		}
	}

	var templateFlag bool
	// 模版不需要校验时间和指标阈值
	if _, ok := ctx.Value(consts.CtxTemplateFlag).(string); ok {
		templateFlag = true
		return
	}

	// 判断指标信息
	if len(req.TargetMetaList) == 0 {
		req.TargetMetaList = dimension_service.GetDefaultTargetMetaList(ctx, req.BizType)
	} else if !dimension_service.CheckTargetMetaListValid(ctx, req.BizType, req.TargetMetaList) {
		logs.CtxWarn(ctx, "CheckTargetMetaListValid 传入指标列表无权限, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusUserAuthError, "传入指标列表无权限", ctx
	}

	// 若该业务线有必选项，则填充
	if len(bizInfo.RequiredDimInfo) > 0 && !isEditable(bizInfo.RequiredDimInfo) {
		if req.Dimensions == nil {
			req.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		}
		req.Dimensions = append(req.Dimensions, bizInfo.RequiredDimInfo...)
	}
	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)

	if !templateFlag {
		// 校验时间选择是否越界限
		dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, req.BizType)
		if err != nil {
			logs.CtxError(ctx, "获取os最新时间失败, err = %v+", err)
			return false, stcodes.StatusCodeDefaultError, "获取os最新时间失败", ctx
		}
		isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.StartDate, req.EndDate, bizInfo, dataInfo)
		if !isOk {
			logs.CtxWarn(ctx, "当前周期校验时间失败，msg=%s", msg)
			return
		}

		isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.CompareStartDate, req.CompareEndDate, bizInfo, dataInfo)
		if !isOk {
			logs.CtxWarn(ctx, "对比周期校验时间失败，msg=%s", msg)
			return
		}
	}

	// 校验枚举数据类型与枚举传入的参数是否匹配
	if len(req.Dimensions) > 0 || len(req.GroupAttrs) > 0 {
		if len(req.Dimensions) > 0 {
			for _, reqDim := range req.Dimensions {
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim, dimMap, false)
				if !isOk {
					return
				}
				if haveUse && reqDim.Id == consts.IsRcmdPoolProdDim {
					ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, []consts.DateType{consts.DateType_DAY})
				}
			}
		}

		if len(req.GroupAttrs) > 0 {
			for _, reqDim := range req.GroupAttrs {
				if reqDim == nil {
					continue
				}
				if reqDim.DimInfo != nil {
					reqDim.DimInfo.IsGroup = true
				}
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim.DimInfo, dimMap, true)
				if !isOk {
					return
				}
				if haveUse && reqDim != nil && reqDim.DimInfo != nil && (reqDim.DimInfo.AttrType != dimensions.DimensionAttributeType_Product ||
					reqDim.DimInfo.Id == consts.IsNewPayCntDim || reqDim.DimInfo.Id == consts.IsRecallPayCntDim) {
					//useProdTable = false
				}
			}
		}
	}

	if len(req.ThresholdAttrs) > 0 && !templateFlag {
		thresholdType := req.ThresholdAttrs[0].Type
		for _, t := range req.ThresholdAttrs {
			if thresholdType != t.Type {
				return false, stcodes.StatusCodeParamError, "所选的指标阈值类型存在不一致", ctx
			}

			switch t.Type {
			case dimensions.ThresholdType_TOP_THRESHOLD:
				if t.TopN == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if *t.TopN < 0 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
				if t.TopN == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if *t.TopN < 0 || *t.TopN >= 100 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			case dimensions.ThresholdType_ACC_THRESHOLD:
				if t.AccThreshold == nil {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
				}
				if t.AccThreshold.Threshold < 0 {
					return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
				}
			default:
				return false, stcodes.StatusCodeParamError, "所选的指标阈值类型不存在", ctx
			}
		}
	}
	return isOk, stCode, msg, ctx
}
