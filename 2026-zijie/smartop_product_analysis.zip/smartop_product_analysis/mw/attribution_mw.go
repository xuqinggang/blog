package mw

import (
	"code.byted.org/ecom/smartop_product_analysis/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis/biz/service/dimension_service"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/time_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/analysis"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"context"
	"fmt"
)

// CheckAttributionStreamParams 校验通用取数的参数与权限问题，用于流式接口，由于agw流式协议转换ctx里面拿不到橙蕉的用户信息，所以需要在接口内部获取
func CheckAttributionStreamParams(ctx context.Context, req *analysis.AttributionCommonBaseStruct, employeeId *string) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	logs.CtxInfo(ctx, "接口请求体入参：\n %s", convert.ToJSONString(req))
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	if req == nil {
		return false, stcodes.StatusCodeParamError, "传入参数为空", ctx
	}

	// 校验同比和传入的日期是否符合规范
	if req.SyncType != nil {
		if (time_utils.DateDiffAbs(req.StartDate, req.EndDate)+1) > 7 && *req.SyncType == analysis.SyncType_Week {
			return false, stcodes.StatusCodeParamError, "所选时间大于7天时不支持查看周同比", ctx
		}
		if (time_utils.DateDiffAbs(req.StartDate, req.EndDate)+1) > 30 && *req.SyncType != analysis.SyncType_NotNeed {
			return false, stcodes.StatusCodeParamError, "所选时间大于30天时不支持查看同比", ctx
		}
	}
	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}

	// 判断是否有该异动归因分析对象的权限
	if !env.IsBoe() && len(bizInfo.UserDimensionCode) > 0 {
		userDimensionMap, err := utils.GetStreamUserDimensionMap(ctx, employeeId)
		if err != nil {
			return false, stcodes.StatusCodeDefaultError, "获取数据权限失败", ctx
		}
		if !utils.CheckUserDimension(userDimensionMap, bizInfo.UserDimensionCode) {
			return false, stcodes.StatusUserAuthError, "无该业务线数据权限", ctx
		}
	}

	// 衍生业务线和分析对象转成真实业务线和分析对象
	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)
	if req.ObjectBizType != nil {
		bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, *req.ObjectBizType)
		if err != nil || bizInfo == nil {
			logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
			return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
		}
		bizType := biz_utils.GetAnalysisBizType(*req.ObjectBizType, bizInfo.DependBizID)
		req.ObjectBizType = &bizType
	}

	// 获取业务线的维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionAllList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimMap, dimMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimColMap, dimColMap)

	// 判断是否有该业务线的权限
	//if !env.IsBoe() {
	//	userDimensionMap, err := utils.GetUserDimensionMap(ctx)
	//	if err != nil {
	//		return false, stcodes.StatusCodeDefaultError, "获取数据权限失败", ctx
	//	}
	//	if !utils.CheckUserDimension(userDimensionMap, bizInfo.UserDimensionCode) {
	//		return false, stcodes.StatusUserAuthError, "无该业务线数据权限", ctx
	//	}
	//}

	// 若该业务线有必选项，则填充
	if len(bizInfo.RequiredDimInfo) > 0 {
		if req.Dimensions == nil {
			req.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		}
		req.Dimensions = append(req.Dimensions, bizInfo.RequiredDimInfo...)
	}

	// 校验时间选择是否越界限
	dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, dimensions.BizType_AttributionCore)
	if err != nil {
		return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String(), ctx
	}
	isOk, stCode, msg = checkAttributionDate(ctx, req.StartDate, req.EndDate, bizInfo, dataInfo)
	if !isOk {
		return
	}

	isOk, stCode, msg = checkAttributionDate(ctx, req.CompareStartDate, req.CompareEndDate, bizInfo, dataInfo)
	if !isOk {
		return
	}

	// 校验枚举数据类型与枚举传入的参数是否匹配
	if len(req.Dimensions) > 0 || len(req.GroupAttrs) > 0 {
		if len(req.Dimensions) > 0 {
			for _, reqDim := range req.Dimensions {
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim, dimMap, false)
				if !isOk {
					return
				}
				if haveUse && reqDim.Id == consts.IsRcmdPoolProdDim {
					ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, []consts.DateType{consts.DateType_DAY})
				}
			}
		}

		if len(req.GroupAttrs) > 0 {
			for _, reqDim := range req.GroupAttrs {
				if reqDim == nil {
					continue
				}
				if reqDim.DimInfo != nil {
					reqDim.DimInfo.IsGroup = true
				}
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim.DimInfo, dimMap, true)
				if !isOk {
					return
				}
				if haveUse && reqDim != nil && reqDim.DimInfo != nil && (reqDim.DimInfo.AttrType != dimensions.DimensionAttributeType_Product ||
					reqDim.DimInfo.Id == consts.IsNewPayCntDim || reqDim.DimInfo.Id == consts.IsRecallPayCntDim) {
					//useProdTable = false
				}
			}
		}
	}
	return isOk, stCode, msg, ctx
}

// CheckAttributionStructParams 校验通用取数的参数与权限问题
func CheckAttributionStructParams(ctx context.Context, req *analysis.AttributionCommonBaseStruct) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	logs.CtxInfo(ctx, "接口请求体入参：\n %s", convert.ToJSONString(req))
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	if req == nil {
		return false, stcodes.StatusCodeParamError, "传入参数为空", ctx
	}

	// 校验同比和传入的日期是否符合规范
	if req.SyncType != nil {
		if (time_utils.DateDiffAbs(req.StartDate, req.EndDate)+1) > 7 && *req.SyncType == analysis.SyncType_Week {
			return false, stcodes.StatusCodeParamError, "所选时间大于7天时不支持查看周同比", ctx
		}
		if (time_utils.DateDiffAbs(req.StartDate, req.EndDate)+1) > 30 && *req.SyncType != analysis.SyncType_NotNeed {
			return false, stcodes.StatusCodeParamError, "所选时间大于30天时不支持查看同比", ctx
		}
	}
	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}

	// 判断是否有该异动归因分析对象的权限
	if !env.IsBoe() && len(bizInfo.UserDimensionCode) > 0 {
		userDimensionMap, err := utils.GetUserDimensionMap(ctx)
		if err != nil {
			return false, stcodes.StatusCodeDefaultError, "获取数据权限失败", ctx
		}
		if !utils.CheckUserDimension(userDimensionMap, bizInfo.UserDimensionCode) {
			return false, stcodes.StatusUserAuthError, "无该业务线数据权限", ctx
		}
	}

	// 衍生业务线和分析对象转成真实业务线和分析对象
	req.BizType = biz_utils.GetAnalysisBizType(req.BizType, bizInfo.DependBizID)
	if req.ObjectBizType != nil {
		bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, *req.ObjectBizType)
		if err != nil || bizInfo == nil {
			logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
			return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
		}
		bizType := biz_utils.GetAnalysisBizType(*req.ObjectBizType, bizInfo.DependBizID)
		req.ObjectBizType = &bizType
	}

	// 获取业务线的维度信息
	dimList, err := new(dao.DimensionListDao).GetDimensionAllList(ctx)
	if err != nil {
		logs.CtxError(ctx, "[GetDimensionAllList]获取map失败，err=%v+", err)
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	dimMap := make(map[int64]*dao.DimensionInfo)
	dimColMap := make(map[string]*dao.DimensionInfo)
	if len(dimList) > 0 {
		for _, dim := range dimList {
			dimMap[dim.ID] = dim
			dimColMap[dim.DimColumn] = dim
		}
	}
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimMap, dimMap)
	ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimColMap, dimColMap)

	// 判断是否有该业务线的权限
	//if !env.IsBoe() {
	//	userDimensionMap, err := utils.GetUserDimensionMap(ctx)
	//	if err != nil {
	//		return false, stcodes.StatusCodeDefaultError, "获取数据权限失败", ctx
	//	}
	//	if !utils.CheckUserDimension(userDimensionMap, bizInfo.UserDimensionCode) {
	//		return false, stcodes.StatusUserAuthError, "无该业务线数据权限", ctx
	//	}
	//}

	// 若该业务线有必选项，则填充
	if len(bizInfo.RequiredDimInfo) > 0 {
		if req.Dimensions == nil {
			req.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		}
		req.Dimensions = append(req.Dimensions, bizInfo.RequiredDimInfo...)
	}

	// 校验时间选择是否越界限
	biz := dimensions.BizType_AttributionCore
	if req.ObjectBizType != nil && *req.ObjectBizType == dimensions.BizType_AttributionCoreGuessV2 {
		biz = dimensions.BizType_AttributionCoreGuessV2
	}
	dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, biz)
	if err != nil {
		return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String(), ctx
	}
	isOk, stCode, msg = checkAttributionDate(ctx, req.StartDate, req.EndDate, bizInfo, dataInfo)
	if !isOk {
		return
	}

	isOk, stCode, msg = checkAttributionDate(ctx, req.CompareStartDate, req.CompareEndDate, bizInfo, dataInfo)
	if !isOk {
		return
	}

	// 校验枚举数据类型与枚举传入的参数是否匹配
	if len(req.Dimensions) > 0 || len(req.GroupAttrs) > 0 {
		if len(req.Dimensions) > 0 {
			for _, reqDim := range req.Dimensions {
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim, dimMap, false)
				if !isOk {
					return
				}
				if haveUse && reqDim.Id == consts.IsRcmdPoolProdDim {
					ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, []consts.DateType{consts.DateType_DAY})
				}
			}
		}

		if len(req.GroupAttrs) > 0 {
			for _, reqDim := range req.GroupAttrs {
				if reqDim == nil {
					continue
				}
				if reqDim.DimInfo != nil {
					reqDim.DimInfo.IsGroup = true
				}
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim.DimInfo, dimMap, true)
				if !isOk {
					return
				}
				if haveUse && reqDim != nil && reqDim.DimInfo != nil && (reqDim.DimInfo.AttrType != dimensions.DimensionAttributeType_Product ||
					reqDim.DimInfo.Id == consts.IsNewPayCntDim || reqDim.DimInfo.Id == consts.IsRecallPayCntDim) {
					//useProdTable = false
				}
			}
		}
	}
	return isOk, stCode, msg, ctx
}

func checkAttributionDate(ctx context.Context, startDate, endDate string, bizInfo *biz_utils.BizMetaInfo, readyDateInfo *dimensions.DataReadyTime) (isOk bool, stCode stcodes.StCode, msg string) {
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty
	// 开始进行时间函数解析
	dateTypeSplitMap, err := time_utils.GetCustomTimeStrSplit(startDate, endDate, []consts.DateType{consts.DateType_DAY})
	if err != nil {
		return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String()
	}

	if len(dateTypeSplitMap) == 0 {
		return false, stcodes.StatusCodeParamError, "时间周期选择有误，请检查后重新选择"
	}

	// 校验时间周期的范围比较
	currRange := time_utils.DateDiffAbsWithFormat(startDate, endDate, consts.Fmt_Date)
	if bizInfo.SelectRangeDay < currRange {
		return false, stcodes.StatusCodeParamError, fmt.Sprintf("时间周期最大可选范围%d天", bizInfo.SelectRangeDay)
	}

	for _, dateList := range dateTypeSplitMap {
		for _, d := range dateList {
			if checkDataRange(d.EndDate, readyDateInfo) {
				return false, stcodes.StatusCodeParamError, "超出所选时间范围"
			}
		}
	}

	return
}
