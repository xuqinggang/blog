package mw

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/biz_utils"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/activity_review"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
)

// CheckBigPromotionBaseStructParams 校验大促复盘取数的参数与权限问题
func CheckBigPromotionBaseStructParams(ctx context.Context, req *activity_review.BigPromotionReviewBaseStruct) (isOk bool, stCode stcodes.StCode, msg string, outCtx context.Context) {
	outCtx = ctx
	isOk, stCode, msg = true, stcodes.StatusCodeSuccess, consts.Empty

	if req == nil {
		return false, stcodes.StatusCodeParamError, "传入参数为空", ctx
	}

	// 获取业务线信息
	bizInfo, ctx, err := biz_utils.GetBizMetaInfo(ctx, req.BizType)
	if err != nil || bizInfo == nil {
		logs.CtxWarn(ctx, "业务线未发现元信息, req = %s", convert.ToJSONString(req))
		return false, stcodes.StatusCodeParamError, "未发现该业务线", ctx
	}
	dimMap, _, err := biz_utils.GetDimMapAndColMapByBiz(ctx, req.BizType)
	if err != nil {
		return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	}
	//ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimMap, dimMap)
	//ctx = context.WithValue(ctx, consts.CtxBizInfoAllDimColMap, dimColMap)

	//supplyDimMap, supplyDimColMap, err := GetDimMap(ctx, dimensions.BizType_BigPromotionSupply)
	//if err != nil {
	//	return false, stcodes.StatusCodeParamError, "获取维度元数据映射信息失败", ctx
	//}
	//ctx = context.WithValue(ctx, consts.CtxBizInfoSupplyDimMap, supplyDimMap)
	//ctx = context.WithValue(ctx, consts.CtxBizInfoSupplyDimColMap, supplyDimColMap)
	// 判断是否有该业务线的权限
	// if !env.IsBoe() {
	// 	userDimensionMap, err := utils.GetUserDimensionMap(ctx)
	// 	if err != nil {
	// 		return false, stcodes.StatusCodeDefaultError, "获取数据权限失败", ctx
	// 	}
	// 	if !utils.CheckUserDimension(userDimensionMap, bizInfo.UserDimensionCode) {
	// 		return false, stcodes.StatusUserAuthError, "无该业务线数据权限", ctx
	// 	}
	// }

	// 判断指标信息
	//if len(req.TargetMetaList) == 0 {
	//	req.TargetMetaList = dimension_service.GetDefaultTargetMetaList(ctx, req.BizType)
	//} else if !dimension_service.CheckTargetMetaListValid(ctx, req.BizType, req.TargetMetaList) {
	//	logs.CtxWarn(ctx, "CheckTargetMetaListValid 传入指标列表无权限, req = %s", convert.ToJSONString(req))
	//	return false, stcodes.StatusUserAuthError, "传入指标列表无权限", ctx
	//}

	// 若该业务线有必选项，则填充
	if len(bizInfo.RequiredDimInfo) > 0 {
		if req.Dimensions == nil {
			req.Dimensions = make([]*dimensions.SelectedDimensionInfo, 0)
		}
		req.Dimensions = append(req.Dimensions, bizInfo.RequiredDimInfo...)
	}

	// 校验时间选择是否越界限
	//dataInfo, err := (&dimension_service.DimensionService{}).GetReadyTime(ctx, req.BizType)
	//if err != nil {
	//	return false, stcodes.StatusCodeDefaultError, stcodes.StatusCodeDefaultError.String(), ctx
	//}
	//isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.StartDate, req.EndDate, bizInfo, dataInfo)
	//if !isOk {
	//	return
	//}
	//if len(req.CompareStartDate) > 0 && len(req.CompareEndDate) > 0 {
	//	isOk, stCode, msg = checkCustomWithDaysTypeDate(ctx, req.CompareStartDate, req.CompareEndDate, bizInfo, dataInfo)
	//	if !isOk {
	//		return
	//	}
	//}

	// 校验枚举数据类型与枚举传入的参数是否匹配
	if len(req.Dimensions) > 0 || len(req.GroupAttrs) > 0 {
		if len(req.Dimensions) > 0 {
			for _, reqDim := range req.Dimensions {
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim, dimMap, false)
				if !isOk {
					return
				}
				if haveUse && reqDim.Id == consts.IsRcmdPoolProdDim {
					ctx = context.WithValue(ctx, consts.CtxBizInfoDaysTypeList, []consts.DateType{consts.DateType_DAY})
				}
			}
		}

		if len(req.GroupAttrs) > 0 {
			for _, reqDim := range req.GroupAttrs {
				if reqDim == nil {
					continue
				}
				if reqDim.DimInfo != nil {
					reqDim.DimInfo.IsGroup = true
				}
				haveUse := true
				isOk, stCode, msg, haveUse = checkDimInfo(ctx, reqDim.DimInfo, dimMap, true)
				if !isOk {
					return
				}
				if haveUse && reqDim.DimInfo != nil && (reqDim.DimInfo.AttrType != dimensions.DimensionAttributeType_Product ||
					reqDim.DimInfo.Id == consts.IsNewPayCntDim || reqDim.DimInfo.Id == consts.IsRecallPayCntDim) {
					//useProdTable = false
				}
			}
		}
	}

	//if len(req.ThresholdAttrs) > 0 {
	//	thresholdType := req.ThresholdAttrs[0].Type
	//	for _, t := range req.ThresholdAttrs {
	//		if thresholdType != t.Type {
	//			return false, stcodes.StatusCodeParamError, "所选的指标阈值类型存在不一致", ctx
	//		}
	//
	//		switch t.Type {
	//		case dimensions.ThresholdType_TOP_THRESHOLD:
	//			if t.TopN == nil {
	//				return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
	//			}
	//			if *t.TopN < 0 {
	//				return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
	//			}
	//		case dimensions.ThresholdType_CONTRIBUTION_THRESHOLD:
	//			if t.TopN == nil {
	//				return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
	//			}
	//			if *t.TopN < 0 || *t.TopN >= 100 {
	//				return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
	//			}
	//		case dimensions.ThresholdType_ACC_THRESHOLD:
	//			if t.AccThreshold == nil {
	//				return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件为空", ctx
	//			}
	//			if t.AccThreshold.Threshold < 0 {
	//				return false, stcodes.StatusCodeParamError, "所选的指标阈值的限制条件不符合规范", ctx
	//			}
	//		}
	//	}
	//}
	return isOk, stCode, msg, ctx
}

//func GetDimMap(ctx context.Context, bizType dimensions.BizType) (map[int64]*dao.DimensionInfo, map[string]*dao.DimensionInfo, error) {
//	dimensionListDao := new(dao.DimensionListDao)
//	dimList, err := dimensionListDao.GetDimensionList(ctx, bizType)
//
//	if err != nil {
//		logs.CtxError(ctx, "[GetDimensionList]获取map失败，err=%v+", err)
//		return nil, nil, errors.New("获取维度元数据映射信息失败")
//	}
//	dimMap := make(map[int64]*dao.DimensionInfo)
//	dimColMap := make(map[string]*dao.DimensionInfo)
//	if len(dimList) > 0 {
//		for _, dim := range dimList {
//			dimMap[dim.ID] = dim
//			dimColMap[dim.DimColumn] = dim
//		}
//	}
//	return dimMap, dimColMap, nil
//}
