PRODUCT="ecom"
SUBSYSTEM="smartop"
MODULE="product_analysis"
APP_TYPE="binary"
