package dim_manage_service

import (
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/dim_manage"
	"code.byted.org/temai/go_lib/convert"
	"fmt"
	"testing"
)

func Test_compareStructs(t *testing.T) {
	// 示例对象
	dimInfo := dim_manage.DimensionMetaInfo{
		Id:                     "1",
		ShowName:               "Nam11e1",
		ShowType:               "Type1",
		EnumType:               "Enum1",
		EnumDataType:           "DataType1",
		DimColumn:              "Column1",
		DimExpr:                "Expr1",
		DynamicFuncName:        "Func1",
		IsMultiDim:             1,
		IsProdIdAttr:           0,
		ProcessType:            "Process1",
		DimensionCategory:      "Category1",
		DimensionGroup:         "Group1",
		DimensionGroupOrder:    1,
		DimensionGroupDimOrder: convert.ToInt64Ptr(2),
		BizList: []string{"1",
			"2",
			"20001",
			"20002",
			"20003",
			"30001",
			"10002",
			"10003",
			"10004",
			"10005",
			"10001",
			"10006",
			"10007",
			"50000",
			"10008",
		},
		DefaultShowBizList: []string{},
		Values: []*dim_manage.EnumElement{
			{Code: "Code1", Name: "Name1", IsDefaultShow: true, TagRank: 1},
		},
	}

	reqDimInfo := dim_manage.DimensionMetaInfo{
		Id:                     "1",
		ShowName:               "Nam11e1",
		ShowType:               "Type1",
		EnumType:               "Enum1",
		EnumDataType:           "DataType1",
		DimColumn:              "Column1",
		DimExpr:                "Expr1",
		DynamicFuncName:        "Func1",
		IsMultiDim:             1,
		IsProdIdAttr:           0,
		ProcessType:            "Process1",
		DimensionCategory:      "Category1",
		DimensionGroup:         "Group1",
		DimensionGroupOrder:    1,
		DimensionGroupDimOrder: convert.ToInt64Ptr(2),
		BizList: []string{"1",
			"2",
			"20001",
			"20002",
			"20003",
			"30001",
			"10002",
			"10003",
			"10004",
			"10005",
			"10001",
			"10006",
			"10007",
			"50000",
			"10008",
			"10021"},
		DefaultShowBizList: nil,
		Values: []*dim_manage.EnumElement{
			{Code: "Code1", Name: "Name1", IsDefaultShow: true, TagRank: 1},
		},
	}

	similarityScore := compareStructs(dimInfo, reqDimInfo)
	fmt.Printf("Similarity Score: %.2f%%\n", similarityScore*100)
}
