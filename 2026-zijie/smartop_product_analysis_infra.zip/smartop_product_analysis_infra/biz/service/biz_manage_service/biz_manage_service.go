package biz_manage_service

import (
	"context"
	"errors"
	"fmt"
	"reflect"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/biz_manage"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/meta_info"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"gorm.io/gorm"
)

type IBizManageService interface {
	GetInfraBizList(ctx context.Context, req *biz_manage.GetInfraBizListRequest) ([]*biz_manage.BizMetaInfo, error)
	GetInfraBizDetail(ctx context.Context, req *biz_manage.GetInfraBizDetailRequest) (*biz_manage.BizMetaInfo, error)
	CreateOrUpdateInfraBiz(ctx context.Context, req *biz_manage.CreateOrUpdateInfraBizRequest) (string, error)
	GetEffectModuleMetaList(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) ([]string, error)
}

type BizManageService struct {
	BizListDao dao.IBizListDao
}

func (d *BizManageService) GetInfraBizDetail(ctx context.Context, req *biz_manage.GetInfraBizDetailRequest) (*biz_manage.BizMetaInfo, error) {
	bizID := convert.ToInt64(req.BizId)
	bizInfo, err := d.BizListDao.GetBizById(ctx, req.GetEnvType(), bizID)
	if err != nil || bizInfo == nil {
		return nil, err
	}

	bizMeta := &biz_manage.BizMetaInfo{
		Id:                convert.ToString(bizInfo.ID),
		BizName:           bizInfo.BizName,
		MaxRangeDay:       bizInfo.MaxRangeDay,
		DateRangeInfo:     bizInfo.DateRangeInfo,
		OsTableName:       bizInfo.OsTableName,
		LogicTableList:    bizInfo.LogicTableList,
		OsApiId:           bizInfo.OsApiId,
		OsTableId:         bizInfo.OsTableId,
		ThresholdAttrMeta: bizInfo.ThresholdAttrMeta,
		DefaultGroupAttrs: bizInfo.DefaultGroupAttrs,
		DaysTypeList:      bizInfo.DaysTypeList,
		UserDimensionCode: bizInfo.UserDimensionCode,
		RequiredDimInfo:   bizInfo.RequiredDimInfo,
		EffectModule:      bizInfo.EffectModule,
		DisplayOrder:      bizInfo.DisplayOrder,
		MultiDimApiId:     bizInfo.MultiDimApiId,
		TargetCardApiId:   bizInfo.TargetCardApiId,
		ProdListApiId:     bizInfo.ProdListApiId,
		TargetCardUvApiId: bizInfo.TargetCardUvApiId,
		ProdDetailExportType: bizInfo.ProdDetailExportType,
		ProdPortraitDims: bizInfo.ProdPortraitDims,
		ProdPortraitPieGraphDims: bizInfo.ProdPortraitPieGraphDims,
		ConclusionTargetMap: bizInfo.ConclusionTargetMap,
		HiddenModule:      bizInfo.HiddenModule,
		DefaultFunnelMeta: bizInfo.DefaultFunnelMeta,
		DependBizId:       convert.ToString(bizInfo.DependBizId),
		DataDelayDay:      bizInfo.DataDelayDay,
		// CreateTime:        convert.ToString(bizInfo.CreateTime),
		// UpdateTime:        convert.ToString(bizInfo.UpdateTime),
		UpdateUser:        bizInfo.UpdateUser,
		IsDelete:          bizInfo.IsDelete,
	}
	return bizMeta, nil
}
func (d *BizManageService) GetInfraBizList(ctx context.Context, req *biz_manage.GetInfraBizListRequest) ([]*biz_manage.BizMetaInfo, error) {
	bizList, err := d.BizListDao.GetBizListByBiz(ctx, req.GetEnvType(), req.BizType)
	if err != nil {
		return nil, err
	}

	ret := make([]*biz_manage.BizMetaInfo, 0)
	for _, item := range bizList {
		bizMeta := &biz_manage.BizMetaInfo{
			Id:                convert.ToString(item.ID),
			BizName:           item.BizName,
			MaxRangeDay:       item.MaxRangeDay,
			DateRangeInfo:     item.DateRangeInfo,
			OsTableName:       item.OsTableName,
			LogicTableList:    item.LogicTableList,
			OsApiId:           item.OsApiId,
			OsTableId:         item.OsTableId,
			ThresholdAttrMeta: item.ThresholdAttrMeta,
			DefaultGroupAttrs: item.DefaultGroupAttrs,
			DaysTypeList:      item.DaysTypeList,
			UserDimensionCode: item.UserDimensionCode,
			RequiredDimInfo:   item.RequiredDimInfo,
			EffectModule:      item.EffectModule,
			DisplayOrder:      item.DisplayOrder,
			MultiDimApiId:     item.MultiDimApiId,
			TargetCardApiId:   item.TargetCardApiId,
			ProdListApiId:     item.ProdListApiId,
			TargetCardUvApiId: item.TargetCardUvApiId,
			ProdDetailExportType: item.ProdDetailExportType,
			ProdPortraitDims: item.ProdPortraitDims,
			ProdPortraitPieGraphDims: item.ProdPortraitPieGraphDims,
			ConclusionTargetMap: item.ConclusionTargetMap,
			HiddenModule:      item.HiddenModule,
			DefaultFunnelMeta: item.DefaultFunnelMeta,
			DependBizId:       convert.ToString(item.DependBizId),
			DataDelayDay:      item.DataDelayDay,
			CreateTime:        convert.ToString(item.CreateTime),
			UpdateTime:        convert.ToString(item.UpdateTime),
			UpdateUser:        item.UpdateUser,
			IsDelete:          item.IsDelete,
		}

		ret = append(ret, bizMeta)
	}

	return ret, nil
}

func (d *BizManageService) CreateOrUpdateInfraBiz(ctx context.Context, req *biz_manage.CreateOrUpdateInfraBizRequest) (string, error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return consts.Empty, err
	}

	bizInfo, err := d.GetInfraBizDetail(ctx, &biz_manage.GetInfraBizDetailRequest{
		BizId:   req.BizInfo.Id,
		EnvType: req.EnvType,
	})
	if err != nil {
		return consts.Empty, err
	}

	// 创建事务
	tx := &gorm.DB{}
	if req.EnvType == base.EnvType_PPE {
		tx = mysql.PpeDB(ctx).Begin()
	} else {
		tx = mysql.DB(ctx).Begin()
	}
	if tx.Error != nil {
		logs.CtxError(ctx, "[SubmitDoradoTask]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return consts.Empty, errors.New("获取数据库的事务失败")
	}

	if bizInfo != nil {
		//logs.CtxInfo(ctx, "debug dimInfo: %s", convert.ToJSONString(dimInfo))
		//logs.CtxInfo(ctx, "debug req.DimInfo: %s", convert.ToJSONString(req.DimInfo))

		// 比较dimInfo 和 req.DimInfo 的diff程度
		similarityScore := compareStructs(bizInfo, req.BizInfo)

		//logs.CtxInfo(ctx, "debug Similarity Score: %s", convert.ToString(similarityScore))
		if similarityScore <= 0.8 {
			logs.CtxError(ctx, "Similarity Score: %s", convert.ToString(similarityScore))
			return consts.Empty, errors.New("改业务线修改的信息与已存在的gap差异大于20%，不允许修改")
		}

		// // 记录旧的维度信息
		// err = d.OperationLogDao.InsertDimensionInfo(ctx, tx, &dao.OperationLogInfo{
		// 	OperationType: "update_dimension",
		// 	OperationInfo: convert.ToJSONString(dimInfo),
		// 	Operator:      email,
		// })
		// if err != nil {
		// 	tx.Rollback()
		// 	logs.CtxError(ctx, "OperationLogDao.InsertDimensionInfo Error: %s", err.Error())
		// 	return consts.Empty, err
		// }

		// 更新业务线信息
		err = d.BizListDao.UpdateBizInfo(ctx, tx, req.BizInfo, email)
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "DimensionListDao.UpdateDimensionInfo Error: %s", err.Error())
			return consts.Empty, err
		}
	} else {
		err = d.BizListDao.InsertBizInfo(ctx, tx, req.BizInfo, email)
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "BizListDao.InsertBizInfo Error: %s", err.Error())
			return consts.Empty, err
		}
	}

	// // 更新维度关联的业务线信息
	// err = d.DimensionListDao.UpdateDimensionBizInfo(ctx, tx, req.DimInfo)
	// if err != nil {
	// 	tx.Rollback()
	// 	logs.CtxError(ctx, "DimensionListDao.UpdateDimensionBizInfo Error: %s", err.Error())
	// 	return consts.Empty, err
	// }

	// 插入维度枚举值信息
	// err = d.DimensionEnumDao.InsertDimensionEnum(ctx, tx, req.DimInfo)
	// if err != nil {
	// 	tx.Rollback()
	// 	logs.CtxError(ctx, "DimensionEnumDao.InsertDimensionEnum Error: %s", err.Error())
	// 	return consts.Empty, err
	// }

	tx.Commit()
	return req.BizInfo.Id, nil
}

func (d *BizManageService) GetInfraLogicTableListArr(ctx context.Context, req *biz_manage.GetInfraBizListRequest) ([]string, error) {
	logicTableListArr, err := d.BizListDao.GetLogicTableListArr(ctx, req.GetEnvType(), req.BizType)
	if err != nil {
		return nil, err
	}

	ret := make([][]string, 0)
	for _, item := range logicTableListArr {
		ret = append(ret, item.LogicTableList)
	}

	return FlattenAndRemoveDuplicatesGeneric(ret), nil
}

func (d *BizManageService) GetEffectModuleMetaList(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) ([]string, error) {
	effectModuleList, err := d.BizListDao.GetEffectModuleMetaList(ctx, req.GetEnvType())
	if err != nil {
		return nil, err
	}
	return effectModuleList, nil
}

func FlattenAndRemoveDuplicatesGeneric[T comparable](matrix [][]T) []T {
    var flatSlice []T
    for _, row := range matrix {
        flatSlice = append(flatSlice, row...)
    }

    seen := make(map[T]bool)
    var result []T
    for _, item := range flatSlice {
        if !seen[item] {
            result = append(result, item)
            seen[item] = true
        }
    }
    return result
}

func compareStructs(struct1, struct2 interface{}) float64 {
	v1 := reflect.ValueOf(struct1)
	v2 := reflect.ValueOf(struct2)

	if v1.Type() != v2.Type() {
		return 0.0
	}

	totalFields := 0
	matchingFields := 0

	if v1.Kind() == reflect.Ptr {
		v1 = v1.Elem()
	}

	if v2.Kind() == reflect.Ptr {
		v2 = v2.Elem()
	}

	for i := 0; i < v1.NumField(); i++ {
		field1 := v1.Field(i)
		field2 := v2.Field(i)

		if field1.Kind() == reflect.Struct {
			matchingFields += int(compareStructs(field1.Interface(), field2.Interface()) * float64(field1.NumField()))
			totalFields += field1.NumField()
		} else if field1.Kind() == reflect.Slice {
			sliceMatchingFields, sliceLen := matchSlices(field1, field2)
			matchingFields += sliceMatchingFields
			totalFields += sliceLen
		} else {
			if reflect.DeepEqual(field1.Interface(), field2.Interface()) {
				matchingFields++
			}
			totalFields++
		}
	}

	return float64(matchingFields) / float64(totalFields)
}
func matchSlices(slice1, slice2 reflect.Value) (int, int) {
	matchingElements := 0
	for i := 0; i < slice1.Len(); i++ {
		for j := 0; j < slice2.Len(); j++ {
			if reflect.DeepEqual(slice1.Index(i).Interface(), slice2.Index(j).Interface()) {
				matchingElements++
				break
			}
		}
	}
	fmt.Printf("matchingElements: %d \n", matchingElements)
	fmt.Printf("maxLen: %d, %d \n", slice1.Len(), slice2.Len())
	return matchingElements, utils.If(slice1.Len() > slice2.Len(), slice1.Len(), slice2.Len())
}