package dao

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/dim_manage"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"gorm.io/gorm"
)

type IDimensionListDao interface {
	GetDimensionById(ctx context.Context, envType base.EnvType, dimID int64) (*DimensionInfo, error)
	GetDimensionListByBiz(ctx context.Context, envType base.EnvType, bizType *string) (ret []*DimensionInfo, err error)
	GetBizListByDimID(ctx context.Context, envType base.EnvType, ids ...int64) (bizListMap map[int64][]string, defaultShowBizListMap map[int64][]string, err error)
	GetBizList(ctx context.Context, envType base.EnvType) ([]*base.ElementValue, error)
	GetMaxDimID(ctx context.Context, envType base.EnvType) (string, error)
	InsertDimensionInfo(ctx context.Context, tx *gorm.DB, dimInfo *dim_manage.DimensionMetaInfo, email string) error
	UpdateDimensionInfo(ctx context.Context, tx *gorm.DB, dimInfo *dim_manage.DimensionMetaInfo, email string) error
	UpdateDimensionBizInfo(ctx context.Context, tx *gorm.DB, dimInfo *dim_manage.DimensionMetaInfo) error
}

type DimensionInfo struct {
	ID                int64  `json:"id"`
	ShowName          string `json:"show_name"`
	ShowType          string `json:"show_type"`
	EnumType          int64  `json:"enum_type"`
	EnumDataType      string `json:"enum_data_type"`
	ProcessType       string `json:"process_type"`
	DimColumn         string `jon:"dim_column"`
	DimExpr           string `json:"dim_expr"`
	DynamicFuncName   string `json:"dynamic_func_name"`
	IsMultiDim        int64  `json:"is_multi_dim"`
	IsProdIDAttr      int64  `json:"is_prod_id_attr"`
	DimensionCategory int64  `json:"dimension_category"`
	DimGroupInfo      string `json:"dim_group_info"`
	IsDefaultShow     int64  `json:"is_default_show"`
	UpdateUser        string `json:"update_user"`
	UpdateTime        string `json:"update_time"`
}

type DimensionListDao struct{}

func (d *DimensionListDao) GetDimensionById(ctx context.Context, envType base.EnvType, dimID int64) (*DimensionInfo, error) {
	var dimInfo *DimensionInfo

	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	err := rdsDB.Raw(`
		select id, show_name, show_type, enum_type, enum_data_type, dim_column, dim_expr, process_type, dynamic_func_name, is_multi_dim, is_prod_id_attr, dimension_category, dim_group_info, update_user, 
		       date_format(update_time, '%Y-%m-%d %H:%I:%S') as update_time
		from dimension_list 
		where id = ? and is_delete = 0
	`, dimID).Scan(&dimInfo).Error
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, dim_id=%v, err=%v", ctx, dimID, err)
		return nil, err
	}

	logs.CtxInfo(ctx, "Query GetDimensionById Succeed with params {dim_id: %v}", dimID)
	return dimInfo, nil
}

type DimBizInfo struct {
	DimID         int64 `json:"dim_id"`
	BizID         int64 `json:"biz_id"`
	IsDefaultShow int64 `json:"is_default_show"`
}

func (d *DimensionListDao) GetBizListByDimID(ctx context.Context, envType base.EnvType, ids ...int64) (bizListMap map[int64][]string, defaultShowBizListMap map[int64][]string, err error) {
	var dimBizInfo []*DimBizInfo

	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	err = rdsDB.Raw(`
		select 
		    dimension_id as dim_id,
		    biz_id,
		    is_default_show
		from biz_dimension_relation 
		where is_delete = 0 and sys_date in (select max(sys_date) from biz_dimension_relation where is_delete = 0) and dimension_id in ?
	`, ids).Scan(&dimBizInfo).Error
	if err != nil {
		logs.CtxError(ctx, "GetDimensionList ctx=%v, err=%v", ctx, err)
		return
	}

	bizListMap = make(map[int64][]string)
	defaultShowBizListMap = make(map[int64][]string)
	for _, dimInfo := range dimBizInfo {
		bizList := bizListMap[dimInfo.DimID]
		if bizList == nil {
			bizList = make([]string, 0)
		}
		bizList = append(bizList, convert.ToString(dimInfo.BizID))
		bizListMap[dimInfo.DimID] = bizList

		if dimInfo.IsDefaultShow == 1 {
			defaultShowBizList := defaultShowBizListMap[dimInfo.DimID]
			if defaultShowBizList == nil {
				defaultShowBizList = make([]string, 0)
			}
			defaultShowBizList = append(defaultShowBizList, convert.ToString(dimInfo.BizID))
			defaultShowBizListMap[dimInfo.DimID] = defaultShowBizList
		}
	}
	return
}

func (d *DimensionListDao) GetDimensionListByBiz(ctx context.Context, envType base.EnvType, bizType *string) (ret []*DimensionInfo, err error) {
	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	var dimList []*DimensionInfo
	sql := `select id, show_name, show_type, enum_type, enum_data_type, dim_column, dim_expr, process_type, dynamic_func_name, is_multi_dim, is_prod_id_attr, dimension_category, dim_group_info, update_user, 
       		date_format(update_time, '%Y-%m-%d %H:%I:%S') as update_time
		from dimension_list 
		where is_delete = 0 `
	if bizType != nil {
		sql += " and biz_type = ?"
		err = rdsDB.Raw(sql, convert.ToInt64(*bizType)).Scan(&dimList).Error
	} else {
		err = rdsDB.Raw(sql).Scan(&dimList).Error
	}
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, bizType=%v, err=%v", ctx, bizType, err)
		return nil, err
	}
	logs.CtxInfo(ctx, "Query GetDimensionById Succeed with params {bizType: %v}", bizType)
	return dimList, nil
}

func (d *DimensionListDao) GetBizList(ctx context.Context, envType base.EnvType) ([]*base.ElementValue, error) {
	var ret []*base.ElementValue

	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	err := rdsDB.Raw(`
		select  id, biz_name as name
		from dimension_biz_list 
		where is_delete = 0
	`).Scan(&ret).Error
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, err=%v", ctx, err)
		return nil, err
	}

	logs.CtxInfo(ctx, "Query GetBizList Succeed")
	return ret, nil
}

func (d *DimensionListDao) GetMaxDimID(ctx context.Context, envType base.EnvType) (string, error) {
	var ret int64

	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	err := rdsDB.Raw(`
		select max(id) + 1 as id
		from dimension_list 
		where is_delete = 0 and id < 90000
	`).Scan(&ret).Error
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, err=%v", ctx, err)
		return convert.ToString(ret), err
	}

	logs.CtxInfo(ctx, "Query GetBizList Succeed")
	return convert.ToString(ret), nil
}

func (d *DimensionListDao) InsertDimensionInfo(ctx context.Context, tx *gorm.DB, dimInfo *dim_manage.DimensionMetaInfo, email string) error {
	dimGroupInfo := dimInfo.DimensionGroup + "#" + convert.ToString(dimInfo.DimensionGroupOrder)
	if dimInfo.DimensionGroupDimOrder != nil {
		dimGroupInfo += "#" + convert.ToString(dimInfo.DimensionGroupDimOrder)
	}
	err := tx.Exec(
		`insert into dimension_list 
				set id = ?,
					show_name = ?,
					show_type = ?,
					enum_type = ?,
					enum_data_type = ?,
					dim_column = ?,
					dim_expr = ?,
					dynamic_func_name = ?,
					is_multi_dim = ?,
					is_prod_id_attr = ?,
					dimension_category = ?,
					dim_group_info = ?,
					process_type = ?,
					update_user	= ?
	`, convert.ToInt64(dimInfo.Id), dimInfo.ShowName, dimInfo.ShowType, convert.ToInt64(dimInfo.EnumType),
		dimInfo.EnumDataType, dimInfo.DimColumn, dimInfo.DimExpr, dimInfo.DynamicFuncName, dimInfo.IsMultiDim,
		dimInfo.IsProdIdAttr, convert.ToInt64(dimInfo.DimensionCategory), dimGroupInfo, dimInfo.ProcessType, email).Error
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return err
	}
	return nil
}

func (d *DimensionListDao) UpdateDimensionInfo(ctx context.Context, tx *gorm.DB, dimInfo *dim_manage.DimensionMetaInfo, email string) error {
	dimGroupInfo := dimInfo.DimensionGroup + "#" + convert.ToString(dimInfo.DimensionGroupOrder)
	if dimInfo.DimensionGroupDimOrder != nil {
		dimGroupInfo += "#" + convert.ToString(dimInfo.DimensionGroupDimOrder)
	}
	err := tx.Exec(
		`update dimension_list 
				set
					show_name = ?,
					show_type = ?,
					enum_type = ?,
					enum_data_type = ?,
					dim_column = ?,
					dim_expr = ?,
					dynamic_func_name = ?,
					is_multi_dim = ?,
					is_prod_id_attr = ?,
					dimension_category = ?,
					dim_group_info = ?,
					process_type = ?,
					update_user	= ?
			where id = ?
	`, dimInfo.ShowName, dimInfo.ShowType, convert.ToInt64(dimInfo.EnumType),
		dimInfo.EnumDataType, dimInfo.DimColumn, dimInfo.DimExpr, dimInfo.DynamicFuncName, dimInfo.IsMultiDim,
		dimInfo.IsProdIdAttr, convert.ToInt64(dimInfo.DimensionCategory), dimGroupInfo, dimInfo.ProcessType, email, convert.ToInt64(dimInfo.Id)).Error
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return err
	}
	return nil
}

func (d *DimensionListDao) UpdateDimensionBizInfo(ctx context.Context, tx *gorm.DB, dimInfo *dim_manage.DimensionMetaInfo) error {
	err := tx.Exec(`delete from biz_dimension_relation where dimension_id = ?`, convert.ToInt64(dimInfo.Id)).Error
	if err != nil {
		logs.CtxError(ctx, "[UpdateDimensionBizInfo]清理维度信息失败, err = %s", err.Error())
		return err
	}
	logs.CtxInfo(ctx, "[UpdateDimensionBizInfo]清理维度信息成功, dim_id=%v", dimInfo.Id)
	if len(dimInfo.BizList) == 0 {
		logs.CtxInfo(ctx, "[UpdateDimensionBizInfo] biz_list is nil")
		return nil
	}

	var sysDate string

	err = tx.Raw(`select max(sys_date) as sys_date from biz_dimension_relation where is_delete = 0`).Scan(&sysDate).Error
	if err != nil {
		logs.CtxError(ctx, "[UpdateDimensionBizInfo]查询最新的sys_date失败, err = %s", err.Error())
		return err
	}

	for _, bizID := range dimInfo.BizList {
		isDefaultShow := 0
		if slices.ContainsString(dimInfo.DefaultShowBizList, bizID) {
			isDefaultShow = 1
		}
		err = tx.Exec(
			`insert into biz_dimension_relation
					set dimension_id = ?,
						biz_id = ?,
						is_default_show = ?,
					    sys_date = ?
			`, convert.ToInt64(dimInfo.Id), convert.ToInt64(bizID), isDefaultShow, sysDate).Error
		if err != nil {
			logs.CtxError(ctx, "[UpdateDimensionBizInfo]插入维度关系失败, bizID = %s, dimension_id = %s, err = %s", bizID, dimInfo.Id, err.Error())
			return err
		}
	}
	logs.CtxInfo(ctx, "[UpdateDimensionBizInfo] biz_list is updated, dim_id=%v", dimInfo.Id)
	return nil
}
