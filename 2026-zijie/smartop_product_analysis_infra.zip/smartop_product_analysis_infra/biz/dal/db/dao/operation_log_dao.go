package dao

import (
	"code.byted.org/gopkg/logs"
	"context"
	"gorm.io/gorm"
)

type IOperationLogDao interface {
	InsertDimensionInfo(ctx context.Context, tx *gorm.DB, info *OperationLogInfo) error
}

type OperationLogInfo struct {
	OperationType string `json:"operation_type"`
	OperationInfo string `json:"operation_info"`
	Operator      string `json:"operator"`
}

type OperationLogDao struct{}

func (d *OperationLogDao) InsertDimensionInfo(ctx context.Context, tx *gorm.DB, info *OperationLogInfo) error {
	if info == nil {
		return nil
	}
	err := tx.Exec(
		`insert into operation_log_info
				set operation_type =?,
					operation_info =?,
					operator =?
	`, info.OperationType, info.OperationInfo, info.Operator).Error
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return err
	}
	return nil
}
