package dao

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/biz_manage"
	"code.byted.org/gopkg/logs/v2"
	"code.byted.org/temai/go_lib/convert"
	"gorm.io/gorm"
)

type IBizListDao interface {
	GetBizListByBiz(ctx context.Context, envType base.EnvType, bizType *string) (ret []*BizInfo, err error)
	GetBizById(ctx context.Context, envType base.EnvType, bizID int64) (ret *BizInfo, err error)
	GetLogicTableListArr(ctx context.Context, envType base.EnvType, bizType *string) (ret []*LogicTableListInfo, err error)
	InsertBizInfo(ctx context.Context, tx *gorm.DB, bizInfo *biz_manage.BizMetaInfo, email string) error
	UpdateBizInfo(ctx context.Context, tx *gorm.DB, bizInfo *biz_manage.BizMetaInfo, email string) error
	GetEffectModuleMetaList(ctx context.Context, envType base.EnvType) (ret []string, err error)
}

type BizInfo struct {
	ID                			 int64  `json:"id"`
	BizName           			 string `json:"biz_name"`
	MaxRangeDay              int64  `json:"max_range_day"`
	DateRangeInfo            string `json:"date_range_info"`
	OsTableName              string `json:"os_table_name"`
	LogicTableList           string `json:"logic_table_list"`
	OsApiId                  string `json:"os_api_id"`
	OsTableId                string `json:"os_table_id"`
	ThresholdAttrMeta        string `json:"threshold_attr_meta"`
	DefaultGroupAttrs        string `json:"default_group_attrs"`
	DaysTypeList             string `json:"days_type_list"`
	UserDimensionCode        string `json:"user_dimension_code"`
	RequiredDimInfo          string `json:"required_dim_info"`
	EffectModule             string `json:"effect_module"`
	DisplayOrder             int64  `json:"display_order"`
	MultiDimApiId            string `json:"multi_dim_api_id"`
	TargetCardApiId          string `json:"target_card_api_id"`
	ProdListApiId            string `json:"prod_list_api_id"`
	TargetCardUvApiId        string `json:"target_card_uv_api_id"`
	ProdDetailExportType     int64  `json:"prod_detail_export_type"`
	ProdPortraitDims         string `json:"prod_portrait_dims"`
	ProdPortraitPieGraphDims string `json:"prod_portrait_pie_graph_dims"`
	ConclusionTargetMap      string `json:"conclusion_target_map"`
	HiddenModule             string `json:"hidden_module"`
	DefaultFunnelMeta        string `json:"default_funnel_meta"`
	DependBizId              int64 `json:"depend_biz_id"`
	DataDelayDay             int64  `json:"data_delay_day"`
	CreateTime               string `json:"create_time"`
	UpdateTime               string `json:"update_time"`
	UpdateUser               string `json:"update_user"`
	IsDelete                 int64  `json:"is_delete"`
}
type LogicTableListInfo struct {
	LogicTableList []string `json:"logic_table_list"`
}

type BizListDao struct{}

func (d *BizListDao) GetBizById(ctx context.Context, envType base.EnvType, bizId int64) (*BizInfo, error) {
	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	var bizInfo *BizInfo
	sql := `select id, biz_name, max_range_day, date_range_info, os_table_name, logic_table_list, 
		os_api_id, os_table_id, threshold_attr_meta, default_group_attrs, days_type_list, user_dimension_code, required_dim_info, effect_module, display_order, multi_dim_api_id,
		target_card_api_id, target_card_overall_api_id, prod_list_api_id, target_card_uv_api_id, prod_detail_export_type, prod_portrait_dims, prod_portrait_pie_graph_dims, conclusion_target_map,
		hidden_module, default_funnel_meta, depend_biz_id, data_delay_day, date_format(create_time, '%Y-%m-%d %H:%i:%s') as create_time, date_format(update_time, '%Y-%m-%d %H:%i:%s') as update_time, update_user, is_delete 
		from dimension_biz_list 
		where id = ? and is_delete = 0 `

	err := rdsDB.Raw(sql, bizId).Scan(&bizInfo).Error

	if err != nil {
		logs.CtxError(ctx, "ctx=%v, biz_id=%v, err=%v", ctx, bizId, err)
		return nil, err
	}
	logs.CtxInfo(ctx, "Query GetBizById Succeed with params {biz_id: %v}", bizId)
	return bizInfo, nil
}
func (d *BizListDao) GetBizListByBiz(ctx context.Context, envType base.EnvType, bizType *string) (ret []*BizInfo, err error) {
	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	var bizList []*BizInfo
	sql := `select id, biz_name, max_range_day, date_range_info, os_table_name, logic_table_list, 
		os_api_id, os_table_id, threshold_attr_meta, default_group_attrs, days_type_list, user_dimension_code, required_dim_info, effect_module, display_order, multi_dim_api_id,
		target_card_api_id, target_card_overall_api_id, prod_list_api_id, target_card_uv_api_id, prod_detail_export_type, prod_portrait_dims, prod_portrait_pie_graph_dims, conclusion_target_map,
		hidden_module, default_funnel_meta, depend_biz_id, data_delay_day, date_format(create_time, '%Y-%m-%d %H:%i:%s') as create_time, date_format(update_time, '%Y-%m-%d %H:%i:%s') as update_time, update_user, is_delete 
		from dimension_biz_list 
		where is_delete = 0 `
	if bizType != nil {
		sql += " and biz_type = ?"
		err = rdsDB.Raw(sql, convert.ToInt64(*bizType)).Scan(&bizList).Error
	} else {
		err = rdsDB.Raw(sql).Scan(&bizList).Error
	}
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, bizType=%v, err=%v", ctx, bizType, err)
		return nil, err
	}
	logs.CtxInfo(ctx, "Query GetBizListByBiz Succeed with params {bizType: %v}", bizType)
	return bizList, nil
}

func (d *BizListDao) GetLogicTableListArr(ctx context.Context, envType base.EnvType, bizType *string) (ret []*LogicTableListInfo, err error) {
	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	var logicTableListArr []*LogicTableListInfo
	sql := `select logic_table_list
		from dimension_biz_list 
		where is_delete = 0 `
	if bizType != nil {
		sql += " and biz_type = ?"
		err = rdsDB.Raw(sql, convert.ToInt64(*bizType)).Scan(&logicTableListArr).Error
	} else {
		err = rdsDB.Raw(sql).Scan(&logicTableListArr).Error
	}
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, bizType=%v, err=%v", ctx, bizType, err)
		return nil, err
	}
	logs.CtxInfo(ctx, "Query GetBizListByBiz Succeed with params {bizType: %v}", bizType)
	return logicTableListArr, nil
}

func (d *BizListDao) UpdateBizInfo(ctx context.Context, tx *gorm.DB, bizInfo *biz_manage.BizMetaInfo, email string) error {
	err := tx.Exec(
		`update dimension_biz_list 
				set
					biz_name = ?,
					max_range_day = ?,
					date_range_info = ?,
					os_table_name = ?,
					logic_table_list = ?,
					os_api_id = ?,
					os_table_id = ?,
					threshold_attr_meta = ?,
					default_group_attrs = ?,
					days_type_list = ?,
					user_dimension_code = ?,
					required_dim_info = ?,
					effect_module	= ?,
					display_order = ?,
					multi_dim_api_id = ?,
					target_card_api_id = ?,
					target_card_overall_api_id = ?,
					prod_list_api_id = ?,
					target_card_uv_api_id = ?,
					prod_detail_export_type = ?,
					prod_portrait_dims = ?,
					prod_portrait_pie_graph_dims = ?,
					conclusion_target_map = ?,
					hidden_module = ?,
					default_funnel_meta	= ?,
					depend_biz_id	= ?,
					data_delay_day = ?,
					update_user = ?
			where id = ?
	`, bizInfo.BizName, bizInfo.MaxRangeDay, bizInfo.DateRangeInfo, bizInfo.OsTableName, bizInfo.LogicTableList, bizInfo.OsApiId, bizInfo.OsTableId,
	bizInfo.ThresholdAttrMeta, bizInfo.DefaultGroupAttrs, bizInfo.DaysTypeList, bizInfo.UserDimensionCode, bizInfo.RequiredDimInfo, bizInfo.EffectModule,
	bizInfo.DisplayOrder, bizInfo.MultiDimApiId, bizInfo.TargetCardApiId, bizInfo.TargetCardOverallApiId, bizInfo.ProdListApiId, bizInfo.TargetCardUvApiId,
	bizInfo.ProdDetailExportType, bizInfo.ProdPortraitDims, bizInfo.ProdPortraitPieGraphDims, bizInfo.ConclusionTargetMap, bizInfo.HiddenModule, bizInfo.DefaultFunnelMeta,
	convert.ToInt64(bizInfo.DependBizId), bizInfo.DataDelayDay, email, convert.ToInt64(bizInfo.Id)).Error
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return err
	}
	return nil
}

func (d *BizListDao) InsertBizInfo(ctx context.Context, tx *gorm.DB, bizInfo *biz_manage.BizMetaInfo, email string) error {
	err := tx.Exec(
		`insert into dimension_biz_list 
				set id = ?,
					biz_name = ?,
					max_range_day = ?,
					date_range_info = ?,
					os_table_name = ?,
					logic_table_list = ?,
					os_api_id = ?,
					os_table_id = ?,
					threshold_attr_meta = ?,
					default_group_attrs = ?,
					days_type_list = ?,
					user_dimension_code = ?,
					required_dim_info = ?,
					effect_module	= ?,
					display_order = ?,
					multi_dim_api_id = ?,
					target_card_api_id = ?,
					target_card_overall_api_id = ?,
					prod_list_api_id = ?,
					target_card_uv_api_id = ?,
					prod_detail_export_type = ?,
					prod_portrait_dims = ?,
					prod_portrait_pie_graph_dims = ?,
					conclusion_target_map = ?,
					hidden_module = ?,
					default_funnel_meta	= ?,
					depend_biz_id	= ?,
					data_delay_day = ?,
					update_user = ?
	`, convert.ToInt64(bizInfo.Id), bizInfo.BizName, bizInfo.MaxRangeDay, bizInfo.DateRangeInfo, bizInfo.OsTableName, bizInfo.LogicTableList, bizInfo.OsApiId, bizInfo.OsTableId,
	bizInfo.ThresholdAttrMeta, bizInfo.DefaultGroupAttrs, bizInfo.DaysTypeList, bizInfo.UserDimensionCode, bizInfo.RequiredDimInfo, bizInfo.EffectModule,
	bizInfo.DisplayOrder, bizInfo.MultiDimApiId, bizInfo.TargetCardApiId, bizInfo.TargetCardOverallApiId, bizInfo.ProdListApiId, bizInfo.TargetCardUvApiId,
	bizInfo.ProdDetailExportType, bizInfo.ProdPortraitDims, bizInfo.ProdPortraitPieGraphDims, bizInfo.ConclusionTargetMap, bizInfo.HiddenModule, bizInfo.DefaultFunnelMeta,
	convert.ToInt64(bizInfo.DependBizId), bizInfo.DataDelayDay, email).Error
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return err
	}
	return nil
}

func (d *BizListDao) GetEffectModuleMetaList(ctx context.Context, envType base.EnvType) (ret []string, err error) {
	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	var effectModuleList []string
	sql := `select effect_module 
		from dimension_biz_list 
		where is_delete = 0 group by effect_module`
	err = rdsDB.Raw(sql).Scan(&effectModuleList).Error
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, err=%v", ctx, err)
		return nil, err
	}
	return effectModuleList, nil
}