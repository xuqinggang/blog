package mysql

import (
	"context"
	"sync"
	"time"

	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gorm/bytedgorm"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
)

var (
	db     *gorm.DB
	dbName = "smartop_product_analysis"
	psm    = "toutiao.mysql.smartop_product_analysis"
	once   sync.Once
)

var (
	ppe_db     *gorm.DB
	ppe_dbName = "smartop_product_analysis_ppe"
	ppe_psm    = "toutiao.mysql.smartop_product_analysis_ppe"
	ppe_once   sync.Once
)

func Init() {
	once.Do(func() {
		// init
		DB, err := gorm.Open(
			bytedgorm.MySQL(psm /*数据库PSM*/, dbName /*数据库名*/).WithReadReplicas().With(func(config *bytedgorm.DBConfig) {
				config.Timeout = time.Second
				config.ReadTimeout = 3 * time.Second
				config.WriteTimeout = 3 * time.Second
			}),
			bytedgorm.WithDefaults(), bytedgorm.WithSingularTable(),
		)
		// check err
		if err != nil {
			panic(err)
		}
		db = DB
		if env.IsBoe() {
			db = db.Debug()
		}
		logs.Info("init mysql for %s success", psm)
	})

	ppe_once.Do(func() {
		// init
		DB, err := gorm.Open(
			bytedgorm.MySQL(ppe_psm /*数据库PSM*/, ppe_dbName /*数据库名*/).WithReadReplicas().With(func(config *bytedgorm.DBConfig) {
				config.Timeout = time.Second
				config.ReadTimeout = 3 * time.Second
				config.WriteTimeout = 3 * time.Second
			}),
			bytedgorm.WithDefaults(), bytedgorm.WithSingularTable(),
		)
		// check err
		if err != nil {
			panic(err)
		}
		ppe_db = DB
		if env.IsBoe() {
			ppe_db = ppe_db.Debug()
		}
		logs.Info("init mysql for %s success", psm)
	})
}

// WriteDB ...
func WriteDB(ctx context.Context) *gorm.DB {
	return db.Clauses(dbresolver.Write).WithContext(ctx)
}

// ReadDB ...
func ReadDB(ctx context.Context) *gorm.DB {
	return db.Clauses(dbresolver.Read).WithContext(ctx)
}

// Read write separation
func DB(ctx context.Context) *gorm.DB {
	return db.WithContext(ctx)
}

// Read write separation
func PpeDB(ctx context.Context) *gorm.DB {
	return ppe_db.WithContext(ctx)
}
