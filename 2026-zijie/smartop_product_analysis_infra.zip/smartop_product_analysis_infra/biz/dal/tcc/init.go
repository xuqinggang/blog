package tcc

import (
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/gopkg/tccclient"
	"sync"
)

var (
	tccClient       *tccclient.ClientV2
	ErrNonExistsKey = errors.New("key not exists")
	once            sync.Once
)

const (
	API_PSM = "ecom.smartop.product_analysis"
)

func Init() {
	config := tccclient.NewConfigV2()

	client, err := tccclient.NewClientV2(API_PSM, config)
	if err != nil {
		panic(err)
	}
	tccClient = client
}

func GetInstance() *tccclient.ClientV2 {
	if tccClient == nil {
		once.Do(func() {
			Init()
		})
	}
	return tccClient
}
