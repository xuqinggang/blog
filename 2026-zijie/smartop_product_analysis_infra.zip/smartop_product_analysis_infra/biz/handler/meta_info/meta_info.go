package meta_info

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis_infra/biz/service/biz_manage_service"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/service/dim_manage_service"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/meta_info"
)

type MetaInfoHandler struct {
	DimManageService dim_manage_service.IDimManageService
	BizManageService biz_manage_service.IBizManageService
}

var MetaInfoList = []*meta_info.GetInfraMetaInfoData{
	{meta_info.MetaType_DIM_SHOW_TYPE, []*base.ElementValue{
		{"multi_select", "复选框"},
		{"single_select", "单选框"},
		{"bool_single_select", "bool单选框"},
		{"amount_range_input", "范围输入框金额"},
		{"number_range_input", "范围输入框数值"},
		{"ratio_range_input", "范围输入框比率"},
		{"text_array_input", "文本输入框数组"},
		{"basic_info_search_input", "基础信息动态搜索框"},
		{"basic_info_search_single_input", "基础信息动态搜索单选框"},
	}},
	{meta_info.MetaType_DIM_ENUM_TYPE, []*base.ElementValue{
		{"0", "无枚举"},
		{"1", "静态枚举"},
		{"2", "动态枚举"},
	}},
	{meta_info.MetaType_DIM_ENUM_DATA_TYPE, []*base.ElementValue{
		{"string", "string"},
		{"long", "long"},
		{"double", "double"},
		{"raw", "raw"},
		{"bool", "bool"},
	}},
	{meta_info.MetaType_DIM_CATEGORY, []*base.ElementValue{
		{"1", "用户类型"},
		{"2", "商品类型"},
		{"3", "场域类型"},
		{"4", "订单类型"},
	}},
}

func (d *MetaInfoHandler) GetInfraMetaInfo(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) (resp *meta_info.GetInfraMetaInfoResponse, err error) {
	resp = &meta_info.GetInfraMetaInfoResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	resp.Data = make([]*meta_info.GetInfraMetaInfoData, 0)
	resp.Data = append(resp.Data, MetaInfoList...)

	bizList, err := d.DimManageService.GetBizList(ctx, base.EnvType_PROD)
	if err != nil {
		return nil, err
	}
	resp.Data = append(resp.Data, &meta_info.GetInfraMetaInfoData{
		MetaType: meta_info.MetaType_DIM_BIZ_TYPE,
		Enums:    bizList,
	})
	// 读取业务线数据
	return resp, nil
}

func (d *MetaInfoHandler) GetInfraBizMetaInfo(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) (resp *meta_info.GetInfraBizMetaInfoResponse, err error) {
	resp = &meta_info.GetInfraBizMetaInfoResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	dimMetaList, err := d.DimManageService.GetInfraDimensionMetaList(ctx, req)
	if err != nil {
		return nil, err
	}
	effectModuleList, err := d.BizManageService.GetEffectModuleMetaList(ctx, req)
	if err != nil {
		return nil, err
	}
	resp.Data = &meta_info.GetInfraBizMetaInfoData{
		DimensionList: dimMetaList,
		EffectModuleList: effectModuleList,
	}
	return resp, nil
}