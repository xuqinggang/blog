package dim_manage

import (
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/service/dim_manage_service"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/dim_manage"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/meta_info"
	"code.byted.org/gopkg/pkg/errors"
	"context"
)

type DimManageHandler struct {
	DimManageService dim_manage_service.IDimManageService
}

func (d *DimManageHandler) GetInfraDimensionList(ctx context.Context, req *dim_manage.GetInfraDimensionListRequest) (resp *dim_manage.GetInfraDimensionListResponse, err error) {
	resp = &dim_manage.GetInfraDimensionListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	// 补充维度列表
	data, err := d.DimManageService.GetInfraDimensionList(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimManageHandler) GetInfraDimensionDetail(ctx context.Context, req *dim_manage.GetInfraDimensionDetailRequest) (resp *dim_manage.GetInfraDimensionDetailResponse, err error) {
	resp = &dim_manage.GetInfraDimensionDetailResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	// 补充维度列表
	data, err := d.DimManageService.GetInfraDimensionDetail(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimManageHandler) GetDimensionNewestID(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) (resp *dim_manage.GetDimensionNewestIDResponse, err error) {
	resp = &dim_manage.GetDimensionNewestIDResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	// 补充维度列表
	data, err := d.DimManageService.GetDimensionNewestID(ctx)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *DimManageHandler) CreateOrUpdateInfraDimension(ctx context.Context, req *dim_manage.CreateOrUpdateInfraDimensionRequest) (resp *dim_manage.CreateOrUpdateInfraDimensionResponse, err error) {
	resp = &dim_manage.CreateOrUpdateInfraDimensionResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	// 补充维度列表
	data, err := d.DimManageService.CreateOrUpdateInfraDimension(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}
