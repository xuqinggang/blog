package biz_manage

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis_infra/biz/service/biz_manage_service"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/biz_manage"
	"code.byted.org/gopkg/pkg/errors"
)

type BizManageHandler struct {
	BizManageService biz_manage_service.IBizManageService
}

func (d *BizManageHandler) GetInfraBizList(ctx context.Context, req *biz_manage.GetInfraBizListRequest) (resp *biz_manage.GetInfraBizListResponse, err error) {
	resp = &biz_manage.GetInfraBizListResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	// 补充维度列表
	data, err := d.BizManageService.GetInfraBizList(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *BizManageHandler) GetInfraBizDetail(ctx context.Context, req *biz_manage.GetInfraBizDetailRequest) (resp *biz_manage.GetInfraBizDetailResponse, err error) {
	resp = &biz_manage.GetInfraBizDetailResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	// 补充维度列表
	data, err := d.BizManageService.GetInfraBizDetail(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}

func (d *BizManageHandler) CreateOrUpdateInfraBiz(ctx context.Context, req *biz_manage.CreateOrUpdateInfraBizRequest) (resp *biz_manage.CreateOrUpdateInfraBizResponse, err error) {
	resp = &biz_manage.CreateOrUpdateInfraBizResponse{}
	resp.SetBaseResp(base.NewBaseResp())
	if req == nil {
		return nil, errors.New("请求参数为空")
	}
	data, err := d.BizManageService.CreateOrUpdateInfraBiz(ctx, req)
	if err != nil {
		return resp, err
	}
	resp.Data = data
	return resp, nil
}