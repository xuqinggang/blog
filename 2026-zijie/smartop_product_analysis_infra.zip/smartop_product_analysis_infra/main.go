package main

import (
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/tcc"
	product_analysis_infra "code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/ecom/smartop/product_analysis_infra/smartopproductanalysisinfraservice"
	"code.byted.org/ecom/smartop_product_analysis_infra/middleware"
	"code.byted.org/kite/kitex/server"
	"log"
)

func main() {
	opts := []server.Option{
		server.WithMiddleware(middleware.CtxLog),
	}
	svr := product_analysis_infra.NewServer(new(SmartopProductAnalysisInfraServiceImpl), opts...)

	mysql.Init()
	tcc.Init()
	err := svr.Run()
	if err != nil {
		log.Println(err.Error())
	}
}
