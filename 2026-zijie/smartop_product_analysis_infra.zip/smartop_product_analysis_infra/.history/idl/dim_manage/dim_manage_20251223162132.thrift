namespace py dim_manage
namespace go dim_manage

include "../base.thrift"

struct DimensionMetaInfo {
    1: string id // 维度ID
    2: string show_name // 展示名称
    3: string show_type // 展示类型 multi_select=复选，single_select=单选，amount_range_input=金额范围输入，tree_select=级联
    4: string enum_type // 枚举类型
    5: string enum_data_type // 枚举数据类型
    6: string dim_column // 维度字段名
    7: string dim_expr // 维度字段表达式
    8: string dynamic_func_name // 动态方法名
    9: i64 is_multi_dim // 是否多维分析
    10: i64 is_prod_id_attr // 是否查看周期最后一天（商品维表数据）
    11: string dimension_category // 属性类型：人 货 场
    12: string process_type // 处理类型
    13: string update_user // 更新人
    14: string update_time // 更新时间

    21: string dimension_group // 维度分组
    22: i64 dimension_group_order // 维度分组排序
    23: optional i64 dimension_group_dim_order // 维度分组下维度的顺序

    31: list<EnumElement> values  // 枚举值

    51: list<string> default_show_biz_list // 默认展示的业务线
    52: list<string> biz_list // 归属业务线
}

// 枚举类型
enum EnumType {
    NoEnum      = 0    // 无枚举
    StaticEnum  = 1    // 静态枚举
    DynamicEnum = 2    // 动态枚举
}

// 枚举信息
struct EnumElement {
    1: string            code           // 枚举code
    2: string            name           // 枚举名称
    3: bool   is_default_show           // 该枚举是否默认选择
    4: i64    tag_rank // 排序
}

// 获取维度列表
struct GetInfraDimensionListRequest {
    1: optional string biz_type
    2: base.EnvType env_type // ppe / prod

    255: optional base.Base Base
}
struct GetInfraDimensionListResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<DimensionMetaInfo> data

    255: base.BaseResp BaseResp
}

// 获取维度详情信息
struct GetInfraDimensionDetailRequest {
    1: string dim_id
    2: base.EnvType env_type // ppe / prod

    255: optional base.Base Base
}
struct GetInfraDimensionDetailResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: DimensionMetaInfo data

    255: base.BaseResp BaseResp
}

// 新增/覆盖 维度
struct CreateOrUpdateInfraDimensionRequest {
    1: DimensionMetaInfo dim_info
    2: base.EnvType env_type // ppe / prod

    255: optional base.Base Base
}
struct CreateOrUpdateInfraDimensionResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: string data

    255: base.BaseResp BaseResp
}

struct GetDimensionNewestIDResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: string data

    255: base.BaseResp BaseResp
}