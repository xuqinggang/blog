package dim_manage_service

import (
	"context"
	"fmt"
	"reflect"
	"strings"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/dynamic_enum"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis/kitex_gen/dimensions"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/db/dao"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/dim_manage"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/meta_info"
	"code.byted.org/gopkg/lang/slices"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/pkg/errors"
	"code.byted.org/temai/go_lib/convert"
	"gorm.io/gorm"
)

type IDimManageService interface {
	GetInfraDimensionList(ctx context.Context, req *dim_manage.GetInfraDimensionListRequest) ([]*dim_manage.DimensionMetaInfo, error)
	GetInfraDimensionMetaList(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) ([]*meta_info.DimensionMetaInfo, error)
	GetInfraDimensionDetail(ctx context.Context, req *dim_manage.GetInfraDimensionDetailRequest) (*dim_manage.DimensionMetaInfo, error)
	GetBizList(ctx context.Context, envType base.EnvType) ([]*base.ElementValue, error)
	GetDimensionNewestID(ctx context.Context) (string, error)
	CreateOrUpdateInfraDimension(ctx context.Context, req *dim_manage.CreateOrUpdateInfraDimensionRequest) (string, error)
}

type DimManageService struct {
	DimensionListDao dao.IDimensionListDao
	DimensionEnumDao dao.IDimensionEnumDao
	OperationLogDao  dao.IOperationLogDao
}

func (d *DimManageService) GetBizList(ctx context.Context, envType base.EnvType) ([]*base.ElementValue, error) {
	return d.DimensionListDao.GetBizList(ctx, envType)
}

// GetInfraDimensionList 获取维度
func (d *DimManageService) GetInfraDimensionList(ctx context.Context, req *dim_manage.GetInfraDimensionListRequest) ([]*dim_manage.DimensionMetaInfo, error) {
	dimList, err := d.DimensionListDao.GetDimensionListByBiz(ctx, req.GetEnvType(), req.BizType)
	if err != nil {
		return nil, err
	}

	ret := make([]*dim_manage.DimensionMetaInfo, 0)
	ids := make([]int64, 0)
	for _, dim := range dimList {
		dimMeta := &dim_manage.DimensionMetaInfo{
			Id:                convert.ToString(dim.ID),
			ShowName:          dim.ShowName,
			ShowType:          dim.ShowType,
			EnumType:          convert.ToString(dim.EnumType),
			EnumDataType:      dim.EnumDataType,
			DimColumn:         dim.DimColumn,
			DimExpr:           dim.DimExpr,
			DynamicFuncName:   dim.DynamicFuncName,
			IsMultiDim:        dim.IsMultiDim,
			IsProdIdAttr:      dim.IsProdIDAttr,
			ProcessType:       dim.ProcessType,
			DimensionCategory: convert.ToString(dim.DimensionCategory),
			UpdateUser:        dim.UpdateUser,
			UpdateTime:        dim.UpdateTime,
		}

		dimGroupArr := strings.Split(dim.DimGroupInfo, "#")
		dimMeta.DimensionGroup = dimGroupArr[0]
		if len(dimGroupArr) > 1 {
			dimMeta.DimensionGroupOrder = convert.ToInt64(dimGroupArr[1])
		}
		if len(dimGroupArr) > 2 {
			dimMeta.DimensionGroupDimOrder = convert.ToInt64Ptr(convert.ToInt64(dimGroupArr[2]))
		}

		ids = append(ids, dim.ID)
		ret = append(ret, dimMeta)
	}

	ids = slices.DistinctInt64(ids)

	// 补充关联的业务线
	bizListMap, defaultShowBizListMap, err := d.DimensionListDao.GetBizListByDimID(ctx, req.GetEnvType(), ids...)
	for _, r := range ret {
		dimID := convert.ToInt64(r.Id)
		r.BizList = bizListMap[dimID]
		r.DefaultShowBizList = defaultShowBizListMap[dimID]
	}
	return ret, nil
}

func (d *DimManageService) GetInfraDimensionMetaList(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) ([]*meta_info.DimensionMetaInfo, error) {
	dimList, err := d.DimensionListDao.GetDimensionListByBiz(ctx, req.GetEnvType(), req.BizType)
	if err != nil {
		return nil, err
	}

	ret := make([]*meta_info.DimensionMetaInfo, 0)
	for _, dim := range dimList {
		dimMeta := &meta_info.DimensionMetaInfo{
			Id:                convert.ToString(dim.ID),
			Name:          		 dim.ShowName,
			SelectedOperator:  0,
			AttrType:          dim.DimensionCategory,
		}

		ret = append(ret, dimMeta)
	}
	return ret, nil
}
func (d *DimManageService) GetDimEnumInfoByDimInfoList(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest, dimList []*dao.DimensionInfo) ([]*dimensions.DimensionInfo, error) {
	// 存储属于静态枚举的维度ID列表
	dimStaticIds := make([]int64, 0)
	// 存储属于动态枚举，需要2次查询接口数据的维度清单
	dimDynamicList := make([]*dao.DimensionInfo, 0)
	// 遍历
	for _, dim := range dimList {
		switch dim_manage.EnumType(dim.EnumType) {
		case dim_manage.EnumType_StaticEnum:
			dimStaticIds = append(dimStaticIds, dim.ID)
		case dim_manage.EnumType_DynamicEnum:
			if !slices.ContainsString(dynamic_enum.NeedPageEnumSearchList, dim.DynamicFuncName) {
				dimDynamicList = append(dimDynamicList, dim)
			}
		default:
			continue
		}
	}

	// 存储每个维度-枚举映射关系
	dimEnumMap := make(map[int64][]*dimensions.EnumElement)

	// 计算静态枚举
	if len(dimStaticIds) > 0 {
		dimStaticEnumMap, err := d.DimensionEnumDao.GetEnumByDimIds(ctx, req.GetEnvType(), dimStaticIds...)
		if err != nil {
			return nil, err
		}
		for k, v := range dimStaticEnumMap {
			dimEnumMap[k] = v
		}
	}

	// 计算动态枚举
	if len(dimDynamicList) > 0 {
		for _, dim := range dimDynamicList {
			if len(dim.DynamicFuncName) == 0 {
				logs.CtxWarn(ctx, "该维度动态枚举未封装方法，dim=%s", convert.ToJSONString(dim))
				continue
			}
			enums, err := dynamic_enum.GetEnumByMethod(ctx, dim.DynamicFuncName)
			if err != nil {
				return nil, err
			}
			dimEnumMap[dim.ID] = enums
			// 维度允许编辑，则需全量返回枚举
			if len(enums) > 0 {
				dimEnumMap[dim.ID] = enums
			}
		}
	}

	// 封装结构体
	ret := make([]*meta_info.DimensionMetaInfo, 0)
	for _, dim := range dimList {
		tmp := &meta_info.DimensionMetaInfo{
			Id:                convert.ToString(dim.ID),
			Name:          		 dim.ShowName,
			SelectedOperator:  0,
			AttrType:          dim.DimensionCategory,
			Values:            dimEnumMap[dim.ID],
		}
		ret = append(ret, tmp)
	}
	return ret, nil
}

// GetInfraDimensionDetail 获取维度
func (d *DimManageService) GetInfraDimensionDetail(ctx context.Context, req *dim_manage.GetInfraDimensionDetailRequest) (*dim_manage.DimensionMetaInfo, error) {
	dimID := convert.ToInt64(req.DimId)
	dimensionInfo, err := d.DimensionListDao.GetDimensionById(ctx, req.GetEnvType(), dimID)
	if err != nil || dimensionInfo == nil {
		return nil, err
	}

	ret := &dim_manage.DimensionMetaInfo{
		Id:                req.DimId,
		ShowName:          dimensionInfo.ShowName,
		ShowType:          dimensionInfo.ShowType,
		EnumType:          convert.ToString(dimensionInfo.EnumType),
		EnumDataType:      dimensionInfo.EnumDataType,
		DimColumn:         dimensionInfo.DimColumn,
		DimExpr:           dimensionInfo.DimExpr,
		DynamicFuncName:   dimensionInfo.DynamicFuncName,
		IsMultiDim:        dimensionInfo.IsMultiDim,
		IsProdIdAttr:      dimensionInfo.IsProdIDAttr,
		ProcessType:       dimensionInfo.ProcessType,
		DimensionCategory: convert.ToString(dimensionInfo.DimensionCategory),
		UpdateUser:        dimensionInfo.UpdateUser,
	}

	dimGroupArr := strings.Split(dimensionInfo.DimGroupInfo, "#")
	ret.DimensionGroup = dimGroupArr[0]
	if len(dimGroupArr) > 1 {
		ret.DimensionGroupOrder = convert.ToInt64(dimGroupArr[1])
	}
	if len(dimGroupArr) > 2 {
		ret.DimensionGroupDimOrder = convert.ToInt64Ptr(convert.ToInt64(dimGroupArr[2]))
	}

	// 补充关联的业务线
	bizListMap, defaultShowBizListMap, err := d.DimensionListDao.GetBizListByDimID(ctx, req.GetEnvType(), dimID)
	ret.BizList = bizListMap[dimID]
	ret.DefaultShowBizList = defaultShowBizListMap[dimID]

	// 补充枚举值信息
	enumList, err := d.DimensionEnumDao.GetEnumByDimId(ctx, req.GetEnvType(), dimID)
	if err != nil {
		return nil, err
	}

	ret.Values = make([]*dim_manage.EnumElement, 0)
	for _, e := range enumList {
		ret.Values = append(ret.Values, &dim_manage.EnumElement{
			Code:          e.Code,
			Name:          e.Name,
			IsDefaultShow: e.IsDefaultShow,
			TagRank:       e.TagRank,
		})
	}

	return ret, nil
}

// GetDimensionNewestID
func (d *DimManageService) GetDimensionNewestID(ctx context.Context) (string, error) {
	return d.DimensionListDao.GetMaxDimID(ctx, base.EnvType_PPE)
}

// CreateOrUpdateInfraDimension
func (d *DimManageService) CreateOrUpdateInfraDimension(ctx context.Context, req *dim_manage.CreateOrUpdateInfraDimensionRequest) (string, error) {
	email, err := utils.GetOperatorEmailFromContext(ctx)
	if err != nil {
		logs.CtxError(ctx, err.Error())
		return consts.Empty, err
	}

	//dimID := convert.ToInt64(req.DimInfo.Id)
	dimInfo, err := d.GetInfraDimensionDetail(ctx, &dim_manage.GetInfraDimensionDetailRequest{
		DimId:   req.DimInfo.Id,
		EnvType: req.EnvType,
	})
	if err != nil {
		return consts.Empty, err
	}

	// 创建事务
	tx := &gorm.DB{}
	if req.EnvType == base.EnvType_PPE {
		tx = mysql.PpeDB(ctx).Begin()
	} else {
		tx = mysql.DB(ctx).Begin()
	}
	if tx.Error != nil {
		logs.CtxError(ctx, "[SubmitDoradoTask]获取数据库的事务失败，err=%v+", tx.Error.Error())
		return consts.Empty, errors.New("获取数据库的事务失败")
	}

	if dimInfo != nil {
		//logs.CtxInfo(ctx, "debug dimInfo: %s", convert.ToJSONString(dimInfo))
		//logs.CtxInfo(ctx, "debug req.DimInfo: %s", convert.ToJSONString(req.DimInfo))

		// 比较dimInfo 和 req.DimInfo 的diff程度
		similarityScore := compareStructs(dimInfo, req.DimInfo)

		//logs.CtxInfo(ctx, "debug Similarity Score: %s", convert.ToString(similarityScore))
		if similarityScore <= 0.8 {
			logs.CtxError(ctx, "Similarity Score: %s", convert.ToString(similarityScore))
			return consts.Empty, errors.New("改业务线修改的信息与已存在的gap差异大于20%，不允许修改")
		}

		// 记录旧的维度信息
		err = d.OperationLogDao.InsertDimensionInfo(ctx, tx, &dao.OperationLogInfo{
			OperationType: "update_dimension",
			OperationInfo: convert.ToJSONString(dimInfo),
			Operator:      email,
		})
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "OperationLogDao.InsertDimensionInfo Error: %s", err.Error())
			return consts.Empty, err
		}

		// 更新维度信息
		err = d.DimensionListDao.UpdateDimensionInfo(ctx, tx, req.DimInfo, email)
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "DimensionListDao.UpdateDimensionInfo Error: %s", err.Error())
			return consts.Empty, err
		}
	} else {
		err = d.DimensionListDao.InsertDimensionInfo(ctx, tx, req.DimInfo, email)
		if err != nil {
			tx.Rollback()
			logs.CtxError(ctx, "DimensionListDao.InsertDimensionInfo Error: %s", err.Error())
			return consts.Empty, err
		}
	}

	// 更新维度关联的业务线信息
	err = d.DimensionListDao.UpdateDimensionBizInfo(ctx, tx, req.DimInfo)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "DimensionListDao.UpdateDimensionBizInfo Error: %s", err.Error())
		return consts.Empty, err
	}

	// 插入维度枚举值信息
	err = d.DimensionEnumDao.InsertDimensionEnum(ctx, tx, req.DimInfo)
	if err != nil {
		tx.Rollback()
		logs.CtxError(ctx, "DimensionEnumDao.InsertDimensionEnum Error: %s", err.Error())
		return consts.Empty, err
	}

	tx.Commit()
	return req.DimInfo.Id, nil
}

func compareStructs(struct1, struct2 interface{}) float64 {
	v1 := reflect.ValueOf(struct1)
	v2 := reflect.ValueOf(struct2)

	if v1.Type() != v2.Type() {
		return 0.0
	}

	totalFields := 0
	matchingFields := 0

	if v1.Kind() == reflect.Ptr {
		v1 = v1.Elem()
	}

	if v2.Kind() == reflect.Ptr {
		v2 = v2.Elem()
	}

	for i := 0; i < v1.NumField(); i++ {
		field1 := v1.Field(i)
		field2 := v2.Field(i)

		if field1.Kind() == reflect.Struct {
			matchingFields += int(compareStructs(field1.Interface(), field2.Interface()) * float64(field1.NumField()))
			totalFields += field1.NumField()
		} else if field1.Kind() == reflect.Slice {
			sliceMatchingFields, sliceLen := matchSlices(field1, field2)
			matchingFields += sliceMatchingFields
			totalFields += sliceLen
		} else {
			if reflect.DeepEqual(field1.Interface(), field2.Interface()) {
				matchingFields++
			}
			totalFields++
		}
	}

	return float64(matchingFields) / float64(totalFields)
}

func matchSlices(slice1, slice2 reflect.Value) (int, int) {
	matchingElements := 0
	for i := 0; i < slice1.Len(); i++ {
		for j := 0; j < slice2.Len(); j++ {
			if reflect.DeepEqual(slice1.Index(i).Interface(), slice2.Index(j).Interface()) {
				matchingElements++
				break
			}
		}
	}
	fmt.Printf("matchingElements: %d \n", matchingElements)
	fmt.Printf("maxLen: %d, %d \n", slice1.Len(), slice2.Len())
	return matchingElements, utils.If(slice1.Len() > slice2.Len(), slice1.Len(), slice2.Len())
}

func GetDimEnumsByBizFilter(enums []*dimensions.EnumElement, filterEnums []string) []*dimensions.EnumElement {
	if len(filterEnums) > 0 && len(enums) > 0 {
		newRet := make([]*dimensions.EnumElement, 0)
		for _, e := range enums {
			if slices.ContainsString(filterEnums, e.Code) {
				newRet = append(newRet, e)
			}
		}
		return newRet
	}
	return enums
}