package dao

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/mysql"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/dim_manage"
	"code.byted.org/gopkg/logs"
	"code.byted.org/temai/go_lib/convert"
	"gorm.io/gorm"
)

type IDimensionEnumDao interface {
	GetEnumByDimId(ctx context.Context, envType base.EnvType, dimId int64) ([]*EnumInfo, error)
	GetEnumByDimIds(ctx context.Context, envType base.EnvType, dimIds ...int64) (map[int64][]*EnumInfo, error)
	InsertDimensionEnum(ctx context.Context, tx *gorm.DB, dimInfo *dim_manage.DimensionMetaInfo) error
}

type DimensionEnumDao struct{}

type EnumInfo struct {
	DimensionID   int64  `json:"dimension_id"`
	Code          string `json:"code"`
	Name          string `json:"name"`
	IsDefaultShow bool   `json:"is_default_show"`
	TagRank       int64  `json:"tag_rank"`
}

func (*DimensionEnumDao) GetEnumByDimId(ctx context.Context, envType base.EnvType, dimId int64) ([]*EnumInfo, error) {
	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	var ret []*EnumInfo
	err := rdsDB.Raw(`
		select dimension_id, code, name, is_default_show = 1 as is_default_show, tag_rank
		from dimension_enum 
		where dimension_id = ? and is_delete = 0 and sys_date in (select max(sys_date) from dimension_enum where is_delete = 0)
	`, dimId).Scan(&ret).Error
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, dim_id=%v, err=%v", ctx, dimId, err)
		return nil, err
	}

	logs.CtxInfo(ctx, "Query GetEnumByDimId Succeed with params {dim_id: %v}", dimId)
	return ret, nil
}

func (*DimensionEnumDao) GetEnumByDimIds(ctx context.Context, envType base.EnvType, dimIds ...int64) (map[int64][]*EnumInfo, error) {
	if len(dimIds) == 0 {
		logs.CtxWarn(ctx, "GetEnumByDimIds DimIds Empty")
	}
	rdsDB := mysql.PpeDB(ctx)
	if envType == base.EnvType_PROD {
		rdsDB = mysql.DB(ctx)
	}

	var enumList []*EnumInfo
	err := rdsDB.Raw(`
		select dimension_id, code, name, is_default_show = 1 as is_default_show, tag_rank
		from dimension_enum 
		where dimension_id IN ? and is_delete = 0 and sys_date in (select max(sys_date) from dimension_enum where is_delete = 0)
	`, dimIds).Scan(&enumList).Error
	if err != nil {
		logs.CtxError(ctx, "ctx=%v, dimIds=%s, err=%v", ctx, convert.ToJSONString(dimIds), err)
		return nil, err
	}

	dimEnumListMap := make(map[int64][]*EnumInfo)
	for _, enum := range enumList {
		enums, exist := dimEnumListMap[enum.DimensionID]
		if !exist {
			enums = make([]*EnumInfo, 0)
		}
		enums = append(enums, &EnumInfo{
			Code:          enum.Code,
			Name:          enum.Name,
			IsDefaultShow: enum.IsDefaultShow,
		})
		dimEnumListMap[enum.DimensionID] = enums
	}

	logs.CtxInfo(ctx, "Query GetEnumByDimId Succeed with params {dimIds: %s}", convert.ToJSONString(dimIds))
	return dimEnumListMap, nil
}

func (*DimensionEnumDao) InsertDimensionEnum(ctx context.Context, tx *gorm.DB, dimInfo *dim_manage.DimensionMetaInfo) error {
	err := tx.Exec(`delete from dimension_enum where dimension_id = ?`, convert.ToInt64(dimInfo.Id)).Error
	if err != nil {
		logs.CtxError(ctx, "[InsertDimensionEnum]ctx=%v, dim_id=%v, err=%v", ctx, dimInfo.Id, err)
		return err
	}
	logs.CtxInfo(ctx, "[InsertDimensionEnum]清理维度成功, dim_id=%v", dimInfo.Id)
	if len(dimInfo.Values) == 0 {
		logs.CtxInfo(ctx, "[InsertDimensionEnum]ctx=%v, dim_id=%v, enum is empty", ctx, dimInfo.Id)
		return nil
	}

	var sysDate string
	err = tx.Raw(`select max(sys_date) as sys_date from dimension_enum where is_delete = 0`).Scan(&sysDate).Error
	if err != nil {
		logs.CtxError(ctx, "[InsertDimensionEnum]ctx=%v, dim_id=%v, err=%v", ctx, dimInfo.Id, err)
		return err
	}

	for _, enum := range dimInfo.Values {
		err = tx.Exec(`insert into dimension_enum (dimension_id, code, name, is_default_show, tag_rank, sys_date) values (?, ?, ?, ?, ?, ?)`,
			convert.ToInt64(dimInfo.Id), enum.Code, enum.Name, convert.ToInt(enum.IsDefaultShow), enum.TagRank, sysDate).Error
		if err != nil {
			logs.CtxError(ctx, "[InsertDimensionEnum]ctx=%v, dim_id=%v, err=%v", ctx, dimInfo.Id, err)
			return err
		}
	}
	logs.CtxInfo(ctx, "[InsertDimensionEnum]数据更新成功, dim_id=%v", dimInfo.Id)
	return nil
}
