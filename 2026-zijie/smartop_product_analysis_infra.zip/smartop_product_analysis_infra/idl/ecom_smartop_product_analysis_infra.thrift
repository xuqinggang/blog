include "base.thrift"
include "meta_info/meta_info.thrift"
include "dim_manage/dim_manage.thrift"
include "biz_manage/biz_manage.thrift"

namespace go ecom.smartop.product_analysis_infra
// 商品洞察
service SmartopProductAnalysisInfraService {
    /*
        维度管理
     */

    // 获取元数据信息
    meta_info.GetInfraMetaInfoResponse GetInfraMetaInfo(1: meta_info.GetInfraMetaInfoRequest req) (api.get = "/product_analysis_infra/meta_info/get_meta_info", api.category = "维度管理", agw.preserve_base = "true"),

    // 维度管理 - 获取维度列表信息
    dim_manage.GetInfraDimensionListResponse GetInfraDimensionList(1: dim_manage.GetInfraDimensionListRequest req) (api.get = "/product_analysis_infra/dimensions/get_dimension_list", api.category = "维度管理", agw.preserve_base = "true"),

    // 维度管理 - 获取维度详情信息
    dim_manage.GetInfraDimensionDetailResponse GetInfraDimensionDetail(1: dim_manage.GetInfraDimensionDetailRequest req) (api.get = "/product_analysis_infra/dimensions/get_dimension_detail", api.category = "维度管理", agw.preserve_base = "true"),

    // 维度管理 - 新增/编辑维度
    dim_manage.CreateOrUpdateInfraDimensionResponse CreateOrUpdateInfraDimension(1: dim_manage.CreateOrUpdateInfraDimensionRequest req) (api.post = "/product_analysis_infra/dimensions/create_update_dimension", api.category = "维度管理", agw.preserve_base = "true"),

    // 维度管理 - 获取维度ID
    dim_manage.GetDimensionNewestIDResponse GetDimensionNewestID(1: meta_info.GetInfraMetaInfoRequest req) (api.get = "/product_analysis_infra/dimensions/get_newest_id", api.category = "维度管理", agw.preserve_base = "true"),

    // 业务线管理 - 获取业务线列表信息
    biz_manage.GetInfraBizListResponse GetInfraBizList(1: biz_manage.GetInfraBizListRequest req) (api.get = "/product_analysis_infra/biz/get_biz_list", api.category = "业务线管理", agw.preserve_base = "true"),

    // 业务线管理 - 获取业务线详情信息
    biz_manage.GetInfraBizDetailResponse GetInfraBizDetail(1: biz_manage.GetInfraBizDetailRequest req) (api.get = "/product_analysis_infra/biz/get_biz_detail", api.category = "业务线管理", agw.preserve_base = "true"),

    // 业务线管理 - 新增/编辑维度
    biz_manage.CreateOrUpdateInfraBizResponse CreateOrUpdateInfraBiz(1: biz_manage.CreateOrUpdateInfraBizRequest req) (api.post = "/product_analysis_infra/biz/create_update_biz", api.category = "业务线管理", agw.preserve_base = "true"),

    // 获取业务线下的元数据信息
    meta_info.GetInfraBizMetaInfoResponse GetInfraBizMetaInfo(1: meta_info.GetInfraMetaInfoRequest req) (api.get = "/product_analysis_infra/biz/get_meta_info", api.category = "业务线管理", agw.preserve_base = "true"),
}
