namespace py biz_manage
namespace go biz_manage

include "../base.thrift"

struct BizMetaInfo {
    1: string id // 业务线ID
    2: string biz_name // 业务线名称
    3: i64 max_range_day
    4: string date_range_info
    5: string os_table_name
    6: string logic_table_list
    7: string os_api_id
    8: string os_table_id
    9: string threshold_attr_meta
    10: string default_group_attrs
    11: string days_type_list
    12: string user_dimension_code
    13: string required_dim_info
    14: string effect_module // 展示模板
    15: i64 display_order
    16: string multi_dim_api_id
    17: string target_card_api_id
    18: string target_card_overall_api_id
    19: string prod_list_api_id
    20: string target_card_uv_api_id
    21: i64 prod_detail_export_type
    22: string prod_portrait_dims
    23: string prod_portrait_pie_graph_dims
    24: string conclusion_target_map
    25: string hidden_module
    26: string default_funnel_meta
    27: string depend_biz_id
    28: i64 data_delay_day 
    29: string create_time
    30: string update_time // 更新时间
    31: string update_user // 更新人
    32: i64 is_delete // 是否删除
}

// 获取业务线列表
struct GetInfraBizListRequest {
    1: optional string biz_type
    2: base.EnvType env_type // ppe / prod

    255: optional base.Base Base
}
struct GetInfraBizListResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<BizMetaInfo> data

    255: base.BaseResp BaseResp
}
// 获取业务线详情
struct GetInfraBizDetailRequest {
    1: string biz_id
    2: base.EnvType env_type // ppe / prod

    255: optional base.Base Base
}
struct GetInfraBizDetailResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: BizMetaInfo data

    255: base.BaseResp BaseResp
}

// 新增/覆盖 业务线
struct CreateOrUpdateInfraBizRequest {
    1: BizMetaInfo biz_info
    2: base.EnvType env_type // ppe / prod

    255: optional base.Base Base
}
struct CreateOrUpdateInfraBizResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: string data

    255: base.BaseResp BaseResp
}