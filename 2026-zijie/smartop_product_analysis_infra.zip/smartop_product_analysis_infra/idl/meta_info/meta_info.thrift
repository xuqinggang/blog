namespace py meta_info
namespace go meta_info

include "../base.thrift"

struct GetInfraMetaInfoRequest {
    1: optional string biz_type
    2: optional base.EnvType env_type // ppe / prod
    255: optional base.Base Base
}

enum MetaType {
    DIM_SHOW_TYPE // 展示类型
    DIM_ENUM_TYPE // 枚举类型
    DIM_ENUM_DATA_TYPE // 枚举数据类型
    DIM_CATEGORY // 属性类型：人 货 场
    DIM_BIZ_TYPE // 业务线列表
}
struct GetInfraMetaInfoData {
    1: MetaType meta_type
    2: list<base.ElementValue> enums
}
struct GetInfraMetaInfoResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: list<GetInfraMetaInfoData> data

    255: base.BaseResp BaseResp
}

struct DimensionMetaInfo {
    1: string id // 维度ID
    2: string name // 展示名称
    3: i64 selected_operator
    4: i64 attr_type
}

struct GetInfraBizMetaInfoData {
    1: list<DimensionMetaInfo> dimension_list
    2: list<string> effect_module_list
}

struct GetInfraBizMetaInfoResponse {
    1: required i32 code                              // 状态码 0: 成功
    2: required string msg                          // 出错提示消息
    3: GetInfraBizMetaInfoData data

    255: base.BaseResp BaseResp
}