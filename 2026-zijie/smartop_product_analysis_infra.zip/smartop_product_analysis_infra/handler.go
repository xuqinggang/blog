package main

import (
	"context"

	"code.byted.org/ecom/smartop_product_analysis/biz/tools/consts/stcodes"
	"code.byted.org/ecom/smartop_product_analysis/biz/tools/utils"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/dal/db/dao"
	biz_manage_handler "code.byted.org/ecom/smartop_product_analysis_infra/biz/handler/biz_manage"
	dim_manage_handler "code.byted.org/ecom/smartop_product_analysis_infra/biz/handler/dim_manage"
	meta_info_handler "code.byted.org/ecom/smartop_product_analysis_infra/biz/handler/meta_info"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/service/biz_manage_service"
	"code.byted.org/ecom/smartop_product_analysis_infra/biz/service/dim_manage_service"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/base"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/biz_manage"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/dim_manage"
	"code.byted.org/ecom/smartop_product_analysis_infra/kitex_gen/meta_info"
	"code.byted.org/gopkg/logs/v2"
)

// 依赖分层 Main --> Handler --> Service --> Dao
var DimensionListDao = &dao.DimensionListDao{}
var DimensionEnumDao = &dao.DimensionEnumDao{}
var OperationLogDao = &dao.OperationLogDao{}
var BizListDao = &dao.BizListDao{}

var DimManageService = &dim_manage_service.DimManageService{
	DimensionListDao: DimensionListDao,
	DimensionEnumDao: DimensionEnumDao,
	OperationLogDao:  OperationLogDao,
}

var BizManageService = &biz_manage_service.BizManageService{
	BizListDao: BizListDao,
}

var DimManageHandler = &dim_manage_handler.DimManageHandler{
	DimManageService,
}
var MetaInfoHandler = &meta_info_handler.MetaInfoHandler{
	DimManageService: DimManageService,
	BizManageService: BizManageService,
}
var BizManageHandler = &biz_manage_handler.BizManageHandler{
	BizManageService,
}

// ItemServiceImpl implements the last service interface defined in the IDL.
type SmartopProductAnalysisInfraServiceImpl struct{}

// GetInfraMetaInfo implements the SmartopProductAnalysisInfraServiceImpl interface.
func (s *SmartopProductAnalysisInfraServiceImpl) GetInfraMetaInfo(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) (resp *meta_info.GetInfraMetaInfoResponse, err error) {
	resp, err = MetaInfoHandler.GetInfraMetaInfo(ctx, req)
	if resp == nil {
		resp = &meta_info.GetInfraMetaInfoResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetInfraDimensionDetail implements the SmartopProductAnalysisInfraServiceImpl interface.
func (s *SmartopProductAnalysisInfraServiceImpl) GetInfraDimensionDetail(ctx context.Context, req *dim_manage.GetInfraDimensionDetailRequest) (resp *dim_manage.GetInfraDimensionDetailResponse, err error) {
	resp, err = DimManageHandler.GetInfraDimensionDetail(ctx, req)
	if resp == nil {
		resp = &dim_manage.GetInfraDimensionDetailResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// CreateOrUpdateInfraDimension implements the SmartopProductAnalysisInfraServiceImpl interface.
func (s *SmartopProductAnalysisInfraServiceImpl) CreateOrUpdateInfraDimension(ctx context.Context, req *dim_manage.CreateOrUpdateInfraDimensionRequest) (resp *dim_manage.CreateOrUpdateInfraDimensionResponse, err error) {
	resp, err = DimManageHandler.CreateOrUpdateInfraDimension(ctx, req)
	if resp == nil {
		resp = &dim_manage.CreateOrUpdateInfraDimensionResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetDimensionNewestID implements the SmartopProductAnalysisInfraServiceImpl interface.
func (s *SmartopProductAnalysisInfraServiceImpl) GetDimensionNewestID(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) (resp *dim_manage.GetDimensionNewestIDResponse, err error) {
	resp, err = DimManageHandler.GetDimensionNewestID(ctx, req)
	if resp == nil {
		resp = &dim_manage.GetDimensionNewestIDResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetInfraDimensionList implements the SmartopProductAnalysisInfraServiceImpl interface.
func (s *SmartopProductAnalysisInfraServiceImpl) GetInfraDimensionList(ctx context.Context, req *dim_manage.GetInfraDimensionListRequest) (resp *dim_manage.GetInfraDimensionListResponse, err error) {
	resp, err = DimManageHandler.GetInfraDimensionList(ctx, req)
	if resp == nil {
		resp = &dim_manage.GetInfraDimensionListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

func (s *SmartopProductAnalysisInfraServiceImpl) GetInfraBizDetail(ctx context.Context, req *biz_manage.GetInfraBizDetailRequest) (resp *biz_manage.GetInfraBizDetailResponse, err error) {
	resp, err = BizManageHandler.GetInfraBizDetail(ctx, req)
	if resp == nil {
		resp = &biz_manage.GetInfraBizDetailResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctxtest=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil

}
func (s *SmartopProductAnalysisInfraServiceImpl) GetInfraBizList(ctx context.Context, req *biz_manage.GetInfraBizListRequest) (resp *biz_manage.GetInfraBizListResponse, err error) {
	resp, err = BizManageHandler.GetInfraBizList(ctx, req)
	if resp == nil {
		resp = &biz_manage.GetInfraBizListResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}

// GetInfraBizMetaInfo implements the SmartopProductAnalysisInfraServiceImpl interface.
func (s *SmartopProductAnalysisInfraServiceImpl) GetInfraBizMetaInfo(ctx context.Context, req *meta_info.GetInfraMetaInfoRequest) (resp *meta_info.GetInfraBizMetaInfoResponse, err error) {
	resp, err = MetaInfoHandler.GetInfraBizMetaInfo(ctx, req)
	if resp == nil {
		resp = &meta_info.GetInfraBizMetaInfoResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
	return
}

// CreateOrUpdateInfraBiz implements the SmartopProductAnalysisInfraServiceImpl interface.
func (s *SmartopProductAnalysisInfraServiceImpl) CreateOrUpdateInfraBiz(ctx context.Context, req *biz_manage.CreateOrUpdateInfraBizRequest) (resp *biz_manage.CreateOrUpdateInfraBizResponse, err error) {
	resp, err = BizManageHandler.CreateOrUpdateInfraBiz(ctx, req)
	if resp == nil {
		resp = &biz_manage.CreateOrUpdateInfraBizResponse{}
		resp.SetBaseResp(base.NewBaseResp())
	}
	if err != nil {
		if len(resp.GetBaseResp().GetStatusMessage()) == 0 {
			defaultStCode := stcodes.StatusCodeDefaultError // 默认返回前端的 St 错误码
			resp.GetBaseResp().SetStatusCode(defaultStCode.Int())
			resp.GetBaseResp().SetStatusMessage(utils.GetErrorMsg(err.Error(), defaultStCode.String()))
		}
		logs.CtxError(ctx, "ctx=%v,req=%v,err=%v", ctx, req, err)
		return resp, nil
	}
	return resp, nil
}
