PRODUCT="ecom"
SUBSYSTEM="smartop"
MODULE="product_analysis_infra"
APP_TYPE="binary"
